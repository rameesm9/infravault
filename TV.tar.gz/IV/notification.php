<?php

require_once 'config/db.php';
require_once 'includes/audit_helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('notification', 'can_view');


$current_user_id = (int) $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');
$current_user_team = $_SESSION['team'] ?? '';

$success_msg = '';
$error_msg = '';

/*
=====================================================
VISIBILITY HELPERS
=====================================================
| Same private/public/team/user sharing model already used by
| reminders.php / sticky notes -- checks the communication_teams and
| communication_users join tables (config/schema/communications.php).
*/

function canViewCommunication($note, $current_user_id, $current_user_team, $role, $pdo)
{
    if (strtolower($role) === 'admin') return true;
    if ((int) $note['created_by'] === (int) $current_user_id) return true;

    $visibility = $note['visibility'] ?? 'public';

    if ($visibility === 'public') return true;
    if ($visibility === 'private') return false;

    if ($visibility === 'team' && !empty($current_user_team)) {
        $stmt = $pdo->prepare("SELECT 1 FROM communication_teams WHERE communication_id=? AND team_name=? LIMIT 1");
        $stmt->execute([$note['id'], $current_user_team]);
        if ($stmt->fetch()) return true;
    }

    if ($visibility === 'user') {
        $stmt = $pdo->prepare("SELECT 1 FROM communication_users WHERE communication_id=? AND user_id=? LIMIT 1");
        $stmt->execute([$note['id'], $current_user_id]);
        if ($stmt->fetch()) return true;
    }

    return false;
}

function getUniqueTeams($pdo)
{
    $stmt = $pdo->query("SELECT DISTINCT team FROM users WHERE team IS NOT NULL AND team != '' ORDER BY team ASC");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function getCommunicationTeams($pdo, $communication_id)
{
    $stmt = $pdo->prepare("SELECT team_name FROM communication_teams WHERE communication_id=?");
    $stmt->execute([$communication_id]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function getCommunicationUserIds($pdo, $communication_id)
{
    $stmt = $pdo->prepare("SELECT user_id FROM communication_users WHERE communication_id=?");
    $stmt->execute([$communication_id]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}

function getCommunicationVisibilityDisplay($visibility, $id, $pdo)
{
    $visibility = strtolower($visibility ?: 'public');

    if ($visibility === 'private') {
        return '<span class="cn-visibility private">Private</span>';
    }

    if ($visibility === 'team') {
        $stmt = $pdo->prepare("SELECT GROUP_CONCAT(team_name, ', ') as teams FROM communication_teams WHERE communication_id = ?");
        $stmt->execute([$id]);
        $teams = $stmt->fetch(PDO::FETCH_ASSOC)['teams'] ?? '';
        $count = $teams === '' ? 0 : count(explode(',', $teams));
        return '<span class="cn-visibility team" title="' . htmlspecialchars($teams) . '">Team (' . $count . ')</span>';
    }

    if ($visibility === 'user') {
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM communication_users WHERE communication_id = ?");
        $stmt->execute([$id]);
        $count = $stmt->fetch(PDO::FETCH_ASSOC)['count'] ?? 0;
        return '<span class="cn-visibility user">Users (' . $count . ')</span>';
    }

    return '<span class="cn-visibility public">Everyone</span>';
}

/*
=====================================================
PHASE 1 - COMMUNICATIONS TABLE SAFETY / MIGRATION
=====================================================
*/

try {

    /*
     * Check the actual database being used by PHP.
     * Add missing columns automatically.
     */

    $columns = [];

    $column_stmt = $pdo->query("PRAGMA table_info(communications)");

    foreach ($column_stmt->fetchAll(PDO::FETCH_ASSOC) as $column) {
        $columns[$column['name']] = true;
    }

    /*
     * IMPORTANT:
     * Older versions of the application had a required
     * "category" column.
     */
    if (!isset($columns['category'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN category TEXT NOT NULL DEFAULT 'General'
        ");

        $columns['category'] = true;
    }

    if (!isset($columns['note_type'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN note_type TEXT DEFAULT 'Announcement'
        ");

        $columns['note_type'] = true;
    }

    if (!isset($columns['assigned_to'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN assigned_to INTEGER
        ");

        $columns['assigned_to'] = true;
    }

    if (!isset($columns['target_date'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN target_date TEXT
        ");

        $columns['target_date'] = true;
    }

    if (!isset($columns['completion_date'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN completion_date TEXT
        ");

        $columns['completion_date'] = true;
    }

    if (!isset($columns['status'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN status TEXT DEFAULT 'Pending'
        ");

        $columns['status'] = true;
    }

    if (!isset($columns['priority'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN priority TEXT DEFAULT 'Normal'
        ");

        $columns['priority'] = true;
    }

    if (!isset($columns['expiry_date'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN expiry_date TEXT
        ");

        $columns['expiry_date'] = true;
    }

    if (!isset($columns['updated_at'])) {

        $pdo->exec("
            ALTER TABLE communications
            ADD COLUMN updated_at DATETIME
        ");

        $columns['updated_at'] = true;
    }

} catch (PDOException $e) {

    $error_msg = "Database migration error: " . $e->getMessage();
}


/*
=====================================================
LOAD USERS FOR ASSIGNMENT
=====================================================
*/

try {

    $user_stmt = $pdo->query("
        SELECT
            id,
            first_name,
            last_name,
            email
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name ASC
    ");

    $users = $user_stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {

    $users = [];
    $error_msg = "Unable to load users: " . $e->getMessage();
}


/*
=====================================================
CREATE NOTE
=====================================================
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    ($_POST['action'] ?? '') === 'create'
) {

    try {

        $title = trim($_POST['title'] ?? '');
        $message = trim($_POST['message'] ?? '');

        $category = trim(
            $_POST['category'] ?? 'General'
        );

        $note_type = trim(
            $_POST['note_type'] ?? 'Announcement'
        );

        $priority = trim(
            $_POST['priority'] ?? 'Normal'
        );

        $assigned_to = !empty($_POST['assigned_to'])
            ? (int) $_POST['assigned_to']
            : null;

        $target_date = !empty($_POST['target_date'])
            ? $_POST['target_date']
            : null;

        $completion_date = !empty($_POST['completion_date'])
            ? $_POST['completion_date']
            : null;

        $status = trim(
            $_POST['status'] ?? 'Pending'
        );

        $visibility = trim(
            $_POST['visibility'] ?? 'public'
        );

        $selected_teams = $_POST['note_teams'] ?? [];
        $selected_users = $_POST['note_users'] ?? [];

        if (!is_array($selected_teams)) $selected_teams = [];
        if (!is_array($selected_users)) $selected_users = [];

        /*
         * Handover fields are only applicable
         * to Handover Task.
         */
        if ($note_type !== 'Handover Task') {

            $assigned_to = null;
            $target_date = null;
        }

        /*
         * Validate values.
         */
        $allowed_categories = [
            'General',
            'Operational',
            'Infrastructure',
            'Application',
            'Handover'
        ];

        if (!in_array($category, $allowed_categories, true)) {
            $category = 'General';
        }

        $allowed_note_types = [
            'Announcement',
            'General Note',
            'Handover Task'
        ];

        if (!in_array($note_type, $allowed_note_types, true)) {
            $note_type = 'Announcement';
        }

        $allowed_priorities = [
            'Normal',
            'High',
            'Critical'
        ];

        if (!in_array($priority, $allowed_priorities, true)) {
            $priority = 'Normal';
        }

        $allowed_statuses = [
            'Pending',
            'In Progress',
            'Completed'
        ];

        if (!in_array($status, $allowed_statuses, true)) {
            $status = 'Pending';
        }

        $allowed_visibilities = [
            'private',
            'public',
            'team',
            'user'
        ];

        if (!in_array($visibility, $allowed_visibilities, true)) {
            $visibility = 'public';
        }

        if ($title === '' || $message === '') {

            $error_msg =
                "Title and message are required.";

        } else {

            $pdo->beginTransaction();

            /*
             * CATEGORY IS INCLUDED HERE.
             * This matches the older database schema.
             */
            $stmt = $pdo->prepare("
                INSERT INTO communications
                (
                    title,
                    message,
                    category,
                    note_type,
                    priority,
                    assigned_to,
                    target_date,
                    completion_date,
                    status,
                    visibility,
                    created_by,
                    created_at
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?
                )
            ");

            $stmt->execute([
                $title,
                $message,
                $category,
                $note_type,
                $priority,
                $assigned_to,
                $target_date,
                $completion_date,
                $status,
                $visibility,
                $current_user_id,
                date('Y-m-d H:i:s')
            ]);

            // Get the newly created ID
            $new_id = $pdo->lastInsertId();

            if ($visibility === 'team' && !empty($selected_teams)) {
                $team_stmt = $pdo->prepare("INSERT INTO communication_teams (communication_id, team_name) VALUES (?, ?)");
                foreach ($selected_teams as $team) {
                    $team = trim($team);
                    if ($team !== '') {
                        $team_stmt->execute([$new_id, $team]);
                    }
                }
            }

            if ($visibility === 'user' && !empty($selected_users)) {
                $user_stmt = $pdo->prepare("INSERT INTO communication_users (communication_id, user_id) VALUES (?, ?)");
                foreach ($selected_users as $uid) {
                    $uid = (int) $uid;
                    if ($uid > 0) {
                        $user_stmt->execute([$new_id, $uid]);
                    }
                }
            }

            $pdo->commit();

            // Log audit entry
            logCommunicationAudit($pdo, $new_id, 'CREATED', $current_user_id, $_SESSION['first_name'] ?? $_SESSION['name'] ?? 'Unknown', "Title: {$title}");

            $success_msg =
                "Note created successfully.";
        }

    } catch (PDOException $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $error_msg =
            "Unable to create note: " .
            $e->getMessage();
    }
}


/*
=====================================================
UPDATE NOTE
OWNER OR ADMIN ONLY
=====================================================
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    ($_POST['action'] ?? '') === 'update'
) {

    try {

        $id = (int) ($_POST['id'] ?? 0);

        $check = $pdo->prepare("
            SELECT created_by
            FROM communications
            WHERE id = ?
        ");

        $check->execute([$id]);

        $existing = $check->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {

            $error_msg = "Note not found.";

        } else {

            // Check permission: user must have can_edit permission OR be the author
            if (!canEdit($pdo, $current_user_id, $role, 'notification', $existing['created_by'])) {
                $error_msg = "Permission denied. You cannot edit this note.";
            } else {

                $title = trim($_POST['title'] ?? '');
                $message = trim($_POST['message'] ?? '');

                $category = trim(
                    $_POST['category'] ?? 'General'
                );

                $note_type = trim(
                    $_POST['note_type'] ?? 'Announcement'
                );

                $priority = trim(
                    $_POST['priority'] ?? 'Normal'
                );

                $assigned_to = !empty($_POST['assigned_to'])
                    ? (int) $_POST['assigned_to']
                    : null;

                $target_date = !empty($_POST['target_date'])
                    ? $_POST['target_date']
                    : null;

                $completion_date = !empty($_POST['completion_date'])
                    ? $_POST['completion_date']
                    : null;

                $status = trim(
                    $_POST['status'] ?? 'Pending'
                );

                $visibility = trim(
                    $_POST['visibility'] ?? 'public'
                );

                $selected_teams = $_POST['note_teams'] ?? [];
                $selected_users = $_POST['note_users'] ?? [];

                if (!is_array($selected_teams)) $selected_teams = [];
                if (!is_array($selected_users)) $selected_users = [];

                $allowed_visibilities = [
                    'private',
                    'public',
                    'team',
                    'user'
                ];

                if (!in_array($visibility, $allowed_visibilities, true)) {
                    $visibility = 'public';
                }

                if ($note_type !== 'Handover Task') {

                    $assigned_to = null;
                    $target_date = null;
                }

                if ($title === '' || $message === '') {

                    $error_msg =
                        "Title and message are required.";

                } else {

                    $pdo->beginTransaction();

                    $stmt = $pdo->prepare("
                        UPDATE communications
                        SET
                            title = ?,
                            message = ?,
                            category = ?,
                            note_type = ?,
                            priority = ?,
                            assigned_to = ?,
                            target_date = ?,
                            completion_date = ?,
                            status = ?,
                            visibility = ?,
                            updated_at = ?
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $title,
                        $message,
                        $category,
                        $note_type,
                        $priority,
                        $assigned_to,
                        $target_date,
                        $completion_date,
                        $status,
                        $visibility,
                        date('Y-m-d H:i:s'),
                        $id
                    ]);

                    // Clear existing team/user associations -- re-inserted
                    // below from whatever is currently checked.
                    $pdo->prepare("DELETE FROM communication_teams WHERE communication_id=?")->execute([$id]);
                    $pdo->prepare("DELETE FROM communication_users WHERE communication_id=?")->execute([$id]);

                    if ($visibility === 'team' && !empty($selected_teams)) {
                        $team_stmt = $pdo->prepare("INSERT INTO communication_teams (communication_id, team_name) VALUES (?, ?)");
                        foreach ($selected_teams as $team) {
                            $team = trim($team);
                            if ($team !== '') {
                                $team_stmt->execute([$id, $team]);
                            }
                        }
                    }

                    if ($visibility === 'user' && !empty($selected_users)) {
                        $user_stmt = $pdo->prepare("INSERT INTO communication_users (communication_id, user_id) VALUES (?, ?)");
                        foreach ($selected_users as $uid) {
                            $uid = (int) $uid;
                            if ($uid > 0) {
                                $user_stmt->execute([$id, $uid]);
                            }
                        }
                    }

                    $pdo->commit();

                    // Log audit entry
                    logCommunicationAudit($pdo, $id, 'UPDATED', $current_user_id, $_SESSION['first_name'] ?? $_SESSION['name'] ?? 'Unknown', "Title: {$title}");

                    $success_msg =
                        "Note updated successfully.";
                }
            }
        }

    } catch (PDOException $e) {

        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }

        $error_msg =
            "Unable to update note: " .
            $e->getMessage();
    }
}


/*
=====================================================
MARK COMPLETED
=====================================================
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    ($_POST['action'] ?? '') === 'complete'
) {

    try {

        $id = (int) ($_POST['id'] ?? 0);

        // Check if communication exists and user has permission to edit
        $check = $pdo->prepare("
            SELECT created_by
            FROM communications
            WHERE id = ?
        ");

        $check->execute([$id]);
        $existing = $check->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {
            $error_msg = "Note not found.";
        } elseif (!canEdit($pdo, $current_user_id, $role, 'notification', $existing['created_by'])) {
            $error_msg = "Permission denied. You cannot mark this note as complete.";
        } else {

            $stmt = $pdo->prepare("
                UPDATE communications
                SET
                    status = 'Completed',
                    completion_date = ?,
                    updated_at = ?
                WHERE id = ?
            ");

            $stmt->execute([date('Y-m-d'), date('Y-m-d H:i:s'), $id]);

            // Log audit entry
            logCommunicationAudit($pdo, $id, 'STATUS_CHANGED', $current_user_id, $_SESSION['first_name'] ?? $_SESSION['name'] ?? 'Unknown', "Status changed to Completed");

            $success_msg =
                "Task marked as completed.";
        }

    } catch (PDOException $e) {

        $error_msg =
            "Unable to complete note: " .
            $e->getMessage();
    }
}


/*
=====================================================
DELETE NOTE
=====================================================
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    ($_POST['action'] ?? '') === 'delete'
) {

    try {

        $id = (int) ($_POST['id'] ?? 0);

        $check = $pdo->prepare("
            SELECT created_by
            FROM communications
            WHERE id = ?
        ");

        $check->execute([$id]);

        $note = $check->fetch(PDO::FETCH_ASSOC);

        if (!$note) {

            $error_msg = "Note not found.";

        } elseif (!canDelete($pdo, $current_user_id, $role, 'notification', $note['created_by'])) {

            $error_msg =
                "Permission denied. You cannot delete this note.";

        } else {

            $delete = $pdo->prepare("
                DELETE FROM communications
                WHERE id = ?
            ");

            $delete->execute([$id]);

            // Delete associated team/user sharing entries
            $pdo->prepare("DELETE FROM communication_teams WHERE communication_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM communication_users WHERE communication_id=?")->execute([$id]);

            // Log audit entry
            logCommunicationAudit($pdo, $id, 'DELETED', $current_user_id, $_SESSION['first_name'] ?? $_SESSION['name'] ?? 'Unknown', "Communication ID: {$id}");

            $success_msg =
                "Note deleted successfully.";
        }

    } catch (PDOException $e) {

        $error_msg =
            "Unable to delete note: " .
            $e->getMessage();
    }
}


/*
=====================================================
FETCH AUDIT HISTORY (AJAX)
=====================================================
*/

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'get_audit_history'){

    header('Content-Type: application/json');

    $type = $_POST['type'] ?? 'communication';
    $id = (int)($_POST['id'] ?? 0);

    // Check permission
    if(!canAudit($pdo, $current_user_id, $role, $type)) {
        echo json_encode(['error' => 'No audit permission']);
        exit;
    }

    $history = [];

    // If ID is provided, get history for that specific record
    if($id > 0) {
        $history = getCommunicationAuditHistory($pdo, $id);
    } else {
        // Get all history for the module type
        $history = getAllAuditHistory($pdo, $type);
    }

    echo json_encode($history);
    exit;
}


/*
=====================================================
FETCH NOTES
=====================================================
*/

try {

    $notes_stmt = $pdo->query("
        SELECT

            c.*,

            creator.first_name AS creator_first,
            creator.last_name AS creator_last,

            assignee.first_name AS assigned_first,
            assignee.last_name AS assigned_last

        FROM communications c

        LEFT JOIN users creator
            ON c.created_by = creator.id

        LEFT JOIN users assignee
            ON c.assigned_to = assignee.id

        ORDER BY c.created_at DESC
    ");

    $all_notes = $notes_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Filter notes based on visibility (private/public/team/user)
    $notes = array_values(array_filter($all_notes, function ($note) use ($current_user_id, $current_user_team, $role, $pdo) {
        return canViewCommunication($note, $current_user_id, $current_user_team, $role, $pdo);
    }));

} catch (PDOException $e) {

    $notes = [];

    $error_msg =
        "Unable to load notes: " .
        $e->getMessage();
}

$teams = getUniqueTeams($pdo);

$page_title = "Team Notes & Handover Board | InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<div class="content">

    <!-- =================================================
         PAGE HEADER
    ================================================== -->

    <div class="dashboard-header">

        <div>

            <h1>
                Team Notes & Handover Board
            </h1>

            <p>
                Manage announcements, operational notes
                and handover activities.
            </p>

        </div>

        <div style="display: flex; gap: 10px;">

            <?php if(canAudit($pdo, $current_user_id, $role, 'communication')): ?>
                <button
                    type="button"
                    class="cn-btn cn-btn-secondary"
                    onclick="showAllAuditHistory('communication'); return false;">
                    ⏱ History
                </button>
            <?php endif; ?>

            <button
                type="button"
                class="cn-btn cn-btn-primary"
                onclick="openNoteModal()">

                <span class="cn-btn-icon">+</span>

                Add Note

            </button>

        </div>

    </div>


    <!-- =================================================
         ALERTS
    ================================================== -->

    <?php if ($success_msg): ?>

        <div class="cn-alert success">
            <?= htmlspecialchars($success_msg) ?>
        </div>

    <?php endif; ?>


    <?php if ($error_msg): ?>

        <div class="cn-alert error">
            <?= htmlspecialchars($error_msg) ?>
        </div>

    <?php endif; ?>


    <!-- =================================================
         NOTES LIST
    ================================================== -->

    <div class="dashboard-panel">

        <div class="panel-header">

            <h3>
                Operational Notes
            </h3>

            <span>
                <?= count($notes) ?> Notes
            </span>

        </div>


        <?php if (empty($notes)): ?>

            <div class="bd-empty">
                No notes available.
            </div>

        <?php else: ?>

            <?php foreach ($notes as $note): ?>

                <div class="note-board-item">

                    <div class="note-title-row">

                        <div>

                            <h3>
                                <?= htmlspecialchars(
                                    $note['title']
                                ) ?>
                            </h3>

                            <ul class="note-info">

                                <li>
                                    Category:

                                    <strong>
                                        <?= htmlspecialchars(
                                            $note['category'] ?? 'General'
                                        ) ?>
                                    </strong>
                                </li>

                                <li>
                                    Type:

                                    <strong>
                                        <?= htmlspecialchars(
                                            $note['note_type']
                                        ) ?>
                                    </strong>
                                </li>

                                <li>
                                    Created By:

                                    <strong>
                                        <?= htmlspecialchars(
                                            trim(
                                                ($note['creator_first'] ?? '') .
                                                ' ' .
                                                ($note['creator_last'] ?? '')
                                            )
                                        ) ?>
                                    </strong>
                                </li>

                                <li>
                                    Created:

                                    <strong>
                                        <?= htmlspecialchars(
                                            $note['created_at']
                                        ) ?>
                                    </strong>
                                </li>

                                <li>
                                    Visibility:

                                    <?= getCommunicationVisibilityDisplay($note['visibility'] ?? 'public', $note['id'], $pdo) ?>
                                </li>


                                <?php if (
                                    $note['note_type'] ===
                                    'Handover Task'
                                ): ?>

                                    <li>

                                        Assigned To:

                                        <strong>

                                            <?php
                                                $noteAssigneeLabel = trim((string) ($note['assigned_to_name'] ?? ''));
                                                if ($noteAssigneeLabel === '' && !empty($note['assigned_first'])) {
                                                    $noteAssigneeLabel = trim($note['assigned_first'] . ' ' . $note['assigned_last']);
                                                }
                                                echo htmlspecialchars($noteAssigneeLabel !== '' ? $noteAssigneeLabel : 'Not Assigned');
                                            ?>

                                        </strong>

                                    </li>


                                    <li>

                                        Target Date:

                                        <strong>

                                            <?= htmlspecialchars(
                                                $note['target_date'] ?: '-'
                                            ) ?>

                                        </strong>

                                    </li>


                                    <li>

                                        Completion Date:

                                        <strong>

                                            <?= htmlspecialchars(
                                                $note['completion_date'] ?: '-'
                                            ) ?>

                                        </strong>

                                    </li>

                                <?php endif; ?>


                                <li>

                                    Status:

                                    <?php if (
                                        $note['status'] ===
                                        'Completed'
                                    ): ?>

                                        <span
                                            class="cn-status completed">
                                            Completed
                                        </span>

                                    <?php elseif (
                                        $note['status'] ===
                                        'In Progress'
                                    ): ?>

                                        <span
                                            class="cn-status progress">
                                            In Progress
                                        </span>

                                    <?php else: ?>

                                        <span
                                            class="cn-status pending">
                                            Pending
                                        </span>

                                    <?php endif; ?>

                                </li>

                            </ul>

                        </div>


                        <div>

                            <?php if (
                                $note['priority'] ===
                                'Critical'
                            ): ?>

                                <span
                                    class="cn-priority critical">
                                    Critical
                                </span>

                            <?php elseif (
                                $note['priority'] ===
                                'High'
                            ): ?>

                                <span
                                    class="cn-priority high">
                                    High
                                </span>

                            <?php else: ?>

                                <span
                                    class="cn-priority normal">
                                    Normal
                                </span>

                            <?php endif; ?>

                        </div>

                    </div>


                    <div class="note-message">

                        <?= nl2br(
                            htmlspecialchars(
                                $note['message']
                            )
                        ) ?>

                    </div>


                    <div class="note-actions">

                        <?php

                        $can_manage =
                            $role === 'Admin'
                            ||
                            (int) $note['created_by']
                            === $current_user_id;

                        ?>


                        <?php if (
                            $note['status'] !==
                            'Completed'
                        ): ?>

                            <form
                                method="POST"
                                style="display:inline;">

                                <input
                                    type="hidden"
                                    name="action"
                                    value="complete">

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= $note['id'] ?>">

                                <button
                                    type="submit"
                                    class="cn-btn cn-btn-success">

                                    ✓ Complete

                                </button>

                            </form>

                        <?php endif; ?>


                        <?php if ($can_manage): ?>

                            <?php
                                $note_js = $note;
                                $note_js['_visibility_teams'] = ($note['visibility'] ?? '') === 'team' ? getCommunicationTeams($pdo, $note['id']) : [];
                                $note_js['_visibility_users'] = ($note['visibility'] ?? '') === 'user' ? getCommunicationUserIds($pdo, $note['id']) : [];
                            ?>

                            <button
                                type="button"
                                class="cn-btn cn-btn-edit"
                                onclick='editNote(
                                    <?= json_encode(
                                        $note_js,
                                        JSON_HEX_TAG |
                                        JSON_HEX_APOS |
                                        JSON_HEX_QUOT |
                                        JSON_HEX_AMP
                                    ) ?>
                                )'>

                                ✎ Edit

                            </button>


                            <form
                                method="POST"
                                style="display:inline;"
                                onsubmit="
                                    return confirm(
                                        'Delete this note?'
                                    );
                                ">

                                <input
                                    type="hidden"
                                    name="action"
                                    value="delete">

                                <input
                                    type="hidden"
                                    name="id"
                                    value="<?= $note['id'] ?>">

                                <button
                                    type="submit"
                                    class="cn-btn cn-btn-danger">

                                    🗑 Delete

                                </button>

                            </form>

                        <?php endif; ?>

                    </div>

                </div>

            <?php endforeach; ?>

        <?php endif; ?>

    </div>

</div>


<!-- =====================================================
     ADD / EDIT MODAL
===================================================== -->

<div
    id="noteModal"
    class="cn-modal"
    aria-hidden="true">

    <div
        class="cn-modal-box"
        role="dialog"
        aria-modal="true"
        aria-labelledby="modalTitle">


        <!-- HEADER -->

        <div class="cn-modal-header">

            <div>

                <div class="cn-modal-eyebrow">
                    TEAM COMMUNICATION
                </div>

                <h2 id="modalTitle">
                    Add New Note
                </h2>

                <p id="modalSubtitle">
                    Create an announcement, operational
                    note, or handover task.
                </p>

            </div>

            <button
                type="button"
                class="cn-close"
                onclick="closeNoteModal()"
                aria-label="Close">

                &times;

            </button>

        </div>


        <!-- FORM -->

        <form
            method="POST"
            id="noteForm">

            <input
                type="hidden"
                name="action"
                id="form_action"
                value="create">

            <input
                type="hidden"
                name="id"
                id="note_id">


            <div class="cn-form-grid">


                <!-- TITLE -->

                <div
                    class="bd-field cn-field-full">

                    <label for="note_title">
                        Title
                    </label>

                    <input
                        type="text"
                        name="title"
                        id="note_title"
                        placeholder="Enter note title"
                        autocomplete="off"
                        required>

                </div>


                <!-- CATEGORY -->

                <div class="bd-field">

                    <label for="category">
                        Category
                    </label>

                    <select
                        name="category"
                        id="category">

                        <option value="General">
                            General
                        </option>

                        <option value="Operational">
                            Operational
                        </option>

                        <option value="Infrastructure">
                            Infrastructure
                        </option>

                        <option value="Application">
                            Application
                        </option>

                        <option value="Handover">
                            Handover
                        </option>

                    </select>

                </div>


                <!-- NOTE TYPE -->

                <div class="bd-field">

                    <label for="note_type">
                        Note Type
                    </label>

                    <select
                        name="note_type"
                        id="note_type"
                        onchange="toggleHandover()">

                        <option value="Announcement">
                            Announcement
                        </option>

                        <option value="General Note">
                            General Note
                        </option>

                        <option value="Handover Task">
                            Handover Task
                        </option>

                    </select>

                </div>


                <!-- PRIORITY -->

                <div class="bd-field">

                    <label for="priority">
                        Priority
                    </label>

                    <select
                        name="priority"
                        id="priority">

                        <option value="Normal">
                            Normal
                        </option>

                        <option value="High">
                            High
                        </option>

                        <option value="Critical">
                            Critical
                        </option>

                    </select>

                </div>


                <!-- STATUS -->

                <div class="bd-field">

                    <label for="status">
                        Status
                    </label>

                    <select
                        name="status"
                        id="status">

                        <option value="Pending">
                            Pending
                        </option>

                        <option value="In Progress">
                            In Progress
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                    </select>

                </div>


                <!-- HANDOVER -->

                <div
                    id="handoverFields"
                    class="cn-handover-fields cn-field-full"
                    style="display:none;">

                    <div class="cn-handover-title">

                        <span>
                            Handover Assignment
                        </span>

                    </div>

                    <div class="cn-handover-grid">

                        <div class="bd-field">

                            <label for="assigned_to">
                                Assign User
                            </label>

                            <select
                                name="assigned_to"
                                id="assigned_to">

                                <option value="">
                                    -- Select User --
                                </option>

                                <?php foreach (
                                    $users as $u
                                ): ?>

                                    <option
                                        value="<?= $u['id'] ?>">

                                        <?= htmlspecialchars(
                                            $u['first_name'] .
                                            ' ' .
                                            $u['last_name']
                                        ) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>


                        <div class="bd-field">

                            <label for="target_date">
                                Target Date
                            </label>

                            <input
                                type="date"
                                name="target_date"
                                id="target_date">

                        </div>

                    </div>

                </div>


                <!-- MESSAGE -->

                <div
                    class="bd-field cn-field-full">

                    <label for="note_message">
                        Message
                    </label>

                    <textarea
                        name="message"
                        id="note_message"
                        rows="6"
                        placeholder="Enter your message or operational note..."
                        required></textarea>

                </div>


                <!-- VISIBILITY -->

                <div class="bd-field cn-field-full cn-visibility-field">

                    <label>Visibility</label>

                    <div class="cn-visibility-options">
                        <label class="cn-visibility-option">
                            <input type="radio" name="visibility" value="public" class="note-visibility-radio" checked>
                            <span>Public (everyone)</span>
                        </label>
                        <label class="cn-visibility-option">
                            <input type="radio" name="visibility" value="private" class="note-visibility-radio">
                            <span>Private (only me)</span>
                        </label>
                        <label class="cn-visibility-option">
                            <input type="radio" name="visibility" value="team" class="note-visibility-radio">
                            <span>Team</span>
                        </label>
                        <label class="cn-visibility-option">
                            <input type="radio" name="visibility" value="user" class="note-visibility-radio">
                            <span>Specific Users</span>
                        </label>
                    </div>

                    <div id="note-team-selector" class="cn-visibility-selector" style="display: none;">
                        <label>Select Teams</label>
                        <div class="cn-visibility-checklist">
                            <?php foreach ($teams as $team): ?>
                            <label class="cn-visibility-option">
                                <input type="checkbox" name="note_teams[]" value="<?= htmlspecialchars($team) ?>">
                                <span><?= htmlspecialchars($team) ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div id="note-user-selector" class="cn-visibility-selector" style="display: none;">
                        <label>Select Users</label>
                        <div class="cn-visibility-checklist">
                            <?php foreach ($users as $u): ?>
                            <label class="cn-visibility-option">
                                <input type="checkbox" name="note_users[]" value="<?= (int) $u['id'] ?>">
                                <span><?= htmlspecialchars($u['first_name'] . ' ' . $u['last_name'] . ' (' . $u['email'] . ')') ?></span>
                            </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                </div>


                <!-- COMPLETION DATE -->

                <div class="bd-field">

                    <label for="completion_date">
                        Completion Date
                    </label>

                    <input
                        type="date"
                        name="completion_date"
                        id="completion_date">

                </div>


            </div>


            <!-- FOOTER -->

            <div class="cn-modal-footer">

                <button
                    type="button"
                    class="cn-btn cn-btn-secondary"
                    onclick="closeNoteModal()">

                    Cancel

                </button>

                <button
                    type="submit"
                    class="cn-btn cn-btn-primary cn-btn-save">

                    <span class="cn-save-icon">
                        ✓
                    </span>

                    <span id="saveButtonText">
                        Save Note
                    </span>

                </button>

            </div>

        </form>

    </div>

</div>


<!-- AUDIT HISTORY MODAL -->
<style>
#auditModal { animation: modalOverlayFadeIn .18s ease-out; }
#auditModal > div { animation: auditModalPopIn .22s cubic-bezier(.16, 1, .3, 1); }
@keyframes modalOverlayFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes auditModalPopIn { from { opacity: 0; transform: translate(-50%, -50%) scale(.96); } to { opacity: 1; transform: translate(-50%, -50%) scale(1); } }
@media (prefers-reduced-motion: reduce) { #auditModal, #auditModal > div { animation: none; } }
</style>
<div id="auditModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: var(--bg-content); border-radius: 8px; padding: 30px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 id="auditTitle" style="margin: 0;">Audit History</h2>
            <button onclick="closeAuditHistory()" style="background: none; border: none; font-size: 24px; cursor: pointer;">✕</button>
        </div>
        <div id="auditContent" style="max-height: 500px; overflow-y: auto;">
            <!-- Audit entries will be loaded here -->
        </div>
    </div>
</div>


<style>

/* =====================================================
   BUTTONS
===================================================== */

.cn-btn {
    border: 0;
    border-radius: 9px;
    padding: 9px 15px;
    font-size: 13px;
    font-weight: 700;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    transition:
        background .18s ease,
        transform .18s ease,
        box-shadow .18s ease,
        opacity .18s ease;
    text-decoration: none;
}

.cn-btn:hover {
    transform: translateY(-1px);
}

.cn-btn:active {
    transform: translateY(0);
}

.cn-btn-primary {
    background: #2563eb;
    color: #fff;
    box-shadow: 0 4px 12px rgba(37, 99, 235, .22);
}

.cn-btn-primary:hover {
    background: #1d4ed8;
    box-shadow: 0 6px 16px rgba(37, 99, 235, .28);
}

.cn-btn-secondary {
    background: var(--hover-bg);
    color: var(--text-primary);
    border: 1px solid var(--border-color);
}

.cn-btn-secondary:hover {
    background: var(--border-color);
}

.cn-btn-success {
    background: #16a34a;
    color: #fff;
}

.cn-btn-edit {
    background: #0ea5e9;
    color: #fff;
}

.cn-btn-danger {
    background: #dc2626;
    color: #fff;
}

.cn-btn-icon {
    font-size: 18px;
    line-height: 1;
}

.cn-btn-save {
    min-width: 125px;
}

.cn-save-icon {
    font-size: 14px;
}


/* =====================================================
   ALERTS
===================================================== */

.cn-alert {
    padding: 14px 18px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-size: 14px;
    font-weight: 600;
}

.cn-alert.success {
    background: #ecfdf5;
    color: #047857;
    border: 1px solid #a7f3d0;
}

.cn-alert.error {
    background: #fef2f2;
    color: #b91c1c;
    border: 1px solid #fecaca;
}


/* =====================================================
   NOTE CARD
===================================================== */

.note-board-item {
    background: var(--bg-content);
    border-radius: 14px;
    padding: 22px;
    margin-bottom: 18px;
    border-left: 5px solid #2563eb;
    box-shadow: 0 4px 15px rgba(15, 23, 42, .08);
}

.note-title-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    gap: 20px;
}

.note-title-row h3 {
    margin: 0 0 10px;
    font-size: 18px;
    color: var(--text-primary);
}

.note-info {
    list-style: none;
    padding: 0;
    margin: 0;
}

.note-info li {
    display: inline-block;
    margin-right: 20px;
    margin-bottom: 8px;
    color: var(--text-secondary);
    font-size: 13px;
}

.note-info strong {
    color: var(--text-primary);
}

.note-message {
    margin-top: 18px;
    padding: 15px;
    background: var(--hover-bg);
    border-radius: 10px;
    color: var(--text-primary);
    line-height: 1.6;
    font-size: 14px;
}

.note-actions {
    margin-top: 18px;
    padding-top: 15px;
    border-top: 1px solid var(--border-color);
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
}


/* =====================================================
   STATUS
===================================================== */

.cn-status {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.cn-status.completed {
    background: #dcfce7;
    color: #15803d;
}

.cn-status.progress {
    background: #dbeafe;
    color: #1d4ed8;
}

.cn-status.pending {
    background: #fef3c7;
    color: #92400e;
}


/* =====================================================
   PRIORITY
===================================================== */

.cn-priority {
    display: inline-block;
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.cn-priority.normal {
    background: #ecfdf5;
    color: #047857;
}

.cn-priority.high {
    background: #fff7ed;
    color: #c2410c;
}

.cn-priority.critical {
    background: #fef2f2;
    color: #b91c1c;
}


/* =====================================================
   VISIBILITY
===================================================== */

.cn-visibility {
    display: inline-block;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 700;
}

.cn-visibility.public {
    background: #dcfce7;
    color: #166534;
}

.cn-visibility.private {
    background: #fee2e2;
    color: #991b1b;
}

.cn-visibility.team {
    background: #dbeafe;
    color: #1e40af;
}

.cn-visibility.user {
    background: #fce7f3;
    color: #831843;
}


/* =====================================================
   VISIBILITY FIELD (form)
===================================================== */

.cn-visibility-field label {
    display: block;
}

.cn-visibility-options {
    display: flex;
    flex-wrap: wrap;
    gap: 8px 20px;
    margin-top: 8px;
}

.cn-visibility-selector {
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px solid var(--border-color);
}

.cn-visibility-selector label {
    margin-bottom: 6px;
}

.cn-visibility-checklist {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(170px, 1fr));
    gap: 6px 16px;
    max-height: 150px;
    overflow-y: auto;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 10px 12px;
}

.cn-visibility-field .cn-visibility-option {
    display: inline-flex !important;
    align-items: center;
    gap: 6px;
    margin: 0 !important;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    white-space: nowrap;
}

.cn-visibility-field input[type="radio"],
.cn-visibility-field input[type="checkbox"] {
    width: 15px;
    height: 15px;
    flex: none;
    accent-color: #2563eb;
}


/* =====================================================
   MODAL OVERLAY
===================================================== */

.cn-modal {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 5000;
    padding: 30px 20px;
    background: rgba(15, 23, 42, .62);
    backdrop-filter: blur(4px);
    overflow-y: auto;
    animation: modalOverlayFadeIn .18s ease-out;
}

@keyframes modalOverlayFadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
}


/* =====================================================
   MODAL BOX
===================================================== */

.cn-modal-box {
    width: 100%;
    max-width: 700px;
    margin: 10px auto;
    background: var(--bg-content);
    border-radius: 18px;
    overflow: hidden;
    box-shadow:
        0 25px 70px rgba(15, 23, 42, .28);
    animation: noteModalOpen .18s ease-out;
}

@keyframes noteModalOpen {

    from {
        opacity: 0;
        transform: translateY(-12px) scale(.985);
    }

    to {
        opacity: 1;
        transform: translateY(0) scale(1);
    }
}

@media (prefers-reduced-motion: reduce) {
    .cn-modal,
    .cn-modal-box {
        animation: none;
    }
}


/* =====================================================
   MODAL HEADER
===================================================== */

.cn-modal-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 20px;
    padding: 24px 28px 20px;
    border-bottom: 1px solid var(--border-color);
    background:
        linear-gradient(
            180deg,
            #ffffff 0%,
            #f8fafc 100%
        );
}

[data-theme="dark"] .cn-modal-header {
    background:
        linear-gradient(
            180deg,
            var(--bg-content) 0%,
            var(--hover-bg) 100%
        );
}

.cn-modal-eyebrow {
    color: #2563eb;
    font-size: 10px;
    font-weight: 800;
    letter-spacing: .12em;
    margin-bottom: 5px;
}

.cn-modal-header h2 {
    margin: 0;
    color: var(--text-primary);
    font-size: 22px;
    line-height: 1.25;
}

.cn-modal-header p {
    margin: 6px 0 0;
    color: var(--text-secondary);
    font-size: 13px;
}

.cn-close {
    flex: 0 0 auto;
    width: 36px;
    height: 36px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    background: var(--bg-content);
    color: var(--text-secondary);
    font-size: 24px;
    line-height: 1;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    transition: .18s;
}

.cn-close:hover {
    background: var(--hover-bg);
    color: var(--text-primary);
}


/* =====================================================
   FORM
===================================================== */

#noteForm {
    padding: 24px 28px 0;
}

.cn-form-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 17px 18px;
}

.cn-field-full {
    grid-column: 1 / -1;
}

.bd-field {
    margin: 0;
}

.bd-field label {
    display: block;
    margin-bottom: 7px;
    color: var(--text-primary);
    font-size: 13px;
    font-weight: 700;
}

.bd-field input,
.bd-field select,
.bd-field textarea {
    box-sizing: border-box;
    width: 100%;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    background: var(--bg-content);
    color: var(--text-primary);
    font-family: inherit;
    font-size: 14px;
    outline: none;
    transition:
        border-color .18s,
        box-shadow .18s,
        background .18s;
}

.bd-field input,
.bd-field select {
    height: 42px;
    padding: 0 12px;
}

.bd-field textarea {
    min-height: 130px;
    padding: 12px;
    resize: vertical;
    line-height: 1.5;
}

.bd-field input::placeholder,
.bd-field textarea::placeholder {
    color: var(--text-muted);
}

.bd-field input:focus,
.bd-field select:focus,
.bd-field textarea:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .10);
}


/* =====================================================
   HANDOVER SECTION
===================================================== */

.cn-handover-fields {
    padding: 16px;
    border: 1px solid #bfdbfe;
    border-radius: 12px;
    background: #eff6ff;
}

[data-theme="dark"] .cn-handover-fields {
    background: rgba(37, 99, 235, .15);
    border-color: rgba(59, 130, 246, .35);
}

.cn-handover-title {
    margin-bottom: 14px;
    color: #1d4ed8;
    font-size: 12px;
    font-weight: 800;
    text-transform: uppercase;
    letter-spacing: .05em;
}

[data-theme="dark"] .cn-handover-title {
    color: #93c5fd;
}

.cn-handover-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 16px;
}


/* =====================================================
   MODAL FOOTER
===================================================== */

.cn-modal-footer {
    margin-top: 25px;
    padding: 18px 28px;
    border-top: 1px solid var(--border-color);
    background: var(--hover-bg);
    display: flex;
    justify-content: flex-end;
    align-items: center;
    gap: 10px;
}


/* =====================================================
   RESPONSIVE
===================================================== */

@media (max-width: 700px) {

    .cn-modal {
        padding: 12px;
    }

    .cn-modal-box {
        margin: 0 auto;
        border-radius: 14px;
    }

    .cn-modal-header {
        padding: 20px;
    }

    #noteForm {
        padding: 20px 20px 0;
    }

    .cn-form-grid {
        grid-template-columns: 1fr;
    }

    .cn-field-full {
        grid-column: auto;
    }

    .cn-handover-grid {
        grid-template-columns: 1fr;
    }

    .cn-modal-footer {
        padding: 16px 20px;
    }

    .note-title-row {
        flex-direction: column;
    }

    .note-info li {
        display: block;
        margin-right: 0;
    }

}


/* =====================================================
   MOBILE BUTTONS
===================================================== */

@media (max-width: 480px) {

    .cn-modal-footer {
        flex-direction: column-reverse;
        align-items: stretch;
    }

    .cn-modal-footer .cn-btn {
        width: 100%;
    }

}

</style>


<script>

/*
=====================================================
OPEN CREATE MODAL
=====================================================
*/

function openNoteModal() {

    const modal =
        document.getElementById("noteModal");

    document.getElementById(
        "modalTitle"
    ).textContent = "Add New Note";

    document.getElementById(
        "modalSubtitle"
    ).textContent =
        "Create an announcement, operational note, or handover task.";

    document.getElementById(
        "form_action"
    ).value = "create";

    document.getElementById(
        "note_id"
    ).value = "";

    document.getElementById(
        "note_title"
    ).value = "";

    document.getElementById(
        "category"
    ).value = "General";

    document.getElementById(
        "note_type"
    ).value = "Announcement";

    document.getElementById(
        "priority"
    ).value = "Normal";

    document.getElementById(
        "note_message"
    ).value = "";

    document.getElementById(
        "assigned_to"
    ).value = "";

    document.getElementById(
        "target_date"
    ).value = "";

    document.getElementById(
        "completion_date"
    ).value = "";

    document.getElementById(
        "status"
    ).value = "Pending";

    document.querySelector('input[name="visibility"][value="public"]').checked = true;

    document.querySelectorAll('input[name="note_teams[]"]').forEach(cb => cb.checked = false);
    document.querySelectorAll('input[name="note_users[]"]').forEach(cb => cb.checked = false);

    document.getElementById('note-team-selector').style.display = 'none';
    document.getElementById('note-user-selector').style.display = 'none';

    document.getElementById(
        "saveButtonText"
    ).textContent = "Save Note";

    toggleHandover();

    modal.style.display = "block";

    modal.setAttribute(
        "aria-hidden",
        "false"
    );

    setTimeout(function() {

        document.getElementById(
            "note_title"
        ).focus();

    }, 100);

}


/*
=====================================================
EDIT NOTE
=====================================================
*/

function editNote(note) {

    const modal =
        document.getElementById("noteModal");

    document.getElementById(
        "modalTitle"
    ).textContent = "Edit Note";

    document.getElementById(
        "modalSubtitle"
    ).textContent =
        "Update the note and save your changes.";

    document.getElementById(
        "form_action"
    ).value = "update";

    document.getElementById(
        "note_id"
    ).value = note.id || "";

    document.getElementById(
        "note_title"
    ).value = note.title || "";

    document.getElementById(
        "category"
    ).value =
        note.category || "General";

    document.getElementById(
        "note_type"
    ).value =
        note.note_type || "Announcement";

    document.getElementById(
        "priority"
    ).value =
        note.priority || "Normal";

    document.getElementById(
        "note_message"
    ).value =
        note.message || "";

    document.getElementById(
        "assigned_to"
    ).value =
        note.assigned_to || "";

    document.getElementById(
        "target_date"
    ).value =
        note.target_date || "";

    document.getElementById(
        "completion_date"
    ).value =
        note.completion_date || "";

    document.getElementById(
        "status"
    ).value =
        note.status || "Pending";

    const visibility = note.visibility || "public";
    const visibilityRadio = document.querySelector(`input[name="visibility"][value="${visibility}"]`);
    if (visibilityRadio) {
        visibilityRadio.checked = true;
        visibilityRadio.dispatchEvent(new Event('change'));
    }

    // Pre-check the team/user boxes this note is already shared with --
    // otherwise re-saving with none re-checked silently drops the sharing
    // (update always deletes and re-inserts from whatever is checked).
    const sharedTeams = note._visibility_teams || [];
    const sharedUsers = note._visibility_users || [];

    document.querySelectorAll('input[name="note_teams[]"]').forEach(checkbox => {
        checkbox.checked = sharedTeams.includes(checkbox.value);
    });

    document.querySelectorAll('input[name="note_users[]"]').forEach(checkbox => {
        checkbox.checked = sharedUsers.includes(parseInt(checkbox.value, 10));
    });

    document.getElementById(
        "saveButtonText"
    ).textContent = "Update Note";

    toggleHandover();

    modal.style.display = "block";

    modal.setAttribute(
        "aria-hidden",
        "false"
    );

    setTimeout(function() {

        document.getElementById(
            "note_title"
        ).focus();

    }, 100);

}


/*
=====================================================
CLOSE MODAL
=====================================================
*/

function closeNoteModal() {

    const modal =
        document.getElementById("noteModal");

    modal.style.display = "none";

    modal.setAttribute(
        "aria-hidden",
        "true"
    );

}


/*
=====================================================
HANDOVER FIELDS
=====================================================
*/

function toggleHandover() {

    const type =
        document.getElementById(
            "note_type"
        ).value;

    const box =
        document.getElementById(
            "handoverFields"
        );

    if (type === "Handover Task") {

        box.style.display = "block";

    } else {

        box.style.display = "none";

        document.getElementById(
            "assigned_to"
        ).value = "";

        document.getElementById(
            "target_date"
        ).value = "";
    }

}


/*
=====================================================
VISIBILITY TEAM/USER SELECTOR TOGGLE
=====================================================
*/

document.querySelectorAll('input.note-visibility-radio').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('note-team-selector').style.display = this.value === 'team' ? 'block' : 'none';
        document.getElementById('note-user-selector').style.display = this.value === 'user' ? 'block' : 'none';
    });
});


/*
=====================================================
CLICK OUTSIDE MODAL
=====================================================
*/

window.addEventListener(
    "click",
    function(event) {

        const modal =
            document.getElementById(
                "noteModal"
            );

        if (event.target === modal) {

            closeNoteModal();

        }

    }
);


/*
=====================================================
ESCAPE KEY
=====================================================
*/

document.addEventListener(
    "keydown",
    function(event) {

        if (
            event.key === "Escape"
        ) {

            closeNoteModal();

        }

    }
);

function showAllAuditHistory(type) {
    const modal = document.getElementById('auditModal');
    const auditTitle = document.getElementById('auditTitle');
    const auditContent = document.getElementById('auditContent');

    const titleMap = {
        'communication': 'Communications',
        'reminder': 'Reminders',
        'sticky_note': 'Sticky Notes',
        'mydata': 'My Data'
    };

    auditTitle.textContent = 'Audit History - ' + (titleMap[type] || type);
    auditContent.innerHTML = '<p>Loading...</p>';

    const formData = new FormData();
    formData.append('action', 'get_audit_history');
    formData.append('type', type);

    fetch('notification.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            auditContent.innerHTML = '<p style="color: red;">Error: ' + data.error + '</p>';
            return;
        }

        if (data.length === 0) {
            auditContent.innerHTML = '<p>No audit history found.</p>';
            modal.style.display = 'block';
            return;
        }

        let html = '<table style="width: 100%; border-collapse: collapse;">';
        html += '<tr style="background: #f5f5f5; border-bottom: 1px solid #ddd;">';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Action</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Performed By</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Date/Time</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Details</th>';
        html += '</tr>';

        data.forEach(entry => {
            const actionDate = new Date(entry.action_date);
            const formattedDate = actionDate.toLocaleDateString();
            const formattedTime = actionDate.toLocaleTimeString();
            const details = entry.details ? entry.details : '-';

            html += '<tr style="border-bottom: 1px solid #eee;">';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.action) + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.user_name) + '</td>';
            html += '<td style="padding: 10px;">' + formattedDate + ' ' + formattedTime + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(details) + '</td>';
            html += '</tr>';
        });

        html += '</table>';
        auditContent.innerHTML = html;
        modal.style.display = 'block';
    })
    .catch(error => {
        auditContent.innerHTML = '<p style="color: red;">Error loading audit history: ' + error + '</p>';
        modal.style.display = 'block';
    });
}

function closeAuditHistory() {
    document.getElementById('auditModal').style.display = 'none';
}

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

// Close modal when clicking outside
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('auditModal');
    if (modal) {
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
});

</script>


<?php include 'includes/footer.php'; ?>

