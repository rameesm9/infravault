<?php

/*
| Forced password rotation, reached only after signing in with a temporary
| password issued by forgot-password.php.
|
| No session_start() here -- config/db.php's securityBootstrap() starts it
| with the hardened cookie parameters, same as index.php and
| forgot-password.php.
|
| This page is allowlisted in securityEnforcePasswordChange(), so it is the
| one place a user carrying must_change_password can actually reach. Every
| other page in the application redirects back here until the flag is gone.
*/

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/branding-helpers.php';

$appName = getAppName($pdo);
$appLogoUrl = getAppLogoUrl($pdo);

if (empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Without the flag this would be a way to set a new password without proving
| the current one -- exactly what myprofile.php's "Current Password" field
| exists to prevent. So anyone arriving here who is not mid-rotation is sent
| there instead.
*/
if ((int) ($_SESSION['must_change_password'] ?? 0) !== 1) {
    header('Location: myprofile.php');
    exit;
}

$user_id = $_SESSION['user_id'];
$error   = '';

$stmt = $pdo->prepare("SELECT id, ncgr_id, first_name, password FROM users WHERE id = ? LIMIT 1");
$stmt->execute([$user_id]);
$current_user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$current_user) {
    // The account was deleted while the session was open.
    securityDestroySession();
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    csrfVerifyOrDie();

    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    if ($new_password === '' || $confirm_password === '') {

        $error = 'Enter your new password twice.';

    } elseif ($new_password !== $confirm_password) {

        $error = 'The two passwords do not match.';

    } elseif (password_verify($new_password, $current_user['password'])) {

        /*
        | The point of this screen is to retire the password that was mailed
        | out in plaintext. Accepting it again would leave the account exactly
        | where it started.
        */
        $error = 'Choose a password different from the temporary one you were emailed.';

    } elseif (($policyErrors = validatePasswordPolicy($pdo, $new_password)) !== []) {

        // Password policy from Settings -> Security, the same check signup.php
        // and myprofile.php apply.
        $error = implode(' ', $policyErrors);

    } else {

        $pdo->prepare("
            UPDATE users
            SET password = ?, must_change_password = 0
            WHERE id = ?
        ")->execute([
            password_hash($new_password, PASSWORD_DEFAULT),
            $user_id,
        ]);

        // Clearing the session copy is what lets every other page load again;
        // securityEnforcePasswordChange() reads this, not the column.
        unset($_SESSION['must_change_password']);

        // New credential, new session id -- the same reasoning as
        // securityOnLogin(): anything that knew the old id no longer rides
        // along on the newly re-secured account.
        if (session_status() === PHP_SESSION_ACTIVE) {
            session_regenerate_id(true);
        }

        // Read once by home.php to play a one-time arrival animation --
        // never set for ordinary in-app navigation back to the dashboard.
        $_SESSION['just_logged_in'] = 1;

        header('Location: home.php');
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Set a New Password | <?= htmlspecialchars($appName) ?></title>
<link rel="icon" href="<?= htmlspecialchars($appLogoUrl) ?>">

<style>

@font-face {
    font-family: Inter;
    src: url("assets/webfonts/Inter-Regular.woff2") format("woff2");
    font-weight: 400 700;
}

:root {
    --navy-950: #020617;
    --accent: #22D3EE;
    --accent-2: #2563EB;
    --indigo: #4F46E5;
    --ink: #0F172A;
    --muted: #64748B;
    --border: #E2E8F0;
    --danger-bg: #FEF2F2;
    --danger-border: #FECACA;
    --danger-ink: #991B1B;
    --info-bg: #EFF6FF;
    --info-border: #BFDBFE;
    --info-ink: #1D4ED8;
}

* {
    box-sizing: border-box;
}

html, body {
    height: 100%;
}

body {
    margin: 0;
    min-height: 100vh;
    background: var(--navy-950);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    color: var(--ink);
    position: relative;
    overflow-x: hidden;
}

.backdrop {
    position: fixed;
    inset: 0;
    z-index: 0;
}

.backdrop svg {
    width: 100%;
    height: 100%;
    display: block;
}

.page {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 56px 20px 40px;
}

.lockup {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 34px;
}

.lockup img {
    width: 30px;
    height: 30px;
}

.lockup span {
    font-size: 15px;
    font-weight: 800;
    letter-spacing: .02em;
    color: #F1F5F9;
}

.card-wrap {
    position: relative;
    width: 100%;
    max-width: 430px;
}

.badge {
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-2), var(--accent));
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 12px 30px rgba(34, 211, 238, .35), 0 0 0 6px rgba(255, 255, 255, .06);
    z-index: 2;
}

.badge svg {
    width: 26px;
    height: 26px;
    color: #fff;
}

.card {
    position: relative;
    background: rgba(255, 255, 255, .78);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, .6);
    border-radius: 28px;
    padding: 52px 40px 36px;
    box-shadow: 0 25px 70px rgba(2, 6, 23, .45), inset 0 1px 0 rgba(255, 255, 255, .6);
    text-align: center;
}

.card h2 {
    font-size: 25px;
    font-weight: 800;
    margin: 0 0 6px;
    letter-spacing: -.01em;
}

.card-sub {
    color: var(--muted);
    font-size: 13.5px;
    margin: 0;
}

.banner {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 10px;
    margin: 18px 0 4px;
    font-size: 13px;
    line-height: 1.5;
    text-align: left;
    border: 1px solid transparent;
}

.banner svg {
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    margin-top: 1px;
}

.banner.error {
    background: var(--danger-bg);
    border-color: var(--danger-border);
    color: var(--danger-ink);
}

.banner.info {
    background: var(--info-bg);
    border-color: var(--info-border);
    color: var(--info-ink);
}

form {
    margin-top: 14px;
    text-align: left;
}

.field {
    margin-top: 16px;
}

.field label {
    display: block;
    margin-bottom: 7px;
    font-size: 12.5px;
    font-weight: 700;
    color: #334155;
}

.field-input {
    position: relative;
    display: flex;
    align-items: center;
}

.field-input svg.leading-icon {
    position: absolute;
    left: 15px;
    width: 16px;
    height: 16px;
    color: #94A3B8;
    pointer-events: none;
}

.field input {
    width: 100%;
    padding: 12px 40px 12px 42px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, .12);
    background: rgba(255, 255, 255, .7);
    font-size: 14px;
    font-family: inherit;
    color: var(--ink);
    transition: .15s;
}

.field input:focus {
    outline: none;
    border-color: var(--accent-2);
    background: rgba(255, 255, 255, .95);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .14);
}

.toggle-visibility {
    position: absolute;
    right: 5px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    background: transparent;
    color: #94A3B8;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.toggle-visibility:hover {
    background: #E2E8F0;
    color: #475569;
}

.toggle-visibility svg {
    width: 17px;
    height: 17px;
}

.policy-hint {
    margin: 14px 0 0;
    padding: 10px 14px;
    border-radius: 10px;
    background: rgba(148, 163, 184, .12);
    font-size: 12px;
    line-height: 1.5;
    color: var(--muted);
}

button.submit {
    width: 100%;
    margin-top: 22px;
    padding: 14px;
    border: none;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-2), var(--indigo));
    color: #fff;
    font-size: 14.5px;
    font-weight: 700;
    cursor: pointer;
    transition: filter .15s, transform .1s;
}

button.submit:hover {
    filter: brightness(1.08);
}

button.submit:active {
    transform: translateY(1px);
}

.signout {
    margin-top: 18px;
    font-size: 12.5px;
}

.signout a {
    color: var(--muted);
    text-decoration: none;
    font-weight: 600;
}

.signout a:hover {
    color: #334155;
    text-decoration: underline;
}

.page-footer {
    margin-top: 26px;
    text-align: center;
    font-size: 11.5px;
    color: rgba(148, 163, 184, .6);
}

@media (max-width: 480px) {
    .card {
        padding: 46px 26px 30px;
    }
}

</style>

</head>
<body>

<div class="backdrop" aria-hidden="true">
    <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">

        <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#020617"/>
                <stop offset="55%" stop-color="#0B1220"/>
                <stop offset="100%" stop-color="#0F172A"/>
            </linearGradient>

            <pattern id="floorGrid" width="64" height="64" patternUnits="userSpaceOnUse">
                <path d="M64 0H0V64" fill="none" stroke="#FFFFFF" stroke-opacity="0.045"/>
            </pattern>

            <filter id="blurBlob" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="75"/>
            </filter>
        </defs>

        <rect width="1600" height="900" fill="url(#bgGrad)"/>
        <rect width="1600" height="900" fill="url(#floorGrid)"/>

        <circle cx="230" cy="170" r="230" fill="#22D3EE" opacity="0.28" filter="url(#blurBlob)"/>
        <circle cx="1370" cy="740" r="290" fill="#4F46E5" opacity="0.32" filter="url(#blurBlob)"/>
        <circle cx="1250" cy="160" r="160" fill="#2563EB" opacity="0.18" filter="url(#blurBlob)"/>

    </svg>
</div>

<div class="page">

    <div class="lockup">
        <img src="<?= htmlspecialchars($appLogoUrl) ?>" alt="<?= htmlspecialchars($appName) ?>">
        <span><?= htmlspecialchars($appName) ?></span>
    </div>

    <div class="card-wrap">

        <div class="badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="4" y="11" width="16" height="9" rx="2"/>
                <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
            </svg>
        </div>

        <div class="card">

            <h2>Set a new password</h2>
            <p class="card-sub">
                Hello <?= htmlspecialchars((string) $current_user['first_name'], ENT_QUOTES, 'UTF-8') ?> —
                you signed in with a temporary password
            </p>

            <?php if ($error): ?>

                <div class="banner error">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="9"/>
                        <line x1="12" y1="8" x2="12" y2="13"/>
                        <line x1="12" y1="16" x2="12" y2="16"/>
                    </svg>
                    <span><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></span>
                </div>

            <?php else: ?>

                <div class="banner info">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="9"/>
                        <path d="M12 8v5"/>
                        <line x1="12" y1="16" x2="12" y2="16"/>
                    </svg>
                    <span>Choose your own password to finish signing in. The temporary one stops working once you do.</span>
                </div>

            <?php endif; ?>

            <form method="POST" id="changeForm">

                <?= csrfField() ?>

                <div class="field">
                    <label for="new_password">New Password</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="11" width="16" height="9" rx="2"/>
                            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                        </svg>
                        <input
                            type="password"
                            id="new_password"
                            name="new_password"
                            autocomplete="new-password"
                            required
                            autofocus
                        >
                        <button type="button" class="toggle-visibility" data-target="new_password" aria-label="Show password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="field">
                    <label for="confirm_password">Confirm New Password</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="11" width="16" height="9" rx="2"/>
                            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                        </svg>
                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            autocomplete="new-password"
                            required
                        >
                        <button type="button" class="toggle-visibility" data-target="confirm_password" aria-label="Show password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <p class="policy-hint"><?= htmlspecialchars(describePasswordPolicy($pdo), ENT_QUOTES, 'UTF-8') ?></p>

                <button type="submit" class="submit">Save New Password</button>

            </form>

            <div class="signout">
                <a href="logout.php">Sign out instead</a>
            </div>

        </div>

    </div>

    <div class="page-footer">
        &copy; <?= date('Y') ?> <?= htmlspecialchars($appName) ?> &middot; Internal Enterprise Platform &middot; All access is logged
    </div>

</div>

<script>
(function () {
    document.querySelectorAll('.toggle-visibility').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const input = document.getElementById(btn.getAttribute('data-target'));
            const isHidden = input.type === 'password';
            input.type = isHidden ? 'text' : 'password';
            btn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
        });
    });
})();
</script>

</body>
</html>
