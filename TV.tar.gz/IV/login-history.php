<?php

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/pagination-helpers.php';

requireLogin();

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| Same page_key/verb as the "History" (user record audit) button on
| users.php -- reading who signed in and when is an audit capability,
| not something every user with users.can_view should see.
*/
requirePermission('users', 'can_audit');

$user_id = (int) ($_SESSION['user_id'] ?? 0);


/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
|
| Reads directly from login_attempts (config/schema/security_settings.php).
| That table already doubles as the brute-force audit trail -- it records
| both failed and successful sign-ins -- so this page is a read-only view
| over it rather than a second table to keep in sync. Rows older than
| LOGIN_HISTORY_RETENTION_DAYS are dropped by pruneLoginAttempts(), called
| opportunistically from index.php on every login post.
*/

$keyword = trim($_GET['keyword'] ?? '');
$status  = trim($_GET['status'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if ($keyword !== '') {
    $where_clauses[] = "(identifier LIKE ? OR ip_address LIKE ? OR user_agent LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if ($status === 'success') {
    $where_clauses[] = "success = 1";
} elseif ($status === 'failed') {
    $where_clauses[] = "success = 0";
}

$where_sql = implode(" AND ", $where_clauses);


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$limit = resolveUserPageSize($pdo, $user_id);
$page  = isset($_GET['page']) ? (int) $_GET['page'] : 1;
if ($page < 1) {
    $page = 1;
}
$start = ($page - 1) * $limit;

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM login_attempts WHERE $where_sql");
$total_stmt->execute($params);
$total_records = (int) $total_stmt->fetchColumn();
$total_pages = max(1, (int) ceil($total_records / $limit));

if ($page > $total_pages) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

$data_stmt = $pdo->prepare("
    SELECT identifier, ip_address, success, attempted_at, user_agent
    FROM login_attempts
    WHERE $where_sql
    ORDER BY attempted_at DESC
    LIMIT $limit OFFSET $start
");
$data_stmt->execute($params);
$attempts = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

$hidden_filter_fields = ''
    . '<input type="hidden" name="keyword" value="' . htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') . '">'
    . '<input type="hidden" name="status" value="' . htmlspecialchars($status, ENT_QUOTES, 'UTF-8') . '">';

$page_title = "Login History | InfraVault";

include "includes/header.php";
include "includes/sidebar.php";
?>
<link rel="stylesheet" href="assets/css/ip.css">
<div class="content">
<div class="ip-page">

<div class="page-header">
    <div>
        <h1>Login History</h1>
        <p>Sign-in attempts &mdash; successful and failed &mdash; kept for <?= (int) LOGIN_HISTORY_RETENTION_DAYS ?> days</p>
    </div>
    <a href="users.php" class="secondary-btn">Back to Users</a>
</div>

<div class="ip-toolbar">
    <form method="GET" class="search-box" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <input
            type="text"
            name="keyword"
            placeholder="Search user ID, IP address, browser..."
            value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') ?>"
        >
        <select name="status" class="form-control" style="max-width:160px;">
            <option value="">All statuses</option>
            <option value="success" <?= $status === 'success' ? 'selected' : '' ?>>Successful</option>
            <option value="failed" <?= $status === 'failed' ? 'selected' : '' ?>>Failed</option>
        </select>
        <button class="primary-btn">Search</button>
        <?php if ($keyword !== '' || $status !== ''): ?>
            <a href="login-history.php" class="secondary-btn">Clear</a>
        <?php endif; ?>
        <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
    </form>
</div>

<div class="ip-card">
<table class="ip-table">
<thead>
<tr>
    <th>User ID</th>
    <th>Status</th>
    <th>IP Address</th>
    <th>Browser / Agent</th>
    <th>Date &amp; Time</th>
</tr>
</thead>
<tbody>
<?php if (count($attempts)): ?>
    <?php foreach ($attempts as $a): ?>
    <tr>
        <td><?= htmlspecialchars((string) $a['identifier'], ENT_QUOTES, 'UTF-8') ?></td>
        <td>
            <?php if ((int) $a['success'] === 1): ?>
                <span class="environment" style="background:#dcfce7;color:#166534">Successful</span>
            <?php else: ?>
                <span class="environment" style="background:#fee2e2;color:#991b1b">Failed</span>
            <?php endif; ?>
        </td>
        <td><?= htmlspecialchars((string) $a['ip_address'], ENT_QUOTES, 'UTF-8') ?></td>
        <td style="max-width:320px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?= htmlspecialchars((string) $a['user_agent'], ENT_QUOTES, 'UTF-8') ?>">
            <?= htmlspecialchars((string) $a['user_agent'], ENT_QUOTES, 'UTF-8') ?>
        </td>
        <td><?= htmlspecialchars(date('Y-m-d H:i:s', (int) $a['attempted_at']), ENT_QUOTES, 'UTF-8') ?></td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="5" class="empty">No login history found</td>
    </tr>
<?php endif; ?>
</tbody>
</table>

<?= ivPager($page, $total_pages, [
    'keyword' => $keyword,
    'status'  => $status,
], ['base' => 'login-history.php', 'total_records' => $total_records, 'per_page' => $limit]) ?>

</div>

</div>
</div>
<?php include "includes/footer.php"; ?>
