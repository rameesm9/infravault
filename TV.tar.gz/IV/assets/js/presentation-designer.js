/*
 * Presentation & Document Designer.
 *
 * Fully offline: PptxGenJS and docx.js are vendored under assets/js/vendor/
 * (no CDN, no network calls) and every export runs entirely in the browser.
 * One template definition drives both the on-screen live preview (HTML/CSS)
 * and the real .pptx/.docx file generation, so what you see is what you get.
 */

(function () {
    'use strict';

    /* ---------------------------------------------------------------- */
    /* Helpers                                                           */
    /* ---------------------------------------------------------------- */

    function pdEsc(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

    function pdLines(raw) {
        return String(raw || '').split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
    }

    function pdParts(raw, names) {
        return pdLines(raw).map(function (line) {
            var bits = line.split('|').map(function (s) { return s.trim(); });
            var o = {};
            names.forEach(function (n, i) { o[n] = bits[i] || ''; });
            return o;
        });
    }

    function pdHex(hex) {
        return String(hex || '').replace('#', '');
    }

    function pdHexToRgb(hex) {
        var h = pdHex(hex);
        if (h.length === 3) h = h.split('').map(function (c) { return c + c; }).join('');
        var n = parseInt(h, 16) || 0;
        return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
    }

    function pdRgba(hex, a) {
        var rgb = pdHexToRgb(hex);
        return 'rgba(' + rgb.r + ',' + rgb.g + ',' + rgb.b + ',' + a + ')';
    }

    function pdMixHex(hexA, hexB, t) {
        var a = pdHexToRgb(hexA), b = pdHexToRgb(hexB);
        var r = Math.round(a.r + (b.r - a.r) * t);
        var g = Math.round(a.g + (b.g - a.g) * t);
        var bl = Math.round(a.b + (b.b - a.b) * t);
        return '#' + [r, g, bl].map(function (x) { return ('0' + x.toString(16)).slice(-2); }).join('');
    }

    /** N distinct chart colors, interpolated across the theme's two hues. */
    function pdChartPalette(theme, n) {
        n = Math.max(1, n | 0);
        if (n === 1) return [theme.accent];
        var colors = [];
        for (var i = 0; i < n; i++) {
            colors.push(pdMixHex(theme.accent, theme.accent2, i / (n - 1)));
        }
        return colors;
    }

    function pdSlug(s) {
        return String(s || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '') || 'design';
    }

    function pdSaveBlob(blob, filename) {
        var url = URL.createObjectURL(blob);
        var a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
    }

    /**
     * Reads an image file, downscales it to fit maxDim (keeping aspect
     * ratio) and hands back a PNG data URI. Everything (header/footer
     * logos, slide images) is stored and saved as a data URI -- there is
     * no separate file upload endpoint, so the deck's JSON blob stays
     * self-contained and portable.
     */
    function pdReadImageFile(file, maxDim, cb) {
        var reader = new FileReader();
        reader.onload = function () {
            var img = new Image();
            img.onload = function () {
                var scale = Math.min(1, maxDim / Math.max(img.width, img.height));
                var w = Math.max(1, Math.round(img.width * scale));
                var h = Math.max(1, Math.round(img.height * scale));
                var canvas = document.createElement('canvas');
                canvas.width = w;
                canvas.height = h;
                canvas.getContext('2d').drawImage(img, 0, 0, w, h);
                cb(canvas.toDataURL('image/png'), w, h);
            };
            img.onerror = function () { cb(null); };
            img.src = reader.result;
        };
        reader.onerror = function () { cb(null); };
        reader.readAsDataURL(file);
    }

    /** A data: URI's raw bytes, for handing to docx.js's ImageRun. */
    function pdDataUriToUint8Array(dataUri) {
        var base64 = String(dataUri || '').split(',')[1] || '';
        var binary = atob(base64);
        var bytes = new Uint8Array(binary.length);
        for (var i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
        return bytes;
    }

    /* ---------------------------------------------------------------- */
    /* Themes                                                            */
    /* ---------------------------------------------------------------- */

    var PD_THEMES = [
        { id: 'blue', name: 'Blue', accent: '#2563EB', accent2: '#7DD3FC' },
        { id: 'indigo', name: 'Indigo', accent: '#4F46E5', accent2: '#A5B4FC' },
        { id: 'violet', name: 'Violet', accent: '#7C3AED', accent2: '#C4B5FD' },
        { id: 'fuchsia', name: 'Fuchsia', accent: '#C026D3', accent2: '#F0ABFC' },
        { id: 'rose', name: 'Rose', accent: '#E11D48', accent2: '#FDA4AF' },
        { id: 'crimson', name: 'Crimson', accent: '#DC2626', accent2: '#FCA5A5' },
        { id: 'orange', name: 'Orange', accent: '#EA580C', accent2: '#FDBA74' },
        { id: 'amber', name: 'Amber', accent: '#B45309', accent2: '#FCD34D' },
        { id: 'emerald', name: 'Emerald', accent: '#059669', accent2: '#6EE7B7' },
        { id: 'teal', name: 'Teal', accent: '#0D9488', accent2: '#5EEAD4' },
        { id: 'cyan', name: 'Cyan', accent: '#0891B2', accent2: '#67E8F9' },
        { id: 'slate', name: 'Slate', accent: '#475569', accent2: '#94A3B8' },
        { id: 'charcoal', name: 'Charcoal', accent: '#1F2937', accent2: '#9CA3AF' }
    ];

    /* ---------------------------------------------------------------- */
    /* Preview shells                                                    */
    /* ---------------------------------------------------------------- */

    function pdDarkShell(theme, inner) {
        var glow = pdRgba(theme.accent, .28);
        return '' +
            '<div style="position:relative;width:1280px;height:720px;overflow:hidden;background:linear-gradient(135deg,#020617 0%,#0B1220 55%,#0F172A 100%);font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;">' +
                '<div style="position:absolute;top:-220px;right:-180px;width:640px;height:640px;border-radius:50%;background:radial-gradient(circle, ' + glow + ' 0%, transparent 70%);pointer-events:none;"></div>' +
                '<div style="position:absolute;inset:0;opacity:.5;background-image:radial-gradient(rgba(255,255,255,.06) 1px, transparent 1px);background-size:26px 26px;pointer-events:none;"></div>' +
                '<div style="position:relative;z-index:1;height:100%;">' + inner + '</div>' +
            '</div>';
    }

    function pdLightShell(theme, inner) {
        return '' +
            '<div style="position:relative;width:1280px;height:720px;overflow:hidden;background:#FFFFFF;font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;color:#0F172A;">' +
                '<div style="position:absolute;top:0;left:0;right:0;height:8px;background:linear-gradient(90deg,' + theme.accent + ' 0%, ' + theme.accent2 + ' 100%);"></div>' +
                '<div style="height:100%;">' + inner + '</div>' +
            '</div>';
    }

    function pdDocShell(theme, inner) {
        return '' +
            '<div style="position:relative;width:794px;height:1123px;overflow:hidden;background:#FFFFFF;font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;color:#1E293B;">' +
                '<div style="position:absolute;top:0;left:0;right:0;height:8px;background:linear-gradient(90deg,#0B1220 0%, ' + theme.accent + ' 55%, ' + theme.accent2 + ' 100%);"></div>' +
                '<div style="height:100%;">' + inner + '</div>' +
            '</div>';
    }

    function pdFrameShell(theme, inner) {
        return '' +
            '<div style="position:relative;width:1280px;height:720px;overflow:hidden;background:' + pdRgba(theme.accent, .045) + ';font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;color:#0F172A;">' +
                '<div style="position:absolute;inset:24px;border:2px solid ' + pdRgba(theme.accent, .18) + ';border-radius:18px;pointer-events:none;"></div>' +
                '<div style="height:100%;">' + inner + '</div>' +
            '</div>';
    }

    /**
     * Every buildPptx() calls this instead of pptx.addSlide() directly, so
     * a deck-level header/footer (see pdBuildMaster below) applies to every
     * slide uniformly via a real PowerPoint slide master, without each of
     * the 17 templates needing to know whether one is configured. It also
     * remembers the slide it just created in pdLastSlideRef, so exportDeck
     * can add a deck item's "extra elements" onto the same slide object
     * without every template needing to return it.
     */
    var pdLastSlideRef = null;

    function pdAddSlide(pptx, opts) {
        var s = pptx.addSlide(opts && opts.masterName ? { masterName: opts.masterName } : undefined);
        pdLastSlideRef = s;
        return s;
    }

    var PD_SLIDE_W = 13.333;

    /** Left/center/right -> the x where a group of that total width should start. */
    function pdHfGroupStartX(position, groupWidth) {
        var margin = 0.4;
        if (position === 'left') return margin;
        if (position === 'center') return (PD_SLIDE_W - groupWidth) / 2;
        return PD_SLIDE_W - margin - groupWidth;
    }

    /** An element's approximate box width in inches -- exact for images (via their real aspect ratio), a heuristic for text (no live text measurement available). */
    function pdHfElementWidthIn(el) {
        var hIn = el.size / 72;
        if (el.type === 'image') return hIn * (el.aspect || 3);
        return Math.min(3.2, Math.max(0.4, (el.value || '').length * hIn * 0.62));
    }

    /** Slide-master objects for one side (header or footer): elements grouped by their own position, packed left-to-right within each group. */
    function pdHfSideObjects(side, bandY, bandH) {
        var groups = { left: [], center: [], right: [] };
        (side.elements || []).forEach(function (el) {
            if (!el.value) return;
            groups[el.position === 'left' || el.position === 'center' ? el.position : 'right'].push(el);
        });

        var gap = 0.12;
        var objects = [];

        ['left', 'center', 'right'].forEach(function (pos) {
            var els = groups[pos];
            if (!els.length) return;
            var widths = els.map(pdHfElementWidthIn);
            var totalW = widths.reduce(function (a, b) { return a + b; }, 0) + gap * (els.length - 1);
            var x = pdHfGroupStartX(pos, totalW);

            els.forEach(function (el, i) {
                var w = widths[i];
                var hIn = Math.min(bandH, el.size / 72);
                var y = bandY + (bandH - hIn) / 2;
                if (el.type === 'image') {
                    objects.push({ image: { data: el.value, x: x, y: y, w: w, h: hIn } });
                } else {
                    objects.push({ text: { text: el.value, options: { x: x, y: bandY, w: w, h: bandH, fontSize: el.size, color: '94A3B8', align: pos, valign: 'middle' } } });
                }
                x += w + gap;
            });
        });

        return objects;
    }

    /**
     * Defines a slide master carrying the deck's header, footer and
     * watermark, and returns its name, or null when all three are empty --
     * callers pass that straight through as buildPptx's `opts.masterName`.
     * The watermark is added FIRST so it sits behind everything else (a
     * slide master's own objects render behind each slide's own content --
     * exactly what a watermark needs).
     */
    function pdBuildMaster(pptx, hf) {
        if (!hf) return null;
        var header = hf.header || { elements: [] }, footer = hf.footer || { elements: [] }, watermark = hf.watermark || {};
        var hasHeader = (header.elements || []).some(function (el) { return el.value; });
        var hasFooter = (footer.elements || []).some(function (el) { return el.value; });
        var hasWatermark = watermark.text || watermark.image;
        if (!hasHeader && !hasFooter && !hasWatermark) return null;

        var objects = [];
        var transparency = 100 - (watermark.opacity || 12);

        if (watermark.image) {
            objects.push({ image: { data: watermark.image, x: 4.67, y: 2.75, w: 4, h: 2, sizing: { type: 'contain', w: 4, h: 2 }, transparency: transparency } });
        } else if (watermark.text) {
            objects.push({ text: { text: watermark.text, options: { x: 0.5, y: 3, w: 12.33, h: 1.5, fontSize: 54, bold: true, color: '94A3B8', align: 'center', valign: 'middle', rotate: -30, transparency: transparency } } });
        }

        if (hasHeader) objects = objects.concat(pdHfSideObjects(header, 0.15, 0.7));
        if (hasFooter) objects = objects.concat(pdHfSideObjects(footer, 6.65, 0.7));

        pptx.defineSlideMaster({ title: 'PD_MASTER', objects: objects });
        return 'PD_MASTER';
    }

    /* ---------------------------------------------------------------- */
    /* Templates                                                         */
    /* ---------------------------------------------------------------- */

    var PD_TEMPLATES = [

        /* ============================== PPTX ============================== */

        {
            id: 'title-cover',
            type: 'pptx',
            kind: 'dark',
            name: 'Title Cover',
            description: 'Opening slide for a deck: title, subtitle, presenter and date on a branded dark hero.',
            thumb: [{ x: 10, y: 60, w: 60, h: 12 }, { x: 10, y: 76, w: 40, h: 9, accent: true }],
            fields: [
                { key: 'title', label: 'Title', type: 'text', default: 'Quarterly Infrastructure Review' },
                { key: 'subtitle', label: 'Subtitle', type: 'text', default: 'Enterprise IT Operations' },
                { key: 'presenter', label: 'Presenter', type: 'text', default: 'IT Operations Team' },
                { key: 'date', label: 'Date', type: 'text', default: 'Q3 2026' },
                { key: 'logo', label: 'Logo (optional)', type: 'image', hint: 'PNG/JPG, shown top-right', default: '' }
            ],
            preview: function (v, theme) {
                var inner = '' +
                    '<div style="display:flex;flex-direction:column;justify-content:center;height:100%;padding:0 96px;">' +
                        (v.logo ? '<img src="' + v.logo + '" style="position:absolute;top:48px;right:64px;max-height:56px;max-width:200px;">' : '') +
                        '<div style="font-size:12px;font-weight:700;letter-spacing:3px;color:' + theme.accent2 + ';margin-bottom:22px;">ENTERPRISE IT</div>' +
                        '<h1 style="margin:0;font-size:58px;font-weight:800;color:#F8FAFC;letter-spacing:-1px;max-width:900px;line-height:1.08;">' + pdEsc(v.title) + '</h1>' +
                        '<div style="margin-top:18px;font-size:22px;font-weight:600;color:' + theme.accent2 + ';">' + pdEsc(v.subtitle) + '</div>' +
                        '<div style="margin-top:56px;display:flex;gap:16px;align-items:center;font-size:14px;color:#94A3B8;">' +
                            '<span>' + pdEsc(v.presenter) + '</span><span style="opacity:.5;">&bull;</span><span>' + pdEsc(v.date) + '</span>' +
                        '</div>' +
                    '</div>';
                return pdDarkShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: '0B1220' };
                if (v.logo) s.addImage({ data: v.logo, x: 10.3, y: 0.4, w: 2, h: 0.6, sizing: { type: 'contain', w: 2, h: 0.6 } });
                s.addText('ENTERPRISE IT', { x: 1, y: 1.6, w: 8, h: 0.4, fontSize: 12, bold: true, color: pdHex(theme.accent2), charSpacing: 3 });
                s.addText(v.title, { x: 1, y: 2.05, w: 10.8, h: 1.6, fontSize: 40, bold: true, color: 'F8FAFC' });
                s.addText(v.subtitle, { x: 1, y: 3.5, w: 9, h: 0.6, fontSize: 20, bold: true, color: pdHex(theme.accent2) });
                s.addText(v.presenter + '     •     ' + v.date, { x: 1, y: 4.65, w: 9, h: 0.4, fontSize: 12, color: '94A3B8' });
            }
        },

        {
            id: 'image-slide',
            type: 'pptx',
            kind: 'light',
            name: 'Image Slide',
            description: 'A full photo or diagram with a heading and caption.',
            thumb: [{ x: 10, y: 15, w: 55, h: 10, accent: true }, { x: 10, y: 34, w: 80, h: 50 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Network Topology' },
                { key: 'image', label: 'Image', type: 'image', hint: 'PNG/JPG', default: '' },
                { key: 'caption', label: 'Caption (optional)', type: 'text', default: '' }
            ],
            preview: function (v, theme) {
                var pic = v.image
                    ? '<img src="' + v.image + '" style="max-width:100%;max-height:100%;object-fit:contain;border-radius:8px;">'
                    : '<div style="display:flex;align-items:center;justify-content:center;height:100%;color:#94A3B8;font-size:13px;background:#F8FAFC;border:1px dashed #CBD5E1;border-radius:8px;">No image chosen yet</div>';
                var inner = '<div style="padding:56px 96px;height:100%;box-sizing:border-box;display:flex;flex-direction:column;">' +
                    '<h1 style="margin:0 0 24px;font-size:32px;font-weight:800;color:#0F172A;flex:none;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="flex:1;min-height:0;display:flex;align-items:center;justify-content:center;">' + pic + '</div>' +
                    (v.caption ? '<div style="flex:none;margin-top:16px;font-size:13px;color:#64748B;text-align:center;">' + pdEsc(v.caption) + '</div>' : '') +
                    '</div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                if (v.image) {
                    s.addImage({ data: v.image, x: 1.3, y: 1.3, w: 10.7, h: 5.4, sizing: { type: 'contain', w: 10.7, h: 5.4 } });
                } else {
                    s.addShape(pptx.ShapeType.rect, { x: 1.3, y: 1.3, w: 10.7, h: 5.4, fill: { color: 'F8FAFC' }, line: { color: 'CBD5E1', width: 1, dashType: 'dash' } });
                    s.addText('No image chosen', { x: 1.3, y: 1.3, w: 10.7, h: 5.4, fontSize: 13, color: '94A3B8', align: 'center', valign: 'middle' });
                }
                if (v.caption) s.addText(v.caption, { x: 1.3, y: 6.85, w: 10.7, h: 0.35, fontSize: 11, color: '64748B', align: 'center' });
            }
        },

        {
            id: 'agenda',
            type: 'pptx',
            kind: 'light',
            name: 'Agenda',
            description: 'Numbered agenda / table of contents slide.',
            thumb: [{ x: 10, y: 18, w: 70, h: 8, accent: true }, { x: 10, y: 38, w: 60, h: 8 }, { x: 10, y: 56, w: 65, h: 8 }, { x: 10, y: 74, w: 50, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Agenda' },
                { key: 'items', label: 'Agenda items', type: 'lines', hint: 'One item per line', default: ['Infrastructure Overview', 'Patch Compliance Status', 'Security Incidents', 'Upcoming Projects', 'Q&A'] }
            ],
            preview: function (v, theme) {
                var rows = v.items.map(function (it, i) {
                    return '<div style="display:flex;align-items:center;gap:20px;padding:16px 0;border-bottom:1px solid #F1F5F9;">' +
                        '<div style="width:34px;height:34px;flex:none;border-radius:50%;background:' + pdRgba(theme.accent, .12) + ';color:' + theme.accent + ';font-weight:700;font-size:14px;display:flex;align-items:center;justify-content:center;">' + String(i + 1).padStart(2, '0') + '</div>' +
                        '<div style="font-size:19px;font-weight:600;color:#0F172A;">' + pdEsc(it) + '</div>' +
                    '</div>';
                }).join('');
                var inner = '<div style="padding:64px 96px;">' +
                    '<div style="font-size:12px;font-weight:700;letter-spacing:2px;color:' + theme.accent + ';margin-bottom:10px;">AGENDA</div>' +
                    '<h1 style="margin:0 0 30px;font-size:40px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div>' + rows + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 13.333, h: 0.08, fill: { color: pdHex(theme.accent) } });
                s.addText('AGENDA', { x: 1, y: 0.55, w: 5, h: 0.3, fontSize: 11, bold: true, color: pdHex(theme.accent), charSpacing: 2 });
                s.addText(v.heading, { x: 1, y: 0.85, w: 9, h: 0.6, fontSize: 28, bold: true, color: '0F172A' });
                var y = 1.7;
                v.items.forEach(function (item, i) {
                    s.addText(String(i + 1).padStart(2, '0'), { x: 1, y: y, w: 0.6, h: 0.4, fontSize: 14, bold: true, color: pdHex(theme.accent) });
                    s.addText(item, { x: 1.7, y: y, w: 9.5, h: 0.4, fontSize: 16, bold: true, color: '0F172A' });
                    y += 0.62;
                });
            }
        },

        {
            id: 'section-divider',
            type: 'pptx',
            kind: 'dark',
            name: 'Section Divider',
            description: 'Large numbered break between sections of a deck.',
            thumb: [{ x: 8, y: 32, w: 22, h: 34, accent: true }, { x: 38, y: 38, w: 54, h: 10 }, { x: 38, y: 55, w: 40, h: 8 }],
            fields: [
                { key: 'number', label: 'Number', type: 'text', default: '01' },
                { key: 'heading', label: 'Heading', type: 'text', default: 'Infrastructure Overview' },
                { key: 'subheading', label: 'Subheading', type: 'text', default: 'Current state of the environment' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="display:flex;align-items:center;height:100%;padding:0 96px;gap:48px;">' +
                    '<div style="font-size:120px;font-weight:800;color:' + pdRgba(theme.accent2, .35) + ';line-height:1;">' + pdEsc(v.number) + '</div>' +
                    '<div style="width:1px;height:140px;background:rgba(255,255,255,.15);"></div>' +
                    '<div><h1 style="margin:0;font-size:46px;font-weight:800;color:#F8FAFC;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="margin-top:14px;font-size:18px;color:#94A3B8;">' + pdEsc(v.subheading) + '</div></div>' +
                    '</div>';
                return pdDarkShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: '0B1220' };
                s.addText(v.number, { x: 1, y: 2.6, w: 2.4, h: 1.6, fontSize: 80, bold: true, color: pdHex(theme.accent2) });
                s.addText(v.heading, { x: 3.8, y: 2.9, w: 8.5, h: 0.8, fontSize: 32, bold: true, color: 'F8FAFC' });
                s.addText(v.subheading, { x: 3.8, y: 3.65, w: 8, h: 0.5, fontSize: 15, color: '94A3B8' });
            }
        },

        {
            id: 'content-bullets',
            type: 'pptx',
            kind: 'light',
            name: 'Content – Bullets',
            description: 'Title with a short bulleted list.',
            thumb: [{ x: 10, y: 14, w: 55, h: 10 }, { x: 10, y: 33, w: 8, h: 8, accent: true }, { x: 22, y: 33, w: 60, h: 8 }, { x: 10, y: 50, w: 8, h: 8, accent: true }, { x: 22, y: 50, w: 50, h: 8 }, { x: 10, y: 67, w: 8, h: 8, accent: true }, { x: 22, y: 67, w: 55, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Key Achievements' },
                { key: 'bullets', label: 'Bullets', type: 'lines', hint: 'One bullet per line', default: ['Reduced ticket backlog by 40%', 'Migrated 120 servers to the new patch cycle', 'Zero critical incidents this quarter', 'Completed UID/GID audit across all Linux hosts'] }
            ],
            preview: function (v, theme) {
                var rows = v.bullets.map(function (b) {
                    return '<li style="display:flex;gap:14px;align-items:flex-start;font-size:19px;color:#1E293B;line-height:1.5;margin-bottom:20px;list-style:none;">' +
                        '<span style="flex:none;width:22px;height:22px;border-radius:6px;background:' + theme.accent + ';margin-top:3px;position:relative;">' +
                            '<svg width="22" height="22" viewBox="0 0 24 24" style="position:absolute;inset:0;"><path d="M6 12l4 4 8-9" fill="none" stroke="#fff" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                        '</span><span>' + pdEsc(b) + '</span></li>';
                }).join('');
                var inner = '<div style="padding:64px 96px;"><h1 style="margin:0 0 36px;font-size:40px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<ul style="margin:0;padding:0;max-width:820px;">' + rows + '</ul></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.6, w: 10, h: 0.7, fontSize: 28, bold: true, color: '0F172A' });
                var y = 1.7;
                v.bullets.forEach(function (b) {
                    s.addShape(pptx.ShapeType.rect, { x: 1, y: y + 0.05, w: 0.2, h: 0.2, fill: { color: pdHex(theme.accent) } });
                    s.addText(b, { x: 1.5, y: y, w: 9.8, h: 0.5, fontSize: 15, color: '1E293B' });
                    y += 0.62;
                });
            }
        },

        {
            id: 'two-column',
            type: 'pptx',
            kind: 'light',
            name: 'Two-Column Comparison',
            description: 'Side-by-side comparison, e.g. Before / After.',
            thumb: [{ x: 8, y: 18, w: 38, h: 62 }, { x: 54, y: 18, w: 38, h: 62, accent: true }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Before vs. After' },
                { key: 'leftHeading', label: 'Left column heading', type: 'text', default: 'Before' },
                { key: 'leftItems', label: 'Left column items', type: 'lines', hint: 'One per line', default: ['Manual spreadsheet tracking', 'No audit trail', 'Inconsistent patch cadence'] },
                { key: 'rightHeading', label: 'Right column heading', type: 'text', default: 'After' },
                { key: 'rightItems', label: 'Right column items', type: 'lines', hint: 'One per line', default: ['Centralized asset registry', 'Full audit history', 'Standardized quarterly patching'] }
            ],
            preview: function (v, theme) {
                function col(items, color) {
                    return items.map(function (it) {
                        return '<li style="margin-bottom:14px;font-size:15.5px;color:#334155;padding-left:18px;position:relative;list-style:none;">' +
                            '<span style="position:absolute;left:0;top:9px;width:6px;height:6px;border-radius:50%;background:' + color + ';"></span>' + pdEsc(it) + '</li>';
                    }).join('');
                }
                var inner = '<div style="padding:56px 96px;">' +
                    '<h1 style="margin:0 0 36px;font-size:36px;font-weight:800;color:#0F172A;text-align:center;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:40px;">' +
                        '<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:16px;padding:32px;">' +
                            '<div style="font-size:13px;font-weight:700;letter-spacing:1px;color:#94A3B8;margin-bottom:18px;text-transform:uppercase;">' + pdEsc(v.leftHeading) + '</div>' +
                            '<ul style="margin:0;padding:0;">' + col(v.leftItems, '#94A3B8') + '</ul></div>' +
                        '<div style="background:' + pdRgba(theme.accent, .06) + ';border:1px solid ' + pdRgba(theme.accent, .25) + ';border-radius:16px;padding:32px;">' +
                            '<div style="font-size:13px;font-weight:700;letter-spacing:1px;color:' + theme.accent + ';margin-bottom:18px;text-transform:uppercase;">' + pdEsc(v.rightHeading) + '</div>' +
                            '<ul style="margin:0;padding:0;">' + col(v.rightItems, theme.accent) + '</ul></div>' +
                    '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.55, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A', align: 'center' });
                s.addShape(pptx.ShapeType.roundRect, { x: 1, y: 1.5, w: 5.4, h: 4.6, fill: { color: 'F8FAFC' }, line: { color: 'E2E8F0', width: 1 } });
                s.addShape(pptx.ShapeType.roundRect, { x: 6.7, y: 1.5, w: 5.4, h: 4.6, fill: { color: pdHex(theme.accent), transparency: 92 }, line: { color: pdHex(theme.accent), width: 1 } });
                s.addText(v.leftHeading.toUpperCase(), { x: 1.3, y: 1.7, w: 4.8, h: 0.4, fontSize: 12, bold: true, color: '94A3B8' });
                s.addText(v.rightHeading.toUpperCase(), { x: 7, y: 1.7, w: 4.8, h: 0.4, fontSize: 12, bold: true, color: pdHex(theme.accent) });
                s.addText(v.leftItems.map(function (t) { return { text: t, options: { bullet: true, breakLine: true, color: '334155', fontSize: 13 } }; }), { x: 1.3, y: 2.2, w: 4.8, h: 3.7 });
                s.addText(v.rightItems.map(function (t) { return { text: t, options: { bullet: true, breakLine: true, color: '334155', fontSize: 13 } }; }), { x: 7, y: 2.2, w: 4.8, h: 3.7 });
            }
        },

        {
            id: 'timeline',
            type: 'pptx',
            kind: 'light',
            name: 'Timeline / Roadmap',
            description: 'Horizontal milestone timeline.',
            thumb: [{ x: 8, y: 46, w: 84, h: 4, accent: true }, { x: 15, y: 35, w: 8, h: 8 }, { x: 40, y: 35, w: 8, h: 8 }, { x: 65, y: 35, w: 8, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Rollout Roadmap' },
                { key: 'milestones', label: 'Milestones', type: 'lines', parts: ['label', 'description'], hint: 'One per line: Label | Description', default: ['Q1 2026|Discovery & planning', 'Q2 2026|Pilot on 20 servers', 'Q3 2026|Estate-wide rollout', 'Q4 2026|Review & optimize'] }
            ],
            preview: function (v, theme) {
                var n = v.milestones.length || 1;
                var stops = v.milestones.map(function (m) {
                    return '<div style="flex:1;position:relative;text-align:center;">' +
                        '<div style="width:16px;height:16px;border-radius:50%;background:' + theme.accent + ';margin:0 auto 14px;border:3px solid #fff;box-shadow:0 0 0 2px ' + theme.accent + ';"></div>' +
                        '<div style="font-size:14px;font-weight:700;color:' + theme.accent + ';margin-bottom:6px;">' + pdEsc(m.label) + '</div>' +
                        '<div style="font-size:13px;color:#64748B;line-height:1.4;padding:0 10px;">' + pdEsc(m.description) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:70px 96px;"><h1 style="margin:0 0 64px;font-size:38px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="position:relative;display:flex;"><div style="position:absolute;top:8px;left:0;right:0;height:2px;background:#E2E8F0;"></div>' + stops + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.6, w: 11, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var n = v.milestones.length || 1;
                var totalW = 11.3, startX = 1;
                s.addShape(pptx.ShapeType.line, { x: startX, y: 2.3, w: totalW, h: 0, line: { color: 'E2E8F0', width: 1.5 } });
                v.milestones.forEach(function (m, i) {
                    var slot = totalW / n;
                    var cx = startX + slot * (i + 0.5);
                    s.addShape(pptx.ShapeType.ellipse, { x: cx - 0.09, y: 2.21, w: 0.18, h: 0.18, fill: { color: pdHex(theme.accent) }, line: { color: 'FFFFFF', width: 2 } });
                    s.addText(m.label, { x: cx - slot / 2, y: 2.55, w: slot, h: 0.35, fontSize: 13, bold: true, color: pdHex(theme.accent), align: 'center' });
                    s.addText(m.description, { x: cx - slot / 2 + 0.1, y: 2.9, w: slot - 0.2, h: 1, fontSize: 11, color: '64748B', align: 'center' });
                });
            }
        },

        {
            id: 'kpi-stats',
            type: 'pptx',
            kind: 'light',
            name: 'KPI Stats Dashboard',
            description: 'Big-number stat cards in a row.',
            thumb: [{ x: 8, y: 22, w: 24, h: 52 }, { x: 36, y: 22, w: 24, h: 52, accent: true }, { x: 64, y: 22, w: 24, h: 52 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'This Quarter at a Glance' },
                { key: 'stats', label: 'Stats', type: 'lines', parts: ['value', 'label'], hint: 'One per line: Value | Label', default: ['337|Servers Tracked', '98%|Patch Compliance', '12|Open Known Issues', '4.2h|Avg. Resolution Time'] }
            ],
            preview: function (v, theme) {
                var cards = v.stats.map(function (st) {
                    return '<div style="flex:1;background:#F8FAFC;border:1px solid #E2E8F0;border-radius:16px;padding:30px 20px;text-align:center;">' +
                        '<div style="font-size:44px;font-weight:800;color:' + theme.accent + ';">' + pdEsc(st.value) + '</div>' +
                        '<div style="margin-top:10px;font-size:13.5px;color:#64748B;font-weight:600;">' + pdEsc(st.label) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:70px 96px;"><h1 style="margin:0 0 40px;font-size:38px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;gap:24px;">' + cards + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.6, w: 11, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var n = v.stats.length || 1, gap = 0.3, totalW = 11.3;
                var cardW = (totalW - gap * (n - 1)) / n;
                v.stats.forEach(function (st, i) {
                    var x = 1 + i * (cardW + gap);
                    s.addShape(pptx.ShapeType.roundRect, { x: x, y: 1.8, w: cardW, h: 2.4, fill: { color: 'F8FAFC' }, line: { color: 'E2E8F0', width: 1 } });
                    s.addText(st.value, { x: x, y: 2.15, w: cardW, h: 0.9, fontSize: 28, bold: true, color: pdHex(theme.accent), align: 'center' });
                    s.addText(st.label, { x: x, y: 3.05, w: cardW, h: 0.6, fontSize: 12, bold: true, color: '64748B', align: 'center' });
                });
            }
        },

        {
            id: 'closing',
            type: 'pptx',
            kind: 'dark',
            name: 'Closing / Thank You',
            description: 'Final slide with contact details.',
            thumb: [{ x: 20, y: 38, w: 60, h: 14, accent: true }, { x: 28, y: 58, w: 44, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Thank You' },
                { key: 'message', label: 'Message', type: 'text', default: 'Questions and discussion welcome.' },
                { key: 'contact', label: 'Contact', type: 'text', default: 'it-ops@yourorganization.com' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;padding:0 96px;">' +
                    '<h1 style="margin:0;font-size:64px;font-weight:800;color:#F8FAFC;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="margin-top:20px;font-size:19px;color:#94A3B8;max-width:640px;">' + pdEsc(v.message) + '</div>' +
                    '<div style="margin-top:44px;font-size:15px;font-weight:600;color:' + theme.accent2 + ';">' + pdEsc(v.contact) + '</div></div>';
                return pdDarkShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: '0B1220' };
                s.addText(v.heading, { x: 1, y: 2.3, w: 11.3, h: 1.1, fontSize: 48, bold: true, color: 'F8FAFC', align: 'center' });
                s.addText(v.message, { x: 2, y: 3.5, w: 9.3, h: 0.7, fontSize: 16, color: '94A3B8', align: 'center' });
                s.addText(v.contact, { x: 2, y: 4.3, w: 9.3, h: 0.5, fontSize: 13, bold: true, color: pdHex(theme.accent2), align: 'center' });
            }
        },

        {
            id: 'quote',
            type: 'pptx',
            kind: 'light',
            name: 'Quote / Testimonial',
            description: 'A framed pull-quote slide with attribution.',
            thumb: [{ x: 20, y: 16, w: 14, h: 22, accent: true }, { x: 15, y: 46, w: 70, h: 8 }, { x: 25, y: 60, w: 50, h: 8 }, { x: 35, y: 76, w: 30, h: 6 }],
            fields: [
                { key: 'quote', label: 'Quote', type: 'paragraph', default: 'InfraVault gave us a single source of truth for every server in the estate — something four years of spreadsheets never managed.' },
                { key: 'author', label: 'Attribution', type: 'text', default: 'IT Operations Director' },
                { key: 'org', label: 'Organization / role line', type: 'text', default: 'Enterprise IT Division' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 150px;">' +
                    '<div style="font-size:90px;font-weight:800;color:' + theme.accent + ';line-height:.5;margin-bottom:6px;font-family:Georgia,serif;">&ldquo;</div>' +
                    '<div style="font-size:27px;font-weight:600;color:#1E293B;line-height:1.5;">' + pdEsc(v.quote) + '</div>' +
                    '<div style="margin-top:32px;width:40px;height:3px;background:' + theme.accent + ';border-radius:2px;"></div>' +
                    '<div style="margin-top:18px;font-size:15px;font-weight:700;color:#0F172A;">' + pdEsc(v.author) + '</div>' +
                    '<div style="font-size:13px;color:#64748B;">' + pdEsc(v.org) + '</div></div>';
                return pdFrameShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addShape(pptx.ShapeType.rect, { x: 0.3, y: 0.3, w: 12.73, h: 6.9, fill: { color: 'FFFFFF' }, line: { color: pdHex(theme.accent), width: 1.5 } });
                s.addText('“', { x: 1, y: 1.0, w: 2, h: 1.2, fontSize: 70, bold: true, color: pdHex(theme.accent), fontFace: 'Georgia' });
                s.addText(v.quote, { x: 1.6, y: 2.1, w: 10.1, h: 2, fontSize: 22, bold: true, color: '1E293B', align: 'center' });
                s.addText(v.author, { x: 1.6, y: 4.6, w: 10.1, h: 0.4, fontSize: 14, bold: true, color: '0F172A', align: 'center' });
                s.addText(v.org, { x: 1.6, y: 5.0, w: 10.1, h: 0.4, fontSize: 12, color: '64748B', align: 'center' });
            }
        },

        {
            id: 'team-grid',
            type: 'pptx',
            kind: 'light',
            name: 'Team Grid',
            description: 'Row of team members with initials, name and role.',
            thumb: [{ x: 12, y: 25, w: 14, h: 14, accent: true }, { x: 34, y: 25, w: 14, h: 14 }, { x: 56, y: 25, w: 14, h: 14 }, { x: 78, y: 25, w: 14, h: 14 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Our Team' },
                { key: 'people', label: 'People', type: 'lines', parts: ['name', 'role'], hint: 'One per line: Name | Role', default: ['example|IT Operations Lead', 'example|Infrastructure Engineer', 'example|Security Analyst', 'example|Systems Administrator'] }
            ],
            preview: function (v, theme) {
                function initials(name) {
                    var parts = name.replace(/\(.*?\)/g, '').trim().split(/\s+/).filter(Boolean);
                    var s = (parts[0] || '').charAt(0) + (parts.length > 1 ? parts[parts.length - 1].charAt(0) : '');
                    return s.toUpperCase();
                }
                var cards = v.people.map(function (p) {
                    return '<div style="flex:1;text-align:center;">' +
                        '<div style="width:74px;height:74px;border-radius:50%;background:' + pdRgba(theme.accent, .12) + ';color:' + theme.accent + ';font-size:22px;font-weight:700;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;">' + initials(p.name) + '</div>' +
                        '<div style="font-size:15px;font-weight:700;color:#0F172A;">' + pdEsc(p.name) + '</div>' +
                        '<div style="font-size:12.5px;color:#64748B;margin-top:4px;">' + pdEsc(p.role) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:70px 96px;"><h1 style="margin:0 0 50px;font-size:38px;font-weight:800;color:#0F172A;text-align:center;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;gap:24px;">' + cards + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.6, w: 11.3, h: 0.7, fontSize: 28, bold: true, color: '0F172A', align: 'center' });
                var n = v.people.length || 1, gap = 0.3, totalW = 11.3, cardW = (totalW - gap * (n - 1)) / n;
                v.people.forEach(function (p, i) {
                    var x = 1 + i * (cardW + gap);
                    var initials = p.name.replace(/\(.*?\)/g, '').trim().split(/\s+/).filter(Boolean).map(function (w) { return w.charAt(0); }).join('').substring(0, 2).toUpperCase();
                    s.addShape(pptx.ShapeType.ellipse, { x: x + cardW / 2 - 0.55, y: 1.9, w: 1.1, h: 1.1, fill: { color: pdHex(theme.accent), transparency: 85 }, line: { color: pdHex(theme.accent), width: 1 } });
                    s.addText(initials, { x: x, y: 1.9, w: cardW, h: 1.1, fontSize: 20, bold: true, color: pdHex(theme.accent), align: 'center', valign: 'middle' });
                    s.addText(p.name, { x: x, y: 3.15, w: cardW, h: 0.4, fontSize: 14, bold: true, color: '0F172A', align: 'center' });
                    s.addText(p.role, { x: x, y: 3.55, w: cardW, h: 0.5, fontSize: 11, color: '64748B', align: 'center' });
                });
            }
        },

        {
            id: 'process-steps',
            type: 'pptx',
            kind: 'light',
            name: 'Process / Steps',
            description: 'A chevron chain showing a step-by-step flow.',
            thumb: [{ x: 6, y: 40, w: 18, h: 20, accent: true }, { x: 28, y: 40, w: 18, h: 20 }, { x: 50, y: 40, w: 18, h: 20 }, { x: 72, y: 40, w: 18, h: 20 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'How It Works' },
                { key: 'steps', label: 'Steps', type: 'lines', hint: 'One step per line', default: ['Discover', 'Plan', 'Deploy', 'Support'] }
            ],
            preview: function (v, theme) {
                var n = v.steps.length || 1;
                var chevrons = v.steps.map(function (s, i) {
                    var bg = i === 0 ? theme.accent : pdRgba(theme.accent, .10 + i * 0.10);
                    var fg = i === 0 ? '#fff' : theme.accent;
                    return '<div style="flex:1;">' +
                        '<div style="background:' + bg + ';color:' + fg + ';height:70px;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:15px;clip-path:polygon(0 0,88% 0,100% 50%,88% 100%,0 100%,12% 50%);padding-left:' + (i === 0 ? '0' : '18px') + ';">' + pdEsc(s) + '</div></div>';
                }).join('<div style="width:6px;"></div>');
                var inner = '<div style="padding:80px 96px;"><h1 style="margin:0 0 60px;font-size:38px;font-weight:800;color:#0F172A;text-align:center;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;align-items:center;">' + chevrons + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.6, w: 11.3, h: 0.7, fontSize: 28, bold: true, color: '0F172A', align: 'center' });
                var n = v.steps.length || 1, gap = 0.35, totalW = 11.3;
                var stepW = (totalW - gap * (n - 1)) / n;
                v.steps.forEach(function (step, i) {
                    var x = 1 + i * (stepW + gap);
                    s.addShape(pptx.ShapeType.roundRect, { x: x, y: 2.6, w: stepW, h: 1.1, fill: { color: i === 0 ? pdHex(theme.accent) : 'F8FAFC' }, line: { color: pdHex(theme.accent), width: 1 } });
                    s.addText(step, { x: x, y: 2.6, w: stepW, h: 1.1, fontSize: 14, bold: true, color: i === 0 ? 'FFFFFF' : pdHex(theme.accent), align: 'center', valign: 'middle' });
                    if (i < n - 1) {
                        s.addText('→', { x: x + stepW, y: 2.75, w: gap, h: 0.8, fontSize: 18, bold: true, color: '94A3B8', align: 'center' });
                    }
                });
            }
        },

        {
            id: 'bar-chart',
            type: 'pptx',
            kind: 'light',
            name: 'Bar Chart',
            description: 'A simple comparison bar chart slide.',
            thumb: [{ x: 12, y: 50, w: 10, h: 30 }, { x: 30, y: 35, w: 10, h: 45, accent: true }, { x: 48, y: 44, w: 10, h: 36 }, { x: 66, y: 30, w: 10, h: 50 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Compliance by Business Unit' },
                { key: 'bars', label: 'Bars', type: 'lines', parts: ['label', 'value'], hint: 'One per line: Label | Value (number)', default: ['Finance|92', 'Operations|97', 'Engineering|88', 'Retail|95'] }
            ],
            preview: function (v, theme) {
                var max = Math.max.apply(null, v.bars.map(function (b) { return parseFloat(b.value) || 0; })) || 100;
                var bars = v.bars.map(function (b) {
                    var val = parseFloat(b.value) || 0;
                    var h = Math.max(4, (val / max) * 220);
                    return '<div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:flex-end;height:240px;">' +
                        '<div style="font-size:13px;font-weight:700;color:' + theme.accent + ';margin-bottom:8px;">' + pdEsc(b.value) + '</div>' +
                        '<div style="width:44%;height:' + h + 'px;background:linear-gradient(180deg,' + theme.accent + ',' + theme.accent2 + ');border-radius:6px 6px 0 0;"></div>' +
                        '<div style="margin-top:12px;font-size:12.5px;color:#64748B;font-weight:600;">' + pdEsc(b.label) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:64px 96px;"><h1 style="margin:0 0 44px;font-size:36px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;align-items:flex-end;gap:20px;border-bottom:2px solid #E2E8F0;">' + bars + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var data = [{ name: 'Series 1', labels: v.bars.map(function (b) { return b.label; }), values: v.bars.map(function (b) { return parseFloat(b.value) || 0; }) }];
                s.addChart(pptx.ChartType.bar, data, { x: 1, y: 1.3, w: 11.3, h: 5.6, barDir: 'col', chartColors: [pdHex(theme.accent)], showLegend: false, showTitle: false });
            }
        },

        {
            id: 'pie-chart',
            type: 'pptx',
            kind: 'light',
            name: 'Pie Chart',
            description: 'A real, editable pie chart with a legend.',
            thumb: [{ x: 12, y: 25, w: 26, h: 50, accent: true }, { x: 46, y: 30, w: 8, h: 8 }, { x: 58, y: 30, w: 26, h: 8 }, { x: 46, y: 46, w: 8, h: 8 }, { x: 58, y: 46, w: 20, h: 8 }, { x: 46, y: 62, w: 8, h: 8 }, { x: 58, y: 62, w: 16, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Server Distribution by Environment' },
                { key: 'slices', label: 'Slices', type: 'lines', parts: ['label', 'value'], hint: 'One per line: Label | Value (number)', default: ['Production|180', 'Pre-Production|70', 'DR|52', 'Sandbox|35'] }
            ],
            preview: function (v, theme) {
                var total = v.slices.reduce(function (sum, s) { return sum + (parseFloat(s.value) || 0); }, 0) || 1;
                var palette = pdChartPalette(theme, v.slices.length);
                var acc = 0;
                var stops = v.slices.map(function (s, i) {
                    var val = parseFloat(s.value) || 0;
                    var start = (acc / total) * 100;
                    acc += val;
                    var end = (acc / total) * 100;
                    return palette[i] + ' ' + start.toFixed(2) + '% ' + end.toFixed(2) + '%';
                }).join(', ');
                var legend = v.slices.map(function (s, i) {
                    return '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">' +
                        '<span style="width:12px;height:12px;border-radius:3px;background:' + palette[i] + ';flex:none;"></span>' +
                        '<span style="font-size:13.5px;color:#334155;">' + pdEsc(s.label) + '</span>' +
                        '<span style="margin-left:auto;font-size:13px;font-weight:700;color:#0F172A;">' + pdEsc(s.value) + '</span></div>';
                }).join('');
                var inner = '<div style="padding:64px 96px;"><h1 style="margin:0 0 40px;font-size:32px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;align-items:center;gap:64px;">' +
                        '<div style="width:270px;height:270px;border-radius:50%;background:conic-gradient(' + stops + ');flex:none;"></div>' +
                        '<div style="flex:1;max-width:380px;">' + legend + '</div></div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var palette = pdChartPalette(theme, v.slices.length).map(pdHex);
                var data = [{ name: 'Series 1', labels: v.slices.map(function (s2) { return s2.label; }), values: v.slices.map(function (s2) { return parseFloat(s2.value) || 0; }) }];
                s.addChart(pptx.ChartType.pie, data, { x: 1.5, y: 1.3, w: 6.5, h: 5.6, chartColors: palette, showLegend: true, legendPos: 'r', showTitle: false });
            }
        },

        {
            id: 'donut-chart',
            type: 'pptx',
            kind: 'light',
            name: 'Donut Chart',
            description: 'A donut chart with the total shown in the center.',
            thumb: [{ x: 10, y: 25, w: 28, h: 50, accent: true }, { x: 44, y: 32, w: 8, h: 8 }, { x: 56, y: 32, w: 28, h: 8 }, { x: 44, y: 48, w: 8, h: 8 }, { x: 56, y: 48, w: 22, h: 8 }, { x: 44, y: 64, w: 8, h: 8 }, { x: 56, y: 64, w: 18, h: 8 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Tickets by Priority' },
                { key: 'slices', label: 'Slices', type: 'lines', parts: ['label', 'value'], hint: 'One per line: Label | Value (number)', default: ['Low|64', 'Medium|38', 'High|19', 'Critical|4'] }
            ],
            preview: function (v, theme) {
                var total = v.slices.reduce(function (sum, s) { return sum + (parseFloat(s.value) || 0); }, 0) || 1;
                var palette = pdChartPalette(theme, v.slices.length);
                var acc = 0;
                var stops = v.slices.map(function (s, i) {
                    var val = parseFloat(s.value) || 0;
                    var start = (acc / total) * 100;
                    acc += val;
                    var end = (acc / total) * 100;
                    return palette[i] + ' ' + start.toFixed(2) + '% ' + end.toFixed(2) + '%';
                }).join(', ');
                var legend = v.slices.map(function (s, i) {
                    return '<div style="display:flex;align-items:center;gap:10px;margin-bottom:12px;">' +
                        '<span style="width:12px;height:12px;border-radius:3px;background:' + palette[i] + ';flex:none;"></span>' +
                        '<span style="font-size:13.5px;color:#334155;">' + pdEsc(s.label) + '</span>' +
                        '<span style="margin-left:auto;font-size:13px;font-weight:700;color:#0F172A;">' + pdEsc(s.value) + '</span></div>';
                }).join('');
                var inner = '<div style="padding:64px 96px;"><h1 style="margin:0 0 40px;font-size:32px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;align-items:center;gap:64px;">' +
                        '<div style="position:relative;width:270px;height:270px;flex:none;">' +
                            '<div style="width:270px;height:270px;border-radius:50%;background:conic-gradient(' + stops + ');"></div>' +
                            '<div style="position:absolute;top:50%;left:50%;transform:translate(-50%,-50%);width:145px;height:145px;border-radius:50%;background:#FFFFFF;display:flex;flex-direction:column;align-items:center;justify-content:center;">' +
                                '<div style="font-size:26px;font-weight:800;color:#0F172A;">' + pdEsc(String(total)) + '</div>' +
                                '<div style="font-size:11px;color:#64748B;">Total</div></div></div>' +
                        '<div style="flex:1;max-width:380px;">' + legend + '</div></div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var palette = pdChartPalette(theme, v.slices.length).map(pdHex);
                var data = [{ name: 'Series 1', labels: v.slices.map(function (s2) { return s2.label; }), values: v.slices.map(function (s2) { return parseFloat(s2.value) || 0; }) }];
                s.addChart(pptx.ChartType.doughnut, data, { x: 1.5, y: 1.3, w: 6.5, h: 5.6, chartColors: palette, showLegend: true, legendPos: 'r', showTitle: false, holeSize: 55 });
            }
        },

        {
            id: 'line-chart',
            type: 'pptx',
            kind: 'light',
            name: 'Line Chart',
            description: 'A trend line over time, with a soft area fill.',
            thumb: [{ x: 10, y: 60, w: 10, h: 20 }, { x: 26, y: 45, w: 10, h: 35, accent: true }, { x: 42, y: 52, w: 10, h: 28 }, { x: 58, y: 30, w: 10, h: 50 }, { x: 74, y: 20, w: 10, h: 60, accent: true }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Ticket Backlog Trend' },
                { key: 'points', label: 'Points', type: 'lines', parts: ['label', 'value'], hint: 'One per line: Label | Value (number)', default: ['Jan|420', 'Feb|360', 'Mar|310', 'Apr|250', 'May|190', 'Jun|140'] }
            ],
            preview: function (v, theme) {
                var vals = v.points.map(function (p) { return parseFloat(p.value) || 0; });
                var max = Math.max.apply(null, vals) || 1;
                var min = Math.min(0, Math.min.apply(null, vals));
                var w = 900, h = 240, pad = 10;
                var n = v.points.length || 1;
                var stepX = n > 1 ? (w - pad * 2) / (n - 1) : 0;
                var range = (max - min) || 1;
                function yFor(val) { return pad + (h - pad * 2) * (1 - (val - min) / range); }
                var pts = vals.map(function (val, i) { return (pad + i * stepX) + ',' + yFor(val); });
                var linePoints = pts.join(' ');
                var areaPoints = [pad + ',' + (h - pad)].concat(pts).concat([(pad + (n - 1) * stepX) + ',' + (h - pad)]).join(' ');
                var dots = vals.map(function (val, i) {
                    return '<circle cx="' + (pad + i * stepX) + '" cy="' + yFor(val) + '" r="5" fill="' + theme.accent + '" stroke="#fff" stroke-width="2"/>';
                }).join('');
                var labels = v.points.map(function (p, i) {
                    var x = ((pad + i * stepX) / w) * 100;
                    return '<div style="position:absolute;left:' + x + '%;top:0;transform:translateX(-50%);font-size:11.5px;color:#64748B;white-space:nowrap;">' + pdEsc(p.label) + '</div>';
                }).join('');
                var inner = '<div style="padding:64px 96px;"><h1 style="margin:0 0 44px;font-size:34px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="position:relative;padding-bottom:30px;">' +
                        '<svg viewBox="0 0 ' + w + ' ' + h + '" style="width:100%;height:240px;display:block;" preserveAspectRatio="none">' +
                            '<polygon points="' + areaPoints + '" fill="' + pdRgba(theme.accent, .12) + '"/>' +
                            '<polyline points="' + linePoints + '" fill="none" stroke="' + theme.accent + '" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"/>' +
                            dots +
                        '</svg>' +
                        '<div style="position:relative;height:20px;">' + labels + '</div></div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var data = [{ name: 'Trend', labels: v.points.map(function (p) { return p.label; }), values: v.points.map(function (p) { return parseFloat(p.value) || 0; }) }];
                s.addChart(pptx.ChartType.line, data, { x: 1, y: 1.3, w: 11.3, h: 5.6, chartColors: [pdHex(theme.accent)], showLegend: false, showTitle: false, lineDataSymbol: 'circle', lineSize: 2.5 });
            }
        },

        {
            id: 'big-statement',
            type: 'pptx',
            kind: 'dark',
            name: 'Big Number Statement',
            description: 'One huge stat as the whole slide, for maximum impact.',
            thumb: [{ x: 25, y: 22, w: 50, h: 38, accent: true }, { x: 30, y: 66, w: 40, h: 8 }],
            fields: [
                { key: 'value', label: 'Number', type: 'text', default: '98%' },
                { key: 'label', label: 'Label', type: 'text', default: 'Patch Compliance Across the Estate' },
                { key: 'context', label: 'Context line', type: 'text', default: 'Up from 74% at the start of the year' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;height:100%;text-align:center;padding:0 100px;">' +
                    '<div style="font-size:150px;font-weight:800;color:' + theme.accent2 + ';line-height:1;">' + pdEsc(v.value) + '</div>' +
                    '<div style="margin-top:18px;font-size:24px;font-weight:700;color:#F8FAFC;max-width:760px;">' + pdEsc(v.label) + '</div>' +
                    '<div style="margin-top:14px;font-size:14px;color:#94A3B8;">' + pdEsc(v.context) + '</div></div>';
                return pdDarkShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: '0B1220' };
                s.addText(v.value, { x: 1, y: 1.6, w: 11.3, h: 2.2, fontSize: 110, bold: true, color: pdHex(theme.accent2), align: 'center' });
                s.addText(v.label, { x: 1.5, y: 3.9, w: 10.3, h: 0.8, fontSize: 20, bold: true, color: 'F8FAFC', align: 'center' });
                s.addText(v.context, { x: 1.5, y: 4.6, w: 10.3, h: 0.5, fontSize: 13, color: '94A3B8', align: 'center' });
            }
        },

        {
            id: 'split-highlight',
            type: 'pptx',
            kind: 'light',
            name: 'Split Highlight',
            description: 'A bold color panel beside a heading and short paragraph.',
            thumb: [{ x: 0, y: 0, w: 35, h: 100, accent: true }, { x: 46, y: 35, w: 45, h: 10 }, { x: 46, y: 52, w: 35, h: 8 }],
            fields: [
                { key: 'panelLabel', label: 'Panel label', type: 'text', default: 'NEW' },
                { key: 'panelValue', label: 'Panel value', type: 'text', default: 'v2.0' },
                { key: 'heading', label: 'Heading', type: 'text', default: 'Presentation Designer Now Available' },
                { key: 'body', label: 'Body', type: 'paragraph', default: 'Build enterprise-grade slides and reports without leaving InfraVault — fully offline, no templates to hunt for.' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="display:flex;height:100%;">' +
                    '<div style="width:38%;background:linear-gradient(160deg,' + theme.accent + ',' + theme.accent2 + ');display:flex;flex-direction:column;align-items:center;justify-content:center;color:#fff;text-align:center;padding:0 30px;">' +
                        '<div style="font-size:13px;font-weight:700;letter-spacing:2px;opacity:.85;">' + pdEsc(v.panelLabel) + '</div>' +
                        '<div style="font-size:52px;font-weight:800;margin-top:10px;">' + pdEsc(v.panelValue) + '</div></div>' +
                    '<div style="flex:1;display:flex;flex-direction:column;justify-content:center;padding:0 72px;">' +
                        '<h1 style="margin:0;font-size:34px;font-weight:800;color:#0F172A;line-height:1.2;">' + pdEsc(v.heading) + '</h1>' +
                        '<p style="margin-top:20px;font-size:16px;line-height:1.6;color:#475569;max-width:520px;">' + pdEsc(v.body) + '</p></div></div>';
                return '<div style="width:1280px;height:720px;overflow:hidden;background:#FFFFFF;font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;">' + inner + '</div>';
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 5.07, h: 7.5, fill: { color: pdHex(theme.accent) } });
                s.addText(v.panelLabel, { x: 0.5, y: 3.0, w: 4.07, h: 0.4, fontSize: 13, bold: true, color: 'FFFFFF', align: 'center', charSpacing: 2 });
                s.addText(v.panelValue, { x: 0.5, y: 3.4, w: 4.07, h: 0.9, fontSize: 40, bold: true, color: 'FFFFFF', align: 'center' });
                s.addText(v.heading, { x: 5.5, y: 2.3, w: 7.3, h: 1.3, fontSize: 26, bold: true, color: '0F172A' });
                s.addText(v.body, { x: 5.5, y: 3.7, w: 6.8, h: 1.6, fontSize: 14, color: '475569' });
            }
        },

        {
            id: 'data-table',
            type: 'pptx',
            kind: 'light',
            name: 'Data Table',
            description: 'A real, sortable-looking table with as many rows and columns as you need.',
            thumb: [{ x: 8, y: 20, w: 84, h: 12, accent: true }, { x: 8, y: 36, w: 84, h: 10 }, { x: 8, y: 50, w: 84, h: 10 }, { x: 8, y: 64, w: 84, h: 10 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Server Inventory Snapshot' },
                { key: 'columns', label: 'Columns', type: 'csv', hint: 'Comma-separated column headers', default: 'Hostname,Environment,OS,Status' },
                { key: 'rows', label: 'Rows', type: 'table-rows', hint: 'One row per line, cells separated by |', default: ['srv-web01|Production|RHEL 9|Healthy', 'srv-db02|Production|RHEL 8|Healthy', 'srv-app03|DR|RHEL 9|Standby', 'srv-test04|Sandbox|RHEL 9|Decommissioning'] }
            ],
            preview: function (v, theme) {
                var head = v.columns.map(function (c) { return '<th style="text-align:left;padding:10px 14px;background:' + theme.accent + ';color:#fff;font-size:12px;font-weight:700;">' + pdEsc(c) + '</th>'; }).join('');
                var body = v.rows.map(function (r, i) {
                    var cells = r.map(function (c) { return '<td style="padding:9px 14px;font-size:12.5px;color:#1E293B;border-bottom:1px solid #E2E8F0;">' + pdEsc(c) + '</td>'; }).join('');
                    return '<tr style="background:' + (i % 2 === 0 ? '#F8FAFC' : '#FFFFFF') + ';">' + cells + '</tr>';
                }).join('');
                var inner = '<div style="padding:56px 80px;"><h1 style="margin:0 0 30px;font-size:32px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<table style="width:100%;border-collapse:collapse;"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var tableRows = [];
                tableRows.push(v.columns.map(function (c) { return { text: c, options: { bold: true, color: 'FFFFFF', fill: { color: pdHex(theme.accent) }, fontSize: 12 } }; }));
                v.rows.forEach(function (r, i) {
                    tableRows.push(r.map(function (cell) { return { text: cell, options: { fontSize: 11, color: '1E293B', fill: { color: i % 2 === 0 ? 'F8FAFC' : 'FFFFFF' } } }; }));
                });
                s.addTable(tableRows, { x: 1, y: 1.3, w: 11.3, h: 5.5, border: { type: 'solid', color: 'E2E8F0', pt: 0.5 } });
            }
        },

        {
            id: 'pricing-tiers',
            type: 'pptx',
            kind: 'light',
            name: 'Pricing / Tiers',
            description: 'Three side-by-side plan cards with one highlighted as recommended.',
            thumb: [{ x: 8, y: 20, w: 26, h: 60 }, { x: 37, y: 12, w: 26, h: 68, accent: true }, { x: 66, y: 20, w: 26, h: 60 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Choose Your Plan' },
                { key: 'tier1Name', label: 'Tier 1 name', type: 'text', default: 'Starter' },
                { key: 'tier1Price', label: 'Tier 1 price', type: 'text', default: '$0/mo' },
                { key: 'tier1Features', label: 'Tier 1 features', type: 'lines', hint: 'One per line', default: ['Up to 10 servers', 'Community support', 'Basic reporting'] },
                { key: 'tier2Name', label: 'Tier 2 name', type: 'text', default: 'Professional' },
                { key: 'tier2Price', label: 'Tier 2 price', type: 'text', default: '$49/mo' },
                { key: 'tier2Features', label: 'Tier 2 features', type: 'lines', hint: 'One per line', default: ['Up to 200 servers', 'Priority support', 'Advanced reporting', 'Audit trail'] },
                { key: 'tier3Name', label: 'Tier 3 name', type: 'text', default: 'Enterprise' },
                { key: 'tier3Price', label: 'Tier 3 price', type: 'text', default: 'Custom' },
                { key: 'tier3Features', label: 'Tier 3 features', type: 'lines', hint: 'One per line', default: ['Unlimited servers', 'Dedicated support', 'SSO & RBAC', 'Custom integrations'] },
                { key: 'highlight', label: 'Highlighted tier (1, 2 or 3)', type: 'text', default: '2' }
            ],
            preview: function (v, theme) {
                var tiers = [
                    { n: '1', name: v.tier1Name, price: v.tier1Price, features: v.tier1Features },
                    { n: '2', name: v.tier2Name, price: v.tier2Price, features: v.tier2Features },
                    { n: '3', name: v.tier3Name, price: v.tier3Price, features: v.tier3Features }
                ];
                var highlight = String(v.highlight || '').trim();
                var cards = tiers.map(function (t) {
                    var isHi = t.n === highlight;
                    var feats = t.features.map(function (f) {
                        return '<div style="display:flex;gap:8px;align-items:flex-start;font-size:12.5px;margin-bottom:8px;">' +
                            '<svg width="14" height="14" viewBox="0 0 24 24" style="flex:none;margin-top:2px;"><path d="M6 12l4 4 8-9" fill="none" stroke="' + (isHi ? '#fff' : theme.accent) + '" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>' +
                            '<span>' + pdEsc(f) + '</span></div>';
                    }).join('');
                    return '<div style="flex:1;border-radius:14px;padding:26px 22px;' +
                        (isHi ? 'background:' + theme.accent + ';color:#fff;transform:translateY(-10px);box-shadow:0 12px 28px ' + pdRgba(theme.accent, .35) + ';' : 'background:#F8FAFC;border:1px solid #E2E8F0;color:#0F172A;') + '">' +
                        (isHi ? '<div style="font-size:10.5px;font-weight:700;letter-spacing:1px;text-transform:uppercase;opacity:.85;margin-bottom:10px;">Recommended</div>' : '') +
                        '<div style="font-size:16px;font-weight:800;">' + pdEsc(t.name) + '</div>' +
                        '<div style="font-size:26px;font-weight:800;margin:10px 0 18px;">' + pdEsc(t.price) + '</div>' +
                        feats + '</div>';
                }).join('');
                var inner = '<div style="padding:52px 80px;"><h1 style="margin:0 0 34px;font-size:32px;font-weight:800;color:#0F172A;text-align:center;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:flex;gap:20px;align-items:center;">' + cards + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A', align: 'center' });
                var tiers = [
                    { n: '1', name: v.tier1Name, price: v.tier1Price, features: v.tier1Features },
                    { n: '2', name: v.tier2Name, price: v.tier2Price, features: v.tier2Features },
                    { n: '3', name: v.tier3Name, price: v.tier3Price, features: v.tier3Features }
                ];
                var highlight = String(v.highlight || '').trim();
                var gap = 0.3, totalW = 11.3, cardW = (totalW - gap * 2) / 3;
                tiers.forEach(function (t, i) {
                    var x = 1 + i * (cardW + gap);
                    var isHi = t.n === highlight;
                    var y = isHi ? 1.15 : 1.35;
                    var h = isHi ? 5.6 : 5.3;
                    s.addShape(pptx.ShapeType.roundRect, { x: x, y: y, w: cardW, h: h, fill: { color: isHi ? pdHex(theme.accent) : 'F8FAFC' }, line: { color: isHi ? pdHex(theme.accent) : 'E2E8F0', width: 1 } });
                    var textColor = isHi ? 'FFFFFF' : '0F172A';
                    var yy = y + 0.25;
                    if (isHi) {
                        s.addText('RECOMMENDED', { x: x + 0.25, y: yy, w: cardW - 0.5, h: 0.3, fontSize: 9, bold: true, color: 'FFFFFF', charSpacing: 1 });
                        yy += 0.35;
                    }
                    s.addText(t.name, { x: x + 0.25, y: yy, w: cardW - 0.5, h: 0.4, fontSize: 15, bold: true, color: textColor });
                    yy += 0.45;
                    s.addText(t.price, { x: x + 0.25, y: yy, w: cardW - 0.5, h: 0.5, fontSize: 22, bold: true, color: textColor });
                    yy += 0.65;
                    var featureRuns = t.features.map(function (f) { return { text: '✓  ' + f, options: { breakLine: true, fontSize: 11, color: textColor } }; });
                    s.addText(featureRuns, { x: x + 0.25, y: yy, w: cardW - 0.5, h: (y + h) - yy - 0.2 });
                });
            }
        },

        {
            id: 'feature-grid',
            type: 'pptx',
            kind: 'light',
            name: 'Feature Grid',
            description: 'A 2x2 grid of numbered feature cards.',
            thumb: [{ x: 8, y: 15, w: 40, h: 35, accent: true }, { x: 52, y: 15, w: 40, h: 35 }, { x: 8, y: 54, w: 40, h: 35 }, { x: 52, y: 54, w: 40, h: 35 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Platform Capabilities' },
                { key: 'features', label: 'Features', type: 'lines', parts: ['title', 'description'], hint: 'One per line: Title | Description', default: ['Asset Tracking|Every server, licence and warranty in one registry', 'Patch Compliance|Quarterly patching tracked host-by-host', 'Audit Trail|Full history on every record, every change', 'Role-Based Access|Six permission verbs per page, per role'] }
            ],
            preview: function (v, theme) {
                var cards = v.features.slice(0, 4).map(function (f, i) {
                    return '<div style="background:#F8FAFC;border:1px solid #E2E8F0;border-radius:14px;padding:24px;">' +
                        '<div style="width:36px;height:36px;border-radius:9px;background:' + pdRgba(theme.accent, .14) + ';color:' + theme.accent + ';font-weight:800;font-size:15px;display:flex;align-items:center;justify-content:center;margin-bottom:14px;">' + (i + 1) + '</div>' +
                        '<div style="font-size:15px;font-weight:700;color:#0F172A;margin-bottom:6px;">' + pdEsc(f.title) + '</div>' +
                        '<div style="font-size:12.5px;line-height:1.5;color:#64748B;">' + pdEsc(f.description) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:56px 90px;"><h1 style="margin:0 0 34px;font-size:32px;font-weight:800;color:#0F172A;">' + pdEsc(v.heading) + '</h1>' +
                    '<div style="display:grid;grid-template-columns:1fr 1fr;gap:18px;">' + cards + '</div></div>';
                return pdLightShell(theme, inner);
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };
                s.addText(v.heading, { x: 1, y: 0.5, w: 11.3, h: 0.6, fontSize: 26, bold: true, color: '0F172A' });
                var gap = 0.3, totalW = 11.3, cardW = (totalW - gap) / 2, cardH = 2.35, startY = 1.35;
                v.features.slice(0, 4).forEach(function (f, i) {
                    var col = i % 2, row = Math.floor(i / 2);
                    var x = 1 + col * (cardW + gap), y = startY + row * (cardH + gap);
                    s.addShape(pptx.ShapeType.roundRect, { x: x, y: y, w: cardW, h: cardH, fill: { color: 'F8FAFC' }, line: { color: 'E2E8F0', width: 1 } });
                    s.addShape(pptx.ShapeType.roundRect, { x: x + 0.25, y: y + 0.22, w: 0.4, h: 0.4, fill: { color: pdHex(theme.accent) } });
                    s.addText(String(i + 1), { x: x + 0.25, y: y + 0.22, w: 0.4, h: 0.4, fontSize: 13, bold: true, color: 'FFFFFF', align: 'center', valign: 'middle' });
                    s.addText(f.title, { x: x + 0.8, y: y + 0.2, w: cardW - 1, h: 0.4, fontSize: 14, bold: true, color: '0F172A' });
                    s.addText(f.description, { x: x + 0.25, y: y + 0.75, w: cardW - 0.5, h: cardH - 0.95, fontSize: 11, color: '64748B' });
                });
            }
        },

        {
            id: 'company-overview',
            type: 'pptx',
            kind: 'light',
            name: 'Company / Project Overview',
            description: 'A dense one-slide overview: team sidebar, colored service tags, a problem/solution grid and stat cards.',
            thumb: [
                { x: 0, y: 0, w: 22, h: 100, accent: true },
                { x: 28, y: 8, w: 30, h: 8 }, { x: 60, y: 8, w: 22, h: 8 },
                { x: 28, y: 22, w: 30, h: 24 }, { x: 60, y: 22, w: 30, h: 24 },
                { x: 28, y: 50, w: 30, h: 24 }, { x: 60, y: 50, w: 30, h: 24 },
                { x: 84, y: 8, w: 14, h: 28, accent: true }, { x: 84, y: 40, w: 14, h: 28 }
            ],
            fields: [
                { key: 'company', label: 'Company / project name', type: 'text', default: 'Tech Innovators Inc.' },
                { key: 'team', label: 'Team', type: 'lines', parts: ['name', 'role'], hint: 'One per line: Name | Role', default: ['West|CEO', 'East|CTO', 'North|CFO'] },
                { key: 'phone', label: 'Phone', type: 'text', default: '(212) 999 0909' },
                { key: 'email', label: 'Email', type: 'text', default: 'info@example.com' },
                { key: 'heading', label: 'Heading', type: 'text', default: 'Company Overview' },
                { key: 'overview', label: 'Overview', type: 'paragraph', default: 'Tech  Inc. provides technology solutions to businesses across various industries. Our services range from software development to IT consulting.' },
                { key: 'services', label: 'Services (tags)', type: 'csv', hint: 'Comma-separated — each one gets its own color', default: 'Software Development, IT Consulting, Cloud Solutions, Cybersecurity, Data Analytics, AI & Machine Learning' },
                { key: 'sections', label: 'Sections', type: 'lines', parts: ['heading', 'body'], hint: 'One per line: Heading | Body (up to 6, shown 2 per row)', default: ['Problem|Many businesses struggle with outdated technology systems that hinder their growth and efficiency.', 'Solution|We offer tailored software development and IT consulting services that help businesses modernize their technology infrastructure.', 'Market|Our primary market includes medium to large enterprises in sectors such as finance, healthcare, and retail.', 'Business Model|We operate on a subscription-based model for our software solutions, along with project-based pricing for consulting services.', 'Competition|Our competitors include established IT service providers and smaller boutique firms specializing in specific niches.', 'Strategy|Our strategy focuses on continuous innovation, customer-centric service, and strategic partnerships to expand our market reach.'] },
                { key: 'stats', label: 'Stats (right column)', type: 'lines', parts: ['value', 'label'], hint: 'One per line: Value | Label (up to 3)', default: ['4K|Clients Served', '17K|Successful Projects Completed', '80%|Increase in Client Productivity'] }
            ],
            preview: function (v, theme) {
                function initials(name) {
                    var parts = name.replace(/\(.*?\)/g, '').trim().split(/\s+/).filter(Boolean);
                    return ((parts[0] || '').charAt(0) + (parts.length > 1 ? parts[parts.length - 1].charAt(0) : '')).toUpperCase();
                }
                var team = v.team.slice(0, 4).map(function (p) {
                    return '<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px;">' +
                        '<div style="width:38px;height:38px;flex:none;border-radius:50%;background:' + pdRgba(theme.accent2, .22) + ';color:' + theme.accent2 + ';font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;">' + initials(p.name) + '</div>' +
                        '<div><div style="font-size:12.5px;font-weight:700;color:#F8FAFC;">' + pdEsc(p.name) + '</div><div style="font-size:10.5px;color:#94A3B8;">' + pdEsc(p.role) + '</div></div></div>';
                }).join('');

                var palette = pdChartPalette(theme, Math.max(1, v.services.length));
                var tags = v.services.map(function (svc, i) {
                    return '<span style="display:inline-block;background:' + palette[i] + ';color:#fff;font-size:10.5px;font-weight:700;padding:6px 12px;border-radius:999px;margin:0 8px 8px 0;">' + pdEsc(svc) + '</span>';
                }).join('');

                var cards = v.sections.slice(0, 6).map(function (sec) {
                    return '<div><div style="font-size:12.5px;font-weight:700;color:#0F172A;margin-bottom:4px;">' + pdEsc(sec.heading) + '</div>' +
                        '<div style="font-size:10.5px;line-height:1.5;color:#64748B;">' + pdEsc(sec.body) + '</div></div>';
                }).join('');

                var stats = v.stats.slice(0, 3).map(function (st, i) {
                    return '<div style="text-align:center;padding:22px 10px;' + (i > 0 ? 'border-top:1px solid #E2E8F0;' : '') + '">' +
                        '<div style="font-size:30px;font-weight:800;color:#0F172A;">' + pdEsc(st.value) + '</div>' +
                        '<div style="margin-top:6px;font-size:10.5px;color:#64748B;">' + pdEsc(st.label) + '</div></div>';
                }).join('');

                var inner = '<div style="display:flex;height:100%;">' +
                    '<div style="width:300px;flex:none;background:linear-gradient(165deg,#0B1220,#0F1B2E);padding:34px 26px;box-sizing:border-box;">' +
                        '<div style="font-size:17px;font-weight:800;color:#F8FAFC;line-height:1.3;margin-bottom:26px;">' + pdEsc(v.company) + '</div>' +
                        '<div style="font-size:10px;font-weight:700;letter-spacing:1.5px;color:' + theme.accent2 + ';margin-bottom:16px;">TEAM</div>' +
                        team +
                        '<div style="height:1px;background:rgba(255,255,255,.12);margin:20px 0;"></div>' +
                        '<div style="font-size:10px;font-weight:700;letter-spacing:1.5px;color:' + theme.accent2 + ';margin-bottom:12px;">CONTACT</div>' +
                        '<div style="font-size:11.5px;color:#CBD5E1;margin-bottom:6px;">' + pdEsc(v.phone) + '</div>' +
                        '<div style="font-size:11.5px;color:#CBD5E1;">' + pdEsc(v.email) + '</div>' +
                    '</div>' +
                    '<div style="flex:1;min-width:0;padding:34px 30px;box-sizing:border-box;">' +
                        '<div style="font-size:11px;font-weight:700;letter-spacing:1.5px;color:' + theme.accent + ';margin-bottom:8px;">' + pdEsc(v.heading.toUpperCase()) + '</div>' +
                        '<div style="font-size:13px;line-height:1.6;color:#334155;margin-bottom:18px;">' + pdEsc(v.overview) + '</div>' +
                        '<div style="margin-bottom:20px;">' + tags + '</div>' +
                        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:18px 24px;">' + cards + '</div>' +
                    '</div>' +
                    '<div style="width:270px;flex:none;background:#F8FAFC;border-left:1px solid #E2E8F0;">' + stats + '</div>' +
                '</div>';

                return '<div style="width:1280px;height:720px;overflow:hidden;background:#FFFFFF;font-family:\'Inter\',\'Segoe UI\',Arial,sans-serif;">' + inner + '</div>';
            },
            buildPptx: function (pptx, v, theme, opts) {
                var s = pdAddSlide(pptx, opts);
                s.background = { color: 'FFFFFF' };

                s.addShape(pptx.ShapeType.rect, { x: 0, y: 0, w: 3.2, h: 7.5, fill: { color: '0B1220' } });
                s.addText(v.company, { x: 0.35, y: 0.35, w: 2.5, h: 0.6, fontSize: 16, bold: true, color: 'F8FAFC' });
                s.addText('TEAM', { x: 0.35, y: 1.05, w: 2.5, h: 0.3, fontSize: 9, bold: true, color: pdHex(theme.accent2), charSpacing: 2 });

                var ty = 1.4;
                v.team.slice(0, 4).forEach(function (p) {
                    var ini = p.name.replace(/\(.*?\)/g, '').trim().split(/\s+/).filter(Boolean).map(function (w) { return w.charAt(0); }).join('').substring(0, 2).toUpperCase();
                    s.addShape(pptx.ShapeType.ellipse, { x: 0.35, y: ty, w: 0.42, h: 0.42, fill: { color: pdHex(theme.accent2), transparency: 78 } });
                    s.addText(ini, { x: 0.35, y: ty, w: 0.42, h: 0.42, fontSize: 11, bold: true, color: pdHex(theme.accent2), align: 'center', valign: 'middle' });
                    s.addText(p.name, { x: 0.9, y: ty - 0.03, w: 2.0, h: 0.3, fontSize: 11, bold: true, color: 'F8FAFC' });
                    s.addText(p.role, { x: 0.9, y: ty + 0.22, w: 2.0, h: 0.25, fontSize: 9, color: '94A3B8' });
                    ty += 0.72;
                });

                s.addShape(pptx.ShapeType.line, { x: 0.35, y: ty + 0.05, w: 2.5, h: 0, line: { color: 'FFFFFF', width: 0.5, transparency: 88 } });
                s.addText('CONTACT', { x: 0.35, y: ty + 0.2, w: 2.5, h: 0.3, fontSize: 9, bold: true, color: pdHex(theme.accent2), charSpacing: 2 });
                s.addText(v.phone, { x: 0.35, y: ty + 0.52, w: 2.5, h: 0.3, fontSize: 10.5, color: 'CBD5E1' });
                s.addText(v.email, { x: 0.35, y: ty + 0.8, w: 2.5, h: 0.3, fontSize: 10.5, color: 'CBD5E1' });

                var mx = 3.55;
                s.addText(v.heading.toUpperCase(), { x: mx, y: 0.35, w: 6, h: 0.3, fontSize: 11, bold: true, color: pdHex(theme.accent), charSpacing: 2 });
                s.addText(v.overview, { x: mx, y: 0.68, w: 6.2, h: 0.9, fontSize: 12, color: '334155' });

                var palette = pdChartPalette(theme, Math.max(1, v.services.length)).map(pdHex);
                var tx = mx, tyy = 1.75, rowH = 0.4;
                v.services.forEach(function (svc, i) {
                    var w = Math.min(2.6, Math.max(0.9, svc.length * 0.085 + 0.35));
                    if (tx + w > mx + 6.3) { tx = mx; tyy += rowH; }
                    s.addShape(pptx.ShapeType.roundRect, { x: tx, y: tyy, w: w, h: 0.32, rectRadius: 0.16, fill: { color: palette[i] } });
                    s.addText(svc, { x: tx, y: tyy, w: w, h: 0.32, fontSize: 9, bold: true, color: 'FFFFFF', align: 'center', valign: 'middle' });
                    tx += w + 0.14;
                });

                var gridTop = tyy + 0.62;
                var colW = 3.0, rowH2 = 0.95;
                v.sections.slice(0, 6).forEach(function (sec, i) {
                    var col = i % 2, row = Math.floor(i / 2);
                    var x = mx + col * (colW + 0.3), y = gridTop + row * rowH2;
                    s.addText(sec.heading, { x: x, y: y, w: colW, h: 0.3, fontSize: 12, bold: true, color: '0F172A' });
                    s.addText(sec.body, { x: x, y: y + 0.28, w: colW, h: rowH2 - 0.3, fontSize: 9.5, color: '64748B' });
                });

                var rx = 10.3, rw = 2.6;
                s.addShape(pptx.ShapeType.rect, { x: rx - 0.25, y: 0, w: rw + 0.5, h: 7.5, fill: { color: 'F8FAFC' }, line: { color: 'E2E8F0', width: 1 } });
                var sh = 7.5 / Math.max(1, Math.min(3, v.stats.length));
                v.stats.slice(0, 3).forEach(function (st, i) {
                    var y = i * sh;
                    if (i > 0) s.addShape(pptx.ShapeType.line, { x: rx - 0.1, y: y, w: rw + 0.2, h: 0, line: { color: 'E2E8F0', width: 1 } });
                    s.addText(st.value, { x: rx - 0.25, y: y + sh / 2 - 0.5, w: rw + 0.5, h: 0.7, fontSize: 26, bold: true, color: '0F172A', align: 'center' });
                    s.addText(st.label, { x: rx - 0.15, y: y + sh / 2 + 0.15, w: rw + 0.3, h: 0.5, fontSize: 10, color: '64748B', align: 'center' });
                });
            }
        },

        /* ============================== DOCX ============================== */

        {
            id: 'report-cover',
            type: 'docx',
            kind: 'light',
            name: 'Report Cover',
            description: 'Cover page for a report or document pack.',
            thumb: [{ x: 15, y: 12, w: 70, h: 8 }, { x: 25, y: 38, w: 50, h: 12, accent: true }, { x: 30, y: 56, w: 40, h: 7 }],
            fields: [
                { key: 'title', label: 'Title', type: 'text', default: 'InfraVault Platform Overview' },
                { key: 'subtitle', label: 'Subtitle', type: 'text', default: 'Enterprise IT Management Platform' },
                { key: 'org', label: 'Organization', type: 'text', default: '[ORGANIZATION]' },
                { key: 'preparedBy', label: 'Prepared by', type: 'text', default: 'IT Operations' },
                { key: 'date', label: 'Date', type: 'text', default: '[DATE]' }
            ],
            preview: function (v, theme) {
                var inner = '<div style="height:100%;display:flex;flex-direction:column;padding:64px 72px;">' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:2px;color:#64748B;text-transform:uppercase;">' + pdEsc(v.org) + '</div>' +
                    '<div style="flex:1;display:flex;flex-direction:column;justify-content:center;text-align:center;">' +
                        '<h1 style="margin:0;font-size:42px;font-weight:800;color:#0B1220;">' + pdEsc(v.title) + '</h1>' +
                        '<div style="margin-top:14px;font-size:17px;font-weight:600;color:' + theme.accent + ';">' + pdEsc(v.subtitle) + '</div>' +
                        '<div style="margin:26px auto 0;width:64px;height:3px;background:linear-gradient(90deg,' + theme.accent + ',' + theme.accent2 + ');border-radius:2px;"></div>' +
                    '</div>' +
                    '<div style="border-top:1px solid #E5E7EB;padding-top:20px;display:flex;justify-content:space-between;font-size:12.5px;color:#334155;">' +
                        '<span>' + pdEsc(v.preparedBy) + '</span><span>' + pdEsc(v.date) + '</span></div></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                return [
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.org, bold: true, color: '64748B', size: 18 })], spacing: { after: 2400 } }),
                    new docx.Paragraph({ alignment: docx.AlignmentType.CENTER, children: [new docx.TextRun({ text: v.title, bold: true, size: 44, color: '0B1220' })], spacing: { after: 200 } }),
                    new docx.Paragraph({ alignment: docx.AlignmentType.CENTER, children: [new docx.TextRun({ text: v.subtitle, bold: true, size: 26, color: accent })], spacing: { after: 2400 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.preparedBy, size: 20, color: '334155' })], spacing: { before: 2400 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.date, size: 20, color: '334155' })] })
                ];
            }
        },

        {
            id: 'executive-summary',
            type: 'docx',
            kind: 'light',
            name: 'Executive Summary',
            description: 'One-page overview, key points and conclusion.',
            thumb: [{ x: 10, y: 12, w: 70, h: 9, accent: true }, { x: 10, y: 30, w: 80, h: 6 }, { x: 10, y: 42, w: 80, h: 6 }, { x: 10, y: 54, w: 60, h: 6 }],
            fields: [
                { key: 'title', label: 'Title', type: 'text', default: 'Executive Summary' },
                { key: 'overview', label: 'Overview', type: 'paragraph', default: 'InfraVault currently tracks 337 servers across production, DR and pre-production environments, with centralized asset, inventory and patch-compliance data replacing the previous spreadsheet-based process.' },
                { key: 'keyPoints', label: 'Key points', type: 'lines', hint: 'One point per line', default: ['Patch compliance improved from 74% to 98% quarter over quarter', 'Known Issues module reduced repeat-incident resolution time by half', 'UID/GID audit closed 40 cross-server account mismatches', 'Decommissioning workflow now tracks every retired asset end-to-end'] },
                { key: 'conclusion', label: 'Conclusion', type: 'paragraph', default: 'Continued investment in the platform is recommended, with the next phase focused on automated compliance reporting.' }
            ],
            preview: function (v, theme) {
                var points = v.keyPoints.map(function (p) { return '<li style="margin-bottom:10px;font-size:13.5px;line-height:1.6;color:#1E293B;">' + pdEsc(p) + '</li>'; }).join('');
                var inner = '<div style="padding:60px 68px;">' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:2px;color:' + theme.accent + ';text-transform:uppercase;margin-bottom:8px;">Executive Summary</div>' +
                    '<h1 style="margin:0 0 22px;font-size:28px;font-weight:800;color:#0B1220;">' + pdEsc(v.title) + '</h1>' +
                    '<p style="font-size:13.5px;line-height:1.7;color:#334155;white-space:pre-line;">' + pdEsc(v.overview) + '</p>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin:26px 0 12px;">Key Points</div>' +
                    '<ul style="margin:0;padding-left:20px;">' + points + '</ul>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin:26px 0 12px;">Conclusion</div>' +
                    '<p style="font-size:13.5px;line-height:1.7;color:#334155;white-space:pre-line;">' + pdEsc(v.conclusion) + '</p></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [
                    new docx.Paragraph({ children: [new docx.TextRun({ text: 'EXECUTIVE SUMMARY', bold: true, size: 18, color: accent })], spacing: { after: 120 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.title, bold: true, size: 32, color: '0B1220' })], spacing: { after: 280 } })
                ];
                v.overview.split('\n').filter(Boolean).forEach(function (line) {
                    paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: line, size: 22, color: '334155' })], spacing: { after: 160 } }));
                });
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'KEY POINTS', bold: true, size: 18, color: '64748B' })], spacing: { before: 200, after: 120 } }));
                v.keyPoints.forEach(function (p) { paras.push(new docx.Paragraph({ text: p, bullet: { level: 0 }, spacing: { after: 80 } })); });
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'CONCLUSION', bold: true, size: 18, color: '64748B' })], spacing: { before: 200, after: 120 } }));
                v.conclusion.split('\n').filter(Boolean).forEach(function (line) {
                    paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: line, size: 22, color: '334155' })], spacing: { after: 160 } }));
                });
                return paras;
            }
        },

        {
            id: 'project-proposal',
            type: 'docx',
            kind: 'light',
            name: 'Project Proposal',
            description: 'Objective, scope, timeline and budget.',
            thumb: [{ x: 10, y: 10, w: 80, h: 16, accent: true }, { x: 10, y: 34, w: 80, h: 6 }, { x: 10, y: 46, w: 80, h: 6 }, { x: 10, y: 58, w: 80, h: 6 }, { x: 10, y: 70, w: 50, h: 6 }],
            fields: [
                { key: 'projectTitle', label: 'Project title', type: 'text', default: 'Estate-Wide Patch Automation' },
                { key: 'preparedFor', label: 'Prepared for', type: 'text', default: 'IT Steering Committee' },
                { key: 'preparedBy', label: 'Prepared by', type: 'text', default: 'IT Operations' },
                { key: 'date', label: 'Date', type: 'text', default: '[DATE]' },
                { key: 'objective', label: 'Objective', type: 'paragraph', default: 'Reduce manual effort and patch-cycle time by automating quarterly patching across all managed servers.' },
                { key: 'scope', label: 'Scope', type: 'lines', hint: 'One line per scope item', default: ['Automate patch scheduling for all HCL-managed hosts', 'Integrate with the existing Quarterly Patching module', 'Provide a rollback plan for failed patch runs', 'Report compliance status per business unit'] },
                { key: 'timeline', label: 'Timeline', type: 'lines', parts: ['phase', 'dates'], hint: 'One per line: Phase | Dates', default: ['Discovery|Weeks 1-2', 'Pilot (20 servers)|Weeks 3-5', 'Estate rollout|Weeks 6-10', 'Review|Week 11'] },
                { key: 'budget', label: 'Budget', type: 'text', default: '[BUDGET AMOUNT]' }
            ],
            preview: function (v, theme) {
                var scope = v.scope.map(function (s) { return '<li style="margin-bottom:8px;font-size:13px;color:#1E293B;line-height:1.55;">' + pdEsc(s) + '</li>'; }).join('');
                var timelineRows = v.timeline.map(function (t) {
                    return '<tr><td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;font-size:12.5px;font-weight:600;color:#0B1220;">' + pdEsc(t.phase) + '</td>' +
                        '<td style="padding:8px 10px;border-bottom:1px solid #E5E7EB;font-size:12.5px;color:#64748B;">' + pdEsc(t.dates) + '</td></tr>';
                }).join('');
                var inner = '<div style="padding:56px 64px;">' +
                    '<div style="background:' + theme.accent + ';color:#fff;border-radius:10px;padding:22px 24px;margin-bottom:26px;">' +
                        '<div style="font-size:11px;letter-spacing:1.5px;opacity:.85;text-transform:uppercase;">Project Proposal</div>' +
                        '<div style="font-size:22px;font-weight:800;margin-top:6px;">' + pdEsc(v.projectTitle) + '</div></div>' +
                    '<div style="display:flex;justify-content:space-between;font-size:12px;color:#64748B;margin-bottom:22px;">' +
                        '<span><strong style="color:#334155;">Prepared for:</strong> ' + pdEsc(v.preparedFor) + '</span>' +
                        '<span><strong style="color:#334155;">Prepared by:</strong> ' + pdEsc(v.preparedBy) + '</span>' +
                        '<span><strong style="color:#334155;">Date:</strong> ' + pdEsc(v.date) + '</span></div>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:10px;">Objective</div>' +
                    '<p style="font-size:13px;line-height:1.65;color:#334155;margin:0 0 22px;white-space:pre-line;">' + pdEsc(v.objective) + '</p>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:10px;">Scope</div>' +
                    '<ul style="margin:0 0 22px;padding-left:18px;">' + scope + '</ul>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:10px;">Timeline</div>' +
                    '<table style="width:100%;border-collapse:collapse;margin-bottom:22px;">' + timelineRows + '</table>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:8px;">Budget</div>' +
                    '<p style="font-size:13px;color:#334155;margin:0;">' + pdEsc(v.budget) + '</p></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [];
                paras.push(new docx.Paragraph({
                    shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: accent },
                    children: [new docx.TextRun({ text: 'PROJECT PROPOSAL', bold: true, size: 16, color: 'FFFFFF' })],
                    spacing: { before: 80, after: 40 }
                }));
                paras.push(new docx.Paragraph({
                    shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: accent },
                    children: [new docx.TextRun({ text: v.projectTitle, bold: true, size: 30, color: 'FFFFFF' })],
                    spacing: { after: 200 }
                }));
                paras.push(new docx.Paragraph({
                    children: [
                        new docx.TextRun({ text: 'Prepared for: ', bold: true, size: 18, color: '334155' }),
                        new docx.TextRun({ text: v.preparedFor + '    ', size: 18, color: '64748B' }),
                        new docx.TextRun({ text: 'Prepared by: ', bold: true, size: 18, color: '334155' }),
                        new docx.TextRun({ text: v.preparedBy + '    ', size: 18, color: '64748B' }),
                        new docx.TextRun({ text: 'Date: ', bold: true, size: 18, color: '334155' }),
                        new docx.TextRun({ text: v.date, size: 18, color: '64748B' })
                    ],
                    spacing: { after: 280 }
                }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'OBJECTIVE', bold: true, size: 18, color: '64748B' })], spacing: { after: 100 } }));
                v.objective.split('\n').filter(Boolean).forEach(function (l) { paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: l, size: 22, color: '334155' })], spacing: { after: 140 } })); });
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'SCOPE', bold: true, size: 18, color: '64748B' })], spacing: { before: 160, after: 100 } }));
                v.scope.forEach(function (s) { paras.push(new docx.Paragraph({ text: s, bullet: { level: 0 }, spacing: { after: 70 } })); });
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'TIMELINE', bold: true, size: 18, color: '64748B' })], spacing: { before: 160, after: 100 } }));

                var rows = v.timeline.map(function (t) {
                    return new docx.TableRow({
                        children: [
                            new docx.TableCell({ width: { size: 40, type: docx.WidthType.PERCENTAGE }, children: [new docx.Paragraph({ children: [new docx.TextRun({ text: t.phase, bold: true, size: 20 })] })] }),
                            new docx.TableCell({ width: { size: 60, type: docx.WidthType.PERCENTAGE }, children: [new docx.Paragraph({ children: [new docx.TextRun({ text: t.dates, size: 20, color: '64748B' })] })] })
                        ]
                    });
                });
                paras.push(new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows: rows }));

                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'BUDGET', bold: true, size: 18, color: '64748B' })], spacing: { before: 220, after: 100 } }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: v.budget, size: 22, color: '334155' })] }));
                return paras;
            }
        },

        {
            id: 'meeting-minutes',
            type: 'docx',
            kind: 'light',
            name: 'Meeting Minutes',
            description: 'Attendees, agenda and tracked action items.',
            thumb: [{ x: 10, y: 10, w: 60, h: 9, accent: true }, { x: 10, y: 26, w: 80, h: 5 }, { x: 10, y: 36, w: 80, h: 5 }, { x: 10, y: 52, w: 35, h: 6 }, { x: 50, y: 52, w: 20, h: 6 }, { x: 74, y: 52, w: 16, h: 6 }],
            fields: [
                { key: 'meetingTitle', label: 'Meeting title', type: 'text', default: 'Infrastructure Change Review' },
                { key: 'date', label: 'Date', type: 'text', default: '[DATE]' },
                { key: 'attendees', label: 'Attendees', type: 'lines', hint: 'One name per line', default: ['example (Chair)', 'example', 'example', 'example'] },
                { key: 'agendaItems', label: 'Agenda', type: 'lines', hint: 'One item per line', default: ['Review outstanding change requests', 'Patch compliance status', 'Known issues escalations', 'AOB'] },
                { key: 'actionItems', label: 'Action items', type: 'lines', parts: ['task', 'owner', 'due'], hint: 'One per line: Task | Owner | Due', default: ['Close CR-4021|en|Next Friday', 'Update DR runbook|example|End of month'] }
            ],
            preview: function (v, theme) {
                var attendees = v.attendees.join(', ');
                var agenda = v.agendaItems.map(function (a) { return '<li style="margin-bottom:6px;font-size:12.5px;color:#1E293B;">' + pdEsc(a) + '</li>'; }).join('');
                var actions = v.actionItems.map(function (a) {
                    return '<tr><td style="padding:7px 9px;border-bottom:1px solid #E5E7EB;font-size:12px;color:#0B1220;">' + pdEsc(a.task) + '</td>' +
                        '<td style="padding:7px 9px;border-bottom:1px solid #E5E7EB;font-size:12px;color:#334155;">' + pdEsc(a.owner) + '</td>' +
                        '<td style="padding:7px 9px;border-bottom:1px solid #E5E7EB;font-size:12px;color:#64748B;">' + pdEsc(a.due) + '</td></tr>';
                }).join('');
                var inner = '<div style="padding:56px 64px;">' +
                    '<div style="border-bottom:3px solid ' + theme.accent + ';padding-bottom:16px;margin-bottom:20px;">' +
                        '<div style="font-size:11px;letter-spacing:1.5px;color:' + theme.accent + ';text-transform:uppercase;font-weight:700;">Meeting Minutes</div>' +
                        '<div style="font-size:24px;font-weight:800;color:#0B1220;margin-top:6px;">' + pdEsc(v.meetingTitle) + '</div>' +
                        '<div style="font-size:12px;color:#64748B;margin-top:6px;">' + pdEsc(v.date) + '</div></div>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:8px;">Attendees</div>' +
                    '<p style="font-size:12.5px;color:#334155;margin:0 0 20px;">' + pdEsc(attendees) + '</p>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:8px;">Agenda</div>' +
                    '<ul style="margin:0 0 20px;padding-left:18px;">' + agenda + '</ul>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1.2px;color:#64748B;text-transform:uppercase;margin-bottom:8px;">Action Items</div>' +
                    '<table style="width:100%;border-collapse:collapse;">' +
                        '<thead><tr><th style="text-align:left;font-size:11px;color:#94A3B8;padding:0 9px 6px;">Task</th><th style="text-align:left;font-size:11px;color:#94A3B8;padding:0 9px 6px;">Owner</th><th style="text-align:left;font-size:11px;color:#94A3B8;padding:0 9px 6px;">Due</th></tr></thead>' +
                        '<tbody>' + actions + '</tbody></table></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [];
                paras.push(new docx.Paragraph({
                    shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: accent },
                    children: [new docx.TextRun({ text: 'MEETING MINUTES', bold: true, size: 16, color: 'FFFFFF' })],
                    spacing: { after: 40 }
                }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: v.meetingTitle, bold: true, size: 32, color: '0B1220' })], spacing: { after: 60 } }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: v.date, size: 20, color: '64748B' })], spacing: { after: 280 } }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'ATTENDEES', bold: true, size: 18, color: '64748B' })], spacing: { after: 100 } }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: v.attendees.join(', '), size: 22, color: '334155' })], spacing: { after: 260 } }));
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'AGENDA', bold: true, size: 18, color: '64748B' })], spacing: { after: 100 } }));
                v.agendaItems.forEach(function (a) { paras.push(new docx.Paragraph({ text: a, bullet: { level: 0 }, spacing: { after: 60 } })); });
                paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: 'ACTION ITEMS', bold: true, size: 18, color: '64748B' })], spacing: { before: 220, after: 100 } }));

                var headerRow = new docx.TableRow({
                    children: ['Task', 'Owner', 'Due'].map(function (h) {
                        return new docx.TableCell({
                            shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: 'F1F5F9' },
                            children: [new docx.Paragraph({ children: [new docx.TextRun({ text: h, bold: true, size: 18, color: '64748B' })] })]
                        });
                    })
                });
                var rows = v.actionItems.map(function (a) {
                    return new docx.TableRow({
                        children: [a.task, a.owner, a.due].map(function (txt) {
                            return new docx.TableCell({ children: [new docx.Paragraph({ children: [new docx.TextRun({ text: txt, size: 20, color: '334155' })] })] });
                        })
                    });
                });
                paras.push(new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows: [headerRow].concat(rows) }));
                return paras;
            }
        },

        {
            id: 'memo',
            type: 'docx',
            kind: 'light',
            name: 'Memo',
            description: 'Classic interoffice memo header (To/From/Date/Re) plus body.',
            thumb: [{ x: 10, y: 12, w: 55, h: 9, accent: true }, { x: 10, y: 30, w: 30, h: 5 }, { x: 10, y: 40, w: 30, h: 5 }, { x: 10, y: 50, w: 30, h: 5 }, { x: 10, y: 64, w: 80, h: 5 }, { x: 10, y: 74, w: 70, h: 5 }],
            fields: [
                { key: 'to', label: 'To', type: 'text', default: 'All IT Staff' },
                { key: 'from', label: 'From', type: 'text', default: 'IT Operations' },
                { key: 'date', label: 'Date', type: 'text', default: '[DATE]' },
                { key: 'subject', label: 'Re (subject)', type: 'text', default: 'Upcoming Maintenance Window' },
                { key: 'body', label: 'Body', type: 'paragraph', default: 'A scheduled maintenance window will take place this weekend to apply outstanding security patches across the estate. Expect brief service interruptions between 22:00 and 02:00.' }
            ],
            preview: function (v, theme) {
                function row(label, val) {
                    return '<tr><td style="padding:5px 0;width:90px;font-size:12px;font-weight:700;color:#64748B;text-transform:uppercase;letter-spacing:.5px;vertical-align:top;">' + pdEsc(label) + '</td><td style="padding:5px 0;font-size:13.5px;color:#0F172A;font-weight:600;">' + pdEsc(val) + '</td></tr>';
                }
                var inner = '<div style="padding:60px 68px;">' +
                    '<h1 style="margin:0 0 26px;font-size:26px;font-weight:800;color:#0B1220;letter-spacing:1px;">MEMORANDUM</h1>' +
                    '<table style="border-collapse:collapse;margin-bottom:20px;">' + row('To', v.to) + row('From', v.from) + row('Date', v.date) + row('Re', v.subject) + '</table>' +
                    '<div style="border-top:2px solid ' + theme.accent + ';margin-bottom:20px;"></div>' +
                    '<p style="font-size:13.5px;line-height:1.7;color:#334155;white-space:pre-line;">' + pdEsc(v.body) + '</p></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                function row(label, val) {
                    return new docx.Paragraph({ children: [new docx.TextRun({ text: label.toUpperCase() + ':  ', bold: true, size: 18, color: '64748B' }), new docx.TextRun({ text: val, bold: true, size: 20, color: '0B1220' })], spacing: { after: 100 } });
                }
                var paras = [
                    new docx.Paragraph({ children: [new docx.TextRun({ text: 'MEMORANDUM', bold: true, size: 34, color: '0B1220' })], spacing: { after: 280 } }),
                    row('To', v.to), row('From', v.from), row('Date', v.date), row('Re', v.subject),
                    new docx.Paragraph({ shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: accent }, children: [new docx.TextRun({ text: ' ', size: 2 })], spacing: { before: 160, after: 260 } })
                ];
                v.body.split('\n').filter(Boolean).forEach(function (l) {
                    paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: l, size: 22, color: '334155' })], spacing: { after: 160 } }));
                });
                return paras;
            }
        },

        {
            id: 'policy-document',
            type: 'docx',
            kind: 'light',
            name: 'Policy Document',
            description: 'Formal numbered-section policy or SOP.',
            thumb: [{ x: 10, y: 10, w: 60, h: 8, accent: true }, { x: 10, y: 26, w: 20, h: 5 }, { x: 10, y: 38, w: 20, h: 5 }, { x: 20, y: 44, w: 70, h: 4 }, { x: 10, y: 56, w: 20, h: 5 }, { x: 20, y: 62, w: 70, h: 4 }],
            fields: [
                { key: 'title', label: 'Title', type: 'text', default: 'Password Policy' },
                { key: 'policyId', label: 'Policy ID', type: 'text', default: 'POL-SEC-004' },
                { key: 'effectiveDate', label: 'Effective date', type: 'text', default: '[DATE]' },
                { key: 'owner', label: 'Owner', type: 'text', default: 'IT Security' },
                { key: 'sections', label: 'Sections', type: 'lines', parts: ['heading', 'body'], hint: 'One per line: Section Heading | Section Body', default: ['Purpose|Defines minimum password requirements for all InfraVault accounts.', 'Scope|Applies to all employees, contractors and service accounts.', 'Requirements|Passwords must be at least 12 characters and rotated every 90 days.', 'Enforcement|Non-compliance may result in account suspension.'] }
            ],
            preview: function (v, theme) {
                var sections = v.sections.map(function (s, i) {
                    return '<div style="margin-bottom:18px;"><div style="font-size:14px;font-weight:700;color:#0B1220;margin-bottom:6px;">' + (i + 1) + '. ' + pdEsc(s.heading) + '</div>' +
                        '<div style="font-size:12.5px;line-height:1.6;color:#334155;padding-left:18px;">' + pdEsc(s.body) + '</div></div>';
                }).join('');
                var inner = '<div style="padding:56px 64px;">' +
                    '<div style="display:flex;justify-content:space-between;align-items:flex-start;border-bottom:2px solid ' + theme.accent + ';padding-bottom:16px;margin-bottom:22px;">' +
                        '<div><div style="font-size:11px;font-weight:700;letter-spacing:1.5px;color:' + theme.accent + ';text-transform:uppercase;">Policy Document</div>' +
                        '<div style="font-size:24px;font-weight:800;color:#0B1220;margin-top:6px;">' + pdEsc(v.title) + '</div></div>' +
                        '<div style="text-align:right;font-size:11px;color:#64748B;line-height:1.6;"><div>' + pdEsc(v.policyId) + '</div><div>' + pdEsc(v.effectiveDate) + '</div><div>' + pdEsc(v.owner) + '</div></div></div>' +
                    sections + '</div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [
                    new docx.Paragraph({ children: [new docx.TextRun({ text: 'POLICY DOCUMENT', bold: true, size: 18, color: accent })], spacing: { after: 80 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.title, bold: true, size: 32, color: '0B1220' })], spacing: { after: 80 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.policyId + '   ·   ' + v.effectiveDate + '   ·   ' + v.owner, size: 18, color: '64748B' })], spacing: { after: 320 } })
                ];
                v.sections.forEach(function (s, i) {
                    paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: (i + 1) + '. ' + s.heading, bold: true, size: 22, color: '0B1220' })], spacing: { before: 160, after: 80 } }));
                    paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: s.body, size: 20, color: '334155' })], indent: { left: 360 }, spacing: { after: 80 } }));
                });
                return paras;
            }
        },

        {
            id: 'invoice-cost-summary',
            type: 'docx',
            kind: 'light',
            name: 'Cost Summary',
            description: 'Itemized cost breakdown with a total, invoice-style.',
            thumb: [{ x: 10, y: 10, w: 50, h: 9, accent: true }, { x: 10, y: 30, w: 80, h: 4 }, { x: 10, y: 38, w: 80, h: 4 }, { x: 10, y: 46, w: 80, h: 4 }, { x: 55, y: 62, w: 35, h: 10 }],
            fields: [
                { key: 'title', label: 'Title', type: 'text', default: 'Cost Summary' },
                { key: 'billTo', label: 'Bill to', type: 'text', default: '[ORGANIZATION]' },
                { key: 'invoiceNo', label: 'Reference no.', type: 'text', default: 'INV-2026-0142' },
                { key: 'date', label: 'Date', type: 'text', default: '[DATE]' },
                { key: 'items', label: 'Line items', type: 'lines', parts: ['description', 'amount'], hint: 'One per line: Description | Amount', default: ['Annual platform hosting|12,000', 'Support & maintenance|4,500', 'Onboarding & training|2,000'] },
                { key: 'total', label: 'Total', type: 'text', default: '18,500' }
            ],
            preview: function (v, theme) {
                var rows = v.items.map(function (it) {
                    return '<tr><td style="padding:10px 0;border-bottom:1px solid #E5E7EB;font-size:13px;color:#1E293B;">' + pdEsc(it.description) + '</td>' +
                        '<td style="padding:10px 0;border-bottom:1px solid #E5E7EB;font-size:13px;color:#334155;text-align:right;">' + pdEsc(it.amount) + '</td></tr>';
                }).join('');
                var inner = '<div style="padding:60px 68px;">' +
                    '<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:36px;">' +
                        '<div><div style="font-size:11px;font-weight:700;letter-spacing:2px;color:' + theme.accent + ';text-transform:uppercase;">Cost Summary</div>' +
                        '<div style="font-size:26px;font-weight:800;color:#0B1220;margin-top:6px;">' + pdEsc(v.title) + '</div></div>' +
                        '<div style="text-align:right;font-size:12px;color:#64748B;line-height:1.7;"><div><strong style="color:#334155;">' + pdEsc(v.invoiceNo) + '</strong></div><div>' + pdEsc(v.date) + '</div></div></div>' +
                    '<div style="font-size:11px;font-weight:700;letter-spacing:1px;color:#94A3B8;text-transform:uppercase;margin-bottom:6px;">Bill To</div>' +
                    '<div style="font-size:13.5px;color:#0F172A;font-weight:600;margin-bottom:28px;">' + pdEsc(v.billTo) + '</div>' +
                    '<table style="width:100%;border-collapse:collapse;"><thead><tr><th style="text-align:left;font-size:11px;color:#94A3B8;padding-bottom:8px;border-bottom:2px solid #0F172A;">Description</th><th style="text-align:right;font-size:11px;color:#94A3B8;padding-bottom:8px;border-bottom:2px solid #0F172A;">Amount</th></tr></thead><tbody>' + rows + '</tbody></table>' +
                    '<div style="display:flex;justify-content:flex-end;margin-top:18px;"><div style="background:' + theme.accent + ';color:#fff;padding:12px 22px;border-radius:8px;font-size:15px;font-weight:800;">Total &nbsp; ' + pdEsc(v.total) + '</div></div></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [
                    new docx.Paragraph({ children: [new docx.TextRun({ text: 'COST SUMMARY', bold: true, size: 18, color: accent })], spacing: { after: 80 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.title, bold: true, size: 30, color: '0B1220' })], spacing: { after: 60 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.invoiceNo + '   ·   ' + v.date, size: 18, color: '64748B' })], spacing: { after: 220 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: 'BILL TO', bold: true, size: 16, color: '94A3B8' })], spacing: { after: 60 } }),
                    new docx.Paragraph({ children: [new docx.TextRun({ text: v.billTo, bold: true, size: 22, color: '0F172A' })], spacing: { after: 280 } })
                ];
                var headerRow = new docx.TableRow({
                    children: ['Description', 'Amount'].map(function (h, i) {
                        return new docx.TableCell({
                            shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: '0F172A' },
                            children: [new docx.Paragraph({ alignment: i === 1 ? docx.AlignmentType.RIGHT : docx.AlignmentType.LEFT, children: [new docx.TextRun({ text: h, bold: true, size: 18, color: 'FFFFFF' })] })]
                        });
                    })
                });
                var rows = v.items.map(function (it) {
                    return new docx.TableRow({
                        children: [
                            new docx.TableCell({ children: [new docx.Paragraph({ children: [new docx.TextRun({ text: it.description, size: 20, color: '1E293B' })] })] }),
                            new docx.TableCell({ children: [new docx.Paragraph({ alignment: docx.AlignmentType.RIGHT, children: [new docx.TextRun({ text: it.amount, size: 20, color: '334155' })] })] })
                        ]
                    });
                });
                paras.push(new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows: [headerRow].concat(rows) }));
                paras.push(new docx.Paragraph({
                    alignment: docx.AlignmentType.RIGHT, spacing: { before: 280 }, children: [
                        new docx.TextRun({ text: 'TOTAL   ', bold: true, size: 22, color: '64748B' }),
                        new docx.TextRun({ text: v.total, bold: true, size: 28, color: accent })
                    ]
                }));
                return paras;
            }
        },

        {
            id: 'data-table-doc',
            type: 'docx',
            kind: 'light',
            name: 'Data Table',
            description: 'A heading, an intro paragraph, and a real Word table.',
            thumb: [{ x: 10, y: 10, w: 60, h: 8, accent: true }, { x: 10, y: 26, w: 80, h: 5 }, { x: 10, y: 40, w: 80, h: 8, accent: true }, { x: 10, y: 52, w: 80, h: 7 }, { x: 10, y: 63, w: 80, h: 7 }],
            fields: [
                { key: 'heading', label: 'Heading', type: 'text', default: 'Server Inventory Snapshot' },
                { key: 'intro', label: 'Intro (optional)', type: 'paragraph', default: 'The table below reflects the current state of all HCL-managed hosts as of this report.' },
                { key: 'columns', label: 'Columns', type: 'csv', hint: 'Comma-separated column headers', default: 'Server,Environment,Owner,Status' },
                { key: 'rows', label: 'Rows', type: 'table-rows', hint: 'One row per line, cells separated by |', default: ['srv-web01|Production|IT Ops|Healthy', 'srv-db02|Production|IT Ops|Healthy', 'srv-app03|DR|IT Ops|Standby'] }
            ],
            preview: function (v, theme) {
                var head = v.columns.map(function (c) { return '<th style="text-align:left;padding:8px 10px;background:' + theme.accent + ';color:#fff;font-size:11px;font-weight:700;">' + pdEsc(c) + '</th>'; }).join('');
                var body = v.rows.map(function (r, i) {
                    var cells = r.map(function (c) { return '<td style="padding:7px 10px;font-size:11.5px;color:#1E293B;border-bottom:1px solid #E5E7EB;">' + pdEsc(c) + '</td>'; }).join('');
                    return '<tr style="background:' + (i % 2 === 0 ? '#F8FAFC' : '#FFFFFF') + ';">' + cells + '</tr>';
                }).join('');
                var inner = '<div style="padding:56px 64px;">' +
                    '<h1 style="margin:0 0 18px;font-size:26px;font-weight:800;color:#0B1220;">' + pdEsc(v.heading) + '</h1>' +
                    (v.intro ? '<p style="font-size:12.5px;line-height:1.6;color:#334155;white-space:pre-line;margin:0 0 20px;">' + pdEsc(v.intro) + '</p>' : '') +
                    '<table style="width:100%;border-collapse:collapse;"><thead><tr>' + head + '</tr></thead><tbody>' + body + '</tbody></table></div>';
                return pdDocShell(theme, inner);
            },
            buildDocx: function (v, theme) {
                var accent = pdHex(theme.accent);
                var paras = [new docx.Paragraph({ children: [new docx.TextRun({ text: v.heading, bold: true, size: 30, color: '0B1220' })], spacing: { after: 160 } })];
                if (v.intro) {
                    v.intro.split('\n').filter(Boolean).forEach(function (l) {
                        paras.push(new docx.Paragraph({ children: [new docx.TextRun({ text: l, size: 22, color: '334155' })], spacing: { after: 200 } }));
                    });
                }
                var headerRow = new docx.TableRow({
                    children: v.columns.map(function (c) {
                        return new docx.TableCell({ shading: { val: docx.ShadingType.CLEAR, color: 'auto', fill: accent }, children: [new docx.Paragraph({ children: [new docx.TextRun({ text: c, bold: true, size: 18, color: 'FFFFFF' })] })] });
                    })
                });
                var rows = v.rows.map(function (r) {
                    return new docx.TableRow({
                        children: r.map(function (cell) {
                            return new docx.TableCell({ children: [new docx.Paragraph({ children: [new docx.TextRun({ text: cell, size: 20, color: '1E293B' })] })] });
                        })
                    });
                });
                paras.push(new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows: [headerRow].concat(rows) }));
                return paras;
            }
        }
    ];

    /* ---------------------------------------------------------------- */
    /* App state + rendering                                             */
    /* ---------------------------------------------------------------- */

    /*
     * A "deck" is the ordered list of slides (pptx tab) or pages (docx tab)
     * the user has assembled. Each deck item is its own instance -- same
     * template can appear more than once with different content -- so a
     * template card in the gallery below is something you ADD, not select.
     */
    /*
     * Header/footer model: each side (header, footer) holds an ordered list
     * of independent ELEMENTS -- any mix of text and image items, each with
     * its own position (left/center/right) and size. "Size" is always in
     * points, for both text (font size) and images (rendered height) --
     * one unit, so a slider means the same thing either way. An image
     * element also carries `aspect` (naturalWidth/naturalHeight, captured
     * once when the file is chosen) so it can be sized in pptx/docx export
     * without distorting it.
     */
    var PD_MAX_HF_ELEMENTS = 6;
    var PD_HF_TEXT_SIZE_DEFAULT = 9;
    var PD_HF_IMAGE_SIZE_DEFAULT = 28;

    function newHfElement(type) {
        return {
            id: newUid(),
            type: type,
            value: '',
            position: 'right',
            size: type === 'image' ? PD_HF_IMAGE_SIZE_DEFAULT : PD_HF_TEXT_SIZE_DEFAULT,
            aspect: 3
        };
    }

    function emptyHfSide() {
        return { elements: [] };
    }

    function emptyHeaderFooter() {
        return {
            header: emptyHfSide(),
            footer: emptyHfSide(),
            watermark: { text: '', image: '', opacity: 12 }
        };
    }

    function pdNormalizePosition(p) {
        return (p === 'left' || p === 'center') ? p : 'right';
    }

    /**
     * Builds a valid header/footer object from whatever a loaded deck
     * carries -- including the single-text/multi-image-only shape from an
     * earlier version of this feature, migrated into one element per piece
     * of content so an older save still opens correctly.
     */
    function pdNormalizeHeaderFooter(raw) {
        var hf = emptyHeaderFooter();
        if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return hf;

        ['header', 'footer'].forEach(function (side) {
            var s = raw[side];
            if (!s || typeof s !== 'object') return;

            if (Array.isArray(s.elements)) {
                hf[side].elements = s.elements.slice(0, PD_MAX_HF_ELEMENTS).map(function (el) {
                    return {
                        id: (typeof el.id === 'string' && el.id) ? el.id : newUid(),
                        type: el.type === 'image' ? 'image' : 'text',
                        value: typeof el.value === 'string' ? el.value : '',
                        position: pdNormalizePosition(el.position),
                        size: (typeof el.size === 'number' && el.size > 0) ? el.size : (el.type === 'image' ? PD_HF_IMAGE_SIZE_DEFAULT : PD_HF_TEXT_SIZE_DEFAULT),
                        aspect: (typeof el.aspect === 'number' && el.aspect > 0) ? el.aspect : 3
                    };
                });
            } else {
                // Older shape: one shared position, one text, an images[] array.
                var pos = pdNormalizePosition(s.position);
                var migrated = [];
                if (typeof s.text === 'string' && s.text) {
                    var textEl = newHfElement('text');
                    textEl.value = s.text;
                    textEl.position = pos;
                    migrated.push(textEl);
                }
                if (Array.isArray(s.images)) {
                    s.images.slice(0, PD_MAX_HF_ELEMENTS).forEach(function (src) {
                        if (typeof src !== 'string' || !src) return;
                        var imgEl = newHfElement('image');
                        imgEl.value = src;
                        imgEl.position = pos;
                        migrated.push(imgEl);
                    });
                }
                hf[side].elements = migrated.slice(0, PD_MAX_HF_ELEMENTS);
            }
        });

        if (raw.watermark && typeof raw.watermark === 'object') {
            hf.watermark.text = typeof raw.watermark.text === 'string' ? raw.watermark.text : '';
            hf.watermark.image = typeof raw.watermark.image === 'string' ? raw.watermark.image : '';
            hf.watermark.opacity = (typeof raw.watermark.opacity === 'number' && raw.watermark.opacity >= 5 && raw.watermark.opacity <= 40) ? raw.watermark.opacity : 12;
        }

        return hf;
    }

    /*
     * "Extra elements": free text boxes / images a slide or page can carry
     * on top of whatever its template already draws -- e.g. a callout, a
     * partner logo, a note in the corner. Unlike header/footer (one shared
     * config for the whole deck), extras belong to one deck item.
     *
     * For a pptx slide, an extra is placed anywhere via a 3x3 grid
     * (hAlign x vAlign) and exported as a real, absolutely-positioned
     * PowerPoint text box or image -- preview and export always match,
     * since PptxGenJS supports true absolute placement natively.
     *
     * Word has no equivalent of free placement on a page, so a docx extra
     * only takes hAlign (paragraph alignment) and is exported as a plain
     * paragraph/image appended after the page's own content -- the preview
     * mirrors that by always anchoring docx extras near the foot of the
     * page mockup, stacked in the order they were added, rather than
     * pretending to a floating position Word can't actually give it.
     */
    var PD_MAX_EXTRAS = 6;

    function newExtraElement(type) {
        return {
            id: newUid(),
            type: type,
            value: '',
            hAlign: 'center',
            vAlign: 'middle',
            size: type === 'image' ? 2 : 14,
            aspect: 1.5
        };
    }

    function pdNormalizeExtras(raw) {
        if (!Array.isArray(raw)) return [];
        return raw.slice(0, PD_MAX_EXTRAS).map(function (el) {
            return {
                id: (typeof el.id === 'string' && el.id) ? el.id : newUid(),
                type: el.type === 'image' ? 'image' : 'text',
                value: typeof el.value === 'string' ? el.value : '',
                hAlign: (el.hAlign === 'left' || el.hAlign === 'right') ? el.hAlign : 'center',
                vAlign: (el.vAlign === 'top' || el.vAlign === 'bottom') ? el.vAlign : 'middle',
                size: (typeof el.size === 'number' && el.size > 0) ? el.size : (el.type === 'image' ? 2 : 14),
                aspect: (typeof el.aspect === 'number' && el.aspect > 0) ? el.aspect : 1.5
            };
        });
    }

    var state = {
        tab: 'pptx',
        deck: { pptx: [], docx: [] },
        selected: { pptx: null, docx: null },
        name: { pptx: 'Untitled Presentation', docx: 'Untitled Document' },
        headerFooter: { pptx: emptyHeaderFooter(), docx: emptyHeaderFooter() },
        formMode: 'item',
        themeId: PD_THEMES[0].id,
        nextUid: 1,
        loadedDeckId: { pptx: null, docx: null },
        restored: { pptx: false, docx: false },
        galleryPreview: { pptx: null, docx: null }
    };

    function getTheme() {
        for (var i = 0; i < PD_THEMES.length; i++) { if (PD_THEMES[i].id === state.themeId) return PD_THEMES[i]; }
        return PD_THEMES[0];
    }

    function getTemplate(id) {
        for (var i = 0; i < PD_TEMPLATES.length; i++) { if (PD_TEMPLATES[i].id === id) return PD_TEMPLATES[i]; }
        return null;
    }

    function newUid() {
        return 'i' + (state.nextUid++);
    }

    function defaultRawFor(t) {
        var raw = {};
        t.fields.forEach(function (f) {
            raw[f.key] = Array.isArray(f.default) ? f.default.join('\n') : (f.default || '');
        });
        return raw;
    }

    function parseValues(t, raw) {
        var v = {};
        t.fields.forEach(function (f) {
            var r = raw[f.key] || '';
            if (f.type === 'lines') {
                v[f.key] = f.parts ? pdParts(r, f.parts) : pdLines(r);
            } else if (f.type === 'csv') {
                v[f.key] = String(r).split(',').map(function (s) { return s.trim(); }).filter(Boolean);
            } else if (f.type === 'table-rows') {
                v[f.key] = pdLines(r).map(function (line) { return line.split('|').map(function (c) { return c.trim(); }); });
            } else {
                v[f.key] = r;
            }
        });
        return v;
    }

    function currentDeck() {
        return state.deck[state.tab];
    }

    function findItem(uid) {
        var deck = currentDeck();
        for (var i = 0; i < deck.length; i++) { if (deck[i].uid === uid) return deck[i]; }
        return null;
    }

    function findIndexByUid(deck, uid) {
        for (var i = 0; i < deck.length; i++) { if (deck[i].uid === uid) return i; }
        return -1;
    }

    /* ---------------------------------------------------------------- */
    /* Deck actions                                                      */
    /* ---------------------------------------------------------------- */

    function addToDeck(templateId) {
        var t = getTemplate(templateId);
        if (!t) return;
        var item = { uid: newUid(), templateId: templateId, raw: defaultRawFor(t), extras: [] };
        currentDeck().push(item);
        state.selected[state.tab] = item.uid;
        state.galleryPreview[state.tab] = null;
        renderDeckList();
        renderGallery();
        renderForm();
        renderPreview();
    }

    /** Shows a template's default content in the stage without adding it to the deck. */
    function previewTemplate(templateId) {
        state.galleryPreview[state.tab] = templateId;
        renderGallery();
        renderForm();
        renderPreview();
    }

    function removeFromDeck(uid) {
        var deck = currentDeck();
        var idx = findIndexByUid(deck, uid);
        if (idx === -1) return;
        deck.splice(idx, 1);
        if (state.selected[state.tab] === uid) {
            var next = deck[idx] || deck[idx - 1] || null;
            state.selected[state.tab] = next ? next.uid : null;
        }
        renderDeckList();
        renderForm();
        renderPreview();
    }

    function duplicateInDeck(uid) {
        var deck = currentDeck();
        var idx = findIndexByUid(deck, uid);
        if (idx === -1) return;
        var orig = deck[idx];
        var raw = {};
        for (var k in orig.raw) { if (Object.prototype.hasOwnProperty.call(orig.raw, k)) raw[k] = orig.raw[k]; }
        var extras = (orig.extras || []).map(function (el) {
            var copyEl = {};
            for (var ek in el) { if (Object.prototype.hasOwnProperty.call(el, ek)) copyEl[ek] = el[ek]; }
            copyEl.id = newUid();
            return copyEl;
        });
        var copy = { uid: newUid(), templateId: orig.templateId, raw: raw, extras: extras };
        deck.splice(idx + 1, 0, copy);
        state.selected[state.tab] = copy.uid;
        renderDeckList();
        renderForm();
        renderPreview();
    }

    function moveInDeck(uid, dir) {
        var deck = currentDeck();
        var idx = findIndexByUid(deck, uid);
        var newIdx = idx + dir;
        if (idx === -1 || newIdx < 0 || newIdx >= deck.length) return;
        var tmp = deck[idx];
        deck[idx] = deck[newIdx];
        deck[newIdx] = tmp;
        renderDeckList();
    }

    function selectItem(uid) {
        state.selected[state.tab] = uid;
        state.galleryPreview[state.tab] = null;
        renderDeckList();
        renderGallery();
        renderForm();
        renderPreview();
    }

    /* ---------------------------------------------------------------- */
    /* Rendering                                                         */
    /* ---------------------------------------------------------------- */

    function renderTabs() {
        document.querySelectorAll('.pd-tab').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-tab') === state.tab);
        });
    }

    function renderSwatches() {
        var wrap = document.getElementById('pdSwatches');
        if (!wrap) return;
        var theme = getTheme();
        wrap.innerHTML = PD_THEMES.map(function (th) {
            return '<button type="button" class="pd-swatch' + (th.id === theme.id ? ' active' : '') + '" data-id="' + th.id + '" style="background:' + th.accent + ';" title="' + pdEsc(th.name) + '"></button>';
        }).join('');
        wrap.querySelectorAll('.pd-swatch').forEach(function (btn) {
            btn.addEventListener('click', function () {
                state.themeId = btn.getAttribute('data-id');
                renderSwatches();
                renderGallery();
                renderPreview();
            });
        });
    }

    function renderGallery() {
        var list = document.getElementById('pdGalleryList');
        if (!list) return;
        var theme = getTheme();
        var items = PD_TEMPLATES.filter(function (t) { return t.type === state.tab; });
        list.innerHTML = items.map(function (t) {
            var bars = (t.thumb || []).map(function (r) {
                var color = r.accent ? theme.accent : (t.kind === 'dark' ? 'rgba(255,255,255,.55)' : '#CBD5E1');
                return '<span class="bar" style="left:' + r.x + '%;top:' + r.y + '%;width:' + r.w + '%;height:' + r.h + '%;background:' + color + ';"></span>';
            }).join('');
            var previewing = t.id === state.galleryPreview[state.tab];
            return '<div class="pd-card' + (previewing ? ' previewing' : '') + '" data-id="' + t.id + '" title="Click to preview">' +
                '<span class="pd-card-thumb ' + t.kind + '">' + bars + '</span>' +
                '<span class="pd-card-text"><span class="pd-card-label">' + pdEsc(t.name) + '</span><br><span class="pd-card-cat">' + (t.type === 'pptx' ? 'Slide' : 'Page') + '</span></span>' +
                '<button type="button" class="pd-card-add" data-id="' + t.id + '" title="Add to your ' + (t.type === 'pptx' ? 'presentation' : 'document') + '">+</button>' +
                '</div>';
        }).join('');
        list.querySelectorAll('.pd-card').forEach(function (card) {
            card.addEventListener('click', function () { previewTemplate(card.getAttribute('data-id')); });
        });
        list.querySelectorAll('.pd-card-add').forEach(function (btn) {
            btn.addEventListener('click', function (e) {
                e.stopPropagation();
                addToDeck(btn.getAttribute('data-id'));
            });
        });
    }

    function renderDeckList() {
        var list = document.getElementById('pdDeckList');
        var countEl = document.getElementById('pdDeckCount');
        if (!list) return;
        var deck = currentDeck();
        if (countEl) countEl.textContent = String(deck.length);

        if (!deck.length) {
            list.innerHTML = '<div class="pd-empty-small">No ' + (state.tab === 'pptx' ? 'slides' : 'pages') + ' yet &mdash; add one from the templates below.</div>';
            return;
        }

        list.innerHTML = deck.map(function (item, i) {
            var t = getTemplate(item.templateId);
            var active = item.uid === state.selected[state.tab];
            return '<div class="pd-deck-item' + (active ? ' active' : '') + '" data-uid="' + item.uid + '">' +
                '<span class="pd-deck-num">' + (i + 1) + '</span>' +
                '<span class="pd-deck-label" data-action="select">' + pdEsc(t ? t.name : 'Unknown') + '</span>' +
                '<span class="pd-deck-actions">' +
                    '<button type="button" data-action="up" title="Move up">&#9650;</button>' +
                    '<button type="button" data-action="down" title="Move down">&#9660;</button>' +
                    '<button type="button" data-action="dup" title="Duplicate">&#10697;</button>' +
                    '<button type="button" data-action="remove" title="Remove">&times;</button>' +
                '</span>' +
                '</div>';
        }).join('');

        list.querySelectorAll('.pd-deck-item').forEach(function (el) {
            var uid = el.getAttribute('data-uid');
            el.querySelector('[data-action="select"]').addEventListener('click', function () { selectItem(uid); });
            el.querySelector('[data-action="up"]').addEventListener('click', function (e) { e.stopPropagation(); moveInDeck(uid, -1); });
            el.querySelector('[data-action="down"]').addEventListener('click', function (e) { e.stopPropagation(); moveInDeck(uid, 1); });
            el.querySelector('[data-action="dup"]').addEventListener('click', function (e) { e.stopPropagation(); duplicateInDeck(uid); });
            el.querySelector('[data-action="remove"]').addEventListener('click', function (e) { e.stopPropagation(); removeFromDeck(uid); });
        });
    }

    /** One field's markup for a text/paragraph/lines/image field. */
    function pdFieldHtml(f, val) {
        var hint = f.hint ? '<span class="hint">' + pdEsc(f.hint) + '</span>' : '';
        if (f.type === 'text' || f.type === 'csv') {
            return '<div class="pd-field"><label>' + pdEsc(f.label) + '</label><input type="text" data-key="' + f.key + '" value="' + pdEsc(val) + '">' + hint + '</div>';
        }
        if (f.type === 'image') {
            return '<div class="pd-field"><label>' + pdEsc(f.label) + '</label>' +
                '<div class="pd-image-field" data-image-key="' + f.key + '">' +
                    (val ? '<img src="' + val + '" class="pd-image-preview">' : '<div class="pd-image-empty">No image</div>') +
                    '<div class="pd-image-actions">' +
                        '<label class="pd-btn pd-btn-small">Choose&hellip;<input type="file" accept="image/*" data-image-input="' + f.key + '" hidden></label>' +
                        (val ? '<button type="button" class="pd-btn pd-btn-small" data-image-clear="' + f.key + '">Remove</button>' : '') +
                    '</div>' +
                '</div>' + hint + '</div>';
        }
        return '<div class="pd-field"><label>' + pdEsc(f.label) + '</label><textarea data-key="' + f.key + '">' + pdEsc(val) + '</textarea>' + hint + '</div>';
    }

    /**
     * Wires the plain data-key inputs plus any image fields inside `panel`.
     * Image changes get their own callback (defaulting to onChange) since
     * they need the form re-rendered to show the new thumbnail -- text
     * input shouldn't re-render on every keystroke, an image pick is a
     * discrete event so re-rendering is fine there.
     */
    function pdWireFields(panel, getRaw, onChange, onImageChange) {
        onImageChange = onImageChange || onChange;
        panel.querySelectorAll('[data-key]').forEach(function (el) {
            el.addEventListener('input', function () {
                getRaw()[this.getAttribute('data-key')] = this.value;
                onChange();
            });
        });
        panel.querySelectorAll('[data-image-input]').forEach(function (el) {
            el.addEventListener('change', function () {
                var file = this.files && this.files[0];
                var key = this.getAttribute('data-image-input');
                if (!file) return;
                pdReadImageFile(file, 900, function (dataUri) {
                    if (!dataUri) { alert('Could not read that image.'); return; }
                    getRaw()[key] = dataUri;
                    onImageChange();
                });
            });
        });
        panel.querySelectorAll('[data-image-clear]').forEach(function (el) {
            el.addEventListener('click', function () {
                getRaw()[this.getAttribute('data-image-clear')] = '';
                onImageChange();
            });
        });
    }

    function pdExtraById(item, id) {
        var arr = item.extras || [];
        for (var i = 0; i < arr.length; i++) { if (arr[i].id === id) return arr[i]; }
        return null;
    }

    /** One extra element's row: its content, an hAlign toggle (and, for pptx only, a vAlign toggle), a size slider, and remove. */
    function pdExtraRowHtml(el, kind) {
        var isImage = el.type === 'image';
        var body = isImage
            ? (el.value ? '<img src="' + el.value + '" class="pd-hf-el-thumb">' : '<div class="pd-hf-el-thumb pd-hf-el-thumb-empty">Image</div>')
            : '<textarea class="pd-extra-textarea" placeholder="Text" rows="2" data-extra="text" data-id="' + el.id + '">' + pdEsc(el.value) + '</textarea>';
        var chooseBtn = isImage
            ? '<label class="pd-btn pd-btn-small" title="Choose image">Choose&hellip;<input type="file" accept="image/*" hidden data-extra="image" data-id="' + el.id + '"></label>'
            : '';

        var hButtons = ['left', 'center', 'right'].map(function (p) {
            return '<button type="button" class="pd-pos-btn' + (p === el.hAlign ? ' active' : '') + '" data-extra="halign" data-id="' + el.id + '" data-val="' + p + '">' + p.charAt(0).toUpperCase() + p.slice(1) + '</button>';
        }).join('');

        var vRow = '';
        if (kind === 'pptx') {
            var vButtons = ['top', 'middle', 'bottom'].map(function (p) {
                return '<button type="button" class="pd-pos-btn' + (p === el.vAlign ? ' active' : '') + '" data-extra="valign" data-id="' + el.id + '" data-val="' + p + '">' + p.charAt(0).toUpperCase() + p.slice(1) + '</button>';
            }).join('');
            vRow = '<div class="pd-pos-toggle pd-pos-toggle-small" style="margin-top:6px;">' + vButtons + '</div>';
        }

        var sizeMin = isImage ? 1 : 9, sizeMax = isImage ? 4.5 : 36, sizeStep = isImage ? 0.1 : 1;
        var sizeUnit = isImage ? 'in tall' : 'pt';

        return '<div class="pd-hf-element">' +
            '<div class="pd-hf-el-top">' + body + chooseBtn +
                '<button type="button" class="pd-hf-el-remove" data-extra="remove" data-id="' + el.id + '" title="Remove">&times;</button>' +
            '</div>' +
            '<div class="pd-pos-toggle pd-pos-toggle-small">' + hButtons + '</div>' +
            vRow +
            '<div class="pd-hf-el-bottom">' +
                '<div class="pd-hf-el-size">' +
                    '<input type="range" min="' + sizeMin + '" max="' + sizeMax + '" step="' + sizeStep + '" value="' + el.size + '" data-extra="size" data-id="' + el.id + '">' +
                    '<span class="pd-range-value">' + el.size + ' ' + sizeUnit + '</span>' +
                '</div>' +
            '</div>' +
        '</div>';
    }

    function pdExtrasSectionHtml(item, kind) {
        var extras = item.extras || [];
        var rows = extras.map(function (el) { return pdExtraRowHtml(el, kind); }).join('');
        var canAddMore = extras.length < PD_MAX_EXTRAS;
        var noun = kind === 'docx' ? 'page' : 'slide';
        var note = kind === 'docx'
            ? 'Added to the end of this page, aligned as chosen.'
            : 'Placed anywhere on this slide, on top of the template.';

        return '<div class="pd-hf-section"><div class="pd-hf-section-title">Extra Elements</div>' +
            '<div class="pd-form-desc">' + note + '</div>' +
            '<div class="pd-hf-elements">' + rows + '</div>' +
            (canAddMore
                ? '<div class="pd-hf-add-row">' +
                    '<button type="button" class="pd-btn pd-btn-small" data-extra="add" data-add-type="text">+ Text</button>' +
                    '<button type="button" class="pd-btn pd-btn-small" data-extra="add" data-add-type="image">+ Image</button>' +
                  '</div>'
                : '<div class="hint">Up to ' + PD_MAX_EXTRAS + ' extra elements per ' + noun + '.</div>') +
            '</div>';
    }

    /** Wires the "Extra Elements" section for one deck item -- add/remove, alignment toggles, size slider, text/image content. */
    function pdWireExtras(panel, item, kind) {
        item.extras = item.extras || [];

        panel.querySelectorAll('[data-extra="add"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                if (item.extras.length >= PD_MAX_EXTRAS) return;
                item.extras.push(newExtraElement(btn.getAttribute('data-add-type')));
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="remove"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var id = btn.getAttribute('data-id');
                item.extras = item.extras.filter(function (e) { return e.id !== id; });
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="halign"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var el = pdExtraById(item, btn.getAttribute('data-id'));
                if (el) el.hAlign = btn.getAttribute('data-val');
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="valign"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var el = pdExtraById(item, btn.getAttribute('data-id'));
                if (el) el.vAlign = btn.getAttribute('data-val');
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="size"]').forEach(function (input) {
            input.addEventListener('input', function () {
                var el = pdExtraById(item, this.getAttribute('data-id'));
                if (!el) return;
                el.size = parseFloat(this.value) || el.size;
                var label = this.parentElement.querySelector('.pd-range-value');
                if (label) label.textContent = el.size + ' ' + (el.type === 'image' ? 'in tall' : 'pt');
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="text"]').forEach(function (ta) {
            ta.addEventListener('input', function () {
                var el = pdExtraById(item, this.getAttribute('data-id'));
                if (el) el.value = this.value;
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-extra="image"]').forEach(function (input) {
            input.addEventListener('change', function () {
                var id = this.getAttribute('data-id');
                var file = this.files && this.files[0];
                if (!file) return;
                pdReadImageFile(file, 700, function (dataUri, w, h) {
                    if (!dataUri) { alert('Could not read that image.'); return; }
                    var el = pdExtraById(item, id);
                    if (el) { el.value = dataUri; el.aspect = (w && h) ? (w / h) : 1.5; }
                    renderForm();
                    renderPreview();
                });
            });
        });
    }

    function renderForm() {
        var panel = document.getElementById('pdForm');
        if (!panel) return;

        document.querySelectorAll('.pd-form-tab').forEach(function (btn) {
            btn.classList.toggle('active', btn.getAttribute('data-form-tab') === state.formMode);
        });

        if (state.formMode === 'headerFooter') {
            renderHeaderFooterForm(panel);
            return;
        }

        var previewId = state.galleryPreview[state.tab];
        if (previewId) {
            var pt = getTemplate(previewId);
            if (pt) {
                panel.innerHTML = '<div class="pd-form-heading">' + pdEsc(pt.name) + '</div>' +
                    '<div class="pd-form-desc">' + pdEsc(pt.description) + '</div>' +
                    '<div class="pd-preview-note">Previewing with example content &mdash; nothing here is saved yet.</div>' +
                    '<button type="button" class="pd-btn pd-btn-primary pd-add-from-preview" style="width:100%;justify-content:center;">+ Add to your ' + (pt.type === 'pptx' ? 'presentation' : 'document') + '</button>';
                var addBtn = panel.querySelector('.pd-add-from-preview');
                if (addBtn) addBtn.addEventListener('click', function () { addToDeck(previewId); });
                return;
            }
        }

        var uid = state.selected[state.tab];
        var item = uid ? findItem(uid) : null;
        var t = item ? getTemplate(item.templateId) : null;
        if (!t || !item) {
            panel.innerHTML = '<div class="pd-empty">Click a template below to preview it, or select a ' + (state.tab === 'pptx' ? 'slide' : 'page') + ' from your deck to edit it.</div>';
            return;
        }
        var html = '<div class="pd-form-heading">' + pdEsc(t.name) + '</div><div class="pd-form-desc">' + pdEsc(t.description) + '</div>';
        t.fields.forEach(function (f) {
            html += pdFieldHtml(f, item.raw[f.key] || '');
        });
        html += pdExtrasSectionHtml(item, t.type);
        panel.innerHTML = html;
        pdWireFields(panel, function () { return item.raw; }, function () {
            renderPreview();
            renderDeckList();
        }, function () {
            renderForm();
            renderPreview();
            renderDeckList();
        });
        pdWireExtras(panel, item, t.type);
    }

    function pdHfElementByIdIn(side, id) {
        for (var i = 0; i < side.elements.length; i++) { if (side.elements[i].id === id) return side.elements[i]; }
        return null;
    }

    /** One header/footer element's row: its content, a position toggle, a size slider, and remove. */
    function pdHfElementRowHtml(sideKey, el) {
        var isImage = el.type === 'image';
        var body = isImage
            ? (el.value ? '<img src="' + el.value + '" class="pd-hf-el-thumb">' : '<div class="pd-hf-el-thumb pd-hf-el-thumb-empty">Image</div>')
            : '<input type="text" class="pd-hf-el-text-input" placeholder="Text" value="' + pdEsc(el.value) + '" data-hf="text" data-side="' + sideKey + '" data-id="' + el.id + '">';
        var chooseBtn = isImage
            ? '<label class="pd-btn pd-btn-small" title="Choose image">Choose&hellip;<input type="file" accept="image/*" hidden data-hf="image" data-side="' + sideKey + '" data-id="' + el.id + '"></label>'
            : '';
        var posButtons = ['left', 'center', 'right'].map(function (p) {
            return '<button type="button" class="pd-pos-btn' + (p === el.position ? ' active' : '') + '" data-hf="pos" data-side="' + sideKey + '" data-id="' + el.id + '" data-pos="' + p + '">' + p.charAt(0).toUpperCase() + p.slice(1) + '</button>';
        }).join('');
        var sizeMin = isImage ? 12 : 6, sizeMax = isImage ? 72 : 24;
        var sizeUnit = isImage ? 'px tall' : 'pt';

        return '<div class="pd-hf-element">' +
            '<div class="pd-hf-el-top">' + body + chooseBtn +
                '<button type="button" class="pd-hf-el-remove" data-hf="remove" data-side="' + sideKey + '" data-id="' + el.id + '" title="Remove">&times;</button>' +
            '</div>' +
            '<div class="pd-hf-el-bottom">' +
                '<div class="pd-pos-toggle pd-pos-toggle-small">' + posButtons + '</div>' +
                '<div class="pd-hf-el-size">' +
                    '<input type="range" min="' + sizeMin + '" max="' + sizeMax + '" value="' + el.size + '" data-hf="size" data-side="' + sideKey + '" data-id="' + el.id + '">' +
                    '<span class="pd-range-value">' + el.size + ' ' + sizeUnit + '</span>' +
                '</div>' +
            '</div>' +
        '</div>';
    }

    function pdHfSideBlockHtml(sideKey, label, side) {
        var rows = side.elements.map(function (el) { return pdHfElementRowHtml(sideKey, el); }).join('');
        var canAddMore = side.elements.length < PD_MAX_HF_ELEMENTS;
        return '<div class="pd-hf-section"><div class="pd-hf-section-title">' + label + '</div>' +
            '<div class="pd-hf-elements">' + rows + '</div>' +
            (canAddMore
                ? '<div class="pd-hf-add-row">' +
                    '<button type="button" class="pd-btn pd-btn-small" data-hf="add" data-side="' + sideKey + '" data-add-type="text">+ Text</button>' +
                    '<button type="button" class="pd-btn pd-btn-small" data-hf="add" data-side="' + sideKey + '" data-add-type="image">+ Image</button>' +
                  '</div>'
                : '<div class="hint">Up to ' + PD_MAX_HF_ELEMENTS + ' items per ' + (sideKey === 'header' ? 'header' : 'footer') + '.</div>') +
            '</div>';
    }

    function renderHeaderFooterForm(panel) {
        var hf = state.headerFooter[state.tab];
        var noun = state.tab === 'pptx' ? 'slide' : 'page';

        var html = '<div class="pd-form-heading">Header, Footer &amp; Watermark</div>' +
            '<div class="pd-form-desc">Add text and images to every ' + noun + '. Each item has its own position and size.</div>' +
            pdHfSideBlockHtml('header', 'Header', hf.header) +
            pdHfSideBlockHtml('footer', 'Footer', hf.footer);

        html += '<div class="pd-hf-section"><div class="pd-hf-section-title">Watermark</div>' +
            '<div class="pd-form-desc">One watermark, centered behind every ' + noun + '. Use text (e.g. "DRAFT") or an image, not both.</div>' +
            '<div class="pd-field"><label>Text</label><input type="text" data-wm-text value="' + pdEsc(hf.watermark.text) + '" placeholder="e.g. DRAFT or CONFIDENTIAL"></div>' +
            pdFieldHtml({ key: 'image', label: 'Image', type: 'image' }, hf.watermark.image) +
            '<div class="pd-field"><label>Opacity <span id="pdWmOpacityValue">' + hf.watermark.opacity + '%</span></label>' +
            '<input type="range" min="5" max="40" step="1" data-wm-opacity value="' + hf.watermark.opacity + '"></div>' +
            '</div>';

        panel.innerHTML = html;

        panel.querySelectorAll('[data-hf="add"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var side = hf[this.getAttribute('data-side')];
                if (side.elements.length >= PD_MAX_HF_ELEMENTS) return;
                side.elements.push(newHfElement(this.getAttribute('data-add-type')));
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-hf="remove"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var side = hf[this.getAttribute('data-side')];
                var id = this.getAttribute('data-id');
                side.elements = side.elements.filter(function (e) { return e.id !== id; });
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-hf="pos"]').forEach(function (btn) {
            btn.addEventListener('click', function () {
                var side = hf[this.getAttribute('data-side')];
                var target = pdHfElementByIdIn(side, this.getAttribute('data-id'));
                if (target) target.position = this.getAttribute('data-pos');
                renderForm();
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-hf="size"]').forEach(function (el) {
            el.addEventListener('input', function () {
                var side = hf[this.getAttribute('data-side')];
                var target = pdHfElementByIdIn(side, this.getAttribute('data-id'));
                if (!target) return;
                target.size = parseInt(this.value, 10) || target.size;
                var label = this.parentElement.querySelector('.pd-range-value');
                if (label) label.textContent = target.size + ' ' + (target.type === 'image' ? 'px tall' : 'pt');
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-hf="text"]').forEach(function (el) {
            el.addEventListener('input', function () {
                var side = hf[this.getAttribute('data-side')];
                var target = pdHfElementByIdIn(side, this.getAttribute('data-id'));
                if (target) target.value = this.value;
                renderPreview();
            });
        });

        panel.querySelectorAll('[data-hf="image"]').forEach(function (el) {
            el.addEventListener('change', function () {
                var side = hf[this.getAttribute('data-side')];
                var id = this.getAttribute('data-id');
                var file = this.files && this.files[0];
                if (!file) return;
                pdReadImageFile(file, 500, function (dataUri, w, h) {
                    if (!dataUri) { alert('Could not read that image.'); return; }
                    var target = pdHfElementByIdIn(side, id);
                    if (target) {
                        target.value = dataUri;
                        target.aspect = (w && h) ? (w / h) : 3;
                    }
                    renderForm();
                    renderPreview();
                });
            });
        });

        var wmText = panel.querySelector('[data-wm-text]');
        if (wmText) wmText.addEventListener('input', function () { hf.watermark.text = this.value; renderPreview(); });

        var wmOpacity = panel.querySelector('[data-wm-opacity]');
        if (wmOpacity) {
            wmOpacity.addEventListener('input', function () {
                hf.watermark.opacity = parseInt(this.value, 10) || 12;
                var label = document.getElementById('pdWmOpacityValue');
                if (label) label.textContent = hf.watermark.opacity + '%';
                renderPreview();
            });
        }

        pdWireFields(panel, function () { return hf.watermark; }, function () { renderPreview(); }, function () {
            renderForm();
            renderPreview();
        });
    }

    function pdFitFrame(frameEl, w, h) {
        if (!frameEl) return;
        var stage = frameEl.querySelector('.pd-frame-stage');
        var inner = frameEl.querySelector('.pd-frame-inner');
        if (!stage || !inner) return;
        var scale = frameEl.clientWidth / w;
        inner.style.width = w + 'px';
        inner.style.height = h + 'px';
        inner.style.transform = 'scale(' + scale + ')';
        stage.style.height = (h * scale) + 'px';
    }

    /** Absolute-position CSS (relative to the frame box) for one hAlign x vAlign combination. */
    function pdExtraOverlayStyle(hAlign, vAlign) {
        var style = 'position:absolute;';
        var tx = 0, ty = 0;
        if (hAlign === 'left') style += 'left:5%;';
        else if (hAlign === 'right') style += 'right:5%;';
        else { style += 'left:50%;'; tx = -50; }
        if (vAlign === 'top') style += 'top:6%;';
        else if (vAlign === 'bottom') style += 'bottom:6%;';
        else { style += 'top:50%;'; ty = -50; }
        if (tx || ty) style += 'transform:translate(' + tx + '%,' + ty + '%);';
        return style;
    }

    /**
     * A deck item's extra text/image elements, as an overlay on top of its
     * template preview. For a pptx slide this mirrors the true absolute
     * placement PptxGenJS gives it on export. Word has no such thing, so a
     * docx page's extras are always anchored near the foot of the page
     * mockup instead (stacked in the order added) -- matching where
     * export actually puts them: appended after the page's own content.
     */
    function pdExtrasOverlayHtml(item, kind) {
        if (!item || !item.extras || !item.extras.length) return '';
        var isDoc = kind === 'docx';
        return item.extras.map(function (el, i) {
            if (!el.value) return '';
            var style;
            if (isDoc) {
                var hCss = el.hAlign === 'left' ? 'left:5%;' : el.hAlign === 'right' ? 'right:5%;' : 'left:50%;transform:translateX(-50%);';
                style = 'position:absolute;bottom:' + (4 + i * 9) + '%;' + hCss;
            } else {
                style = pdExtraOverlayStyle(el.hAlign, el.vAlign);
            }
            style += 'z-index:' + (6 + i) + ';max-width:60%;pointer-events:none;';

            if (el.type === 'image') {
                var hPx = Math.max(20, (el.size || 2) * 96);
                return '<div style="' + style + '"><img src="' + el.value + '" style="height:' + hPx + 'px;max-width:100%;object-fit:contain;"></div>';
            }
            var fpx = (el.size || 14) * (96 / 72);
            return '<div style="' + style + 'font-size:' + fpx + 'px;font-weight:600;color:#0F172A;background:rgba(255,255,255,.9);padding:6px 14px;border-radius:8px;white-space:pre-wrap;text-align:' + el.hAlign + ';">' + pdEsc(el.value) + '</div>';
        }).join('');
    }

    function renderPreview() {
        var stageWrap = document.getElementById('pdStage');
        if (!stageWrap) return;

        var t, v, item = null;
        var previewId = state.galleryPreview[state.tab];
        if (previewId) {
            t = getTemplate(previewId);
            v = t ? parseValues(t, defaultRawFor(t)) : null;
        } else {
            var uid = state.selected[state.tab];
            item = uid ? findItem(uid) : null;
            t = item ? getTemplate(item.templateId) : null;
            v = (t && item) ? parseValues(t, item.raw) : null;
        }

        if (!t || !v) {
            stageWrap.innerHTML = '<div class="pd-empty">' + (currentDeck().length ? 'Select a ' + (state.tab === 'pptx' ? 'slide' : 'page') + ', or click a template below to preview it.' : 'Click a template below to preview it.') + '</div>';
            return;
        }
        var theme = getTheme();
        var isDoc = t.type === 'docx';
        var html = t.preview(v, theme) + pdHeaderFooterOverlayHtml(state.headerFooter[state.tab]) + pdExtrasOverlayHtml(item, t.type);
        stageWrap.innerHTML = '<div class="pd-frame ' + (isDoc ? 'pd-frame-doc' : 'pd-frame-slide') + '" id="pdFrame">' +
            '<div class="pd-frame-stage"><div class="pd-frame-inner">' + html + '</div></div></div>';
        requestAnimationFrame(function () {
            pdFitFrame(document.getElementById('pdFrame'), isDoc ? 794 : 1280, isDoc ? 1123 : 720);
        });
    }

    /** left/center/right -> the matching absolute-position CSS for an overlay badge. */
    function pdHfPositionCss(position) {
        if (position === 'left') return 'left:18px;';
        if (position === 'center') return 'left:50%;transform:translateX(-50%);';
        return 'right:18px;';
    }

    /** Groups a side's elements by their own position, left/center/right. */
    function pdHfGroupsByPosition(side) {
        var groups = { left: [], center: [], right: [] };
        (side && side.elements ? side.elements : []).forEach(function (el) {
            groups[pdNormalizePosition(el.position)].push(el);
        });
        return groups;
    }

    /** One badge per non-empty position group (up to three) for a header/footer side. */
    function pdHfBadgeHtml(side, vertical) {
        if (!side) return '';
        var groups = pdHfGroupsByPosition(side);
        var vRule = vertical === 'top' ? 'top:14px;' : 'bottom:14px;';
        var out = '';

        ['left', 'center', 'right'].forEach(function (pos) {
            var els = groups[pos].filter(function (el) { return el.value; });
            if (!els.length) return;
            var items = els.map(function (el) {
                var px = el.size * (96 / 72);
                if (el.type === 'image') {
                    return '<img src="' + el.value + '" style="height:' + px + 'px;max-width:140px;object-fit:contain;">';
                }
                return '<span style="font-size:' + px + 'px;font-weight:600;color:#F1F5F9;white-space:nowrap;">' + pdEsc(el.value) + '</span>';
            }).join('');
            out += '<div style="position:absolute;' + vRule + pdHfPositionCss(pos) + 'z-index:5;display:flex;align-items:center;gap:7px;background:rgba(15,23,42,.6);backdrop-filter:blur(2px);padding:5px 11px;border-radius:999px;">' + items + '</div>';
        });

        return out;
    }

    function pdWatermarkOverlayHtml(wm) {
        if (!wm || (!wm.text && !wm.image)) return '';
        var opacity = (wm.opacity || 12) / 100;
        if (wm.image) {
            return '<div style="position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;pointer-events:none;opacity:' + opacity + ';">' +
                '<img src="' + wm.image + '" style="max-width:45%;max-height:45%;object-fit:contain;"></div>';
        }
        return '<div style="position:absolute;inset:0;z-index:1;display:flex;align-items:center;justify-content:center;pointer-events:none;overflow:hidden;">' +
            '<span style="font-size:88px;font-weight:800;color:rgba(15,23,42,' + opacity + ');transform:rotate(-30deg);white-space:nowrap;letter-spacing:5px;">' + pdEsc(wm.text) + '</span></div>';
    }

    /**
     * The header/footer/watermark overlay on the preview canvas. Positioned
     * absolutely over whatever the template drew, so it works for every
     * template without each one knowing about it. Export uses the real
     * mechanisms instead (a PowerPoint slide master for pptx, native page
     * headers/footers for docx) -- this is preview-only.
     */
    function pdHeaderFooterOverlayHtml(hf) {
        if (!hf) return '';
        return pdWatermarkOverlayHtml(hf.watermark) + pdHfBadgeHtml(hf.header, 'top') + pdHfBadgeHtml(hf.footer, 'bottom');
    }

    function switchTab(tab) {
        state.tab = tab;
        state.formMode = 'item';
        renderTabs();
        renderGallery();
        renderDeckList();
        renderForm();
        renderPreview();
        var nameInput = document.getElementById('pdDeckName');
        if (nameInput) nameInput.value = state.name[tab];

        if (!state.restored[tab]) {
            state.restored[tab] = true;
            pdApiMostRecent(tab, function (deck) {
                if (deck && !currentDeckFor(tab).length) {
                    applyLoadedDeck(tab, deck);
                }
            });
        }
    }

    function currentDeckFor(tab) {
        return state.deck[tab];
    }

    function pdDocxAlignmentFor(position) {
        if (position === 'left') return docx.AlignmentType.LEFT;
        if (position === 'center') return docx.AlignmentType.CENTER;
        return docx.AlignmentType.RIGHT;
    }

    /** One position-group's elements (already filtered to one side) as a single run list. */
    function pdDocxElementRuns(els) {
        var children = [];
        els.forEach(function (el, i) {
            if (i > 0) children.push(new docx.TextRun({ text: '  ' }));
            if (el.type === 'image') {
                var hPx = Math.round(el.size * (96 / 72));
                var wPx = Math.round(hPx * (el.aspect || 3));
                children.push(new docx.ImageRun({ data: pdDataUriToUint8Array(el.value), transformation: { width: wPx, height: hPx } }));
            } else {
                children.push(new docx.TextRun({ text: el.value, size: el.size * 2, color: '94A3B8' }));
            }
        });
        return children;
    }

    function pdDocxNoBorder() {
        return { style: docx.BorderStyle.NONE, size: 0, color: 'FFFFFF' };
    }

    /**
     * A side (header or footer) as a borderless 3-column table -- the
     * standard Word technique for a header/footer with independent
     * left/center/right zones, which a single Paragraph (one alignment
     * only) can't do. Each cell holds that position's elements, each sized
     * individually. Falls back to one plain left-aligned paragraph if the
     * table-based layout throws (kept deliberately simple, so it is very
     * unlikely to fail even if the table styling API differs slightly).
     */
    function pdDocxSideContent(side) {
        var groups = { left: [], center: [], right: [] };
        (side.elements || []).forEach(function (el) {
            if (!el.value) return;
            groups[el.position === 'left' || el.position === 'center' ? el.position : 'right'].push(el);
        });

        try {
            var cell = function (pos) {
                return new docx.TableCell({
                    width: { size: 33, type: docx.WidthType.PERCENTAGE },
                    borders: { top: pdDocxNoBorder(), bottom: pdDocxNoBorder(), left: pdDocxNoBorder(), right: pdDocxNoBorder() },
                    children: [new docx.Paragraph({ alignment: pdDocxAlignmentFor(pos), children: pdDocxElementRuns(groups[pos]) })]
                });
            };
            return new docx.Table({
                width: { size: 100, type: docx.WidthType.PERCENTAGE },
                borders: { top: pdDocxNoBorder(), bottom: pdDocxNoBorder(), left: pdDocxNoBorder(), right: pdDocxNoBorder(), insideHorizontal: pdDocxNoBorder(), insideVertical: pdDocxNoBorder() },
                rows: [new docx.TableRow({ children: [cell('left'), cell('center'), cell('right')] })]
            });
        } catch (e) {
            console.warn('Falling back to a single-line header/footer layout:', e);
            var allEls = groups.left.concat(groups.center, groups.right);
            return new docx.Paragraph({ children: pdDocxElementRuns(allEls) });
        }
    }

    /**
     * Native Word header/footer (not an overlay) -- appears on every page.
     * The watermark rides in the header too: a real Word watermark IS a
     * floating image in the header positioned relative to the page and set
     * behind the text, which is exactly what's attempted for an image
     * watermark below. If this browser build's docx.js doesn't support the
     * floating/behind-document options the same way, it's caught and
     * skipped rather than failing the whole export. A text watermark can't
     * get the same diagonal WordArt treatment through this library, so it
     * renders as a plain pale line in the header instead -- a reduced-
     * fidelity fallback, not a true page-spanning watermark.
     */
    function pdBuildDocxHeaderFooter(hf) {
        var result = {};
        if (!hf) return result;
        var header = hf.header || { elements: [] }, footer = hf.footer || { elements: [] }, watermark = hf.watermark || {};

        var headerContent = [];
        var hasHeader = (header.elements || []).some(function (el) { return el.value; });
        if (hasHeader) headerContent.push(pdDocxSideContent(header));

        if (watermark.image) {
            try {
                var wmRun = new docx.ImageRun({
                    data: pdDataUriToUint8Array(watermark.image),
                    transformation: { width: 300, height: 300 },
                    floating: {
                        horizontalPosition: { relative: docx.HorizontalPositionRelativeFrom.PAGE, align: docx.HorizontalPositionAlign.CENTER },
                        verticalPosition: { relative: docx.VerticalPositionRelativeFrom.PAGE, align: docx.VerticalPositionAlign.CENTER },
                        behindDocument: true,
                        wrap: { type: docx.TextWrappingType.NONE }
                    }
                });
                headerContent.push(new docx.Paragraph({ children: [wmRun] }));
            } catch (e) {
                console.warn('Watermark image could not be embedded in the document:', e);
            }
        } else if (watermark.text) {
            headerContent.push(new docx.Paragraph({
                alignment: docx.AlignmentType.CENTER,
                children: [new docx.TextRun({ text: watermark.text, size: 72, bold: true, color: 'E2E8F0' })]
            }));
        }

        if (headerContent.length) {
            result.headers = { default: new docx.Header({ children: headerContent }) };
        }

        var hasFooter = (footer.elements || []).some(function (el) { return el.value; });
        if (hasFooter) {
            result.footers = { default: new docx.Footer({ children: [pdDocxSideContent(footer)] }) };
        }

        return result;
    }

    /** left/center/right -> the x (inches) where a box of this width should sit on a pptx slide. */
    function pdExtraBoxX(hAlign, w) {
        var margin = 0.6;
        if (hAlign === 'left') return margin;
        if (hAlign === 'right') return PD_SLIDE_W - margin - w;
        return (PD_SLIDE_W - w) / 2;
    }

    /** top/middle/bottom -> the y (inches) where a box of this height should sit on a pptx slide. */
    function pdExtraBoxY(vAlign, h) {
        var margin = 0.5, slideH = 7.5;
        if (vAlign === 'top') return margin;
        if (vAlign === 'bottom') return slideH - margin - h;
        return (slideH - h) / 2;
    }

    /** Adds one deck item's extra elements directly onto its slide -- true absolute placement, matching the preview exactly. */
    function pdAddExtrasToPptxSlide(s, extras) {
        if (!s || !extras || !extras.length) return;
        extras.forEach(function (el) {
            if (!el.value) return;
            if (el.type === 'image') {
                var h = el.size || 2;
                var w = h * (el.aspect || 1.5);
                s.addImage({ data: el.value, x: pdExtraBoxX(el.hAlign, w), y: pdExtraBoxY(el.vAlign, h), w: w, h: h, sizing: { type: 'contain', w: w, h: h } });
            } else {
                var w2 = 6, h2 = 1.2;
                s.addText(el.value, {
                    x: pdExtraBoxX(el.hAlign, w2), y: pdExtraBoxY(el.vAlign, h2), w: w2, h: h2,
                    fontSize: el.size || 14, bold: true, color: '0F172A', align: el.hAlign, valign: 'middle',
                    fill: { color: 'FFFFFF', transparency: 15 }
                });
            }
        });
    }

    /** A deck item's extra elements as appended docx content -- Word has no free placement, so these just follow the page's own content, aligned as chosen. */
    function pdBuildDocxExtras(extras) {
        if (!extras || !extras.length) return [];
        var out = [];
        extras.forEach(function (el) {
            if (!el.value) return;
            if (el.type === 'image') {
                try {
                    var hPx = Math.round((el.size || 2) * 96);
                    var wPx = Math.round(hPx * (el.aspect || 1.5));
                    out.push(new docx.Paragraph({
                        alignment: pdDocxAlignmentFor(el.hAlign),
                        spacing: { before: 200 },
                        children: [new docx.ImageRun({ data: pdDataUriToUint8Array(el.value), transformation: { width: wPx, height: hPx } })]
                    }));
                } catch (e) {
                    console.warn('Could not embed an extra image:', e);
                }
            } else {
                out.push(new docx.Paragraph({
                    alignment: pdDocxAlignmentFor(el.hAlign),
                    spacing: { before: 200 },
                    children: [new docx.TextRun({ text: el.value, bold: true, size: (el.size || 14) * 2, color: '0F172A' })]
                }));
            }
        });
        return out;
    }

    function exportDeck() {
        var deck = currentDeck();
        if (!deck.length) {
            alert('Add at least one ' + (state.tab === 'pptx' ? 'slide' : 'page') + ' first.');
            return;
        }
        var theme = getTheme();
        var base = pdSlug(state.name[state.tab]);

        try {
            if (state.tab === 'pptx') {
                var pptx = new PptxGenJS();
                pptx.defineLayout({ name: 'PD_16x9', width: 13.333, height: 7.5 });
                pptx.layout = 'PD_16x9';
                var masterName = pdBuildMaster(pptx, state.headerFooter.pptx);
                deck.forEach(function (item) {
                    var t = getTemplate(item.templateId);
                    var v = parseValues(t, item.raw);
                    t.buildPptx(pptx, v, theme, { masterName: masterName });
                    pdAddExtrasToPptxSlide(pdLastSlideRef, item.extras);
                });
                pptx.writeFile({ fileName: base + '.pptx' });
            } else {
                var children = [];
                deck.forEach(function (item, i) {
                    var t = getTemplate(item.templateId);
                    var v = parseValues(t, item.raw);
                    if (i > 0) children.push(new docx.Paragraph({ children: [new docx.PageBreak()] }));
                    children = children.concat(t.buildDocx(v, theme));
                    children = children.concat(pdBuildDocxExtras(item.extras));
                });
                var section = { children: children };
                var hf = pdBuildDocxHeaderFooter(state.headerFooter.docx);
                if (hf.headers) section.headers = hf.headers;
                if (hf.footers) section.footers = hf.footers;
                var doc = new docx.Document({ sections: [section] });
                docx.Packer.toBlob(doc).then(function (blob) {
                    pdSaveBlob(blob, base + '.docx');
                }).catch(function (err) {
                    console.error(err);
                    alert('Could not generate the document: ' + err.message);
                });
            }
        } catch (err) {
            console.error(err);
            alert('Could not generate the file: ' + err.message);
        }
    }

    /* ---------------------------------------------------------------- */
    /* Save / load (the one piece of server-side persistence)            */
    /* ---------------------------------------------------------------- */

    function serializeDeck(tab) {
        return {
            items: state.deck[tab].map(function (item) { return { templateId: item.templateId, raw: item.raw, extras: item.extras || [] }; }),
            themeId: state.themeId,
            headerFooter: state.headerFooter[tab]
        };
    }

    function applyLoadedDeck(tab, deckPayload) {
        var data = deckPayload.data || {};
        var items = Array.isArray(data.items) ? data.items : [];

        state.deck[tab] = items
            .filter(function (it) { return !!getTemplate(it.templateId); })
            .map(function (it) {
                var t = getTemplate(it.templateId);
                var raw = defaultRawFor(t);
                if (it.raw) {
                    for (var k in it.raw) { if (Object.prototype.hasOwnProperty.call(it.raw, k)) raw[k] = it.raw[k]; }
                }
                return { uid: newUid(), templateId: it.templateId, raw: raw, extras: pdNormalizeExtras(it.extras) };
            });

        state.selected[tab] = state.deck[tab].length ? state.deck[tab][0].uid : null;

        state.headerFooter[tab] = pdNormalizeHeaderFooter(data.headerFooter);

        if (data.themeId) state.themeId = data.themeId;
        state.name[tab] = deckPayload.name || state.name[tab];
        state.loadedDeckId[tab] = deckPayload.id || null;

        if (state.tab === tab) {
            var nameInput = document.getElementById('pdDeckName');
            if (nameInput) nameInput.value = state.name[tab];
            state.formMode = 'item';
            renderSwatches();
            renderGallery();
            renderDeckList();
            renderForm();
            renderPreview();
        }
    }

    function pdCsrfToken() {
        var el = document.getElementById('pdCsrfToken');
        return el ? el.value : '';
    }

    function pdApiMostRecent(tab, cb) {
        fetch('presentation-designer.php?pd_action=most_recent&deck_type=' + encodeURIComponent(tab), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) { cb(res && res.ok ? res.deck : null); })
            .catch(function () { cb(null); });
    }

    function pdApiList(tab, cb) {
        fetch('presentation-designer.php?pd_action=list&deck_type=' + encodeURIComponent(tab), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) { cb(res && res.ok ? res.decks : []); })
            .catch(function () { cb([]); });
    }

    function pdApiLoad(tab, id, cb) {
        fetch('presentation-designer.php?pd_action=load&deck_type=' + encodeURIComponent(tab) + '&id=' + encodeURIComponent(id), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) { cb(res && res.ok ? res.deck : null, res && !res.ok ? res.error : null); })
            .catch(function (err) { cb(null, err.message); });
    }

    function pdApiSave(tab, name, dataObj, cb) {
        var body = new FormData();
        body.append('pd_action', 'save');
        body.append('csrf_token', pdCsrfToken());
        body.append('deck_type', tab);
        body.append('name', name);
        body.append('data', JSON.stringify(dataObj));
        fetch('presentation-designer.php', { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) { cb(res); })
            .catch(function (err) { cb({ ok: false, error: err.message }); });
    }

    function pdApiDelete(id, cb) {
        var body = new FormData();
        body.append('pd_action', 'delete');
        body.append('csrf_token', pdCsrfToken());
        body.append('id', id);
        fetch('presentation-designer.php', { method: 'POST', body: body, credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (res) { cb(res); })
            .catch(function (err) { cb({ ok: false, error: err.message }); });
    }

    function showSaveStatus(msg, isError) {
        var el = document.getElementById('pdSaveStatus');
        if (!el) return;
        el.textContent = msg;
        el.classList.toggle('error', !!isError);
        el.hidden = false;
        clearTimeout(showSaveStatus._t);
        showSaveStatus._t = setTimeout(function () { el.hidden = true; }, 3500);
    }

    function saveCurrentDeck() {
        var deck = currentDeck();
        if (!deck.length) {
            alert('Add at least one ' + (state.tab === 'pptx' ? 'slide' : 'page') + ' before saving.');
            return;
        }
        var name = (state.name[state.tab] || '').trim();
        if (!name) {
            alert('Give this ' + (state.tab === 'pptx' ? 'presentation' : 'document') + ' a name first.');
            return;
        }
        state.name[state.tab] = name;

        var tab = state.tab;
        pdApiSave(tab, name, serializeDeck(tab), function (res) {
            if (res && res.ok) {
                state.loadedDeckId[tab] = res.id;
                showSaveStatus('Saved "' + name + '".', false);
            } else {
                showSaveStatus((res && res.error) || 'Could not save.', true);
            }
        });
    }

    function newDeck() {
        var tab = state.tab;
        if (currentDeck().length && !confirm('Start a new ' + (tab === 'pptx' ? 'presentation' : 'document') + '? Unsaved changes will be lost.')) return;
        state.deck[tab] = [];
        state.selected[tab] = null;
        state.headerFooter[tab] = emptyHeaderFooter();
        state.name[tab] = tab === 'pptx' ? 'Untitled Presentation' : 'Untitled Document';
        state.loadedDeckId[tab] = null;
        state.formMode = 'item';
        var nameInput = document.getElementById('pdDeckName');
        if (nameInput) nameInput.value = state.name[tab];
        renderDeckList();
        renderForm();
        renderPreview();
    }

    function renderDecksDropdown() {
        var dd = document.getElementById('pdDecksDropdown');
        if (!dd) return;
        var tab = state.tab;
        var canDeleteEl = document.getElementById('pdCanDelete');
        var canDelete = !!canDeleteEl && canDeleteEl.value === '1';

        pdApiList(tab, function (decks) {
            if (!decks.length) {
                dd.innerHTML = '<div class="pd-empty-small">No saved ' + (tab === 'pptx' ? 'presentations' : 'documents') + ' yet.</div>';
                return;
            }
            dd.innerHTML = decks.map(function (d) {
                return '<div class="pd-deck-row" data-id="' + d.id + '">' +
                    '<span class="pd-deck-row-name" data-action="open">' + pdEsc(d.name) + '</span>' +
                    '<span class="pd-deck-row-date">' + pdEsc(d.updated_at || '') + '</span>' +
                    (canDelete ? '<button type="button" class="pd-deck-row-del" data-action="del" title="Delete">&times;</button>' : '') +
                    '</div>';
            }).join('');

            dd.querySelectorAll('.pd-deck-row').forEach(function (row) {
                var id = row.getAttribute('data-id');
                row.querySelector('[data-action="open"]').addEventListener('click', function () {
                    pdApiLoad(tab, id, function (deck, err) {
                        if (!deck) { alert(err || 'Could not load that deck.'); return; }
                        applyLoadedDeck(tab, deck);
                        dd.hidden = true;
                    });
                });
                var delBtn = row.querySelector('[data-action="del"]');
                if (delBtn) {
                    delBtn.addEventListener('click', function (e) {
                        e.stopPropagation();
                        var label = row.querySelector('.pd-deck-row-name').textContent;
                        if (!confirm('Delete "' + label + '"? This cannot be undone.')) return;
                        pdApiDelete(id, function (res) {
                            if (res && res.ok) renderDecksDropdown();
                            else alert((res && res.error) || 'Could not delete.');
                        });
                    });
                }
            });
        });
    }

    /* ---------------------------------------------------------------- */
    /* Boot                                                              */
    /* ---------------------------------------------------------------- */

    document.addEventListener('DOMContentLoaded', function () {
        renderSwatches();

        document.querySelectorAll('.pd-tab').forEach(function (btn) {
            btn.addEventListener('click', function () { switchTab(btn.getAttribute('data-tab')); });
        });

        var exportBtn = document.getElementById('pdExportBtn');
        if (exportBtn) exportBtn.addEventListener('click', exportDeck);

        var nameInput = document.getElementById('pdDeckName');
        if (nameInput) {
            nameInput.value = state.name[state.tab];
            nameInput.addEventListener('input', function () { state.name[state.tab] = this.value; });
        }

        var newBtn = document.getElementById('pdNewBtn');
        if (newBtn) newBtn.addEventListener('click', newDeck);

        var saveBtn = document.getElementById('pdSaveBtn');
        if (saveBtn) saveBtn.addEventListener('click', saveCurrentDeck);

        var myDecksBtn = document.getElementById('pdMyDecksBtn');
        var decksDropdown = document.getElementById('pdDecksDropdown');
        if (myDecksBtn && decksDropdown) {
            myDecksBtn.addEventListener('click', function (e) {
                e.stopPropagation();
                var opening = decksDropdown.hidden;
                decksDropdown.hidden = !opening;
                if (opening) renderDecksDropdown();
            });
            document.addEventListener('click', function (e) {
                if (!decksDropdown.hidden && !decksDropdown.contains(e.target) && e.target !== myDecksBtn) {
                    decksDropdown.hidden = true;
                }
            });
        }

        document.querySelectorAll('.pd-form-tab').forEach(function (btn) {
            btn.addEventListener('click', function () {
                state.formMode = btn.getAttribute('data-form-tab');
                renderForm();
            });
        });

        switchTab('pptx');

        var stageEl = document.getElementById('pdStage');
        if (stageEl && window.ResizeObserver) {
            new ResizeObserver(function () {
                var frame = document.getElementById('pdFrame');
                if (!frame) return;
                var isDoc = frame.classList.contains('pd-frame-doc');
                pdFitFrame(frame, isDoc ? 794 : 1280, isDoc ? 1123 : 720);
            }).observe(stageEl);
        }
    });

})();
