/*
|--------------------------------------------------------------------------
| PAGE TRANSITIONS
|--------------------------------------------------------------------------
| InfraVault has no client-side router -- every link is a full page load.
| "Transition motion" here means: hide the incoming page's .content in
| its entry pose before first paint (this file is loaded blocking, from
| <head>, so applyEnterState() below wins the race against the browser
| ever painting .content in its resting state) and let a pure-CSS
| animation (assets/css/page-transitions.css) play it in on its own.
|
| That last part matters: the entrance MUST NOT wait on __ptInit() below,
| which only runs once every other script on the page -- app.js,
| sidebar.js, chat-widget.php's own script, any page's chart/table init
| -- has already executed. Gating visibility on that made heavier pages
| (big tables, Chart.js) look like they'd gone slow to load, when really
| .content was just sitting at opacity:0 the whole time. A CSS animation
| starts as soon as the element exists and is styled, independent of how
| long later scripts take.
|
| __ptInit() only wires up the outgoing side: intercept the click, play
| the matching exit pose, and navigate once it's finished.
|
| Motion is chosen per sidebar section (see includes/sidebar.php's menu
| groups) rather than per individual page -- grouping keeps the effect
| legible instead of forty near-identical one-off animations, and it
| gives each area of the app a consistent, recognisable feel.
|--------------------------------------------------------------------------
*/
(function(window, document){

    var SECTION_PAGES = {
        dashboard: [
            'home.php'
        ],
        inventory: [
            'asset.php', 'inventory.php', 'license_warranty.php', 'ip.php',
            'ownership.php', 'uid-gid-tracking.php', 'handover.php',
            'decommission.php', 'builds.php', 'container_platform.php',
            'oracle_db.php', 'dr_mapping.php', 'app_layout.php',
            'project_overview.php'
        ],
        vulnerability: [
            'patching.php', 'grc_schedule.php', 'vulnerabilities.php',
            'compliance.php', 'patch.php'
        ],
        runbook: [
            'sop-summary.php', 'knowledge-summary.php', 'known-issues-summary.php'
        ],
        workspace: [
            'oncall.php', 'leave.php', 'special_projects.php', 'tickets.php',
            'links.php', 'mydata.php'
        ],
        utilities: [
            'vault.php', 'diagram_designer.php', 'org_charts.php',
            'hostname.php', 'subnet_calculator.php', 'tcpdump_analyzer.php',
            'pasgen.php', 'ssl_manager.php', 'presentation-designer.php'
        ],
        options: [
            'notification.php', 'reminders.php', 'myprofile.php', 'users.php',
            'settings.php', 'help.php', 'about.php'
        ]
    };

    // Each section's motion is a pair of resting-to-hidden poses: "enter"
    // is where the incoming page starts (and animates away from), "exit"
    // is where the outgoing page ends up (and animates towards). Sections
    // that face each other in the sidebar (inventory/vulnerability) use
    // mirrored directions so consecutive sections read as moving past
    // one another.
    var MOTION = {
        dashboard:     { enter: 'translateY(10px) scale(0.99)',    exit: 'translateY(-10px) scale(0.99)' },
        inventory:     { enter: 'translateX(42px)',                exit: 'translateX(-42px)' },
        vulnerability: { enter: 'translateX(-42px)',               exit: 'translateX(42px)' },
        runbook:       { enter: 'translateY(34px)',                exit: 'translateY(-34px)' },
        workspace:     { enter: 'scale(0.95)',                     exit: 'scale(1.05)' },
        utilities:     { enter: 'scale(1.05) rotate(-1.5deg)',     exit: 'scale(0.95) rotate(1.5deg)' },
        options:       { enter: 'translate(24px, 14px)',           exit: 'translate(-24px, -14px)' },
        _default:      { enter: 'translateY(14px)',                exit: 'translateY(-14px)' }
    };

    // Kept in sync with the exit transition duration in
    // assets/css/page-transitions.css.
    var EXIT_DURATION_MS = 200;

    var FILE_TO_SECTION = {};
    Object.keys(SECTION_PAGES).forEach(function(section){
        SECTION_PAGES[section].forEach(function(file){
            FILE_TO_SECTION[file] = section;
        });
    });

    function sectionForUrl(url){
        try{
            var path = new URL(url, window.location.href).pathname;
            var file = path.substring(path.lastIndexOf('/') + 1) || 'home.php';
            return FILE_TO_SECTION[file] || '_default';
        } catch(e){
            return '_default';
        }
    }

    function motionFor(section){
        return MOTION[section] || MOTION._default;
    }

    var html = document.documentElement;

    // Runs immediately -- this file is included, blocking, from <head>,
    // before .content exists in the DOM. Sets the CSS animation's "from"
    // pose and arms it; assets/css/page-transitions.css takes it from
    // here with no further JS involved.
    html.style.setProperty('--pt-enter-pose', motionFor(sectionForUrl(window.location.href)).enter);
    html.classList.add('pt-page');

    window.__ptInit = function(){
        var content = document.querySelector('.content');

        if (!content){
            // Full-bleed pages (diagram_designer.php, subnet_calculator.php,
            // ssl_manager.php, ...) render their own layout instead of the
            // shared .content pane, so there's no exit animation to wire up.
            return;
        }

        var navigating = false;

        document.addEventListener('click', function(e){

            if (navigating || e.defaultPrevented || e.button !== 0){
                return;
            }
            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey){
                return;
            }

            var link = e.target.closest('a[href]');

            if (!link){
                return;
            }

            var href = link.getAttribute('href');

            if (
                !href ||
                href.charAt(0) === '#' ||
                href.indexOf('javascript:') === 0 ||
                href.indexOf('mailto:') === 0 ||
                href.indexOf('tel:') === 0 ||
                link.target === '_blank' ||
                link.hasAttribute('download') ||
                link.dataset.noTransition !== undefined ||
                link.origin !== window.location.origin
            ){
                return;
            }

            // A link back to the exact same page (just a different query
            // string or hash) isn't a navigation this effect should cover.
            if (link.pathname === window.location.pathname && link.search === window.location.search){
                return;
            }

            e.preventDefault();
            navigating = true;

            var section = sectionForUrl(href);
            html.style.setProperty('--pt-exit-pose', motionFor(section).exit);
            html.classList.add('pt-exiting');

            window.setTimeout(function(){
                window.location.href = href;
            }, EXIT_DURATION_MS);
        });
    };

})(window, document);
