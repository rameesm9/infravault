console.log("InfraVault app.js loaded");

// Global application scripts will go here
// Sidebar functionality is handled by sidebar.js

/*
|--------------------------------------------------------------------------
| LIVE SEARCH
|--------------------------------------------------------------------------
| Any input marked data-live-search auto-submits its form a short pause
| after the user stops typing, instead of requiring the Search button.
| The attribute's value is the debounce delay in ms (default 500).
|
| Whether that's active at all is a single site-wide on/off preference
| (localStorage), flipped by any button marked data-live-search-toggle.
| Toggling it on one page carries to the rest, since it's the same
| preference everywhere rather than a per-page setting.
*/
var LIVE_SEARCH_STORAGE_KEY = 'iv_live_search_enabled';

function isLiveSearchEnabled() {
    try {
        var v = localStorage.getItem(LIVE_SEARCH_STORAGE_KEY);
        return v === null ? true : v === '1';
    } catch (e) {
        return true;
    }
}

function setLiveSearchEnabled(enabled) {
    try {
        localStorage.setItem(LIVE_SEARCH_STORAGE_KEY, enabled ? '1' : '0');
    } catch (e) {
        // Storage unavailable (private mode, etc.) -- toggle just won't persist.
    }
    document.querySelectorAll('[data-live-search-toggle]').forEach(updateLiveSearchToggleButton);
}

function updateLiveSearchToggleButton(btn) {
    var on = isLiveSearchEnabled();
    btn.textContent = on ? 'Auto-Search: On' : 'Auto-Search: Off';
    btn.setAttribute('aria-pressed', on ? 'true' : 'false');
    btn.classList.toggle('live-search-off', !on);
}

function toggleLiveSearch() {
    setLiveSearchEnabled(!isLiveSearchEnabled());
}

document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('[data-live-search-toggle]').forEach(updateLiveSearchToggleButton);

    document.querySelectorAll('input[data-live-search]').forEach(function (input) {

        var delay = parseInt(input.getAttribute('data-live-search'), 10) || 500;
        var timer = null;

        input.addEventListener('input', function () {

            clearTimeout(timer);

            if (!isLiveSearchEnabled()) {
                return;
            }

            timer = setTimeout(function () {
                if (input.form) {
                    if (input.form.requestSubmit) {
                        input.form.requestSubmit();
                    } else {
                        input.form.submit();
                    }
                }
            }, delay);

        });

        // Enter still submits immediately; no need to also fire the
        // pending debounce once the form has already been submitted.
        input.addEventListener('keydown', function (e) {
            if (e.key === 'Enter') {
                clearTimeout(timer);
            }
        });

    });

});
