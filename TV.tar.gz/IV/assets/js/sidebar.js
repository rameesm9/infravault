console.log("InfraVault sidebar.js loaded");


(function(){


    function initSidebar(){


        const sidebar = document.getElementById("sidebar");
        const toggleButton = document.getElementById("sidebarToggle");


        if(!sidebar || !toggleButton){

            console.error("Sidebar or toggle button missing");

            return;

        }



        toggleButton.onclick = function(e){

            e.preventDefault();


            sidebar.classList.toggle("collapsed");


            document.body.classList.toggle(
                "sidebar-collapsed"
            );


            var isCollapsed = sidebar.classList.contains("collapsed");

            try{
                localStorage.setItem(
                    "sidebarCollapsed",
                    isCollapsed ? "1" : "0"
                );
            } catch(err){}


            console.log(
                "Sidebar collapsed:",
                isCollapsed
            );


            // close submenu while collapsing

            if(sidebar.classList.contains("collapsed")){


                closeAllSubmenus();


            }


        };


        // Clicking outside an open flyout submenu (icon-rail
        // mode) closes it.

        document.addEventListener("click", function(e){

            if(!isIconRailCollapsed(sidebar)){
                return;
            }

            if(e.target.closest(".menu-group")){
                return;
            }

            closeAllSubmenus();

        });


        // Keep an open flyout aligned with its icon if the
        // window is resized.

        window.addEventListener("resize", function(){

            const openHeader =
                document.querySelector(".menu-header.open");

            if(openHeader && isIconRailCollapsed(sidebar)){

                positionFlyout(
                    openHeader,
                    openHeader.nextElementSibling
                );

            }

        });


    }



    window.addEventListener(
        "load",
        function(){
            initSidebar();
            markCurrentPage();
            initRailTooltips();
        }
    );


})();



// =================================
// ICON RAIL LABELS
// =================================
//
// When the sidebar is collapsed the labels are hidden, leaving icons with
// no way to identify them. Hovering a row shows its label in a floating
// pill next to the rail.
//
// The pill is appended to <body> and positioned with fixed coordinates
// because .sidebar clips its overflow (overflow-y:auto with
// overflow-x:hidden); a tooltip parented inside a row would be clipped at
// the panel edge, which is precisely where it has to appear. The collapsed
// submenu flyout is positioned the same way for the same reason.

function sidebarTipElement(){

    var tip = document.getElementById("sidebarTip");

    if(!tip){

        tip = document.createElement("div");
        tip.id = "sidebarTip";
        tip.className = "sidebar-tip";
        tip.setAttribute("role", "tooltip");

        document.body.appendChild(tip);

    }

    return tip;

}


function hideSidebarTip(){

    var tip = document.getElementById("sidebarTip");

    if(tip){
        tip.classList.remove("show");
    }

}


function showSidebarTip(row){

    var sidebar = document.getElementById("sidebar");

    if(!sidebar || !isIconRailCollapsed(sidebar)){
        return;
    }

    var label = row.querySelector(".nav-text");
    var text = label ? label.textContent.trim() : "";

    if(!text){
        return;
    }

    var tip = sidebarTipElement();
    var rect = row.getBoundingClientRect();

    tip.textContent = text;

    // Matches the flyout's 12px gutter so labels and submenus line up.
    tip.style.left = (rect.right + 12) + "px";
    tip.style.top  = (rect.top + rect.height / 2) + "px";

    tip.classList.add("show");

}


function initRailTooltips(){

    var sidebar = document.getElementById("sidebar");

    if(!sidebar){
        return;
    }

    var rows = sidebar.querySelectorAll(".nav-item, .menu-header");

    Array.prototype.forEach.call(rows, function(row){

        row.addEventListener("mouseenter", function(){
            showSidebarTip(row);
        });

        row.addEventListener("mouseleave", hideSidebarTip);

        // Opening a flyout replaces the label, so the pill must not be
        // left hanging over it.
        row.addEventListener("click", hideSidebarTip);

        // Keyboard parity: the label follows focus as well as the pointer.
        row.addEventListener("focus", function(){
            showSidebarTip(row);
        }, true);

        row.addEventListener("blur", hideSidebarTip, true);

    });

    // A pill pinned to fixed coordinates would otherwise detach from its
    // row when the rail scrolls or the window changes size.
    sidebar.addEventListener("scroll", hideSidebarTip);
    window.addEventListener("resize", hideSidebarTip);

}



// =================================
// CURRENT PAGE HIGHLIGHTING
// =================================
//
// Done here rather than in sidebar.php because the markup has 36 submenu
// links across 6 groups; tagging each one server-side would mean 36 edits
// that have to be kept in sync every time a link is added.
//
// Matching is on a normalised page key, not the raw href, because several
// sidebar links point at a "-summary" landing page while the user ends up
// on the plain page (sop-summary.php -> sop.php). An exact href match
// would leave those pages with nothing highlighted.

function sidebarPageKey(path){

    var file = (String(path).split("?")[0].split("#")[0].split("/").pop() || "")
        .toLowerCase();

    return file
        .replace(/\.php$/, "")
        .replace(/[-_]summary$/, "")
        .replace(/-/g, "_");

}


function markCurrentPage(){

    var sidebar = document.getElementById("sidebar");

    if(!sidebar){
        return;
    }

    var current = sidebarPageKey(window.location.pathname);

    if(!current){
        return;
    }

    var links = sidebar.querySelectorAll("a[href]");

    Array.prototype.forEach.call(links, function(link){

        var href = link.getAttribute("href") || "";

        // Skip anchors and anything pointing off-site.
        if(href.charAt(0) === "#" || /^[a-z]+:/i.test(href)){
            return;
        }

        if(sidebarPageKey(href) !== current){
            return;
        }

        link.classList.add("is-current");

        var group = link.closest(".menu-group");

        if(!group){
            return;
        }

        group.classList.add("has-current");

        var header = group.querySelector(".menu-header");
        var submenu = group.querySelector(".submenu");

        // Auto-expanding in the icon rail would fire the flyout on page
        // load, unanchored, over the content.
        if(isIconRailCollapsed(sidebar)){
            return;
        }

        if(header){
            header.classList.add("open");
        }

        if(submenu){
            submenu.classList.add("show");
        }

    });

}



function closeAllSubmenus(){

    document.querySelectorAll(".submenu")
    .forEach(function(menu){

        menu.classList.remove("show");
        menu.style.top = "";
        menu.style.left = "";

    });


    document.querySelectorAll(".menu-header")
    .forEach(function(header){

        header.classList.remove("open");

    });

}



function isIconRailCollapsed(sidebar){

    return sidebar.classList.contains("collapsed") &&
        window.matchMedia("(min-width: 901px)").matches;

}



function positionFlyout(header, submenu){

    const rect = header.getBoundingClientRect();

    // 12px matches the icon-rail label gutter, so a group's flyout opens
    // exactly where its hover label was.
    submenu.style.left = (rect.right + 12) + "px";

    submenu.style.top = Math.max(rect.top, 8) + "px";

    // Keep a tall flyout on screen: if it would run past the bottom of
    // the viewport, pull it up rather than letting it overflow.
    const height = submenu.offsetHeight;
    const maxTop = window.innerHeight - height - 8;

    if(height && maxTop > 8 && rect.top > maxTop){
        submenu.style.top = maxTop + "px";
    }

}



// =================================
// SUB MENU
// =================================

function toggleMenu(header){


    const sidebar =
        document.getElementById("sidebar");


    const submenu =
        header.nextElementSibling;


    const isOpen =
        submenu.classList.contains("show");


    closeAllSubmenus();

    hideSidebarTip();


    if(!isOpen){

        if(isIconRailCollapsed(sidebar)){

            // Must be shown before positioning: offsetHeight is 0 while
            // the flyout is still display:none, so the bottom-edge clamp
            // in positionFlyout would have nothing to measure.
            submenu.classList.add("show");

            positionFlyout(header, submenu);

        } else {

            submenu.classList.add("show");

        }

        header.classList.add("open");

    }


}
