<?php

session_start();
require 'config/db.php';
require_once 'includes/branding-helpers.php';

$appName = getAppName($pdo);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = $_SESSION['role'] ?? 'User';

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

/*
| Gated on 'patching', the module this import belongs to.
|
| It previously queried page_key = 'patch_servers', which is not a
| registered key -- the lookup returned no row for every role, so the
| gate could never grant and this importer denied everyone. The
| identical bug in patch_servers.php was what made the server modal fail
| with "Failed to load servers"; this file was missed at the time.
|
| authzCan() now logs an unregistered key rather than failing silently,
| so the same mistake cannot hide again.
*/

requireLogin();
requirePermission('patching', 'can_view');
requirePermission('patching', 'can_import');

$canImport = can('patching', 'can_import');

$message = "";
$errors = [];
$imported = 0;
$skipped = 0;

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {

            $header = fgetcsv($handle);

            while (($row = fgetcsv($handle)) !== false) {

                $data = array_combine($header, $row);

                // Extract required fields
                $hostname = trim($data['hostname'] ?? '');

                if (!$hostname) {
                    $skipped++;
                    continue;
                }

                // Check if server exists in inventory
                $stmt = $pdo->prepare("SELECT hostname FROM inventory WHERE hostname = ?");
                $stmt->execute([$hostname]);

                if (!$stmt->fetch()) {
                    $skipped++;
                    continue;
                }

                // Extract optional fields
                $os_version = trim($data['os_version'] ?? '');
                $kernel_version = trim($data['kernel_version'] ?? '');
                $status = trim($data['status'] ?? '');
                $comment = trim($data['comment'] ?? '');

                // Update inventory if OS/kernel versions provided
                if ($os_version !== '' || $kernel_version !== '') {
                    $stmt = $pdo->prepare("UPDATE inventory SET os_version = ?, kernel_version = ? WHERE hostname = ?");
                    $stmt->execute([$os_version, $kernel_version, $hostname]);
                }

                $imported++;
            }

            fclose($handle);
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Patch Servers CSV | <?= htmlspecialchars($appName) ?></title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Patch Servers CSV</h2>

        <?php if ($imported > 0 || $skipped > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Imported</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped; ?></strong>
                </div>
            </div>
            <p class="text-center" style="margin-top: 20px;">
                <a href="patch_servers.php" class="btn btn-primary">Return to Patch Servers List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="patch_servers.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
