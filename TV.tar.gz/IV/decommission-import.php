<?php

session_start();
require 'config/db.php';
require_once 'includes/csv-helpers.php';
require_once 'includes/decommission-helpers.php';
require_once 'includes/branding-helpers.php';

$appName = getAppName($pdo);

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('decommission', 'can_view');
requirePermission('decommission', 'can_import');


$role = $_SESSION['role'] ?? 'User';

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

// Check permissions
if ($role !== 'Admin' && $role !== 'Edit') {
    die("Permission denied");
}

$message = "";
$imported = 0;       // decommission entries created
$replaced = 0;       // existing entries overwritten (duplicate unique_id)
$hosts_added = 0;    // hosts attached across all created/replaced entries
$skipped_groups = 0; // whole entries skipped (no hosts)
$skipped_rows = 0;   // individual rows skipped (missing unique_id/hostname)

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {

            $header = csvNormaliseHeader((array) fgetcsv($handle));

            /*
            | A decommission entry can cover several hosts, so the file is
            | one row per host, grouped by unique_id -- the same convention
            | already used by the Quarterly Patching CSV (one row per host,
            | grouped by schedule). Rows sharing a unique_id become one
            | decommission entry with one decommission_hosts row per host.
            */
            $groups = [];
            $group_order = [];

            while (($row = fgetcsv($handle)) !== false) {

                // A short row would make array_combine fail outright.
                $row = array_pad(array_slice($row, 0, count($header)), count($header), '');
                $data = array_combine($header, $row);

                $unique_id = trim($data['unique_id'] ?? '');
                $hostname = trim($data['hostname'] ?? '');

                if ($unique_id === '' || $hostname === '') {
                    $skipped_rows++;
                    continue;
                }

                if (!isset($groups[$unique_id])) {
                    $groups[$unique_id] = [
                        'req_no' => '',
                        'assignee' => '',
                        'server_state' => '',
                        'start_date' => '',
                        'end_date' => '',
                        'hostnames' => [],
                    ];
                    $group_order[] = $unique_id;
                }

                // Entry-level fields are repeated on every row of a group in
                // this file's own export -- first non-empty value wins so a
                // blank cell on a later row of the same group doesn't erase it.
                $entry_fields = [
                    'req_no' => 'req_no',
                    'assignee' => 'assignee',
                    'server_state' => 'server_state',
                    'start_date' => 'decommission_start_date',
                    'end_date' => 'decommission_end_date',
                ];
                foreach ($entry_fields as $local_key => $csv_key) {
                    if ($groups[$unique_id][$local_key] === '' && trim($data[$csv_key] ?? '') !== '') {
                        $groups[$unique_id][$local_key] = trim($data[$csv_key]);
                    }
                }

                if (!in_array($hostname, $groups[$unique_id]['hostnames'], true)) {
                    $groups[$unique_id]['hostnames'][] = $hostname;
                }
            }

            fclose($handle);

            $dup_stmt = $pdo->prepare("SELECT id FROM decommission WHERE unique_id = ?");

            foreach ($group_order as $unique_id) {
                $g = $groups[$unique_id];

                if (empty($g['hostnames'])) {
                    $skipped_groups++;
                    continue;
                }

                // An entry with this unique_id already exists -- replace its
                // fields and host list with the new CSV data instead of
                // skipping the whole group.
                $dup_stmt->execute([$unique_id]);
                $existing_id = $dup_stmt->fetchColumn();

                try {
                    $assignee_id = decomResolveAssigneeId($pdo, $g['assignee']);
                    $assignee_name = decomResolveAssigneeName($pdo, $assignee_id);

                    if ($existing_id) {
                        $new_id = (int) $existing_id;

                        $stmt = $pdo->prepare("
                            UPDATE decommission SET
                                req_no = ?, assignee_id = ?, assignee_name = ?, server_state = ?,
                                decommission_start_date = ?, decommission_end_date = ?,
                                updated_by = ?, updated_at = CURRENT_TIMESTAMP
                            WHERE id = ?
                        ");
                        $stmt->execute([
                            $g['req_no'],
                            $assignee_id,
                            $assignee_name,
                            $g['server_state'],
                            $g['start_date'] !== '' ? $g['start_date'] : null,
                            $g['end_date'] !== '' ? $g['end_date'] : null,
                            $username,
                            $new_id,
                        ]);

                        // Replace the host list entirely with the CSV's hosts.
                        $pdo->prepare("DELETE FROM decommission_hosts WHERE decommission_id = ?")->execute([$new_id]);

                        $history_action = 'UPDATED';
                        $history_details = "Replaced via CSV: $unique_id covering " . count($g['hostnames']) . " host(s)";
                        $replaced++;
                    } else {
                        $stmt = $pdo->prepare("
                            INSERT INTO decommission
                            (hostname, unique_id, req_no, assignee_id, assignee_name, server_state, decommission_start_date, decommission_end_date, created_by)
                            VALUES ('', ?, ?, ?, ?, ?, ?, ?, ?)
                        ");
                        $stmt->execute([
                            $unique_id,
                            $g['req_no'],
                            $assignee_id,
                            $assignee_name,
                            $g['server_state'],
                            $g['start_date'] !== '' ? $g['start_date'] : null,
                            $g['end_date'] !== '' ? $g['end_date'] : null,
                            $username,
                        ]);

                        $new_id = (int) $pdo->lastInsertId();

                        decomCreateDefaultTasks($pdo, $new_id);

                        $history_action = 'CREATED';
                        $history_details = "Imported from CSV: $unique_id covering " . count($g['hostnames']) . " host(s)";
                    }

                    foreach ($g['hostnames'] as $hostname) {
                        decomAttachHost($pdo, $new_id, $hostname);

                        if ($g['server_state'] !== '') {
                            $pdo->prepare("UPDATE inventory SET server_state = ? WHERE hostname = ?")
                                ->execute([$g['server_state'], $hostname]);
                        }

                        $hosts_added++;
                    }

                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, ?, ?, ?)");
                    $h_stmt->execute([$new_id, $history_action, $username, $history_details]);

                    $imported++;
                } catch (Exception $e) {
                    $skipped_groups++;
                }
            }
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Decommission CSV | <?= htmlspecialchars($appName) ?></title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 640px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: repeat(4, 1fr); gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Decommission CSV</h2>

        <?php if ($imported > 0 || $replaced > 0 || $skipped_groups > 0 || $skipped_rows > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Entries Created</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Entries Replaced</span>
                    <strong style="color: #d97706;"><?php echo $replaced; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Hosts Added</span>
                    <strong style="color: #2563eb;"><?php echo $hosts_added; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped_groups + $skipped_rows; ?></strong>
                </div>
            </div>
            <p class="text-muted small">Skipped: <?php echo $skipped_groups; ?> entrie(s) (no hosts), <?php echo $skipped_rows; ?> row(s) (missing Unique ID or Hostname).</p>
            <p class="text-center" style="margin-top: 20px;">
                <a href="decommission.php" class="btn btn-primary">Return to Decommission List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="decommission.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
