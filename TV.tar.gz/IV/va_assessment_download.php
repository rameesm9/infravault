<?php
/**
 * VA Assessment -- streams the combined + tagged dataset for one folder as
 * a two-sheet spreadsheet: "Combined Data" (every row, with Project and
 * RHEL Tag columns added) and "Pivot Summary" (Project -> RHEL /
 * RHEL-Kernel breakdown by severity, matching the reference report).
 *
 * See includes/va-assessment-helpers.php for why this is hand-written
 * SpreadsheetML XML rather than a library call: no ext-zip / mbstring /
 * PhpSpreadsheet is available in this environment.
 */

require_once __DIR__ . '/config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

requireLogin();
requirePermission('va_assessment', 'can_view');
requirePermission('va_assessment', 'can_export');

require_once __DIR__ . '/includes/va-assessment-helpers.php';

$folderId = (int) ($_GET['folder_id'] ?? 0);

$folderStmt = $pdo->prepare("SELECT * FROM va_folders WHERE id = ?");
$folderStmt->execute([$folderId]);
$folder = $folderStmt->fetch(PDO::FETCH_ASSOC);

if (!$folder) {
    http_response_code(404);
    exit('Folder not found.');
}

$rowsStmt = $pdo->prepare("
    SELECT r.*, ff.original_filename
    FROM va_folder_rows r
    JOIN va_folder_files ff ON ff.id = r.file_id
    WHERE r.folder_id = ?
    ORDER BY ff.original_filename, r.id
");
$rowsStmt->execute([$folderId]);
$rawRows = $rowsStmt->fetchAll(PDO::FETCH_ASSOC);

if (!$rawRows) {
    http_response_code(400);
    exit('This folder has no uploaded findings to export yet.');
}

$ipProjectMap = vaAssessBuildIpProjectMap($pdo);

$rows = [];
foreach ($rawRows as $r) {
    $project = vaAssessLookupProject($ipProjectMap, (string) $r['ip_address']);
    $osTag = vaAssessComputeOsTag((string) $r['family'], (string) $r['plugin_name']);

    $rows[] = [
        'plugin'             => $r['plugin'],
        'plugin_name'        => $r['plugin_name'],
        'family'             => $r['family'],
        'severity'           => $r['severity'],
        'ip_address'         => $r['ip_address'],
        'port'               => $r['port'],
        'exploit'            => $r['exploit'],
        'repository'         => $r['repository'],
        'mac_address'        => $r['mac_address'],
        'dns_name'           => $r['dns_name'],
        'netbios_name'       => $r['netbios_name'],
        'plugin_output'      => $r['plugin_output'],
        'steps_to_remediate' => $r['steps_to_remediate'],
        'cve'                => $r['cve'],
        'first_discovered'   => $r['first_discovered'],
        'last_observed'      => $r['last_observed'],
        'synopsis'           => $r['synopsis'],
        'source_file'        => $r['original_filename'],
        'project'            => $project,
        'os_tag'             => $osTag,
    ];
}

$pivot = vaAssessBuildPivot($rows);

$folderNameSafe = preg_replace('/[^A-Za-z0-9_\- ]/', '', (string) $folder['name']);
$filename = ($folderNameSafe !== '' ? $folderNameSafe : 'VA_Assessment') . '_combined.xls';

if (ob_get_level()) {
    ob_end_clean();
}

header('Content-Type: application/vnd.ms-excel; charset=UTF-8');
header('Content-Disposition: attachment; filename="' . str_replace('"', '', $filename) . '"');
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

echo '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
echo '<?mso-application progid="Excel.Sheet"?>' . "\n";
echo '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"'
    . ' xmlns:o="urn:schemas-microsoft-com:office:office"'
    . ' xmlns:x="urn:schemas-microsoft-com:office:excel"'
    . ' xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet">' . "\n";

echo '<Styles>';
echo '<Style ss:ID="Header"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#2563EB" ss:Pattern="Solid"/></Style>';
echo '<Style ss:ID="ProjectTotal"><Font ss:Bold="1"/><Interior ss:Color="#EFF6FF" ss:Pattern="Solid"/></Style>';
echo '<Style ss:ID="SubRow"><Alignment ss:Indent="2"/></Style>';
echo '<Style ss:ID="GrandTotal"><Font ss:Bold="1" ss:Color="#FFFFFF"/><Interior ss:Color="#1D4ED8" ss:Pattern="Solid"/></Style>';
echo '</Styles>' . "\n";


/*
|--------------------------------------------------------------------------
| SHEET 1: COMBINED DATA
|--------------------------------------------------------------------------
*/

echo '<Worksheet ss:Name="Combined Data"><Table>' . "\n";

$dataHeaders = [
    'Plugin', 'Plugin Name', 'Family', 'Severity', 'IP Address', 'Port',
    'Exploit?', 'Repository', 'MAC Address', 'DNS Name', 'NetBIOS Name',
    'Plugin Output', 'Steps to Remediate', 'CVE', 'First Discovered',
    'Last Observed', 'Synopsis', 'Project', 'RHEL Tag', 'Source File',
];

$headerCells = [];
foreach ($dataHeaders as $h) {
    $headerCells[] = vaAssessXmlCell($h, false, 'Header');
}
echo vaAssessXmlRow($headerCells);

$dataFieldOrder = [
    'plugin', 'plugin_name', 'family', 'severity', 'ip_address', 'port',
    'exploit', 'repository', 'mac_address', 'dns_name', 'netbios_name',
    'plugin_output', 'steps_to_remediate', 'cve', 'first_discovered',
    'last_observed', 'synopsis', 'project', 'os_tag', 'source_file',
];

foreach ($rows as $row) {
    $cells = [];
    foreach ($dataFieldOrder as $field) {
        $value = $field === 'os_tag' ? $row['os_tag'] : $row[$field];
        $cells[] = vaAssessXmlCell((string) $value);
    }
    echo vaAssessXmlRow($cells);
}

echo '</Table></Worksheet>' . "\n";


/*
|--------------------------------------------------------------------------
| SHEET 2: PIVOT SUMMARY
|--------------------------------------------------------------------------
*/

echo '<Worksheet ss:Name="Pivot Summary"><Table>' . "\n";

$severities = $pivot['severities'];

$pivotHeaderCells = [vaAssessXmlCell('Applications', false, 'Header')];
foreach ($severities as $sev) {
    $pivotHeaderCells[] = vaAssessXmlCell($sev, false, 'Header');
}
$pivotHeaderCells[] = vaAssessXmlCell('Total', false, 'Header');
echo vaAssessXmlRow($pivotHeaderCells);

$grandTotalCounts = [];
$grandTotalSum = 0;

foreach ($pivot['projects'] as $projectName => $osTags) {

    $projectTotalCounts = vaAssessSumSeverityCounts(
        $osTags['RHEL'] ?? [],
        $osTags['RHEL-Kernel'] ?? []
    );
    $projectTotalSum = array_sum($projectTotalCounts);

    $grandTotalCounts = vaAssessSumSeverityCounts($grandTotalCounts, $projectTotalCounts);
    $grandTotalSum += $projectTotalSum;

    // Project total row (bold).
    $cells = [vaAssessXmlCell($projectName, false, 'ProjectTotal')];
    foreach ($severities as $sev) {
        $count = $projectTotalCounts[$sev] ?? 0;
        $cells[] = $count > 0
            ? vaAssessXmlCell($count, true, 'ProjectTotal')
            : vaAssessXmlCell('', false, 'ProjectTotal');
    }
    $cells[] = vaAssessXmlCell($projectTotalSum, true, 'ProjectTotal');
    echo vaAssessXmlRow($cells);

    // RHEL / RHEL-Kernel sub-rows.
    foreach (['RHEL' => 'RHEL', 'RHEL-Kernel' => 'RHEL - Kernel'] as $tagKey => $tagLabel) {
        $counts = $osTags[$tagKey] ?? [];
        $rowSum = array_sum($counts);

        $cells = [vaAssessXmlCell($tagLabel, false, 'SubRow')];
        foreach ($severities as $sev) {
            $count = $counts[$sev] ?? 0;
            $cells[] = $count > 0 ? vaAssessXmlCell($count, true) : vaAssessXmlCell('');
        }
        $cells[] = $rowSum > 0 ? vaAssessXmlCell($rowSum, true) : vaAssessXmlCell('');
        echo vaAssessXmlRow($cells);
    }
}

// Grand total row.
$cells = [vaAssessXmlCell('Grand Total', false, 'GrandTotal')];
foreach ($severities as $sev) {
    $count = $grandTotalCounts[$sev] ?? 0;
    $cells[] = vaAssessXmlCell($count, true, 'GrandTotal');
}
$cells[] = vaAssessXmlCell($grandTotalSum, true, 'GrandTotal');
echo vaAssessXmlRow($cells);

echo '</Table></Worksheet>' . "\n";

echo '</Workbook>';
exit;
