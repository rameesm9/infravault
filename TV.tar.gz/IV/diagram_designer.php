<?php

require_once __DIR__ . '/config/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
| Authorization. This page had neither a login check nor a permission
| check -- it fell back to a 'System' username and rendered for anyone.
*/
requireLogin();
requirePermission('diagram_designer', 'can_view');

$page_title = 'Diagram Designer | InfraVault';

$current_user = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? $_SESSION['name']
    ?? $_SESSION['user']['name']
    ?? 'System';

$current_role = strtolower(
    $_SESSION['user_role']
    ?? $_SESSION['role']
    ?? $_SESSION['user']['role']
    ?? 'user'
);

$isAdmin = in_array($current_role, ['admin', 'administrator'], true);

/*
|--------------------------------------------------------------------------
| DATABASE
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS diagram_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        diagram_data TEXT NOT NULL,
        created_by TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT DEFAULT '',
        updated_at DATETIME
    )
");

/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function jsonResponse(array $data)
{
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data);
    exit;
}

/*
|--------------------------------------------------------------------------
| AJAX SAVE
|--------------------------------------------------------------------------
|
| Important:
| If an ID is supplied but the record no longer exists, we create a new
| document instead of returning "Diagram not found".
|
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save_diagram') {

    $id   = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? 'Untitled Diagram');

    if ($name === '') {
        $name = 'Untitled Diagram';
    }

    $data = $_POST['diagram_data'] ?? '';

    if ($data === '') {
        jsonResponse([
            'success' => false,
            'message' => 'Diagram data is empty.'
        ]);
    }

    $decoded = json_decode($data, true);

    if (json_last_error() !== JSON_ERROR_NONE || !is_array($decoded)) {
        jsonResponse([
            'success' => false,
            'message' => 'Invalid diagram data.'
        ]);
    }

    /*
     * Make sure the basic structure always exists.
     *
     * Two document shapes are valid: the legacy single-page
     * shape ({width,height,background,objects} at the top
     * level) and the multi-page shape ({pages:[{name,data}],
     * activePage}) added for multiple flowcharts in one
     * document. Each page's `data` is the same shape as the
     * legacy document, just nested.
     */
    if (isset($decoded['pages']) && is_array($decoded['pages'])) {

        foreach ($decoded['pages'] as &$page) {

            if (!is_array($page)) {
                $page = [];
            }

            if (!isset($page['name']) || $page['name'] === '') {
                $page['name'] = 'Page';
            }

            if (!isset($page['data']) || !is_array($page['data'])) {
                $page['data'] = [];
            }

            if (!isset($page['data']['width'])) {
                $page['data']['width'] = 2400;
            }

            if (!isset($page['data']['height'])) {
                $page['data']['height'] = 1400;
            }

            if (!isset($page['data']['background'])) {
                $page['data']['background'] = '#0B0F19';
            }

            if (!isset($page['data']['objects']) || !is_array($page['data']['objects'])) {
                $page['data']['objects'] = [];
            }
        }

        unset($page);

        if (empty($decoded['pages'])) {
            $decoded['pages'] = [[
                'name' => 'Page 1',
                'data' => [
                    'width' => 2400,
                    'height' => 1400,
                    'background' => '#0B0F19',
                    'objects' => []
                ]
            ]];
        }

        if (!isset($decoded['activePage']) || !is_int($decoded['activePage'])) {
            $decoded['activePage'] = 0;
        }

    } else {

        if (!isset($decoded['width'])) {
            $decoded['width'] = 2400;
        }

        if (!isset($decoded['height'])) {
            $decoded['height'] = 1400;
        }

        if (!isset($decoded['background'])) {
            $decoded['background'] = '#FFFFFF';
        }

        if (!isset($decoded['objects']) || !is_array($decoded['objects'])) {
            $decoded['objects'] = [];
        }
    }

    $data = json_encode(
        $decoded,
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );

    /*
     * UPDATE EXISTING
     */
    if ($id > 0) {

        $stmt = $pdo->prepare("
            SELECT id, created_by
            FROM diagram_documents
            WHERE id = ?
        ");

        $stmt->execute([$id]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        /*
         * If record exists, update it.
         */
        if ($existing) {

            if (
                !$isAdmin &&
                (string)$existing['created_by'] !== (string)$current_user
            ) {
                jsonResponse([
                    'success' => false,
                    'message' => 'Unauthorized: You can only edit your own diagrams.'
                ]);
            }

            $stmt = $pdo->prepare("
                UPDATE diagram_documents
                SET
                    name = ?,
                    diagram_data = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $name,
                $data,
                $current_user,
                $id
            ]);

            jsonResponse([
                'success' => true,
                'id' => $id,
                'name' => $name,
                'message' => 'Diagram saved successfully.'
            ]);
        }

        /*
         * If an old ID was supplied but no longer exists,
         * create a new document instead of throwing "Diagram not found".
         */
        $id = 0;
    }

    /*
     * INSERT NEW
     */

    $stmt = $pdo->prepare("
        INSERT INTO diagram_documents
            (name, diagram_data, created_by)
        VALUES
            (?, ?, ?)
    ");

    $stmt->execute([
        $name,
        $data,
        $current_user
    ]);

    $newId = (int)$pdo->lastInsertId();

    jsonResponse([
        'success' => true,
        'id' => $newId,
        'name' => $name,
        'message' => 'Diagram created successfully.'
    ]);
}

/*
|--------------------------------------------------------------------------
| AJAX DELETE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_diagram') {

    $id = (int)($_POST['id'] ?? 0);

    if ($id <= 0) {
        jsonResponse([
            'success' => false,
            'message' => 'Invalid diagram ID.'
        ]);
    }

    $stmt = $pdo->prepare("
        SELECT id, created_by
        FROM diagram_documents
        WHERE id = ?
    ");

    $stmt->execute([$id]);
    $existing = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$existing) {
        jsonResponse([
            'success' => false,
            'message' => 'Diagram no longer exists.'
        ]);
    }

    if (
        !$isAdmin &&
        (string)$existing['created_by'] !== (string)$current_user
    ) {
        jsonResponse([
            'success' => false,
            'message' => 'Unauthorized: You can only delete your own diagrams.'
        ]);
    }

    $stmt = $pdo->prepare("
        DELETE FROM diagram_documents
        WHERE id = ?
    ");

    $stmt->execute([$id]);

    jsonResponse([
        'success' => true
    ]);
}

/*
|--------------------------------------------------------------------------
| LOAD CURRENT DIAGRAM
|--------------------------------------------------------------------------
*/

$diagram_id = (int)($_GET['id'] ?? 0);
$loaded_diagram = null;

if ($diagram_id > 0) {

    $stmt = $pdo->prepare("
        SELECT *
        FROM diagram_documents
        WHERE id = ?
    ");

    $stmt->execute([$diagram_id]);
    $loaded_diagram = $stmt->fetch(PDO::FETCH_ASSOC);

    /*
     * If requested ID doesn't exist, don't break the editor.
     */
    if (!$loaded_diagram) {
        $diagram_id = 0;
    }
}

/*
|--------------------------------------------------------------------------
| SAVED DIAGRAMS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        name,
        created_by,
        updated_at,
        created_at
    FROM diagram_documents
    ORDER BY
        COALESCE(updated_at, created_at) DESC,
        id DESC
");

$saved_diagrams = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| INITIAL DATA
|--------------------------------------------------------------------------
*/

if ($loaded_diagram) {

    $initial_data = json_decode(
        $loaded_diagram['diagram_data'],
        true
    );

    if (!is_array($initial_data)) {
        $initial_data = [];
    }

    $initial_name = $loaded_diagram['name'];

} else {

    $initial_data = [
        'width' => 2400,
        'height' => 1400,
        'background' => '#0B0F19',
        'objects' => []
    ];

    $initial_name = 'Untitled Diagram';
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<style>

/* =========================================================
   PAGE
========================================================= */

.dg-page {
    position: fixed;
    left: 250px;
    right: 0;
    /* Was var(--header-height, 60px): the header now floats over the
       page rather than sitting in flow above it. */
    top: 0;
    /* Was var(--footer-height, 32px): same reason, for the footer. */
    bottom: 0;
    display: flex;
    flex-direction: column;
    background: var(--bg-main);
    overflow: hidden;
    transition: .3s ease;
}

body.sidebar-collapsed .dg-page {
    left: 72px;
}

body.header-pinned .dg-page {
    top: var(--header-height, 60px);
}

/* Full screen replaces the whole app chrome (header, app
   sidebar, footer) with just this element -- make sure it
   actually fills the physical screen rather than keeping
   the app-layout offsets meant for sitting beside them. */
.dg-page:fullscreen,
.dg-page:-webkit-full-screen {
    left: 0 !important;
    right: 0 !important;
    top: 0 !important;
    bottom: 0 !important;
}

/* =========================================================
   TOP BAR
========================================================= */

.dg-topbar {
    height: 64px;
    min-height: 64px;
    background: linear-gradient(180deg,#FFFFFF 0%,#FBFCFE 100%);
    border-bottom: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 22px;
    z-index: 20;
    box-shadow: 0 1px 10px rgba(15,23,42,.05);
}

[data-theme="dark"] .dg-topbar {
    background: linear-gradient(180deg,#1E293B 0%,#1B2230 100%);
    box-shadow: 0 1px 10px rgba(0,0,0,.25);
}

.dg-title-area {
    display: flex;
    align-items: center;
    gap: 16px;
}

.dg-logo-mark {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    background: linear-gradient(135deg,#2563EB,#7C3AED);
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 3px 10px rgba(37,99,235,.28);
    flex: none;
}

.dg-logo-mark svg {
    width: 19px;
    height: 19px;
    stroke: #fff;
}

.dg-title {
    font-size: 16px;
    font-weight: 800;
    color: var(--text-primary);
    letter-spacing: -.01em;
}

.dg-subtitle {
    font-size: 11px;
    color: var(--text-muted);
    font-weight: 600;
}

.dg-subtitle b {
    color: var(--text-secondary);
    font-weight: 700;
}

.dg-name-input {
    border: 1px solid var(--border-color);
    border-radius: 9px;
    padding: 8px 12px;
    font-size: 13px;
    width: 230px;
    background: var(--hover-bg);
    font-family: inherit;
    color: var(--text-primary);
}

.dg-name-input:focus {
    outline: none;
    border-color: #2563EB;
    background: var(--bg-content);
    box-shadow: 0 0 0 3px rgba(37,99,235,.12);
}

/* =========================================================
   BUTTONS
========================================================= */

.dg-actions {
    display: flex;
    align-items: center;
    gap: 7px;
}

.dg-btn {
    border: 1px solid var(--border-color);
    background: var(--bg-content);
    color: var(--text-secondary);
    border-radius: 9px;
    padding: 9px 14px;
    font-size: 12.5px;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 6px;
    white-space: nowrap;
    font-family: inherit;
    transition: .15s ease;
}

.dg-btn svg {
    width: 14px;
    height: 14px;
    flex: none;
}

.dg-btn:hover {
    background: var(--hover-bg);
    border-color: #CBD5E1;
    transform: translateY(-1px);
}

.dg-btn:active {
    transform: translateY(0);
}

.dg-btn-primary {
    background: linear-gradient(180deg,#3B82F6,#2563EB);
    border-color: #2563EB;
    color: #fff;
    box-shadow: 0 2px 8px rgba(37,99,235,.25);
}

.dg-btn-primary:hover {
    background: linear-gradient(180deg,#2E71F0,#1D4ED8);
    border-color: #1D4ED8;
}

.dg-btn-success {
    background: linear-gradient(180deg,#34D399,#10B981);
    border-color: #10B981;
    color: #fff;
    box-shadow: 0 2px 8px rgba(16,185,129,.25);
}

.dg-btn-success:hover {
    background: linear-gradient(180deg,#22C892,#059669);
    border-color: #059669;
}

.dg-btn-ghost {
    background: var(--hover-bg);
}

.dg-btn-divider {
    width: 1px;
    height: 22px;
    background: var(--border-color);
    margin: 0 2px;
}

/* =========================================================
   WORKSPACE
========================================================= */

.dg-workspace {
    flex: 1;
    min-height: 0;
    display: grid;
    grid-template-columns: 270px minmax(0,1fr) 300px;
    transition: grid-template-columns .2s ease;
}

.dg-workspace.palette-collapsed {
    grid-template-columns: 0 minmax(0,1fr) 300px;
}

.dg-workspace.properties-collapsed {
    grid-template-columns: 270px minmax(0,1fr) 0;
}

.dg-workspace.palette-collapsed.properties-collapsed {
    grid-template-columns: 0 minmax(0,1fr) 0;
}

.dg-workspace.palette-collapsed .dg-palette,
.dg-workspace.properties-collapsed .dg-properties {
    padding-left: 0;
    padding-right: 0;
    overflow: hidden;
    border: none;
}

.dg-palette,
.dg-properties {
    min-width: 0;
}

/* =========================================================
   PALETTE
========================================================= */

.dg-palette {
    background: var(--bg-content);
    border-right: 1px solid var(--border-color);
    overflow-y: auto;
    padding: 14px 12px;
}

.dg-palette-title {
    font-size: 10.5px;
    font-weight: 800;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: .06em;
    margin: 18px 3px 9px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.dg-palette-title::before {
    content: '';
    width: 3px;
    height: 11px;
    border-radius: 2px;
    background: var(--border-color);
}

.dg-palette-title:first-child {
    margin-top: 2px;
}

.dg-palette-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 7px;
}

.dg-palette-item {
    min-height: 76px;
    border: 1px solid #EEF1F5;
    border-radius: 11px;
    background: var(--bg-content);
    color: var(--text-secondary);
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 6px;
    transition: .15s ease;
    font-family: inherit;
    padding: 8px 4px 7px;
}

.dg-palette-item:hover {
    background: var(--hover-bg);
    border-color: #E2E8F0;
    box-shadow: 0 6px 16px rgba(15,23,42,.08);
    transform: translateY(-2px);
}

.dg-palette-icon {
    width: 34px;
    height: 34px;
    border-radius: 9px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-weight: 700;
    flex: none;
}

.dg-palette-icon svg {
    width: 19px;
    height: 19px;
}

.dg-palette-label {
    font-size: 9px;
    font-weight: 700;
    text-align: center;
    line-height: 1.15;
    color: var(--text-secondary);
}

/* Category badge colors -- shared with canvas node accents */

.dg-icon-basic       { background: linear-gradient(155deg,#F1F5F9,#E2E8F0); color: var(--text-secondary); }
.dg-icon-network      { background: linear-gradient(155deg,#DBEAFE,#BFDBFE); color: #1D4ED8; }
.dg-icon-compute      { background: linear-gradient(155deg,#EDE9FE,#DDD6FE); color: #6D28D9; }
.dg-icon-datacenter    { background: linear-gradient(155deg,#FEF3C7,#FDE68A); color: #B45309; }
.dg-icon-security      { background: linear-gradient(155deg,#FEE2E2,#FECACA); color: #B91C1C; }
.dg-icon-cloud       { background: linear-gradient(155deg,#E0F2FE,#BAE6FD); color: #0369A1; }
.dg-icon-layout      { background: linear-gradient(155deg,#FFEDD5,#FED7AA); color: #C2410C; }
.dg-icon-people      { background: linear-gradient(155deg,#CFFAFE,#A5F3FC); color: #0E7490; }

/* =========================================================
   CANVAS
========================================================= */

.dg-canvas-area {
    position: relative;
    overflow: hidden;
    background: #EAEEF3;
}

.dg-viewport {
    position: absolute;
    inset: 0;
    overflow: hidden;
}

.dg-svg {
    position: absolute;
    left: 0;
    top: 0;
    width: 100%;
    height: 100%;
    user-select: none;
    touch-action: none;
    overflow: visible;
}

.diagram-object {
    cursor: move;
    pointer-events: auto;
}

.dg-svg.freehand-armed {
    cursor: crosshair;
}

.diagram-object text {
    user-select: none;
    pointer-events: none;
}

.node-text {
    font-family: Inter,"Segoe UI",Arial,sans-serif;
    fill: #111827;
    font-size: 14px;
    font-weight: 700;
    text-anchor: middle;
    dominant-baseline: middle;
}

.node-subtext {
    font-family: Inter,"Segoe UI",Arial,sans-serif;
    fill: #64748B;
    font-size: 10px;
    text-anchor: middle;
}

.node-stroke {
    stroke: #334155;
    stroke-width: 1.6;
}

.node-shadow {
    filter: drop-shadow(0 3px 5px rgba(15,23,42,.10));
}

/* Dark-canvas variant, toggled on the SVG root when the
   diagram's own background color is dark (independent of
   the app-wide light/dark chrome theme). */

#diagramSvg.dg-dark-canvas .node-text {
    fill: #F1F5F9;
}

#diagramSvg.dg-dark-canvas .node-subtext {
    fill: #94A3B8;
}

#diagramSvg.dg-dark-canvas .node-shadow {
    filter: drop-shadow(0 4px 14px rgba(0,0,0,.45));
}

#diagramSvg.dg-dark-canvas .connection-line {
    stroke: #94A3B8;
}

#diagramSvg.dg-dark-canvas .group-label-text {
    fill: #F1F5F9;
}

.selected-outline {
    fill: none;
    stroke: #2563EB;
    stroke-width: 2;
    stroke-dasharray: 6 4;
    pointer-events: none;
}

.rotate-line {
    stroke: #2563EB;
    stroke-width: 1.5;
    pointer-events: none;
}

.rotate-handle {
    fill: #FFFFFF;
    stroke: #2563EB;
    stroke-width: 2;
    cursor: grab;
    pointer-events: auto;
}

.resize-handle {
    fill: #FFFFFF;
    stroke: #2563EB;
    stroke-width: 2;
    cursor: nwse-resize;
    pointer-events: auto;
}

.connection-line {
    stroke: #475569;
    stroke-width: 2.5;
    fill: none;
}

.connection-selected {
    stroke: #2563EB;
    stroke-width: 3;
    stroke-dasharray: 7 4;
}

.endpoint-handle {
    fill: white;
    stroke: #2563EB;
    stroke-width: 2;
    cursor: crosshair;
}

.expand-hotspot {
    pointer-events: auto;
    cursor: pointer;
    opacity: .55;
    transition: opacity .12s ease;
}

.expand-hotspot:hover {
    opacity: 1;
}

.expand-hotspot circle {
    fill: #2563EB;
    stroke: #FFFFFF;
    stroke-width: 1.5;
}

.expand-hotspot path {
    stroke: #FFFFFF;
    stroke-width: 1.6;
    stroke-linecap: round;
}

/* =========================================================
   CANVAS TOOLBAR
========================================================= */

.dg-canvas-toolbar {
    position: absolute;
    top: 14px;
    left: 14px;
    z-index: 100;
    display: flex;
    align-items: center;
    gap: 3px;
    padding: 5px;
    background: rgba(255,255,255,.97);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    box-shadow: 0 5px 20px rgba(15,23,42,.08);
    pointer-events: auto;
}

[data-theme="dark"] .dg-canvas-toolbar {
    background: rgba(27,34,48,.97);
    box-shadow: 0 5px 20px rgba(0,0,0,.35);
}

.dg-tool-btn {
    width: 34px;
    height: 32px;
    border: none;
    background: transparent;
    border-radius: 7px;
    cursor: pointer;
    color: var(--text-secondary);
    font-weight: 700;
    font-family: inherit;
}

.dg-tool-btn:hover {
    background: var(--hover-bg);
}

.dg-tool-divider {
    width: 1px;
    height: 20px;
    background: var(--border-color);
    margin: 0 2px;
}

.dg-tool-btn.active {
    background: #DBEAFE;
    color: #1D4ED8;
}

[data-theme="dark"] .dg-tool-btn.active {
    background: rgba(37,99,235,.3);
    color: #93C5FD;
}

.dg-zoom-label {
    min-width: 48px;
    text-align: center;
    font-size: 11px;
    color: var(--text-secondary);
    font-weight: 700;
}

/* =========================================================
   PROPERTIES
========================================================= */

.dg-properties {
    background: var(--bg-content);
    border-left: 1px solid var(--border-color);
    overflow-y: auto;
    padding: 16px;
}

.dg-properties-title {
    font-size: 13.5px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 14px;
}

.dg-no-selection {
    color: var(--text-muted);
    font-size: 12px;
    line-height: 1.7;
    background: var(--hover-bg);
    border-radius: 10px;
    padding: 14px;
}

.dg-prop-group {
    margin-bottom: 12px;
}

.dg-prop-group label {
    display: block;
    font-size: 10px;
    font-weight: 700;
    color: var(--text-secondary);
    margin-bottom: 5px;
    text-transform: uppercase;
    letter-spacing: .03em;
}

.dg-prop-group input,
.dg-prop-group select {
    width: 100%;
    box-sizing: border-box;
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 8px 9px;
    font-size: 12px;
    color: var(--text-primary);
    background: var(--hover-bg);
    font-family: inherit;
}

.dg-prop-group input:focus,
.dg-prop-group select:focus {
    outline: none;
    border-color: #2563EB;
    background: var(--bg-content);
}

.dg-prop-row {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 8px;
}

.dg-checkbox-row {
    display: flex;
    flex-wrap: wrap;
    gap: 10px 14px;
}

.dg-prop-group .dg-checkbox {
    display: flex;
    align-items: center;
    gap: 6px;
    margin-bottom: 0;
    font-size: 12px;
    font-weight: 600;
    color: var(--text-primary);
    text-transform: none;
    letter-spacing: normal;
    cursor: pointer;
}

.dg-checkbox input {
    width: auto;
    height: auto;
    padding: 0;
    border: none;
    border-radius: 0;
    background: none;
    cursor: pointer;
}

.dg-canvas-bg-row {
    display: flex;
    align-items: center;
    gap: 6px;
}

.dg-canvas-bg-row input[type="color"] {
    width: 36px;
    height: 34px;
    padding: 2px;
    flex: none;
    cursor: pointer;
}

.dg-preset-btn {
    flex: 1;
    border: 1px solid var(--border-color);
    background: var(--hover-bg);
    border-radius: 8px;
    padding: 8px 5px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 700;
    color: var(--text-primary);
    font-family: inherit;
}

.dg-preset-btn:hover {
    background: #EFF6FF;
    border-color: #93C5FD;
    color: #1D4ED8;
}

.dg-prop-buttons {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 6px;
}

.dg-prop-buttons button {
    border: 1px solid var(--border-color);
    background: var(--hover-bg);
    border-radius: 8px;
    padding: 8px 5px;
    cursor: pointer;
    font-size: 11px;
    font-weight: 600;
    color: var(--text-primary);
    font-family: inherit;
}

.dg-prop-buttons button:hover {
    background: #EFF6FF;
    border-color: #93C5FD;
    color: #1D4ED8;
}

/* =========================================================
   SAVED
========================================================= */

.dg-saved-list {
    margin-top: 18px;
    border-top: 1px solid var(--border-light);
    padding-top: 14px;
}

.dg-saved-item {
    padding: 10px 12px;
    border: 1px solid #F1F5F9;
    border-radius: 9px;
    margin-bottom: 8px;
    background: var(--hover-bg);
}

.dg-saved-info {
    cursor: pointer;
}

.dg-saved-name {
    font-size: 12px;
    font-weight: 600;
    color: var(--text-primary);
}

.dg-saved-meta {
    font-size: 10px;
    color: var(--text-muted);
    margin-top: 2px;
}

.dg-saved-actions {
    display: flex;
    gap: 5px;
    margin-top: 7px;
}

.dg-saved-actions a,
.dg-saved-actions button {
    text-decoration: none;
    font-size: 10px;
    padding: 4px 8px;
    border-radius: 5px;
    border: 1px solid #CBD5E1;
    background: var(--bg-content);
    color: var(--text-primary);
    cursor: pointer;
    font-weight: 600;
}

.dg-saved-actions a:hover,
.dg-saved-actions button:hover {
    background: #EFF6FF;
    color: #1D4ED8;
    border-color: #93C5FD;
}

/* =========================================================
   PAGE TABS
========================================================= */

.dg-page-tabs {
    height: 38px;
    min-height: 38px;
    background: var(--hover-bg);
    border-top: 1px solid var(--border-color);
    display: flex;
    align-items: center;
    gap: 4px;
    padding: 0 10px;
    overflow-x: auto;
}

.dg-page-tab {
    display: flex;
    align-items: center;
    gap: 7px;
    padding: 6px 10px;
    border-radius: 7px 7px 0 0;
    font-size: 12px;
    font-weight: 600;
    color: var(--text-secondary);
    background: transparent;
    cursor: pointer;
    white-space: nowrap;
    border: 1px solid transparent;
    border-bottom: none;
    flex: none;
}

.dg-page-tab:hover {
    background: var(--hover-bg);
}

.dg-page-tab.active {
    background: var(--bg-content);
    color: #1D4ED8;
    border-color: var(--border-color);
}

.dg-page-tab-close {
    font-size: 13px;
    line-height: 1;
    color: var(--text-muted);
    padding: 0 1px;
}

.dg-page-tab-close:hover {
    color: #DC2626;
}

.dg-page-tab-add {
    width: 26px;
    height: 26px;
    border-radius: 6px;
    border: 1px dashed var(--border-color);
    background: none;
    color: var(--text-secondary);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    flex: none;
    font-size: 15px;
    font-family: inherit;
}

.dg-page-tab-add:hover {
    background: #EFF6FF;
    border-color: #93C5FD;
    color: #1D4ED8;
}

/* =========================================================
   TEMPLATE PICKER MODAL
========================================================= */

.dg-modal-overlay {
    position: fixed;
    inset: 0;
    z-index: 300;
    background: rgba(15,23,42,.45);
    display: flex;
    align-items: center;
    justify-content: center;
    animation: modalOverlayFadeIn .18s ease-out;
}

.dg-modal-overlay[hidden] {
    display: none;
}

.dg-modal {
    width: 620px;
    max-width: calc(100vw - 40px);
    max-height: calc(100vh - 60px);
    overflow-y: auto;
    background: var(--bg-content);
    border-radius: 16px;
    box-shadow: 0 30px 70px rgba(0,0,0,.35);
    padding: 20px 22px;
    animation: modalContentPopIn .22s cubic-bezier(.16, 1, .3, 1);
}

@keyframes modalOverlayFadeIn {
    from { opacity: 0; }
    to   { opacity: 1; }
}

@keyframes modalContentPopIn {
    from { opacity: 0; transform: scale(.96) translateY(-8px); }
    to   { opacity: 1; transform: scale(1) translateY(0); }
}

@media (prefers-reduced-motion: reduce) {
    .dg-modal-overlay,
    .dg-modal {
        animation: none;
    }
}

.dg-modal-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 15px;
    font-weight: 800;
    color: var(--text-primary);
}

.dg-modal-header button {
    border: none;
    background: none;
    font-size: 20px;
    line-height: 1;
    color: var(--text-muted);
    cursor: pointer;
    padding: 2px 4px;
}

.dg-modal-header button:hover {
    color: var(--text-primary);
}

.dg-modal-sub {
    font-size: 12px;
    color: var(--text-secondary);
    margin-top: 6px;
    margin-bottom: 16px;
}

.dg-template-grid {
    display: grid;
    grid-template-columns: repeat(3,1fr);
    gap: 12px;
}

.dg-template-card {
    border: 1px solid var(--border-color);
    border-radius: 12px;
    padding: 14px 12px;
    cursor: pointer;
    text-align: left;
    background: var(--bg-content);
    transition: .15s ease;
    display: flex;
    flex-direction: column;
    gap: 8px;
    font-family: inherit;
}

.dg-template-card:hover {
    border-color: #93C5FD;
    box-shadow: 0 8px 20px rgba(15,23,42,.10);
    transform: translateY(-2px);
}

.dg-template-preview {
    height: 74px;
    border-radius: 8px;
    background: var(--hover-bg);
    display: flex;
    align-items: center;
    justify-content: center;
}

.dg-template-preview svg {
    width: 100%;
    height: 100%;
    padding: 8px;
}

.dg-template-name {
    font-size: 12.5px;
    font-weight: 700;
    color: var(--text-primary);
}

.dg-template-desc {
    font-size: 10.5px;
    color: var(--text-muted);
    line-height: 1.4;
}

/* =========================================================
   EXPAND POPUP
========================================================= */

.dg-expand-popup {
    position: fixed;
    z-index: 200;
    width: 200px;
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 12px;
    box-shadow: 0 14px 36px rgba(15,23,42,.20);
    padding: 10px;
}

.dg-expand-popup[hidden] {
    display: none;
}

.dg-expand-popup-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 11px;
    font-weight: 700;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: .03em;
    margin-bottom: 8px;
}

.dg-expand-popup-header button {
    border: none;
    background: none;
    font-size: 15px;
    line-height: 1;
    color: var(--text-muted);
    cursor: pointer;
    padding: 0 2px;
}

.dg-expand-popup-header button:hover {
    color: var(--text-primary);
}

.dg-expand-grid {
    display: grid;
    grid-template-columns: repeat(4,1fr);
    gap: 6px;
}

.dg-expand-item {
    border: 1px solid #EEF1F5;
    border-radius: 9px;
    background: var(--bg-content);
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 8px 4px;
    transition: .12s ease;
}

.dg-expand-item:hover {
    background: var(--hover-bg);
    border-color: #93C5FD;
    transform: translateY(-1px);
}

.dg-expand-item svg {
    width: 18px;
    height: 18px;
}

/* =========================================================
   STATUS
========================================================= */

.dg-status {
    position: absolute;
    bottom: 14px;
    left: 14px;
    background: rgba(17,24,39,.92);
    color: #FFFFFF;
    border-radius: 8px;
    padding: 8px 12px;
    font-size: 11px;
    z-index: 10;
    pointer-events: none;
}

</style>

<div class="dg-page">

    <!-- =====================================================
         TOP BAR
    ====================================================== -->

    <div class="dg-topbar">

        <div class="dg-title-area">

            <div class="dg-logo-mark">
                <svg viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="4" width="7" height="7" rx="1.3"/>
                    <rect x="14" y="4" width="7" height="7" rx="1.3"/>
                    <rect x="8.5" y="14" width="7" height="7" rx="1.3"/>
                    <path d="M6.5 11v3.5M17.5 11v3.5M9.5 7h5"/>
                </svg>
            </div>

            <div>
                <div class="dg-title">
                    Diagram Designer
                </div>

                <div class="dg-subtitle">
                    Logged in as
                    <b><?= h($current_user); ?></b>
                    &middot; <?= h(ucfirst($current_role)); ?>
                </div>
            </div>

            <input
                id="diagramName"
                class="dg-name-input"
                type="text"
                value="<?= h($initial_name); ?>"
                placeholder="Diagram name"
            >

        </div>

        <div class="dg-actions">

            <button
                class="dg-btn dg-btn-ghost"
                onclick="newDiagram()"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>
                New
            </button>

            <button
                class="dg-btn dg-btn-ghost"
                onclick="openTemplatePicker()"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.3"/><rect x="14" y="3" width="7" height="7" rx="1.3"/><rect x="8.5" y="14" width="7" height="7" rx="1.3"/><path d="M6.5 10v2.5h11V10M12 16.5V12.5"/></svg>
                Templates
            </button>

            <button
                class="dg-btn dg-btn-success"
                onclick="saveDiagram()"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h11l3 3v13H5V4Z"/><path d="M8 4v5h7V4M8 14h8v6H8z"/></svg>
                Save
            </button>

            <div class="dg-btn-divider"></div>

            <button
                class="dg-btn dg-btn-primary"
                onclick="exportDiagram('png')"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16.5V19a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2.5M7 10l5 5 5-5M12 15V4"/></svg>
                PNG
            </button>

            <button
                class="dg-btn dg-btn-primary"
                onclick="exportDiagram('jpg')"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16.5V19a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2.5M7 10l5 5 5-5M12 15V4"/></svg>
                JPG
            </button>

            <button
                class="dg-btn dg-btn-ghost"
                onclick="exportDiagram('svg')"
            >
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 16.5V19a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1v-2.5M7 10l5 5 5-5M12 15V4"/></svg>
                SVG
            </button>

        </div>

    </div>


    <!-- =====================================================
         WORKSPACE
    ====================================================== -->

    <div class="dg-workspace">

        <!-- =================================================
             PALETTE
        ================================================== -->

        <div class="dg-palette">

            <!-- BASIC -->

            <div class="dg-palette-title">
                Basic
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('rectangle')">
                    <div class="dg-palette-icon">▭</div>
                    <div class="dg-palette-label">Rectangle</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('rounded')">
                    <div class="dg-palette-icon">▢</div>
                    <div class="dg-palette-label">Rounded</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('circle')">
                    <div class="dg-palette-icon">○</div>
                    <div class="dg-palette-label">Circle</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('diamond')">
                    <div class="dg-palette-icon">◇</div>
                    <div class="dg-palette-label">Diamond</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('text')">
                    <div class="dg-palette-icon">T</div>
                    <div class="dg-palette-label">Label</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('textbox')">
                    <div class="dg-palette-icon">▤</div>
                    <div class="dg-palette-label">Text Box</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('arrow')">
                    <div class="dg-palette-icon">→</div>
                    <div class="dg-palette-label">Arrow</div>
                </button>

                <button class="dg-palette-item" data-icon="dashedarrow" onclick="addObject('arrow', {dashed:true})">
                    <div class="dg-palette-icon">⇢</div>
                    <div class="dg-palette-label">Dashed Arrow</div>
                </button>

                <button class="dg-palette-item" data-icon="line" onclick="addObject('arrow', {arrowhead:false})">
                    <div class="dg-palette-icon">╱</div>
                    <div class="dg-palette-label">Line</div>
                </button>

                <button class="dg-palette-item" data-icon="line" onclick="addObject('arrow', {arrowhead:false, dashed:true})">
                    <div class="dg-palette-icon">┄</div>
                    <div class="dg-palette-label">Dashed Line</div>
                </button>

                <button class="dg-palette-item" data-icon="elbow" onclick="addObject('arrow', {shape:'elbow'})">
                    <div class="dg-palette-icon">⌐</div>
                    <div class="dg-palette-label">Elbow Connector</div>
                </button>

                <button class="dg-palette-item" data-icon="curved" onclick="addObject('arrow', {shape:'curved'})">
                    <div class="dg-palette-icon">〰</div>
                    <div class="dg-palette-label">Curved Connector</div>
                </button>

                <button class="dg-palette-item" data-icon="bidirectional" onclick="addObject('arrow', {arrowStart:true})">
                    <div class="dg-palette-icon">↔</div>
                    <div class="dg-palette-label">Bidirectional</div>
                </button>

                <button class="dg-palette-item" data-icon="freehand" onclick="armFreehandTool()">
                    <div class="dg-palette-icon">✎</div>
                    <div class="dg-palette-label">Free Draw</div>
                </button>

                <button class="dg-palette-item" data-icon="dottedfreehand" onclick="armFreehandTool(true)">
                    <div class="dg-palette-icon">⋯</div>
                    <div class="dg-palette-label">Dotted Free Draw</div>
                </button>

            </div>


            <!-- NETWORK -->

            <div class="dg-palette-title">
                Network
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('router')">
                    <div class="dg-palette-icon">◆</div>
                    <div class="dg-palette-label">Router</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('switch')">
                    <div class="dg-palette-icon">▤</div>
                    <div class="dg-palette-label">Switch</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('firewall')">
                    <div class="dg-palette-icon">🛡</div>
                    <div class="dg-palette-label">Firewall</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('loadbalancer')">
                    <div class="dg-palette-icon">⚖</div>
                    <div class="dg-palette-label">Load Balancer</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('accesspoint')">
                    <div class="dg-palette-icon">⌁</div>
                    <div class="dg-palette-label">Access Point</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('wan')">
                    <div class="dg-palette-icon">☁</div>
                    <div class="dg-palette-label">WAN</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('internet')">
                    <div class="dg-palette-icon">◎</div>
                    <div class="dg-palette-label">Internet</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('vpn')">
                    <div class="dg-palette-icon">🔒</div>
                    <div class="dg-palette-label">VPN</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('network')">
                    <div class="dg-palette-icon">⌘</div>
                    <div class="dg-palette-label">Network</div>
                </button>

            </div>


            <!-- COMPUTE -->

            <div class="dg-palette-title">
                Compute
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('server')">
                    <div class="dg-palette-icon">▤</div>
                    <div class="dg-palette-label">Server</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('rack')">
                    <div class="dg-palette-icon">▥</div>
                    <div class="dg-palette-label">Rack</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('virtualmachine')">
                    <div class="dg-palette-icon">▣</div>
                    <div class="dg-palette-label">Virtual Machine</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('container')">
                    <div class="dg-palette-icon">□</div>
                    <div class="dg-palette-label">Container</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('cluster')">
                    <div class="dg-palette-icon">◉</div>
                    <div class="dg-palette-label">Cluster</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('pc')">
                    <div class="dg-palette-icon">▣</div>
                    <div class="dg-palette-label">PC</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('laptop')">
                    <div class="dg-palette-icon">▱</div>
                    <div class="dg-palette-label">Laptop</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('mobile')">
                    <div class="dg-palette-icon">▯</div>
                    <div class="dg-palette-label">Mobile</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('printer')">
                    <div class="dg-palette-icon">▤</div>
                    <div class="dg-palette-label">Printer</div>
                </button>

            </div>


            <!-- DATA CENTER -->

            <div class="dg-palette-title">
                Data Center
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('database')">
                    <div class="dg-palette-icon">◎</div>
                    <div class="dg-palette-label">Database</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('storage')">
                    <div class="dg-palette-icon">▤</div>
                    <div class="dg-palette-label">Storage</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('san')">
                    <div class="dg-palette-icon">◉</div>
                    <div class="dg-palette-label">SAN</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('nas')">
                    <div class="dg-palette-icon">▥</div>
                    <div class="dg-palette-label">NAS</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('backup')">
                    <div class="dg-palette-icon">↻</div>
                    <div class="dg-palette-label">Backup</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('cloud')">
                    <div class="dg-palette-icon">☁</div>
                    <div class="dg-palette-label">Cloud</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('datacenter')">
                    <div class="dg-palette-icon">▥</div>
                    <div class="dg-palette-label">Data Center</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('rackunit')">
                    <div class="dg-palette-icon">▥</div>
                    <div class="dg-palette-label">Rack Unit</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('ups')">
                    <div class="dg-palette-icon">⚡</div>
                    <div class="dg-palette-label">UPS</div>
                </button>

            </div>


            <!-- SECURITY -->

            <div class="dg-palette-title">
                Security
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('security')">
                    <div class="dg-palette-icon">🛡</div>
                    <div class="dg-palette-label">Security</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('ids')">
                    <div class="dg-palette-icon">!</div>
                    <div class="dg-palette-label">IDS</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('ips')">
                    <div class="dg-palette-icon">!</div>
                    <div class="dg-palette-label">IPS</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('proxy')">
                    <div class="dg-palette-icon">↔</div>
                    <div class="dg-palette-label">Proxy</div>
                </button>

            </div>


            <!-- CLOUD -->

            <div class="dg-palette-title">
                Cloud
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('privatecloud')">
                    <div class="dg-palette-icon">☁</div>
                    <div class="dg-palette-label">Private Cloud</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('publiccloud')">
                    <div class="dg-palette-icon">☁</div>
                    <div class="dg-palette-label">Public Cloud</div>
                </button>

                <button class="dg-palette-item" onclick="addObject('hybridcloud')">
                    <div class="dg-palette-icon">☁</div>
                    <div class="dg-palette-label">Hybrid Cloud</div>
                </button>

            </div>


            <!-- LAYOUT -->

            <div class="dg-palette-title">
                Layout
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('group')">
                    <div class="dg-palette-icon">▧</div>
                    <div class="dg-palette-label">Group Frame</div>
                </button>

            </div>


            <!-- PEOPLE -->

            <div class="dg-palette-title">
                People
            </div>

            <div class="dg-palette-grid">

                <button class="dg-palette-item" onclick="addObject('actor')">
                    <div class="dg-palette-icon">☺</div>
                    <div class="dg-palette-label">User / Actor</div>
                </button>

            </div>

        </div>


        <!-- =================================================
             CANVAS
        ================================================== -->

        <div class="dg-canvas-area">

            <div class="dg-canvas-toolbar">

                <button
                    class="dg-tool-btn"
                    title="Undo"
                    onclick="undo()"
                >↶</button>

                <button
                    class="dg-tool-btn"
                    title="Redo"
                    onclick="redo()"
                >↷</button>

                <button
                    class="dg-tool-btn"
                    title="Zoom Out"
                    onclick="zoomBy(-0.1)"
                >−</button>

                <div
                    class="dg-zoom-label"
                    id="zoomLabel"
                >100%</div>

                <button
                    class="dg-tool-btn"
                    title="Zoom In"
                    onclick="zoomBy(0.1)"
                >+</button>

                <button
                    class="dg-tool-btn"
                    title="Reset Zoom"
                    onclick="resetView()"
                >1:1</button>

                <button
                    class="dg-tool-btn"
                    title="Delete Selected"
                    onclick="deleteSelected()"
                ><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M5 7h14M9 7V4.5h6V7M7 7l1 13h8l1-13"/></svg></button>

                <div class="dg-tool-divider"></div>

                <button
                    class="dg-tool-btn"
                    id="togglePaletteBtn"
                    title="Show/hide the shape palette"
                    onclick="togglePalette()"
                ><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><rect x="3" y="4" width="7" height="16" rx="1.3"/><path d="M14 4h7v16h-7z" opacity=".35"/></svg></button>

                <button
                    class="dg-tool-btn"
                    id="togglePropertiesBtn"
                    title="Show/hide the properties panel"
                    onclick="toggleProperties()"
                ><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M3 4h7v16H3z" opacity=".35"/><rect x="14" y="4" width="7" height="16" rx="1.3"/></svg></button>

                <button
                    class="dg-tool-btn"
                    id="toggleFullscreenBtn"
                    title="Full screen"
                    onclick="toggleFullscreen()"
                ><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="width:15px;height:15px"><path d="M8 3H5a2 2 0 0 0-2 2v3M16 3h3a2 2 0 0 1 2 2v3M8 21H5a2 2 0 0 1-2-2v-3M16 21h3a2 2 0 0 0 2-2v-3"/></svg></button>

            </div>


            <div
                class="dg-viewport"
                id="diagramViewport"
            >

                <svg
                    id="diagramSvg"
                    class="dg-svg"
                    xmlns="http://www.w3.org/2000/svg"
                >

                    <defs>

                        <pattern
                            id="smallGrid"
                            width="20"
                            height="20"
                            patternUnits="userSpaceOnUse"
                        >
                            <path
                                id="smallGridPath"
                                d="M20 0 L0 0 0 20"
                                stroke="#E5E9F0"
                                stroke-width="1"
                                fill="none"
                            />
                        </pattern>

                        <pattern
                            id="largeGrid"
                            width="100"
                            height="100"
                            patternUnits="userSpaceOnUse"
                        >
                            <rect
                                width="100"
                                height="100"
                                fill="url(#smallGrid)"
                            />

                            <path
                                id="largeGridPath"
                                d="M100 0 L0 0 0 100"
                                stroke="#D7DEE7"
                                stroke-width="1.2"
                                fill="none"
                            />
                        </pattern>

                        <marker
                            id="arrowHead"
                            markerWidth="10"
                            markerHeight="10"
                            refX="9"
                            refY="3"
                            orient="auto"
                            markerUnits="strokeWidth"
                        >
                            <path
                                id="arrowHeadPath"
                                d="M0,0 L0,6 L9,3 z"
                                fill="#475569"
                            />
                        </marker>

                        <marker
                            id="arrowHeadStart"
                            markerWidth="10"
                            markerHeight="10"
                            refX="9"
                            refY="3"
                            orient="auto-start-reverse"
                            markerUnits="strokeWidth"
                        >
                            <path
                                id="arrowHeadStartPath"
                                d="M0,0 L0,6 L9,3 z"
                                fill="#475569"
                            />
                        </marker>

                    </defs>

                    <rect
                        id="canvasBackground"
                        x="0"
                        y="0"
                        width="2400"
                        height="1400"
                        fill="<?= h($initial_data['background'] ?? '#0B0F19'); ?>"
                    />

                    <rect
                        id="canvasGrid"
                        x="0"
                        y="0"
                        width="2400"
                        height="1400"
                        fill="url(#largeGrid)"
                    />

                    <g id="objectsLayer"></g>

                    <g id="selectionLayer"></g>

                    <g id="hoverLayer"></g>

                </svg>

            </div>

            <div
                class="dg-status"
                id="diagramStatus"
            >Ready</div>

        </div>


        <!-- =================================================
             PROPERTIES
        ================================================== -->

        <div class="dg-properties">

            <div class="dg-properties-title">
                Canvas
            </div>

            <div class="dg-prop-group">

                <label>Background</label>

                <div class="dg-canvas-bg-row">

                    <input
                        type="color"
                        id="canvasBgInput"
                        value="<?= h($initial_data['background'] ?? '#0B0F19'); ?>"
                        onchange="updateCanvasBackground(this.value)"
                    >

                    <button
                        type="button"
                        class="dg-preset-btn"
                        onclick="applyCanvasPreset('dark')"
                    >Dark</button>

                    <button
                        type="button"
                        class="dg-preset-btn"
                        onclick="applyCanvasPreset('light')"
                    >Light</button>

                </div>

            </div>

            <div class="dg-properties-title">
                Properties
            </div>

            <div id="propertiesContent">

                <div class="dg-no-selection">
                    Select an object on the canvas to edit
                    its properties.
                </div>

            </div>


            <!-- SAVED DIAGRAMS -->

            <div class="dg-saved-list" id="savedList">

                <div class="dg-properties-title">
                    Saved Diagrams
                </div>

                <?php if (!$saved_diagrams): ?>

                    <div class="dg-no-selection" id="savedListEmpty">
                        No saved diagrams yet.
                    </div>

                <?php else: ?>

                    <?php foreach ($saved_diagrams as $saved): ?>

                        <?php
                        $canModify =
                            $isAdmin ||
                            ((string)$saved['created_by'] === (string)$current_user);
                        ?>

                        <div class="dg-saved-item" data-id="<?= (int)$saved['id']; ?>">

                            <div
                                class="dg-saved-info"
                                onclick="openDiagram(<?= (int)$saved['id']; ?>)"
                            >

                                <div class="dg-saved-name">
                                    <?= h($saved['name']); ?>
                                </div>

                                <div class="dg-saved-meta">
                                    By:
                                    <?= h($saved['created_by'] ?: 'System'); ?>
                                </div>

                            </div>

                            <div class="dg-saved-actions">

                                <a
                                    href="?id=<?= (int)$saved['id']; ?>"
                                >
                                    View
                                </a>

                                <?php if ($canModify): ?>

                                    <a
                                        href="?id=<?= (int)$saved['id']; ?>"
                                    >
                                        Edit
                                    </a>

                                    <button
                                        onclick="deleteSavedDiagram(<?= (int)$saved['id']; ?>)"
                                        style="color:#DC2626;"
                                    >
                                        Delete
                                    </button>

                                <?php endif; ?>

                            </div>

                        </div>

                    <?php endforeach; ?>

                <?php endif; ?>

            </div>

        </div>

    </div>


    <!-- =====================================================
         PAGE TABS (multiple flowcharts in one document)
    ====================================================== -->

    <div class="dg-page-tabs" id="pageTabs"></div>


    <!-- =====================================================
         FLOATING EXPAND POPUP
         Opened from a shape's edge hotspots to quickly add
         and auto-connect a new shape in that direction.
    ====================================================== -->

    <div
        id="expandPopup"
        class="dg-expand-popup"
        hidden
    >

        <div class="dg-expand-popup-header">
            <span>Add connected shape</span>
            <button type="button" onclick="closeExpandPopup()">&times;</button>
        </div>

        <div class="dg-expand-grid" id="expandGrid"></div>

    </div>


    <!-- =====================================================
         TEMPLATE PICKER
         Starts a new page pre-built as a hierarchy chart --
         org chart, escalation flow, or a decision hierarchy.
    ====================================================== -->

    <div
        id="templateOverlay"
        class="dg-modal-overlay"
        hidden
        onclick="if(event.target===this) closeTemplatePicker()"
    >

        <div class="dg-modal">

            <div class="dg-modal-header">
                <span>Start a hierarchy chart</span>
                <button type="button" onclick="closeTemplatePicker()">&times;</button>
            </div>

            <div class="dg-modal-sub">
                Adds a new page pre-built with the layout below -- reshape or extend it with the shape hotspots afterward.
            </div>

            <div class="dg-template-grid" id="templateGrid"></div>

        </div>

    </div>

</div>


<script>

/* =========================================================
   INITIAL DATA
========================================================= */

const initialDiagram =
<?= json_encode(
    $initial_data,
    JSON_HEX_TAG |
    JSON_HEX_AMP |
    JSON_HEX_APOS |
    JSON_HEX_QUOT
); ?>;

let currentDiagramId =
<?= (int)$diagram_id; ?>;

const CURRENT_USER =
<?= json_encode($current_user, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;


/* =========================================================
   DIAGRAM STATE
========================================================= */

/*
 * Two document shapes come from the server: the legacy
 * single-page shape (every diagram saved before multi-page
 * support existed) and the multi-page shape. Both are
 * normalized into the same runtime `pages` array so the
 * rest of the editor -- which reads/writes `diagram` as a
 * plain {width,height,background,objects} object -- doesn't
 * need to know which one it started from.
 */
function normalizePageData(data)
{
    data = data || {};

    return {

        width: Number(data.width) || 2400,

        height: Number(data.height) || 1400,

        background: data.background || '#0B0F19',

        objects:
            Array.isArray(data.objects)
                ? data.objects
                : []

    };
}


function normalizeDiagramDocument(raw)
{
    if (raw && Array.isArray(raw.pages) && raw.pages.length) {

        return {

            pages: raw.pages.map(function(p) {

                p = p || {};

                return {
                    name: p.name || 'Page',
                    data: normalizePageData(p.data)
                };

            }),

            activePage:
                Number.isInteger(raw.activePage)
                    ? raw.activePage
                    : 0

        };
    }

    return {

        pages: [{
            name: 'Page 1',
            data: normalizePageData(raw)
        }],

        activePage: 0

    };
}


const normalizedDocument =
    normalizeDiagramDocument(initialDiagram);

let pages =
    normalizedDocument.pages;

let activePageIndex =
    Math.min(
        Math.max(normalizedDocument.activePage, 0),
        pages.length - 1
    );

let diagram =
    pages[activePageIndex].data;


/* =========================================================
   EDITOR STATE
========================================================= */

let selectedId = null;

let zoom = 1;

let panX = 30;

let panY = 30;

let history = [];

let historyIndex = -1;

let dragState = null;

let rotateState = null;

let resizeState = null;

let endpointState = null;

let freehandArmed = false;

let freehandDashedMode = false;

let freehandDraft = null;


/* =========================================================
   DOM
========================================================= */

const svg =
    document.getElementById('diagramSvg');

const objectsLayer =
    document.getElementById('objectsLayer');

const selectionLayer =
    document.getElementById('selectionLayer');

const hoverLayer =
    document.getElementById('hoverLayer');

let hoveredId = null;

const background =
    document.getElementById('canvasBackground');

const grid =
    document.getElementById('canvasGrid');

const viewport =
    document.getElementById('diagramViewport');

const propertiesContent =
    document.getElementById('propertiesContent');

const statusBox =
    document.getElementById('diagramStatus');

const zoomLabel =
    document.getElementById('zoomLabel');

const smallGridPath =
    document.getElementById('smallGridPath');

const largeGridPath =
    document.getElementById('largeGridPath');

const arrowHeadPath =
    document.getElementById('arrowHeadPath');

const arrowHeadStartPath =
    document.getElementById('arrowHeadStartPath');


/* =========================================================
   SYMBOL NAMES
========================================================= */

const TYPE_NAMES = {

    rectangle: 'Rectangle',
    rounded: 'Rounded Rectangle',
    circle: 'Circle',
    diamond: 'Decision',
    text: 'Label',
    textbox: 'Text Box',
    arrow: 'Connector',

    router: 'Router',
    switch: 'Network Switch',
    firewall: 'Firewall',
    loadbalancer: 'Load Balancer',
    accesspoint: 'Wireless Access Point',
    wan: 'WAN',
    internet: 'Internet',
    vpn: 'VPN',
    network: 'Network',

    server: 'Server',
    rack: 'Server Rack',
    virtualmachine: 'Virtual Machine',
    container: 'Container',
    cluster: 'Cluster',
    pc: 'Desktop PC',
    laptop: 'Laptop',
    mobile: 'Mobile Device',
    printer: 'Printer',

    database: 'Database',
    storage: 'Storage',
    san: 'SAN',
    nas: 'NAS',
    backup: 'Backup',
    cloud: 'Cloud',
    datacenter: 'Data Center',
    rackunit: 'Rack Unit',
    ups: 'UPS',

    security: 'Security',
    ids: 'Intrusion Detection',
    ips: 'Intrusion Prevention',
    proxy: 'Proxy',

    privatecloud: 'Private Cloud',
    publiccloud: 'Public Cloud',
    hybridcloud: 'Hybrid Cloud',

    group: 'Group Frame',
    actor: 'User / Actor'
};


/* =========================================================
   COLORS
========================================================= */

const TYPE_COLORS = {

    router: '#DBEAFE',
    switch: '#E0F2FE',
    firewall: '#FEE2E2',
    loadbalancer: '#F3E8FF',
    accesspoint: '#DCFCE7',
    wan: '#E0E7FF',
    internet: '#DBEAFE',
    vpn: '#EDE9FE',
    network: '#E0F2FE',

    server: '#F1F5F9',
    rack: '#E2E8F0',
    virtualmachine: '#DBEAFE',
    container: '#DCFCE7',
    cluster: '#FEF3C7',
    pc: '#F8FAFC',
    laptop: '#F8FAFC',
    mobile: '#F8FAFC',
    printer: '#F8FAFC',

    database: '#FEF3C7',
    storage: '#E0F2FE',
    san: '#E0E7FF',
    nas: '#E0F2FE',
    backup: '#DCFCE7',
    cloud: '#DBEAFE',
    datacenter: '#F1F5F9',
    rackunit: '#E2E8F0',
    ups: '#FEF3C7',

    security: '#FEE2E2',
    ids: '#FEE2E2',
    ips: '#FECACA',
    proxy: '#F3E8FF',

    privatecloud: '#E0E7FF',
    publiccloud: '#DBEAFE',
    hybridcloud: '#DCFCE7',

    group: 'transparent',
    actor: '#CFFAFE'
};


/* =========================================================
   CATEGORIES + ACCENT COLORS

   Drives both the palette icon badges and the accent
   (stroke / icon) color used on the canvas for shapes
   that carry a distinct icon glyph.
========================================================= */

const TYPE_CATEGORY = {

    rectangle: 'basic', rounded: 'basic', circle: 'basic',
    diamond: 'basic', text: 'basic', textbox: 'basic',
    arrow: 'basic', dashedarrow: 'basic', line: 'basic',
    freehand: 'basic',

    router: 'network', switch: 'network', firewall: 'network',
    loadbalancer: 'network', accesspoint: 'network', wan: 'network',
    internet: 'network', vpn: 'network', network: 'network',

    server: 'compute', rack: 'compute', virtualmachine: 'compute',
    container: 'compute', cluster: 'compute', pc: 'compute',
    laptop: 'compute', mobile: 'compute', printer: 'compute',

    database: 'datacenter', storage: 'datacenter', san: 'datacenter',
    nas: 'datacenter', backup: 'datacenter', cloud: 'datacenter',
    datacenter: 'datacenter', rackunit: 'datacenter', ups: 'datacenter',

    security: 'security', ids: 'security', ips: 'security',
    proxy: 'security',

    privatecloud: 'cloud', publiccloud: 'cloud', hybridcloud: 'cloud',

    group: 'layout',
    actor: 'people'

};

const CATEGORY_ACCENT = {
    basic: '#64748B',
    network: '#2563EB',
    compute: '#7C3AED',
    datacenter: '#B45309',
    security: '#DC2626',
    cloud: '#0891B2',
    layout: '#EA580C',
    people: '#0E7490'
};


/* =========================================================
   ICON LIBRARY

   Compact 24x24 line-icon paths, stroke=currentColor.
   Shared by the palette badges and by the canvas glyphs
   drawn on top of a handful of network/security shapes.
========================================================= */

const ICONS = {

    rectangle: '<rect x="4" y="6" width="16" height="12" rx="1.5"/>',
    rounded: '<rect x="4" y="6" width="16" height="12" rx="4"/>',
    circle: '<circle cx="12" cy="12" r="8"/>',
    diamond: '<path d="M12 4 20 12 12 20 4 12Z"/>',
    text: '<path d="M5 6h14M12 6v12"/>',
    textbox: '<rect x="4" y="6" width="16" height="12" rx="1.5"/><path d="M7 10h10M7 13h7"/>',
    arrow: '<path d="M4 12h13M12 7l5 5-5 5"/>',
    dashedarrow: '<path d="M3.5 12h2.4M8.3 12h2.4M13.1 12h2.4" stroke-dasharray="0"/><path d="M17.5 12h2M14 7l5.5 5-5.5 5"/>',
    line: '<path d="M4 18 20 6"/>',
    freehand: '<path d="M4 17c2-1 3-6 5-7s2 5 4 4 2-6 4-6 2 4 3 3"/>',
    dottedfreehand: '<path d="M4 17c2-1 3-6 5-7s2 5 4 4 2-6 4-6 2 4 3 3" stroke-dasharray="2.4 3"/>',
    elbow: '<path d="M4 6h8v12h8"/><path d="M17 15l3 3-3 3"/>',
    curved: '<path d="M4 18C4 9 20 15 20 6"/><path d="M17 4l3 2-2 3"/>',
    bidirectional: '<path d="M4 12h16"/><path d="M8 7l-4 5 4 5M16 7l4 5-4 5"/>',

    router: '<rect x="4" y="9" width="16" height="7" rx="1.5"/><path d="M8 9V6M16 9V6"/><circle cx="8" cy="12.5" r=".7" fill="currentColor" stroke="none"/><circle cx="12" cy="12.5" r=".7" fill="currentColor" stroke="none"/><circle cx="16" cy="12.5" r=".7" fill="currentColor" stroke="none"/>',
    switch: '<rect x="3" y="8" width="18" height="8" rx="1.5"/><path d="M6.5 12h.01M9.5 12h.01M12.5 12h.01M15.5 12h.01M18 12h.01" stroke-width="2.4"/>',
    firewall: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z"/><path d="M7.5 9.5h9M7.5 12.5h9M7.5 15.5h5.5"/>',
    loadbalancer: '<circle cx="5.5" cy="12" r="1.8"/><circle cx="18.5" cy="6" r="1.8"/><circle cx="18.5" cy="12" r="1.8"/><circle cx="18.5" cy="18" r="1.8"/><path d="M7.3 12h2.7M11.5 12l3-4.7M11.5 12h3M11.5 12l3 4.7"/>',
    accesspoint: '<path d="M5 9.5a10 10 0 0 1 14 0M7.8 13a6 6 0 0 1 8.4 0"/><circle cx="12" cy="18.5" r="1.3" fill="currentColor" stroke="none"/>',
    wan: '<circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.6 2.4 2.6 13.6 0 16M12 4c-2.6 2.4-2.6 13.6 0 16"/>',
    internet: '<circle cx="12" cy="12" r="8"/><path d="M4.5 9.5h15M4.5 14.5h15M9.3 4.3a15 15 0 0 0 0 15.4M14.7 4.3a15 15 0 0 0 0 15.4"/>',
    vpn: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z"/><rect x="9.3" y="11" width="5.4" height="4.2" rx="1"/><path d="M10.2 11V9.6a1.8 1.8 0 0 1 3.6 0V11"/>',
    network: '<circle cx="6" cy="6" r="2"/><circle cx="18" cy="6" r="2"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/><circle cx="12" cy="12" r="2.2"/><path d="M7.6 7.4l2.8 3.2M16.4 7.4l-2.8 3.2M7.6 16.6l2.8-3.2M16.4 16.6l-2.8-3.2"/>',

    server: '<rect x="4" y="4" width="16" height="6.5" rx="1.3"/><rect x="4" y="13.5" width="16" height="6.5" rx="1.3"/><circle cx="7.2" cy="7.2" r=".8" fill="currentColor" stroke="none"/><circle cx="7.2" cy="16.8" r=".8" fill="currentColor" stroke="none"/>',
    rack: '<rect x="5" y="3" width="14" height="18" rx="1.3"/><path d="M7.5 6.5h9M7.5 9.5h9M7.5 12.5h9M7.5 15.5h9M7.5 18.2h9"/>',
    virtualmachine: '<rect x="3" y="5" width="18" height="11.5" rx="1.5"/><rect x="7" y="8" width="10" height="5.5" rx="1"/><path d="M9 19.5h6"/>',
    container: '<rect x="4" y="5" width="16" height="14" rx="1.5"/><path d="M4 10.3h16M9.3 5v14M14.7 5v14"/>',
    cluster: '<rect x="3" y="9.5" width="7.5" height="7.5" rx="1.2"/><rect x="13.5" y="9.5" width="7.5" height="7.5" rx="1.2"/><rect x="8.3" y="3" width="7.5" height="7.5" rx="1.2"/>',
    pc: '<rect x="4" y="4" width="16" height="11" rx="1.3"/><path d="M9 19.5h6M12 15v4.5"/>',
    laptop: '<rect x="5" y="5" width="14" height="9" rx="1.2"/><path d="M3 18h18l-2-3H5l-2 3Z"/>',
    mobile: '<rect x="8" y="3" width="8" height="18" rx="2"/><path d="M11 18.3h2"/>',
    printer: '<path d="M6.5 8V4.3h11V8"/><rect x="4" y="8" width="16" height="7" rx="1.3"/><rect x="7.5" y="14" width="9" height="5.7" rx="1"/>',

    database: '<ellipse cx="12" cy="6" rx="7" ry="3"/><path d="M5 6v6c0 1.7 3.1 3 7 3s7-1.3 7-3V6"/><path d="M5 12v6c0 1.7 3.1 3 7 3s7-1.3 7-3v-6"/>',
    storage: '<rect x="4" y="4" width="16" height="16" rx="1.5"/><path d="M4 9.3h16M4 14.7h16"/><circle cx="7.2" cy="6.6" r=".7" fill="currentColor" stroke="none"/>',
    san: '<circle cx="12" cy="12" r="8"/><path d="M8 9.5h8M8 12h8M8 14.5h5"/>',
    nas: '<rect x="4" y="7.5" width="16" height="10.5" rx="1.5"/><path d="M4 12.7h16"/><circle cx="7.2" cy="10" r=".7" fill="currentColor" stroke="none"/><path d="M12 3v4.2M9.3 3.5l2.7 3.7 2.7-3.7"/>',
    backup: '<path d="M4.5 12a7.5 7.5 0 1 1 2.2 5.3"/><path d="M4.5 17v-4.2h4.2"/>',
    cloud: '<path d="M7.2 18a4.4 4.4 0 0 1-.6-8.75A5.4 5.4 0 0 1 17.2 8.1 3.9 3.9 0 0 1 17 18H7.2Z"/>',
    datacenter: '<rect x="4" y="3" width="16" height="18" rx="1.3"/><path d="M7.8 6.8h2.2v2H7.8ZM14 6.8h2.2v2H14ZM7.8 10.8h2.2v2H7.8ZM14 10.8h2.2v2H14ZM7.8 14.8h2.2v2H7.8ZM14 14.8h2.2v2H14Z" fill="currentColor" stroke="none"/>',
    rackunit: '<rect x="4" y="9.5" width="16" height="5.5" rx="1"/><circle cx="7" cy="12.2" r=".7" fill="currentColor" stroke="none"/><path d="M10.7 12.2h6.8"/>',
    ups: '<rect x="3.5" y="6.5" width="15" height="10.5" rx="1.5"/><path d="M19 10v4"/><path d="M12.3 8.7l-3 5h2.6l-.9 3.4 3.4-5.5h-2.5l.9-2.9Z" fill="currentColor" stroke="none"/>',

    security: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z"/><path d="M9 12l2 2 4-4.3"/>',
    ids: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z"/><path d="M12 8.3v5"/><circle cx="12" cy="16" r=".9" fill="currentColor" stroke="none"/>',
    ips: '<path d="M12 3l7 3v5c0 4.5-3 8-7 10-4-2-7-5.5-7-10V6l7-3Z"/><path d="M9.3 9.3l5.4 5.4M14.7 9.3l-5.4 5.4"/>',
    proxy: '<path d="M4 8.3h13M12.7 4.6l4 3.7-4 3.7"/><path d="M20 15.7H7M11.3 12l-4 3.7 4 3.7"/>',

    privatecloud: '<path d="M7.2 18a4.4 4.4 0 0 1-.6-8.75A5.4 5.4 0 0 1 17.2 8.1 3.9 3.9 0 0 1 17 18H7.2Z"/><rect x="10" y="12.8" width="4" height="3" rx=".6" fill="currentColor" stroke="none"/>',
    publiccloud: '<path d="M7.2 18a4.4 4.4 0 0 1-.6-8.75A5.4 5.4 0 0 1 17.2 8.1 3.9 3.9 0 0 1 17 18H7.2Z"/><circle cx="12" cy="13.2" r="1.5"/>',
    hybridcloud: '<path d="M7.2 15.5a4.4 4.4 0 0 1-.6-8.75A5.4 5.4 0 0 1 17.2 5.6 3.9 3.9 0 0 1 17 15.5H7.2Z"/><path d="M9 20l-2-2 2-2M15 20l2-2-2-2"/>',

    group: '<rect x="3.5" y="3.5" width="17" height="17" rx="2"/><path d="M3.5 8.3h5.5V3.5"/>',
    actor: '<circle cx="12" cy="8.3" r="3.3"/><path d="M5 19.5c0-3.6 3.1-6 7-6s7 2.4 7 6"/>'

};

function uid()
{
    return 'obj_' +
        Date.now() +
        '_' +
        Math.random()
            .toString(36)
            .substring(2, 9);
}


function cloneObject(obj)
{
    return JSON.parse(JSON.stringify(obj));
}


function escapeHtml(str)
{
    return String(str ?? '')
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#039;');
}


function svgEl(tag, attrs = {})
{
    const el =
        document.createElementNS(
            'http://www.w3.org/2000/svg',
            tag
        );

    Object.entries(attrs).forEach(
        ([key,value]) =>
            el.setAttribute(key,value)
    );

    return el;
}


function textEl(
    text,
    x,
    y,
    className = 'node-text',
    size = 14
)
{
    const el =
        svgEl('text', {
            x: x,
            y: y,
            class: className
        });

    el.setAttribute(
        'font-size',
        size
    );

    el.textContent = text || '';

    return el;
}


/* =========================================================
   ICON RENDERING
========================================================= */

function iconGroup(type, cx, cy, size, color)
{
    const markup = ICONS[type];

    if (!markup) {
        return svgEl('g', {});
    }

    const scale = size / 24;

    const g =
        svgEl('g', {

            transform:
                `translate(${cx - size / 2} ${cy - size / 2}) scale(${scale})`,

            fill: 'none',

            stroke: color,

            'stroke-width': 1.7,

            'stroke-linecap': 'round',

            'stroke-linejoin': 'round'

        });

    g.innerHTML = markup;

    return g;
}


function isDarkColor(hex)
{
    if (typeof hex !== 'string') {
        return false;
    }

    const m =
        hex.trim().match(
            /^#?([0-9a-f]{6})$/i
        );

    if (!m) {
        return false;
    }

    const n = parseInt(m[1], 16);

    const r = (n >> 16) & 255;

    const g = (n >> 8) & 255;

    const b = n & 255;

    const luminance =
        (0.299 * r + 0.587 * g + 0.114 * b) / 255;

    return luminance < 0.5;
}


function hexToRgba(hex, alpha)
{
    const m =
        String(hex).trim().match(
            /^#?([0-9a-f]{6})$/i
        );

    if (!m) {
        return hex;
    }

    const n = parseInt(m[1], 16);

    const r = (n >> 16) & 255;

    const g = (n >> 8) & 255;

    const b = n & 255;

    return `rgba(${r},${g},${b},${alpha})`;
}


/* =========================================================
   PALETTE ICONS

   The palette buttons are plain server-rendered HTML;
   replace their placeholder glyph with a real icon badge
   colored per category.
========================================================= */

function initPaletteIcons()
{
    document
        .querySelectorAll(
            '.dg-palette-item[onclick^="addObject("],' +
            '.dg-palette-item[data-icon]'
        )
        .forEach(btn => {

            const m =
                btn.getAttribute('onclick')
                    .match(/addObject\('([a-z]+)'/);

            /*
             * A few palette buttons create the same
             * underlying object type with different default
             * fields (e.g. a dashed arrow is still type
             * 'arrow'), or don't create an object at all
             * (the freehand tool arms a draw mode instead)
             * -- data-icon lets those show their own icon
             * independent of what addObject() sees.
             */
            const type = m ? m[1] : btn.dataset.icon;

            if (!type) {
                return;
            }

            const iconKey =
                btn.dataset.icon || type;

            const category =
                TYPE_CATEGORY[type] || 'basic';

            const iconBox =
                btn.querySelector('.dg-palette-icon');

            if (!iconBox || !ICONS[iconKey]) {
                return;
            }

            iconBox.classList.add('dg-icon-' + category);

            iconBox.innerHTML =
                `<svg viewBox="0 0 24 24" fill="none" ` +
                `stroke="currentColor" stroke-width="1.7" ` +
                `stroke-linecap="round" stroke-linejoin="round">` +
                ICONS[iconKey] +
                `</svg>`;

        });
}


function getObject(id)
{
    return diagram.objects.find(
        obj => obj.id === id
    );
}


/*
 * Shared by renderObject() and renderSelection() so the
 * highlighted outline always matches what's actually drawn
 * -- straight is a plain line, elbow/curved are SVG paths.
 */
function arrowGeometry(obj)
{
    const shape = obj.shape || 'straight';

    if (shape === 'elbow') {

        const dx = obj.x2 - obj.x;
        const dy = obj.y2 - obj.y;

        let d;

        if (Math.abs(dx) >= Math.abs(dy)) {
            const midX = obj.x + dx / 2;
            d = `M ${obj.x} ${obj.y} L ${midX} ${obj.y} L ${midX} ${obj.y2} L ${obj.x2} ${obj.y2}`;
        } else {
            const midY = obj.y + dy / 2;
            d = `M ${obj.x} ${obj.y} L ${obj.x} ${midY} L ${obj.x2} ${midY} L ${obj.x2} ${obj.y2}`;
        }

        return { tag: 'path', d };
    }

    if (shape === 'curved') {

        const mx = (obj.x + obj.x2) / 2;
        const my = (obj.y + obj.y2) / 2;

        const dx = obj.x2 - obj.x;
        const dy = obj.y2 - obj.y;

        const len = Math.hypot(dx, dy) || 1;

        const nx = -dy / len;
        const ny = dx / len;

        const bend = Math.min(60, len * 0.25);

        const cx = mx + nx * bend;
        const cy = my + ny * bend;

        return {
            tag: 'path',
            d: `M ${obj.x} ${obj.y} Q ${cx} ${cy} ${obj.x2} ${obj.y2}`
        };
    }

    return { tag: 'line' };
}


function freehandBounds(obj)
{
    const points = obj.points || [];

    if (!points.length) {
        return null;
    }

    let minX = points[0].x;
    let maxX = points[0].x;
    let minY = points[0].y;
    let maxY = points[0].y;

    points.forEach(pt => {

        if (pt.x < minX) minX = pt.x;
        if (pt.x > maxX) maxX = pt.x;
        if (pt.y < minY) minY = pt.y;
        if (pt.y > maxY) maxY = pt.y;

    });

    return { minX, maxX, minY, maxY };
}


function setStatus(text)
{
    statusBox.textContent = text;

    clearTimeout(window.dgStatusTimer);

    window.dgStatusTimer =
        setTimeout(
            () => {
                statusBox.textContent = 'Ready';
            },
            1800
        );
}


/* =========================================================
   HISTORY
========================================================= */

function pushHistory()
{
    const snapshot =
        JSON.stringify(diagram);

    history =
        history.slice(
            0,
            historyIndex + 1
        );

    history.push(snapshot);

    /*
     * Keep history manageable.
     */
    if (history.length > 100) {
        history.shift();
    }

    historyIndex =
        history.length - 1;
}


function undo()
{
    if (historyIndex <= 0) {
        return;
    }

    historyIndex--;

    diagram =
        JSON.parse(
            history[historyIndex]
        );

    selectedId = null;

    renderCanvas();

    renderPropertiesPanel();
}


function redo()
{
    if (
        historyIndex >=
        history.length - 1
    ) {
        return;
    }

    historyIndex++;

    diagram =
        JSON.parse(
            history[historyIndex]
        );

    selectedId = null;

    renderCanvas();

    renderPropertiesPanel();
}


/* =========================================================
   CREATE OBJECT
========================================================= */

function createObject(type,x,y)
{
    let w = 150;

    let h = 80;

    if (type === 'circle') {
        w = 100;
        h = 100;
    }

    if (type === 'text') {
        w = 180;
        h = 45;
    }

    if (type === 'textbox') {
        w = 220;
        h = 100;
    }

    if (
        [
            'router',
            'switch',
            'firewall',
            'loadbalancer',
            'accesspoint',
            'server',
            'database',
            'storage',
            'san',
            'nas',
            'virtualmachine',
            'container',
            'pc',
            'laptop',
            'printer',
            'proxy'
        ].includes(type)
    ) {
        w = 160;
        h = 90;
    }

    if (type === 'rack') {
        w = 150;
        h = 220;
    }

    if (type === 'datacenter') {
        w = 300;
        h = 220;
    }

    if (type === 'cloud') {
        w = 180;
        h = 110;
    }

    if (
        [
            'wan',
            'internet',
            'vpn',
            'network',
            'privatecloud',
            'publiccloud',
            'hybridcloud'
        ].includes(type)
    ) {
        w = 180;
        h = 110;
    }

    if (type === 'actor') {
        w = 100;
        h = 120;
    }

    if (type === 'group') {
        w = 380;
        h = 260;
    }

    const dark =
        isDarkColor(diagram.background);

    const category =
        TYPE_CATEGORY[type] || 'basic';

    const accent =
        CATEGORY_ACCENT[category] || '#334155';

    /*
     * Arrow is a line object.
     * It deliberately does NOT use w/h.
     */
    if (type === 'arrow') {

        return {

            id: uid(),

            type: 'arrow',

            x: x,

            y: y,

            x2: x + 180,

            y2: y,

            rotation: 0,

            stroke:
                dark ? '#94A3B8' : '#475569',

            strokeWidth: 2.5,

            arrowhead: true,

            arrowStart: false,

            dashed: false,

            shape: 'straight'

        };
    }

    /*
     * Group frame: a labelled container, not a filled
     * shape -- it should read through to whatever sits
     * behind/inside it. Fill is kept as a plain solid hex
     * (so the Fill color picker stays usable) and the
     * translucency is applied separately as fillOpacity.
     */
    if (type === 'group') {

        return {

            id: uid(),

            type: 'group',

            x: x,

            y: y,

            w: w,

            h: h,

            rotation: 0,

            text: 'Group',

            fill: accent,

            fillOpacity: dark ? 0.06 : 0.05,

            stroke: accent,

            strokeWidth: 2,

            fontSize: 11

        };
    }

    /*
     * On a dark canvas, icon-bearing categories get a
     * translucent tinted "glass chip" fill with an accent
     * border instead of the flat pastel used on a light
     * canvas -- closer to how real architecture diagrams
     * read against a dark background. fill stays a plain
     * solid hex (valid for the color-picker input) and the
     * translucency rides along as a separate fillOpacity
     * field applied at render time.
     *
     * Basic shapes (rectangle/rounded/circle/diamond/label)
     * are plain generic cards, not accent chips -- on a dark
     * canvas a leftover white fill made their own label text
     * (which turns light for readability) nearly invisible,
     * so they get a solid dark card fill instead, with a
     * lighter border so the shape still reads against the
     * dark canvas behind it.
     */
    let fill;
    let fillOpacity;
    let stroke;

    if (type === 'actor') {

        fill = accent;
        fillOpacity = 1;
        stroke = dark ? accent : '#334155';

    } else if (category === 'basic') {

        fill = dark ? '#1E293B' : '#FFFFFF';
        fillOpacity = 1;
        stroke = dark ? '#64748B' : '#334155';

    } else if (dark) {

        fill = accent;
        fillOpacity = 0.16;
        stroke = accent;

    } else {

        fill = TYPE_COLORS[type] || '#FFFFFF';
        fillOpacity = 1;
        stroke = '#334155';

    }

    return {

        id: uid(),

        type: type,

        x: x,

        y: y,

        w: w,

        h: h,

        rotation: 0,

        text:
            TYPE_NAMES[type] || type,

        fill: fill,

        fillOpacity: fillOpacity,

        stroke: stroke,

        strokeWidth: 1.6,

        fontSize: 14

    };
}


/* =========================================================
   ADD OBJECT
========================================================= */

function addObject(type, overrides)
{
    /*
     * Picking any other tool while Free Draw is armed exits
     * draw mode, so the next canvas click doesn't
     * unexpectedly start a stroke.
     */
    cancelFreehand();

    pushHistory();

    /*
     * Slight offset each time.
     * This prevents every new symbol from sitting exactly
     * on top of the previous one.
     */
    const offset =
        (diagram.objects.length % 8) * 25;

    const obj =
        createObject(
            type,
            300 + offset,
            180 + offset
        );

    /*
     * A few palette buttons create the same base type with
     * different starting style (e.g. a dashed arrow, or a
     * line with no arrowhead).
     */
    if (overrides) {
        Object.assign(obj, overrides);
    }

    diagram.objects.push(obj);

    selectedId = obj.id;

    renderCanvas();

    renderPropertiesPanel();

    setStatus(
        (TYPE_NAMES[type] || type) +
        ' added'
    );
}


/* =========================================================
   RENDER CANVAS
========================================================= */

function renderCanvas()
{
    clearHoverHotspots();

    background.setAttribute(
        'width',
        diagram.width
    );

    background.setAttribute(
        'height',
        diagram.height
    );

    background.setAttribute(
        'fill',
        diagram.background
    );

    /*
     * Each page can have its own background -- keep the
     * picker in the Canvas panel in sync whenever the active
     * page (or its background) changes.
     */
    const canvasBgInput =
        document.getElementById('canvasBgInput');

    if (canvasBgInput && canvasBgInput.value !== diagram.background) {
        canvasBgInput.value = diagram.background;
    }

    grid.setAttribute(
        'width',
        diagram.width
    );

    grid.setAttribute(
        'height',
        diagram.height
    );

    const dark =
        isDarkColor(diagram.background);

    svg.classList.toggle('dg-dark-canvas', dark);

    if (smallGridPath) {
        smallGridPath.setAttribute(
            'stroke',
            dark ? 'rgba(255,255,255,.07)' : '#E5E9F0'
        );
    }

    if (largeGridPath) {
        largeGridPath.setAttribute(
            'stroke',
            dark ? 'rgba(255,255,255,.12)' : '#D7DEE7'
        );
    }

    if (arrowHeadPath) {
        arrowHeadPath.setAttribute(
            'fill',
            dark ? '#94A3B8' : '#475569'
        );
    }

    if (arrowHeadStartPath) {
        arrowHeadStartPath.setAttribute(
            'fill',
            dark ? '#94A3B8' : '#475569'
        );
    }

    objectsLayer.innerHTML = '';

    selectionLayer.innerHTML = '';

    diagram.objects.forEach(
        obj => {

            objectsLayer.appendChild(
                renderObject(obj)
            );

        }
    );

    if (selectedId) {

        const obj =
            getObject(selectedId);

        if (obj) {
            renderSelection(obj);
        }

    }

    updateTransform();
}


/* =========================================================
   CANVAS BACKGROUND
========================================================= */

function updateCanvasBackground(value)
{
    diagram.background = value;

    document.getElementById('canvasBgInput').value = value;

    renderCanvas();

    setStatus('Canvas background updated');
}


function applyCanvasPreset(which)
{
    updateCanvasBackground(
        which === 'dark' ? '#0B0F19' : '#FFFFFF'
    );
}


/* =========================================================
   PAGES (multiple flowcharts in one document)
========================================================= */

function switchToPage(index)
{
    if (
        index === activePageIndex ||
        index < 0 ||
        index >= pages.length
    ) {
        return;
    }

    pages[activePageIndex].data = diagram;

    activePageIndex = index;

    diagram = pages[activePageIndex].data;

    selectedId = null;

    history = [];

    historyIndex = -1;

    pushHistory();

    renderCanvas();

    renderPropertiesPanel();

    renderPageTabs();

    setStatus('Switched to ' + pages[activePageIndex].name);
}


function addPage()
{
    pages[activePageIndex].data = diagram;

    pages.push({

        name: 'Page ' + (pages.length + 1),

        data: {
            width: 2400,
            height: 1400,
            background: diagram.background,
            objects: []
        }

    });

    switchToPage(pages.length - 1);
}


function renamePage(index)
{
    const current = pages[index].name;

    const name = prompt('Page name:', current);

    if (name === null) {
        return;
    }

    pages[index].name = name.trim() || current;

    renderPageTabs();
}


function deletePage(index)
{
    if (pages.length <= 1) {
        alert('A document needs at least one page.');
        return;
    }

    if (
        !confirm(
            'Delete "' + pages[index].name + '"? ' +
            'This cannot be undone.'
        )
    ) {
        return;
    }

    const wasActive =
        index === activePageIndex;

    pages.splice(index, 1);

    if (wasActive) {

        activePageIndex =
            Math.min(index, pages.length - 1);

        diagram = pages[activePageIndex].data;

        selectedId = null;

        history = [];

        historyIndex = -1;

        pushHistory();

        renderCanvas();

        renderPropertiesPanel();

    } else if (index < activePageIndex) {

        activePageIndex--;

    }

    renderPageTabs();

    setStatus('Page deleted');
}


function renderPageTabs()
{
    const bar =
        document.getElementById('pageTabs');

    if (!bar) {
        return;
    }

    bar.innerHTML = '';

    pages.forEach(function(page, i) {

        const tab =
            document.createElement('div');

        tab.className =
            'dg-page-tab' +
            (i === activePageIndex ? ' active' : '');

        tab.onclick = function() {
            switchToPage(i);
        };

        tab.ondblclick = function(e) {
            e.stopPropagation();
            renamePage(i);
        };

        const label =
            document.createElement('span');

        label.textContent = page.name;

        tab.appendChild(label);

        if (pages.length > 1) {

            const close =
                document.createElement('span');

            close.className = 'dg-page-tab-close';

            close.textContent = '×';

            close.title = 'Delete page';

            close.onclick = function(e) {
                e.stopPropagation();
                deletePage(i);
            };

            tab.appendChild(close);

        }

        bar.appendChild(tab);

    });

    const addBtn =
        document.createElement('button');

    addBtn.type = 'button';

    addBtn.className = 'dg-page-tab-add';

    addBtn.title = 'Add page';

    addBtn.textContent = '+';

    addBtn.onclick = addPage;

    bar.appendChild(addBtn);
}


/* =========================================================
   HIERARCHY TEMPLATES

   Each builder returns a ready-made object list for a new
   page -- org chart, escalation flow, decision hierarchy.
   Styling reads the current page's theme (dark/light) so a
   template matches whatever the user's been working in.
========================================================= */

function tplStyle(dark, kind)
{
    if (kind === 'terminal') {
        return dark
            ? { fill: '#10B981', stroke: '#10B981', fillOpacity: .2 }
            : { fill: '#D1FAE5', stroke: '#059669', fillOpacity: 1 };
    }

    if (kind === 'decision') {
        return dark
            ? { fill: '#D97706', stroke: '#D97706', fillOpacity: .22 }
            : { fill: '#FEF3C7', stroke: '#D97706', fillOpacity: 1 };
    }

    return dark
        ? { fill: '#1E293B', stroke: '#64748B', fillOpacity: 1 }
        : { fill: '#FFFFFF', stroke: '#334155', fillOpacity: 1 };
}


function tplNode(type, x, y, w, h, text, kind, dark)
{
    return Object.assign(
        {
            id: uid(),
            type: type,
            x: x,
            y: y,
            w: w,
            h: h,
            rotation: 0,
            text: text,
            strokeWidth: 1.6,
            fontSize: 13
        },
        tplStyle(dark, kind)
    );
}


function tplConnect(a, b, dark, shape)
{
    return {
        id: uid(),
        type: 'arrow',
        x: a.x + a.w / 2,
        y: a.y + a.h,
        x2: b.x + b.w / 2,
        y2: b.y,
        rotation: 0,
        stroke: dark ? '#94A3B8' : '#475569',
        strokeWidth: 2,
        arrowhead: true,
        arrowStart: false,
        dashed: false,
        shape: shape || 'elbow'
    };
}


function buildOrgChartTemplate()
{
    const dark = isDarkColor(diagram.background);
    const objects = [];

    const ceo = tplNode('rounded', 1010, 80, 180, 70, 'CEO', 'terminal', dark);
    const vpEng = tplNode('rounded', 660, 260, 170, 65, 'VP Engineering', 'process', dark);
    const vpSales = tplNode('rounded', 925, 260, 170, 65, 'VP Sales', 'process', dark);
    const vpOps = tplNode('rounded', 1190, 260, 170, 65, 'VP Operations', 'process', dark);
    const engMgr = tplNode('rectangle', 560, 430, 170, 65, 'Engineering Manager', 'process', dark);
    const qaMgr = tplNode('rectangle', 760, 430, 170, 65, 'QA Manager', 'process', dark);

    objects.push(ceo, vpEng, vpSales, vpOps, engMgr, qaMgr);

    objects.push(
        tplConnect(ceo, vpEng, dark),
        tplConnect(ceo, vpSales, dark),
        tplConnect(ceo, vpOps, dark),
        tplConnect(vpEng, engMgr, dark),
        tplConnect(vpEng, qaMgr, dark)
    );

    return objects;
}


function buildEscalationTemplate()
{
    const dark = isDarkColor(diagram.background);
    const objects = [];

    const issue = tplNode('rounded', 300, 60, 190, 65, 'Issue Reported', 'terminal', dark);
    const tier1 = tplNode('rectangle', 300, 210, 190, 65, 'Tier 1 Support', 'process', dark);
    const dec1 = tplNode('diamond', 295, 355, 200, 110, 'Resolved?', 'decision', dark);
    const tier2 = tplNode('rectangle', 300, 550, 190, 65, 'Tier 2 Support', 'process', dark);
    const dec2 = tplNode('diamond', 295, 695, 200, 110, 'Resolved?', 'decision', dark);
    const manager = tplNode('rectangle', 300, 890, 190, 65, 'Escalate to Manager', 'process', dark);
    const closed = tplNode('rounded', 700, 500, 180, 65, 'Ticket Closed', 'terminal', dark);

    objects.push(issue, tier1, dec1, tier2, dec2, manager, closed);

    objects.push(
        tplConnect(issue, tier1, dark, 'straight'),
        tplConnect(tier1, dec1, dark, 'straight'),
        tplConnect(dec1, tier2, dark, 'straight'),
        tplConnect(dec1, closed, dark),
        tplConnect(tier2, dec2, dark, 'straight'),
        tplConnect(dec2, manager, dark, 'straight'),
        tplConnect(dec2, closed, dark)
    );

    return objects;
}


function buildDecisionHierarchyTemplate()
{
    const dark = isDarkColor(diagram.background);
    const objects = [];

    const start = tplNode('rounded', 460, 60, 160, 65, 'Start', 'terminal', dark);
    const decA = tplNode('diamond', 440, 200, 200, 110, 'Condition A?', 'decision', dark);
    const action1 = tplNode('rectangle', 160, 400, 180, 65, 'Action 1', 'process', dark);
    const decB = tplNode('diamond', 640, 380, 200, 110, 'Condition B?', 'decision', dark);
    const action2 = tplNode('rectangle', 560, 590, 180, 65, 'Action 2', 'process', dark);
    const action3 = tplNode('rectangle', 800, 590, 180, 65, 'Action 3', 'process', dark);
    const end = tplNode('rounded', 500, 760, 160, 65, 'End', 'terminal', dark);

    objects.push(start, decA, action1, decB, action2, action3, end);

    objects.push(
        tplConnect(start, decA, dark, 'straight'),
        tplConnect(decA, action1, dark),
        tplConnect(decA, decB, dark),
        tplConnect(decB, action2, dark),
        tplConnect(decB, action3, dark),
        tplConnect(action1, end, dark),
        tplConnect(action2, end, dark),
        tplConnect(action3, end, dark)
    );

    return objects;
}


const HIERARCHY_TEMPLATES = [
    {
        key: 'orgchart',
        name: 'Organization Chart',
        desc: 'Top-down reporting tree -- CEO, VPs, managers.',
        build: buildOrgChartTemplate,
        preview:
            '<rect x="35" y="4" width="30" height="14" rx="3"/>' +
            '<path d="M50 18v8M20 26h60M20 26v8M50 26v8M80 26v8"/>' +
            '<rect x="5" y="34" width="30" height="14" rx="3"/>' +
            '<rect x="35" y="34" width="30" height="14" rx="3"/>' +
            '<rect x="65" y="34" width="30" height="14" rx="3"/>'
    },
    {
        key: 'escalation',
        name: 'Escalation Flow',
        desc: 'Tiered support escalation with decision checks.',
        build: buildEscalationTemplate,
        preview:
            '<rect x="35" y="4" width="30" height="14" rx="3"/>' +
            '<path d="M50 18v8"/>' +
            '<path d="M50 26 62 38 50 50 38 38Z"/>' +
            '<path d="M50 50v8"/>' +
            '<rect x="35" y="58" width="30" height="14" rx="3"/>' +
            '<path d="M62 38h20v34"/>'
    },
    {
        key: 'decision',
        name: 'Decision Hierarchy',
        desc: 'Branching decision tree down to outcomes.',
        build: buildDecisionHierarchyTemplate,
        preview:
            '<rect x="35" y="2" width="30" height="12" rx="3"/>' +
            '<path d="M50 14 62 28 50 42 38 28Z"/>' +
            '<path d="M38 28 15 28v14"/>' +
            '<path d="M62 28 85 28v14"/>' +
            '<rect x="2" y="42" width="26" height="14" rx="3"/>' +
            '<rect x="72" y="42" width="26" height="14" rx="3"/>'
    }
];


function openTemplatePicker()
{
    const grid =
        document.getElementById('templateGrid');

    grid.innerHTML = '';

    HIERARCHY_TEMPLATES.forEach(tpl => {

        const card =
            document.createElement('button');

        card.type = 'button';

        card.className = 'dg-template-card';

        card.onclick = () => applyTemplate(tpl.key);

        card.innerHTML = `
            <div class="dg-template-preview">
                <svg viewBox="0 0 100 74" fill="none" stroke="#64748B" stroke-width="2" stroke-linejoin="round">
                    ${tpl.preview}
                </svg>
            </div>
            <div class="dg-template-name">${escapeHtml(tpl.name)}</div>
            <div class="dg-template-desc">${escapeHtml(tpl.desc)}</div>
        `;

        grid.appendChild(card);

    });

    document.getElementById('templateOverlay').hidden = false;
}


function closeTemplatePicker()
{
    document.getElementById('templateOverlay').hidden = true;
}


function applyTemplate(key)
{
    const tpl =
        HIERARCHY_TEMPLATES.find(t => t.key === key);

    if (!tpl) {
        return;
    }

    closeTemplatePicker();

    pages[activePageIndex].data = diagram;

    pages.push({

        name: tpl.name,

        data: {
            width: 2400,
            height: 1400,
            background: diagram.background,
            objects: tpl.build()
        }

    });

    switchToPage(pages.length - 1);

    setStatus(tpl.name + ' added as a new page');
}


/* =========================================================
   RENDER OBJECT
========================================================= */

function renderObject(obj)
{
    const g =
        svgEl('g', {
            class: 'diagram-object',
            'data-id': obj.id
        });

    /*
     * ARROW
     * (also covers the Dashed Arrow / Line / Dashed Line /
     * Elbow / Curved / Bidirectional palette variants --
     * same object type, different shape/arrowhead/dashed
     * fields)
     */
    if (obj.type === 'arrow') {

        const geo = arrowGeometry(obj);

        const attrs = {

            class:
                'connection-line',

            stroke:
                obj.stroke ||
                '#475569',

            'stroke-width':
                obj.strokeWidth || 2.5

        };

        if (obj.dashed) {
            attrs['stroke-dasharray'] = '9 7';
        }

        if (obj.arrowhead !== false) {
            attrs['marker-end'] = 'url(#arrowHead)';
        }

        if (obj.arrowStart) {
            attrs['marker-start'] = 'url(#arrowHeadStart)';
        }

        if (geo.tag === 'path') {

            attrs.d = geo.d;
            attrs.fill = 'none';

            g.appendChild(svgEl('path', attrs));

        } else {

            attrs.x1 = obj.x;
            attrs.y1 = obj.y;
            attrs.x2 = obj.x2;
            attrs.y2 = obj.y2;

            g.appendChild(svgEl('line', attrs));

        }

        return g;
    }


    /*
     * FREEHAND
     * A hand-drawn polyline. It carries its own point list
     * instead of x/y/w/h, so -- like arrow -- it renders and
     * is dragged as a special case rather than through the
     * shared rotate/resize box below.
     */
    if (obj.type === 'freehand') {

        const pointsAttr =
            (obj.points || [])
                .map(pt => `${pt.x},${pt.y}`)
                .join(' ');

        /*
         * Wide invisible stroke first, purely to make the
         * thin visible line easier to click/select.
         */
        g.appendChild(
            svgEl('polyline', {

                points: pointsAttr,

                fill: 'none',

                stroke: 'transparent',

                'stroke-width': 16,

                'stroke-linecap': 'round',

                'stroke-linejoin': 'round'

            })
        );

        const visibleAttrs = {

            points: pointsAttr,

            fill: 'none',

            stroke: obj.stroke || '#475569',

            'stroke-width': obj.strokeWidth || 2.5,

            'stroke-linecap': 'round',

            'stroke-linejoin': 'round',

            class: 'node-shadow'

        };

        if (obj.dashed) {
            visibleAttrs['stroke-dasharray'] = '2 7';
        }

        g.appendChild(svgEl('polyline', visibleAttrs));

        return g;
    }


    const cx =
        obj.x + obj.w / 2;

    const cy =
        obj.y + obj.h / 2;


    const group =
        svgEl('g', {

            transform:
                `rotate(${obj.rotation || 0} ${cx} ${cy})`

        });


    const rawFill =
        obj.fill || '#FFFFFF';

    /*
     * fillOpacity is stored separately from fill (kept a
     * plain solid hex so the Fill color picker stays
     * usable) -- it's folded into an rgba() string here,
     * at render time only, for the "glass chip" look on a
     * dark canvas.
     */
    const fill =
        (obj.fillOpacity != null && obj.fillOpacity < 1)
            ? hexToRgba(rawFill, obj.fillOpacity)
            : rawFill;

    const stroke =
        obj.stroke || '#334155';

    const sw =
        obj.strokeWidth || 1.6;


    /*
     * RECTANGLE
     */
    if (
        obj.type === 'rectangle' ||
        obj.type === 'rounded' ||
        obj.type === 'textbox' ||
        obj.type === 'text'
    ) {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx:
                    obj.type === 'rounded'
                        ? 12
                        : 4,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        /*
         * Text box can have multiline-style appearance.
         */
        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                obj.fontSize || 14
            )
        );

    }


    /*
     * CIRCLE
     */
    else if (obj.type === 'circle') {

        group.appendChild(
            svgEl('ellipse', {

                cx: cx,

                cy: cy,

                rx: obj.w / 2,

                ry: obj.h / 2,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                obj.fontSize || 14
            )
        );

    }


    /*
     * DIAMOND
     */
    else if (obj.type === 'diamond') {

        const points =
            `${cx},${obj.y} ` +
            `${obj.x + obj.w},${cy} ` +
            `${cx},${obj.y + obj.h} ` +
            `${obj.x},${cy}`;

        group.appendChild(
            svgEl('polygon', {

                points: points,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                obj.fontSize || 14
            )
        );

    }


    /*
     * DATABASE
     */
    else if (obj.type === 'database') {

        const rx =
            obj.w / 2;

        const topY =
            obj.y + 18;

        group.appendChild(
            svgEl('ellipse', {

                cx: cx,

                cy: topY,

                rx: rx,

                ry: 18,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('path', {

                d:
                    `M ${obj.x} ${topY}
                     L ${obj.x} ${obj.y + obj.h - 18}
                     Q ${cx} ${obj.y + obj.h + 10}
                       ${obj.x + obj.w} ${obj.y + obj.h - 18}
                     L ${obj.x + obj.w} ${topY}`,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                obj.fontSize || 13
            )
        );

    }


    /*
     * CLOUD
     */
    else if (
        [
            'cloud',
            'wan',
            'internet',
            'privatecloud',
            'publiccloud',
            'hybridcloud'
        ].includes(obj.type)
    ) {

        const d =
            `M ${obj.x + 35} ${cy + 20}
             C ${obj.x + 5} ${cy + 20},
               ${obj.x + 5} ${cy - 15},
               ${obj.x + 35} ${cy - 15}
             C ${obj.x + 45} ${obj.y + 15},
               ${obj.x + 85} ${obj.y + 15},
               ${obj.x + 95} ${cy - 5}
             C ${obj.x + 120} ${obj.y - 10},
               ${obj.x + 160} ${obj.y + 10},
               ${obj.x + 150} ${cy + 18}
             C ${obj.x + 175} ${cy + 40},
               ${obj.x + 155} ${obj.y + obj.h - 10},
               ${obj.x + 125} ${obj.y + obj.h - 10}
             L ${obj.x + 40} ${obj.y + obj.h - 10}
             C ${obj.x + 5} ${obj.y + obj.h - 10},
               ${obj.x + 5} ${cy + 30},
               ${obj.x + 35} ${cy + 20}
             Z`;

        group.appendChild(
            svgEl('path', {

                d: d,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy + 5,
                'node-text',
                12
            )
        );

    }


    /*
     * ROUTER
     */
    else if (obj.type === 'router') {

        group.appendChild(
            svgEl('polygon', {

                points:
                    `${cx},${obj.y}
                     ${obj.x + obj.w},${cy}
                     ${cx},${obj.y + obj.h}
                     ${obj.x},${cy}`,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            iconGroup('router', cx, cy - 6, 26, stroke)
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy + 25,
                'node-subtext',
                10
            )
        );

    }


    /*
     * SWITCH
     */
    else if (obj.type === 'switch') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y + 15,

                width: obj.w,

                height: obj.h - 30,

                rx: 6,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        for (let i = 0; i < 6; i++) {

            group.appendChild(
                svgEl('rect', {

                    x:
                        obj.x + 18 + i * 21,

                    y:
                        cy - 4,

                    width: 12,

                    height: 8,

                    rx: 2,

                    fill: '#475569'

                })
            );

        }

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + 14,
                'node-subtext',
                10
            )
        );

    }


    /*
     * FIREWALL / SECURITY
     */
    else if (
        [
            'firewall',
            'security',
            'ids',
            'ips'
        ].includes(obj.type)
    ) {

        group.appendChild(
            svgEl('path', {

                d:
                    `M ${cx} ${obj.y}
                     L ${obj.x + obj.w} ${obj.y + 25}
                     L ${obj.x + obj.w - 15} ${obj.y + obj.h - 10}
                     L ${cx} ${obj.y + obj.h}
                     L ${obj.x + 15} ${obj.y + obj.h - 10}
                     L ${obj.x} ${obj.y + 25}
                     Z`,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            iconGroup(obj.type, cx, cy - 8, 24, stroke)
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy + 24,
                'node-subtext',
                9
            )
        );

    }


    /*
     * SERVER
     */
    else if (
        [
            'server',
            'rackunit',
            'storage',
            'nas',
            'backup',
            'rack'
        ].includes(obj.type)
    ) {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 5,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        const rows =
            obj.type === 'rack'
                ? 7
                : 3;

        for (let i = 0; i < rows; i++) {

            const ry =
                obj.y +
                12 +
                i *
                ((obj.h - 24) / rows);

            group.appendChild(
                svgEl('line', {

                    x1: obj.x + 8,

                    y1: ry,

                    x2: obj.x + obj.w - 8,

                    y2: ry,

                    stroke: '#94A3B8',

                    'stroke-width': 1

                })
            );

            group.appendChild(
                svgEl('circle', {

                    cx: obj.x + 16,

                    cy: ry + 7,

                    r: 3,

                    fill: '#10B981'

                })
            );

        }

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 10,
                'node-subtext',
                9
            )
        );

    }


    /*
     * UPS
     */
    else if (obj.type === 'ups') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 8,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            iconGroup('ups', cx, cy - 8, 24, stroke)
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy + 25,
                'node-subtext',
                10
            )
        );

    }


    /*
     * PC
     */
    else if (obj.type === 'pc') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 15,

                y: obj.y,

                width: obj.w - 30,

                height: obj.h - 20,

                rx: 4,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('line', {

                x1: cx,

                y1: obj.y + obj.h - 20,

                x2: cx,

                y2: obj.y + obj.h - 5,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy - 5,
                'node-subtext',
                10
            )
        );

    }


    /*
     * LAPTOP
     */
    else if (obj.type === 'laptop') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 20,

                y: obj.y,

                width: obj.w - 40,

                height: obj.h - 22,

                rx: 5,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('path', {

                d:
                    `M ${obj.x + 5} ${obj.y + obj.h - 22}
                     L ${obj.x + obj.w - 5} ${obj.y + obj.h - 22}
                     L ${obj.x + obj.w - 20} ${obj.y + obj.h}
                     L ${obj.x + 20} ${obj.y + obj.h}
                     Z`,

                fill: '#E2E8F0',

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy - 5,
                'node-subtext',
                10
            )
        );

    }


    /*
     * MOBILE
     */
    else if (obj.type === 'mobile') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 35,

                y: obj.y,

                width: obj.w - 70,

                height: obj.h,

                rx: 12,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-subtext',
                9
            )
        );

    }


    /*
     * PRINTER
     */
    else if (obj.type === 'printer') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 15,

                y: obj.y + 20,

                width: obj.w - 30,

                height: obj.h - 20,

                rx: 5,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 30,

                y: obj.y,

                width: obj.w - 60,

                height: 30,

                fill: '#FFFFFF',

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 15,
                'node-subtext',
                9
            )
        );

    }


    /*
     * LOAD BALANCER
     */
    else if (obj.type === 'loadbalancer') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 8,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('line', {

                x1: obj.x + 20,

                y1: cy,

                x2: obj.x + obj.w - 20,

                y2: cy,

                stroke: '#7C3AED',

                'stroke-width': 3

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + 15,
                'node-subtext',
                9
            )
        );

    }


    /*
     * ACCESS POINT
     */
    else if (obj.type === 'accesspoint') {

        group.appendChild(
            svgEl('circle', {

                cx: cx,

                cy: cy,

                r: 28,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('path', {

                d:
                    `M ${cx - 18} ${cy + 5}
                     Q ${cx} ${cy - 18}
                       ${cx + 18} ${cy + 5}`,

                fill: 'none',

                stroke: '#2563EB',

                'stroke-width': 3

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 8,
                'node-subtext',
                9
            )
        );

    }


    /*
     * VM
     */
    else if (obj.type === 'virtualmachine') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 8,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 25,

                y: obj.y + 20,

                width: obj.w - 50,

                height: obj.h - 40,

                rx: 4,

                fill: '#FFFFFF',

                stroke: '#2563EB',

                'stroke-width': 2

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 10,
                'node-subtext',
                9
            )
        );

    }


    /*
     * CONTAINER
     */
    else if (obj.type === 'container') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 5,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: 22,

                fill: '#BBF7D0',

                stroke: stroke,

                'stroke-width': 1

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy + 15,
                'node-subtext',
                9
            )
        );

    }


    /*
     * CLUSTER
     */
    else if (obj.type === 'cluster') {

        group.appendChild(
            svgEl('ellipse', {

                cx: cx,

                cy: cy,

                rx: obj.w / 2,

                ry: obj.h / 2,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                'stroke-dasharray': '7 4'

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                12
            )
        );

    }


    /*
     * SAN
     */
    else if (obj.type === 'san') {

        group.appendChild(
            svgEl('ellipse', {

                cx: cx,

                cy: cy,

                rx: obj.w / 2,

                ry: obj.h / 2,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                'SAN',
                cx,
                cy - 4,
                'node-text',
                15
            )
        );

        group.appendChild(
            textEl(
                'Storage Area Network',
                cx,
                cy + 18,
                'node-subtext',
                8
            )
        );

    }


    /*
     * DATA CENTER
     */
    else if (obj.type === 'datacenter') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 8,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        for (let i = 0; i < 4; i++) {

            group.appendChild(
                svgEl('rect', {

                    x: obj.x + 20,

                    y: obj.y + 25 + i * 43,

                    width: obj.w - 40,

                    height: 30,

                    rx: 3,

                    fill: '#FFFFFF',

                    stroke: '#94A3B8',

                    'stroke-width': 1

                })
            );

        }

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 8,
                'node-subtext',
                10
            )
        );

    }


    /*
     * PROXY
     */
    else if (obj.type === 'proxy') {

        group.appendChild(
            svgEl('hexagon', {})
        );

        const points =
            `${cx},${obj.y}
             ${obj.x + obj.w},${obj.y + 25}
             ${obj.x + obj.w},${obj.y + obj.h - 25}
             ${cx},${obj.y + obj.h}
             ${obj.x},${obj.y + obj.h - 25}
             ${obj.x},${obj.y + 25}`;

        group.appendChild(
            svgEl('polygon', {

                points: points,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                11
            )
        );

    }


    /*
     * VPN
     */
    else if (obj.type === 'vpn') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 10,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            iconGroup('vpn', cx, cy - 12, 30, stroke)
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 14,
                'node-subtext',
                10
            )
        );

    }


    /*
     * NETWORK
     */
    else if (obj.type === 'network') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 10,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            iconGroup('network', cx, cy - 12, 30, stroke)
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                obj.y + obj.h - 14,
                'node-subtext',
                10
            )
        );

    }


    /*
     * ACTOR / USER
     */
    else if (obj.type === 'actor') {

        const r =
            Math.min(obj.w, obj.h) * 0.28;

        const circleCy =
            obj.y + obj.h * 0.34;

        group.appendChild(
            svgEl('circle', {

                cx: cx,

                cy: circleCy,

                r: r,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            iconGroup('actor', cx, circleCy, r * 1.3, '#FFFFFF')
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                circleCy + r + 20,
                'node-text',
                12
            )
        );

    }


    /*
     * GROUP FRAME
     */
    else if (obj.type === 'group') {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 12,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                'stroke-dasharray':
                    obj.strokeDasharray || 'none'

            })
        );

        const label =
            obj.text || 'Group';

        const tabWidth =
            Math.max(56, label.length * 7 + 22);

        group.appendChild(
            svgEl('rect', {

                x: obj.x + 14,

                y: obj.y - 11,

                width: tabWidth,

                height: 22,

                rx: 6,

                fill: diagram.background,

                stroke: stroke,

                'stroke-width': sw

            })
        );

        group.appendChild(
            textEl(
                label,
                obj.x + 14 + tabWidth / 2,
                obj.y + 0.5,
                'node-subtext group-label-text',
                10.5
            )
        );

    }


    /*
     * DEFAULT
     */
    else {

        group.appendChild(
            svgEl('rect', {

                x: obj.x,

                y: obj.y,

                width: obj.w,

                height: obj.h,

                rx: 8,

                fill: fill,

                stroke: stroke,

                'stroke-width': sw,

                class: 'node-shadow'

            })
        );

        group.appendChild(
            textEl(
                obj.text,
                cx,
                cy,
                'node-text',
                obj.fontSize || 14
            )
        );
    }


    g.appendChild(group);

    return g;
}


/* =========================================================
   SELECTION
========================================================= */

function renderSelection(obj)
{
    if (!obj) {
        return;
    }


    /*
     * ARROW SELECTION
     */
    if (obj.type === 'arrow') {

        const geo = arrowGeometry(obj);

        const selectedLine =
            geo.tag === 'path'
                ? svgEl('path', {
                    d: geo.d,
                    fill: 'none',
                    class: 'connection-selected'
                })
                : svgEl('line', {
                    x1: obj.x,
                    y1: obj.y,
                    x2: obj.x2,
                    y2: obj.y2,
                    class: 'connection-selected'
                });

        selectionLayer.appendChild(
            selectedLine
        );


        /*
         * Endpoint 1
         */
        selectionLayer.appendChild(
            svgEl('circle', {

                cx: obj.x,

                cy: obj.y,

                r: 7,

                class:
                    'endpoint-handle',

                'data-endpoint':
                    'start',

                'data-id':
                    obj.id

            })
        );


        /*
         * Endpoint 2
         */
        selectionLayer.appendChild(
            svgEl('circle', {

                cx: obj.x2,

                cy: obj.y2,

                r: 7,

                class:
                    'endpoint-handle',

                'data-endpoint':
                    'end',

                'data-id':
                    obj.id

            })
        );

        return;
    }


    /*
     * FREEHAND SELECTION
     * A simple bounding-box outline -- freehand lines don't
     * support rotate/resize, only move/duplicate/delete.
     */
    if (obj.type === 'freehand') {

        const bbox =
            freehandBounds(obj);

        if (!bbox) {
            return;
        }

        selectionLayer.appendChild(
            svgEl('rect', {

                x: bbox.minX - 8,

                y: bbox.minY - 8,

                width: bbox.maxX - bbox.minX + 16,

                height: bbox.maxY - bbox.minY + 16,

                class: 'selected-outline',

                rx: 6

            })
        );

        return;
    }


    /*
     * NORMAL OBJECT
     */

    const cx =
        obj.x + obj.w / 2;

    const cy =
        obj.y + obj.h / 2;

    const rotated =
        svgEl('g', {

            transform:
                `rotate(${obj.rotation || 0} ${cx} ${cy})`

        });


    rotated.appendChild(
        svgEl('rect', {

            x: obj.x - 5,

            y: obj.y - 5,

            width: obj.w + 10,

            height: obj.h + 10,

            class: 'selected-outline',

            rx: 6

        })
    );


    rotated.appendChild(
        svgEl('line', {

            x1: cx,

            y1: obj.y - 5,

            x2: cx,

            y2: obj.y - 30,

            class: 'rotate-line'

        })
    );


    rotated.appendChild(
        svgEl('circle', {

            cx: cx,

            cy: obj.y - 35,

            r: 6,

            class: 'rotate-handle',

            'data-rotate': obj.id

        })
    );


    rotated.appendChild(
        svgEl('rect', {

            x: obj.x + obj.w - 5,

            y: obj.y + obj.h - 5,

            width: 10,

            height: 10,

            class: 'resize-handle',

            'data-resize': obj.id

        })
    );


    /*
     * EXPAND HOTSPOTS
     * A small "+" on each edge -- click one to open a
     * floating shape picker and add a new, auto-connected
     * shape in that direction. Also shown on hover (see
     * showHoverHotspots below) so they don't require
     * selecting a shape first to discover.
     */
    buildExpandHotspots(obj).forEach(
        hotspot => rotated.appendChild(hotspot)
    );


    selectionLayer.appendChild(
        rotated
    );
}


const EXPAND_DIRS = ['up', 'right', 'down', 'left'];

const EXPAND_OPPOSITE = { up: 'down', down: 'up', left: 'right', right: 'left' };


function edgeMidpoint(obj, dir)
{
    switch (dir) {
        case 'up':    return { x: obj.x + obj.w / 2, y: obj.y };
        case 'down':  return { x: obj.x + obj.w / 2, y: obj.y + obj.h };
        case 'left':  return { x: obj.x, y: obj.y + obj.h / 2 };
        case 'right': return { x: obj.x + obj.w, y: obj.y + obj.h / 2 };
    }
}


/*
 * Builds the 4 directional "+" hotspots for a shape --
 * shared by the selection outline (always shown once a
 * shape is selected) and hover (shown just by pointing at
 * any shape, no click needed -- see showHoverHotspots).
 * Not shown for group frames, arrows, or freehand lines.
 */
function buildExpandHotspots(obj)
{
    if (
        !obj ||
        obj.type === 'group' ||
        obj.type === 'arrow' ||
        obj.type === 'freehand'
    ) {
        return [];
    }

    /*
     * Pushed out from the edge so the hotspot doesn't sit on
     * top of the shape's own border -- "up" is pushed
     * further still to clear the rotate handle.
     */
    const HOTSPOT_OFFSET = { up: 48, down: 22, left: 22, right: 22 };

    return EXPAND_DIRS.map(dir => {

        const pt =
            edgeMidpoint(obj, dir);

        const offset = HOTSPOT_OFFSET[dir];

        if (dir === 'up')    pt.y -= offset;
        if (dir === 'down')  pt.y += offset;
        if (dir === 'left')  pt.x -= offset;
        if (dir === 'right') pt.x += offset;

        const hotspot =
            svgEl('g', {

                class: 'expand-hotspot',

                'data-expand-dir': dir,

                'data-id': obj.id

            });

        hotspot.appendChild(
            svgEl('circle', {
                cx: pt.x,
                cy: pt.y,
                r: 9
            })
        );

        hotspot.appendChild(
            svgEl('path', {
                d: `M ${pt.x - 4} ${pt.y} h 8 M ${pt.x} ${pt.y - 4} v 8`
            })
        );

        return hotspot;

    });
}


function showHoverHotspots(obj)
{
    hoverLayer.innerHTML = '';

    const hotspots =
        buildExpandHotspots(obj);

    if (!hotspots.length) {
        return;
    }

    const cx = obj.x + obj.w / 2;
    const cy = obj.y + obj.h / 2;

    const g =
        svgEl('g', {
            transform: `rotate(${obj.rotation || 0} ${cx} ${cy})`
        });

    hotspots.forEach(hotspot => g.appendChild(hotspot));

    hoverLayer.appendChild(g);
}


function clearHoverHotspots()
{
    hoverLayer.innerHTML = '';

    hoveredId = null;
}


/* =========================================================
   EXPAND POPUP (floating quick-add shape picker)
========================================================= */

const EXPAND_SHAPE_SET =
    ['rectangle', 'rounded', 'diamond', 'circle', 'database', 'server', 'cloud', 'textbox'];

const expandPopupEl =
    document.getElementById('expandPopup');

const expandGridEl =
    document.getElementById('expandGrid');

let expandContext = null;


function openExpandPopup(sourceId, dir, anchorRect)
{
    expandContext = { sourceId, dir };

    expandGridEl.innerHTML = '';

    EXPAND_SHAPE_SET.forEach(type => {

        const btn =
            document.createElement('button');

        btn.type = 'button';

        btn.className = 'dg-expand-item';

        btn.title = TYPE_NAMES[type] || type;

        btn.onclick = () => pickExpandShape(type);

        btn.innerHTML =
            `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" ` +
            `stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">` +
            ICONS[type] +
            `</svg>`;

        expandGridEl.appendChild(btn);

    });

    /*
     * Position near the hotspot, clamped so it never runs
     * off the viewport edge.
     */
    const popupWidth = 216;
    const popupHeight = 130;

    let left = anchorRect.left + anchorRect.width / 2 - popupWidth / 2;
    let top = anchorRect.top + anchorRect.height / 2 - popupHeight / 2;

    left = Math.max(8, Math.min(left, window.innerWidth - popupWidth - 8));
    top = Math.max(8, Math.min(top, window.innerHeight - popupHeight - 8));

    expandPopupEl.style.left = `${left}px`;
    expandPopupEl.style.top = `${top}px`;

    expandPopupEl.hidden = false;
}


function closeExpandPopup()
{
    expandPopupEl.hidden = true;

    expandContext = null;
}


document.addEventListener('pointerdown', function(e) {

    if (
        expandContext &&
        !expandPopupEl.contains(e.target) &&
        !e.target.closest('[data-expand-dir]')
    ) {
        closeExpandPopup();
    }

});


function pickExpandShape(type)
{
    if (!expandContext) {
        return;
    }

    const { sourceId, dir } = expandContext;

    const source = getObject(sourceId);

    closeExpandPopup();

    if (!source) {
        return;
    }

    pushHistory();

    const draft =
        createObject(type, 0, 0);

    const gap = 70;

    if (dir === 'right') {
        draft.x = source.x + source.w + gap;
        draft.y = source.y + source.h / 2 - draft.h / 2;
    } else if (dir === 'left') {
        draft.x = source.x - gap - draft.w;
        draft.y = source.y + source.h / 2 - draft.h / 2;
    } else if (dir === 'down') {
        draft.x = source.x + source.w / 2 - draft.w / 2;
        draft.y = source.y + source.h + gap;
    } else {
        draft.x = source.x + source.w / 2 - draft.w / 2;
        draft.y = source.y - gap - draft.h;
    }

    draft.x = Math.round(draft.x);
    draft.y = Math.round(draft.y);

    diagram.objects.push(draft);

    const start = edgeMidpoint(source, dir);
    const end = edgeMidpoint(draft, EXPAND_OPPOSITE[dir]);

    const connector =
        createObject('arrow', 0, 0);

    connector.x = Math.round(start.x);
    connector.y = Math.round(start.y);
    connector.x2 = Math.round(end.x);
    connector.y2 = Math.round(end.y);

    diagram.objects.push(connector);

    selectedId = draft.id;

    renderCanvas();

    renderPropertiesPanel();

    setStatus(
        (TYPE_NAMES[type] || type) + ' added and connected'
    );
}


/* =========================================================
   TRANSFORM
========================================================= */

function updateTransform()
{
    svg.style.transform =
        `translate(${panX}px,${panY}px) scale(${zoom})`;

    svg.style.transformOrigin =
        '0 0';

    zoomLabel.textContent =
        Math.round(zoom * 100) + '%';
}


function zoomBy(amount)
{
    zoom =
        Math.max(
            .25,
            Math.min(
                2.5,
                zoom + amount
            )
        );

    updateTransform();
}


function resetView()
{
    zoom = 1;

    panX = 30;

    panY = 30;

    updateTransform();
}


/* =========================================================
   PANEL COLLAPSE / FULL SCREEN
========================================================= */

const dgWorkspace =
    document.querySelector('.dg-workspace');

let fullscreenPanelState = null;


function togglePalette()
{
    dgWorkspace.classList.toggle('palette-collapsed');

    document
        .getElementById('togglePaletteBtn')
        .classList.toggle(
            'active',
            dgWorkspace.classList.contains('palette-collapsed')
        );
}


function toggleProperties()
{
    dgWorkspace.classList.toggle('properties-collapsed');

    document
        .getElementById('togglePropertiesBtn')
        .classList.toggle(
            'active',
            dgWorkspace.classList.contains('properties-collapsed')
        );
}


function toggleFullscreen()
{
    const el =
        document.querySelector('.dg-page');

    const request =
        el.requestFullscreen ||
        el.webkitRequestFullscreen;

    const exit =
        document.exitFullscreen ||
        document.webkitExitFullscreen;

    if (!document.fullscreenElement) {

        /*
         * Full screen also collapses both side panels for
         * maximum canvas space -- the state beforehand is
         * restored on exit.
         */
        fullscreenPanelState = {

            palette:
                dgWorkspace.classList.contains('palette-collapsed'),

            properties:
                dgWorkspace.classList.contains('properties-collapsed')

        };

        dgWorkspace.classList.add(
            'palette-collapsed',
            'properties-collapsed'
        );

        if (request) {
            request.call(el);
        }

    } else if (exit) {

        exit.call(document);

    }
}


document.addEventListener('fullscreenchange', onFullscreenChange);
document.addEventListener('webkitfullscreenchange', onFullscreenChange);

function onFullscreenChange()
{
    const active =
        !!(document.fullscreenElement || document.webkitFullscreenElement);

    document
        .getElementById('toggleFullscreenBtn')
        .classList.toggle('active', active);

    if (!active && fullscreenPanelState) {

        dgWorkspace.classList.toggle(
            'palette-collapsed',
            fullscreenPanelState.palette
        );

        dgWorkspace.classList.toggle(
            'properties-collapsed',
            fullscreenPanelState.properties
        );

        document
            .getElementById('togglePaletteBtn')
            .classList.toggle(
                'active',
                fullscreenPanelState.palette
            );

        document
            .getElementById('togglePropertiesBtn')
            .classList.toggle(
                'active',
                fullscreenPanelState.properties
            );

        fullscreenPanelState = null;

    }
}


/* =========================================================
   POINTER CONVERSION
========================================================= */

function pointerToSvg(e)
{
    const rect =
        viewport.getBoundingClientRect();

    return {

        x:
            (e.clientX -
             rect.left -
             panX) / zoom,

        y:
            (e.clientY -
             rect.top -
             panY) / zoom

    };
}


/* =========================================================
   POINTER DOWN
========================================================= */

svg.addEventListener(
    'pointerdown',
    function(e)
    {
        /*
         * Any press on the canvas closes a stale expand
         * popup -- if the press itself is on a hotspot, the
         * branch below reopens it for the new context right
         * after.
         */
        if (expandContext) {
            closeExpandPopup();
        }


        /*
         * Freehand draw start
         * Armed by the Free Draw palette button -- the next
         * pointer press begins a stroke instead of selecting
         * or moving anything.
         */
        if (freehandArmed) {

            const p = pointerToSvg(e);

            freehandDraft = {

                stroke:
                    isDarkColor(diagram.background)
                        ? '#94A3B8' : '#475569',

                strokeWidth: 2.5,

                dashed: freehandDashedMode,

                points: [{ x: Math.round(p.x), y: Math.round(p.y) }]

            };

            selectedId = null;

            svg.setPointerCapture(e.pointerId);

            e.preventDefault();

            e.stopPropagation();

            return;
        }


        /*
         * Expand hotspot
         */
        const expandHotspot =
            e.target.closest('[data-expand-dir]');

        if (expandHotspot) {

            openExpandPopup(
                expandHotspot.getAttribute('data-id'),
                expandHotspot.getAttribute('data-expand-dir'),
                expandHotspot.getBoundingClientRect()
            );

            e.preventDefault();

            e.stopPropagation();

            return;
        }


        /*
         * Rotation handle
         */
        const rotateHandle =
            e.target.closest(
                '[data-rotate]'
            );

        if (rotateHandle) {

            const obj =
                getObject(
                    rotateHandle.getAttribute(
                        'data-rotate'
                    )
                );

            if (!obj) {
                return;
            }

            rotateState = {

                id: obj.id,

                cx:
                    obj.x +
                    obj.w / 2,

                cy:
                    obj.y +
                    obj.h / 2

            };

            pushHistory();

            svg.setPointerCapture(
                e.pointerId
            );

            e.preventDefault();

            e.stopPropagation();

            return;
        }


        /*
         * Resize handle
         */
        const resizeHandle =
            e.target.closest(
                '[data-resize]'
            );

        if (resizeHandle) {

            const obj =
                getObject(
                    resizeHandle.getAttribute(
                        'data-resize'
                    )
                );

            if (!obj) {
                return;
            }

            const p =
                pointerToSvg(e);

            resizeState = {

                id: obj.id,

                startW: obj.w,

                startH: obj.h,

                startX: p.x,

                startY: p.y

            };

            pushHistory();

            svg.setPointerCapture(
                e.pointerId
            );

            e.preventDefault();

            e.stopPropagation();

            return;
        }


        /*
         * Arrow endpoint
         */
        const endpoint =
            e.target.closest(
                '[data-endpoint]'
            );

        if (endpoint) {

            const id =
                endpoint.getAttribute(
                    'data-id'
                );

            const which =
                endpoint.getAttribute(
                    'data-endpoint'
                );

            const obj =
                getObject(id);

            if (!obj) {
                return;
            }

            endpointState = {

                id: id,

                which: which

            };

            pushHistory();

            svg.setPointerCapture(
                e.pointerId
            );

            e.preventDefault();

            e.stopPropagation();

            return;
        }


        /*
         * Normal object
         */
        const target =
            e.target.closest(
                '[data-id]'
            );

        if (!target) {

            if (selectedId !== null) {

                selectedId = null;

                renderCanvas();

                renderPropertiesPanel();

            }

            return;
        }


        const id =
            target.getAttribute(
                'data-id'
            );

        const obj =
            getObject(id);

        if (!obj) {
            return;
        }

        selectedId = id;

        renderCanvas();

        renderPropertiesPanel();


        const p =
            pointerToSvg(e);


        /*
         * IMPORTANT:
         * Arrow movement stores the position of BOTH
         * endpoints, allowing the whole arrow to move freely.
         */
        if (obj.type === 'arrow') {

            dragState = {

                id: id,

                startPointerX: p.x,

                startPointerY: p.y,

                startX: obj.x,

                startY: obj.y,

                startX2: obj.x2,

                startY2: obj.y2

            };

        } else if (obj.type === 'freehand') {

            dragState = {

                id: id,

                startPointerX: p.x,

                startPointerY: p.y,

                startPoints:
                    (obj.points || []).map(
                        pt => ({ x: pt.x, y: pt.y })
                    )

            };

        } else {

            dragState = {

                id: id,

                offsetX:
                    p.x - obj.x,

                offsetY:
                    p.y - obj.y

            };

        }


        svg.setPointerCapture(
            e.pointerId
        );

        e.preventDefault();

        e.stopPropagation();
    }
);


/* =========================================================
   POINTER MOVE
========================================================= */

svg.addEventListener(
    'pointermove',
    function(e)
    {
        const p =
            pointerToSvg(e);


        /*
         * FREEHAND DRAW IN PROGRESS
         */
        if (freehandDraft) {

            freehandDraft.points.push({
                x: Math.round(p.x),
                y: Math.round(p.y)
            });

            selectionLayer.innerHTML = '';

            selectionLayer.appendChild(
                svgEl('polyline', {

                    points:
                        freehandDraft.points
                            .map(pt => `${pt.x},${pt.y}`)
                            .join(' '),

                    fill: 'none',

                    stroke: freehandDraft.stroke,

                    'stroke-width': freehandDraft.strokeWidth,

                    'stroke-linecap': 'round',

                    'stroke-linejoin': 'round',

                    'stroke-dasharray': '2 6'

                })
            );

            return;
        }


        /*
         * ROTATE
         */
        if (rotateState) {

            const obj =
                getObject(
                    rotateState.id
                );

            if (!obj) {
                return;
            }

            const angle =
                Math.atan2(
                    p.y - rotateState.cy,
                    p.x - rotateState.cx
                ) *
                180 /
                Math.PI;

            obj.rotation =
                Math.round(
                    angle + 90
                );

            renderCanvas();

            return;
        }


        /*
         * RESIZE
         */
        if (resizeState) {

            const obj =
                getObject(
                    resizeState.id
                );

            if (!obj) {
                return;
            }

            obj.w =
                Math.max(
                    40,
                    resizeState.startW +
                    (p.x -
                     resizeState.startX)
                );

            obj.h =
                Math.max(
                    30,
                    resizeState.startH +
                    (p.y -
                     resizeState.startY)
                );

            renderCanvas();

            renderPropertiesPanel();

            return;
        }


        /*
         * ARROW ENDPOINT
         */
        if (endpointState) {

            const obj =
                getObject(
                    endpointState.id
                );

            if (!obj) {
                return;
            }

            if (
                endpointState.which ===
                'start'
            ) {

                obj.x =
                    Math.round(p.x);

                obj.y =
                    Math.round(p.y);

            } else {

                obj.x2 =
                    Math.round(p.x);

                obj.y2 =
                    Math.round(p.y);

            }

            renderCanvas();

            return;
        }


        /*
         * DRAG
         */
        if (dragState) {

            const obj =
                getObject(
                    dragState.id
                );

            if (!obj) {
                return;
            }


            /*
             * ARROW:
             * Move both endpoints by the same delta.
             */
            if (obj.type === 'arrow') {

                const dx =
                    p.x -
                    dragState.startPointerX;

                const dy =
                    p.y -
                    dragState.startPointerY;

                obj.x =
                    Math.round(
                        dragState.startX + dx
                    );

                obj.y =
                    Math.round(
                        dragState.startY + dy
                    );

                obj.x2 =
                    Math.round(
                        dragState.startX2 + dx
                    );

                obj.y2 =
                    Math.round(
                        dragState.startY2 + dy
                    );

            } else if (obj.type === 'freehand') {

                const dx =
                    p.x -
                    dragState.startPointerX;

                const dy =
                    p.y -
                    dragState.startPointerY;

                obj.points =
                    dragState.startPoints.map(
                        pt => ({
                            x: Math.round(pt.x + dx),
                            y: Math.round(pt.y + dy)
                        })
                    );

            } else {

                obj.x =
                    Math.round(
                        p.x -
                        dragState.offsetX
                    );

                obj.y =
                    Math.round(
                        p.y -
                        dragState.offsetY
                    );
            }


            renderCanvas();
        }

    }
);


/* =========================================================
   POINTER UP
========================================================= */

svg.addEventListener(
    'pointerup',
    function(e)
    {
        if (freehandDraft) {

            try {
                svg.releasePointerCapture(e.pointerId);
            } catch(err) {}

            commitFreehandDraft();

            return;
        }

        if (
            dragState ||
            rotateState ||
            resizeState ||
            endpointState
        ) {

            try {

                svg.releasePointerCapture(
                    e.pointerId
                );

            } catch(err) {}

        }

        dragState = null;

        rotateState = null;

        resizeState = null;

        endpointState = null;
    }
);


/* =========================================================
   HOVER (expand hotspots without needing to select first)
========================================================= */

svg.addEventListener('mouseover', function(e) {

    /*
     * Don't pop up hover hotspots while something else is
     * already being dragged/rotated/resized/drawn.
     */
    if (
        dragState || rotateState || resizeState ||
        endpointState || freehandDraft
    ) {
        return;
    }

    const target =
        e.target.closest('[data-id]');

    if (!target) {
        return;
    }

    const id =
        target.getAttribute('data-id');

    /*
     * Already showing (or the shape is selected, which
     * already has its own hotspots via renderSelection).
     */
    if (id === hoveredId || id === selectedId) {
        return;
    }

    hoveredId = id;

    const obj = getObject(id);

    if (obj) {
        showHoverHotspots(obj);
    } else {
        clearHoverHotspots();
    }

});

svg.addEventListener('mouseout', function(e) {

    const related =
        e.relatedTarget && e.relatedTarget.closest
            ? e.relatedTarget.closest('[data-id]')
            : null;

    const relatedId =
        related ? related.getAttribute('data-id') : null;

    /*
     * Moving onto the same shape's own hotspot (which lives
     * in a separate layer but carries the same data-id) --
     * keep it visible rather than flickering it away.
     */
    if (relatedId === hoveredId) {
        return;
    }

    clearHoverHotspots();

});


/* =========================================================
   FREEHAND COMMIT / CANCEL
========================================================= */

function commitFreehandDraft()
{
    const draft = freehandDraft;

    freehandDraft = null;

    freehandArmed = false;

    svg.classList.remove('freehand-armed');

    selectionLayer.innerHTML = '';

    if (!draft || draft.points.length < 2) {
        renderCanvas();
        return;
    }

    pushHistory();

    diagram.objects.push({

        id: uid(),

        type: 'freehand',

        points: draft.points,

        stroke: draft.stroke,

        strokeWidth: draft.strokeWidth,

        dashed: draft.dashed

    });

    selectedId =
        diagram.objects[diagram.objects.length - 1].id;

    renderCanvas();

    renderPropertiesPanel();

    setStatus('Free line added');
}


function cancelFreehand()
{
    if (!freehandArmed && !freehandDraft) {
        return;
    }

    freehandArmed = false;

    freehandDraft = null;

    svg.classList.remove('freehand-armed');

    selectionLayer.innerHTML = '';

    setStatus('Free draw cancelled');
}


function armFreehandTool(dashed)
{
    freehandArmed = true;

    freehandDashedMode = !!dashed;

    svg.classList.add('freehand-armed');

    selectedId = null;

    renderCanvas();

    renderPropertiesPanel();

    setStatus('Click and drag on the canvas to draw a line (Esc to cancel)');
}


/* =========================================================
   PROPERTIES
========================================================= */

function renderPropertiesPanel()
{
    const obj =
        getObject(selectedId);


    if (!obj) {

        propertiesContent.innerHTML = `
            <div class="dg-no-selection">
                Select an object on the canvas to
                customize it, move it, rotate it,
                resize it, duplicate it, or delete it.
            </div>
        `;

        return;
    }


    /*
     * ARROW PROPERTIES
     */
    if (obj.type === 'arrow') {

        propertiesContent.innerHTML = `

            <div class="dg-prop-group">
                <label>Type</label>
                <input
                    value="Connector / Arrow"
                    disabled
                >
            </div>

            <div class="dg-prop-row">

                <div class="dg-prop-group">
                    <label>Start X</label>
                    <input
                        type="number"
                        value="${obj.x}"
                        oninput="updateObjectValue('x',this.value)"
                    >
                </div>

                <div class="dg-prop-group">
                    <label>Start Y</label>
                    <input
                        type="number"
                        value="${obj.y}"
                        oninput="updateObjectValue('y',this.value)"
                    >
                </div>

            </div>

            <div class="dg-prop-row">

                <div class="dg-prop-group">
                    <label>End X</label>
                    <input
                        type="number"
                        value="${obj.x2}"
                        oninput="updateObjectValue('x2',this.value)"
                    >
                </div>

                <div class="dg-prop-group">
                    <label>End Y</label>
                    <input
                        type="number"
                        value="${obj.y2}"
                        oninput="updateObjectValue('y2',this.value)"
                    >
                </div>

            </div>

            <div class="dg-prop-group">
                <label>Line Color</label>
                <input
                    type="color"
                    value="${obj.stroke || '#475569'}"
                    onchange="updateObjectValue('stroke',this.value)"
                >
            </div>

            <div class="dg-prop-group">
                <label>Line Width</label>
                <input
                    type="number"
                    min="1"
                    max="10"
                    value="${obj.strokeWidth || 2.5}"
                    oninput="updateObjectValue('strokeWidth',this.value)"
                >
            </div>

            <div class="dg-prop-group">
                <label>Connector Shape</label>
                <select onchange="updateObjectValue('shape',this.value)">
                    <option value="straight" ${(obj.shape || 'straight') === 'straight' ? 'selected' : ''}>Straight</option>
                    <option value="elbow" ${obj.shape === 'elbow' ? 'selected' : ''}>Elbow</option>
                    <option value="curved" ${obj.shape === 'curved' ? 'selected' : ''}>Curved</option>
                </select>
            </div>

            <div class="dg-prop-group">
                <label>Style</label>
                <div class="dg-checkbox-row">
                    <label class="dg-checkbox">
                        <input
                            type="checkbox"
                            ${obj.arrowhead !== false ? 'checked' : ''}
                            onchange="updateObjectValue('arrowhead',this.checked)"
                        >
                        End Arrow
                    </label>
                    <label class="dg-checkbox">
                        <input
                            type="checkbox"
                            ${obj.arrowStart ? 'checked' : ''}
                            onchange="updateObjectValue('arrowStart',this.checked)"
                        >
                        Start Arrow
                    </label>
                    <label class="dg-checkbox">
                        <input
                            type="checkbox"
                            ${obj.dashed ? 'checked' : ''}
                            onchange="updateObjectValue('dashed',this.checked)"
                        >
                        Dashed
                    </label>
                </div>
            </div>

            <div class="dg-prop-buttons">

                <button
                    onclick="duplicateSelected()"
                >
                    Duplicate
                </button>

                <button
                    onclick="deleteSelected()"
                >
                    Delete
                </button>

                <button
                    onclick="reorderSelected('back')"
                >
                    Send to Back
                </button>

                <button
                    onclick="reorderSelected('front')"
                >
                    Bring to Front
                </button>

            </div>
        `;

        return;
    }


    /*
     * FREEHAND PROPERTIES
     */
    if (obj.type === 'freehand') {

        propertiesContent.innerHTML = `

            <div class="dg-prop-group">
                <label>Type</label>
                <input
                    value="Free Line"
                    disabled
                >
            </div>

            <div class="dg-prop-group">
                <label>Line Color</label>
                <input
                    type="color"
                    value="${obj.stroke || '#475569'}"
                    onchange="updateObjectValue('stroke',this.value)"
                >
            </div>

            <div class="dg-prop-group">
                <label>Line Width</label>
                <input
                    type="number"
                    min="1"
                    max="10"
                    value="${obj.strokeWidth || 2.5}"
                    oninput="updateObjectValue('strokeWidth',this.value)"
                >
            </div>

            <div class="dg-prop-buttons">

                <button
                    onclick="duplicateSelected()"
                >
                    Duplicate
                </button>

                <button
                    onclick="deleteSelected()"
                >
                    Delete
                </button>

                <button
                    onclick="reorderSelected('back')"
                >
                    Send to Back
                </button>

                <button
                    onclick="reorderSelected('front')"
                >
                    Bring to Front
                </button>

            </div>
        `;

        return;
    }


    /*
     * NORMAL OBJECT
     */

    propertiesContent.innerHTML = `

        <div class="dg-prop-group">
            <label>Type</label>

            <input
                value="${escapeHtml(
                    TYPE_NAMES[obj.type] ||
                    obj.type
                )}"
                disabled
            >
        </div>


        <div class="dg-prop-group">

            <label>Text</label>

            <input
                type="text"
                value="${escapeHtml(
                    obj.text || ''
                )}"
                oninput="
                    updateObjectValue(
                        'text',
                        this.value
                    )
                "
            >

        </div>


        <div class="dg-prop-row">

            <div class="dg-prop-group">

                <label>X</label>

                <input
                    type="number"
                    value="${obj.x}"
                    oninput="
                        updateObjectValue(
                            'x',
                            this.value
                        )
                    "
                >

            </div>


            <div class="dg-prop-group">

                <label>Y</label>

                <input
                    type="number"
                    value="${obj.y}"
                    oninput="
                        updateObjectValue(
                            'y',
                            this.value
                        )
                    "
                >

            </div>

        </div>


        <div class="dg-prop-row">

            <div class="dg-prop-group">

                <label>Width</label>

                <input
                    type="number"
                    min="40"
                    value="${obj.w}"
                    oninput="
                        updateObjectValue(
                            'w',
                            this.value
                        )
                    "
                >

            </div>


            <div class="dg-prop-group">

                <label>Height</label>

                <input
                    type="number"
                    min="30"
                    value="${obj.h}"
                    oninput="
                        updateObjectValue(
                            'h',
                            this.value
                        )
                    "
                >

            </div>

        </div>


        <div class="dg-prop-group">

            <label>Rotation</label>

            <input
                type="number"
                value="${obj.rotation || 0}"
                oninput="
                    updateObjectValue(
                        'rotation',
                        this.value
                    )
                "
            >

        </div>


        <div class="dg-prop-row">

            <div class="dg-prop-group">

                <label>Fill</label>

                <input
                    type="color"
                    value="${obj.fill || '#FFFFFF'}"
                    onchange="
                        updateObjectValue(
                            'fill',
                            this.value
                        )
                    "
                >

            </div>


            <div class="dg-prop-group">

                <label>Border</label>

                <input
                    type="color"
                    value="${obj.stroke || '#334155'}"
                    onchange="
                        updateObjectValue(
                            'stroke',
                            this.value
                        )
                    "
                >

            </div>

        </div>


        <div class="dg-prop-buttons">

            <button
                onclick="duplicateSelected()"
            >
                Duplicate
            </button>

            <button
                onclick="deleteSelected()"
            >
                Delete
            </button>

            <button
                onclick="reorderSelected('back')"
            >
                Send to Back
            </button>

            <button
                onclick="reorderSelected('front')"
            >
                Bring to Front
            </button>

        </div>

    `;
}


/* =========================================================
   UPDATE PROPERTY
========================================================= */

function updateObjectValue(property,value)
{
    const obj =
        getObject(selectedId);

    if (!obj) {
        return;
    }


    if (
        [
            'w',
            'h',
            'x',
            'y',
            'x2',
            'y2',
            'rotation',
            'fontSize',
            'strokeWidth'
        ].includes(property)
    ) {

        value =
            Number(value);

        if (!Number.isFinite(value)) {
            return;
        }
    }


    obj[property] = value;

    renderCanvas();
}


/* =========================================================
   DELETE
========================================================= */

function deleteSelected()
{
    if (!selectedId) {
        return;
    }

    pushHistory();

    diagram.objects =
        diagram.objects.filter(
            obj =>
                obj.id !== selectedId
        );

    selectedId = null;

    renderCanvas();

    renderPropertiesPanel();

    setStatus('Object deleted');
}


/* =========================================================
   DUPLICATE
========================================================= */

function duplicateSelected()
{
    const obj =
        getObject(selectedId);

    if (!obj) {
        return;
    }

    pushHistory();

    const copy =
        cloneObject(obj);

    copy.id = uid();


    /*
     * Move duplicated arrow completely.
     */
    if (copy.type === 'arrow') {

        copy.x += 35;

        copy.y += 35;

        copy.x2 += 35;

        copy.y2 += 35;

    } else if (copy.type === 'freehand') {

        copy.points =
            copy.points.map(
                pt => ({ x: pt.x + 35, y: pt.y + 35 })
            );

    } else {

        copy.x += 35;

        copy.y += 35;

    }


    diagram.objects.push(copy);

    selectedId =
        copy.id;

    renderCanvas();

    renderPropertiesPanel();

    setStatus('Object duplicated');
}


/* =========================================================
   REORDER (Z-INDEX)
========================================================= */

function reorderSelected(direction)
{
    const index =
        diagram.objects.findIndex(
            obj => obj.id === selectedId
        );

    if (index === -1) {
        return;
    }

    pushHistory();

    const [obj] =
        diagram.objects.splice(index, 1);

    if (direction === 'back') {
        diagram.objects.unshift(obj);
    } else {
        diagram.objects.push(obj);
    }

    renderCanvas();

    setStatus(
        direction === 'back'
            ? 'Sent to back'
            : 'Brought to front'
    );
}


/* =========================================================
   SAVED LIST (client-side sync)
========================================================= */

function upsertSavedListEntry(id, name)
{
    const list =
        document.getElementById('savedList');

    if (!list) {
        return;
    }

    const empty =
        document.getElementById('savedListEmpty');

    if (empty) {
        empty.remove();
    }

    const title =
        list.querySelector('.dg-properties-title');

    let item =
        list.querySelector(
            `.dg-saved-item[data-id="${id}"]`
        );

    if (!item) {

        item = document.createElement('div');

        item.className = 'dg-saved-item';

        item.dataset.id = id;

        item.innerHTML = `
            <div class="dg-saved-info" onclick="openDiagram(${id})">
                <div class="dg-saved-name"></div>
                <div class="dg-saved-meta"></div>
            </div>
            <div class="dg-saved-actions">
                <a href="?id=${id}">View</a>
                <a href="?id=${id}">Edit</a>
                <button onclick="deleteSavedDiagram(${id})" style="color:#DC2626;">Delete</button>
            </div>
        `;

    }

    item.querySelector('.dg-saved-name').textContent = name;

    item.querySelector('.dg-saved-meta').textContent =
        'By: ' + (CURRENT_USER || 'System');

    /*
     * Newest/most-recently-saved first, matching the
     * server's own ORDER BY updated_at DESC.
     */
    if (title && title.nextSibling !== item) {
        title.insertAdjacentElement('afterend', item);
    }
}


/* =========================================================
   SAVE
========================================================= */

function buildDocumentForSave()
{
    /*
     * The in-progress edits on the active page live directly
     * on `diagram`, not yet written back into `pages` -- sync
     * that before serializing everything.
     */
    pages[activePageIndex].data = diagram;

    return {

        pages:
            pages.map(function(p) {
                return { name: p.name, data: p.data };
            }),

        activePage: activePageIndex

    };
}


async function saveDiagram()
{
    const nameInput =
        document.getElementById(
            'diagramName'
        );

    const name =
        nameInput.value.trim() ||
        'Untitled Diagram';


    const form =
        new FormData();

    form.append(
        'action',
        'save_diagram'
    );

    /*
     * currentDiagramId is updated after every save.
     */
    form.append(
        'id',
        String(currentDiagramId || 0)
    );

    form.append(
        'name',
        name
    );

    form.append(
        'diagram_data',
        JSON.stringify(buildDocumentForSave())
    );


    setStatus('Saving...');


    try {

        const response =
            await fetch(
                window.location.href,
                {
                    method: 'POST',
                    body: form
                }
            );


        const result =
            await response.json();


        if (!result.success) {

            alert(
                result.message ||
                'Save failed.'
            );

            setStatus(
                'Save failed'
            );

            return;
        }


        /*
         * VERY IMPORTANT:
         * Store the returned database ID.
         */
        if (result.id) {

            currentDiagramId =
                Number(result.id);

        }


        setStatus(
            'Saved successfully'
        );


        /*
         * The "Saved Diagrams" list is server-rendered once
         * at page load -- without this, a brand new save
         * (or a rename) doesn't appear there until the page
         * is reloaded.
         */
        if (currentDiagramId) {

            upsertSavedListEntry(
                currentDiagramId,
                result.name || name
            );

        }


        /*
         * Update browser URL without reloading.
         * This prevents the old ID problem.
         */
        if (currentDiagramId) {

            const newUrl =
                window.location.pathname +
                '?id=' +
                currentDiagramId;

            window.history.replaceState(
                {},
                '',
                newUrl
            );

        }

    } catch(error) {

        console.error(error);

        alert(
            'Unable to save diagram. ' +
            'Please check your database connection and PHP response.'
        );

        setStatus(
            'Save failed'
        );
    }
}


/* =========================================================
   OPEN SAVED DIAGRAM
========================================================= */

function openDiagram(id)
{
    window.location.href =
        window.location.pathname +
        '?id=' +
        encodeURIComponent(id);
}


/* =========================================================
   DELETE SAVED DIAGRAM
========================================================= */

async function deleteSavedDiagram(id)
{
    if (
        !confirm(
            'Are you sure you want to delete this diagram?'
        )
    ) {
        return;
    }


    const form =
        new FormData();

    form.append(
        'action',
        'delete_diagram'
    );

    form.append(
        'id',
        String(id)
    );


    try {

        const response =
            await fetch(
                window.location.href,
                {
                    method: 'POST',
                    body: form
                }
            );


        const result =
            await response.json();


        if (!result.success) {

            alert(
                result.message ||
                'Delete failed.'
            );

            return;
        }


        /*
         * If deleting current diagram,
         * go back to a blank diagram.
         */
        if (
            Number(currentDiagramId) ===
            Number(id)
        ) {

            window.location.href =
                window.location.pathname;

            return;
        }


        window.location.reload();

    } catch(error) {

        console.error(error);

        alert(
            'Unable to delete diagram.'
        );
    }
}


/* =========================================================
   NEW DIAGRAM
========================================================= */

function newDiagram()
{
    if (
        !confirm(
            'Create a new diagram? Unsaved changes will be lost.'
        )
    ) {
        return;
    }

    window.location.href =
        window.location.pathname;
}


/* =========================================================
   EXPORT
========================================================= */

function exportDiagram(format)
{
    /*
     * SVG export
     */
    if (format === 'svg') {

        const clone =
            svg.cloneNode(true);

        clone
            .querySelectorAll(
                '.selected-outline,' +
                '.rotate-line,' +
                '.rotate-handle,' +
                '.resize-handle,' +
                '.endpoint-handle,' +
                '.connection-selected'
            )
            .forEach(
                el => el.remove()
            );


        clone.setAttribute(
            'width',
            diagram.width
        );

        clone.setAttribute(
            'height',
            diagram.height
        );


        const serializer =
            new XMLSerializer();

        const source =
            serializer.serializeToString(
                clone
            );


        const blob =
            new Blob(
                [source],
                {
                    type:
                        'image/svg+xml;charset=utf-8'
                }
            );


        const url =
            URL.createObjectURL(blob);

        const a =
            document.createElement('a');

        a.href = url;

        a.download =
            (
                document.getElementById(
                    'diagramName'
                ).value ||
                'diagram'
            ) +
            '.svg';

        a.click();

        URL.revokeObjectURL(url);

        return;
    }


    /*
     * PNG/JPG
     */
    const clone =
        svg.cloneNode(true);

    clone
        .querySelectorAll(
            '.selected-outline,' +
            '.rotate-line,' +
            '.rotate-handle,' +
            '.resize-handle,' +
            '.endpoint-handle,' +
            '.connection-selected'
        )
        .forEach(
            el => el.remove()
        );


    clone.setAttribute(
        'width',
        diagram.width
    );

    clone.setAttribute(
        'height',
        diagram.height
    );


    const serializer =
        new XMLSerializer();

    const source =
        serializer.serializeToString(
            clone
        );


    const svgBlob =
        new Blob(
            [source],
            {
                type:
                    'image/svg+xml;charset=utf-8'
            }
        );


    const url =
        URL.createObjectURL(
            svgBlob
        );


    const img =
        new Image();


    img.onload = function()
    {
        const canvas =
            document.createElement(
                'canvas'
            );

        canvas.width =
            diagram.width;

        canvas.height =
            diagram.height;


        const ctx =
            canvas.getContext(
                '2d'
            );


        ctx.fillStyle =
            diagram.background ||
            '#FFFFFF';

        ctx.fillRect(
            0,
            0,
            canvas.width,
            canvas.height
        );


        ctx.drawImage(
            img,
            0,
            0
        );


        const mime =
            format === 'jpg'
                ? 'image/jpeg'
                : 'image/png';


        const extension =
            format === 'jpg'
                ? 'jpg'
                : 'png';


        const a =
            document.createElement(
                'a'
            );

        a.href =
            canvas.toDataURL(
                mime,
                .95
            );

        a.download =
            (
                document.getElementById(
                    'diagramName'
                ).value ||
                'diagram'
            ) +
            '.' +
            extension;

        a.click();


        URL.revokeObjectURL(
            url
        );

    };


    img.src = url;
}


/* =========================================================
   KEYBOARD SHORTCUTS
========================================================= */

document.addEventListener(
    'keydown',
    function(e)
    {
        /*
         * Escape -- cancel an armed/in-progress free draw,
         * or close the expand popup if that's open instead
         */
        if (e.key === 'Escape' && (freehandArmed || freehandDraft)) {

            cancelFreehand();

            return;
        }

        if (e.key === 'Escape' && expandContext) {

            closeExpandPopup();

            return;
        }

        if (
            e.key === 'Escape' &&
            !document.getElementById('templateOverlay').hidden
        ) {

            closeTemplatePicker();

            return;
        }


        /*
         * Delete
         */
        if (
            e.key === 'Delete' &&
            document.activeElement.tagName !== 'INPUT'
        ) {

            deleteSelected();

            return;
        }


        /*
         * Ctrl + D
         */
        if (
            (e.ctrlKey || e.metaKey) &&
            e.key.toLowerCase() === 'd'
        ) {

            e.preventDefault();

            duplicateSelected();

            return;
        }


        /*
         * Ctrl + S
         */
        if (
            (e.ctrlKey || e.metaKey) &&
            e.key.toLowerCase() === 's'
        ) {

            e.preventDefault();

            saveDiagram();

            return;
        }


        /*
         * Ctrl + Z
         */
        if (
            (e.ctrlKey || e.metaKey) &&
            e.key.toLowerCase() === 'z'
        ) {

            e.preventDefault();

            undo();

            return;
        }


        /*
         * Ctrl + Y
         */
        if (
            (e.ctrlKey || e.metaKey) &&
            e.key.toLowerCase() === 'y'
        ) {

            e.preventDefault();

            redo();

            return;
        }
    }
);


/* =========================================================
   START
========================================================= */

initPaletteIcons();

renderPageTabs();

pushHistory();

renderCanvas();

renderPropertiesPanel();

</script>

<?php
require_once __DIR__ . '/includes/footer.php';
?>