<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('builds', 'can_view');
requirePermission('builds', 'can_import');


$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');

/* Permission check */
function buildsHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'builds', $permission);
}

$canImport = buildsHasPermission($pdo, $role, 'can_import');
$canEdit = buildsHasPermission($pdo, $role, 'can_edit');

if (!$canImport || !$canEdit) {
    http_response_code(403);
    exit('You do not have permission to import build records.');
}

$error = '';
$success = '';
$imported_count = 0;
$skipped_count = 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['csv_file'])) {

    if ($_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        $error = 'File upload failed.';
    } else {

        $file_path = $_FILES['csv_file']['tmp_name'];
        $handle = fopen($file_path, 'r');

        if (!$handle) {
            $error = 'Unable to open CSV file.';
        } else {

            $header = fgetcsv($handle);
            $expected_cols = ['build_no', 'project', 'status', 'build_by', 'supported_by', 'build_from', 'comments'];

            if (!$header || array_slice($header, 0, count($expected_cols)) !== $expected_cols) {
                $error = 'CSV header does not match expected format. Expected: ' . implode(', ', $expected_cols);
            } else {

                try {
                    $pdo->beginTransaction();

                    while (($row = fgetcsv($handle)) !== false) {

                        if (empty(array_filter($row))) {
                            continue;
                        }

                        $build_no = trim($row[0] ?? '');
                        $project = trim($row[1] ?? '');
                        $status = trim($row[2] ?? '');
                        $build_by = trim($row[3] ?? '');
                        $supported_by = trim($row[4] ?? '');
                        $build_from = trim($row[5] ?? '');
                        $comments = trim($row[6] ?? '');

                        if (empty($build_no) || empty($project) || empty($status) || empty($build_by)) {
                            $skipped_count++;
                            continue;
                        }

                        if (!in_array($status, ['In Progress', 'Completed', 'On Hold', 'Cancelled'], true)) {
                            $skipped_count++;
                            continue;
                        }

                        $build_by_int = (int)$build_by;
                        if ($build_by_int <= 0) {
                            $skipped_count++;
                            continue;
                        }

                        try {
                            $stmt = $pdo->prepare("
                                INSERT INTO builds
                                (build_no, project, status, build_by, supported_by, build_from, comments, user_id, created_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                            ");

                            $stmt->execute([
                                $build_no,
                                $project,
                                $status,
                                $build_by_int,
                                $supported_by ?: null,
                                $build_from ?: null,
                                $comments ?: null,
                                $current_user_id
                            ]);

                            $build_id = $pdo->lastInsertId();

                            $hist_stmt = $pdo->prepare("
                                INSERT INTO build_history
                                (build_id, user_id, action, changes, created_at)
                                VALUES (?, ?, 'Created', 'Imported from CSV', CURRENT_TIMESTAMP)
                            ");
                            $hist_stmt->execute([$build_id, $current_user_id]);

                            $imported_count++;

                        } catch (Exception $e) {
                            $skipped_count++;
                        }
                    }

                    $pdo->commit();
                    $success = "Successfully imported $imported_count record(s). Skipped: $skipped_count.";

                } catch (Exception $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }
                    $error = 'Transaction failed: ' . $e->getMessage();
                }
            }

            fclose($handle);
        }
    }
}

$page_title = "Import Builds | InfraVault";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<div class="content">
    <div class="dashboard-header">
        <div>
            <h1>Import Builds</h1>
            <p>Import build records from a CSV file.</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div style="padding:13px 18px;border-radius:10px;font-size:14px;font-weight:500;margin-bottom:20px;border:1px solid transparent;background:#ECFDF5;border-color:#A7F3D0;color:#047857;">
            <?= htmlspecialchars($success) ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div style="padding:13px 18px;border-radius:10px;font-size:14px;font-weight:500;margin-bottom:20px;border:1px solid transparent;background:#FEF2F2;border-color:#FECACA;color:#B91C1C;">
            <?= htmlspecialchars($error) ?>
        </div>
    <?php endif; ?>

    <div class="dashboard-panel">
        <div class="panel-header">
            <h3>CSV Import Instructions</h3>
        </div>

        <div style="background:var(--hover-bg);padding:20px;border-radius:10px;border:1px solid var(--border-color);margin-bottom:20px;">
            <p style="margin:0 0 15px;color:var(--text-secondary);font-size:13px;">
                <strong>Expected CSV Format:</strong>
            </p>
            <code style="display:block;background:var(--hover-bg);padding:12px;border-radius:6px;overflow-x:auto;font-size:12px;margin-bottom:15px;line-height:1.6;">
build_no,project,status,build_by,supported_by,build_from,comments<br>
BLD-2026-001,Project Alpha,In Progress,5,HCL,provisioning team,Initial build<br>
BLD-2026-002,Project Beta,Completed,7,Ejada,,Phase 2
            </code>
            <ul style="margin:0;padding-left:20px;color:var(--text-secondary);font-size:13px;">
                <li><strong>build_no</strong> (required): Unique build identifier</li>
                <li><strong>project</strong> (required): Project name</li>
                <li><strong>status</strong> (required): One of: In Progress, Completed, On Hold, Cancelled</li>
                <li><strong>build_by</strong> (required): User ID of the builder</li>
                <li><strong>supported_by</strong> (optional): Support team name</li>
                <li><strong>build_from</strong> (optional): Build source/stage</li>
                <li><strong>comments</strong> (optional): Additional comments</li>
            </ul>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <div class="bd-field" style="margin-bottom:20px;">
                <label>Select CSV File *</label>
                <input type="file" name="csv_file" accept=".csv" required style="display:block;width:100%;padding:10px 12px;border:1px solid var(--border-color);border-radius:9px;font-size:14px;box-sizing:border-box;">
            </div>

            <div style="display:flex;gap:10px;justify-content:flex-end;">
                <a href="builds.php" class="bd-btn bd-btn-ghost">Cancel</a>
                <button type="submit" class="bd-btn bd-btn-primary">Import CSV</button>
            </div>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
