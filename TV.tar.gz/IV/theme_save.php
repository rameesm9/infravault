<?php

require_once __DIR__ . '/config/db.php';

header('Content-Type: application/json');

if (!authzIsLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not logged in.']);
    exit;
}

csrfVerifyOrDie();

$theme = ($_POST['theme'] ?? '') === 'dark' ? 'dark' : 'light';

$pdo->prepare("UPDATE users SET theme = ? WHERE id = ?")
    ->execute([$theme, (int) $_SESSION['user_id']]);

$_SESSION['theme'] = $theme;

echo json_encode(['success' => true, 'theme' => $theme]);
