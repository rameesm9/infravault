<?php

session_start();

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| This page had no login check at all. It called session_start() and went
| straight to including the header and sidebar -- and neither of those
| redirects an anonymous visitor either, so there was no gate anywhere on
| the request path. A request with no session rendered the full dashboard:
| asset and server counts, knowledge base and SOP totals, the inventory
| breakdowns, and the Recent Activity panel, which carries audit detail
| and the names of the users who performed each action.
|
| config/db.php is required first (rather than relying on header.php to
| pull it in) so requireLogin() exists before any output is produced.
*/

require_once __DIR__ . '/config/db.php';

requireLogin();
requirePermission('dashboard', 'can_view');

// One-time arrival animation right after signing in -- set by index.php /
// change-password.php on a successful login, never by ordinary in-app
// navigation back to the dashboard (e.g. clicking the sidebar link).
$show_login_intro = !empty($_SESSION['just_logged_in']);
unset($_SESSION['just_logged_in']);


/*
|--------------------------------------------------------------------------
| Spotlight customization (AJAX) -- reorder / dismiss / reset
|--------------------------------------------------------------------------
|
| Must run before includes/header.php produces any output. Only ever
| touches dashboard_spotlight_prefs for the current user -- never the
| underlying communications/reminders/sticky_notes rows, so "dismiss"
| can't accidentally delete real data.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['spotlight_action'])) {

    require_once __DIR__ . '/includes/security.php';
    csrfVerifyOrDie();

    header('Content-Type: application/json');

    $spotlight_user_id = (int) ($_SESSION['user_id'] ?? 0);

    if ($spotlight_user_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Not logged in']);
        exit;
    }

    $spotlight_action = (string) $_POST['spotlight_action'];

    try {

        if ($spotlight_action === 'dismiss') {

            $item_key = trim((string) ($_POST['item_key'] ?? ''));

            if ($item_key !== '') {
                $stmt = $pdo->prepare("
                    INSERT INTO dashboard_spotlight_prefs (user_id, item_key, dismissed, updated_at)
                    VALUES (?, ?, 1, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, item_key)
                    DO UPDATE SET dismissed = 1, updated_at = CURRENT_TIMESTAMP
                ");
                $stmt->execute([$spotlight_user_id, $item_key]);
            }

            echo json_encode(['success' => true]);
            exit;
        }

        if ($spotlight_action === 'reorder') {

            $order = json_decode((string) ($_POST['order'] ?? '[]'), true);

            if (is_array($order)) {
                $stmt = $pdo->prepare("
                    INSERT INTO dashboard_spotlight_prefs (user_id, item_key, sort_order, updated_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, item_key)
                    DO UPDATE SET sort_order = excluded.sort_order, updated_at = CURRENT_TIMESTAMP
                ");

                foreach (array_values($order) as $index => $key) {
                    $key = trim((string) $key);
                    if ($key !== '') {
                        $stmt->execute([$spotlight_user_id, $key, $index]);
                    }
                }
            }

            echo json_encode(['success' => true]);
            exit;
        }

        if ($spotlight_action === 'reset') {

            $stmt = $pdo->prepare("DELETE FROM dashboard_spotlight_prefs WHERE user_id = ?");
            $stmt->execute([$spotlight_user_id]);

            echo json_encode(['success' => true]);
            exit;
        }

        echo json_encode(['success' => false, 'error' => 'Unknown action']);
        exit;

    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'error' => 'Server error']);
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| Dashboard panel layout (AJAX) -- reorder / reset
|--------------------------------------------------------------------------
|
| Same pattern as the spotlight customization above, for the drag-and-drop
| order of the dashboard's own tiles (Asset Growth, Asset Types, the
| breakdown panels, etc.). Only ever touches dashboard_panel_prefs for the
| current user -- never any of the underlying asset/inventory/KB data.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['panel_layout_action'])) {

    require_once __DIR__ . '/includes/security.php';
    csrfVerifyOrDie();

    header('Content-Type: application/json');

    $panel_layout_user_id = (int) ($_SESSION['user_id'] ?? 0);

    if ($panel_layout_user_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Not logged in']);
        exit;
    }

    $panel_layout_action = (string) $_POST['panel_layout_action'];

    try {

        if ($panel_layout_action === 'reorder') {

            $order = json_decode((string) ($_POST['order'] ?? '[]'), true);

            if (is_array($order)) {
                $stmt = $pdo->prepare("
                    INSERT INTO dashboard_panel_prefs (user_id, panel_key, sort_order, updated_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, panel_key)
                    DO UPDATE SET sort_order = excluded.sort_order, updated_at = CURRENT_TIMESTAMP
                ");

                foreach (array_values($order) as $index => $key) {
                    $key = trim((string) $key);
                    if ($key !== '') {
                        $stmt->execute([$panel_layout_user_id, $key, $index]);
                    }
                }
            }

            echo json_encode(['success' => true]);
            exit;
        }

        if ($panel_layout_action === 'reset') {

            $stmt = $pdo->prepare("DELETE FROM dashboard_panel_prefs WHERE user_id = ?");
            $stmt->execute([$panel_layout_user_id]);

            echo json_encode(['success' => true]);
            exit;
        }

        echo json_encode(['success' => false, 'error' => 'Unknown action']);
        exit;

    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'error' => 'Server error']);
        exit;
    }
}


$page_title = "Dashboard | InfraVault";

include "includes/header.php";

include "includes/sidebar.php";

if ($show_login_intro):
?>
<div class="login-intro" id="loginIntro" aria-hidden="true">
    <div class="login-intro-orb">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
    </div>
    <div class="login-intro-text">Welcome back<?= $_SESSION['name'] ? ', ' . h(explode(' ', (string) $_SESSION['name'])[0]) : '' ?></div>
    <div class="login-intro-sub">Loading your dashboard&hellip;</div>
    <div class="login-intro-bar"><span></span></div>
</div>

<style>

.login-intro{
    position: fixed;
    inset: 0;
    z-index: 100000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 18px;
    background: radial-gradient(circle at 30% 20%, #0F172A 0%, #0B1220 45%, #020617 100%);
    animation: liFadeOut .55s ease 1.05s forwards;
}

.login-intro-orb{
    position: relative;
    width: 84px;
    height: 84px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: linear-gradient(135deg, #2563EB, #22D3EE);
    box-shadow: 0 0 60px rgba(34, 211, 238, .45);
    animation: liPulse 1.4s ease-in-out infinite;
}

.login-intro-orb::before{
    content: "";
    position: absolute;
    inset: -10px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: #22D3EE;
    border-right-color: #4F46E5;
    animation: liSpin .9s linear infinite;
}

.login-intro-orb svg{
    width: 36px;
    height: 36px;
    color: #fff;
}

.login-intro-text{
    color: #F1F5F9;
    font: 700 16px/1.3 Inter, "Segoe UI", Arial, sans-serif;
    letter-spacing: .01em;
    opacity: 0;
    animation: liTextIn .4s ease .15s forwards;
}

.login-intro-sub{
    color: #94A3B8;
    font: 500 12.5px Inter, "Segoe UI", Arial, sans-serif;
    opacity: 0;
    animation: liTextIn .4s ease .3s forwards;
}

.login-intro-bar{
    width: 160px;
    height: 4px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .1);
    overflow: hidden;
    opacity: 0;
    animation: liTextIn .4s ease .3s forwards;
}

.login-intro-bar span{
    display: block;
    height: 100%;
    width: 0%;
    border-radius: 999px;
    background: linear-gradient(90deg, #2563EB, #22D3EE);
    animation: liBarFill .85s ease .2s forwards;
}

@keyframes liSpin{
    to{ transform: rotate(360deg); }
}

@keyframes liPulse{
    0%, 100%{ transform: scale(1); }
    50%{ transform: scale(1.06); }
}

@keyframes liTextIn{
    from{ opacity: 0; transform: translateY(6px); }
    to{ opacity: 1; transform: none; }
}

@keyframes liBarFill{
    from{ width: 0%; }
    to{ width: 100%; }
}

@keyframes liFadeOut{
    to{ opacity: 0; visibility: hidden; }
}

@media (prefers-reduced-motion: reduce){
    .login-intro, .login-intro-orb, .login-intro-orb::before,
    .login-intro-text, .login-intro-sub, .login-intro-bar, .login-intro-bar span{
        animation: none !important;
    }
    .login-intro{ display: none; }
}

</style>

<script>
(function(){
    var el = document.getElementById('loginIntro');
    if(!el){ return; }
    el.addEventListener('animationend', function(e){
        if(e.animationName === 'liFadeOut'){
            el.remove();
        }
    });
})();
</script>
<?php
endif;

/*
|--------------------------------------------------------------------------
| DASHBOARD DATA
|--------------------------------------------------------------------------
|
| $pdo, $header_notifications and notif_time_ago() all come from
| includes/header.php (which is included above), so nothing extra
| needs to be required here.
|
*/

function h(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| Assets
|--------------------------------------------------------------------------
*/

$asset_total = (int) $pdo->query(
    "SELECT COUNT(*) FROM asset"
)->fetchColumn();

$asset_status_counts = [];

foreach (
    $pdo->query("SELECT status, COUNT(*) AS c FROM asset GROUP BY status")
        ->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {
    $asset_status_counts[$row['status'] ?: 'Unspecified'] = (int) $row['c'];
}

$asset_in_service = $asset_status_counts['In Service'] ?? 0;

$asset_type_counts = [];

foreach (
    $pdo->query("
        SELECT asset_type, COUNT(*) AS c
        FROM asset
        GROUP BY asset_type
        ORDER BY c DESC
    ")->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {
    $asset_type_counts[$row['asset_type'] ?: 'Unspecified'] = (int) $row['c'];
}


// Asset growth -- real count of assets created per period, customizable window
// (1 week / 1 month bucket by day; 1-5 years bucket by month), driven by the
// asset_growth_range GET param so the chart's own dropdown can reload the page.
$asset_growth_ranges = [
    '1w' => ['option' => '1 Week',   'unit' => 'day',   'count' => 7],
    '1m' => ['option' => '1 Month',  'unit' => 'day',   'count' => 30],
    '1y' => ['option' => '1 Year',   'unit' => 'month', 'count' => 12],
    '2y' => ['option' => '2 Years',  'unit' => 'month', 'count' => 24],
    '3y' => ['option' => '3 Years',  'unit' => 'month', 'count' => 36],
    '4y' => ['option' => '4 Years',  'unit' => 'month', 'count' => 48],
    '5y' => ['option' => '5 Years',  'unit' => 'month', 'count' => 60],
];

$asset_growth_range = (string) ($_GET['asset_growth_range'] ?? '1y');
if (!isset($asset_growth_ranges[$asset_growth_range])) {
    $asset_growth_range = '1y';
}

$asset_growth_unit    = $asset_growth_ranges[$asset_growth_range]['unit'];
$asset_growth_count   = $asset_growth_ranges[$asset_growth_range]['count'];

$asset_growth_labels = [];
$asset_growth_data = [];

if ($asset_growth_unit === 'day') {

    $growth_stmt = $pdo->prepare("
        SELECT COUNT(*) FROM asset
        WHERE strftime('%Y-%m-%d', created_at) = ?
    ");

    for ($i = $asset_growth_count - 1; $i >= 0; $i--) {

        $day_ts = strtotime("-{$i} days");

        $asset_growth_labels[] = date('M j', $day_ts);

        $growth_stmt->execute([date('Y-m-d', $day_ts)]);

        $asset_growth_data[] = (int) $growth_stmt->fetchColumn();
    }

} else {

    $growth_stmt = $pdo->prepare("
        SELECT COUNT(*) FROM asset
        WHERE strftime('%Y-%m', created_at) = ?
    ");

    for ($i = $asset_growth_count - 1; $i >= 0; $i--) {

        $month_ts = strtotime("-{$i} months", strtotime(date('Y-m-01')));

        $asset_growth_labels[] = $asset_growth_count > 12
            ? date('M Y', $month_ts)
            : date('M', $month_ts);

        $growth_stmt->execute([date('Y-m', $month_ts)]);

        $asset_growth_data[] = (int) $growth_stmt->fetchColumn();
    }
}


/*
|--------------------------------------------------------------------------
| Inventory scope -- every inventory-derived stat on this dashboard
| (Servers KPI card, Server Inventory Growth chart, and the OS Family /
| OS Version / Managed By / Support Level breakdown panels) is scoped
| to ACTIVE servers only: powered on AND live, the same "Active Servers"
| definition inventory.php's own filter checkbox uses. Never decommissioned
| or otherwise inactive hardware, which would otherwise inflate counts
| with hardware that's no longer actually in service.
|
| On top of that, an optional "Managed By" filter (checkboxes below the
| breakdown row) narrows the same set further -- e.g. HCL only, or
| HCL+STC -- so a team can see just the fleet they're responsible for.
| Plain GET query string, same pattern as inventory.php's own filters;
| not persisted per-user, so it resets to "All" on a fresh visit.
|--------------------------------------------------------------------------
*/

$inv_managed_by_options = [];
try {
    $inv_managed_by_options = $pdo->query("
        SELECT DISTINCT COALESCE(NULLIF(TRIM(managed_by), ''), 'Unspecified') AS m
        FROM inventory
        WHERE LOWER(TRIM(server_state)) = 'powered on' AND LOWER(TRIM(live)) = 'yes'
        ORDER BY m ASC
    ")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    $inv_managed_by_options = [];
}

$inv_filter_applied = isset($_GET['inv_filter_applied']);

if ($inv_filter_applied) {
    $inv_managed_by_selected = array_values(array_intersect(
        $inv_managed_by_options,
        (array) ($_GET['inv_managed_by'] ?? [])
    ));
} else {
    $inv_managed_by_selected = $inv_managed_by_options;
}

$inv_where = "LOWER(TRIM(server_state)) = 'powered on' AND LOWER(TRIM(live)) = 'yes'";
$inv_where_params = [];

if ($inv_filter_applied && count($inv_managed_by_selected) < count($inv_managed_by_options)) {

    if (empty($inv_managed_by_selected)) {
        // Every option explicitly unchecked -- a valid choice, show nothing
        // rather than silently falling back to "all".
        $inv_where .= " AND 1=0";
    } else {
        $placeholders = implode(',', array_fill(0, count($inv_managed_by_selected), '?'));
        $inv_where .= " AND COALESCE(NULLIF(TRIM(managed_by), ''), 'Unspecified') IN ($placeholders)";
        $inv_where_params = $inv_managed_by_selected;
    }
}

$inv_filter_label = (
    $inv_filter_applied && count($inv_managed_by_selected) < count($inv_managed_by_options)
) ? (
    $inv_managed_by_selected ? implode(', ', $inv_managed_by_selected) : 'None selected'
) : 'All managed-by teams';


// Server (inventory) growth -- real count of ACTIVE servers created per period,
// customizable window (same asset_growth_ranges map, own GET param), still
// scoped by the "Managed By" filter above.
$inv_growth_range = (string) ($_GET['inv_growth_range'] ?? '1y');
if (!isset($asset_growth_ranges[$inv_growth_range])) {
    $inv_growth_range = '1y';
}

$inv_growth_unit  = $asset_growth_ranges[$inv_growth_range]['unit'];
$inv_growth_count = $asset_growth_ranges[$inv_growth_range]['count'];

$inv_growth_labels = [];
$inv_growth_data = [];

if ($inv_growth_unit === 'day') {

    $inv_growth_stmt = $pdo->prepare("
        SELECT COUNT(*) FROM inventory
        WHERE strftime('%Y-%m-%d', created_at) = ? AND $inv_where
    ");

    for ($i = $inv_growth_count - 1; $i >= 0; $i--) {

        $day_ts = strtotime("-{$i} days");

        $inv_growth_labels[] = date('M j', $day_ts);

        $inv_growth_stmt->execute(array_merge([date('Y-m-d', $day_ts)], $inv_where_params));

        $inv_growth_data[] = (int) $inv_growth_stmt->fetchColumn();
    }

} else {

    $inv_growth_stmt = $pdo->prepare("
        SELECT COUNT(*) FROM inventory
        WHERE strftime('%Y-%m', created_at) = ? AND $inv_where
    ");

    for ($i = $inv_growth_count - 1; $i >= 0; $i--) {

        $month_ts = strtotime("-{$i} months", strtotime(date('Y-m-01')));

        $inv_growth_labels[] = $inv_growth_count > 12
            ? date('M Y', $month_ts)
            : date('M', $month_ts);

        $inv_growth_stmt->execute(array_merge([date('Y-m', $month_ts)], $inv_where_params));

        $inv_growth_data[] = (int) $inv_growth_stmt->fetchColumn();
    }
}


/*
|--------------------------------------------------------------------------
| Inventory (Servers)
|--------------------------------------------------------------------------
*/

$inventory_total_stmt = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE $inv_where");
$inventory_total_stmt->execute($inv_where_params);
$inventory_total = (int) $inventory_total_stmt->fetchColumn();


/*
|--------------------------------------------------------------------------
| IP Address Management
|--------------------------------------------------------------------------
*/

$ip_total = (int) $pdo->query(
    "SELECT COUNT(*) FROM ip_ranges"
)->fetchColumn();

$ip_usable_sum = (int) $pdo->query(
    "SELECT COALESCE(SUM(usable_hosts), 0) FROM ip_ranges"
)->fetchColumn();


/*
|--------------------------------------------------------------------------
| Notifications summary (reuses the same feed as the header bell)
|--------------------------------------------------------------------------
*/

$comm_count = count($header_notifications['communications']);
$reminder_count = count($header_notifications['reminders']);
$sticky_count = count($header_notifications['sticky_notes']);
$shared_data_count = count($header_notifications['shared_data']);
$kb_sop_activity_count = count($header_notifications['kb_sop_activity']);


/*
|--------------------------------------------------------------------------
| "For You" spotlight -- merges everything actually tied to this user's
| name into one ranked feed: assignments/handovers first (they have a
| specific named owner), then overdue reminders, then team notes, then
| the rest by recency. Rendered at the very top of the page, above the
| KPI cards, per the redesign brief -- this is deliberately a different
| (smaller, ranked, personal) view than the full feed further down.
|--------------------------------------------------------------------------
*/

$spotlight_items = [];

if ($header_notifications['oncall_current']) {

    $oc = $header_notifications['oncall_current'];

    $spotlight_items[] = [
        'key'   => 'oncall_' . $oc['id'],
        'rank'  => -1,
        'tone'  => 'critical',
        'icon'  => '📟',
        'badge' => 'On-Call Now',
        'title' => $oc['shift_label'] ?: ($oc['rota_team'] ?: 'On-Call Shift') . ' (' . $oc['my_role'] . ')',
        'meta'  => 'Until ' . date('d M, H:i', strtotime($oc['ends_at'])),
        'time'  => (string) $oc['starts_at'],
        'href'  => 'oncall.php',
    ];
}

foreach ($header_notifications['assigned_to_me'] as $c) {

    $overdue = !empty($c['target_date']) && $c['target_date'] < date('Y-m-d');

    $meta = trim(($c['note_type'] ?: 'Handover Task'));
    if (!empty($c['target_date'])) {
        $meta .= ' · ' . ($overdue ? 'Overdue since ' : 'Due ') . date('d M', strtotime($c['target_date']));
    }

    $spotlight_items[] = [
        'key'   => 'assigned_' . $c['id'],
        'rank'  => 0,
        'tone'  => $overdue ? 'critical' : 'assigned',
        'icon'  => '🤝',
        'badge' => 'Assigned to You',
        'title' => (string) $c['title'],
        'meta'  => $meta,
        'time'  => (string) ($c['target_date'] ?: $c['created_at']),
        'href'  => 'notification.php',
    ];
}

$assigned_ids = array_column($header_notifications['assigned_to_me'], 'id');

foreach ($header_notifications['reminders'] as $r) {

    $overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s');

    $spotlight_items[] = [
        'key'   => 'reminder_' . $r['id'],
        'rank'  => $overdue ? 1 : 3,
        'tone'  => $overdue ? 'critical' : 'reminder',
        'icon'  => '⏰',
        'badge' => $overdue ? 'Overdue Reminder' : 'Reminder',
        'title' => (string) $r['title'],
        'meta'  => ($overdue ? 'Was due ' : 'Due ') . date('d M, H:i', strtotime($r['reminder_date'])),
        'time'  => (string) $r['reminder_date'],
        'href'  => 'reminders.php',
    ];
}

foreach ($header_notifications['communications'] as $c) {

    // Already surfaced above as a personal assignment -- don't show twice.
    if (in_array($c['id'], $assigned_ids, true)) {
        continue;
    }

    $spotlight_items[] = [
        'key'   => 'note_' . $c['id'],
        'rank'  => 2,
        'tone'  => 'note',
        'icon'  => '📌',
        'badge' => 'Team Note',
        'title' => (string) $c['title'],
        'meta'  => ($c['note_type'] ?: 'Announcement') . ' · ' . notif_time_ago($c['created_at']),
        'time'  => (string) $c['created_at'],
        'href'  => 'notification.php',
    ];
}

foreach ($header_notifications['sticky_notes'] as $n) {

    $author = trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team';

    $spotlight_items[] = [
        'key'   => 'sticky_' . $n['id'],
        'rank'  => 4,
        'tone'  => 'sticky',
        'icon'  => '🗒',
        'badge' => 'Sticky Note',
        'title' => infravault_truncate((string) $n['content'], 70),
        'meta'  => $author . ' · ' . notif_time_ago($n['updated_at']),
        'time'  => (string) $n['updated_at'],
        'href'  => 'reminders.php',
    ];
}

foreach ($header_notifications['shared_data'] as $d) {

    $owner = trim(($d['owner_first'] ?? '') . ' ' . ($d['owner_last'] ?? '')) ?: 'Someone';

    $spotlight_items[] = [
        'key'   => 'mydata_' . $d['id'],
        'rank'  => 4,
        'tone'  => 'sticky',
        'icon'  => '📁',
        'badge' => 'Shared Data',
        'title' => (string) $d['title'],
        'meta'  => ($d['visibility'] === 'Team' ? 'Shared with your team' : 'Shared with you') . ' · ' . $owner . ' · ' . notif_time_ago($d['updated_at']),
        'time'  => (string) $d['updated_at'],
        'href'  => 'mydata.php?view=' . (int) $d['id'],
    ];
}

usort($spotlight_items, function ($a, $b) {
    if ($a['rank'] !== $b['rank']) {
        return $a['rank'] <=> $b['rank'];
    }
    return strcmp($b['time'], $a['time']);
});


/*
|--------------------------------------------------------------------------
| Per-user spotlight customization -- dismissed cards are dropped, cards
| the user has manually dragged keep the position they were dropped in
| (sorted by their stored sort_order, ascending); anything never touched
| falls in afterwards in the default rank/recency order computed above.
| A brand new item (a new reminder, a newly assigned handover) always has
| no stored row yet, so it simply appears in the "untouched" tail rather
| than being hidden or forced to a stale position.
|--------------------------------------------------------------------------
*/

$spotlight_prefs = [];

try {
    $stmt = $pdo->prepare("
        SELECT item_key, sort_order, dismissed
        FROM dashboard_spotlight_prefs
        WHERE user_id = ?
    ");
    $stmt->execute([(int) ($_SESSION['user_id'] ?? 0)]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $p) {
        $spotlight_prefs[$p['item_key']] = $p;
    }
} catch (Throwable $e) {
    $spotlight_prefs = [];
}

$spotlight_has_prefs = (bool) $spotlight_prefs;

$spotlight_items = array_values(array_filter(
    $spotlight_items,
    fn($item) => empty($spotlight_prefs[$item['key']]['dismissed'])
));

$spotlight_pinned = [];
$spotlight_unpinned = [];

foreach ($spotlight_items as $item) {
    $pref = $spotlight_prefs[$item['key']] ?? null;
    if ($pref !== null && $pref['sort_order'] !== null) {
        $item['_order'] = (int) $pref['sort_order'];
        $spotlight_pinned[] = $item;
    } else {
        $spotlight_unpinned[] = $item;
    }
}

usort($spotlight_pinned, fn($a, $b) => $a['_order'] <=> $b['_order']);

$spotlight_items = array_merge($spotlight_pinned, $spotlight_unpinned);

$spotlight_total = count($spotlight_items);
$spotlight_items = array_slice($spotlight_items, 0, 6);


/*
|--------------------------------------------------------------------------
| Recent Activity -- merged from the per-module history tables
|--------------------------------------------------------------------------
*/

$history_sources = [
    'asset_history'        => 'Asset',
    'inventory_history'    => 'Inventory',
    'ip_ranges_history'    => 'IP Range',
    'ownership_history'    => 'Ownership',
    'decommission_history' => 'Decommission',
];

$recent_activity = [];

foreach ($history_sources as $table => $label) {

    try {

        $rows = $pdo->query("
            SELECT action_type, performed_by, details, timestamp
            FROM {$table}
            ORDER BY timestamp DESC
            LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {

        $rows = [];
    }

    foreach ($rows as $row) {

        // ip_ranges_history stores a raw JSON snapshot in "details" --
        // not readable inline, so summarize instead of dumping it.
        if ($table === 'ip_ranges_history') {
            $text = 'IP range details were updated.';
        } else {
            $text = trim(strtok((string) ($row['details'] ?? ''), "\n"));
        }

        $recent_activity[] = [
            'module'       => $label,
            'action'       => $row['action_type'] ?? '',
            'text'         => $text,
            'performed_by' => trim((string) ($row['performed_by'] ?? '')) ?: 'System',
            'timestamp'    => $row['timestamp'] ?? '',
        ];
    }
}

usort(
    $recent_activity,
    fn($a, $b) => strcmp($b['timestamp'], $a['timestamp'])
);

$recent_activity = array_slice($recent_activity, 0, 8);


$activity_icons = [
    'CREATE'      => '＋',
    'CREATED'     => '＋',
    'UPDATE'      => '✎',
    'UPDATED'     => '✎',
    'DELETE'      => '🗑',
    'DELETED'     => '🗑',
    'BULK IMPORT' => '⇪',
];


/*
|--------------------------------------------------------------------------
| Breakdown helper
|--------------------------------------------------------------------------
|
| Every "X by Y" panel below is the same shape: group a column, count, order
| by count. Wrapped in try/catch so one missing table degrades that panel to
| an empty state instead of fatal-erroring the whole dashboard.
|
| NULLIF(TRIM(col),'') folds empty strings and NULLs into one "Unspecified"
| bucket rather than showing a blank row and an "Unspecified" row separately.
*/

function dashBreakdown(PDO $pdo, string $table, string $column, int $limit = 8, string $extraWhere = '', array $extraParams = []): array
{
    try {
        $stmt = $pdo->prepare("
            SELECT COALESCE(NULLIF(TRIM($column), ''), 'Unspecified') AS label,
                   COUNT(*) AS c
            FROM $table
            WHERE 1=1 $extraWhere
            GROUP BY label
            ORDER BY c DESC, label ASC
        ");

        $stmt->execute($extraParams);

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        return [];
    }

    // Long tails are rolled into a single "Other" bucket rather than
    // rendered as a run of 1-row entries.
    if (count($rows) > $limit) {
        $head = array_slice($rows, 0, $limit);
        $tailCount = 0;
        foreach (array_slice($rows, $limit) as $r) {
            $tailCount += (int) $r['c'];
        }
        $head[] = ['label' => 'Other (' . (count($rows) - $limit) . ' more)', 'c' => $tailCount];
        $rows = $head;
    }

    return array_map(
        fn($r) => ['label' => (string) $r['label'], 'count' => (int) $r['c']],
        $rows
    );
}

function dashTableExists(PDO $pdo, string $table): bool
{
    try {
        return (bool) $pdo->query(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=" . $pdo->quote($table)
        )->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function dashCount(PDO $pdo, string $sql): int
{
    try {
        return (int) $pdo->query($sql)->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}


/*
|--------------------------------------------------------------------------
| Inventory breakdowns -- OS Family, OS Version, Managed By
|--------------------------------------------------------------------------
*/

$inv_by_os_family = dashBreakdown($pdo, 'inventory', 'os_family', 8, " AND ($inv_where)", $inv_where_params);
$inv_by_managed_by = dashBreakdown($pdo, 'inventory', 'managed_by', 8, " AND ($inv_where)", $inv_where_params);
$inv_by_support_level = dashBreakdown($pdo, 'inventory', 'support_level', 8, " AND ($inv_where)", $inv_where_params);

/*
| OS version is reported as "family + version". A bare version number ("8")
| does not identify a platform on its own -- RHEL 8 and Ubuntu 8 would
| collapse into the same row -- and the patching scope question this panel
| answers is always asked per platform.
*/
$inv_by_os_version = [];
try {
    $osVersionStmt = $pdo->prepare("
        SELECT COALESCE(NULLIF(TRIM(os_family), ''), 'Unspecified') AS fam,
               COALESCE(NULLIF(TRIM(os_version), ''), 'Unspecified') AS ver,
               COUNT(*) AS c
        FROM inventory
        WHERE $inv_where
        GROUP BY fam, ver
        ORDER BY c DESC, fam ASC, ver ASC
    ");
    $osVersionStmt->execute($inv_where_params);
    $osVersionRows = $osVersionStmt->fetchAll(PDO::FETCH_ASSOC);

    // Capped at 7 + "Other" so the pie chart never needs more distinct
    // slices than the validated 8-hue categorical palette provides.
    $osVersionLimit = 7;
    foreach (array_slice($osVersionRows, 0, $osVersionLimit) as $r) {
        $inv_by_os_version[] = [
            'label' => $r['fam'] . ' ' . $r['ver'],
            'count' => (int) $r['c'],
        ];
    }

    if (count($osVersionRows) > $osVersionLimit) {
        $otherRows = array_slice($osVersionRows, $osVersionLimit);
        $otherCount = array_sum(array_map(fn($r) => (int) $r['c'], $otherRows));
        $inv_by_os_version[] = [
            'label' => 'Other (' . count($otherRows) . ' more)',
            'count' => $otherCount,
        ];
    }
} catch (Throwable $e) {
    $inv_by_os_version = [];
}


/*
|--------------------------------------------------------------------------
| Knowledge Base / SOPs / Known Issues
|--------------------------------------------------------------------------
*/

$kb_total   = dashCount($pdo, "SELECT COUNT(*) FROM knowledge_base");
$kb_by_category = dashBreakdown($pdo, 'knowledge_base', 'category', 6);

$kb_recent = [];
try {
    $kb_recent = $pdo->query("
        SELECT kb_number, title, category, COALESCE(updated_at, created_at) AS ts
        FROM knowledge_base
        ORDER BY ts DESC
        LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $kb_recent = [];
}

$sop_total = dashCount($pdo, "SELECT COUNT(*) FROM sops");
$sop_published = dashCount($pdo, "SELECT COUNT(*) FROM sops WHERE LOWER(TRIM(status)) = 'published'");
$sop_by_status = dashBreakdown($pdo, 'sops', 'status', 6);

// SOPs whose review date has passed -- the actionable SOP number.
$sop_review_due = dashCount($pdo, "
    SELECT COUNT(*) FROM sops
    WHERE review_date IS NOT NULL
      AND TRIM(review_date) <> ''
      AND date(review_date) <= date('now')
");

$ki_total = dashCount($pdo, "SELECT COUNT(*) FROM known_issues");
$ki_open = dashCount($pdo, "
    SELECT COUNT(*) FROM known_issues
    WHERE LOWER(TRIM(COALESCE(status, ''))) NOT IN ('closed', 'resolved')
");
$ki_by_severity = dashBreakdown($pdo, 'known_issues', 'severity', 6);
$ki_by_status = dashBreakdown($pdo, 'known_issues', 'status', 6);


/*
|--------------------------------------------------------------------------
| Admin tasks
|--------------------------------------------------------------------------
|
| Gated on the same RBAC the rest of the app uses rather than a hardcoded
| role string: whoever may edit the Users page is who may action these.
*/

require_once __DIR__ . '/includes/permission-helpers.php';

$dash_role = trim((string) ($_SESSION['role'] ?? ''));
$dash_is_admin = in_array(strtolower($dash_role), ['admin', 'administrator', 'super admin', 'superadmin'], true);

$canManageUsers = $dash_is_admin;
if (!$canManageUsers) {
    try {
        $canManageUsers = hasRolePermission($pdo, $dash_role, 'users', 'can_edit');
    } catch (Throwable $e) {
        $canManageUsers = false;
    }
}

$pending_users = [];
$pending_user_count = 0;

if ($canManageUsers) {
    try {
        $pending_users = $pdo->query("
            SELECT id, ncgr_id, first_name, last_name, email, role,
                   COALESCE(auth_source, 'local') AS auth_source
            FROM users
            WHERE is_approved = 0
            ORDER BY id DESC
            LIMIT 6
        ")->fetchAll(PDO::FETCH_ASSOC);

        $pending_user_count = dashCount($pdo, "SELECT COUNT(*) FROM users WHERE is_approved = 0");

    } catch (Throwable $e) {
        $pending_users = [];
    }
}

/*
| Other admin-actionable counts, shown alongside pending approvals so the
| panel is a task list rather than a single number.
*/
$admin_tasks = [];

if ($canManageUsers) {

    if ($pending_user_count > 0) {
        $admin_tasks[] = [
            'label' => $pending_user_count . ' user account' . ($pending_user_count === 1 ? '' : 's') . ' awaiting approval',
            'href'  => 'users.php',
            'cta'   => 'Review',
            'tone'  => 'critical',
        ];
    }

    if ($sop_review_due > 0) {
        $admin_tasks[] = [
            'label' => $sop_review_due . ' SOP' . ($sop_review_due === 1 ? '' : 's') . ' past their review date',
            'href'  => 'sop.php',
            'cta'   => 'Open SOPs',
            'tone'  => 'warning',
        ];
    }

    if ($ki_open > 0) {
        $admin_tasks[] = [
            'label' => $ki_open . ' known issue' . ($ki_open === 1 ? '' : 's') . ' still open',
            'href'  => 'known-issues.php',
            'cta'   => 'Open Issues',
            'tone'  => 'warning',
        ];
    }
}


/*
|--------------------------------------------------------------------------
| "My Assigned Work" -- an overview (counts only, not item lists -- the
| bell dropdown and the spotlight above already cover itemized views) of
| what this user personally owns across the modules that carry a named
| assignee. Each card is gated on that module's own can_view permission,
| via the same authz system every other page in this app uses, so a role
| without access to e.g. GRC never sees GRC numbers on their dashboard.
|--------------------------------------------------------------------------
*/

$dash_user_id = (int) ($_SESSION['user_id'] ?? 0);

$my_work_cards = [];

// --- Decommission -----------------------------------------------------
if (can('decommission', 'can_view')) {

    $decom_assigned = dashCount($pdo, "
        SELECT COUNT(*) FROM decommission WHERE assignee_id = {$dash_user_id}
    ");
    $decom_done = dashCount($pdo, "
        SELECT COUNT(*) FROM decommission
        WHERE assignee_id = {$dash_user_id}
          AND LOWER(TRIM(COALESCE(server_state, ''))) = 'decommissioned'
    ");

    if ($decom_assigned > 0) {
        $my_work_cards[] = [
            'icon'  => '🗑',
            'label' => 'Decommission',
            'total' => $decom_assigned,
            'done'  => $decom_done,
            'href'  => 'decommission.php?s_assignee=' . $dash_user_id,
            'color' => 'sky',
        ];
    }
}

// --- Quarterly Patching (current quarter) ------------------------------
if (can('patching', 'can_view')) {

    $patch_this_year = (int) date('Y');
    $patch_this_quarter = (int) ceil(((int) date('n')) / 3);

    $patch_assigned = dashCount($pdo, "
        SELECT COUNT(*)
        FROM patch_schedule_servers pss
        JOIN patch_schedules ps ON ps.id = pss.schedule_id
        WHERE pss.assigned_to = {$dash_user_id}
          AND pss.selected = 1
          AND ps.year = {$patch_this_year}
          AND ps.quarter = {$patch_this_quarter}
    ");
    $patch_done = dashCount($pdo, "
        SELECT COUNT(*)
        FROM patch_schedule_servers pss
        JOIN patch_schedules ps ON ps.id = pss.schedule_id
        WHERE pss.assigned_to = {$dash_user_id}
          AND pss.selected = 1
          AND ps.year = {$patch_this_year}
          AND ps.quarter = {$patch_this_quarter}
          AND pss.status = 'Completed'
    ");

    if ($patch_assigned > 0) {
        $my_work_cards[] = [
            'icon'  => '🩹',
            'label' => 'Patching Q' . $patch_this_quarter . ' ' . $patch_this_year,
            'total' => $patch_assigned,
            'done'  => $patch_done,
            'href'  => 'patching.php?f_assignee=' . $dash_user_id,
            'color' => 'amber',
        ];
    }
}

// --- SOP Review ---------------------------------------------------------
if (can('sop', 'can_view')) {

    $sop_pending_review = dashCount($pdo, "
        SELECT COUNT(*) FROM sops
        WHERE reviewer_id = {$dash_user_id} AND status = 'Pending Review'
    ");

    if ($sop_pending_review > 0) {
        $my_work_cards[] = [
            'icon'  => '📋',
            'label' => 'SOP Review',
            'total' => $sop_pending_review,
            'done'  => 0,
            'href'  => 'sop.php',
            'color' => 'indigo',
        ];
    }
}

// --- GRC Schedule ---------------------------------------------------------
if (can('grc_schedule', 'can_view')) {

    $grc_assigned = dashCount($pdo, "
        SELECT COUNT(*) FROM grc_schedules WHERE assignee_id = {$dash_user_id}
    ");
    $grc_done = dashCount($pdo, "
        SELECT COUNT(*) FROM grc_schedules
        WHERE assignee_id = {$dash_user_id} AND status = 'Patched'
    ");

    if ($grc_assigned > 0) {
        $my_work_cards[] = [
            'icon'  => '🛡',
            'label' => 'GRC Schedule',
            'total' => $grc_assigned,
            'done'  => $grc_done,
            'href'  => 'grc_schedule.php',
            'color' => 'teal',
        ];
    }
}

// --- Tickets -------------------------------------------------------------
if (can('ticket', 'can_view')) {

    $ticket_assigned = dashCount($pdo, "
        SELECT COUNT(*) FROM tickets
        WHERE assigned_to_id = {$dash_user_id}
          AND status NOT IN ('Resolved', 'Closed', 'Cancelled')
    ");
    $ticket_done = dashCount($pdo, "
        SELECT COUNT(*) FROM tickets
        WHERE assigned_to_id = {$dash_user_id}
          AND status IN ('Resolved', 'Closed')
    ");

    if ($ticket_assigned > 0) {
        $my_work_cards[] = [
            'icon'  => '🎫',
            'label' => 'Tickets',
            'total' => $ticket_assigned,
            'done'  => $ticket_done,
            'href'  => 'tickets.php',
            'color' => 'sky',
        ];
    }
}


/*
| Severity/status tone mapping. These are STATUS colors -- reserved, and
| never reused as a category color elsewhere on the page.
*/
function dashSeverityTone(string $label): string
{
    $l = strtolower(trim($label));

    if (in_array($l, ['critical', 'p1', 'sev1', 'blocker'], true))      { return 'critical'; }
    if (in_array($l, ['high', 'major', 'p2', 'sev2'], true))            { return 'serious'; }
    if (in_array($l, ['medium', 'moderate', 'p3', 'sev3'], true))       { return 'warning'; }
    if (in_array($l, ['low', 'minor', 'p4', 'sev4', 'trivial'], true))  { return 'good'; }
    if (in_array($l, ['published', 'approved', 'active', 'closed', 'resolved'], true)) { return 'good'; }
    if (in_array($l, ['draft', 'pending', 'in review', 'review', 'submitted'], true))  { return 'warning'; }

    return 'neutral';
}


/**
 * Ranked bar list -- the form used for every "X by Y" breakdown here.
 *
 * A bar list rather than a pie/donut on purpose. These panels answer
 * "how many, and which is biggest", which length answers directly and an
 * angle does not; it stays readable from one row to twenty, needs no
 * legend because every row is labelled, and always shows the exact count
 * alongside the bar.
 *
 * Bars are a single hue. Colour would be encoding nothing here -- the
 * category is already named on the row and the magnitude is the length --
 * so giving each row its own colour would be decoration competing with
 * the status colours used elsewhere on the page. $useTone opts a panel
 * into the reserved status palette, for severity and workflow state where
 * the colour genuinely carries meaning.
 *
 * Bar width is scaled against the largest row, not the total, so a set of
 * small values is still comparable instead of collapsing into slivers.
 * The percentage shown is still of the total.
 */
function dashBarList(array $rows, int $total, bool $useTone = false): void
{
    if (!$rows) {
        echo '<div class="dash-empty">No data recorded yet.</div>';
        return;
    }

    $max = 0;
    foreach ($rows as $r) {
        $max = max($max, (int) $r['count']);
    }
    if ($max <= 0) {
        $max = 1;
    }

    echo '<ul class="dash-bars">';

    foreach ($rows as $r) {

        $count = (int) $r['count'];
        $width = max(2, (int) round(($count / $max) * 100));
        $pct = $total > 0 ? round(($count / $total) * 100) : 0;
        $tone = $useTone ? dashSeverityTone((string) $r['label']) : 'accent';

        echo '<li class="dash-bar-row">';

        echo '<span class="dash-bar-label" title="' . h($r['label']) . '">'
           . h($r['label']) . '</span>';

        echo '<span class="dash-bar-track">'
           . '<span class="dash-bar-fill tone-' . h($tone) . '" style="width:' . $width . '%"></span>'
           . '</span>';

        echo '<span class="dash-bar-value">' . number_format($count)
           . '<small>' . $pct . '%</small></span>';

        echo '</li>';
    }

    echo '</ul>';
}

?>


<main class="content">


<div class="dashboard-header">


    <div>

        <h1>
            Welcome back, <?= h($_SESSION['name'] ?? 'Admin'); ?> 👋
        </h1>


        <p>
            Here is your IT infrastructure overview
        </p>

    </div>



    <div class="dashboard-actions">

        <a href="asset.php" class="dash-action-link">
            <button type="button">
                View Assets
            </button>
        </a>


        <a href="inventory.php" class="dash-action-link">
            <button type="button">
                View Inventory
            </button>
        </a>

    </div>


</div>


<!-- FOR YOU SPOTLIGHT -->

<input type="hidden" id="spotlightCsrfToken" value="<?= h(csrfToken()) ?>">

<div class="spotlight-section">

    <div class="spotlight-head">
     
        <?php if ($spotlight_total > 0): ?>
            <span class="spotlight-count">
                <?= $spotlight_total ?> item<?= $spotlight_total === 1 ? '' : 's' ?> need<?= $spotlight_total === 1 ? 's' : '' ?> your attention
            </span>
        <?php endif; ?>

        <?php if ($spotlight_has_prefs): ?>
            <button type="button" class="spotlight-reset" id="spotlightReset" title="Restore default order and un-dismiss everything">
                ↺ Reset arrangement
            </button>
        <?php endif; ?>

        <a class="spotlight-viewall" href="notification.php">View all &rarr;</a>
    </div>

    <?php if (!$spotlight_items): ?>

        <div class="spotlight-empty">
            <span class="spotlight-empty-icon">✅</span>
            <div>
                <strong>You're all caught up</strong>
                <p>No assignments, handovers, reminders, or notes need your attention right now.</p>
            </div>
        </div>

    <?php else: ?>

        <p class="spotlight-hint">Drag <span class="spotlight-hint-icon">⠿</span> to rearrange, or <span class="spotlight-hint-icon">×</span> to dismiss a card -- just for you, it won't affect anyone else.</p>

        <div class="spotlight-grid" id="spotlightGrid">
            <?php foreach ($spotlight_items as $item): ?>
                <div class="spotlight-card tone-<?= h($item['tone']) ?>" draggable="true" data-key="<?= h($item['key']) ?>">

                    <div class="spotlight-controls">
                        <span class="spotlight-drag" title="Drag to reorder">⠿</span>
                        <button type="button" class="spotlight-dismiss" data-key="<?= h($item['key']) ?>" title="Dismiss this card">×</button>
                    </div>

                    <?php if (in_array($item['tone'], ['critical', 'assigned'], true)): ?>
                        <span class="spotlight-pulse"></span>
                    <?php endif; ?>

                    <a class="spotlight-link" href="<?= h($item['href']) ?>" draggable="false">
                        <span class="spotlight-icon"><?= $item['icon'] ?></span>
                        <span class="spotlight-badge"><?= h($item['badge']) ?></span>
                        <strong class="spotlight-title"><?= h($item['title']) ?></strong>
                        <span class="spotlight-meta"><?= h($item['meta']) ?></span>
                    </a>

                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($spotlight_total > count($spotlight_items)): ?>
            <a class="spotlight-more" href="notification.php">
                +<?= $spotlight_total - count($spotlight_items) ?> more waiting &rarr;
            </a>
        <?php endif; ?>

    <?php endif; ?>

</div>


<!-- KPI CARDS -->

<div class="stats-grid stats-grid-3">


<div class="dashboard-card">

<div class="card-icon blue">
🖥
</div>

<div>

<span>
Total Assets
</span>

<h2>
<?= number_format($asset_total) ?>
</h2>

<p>
<?= number_format($asset_in_service) ?> In Service
</p>

</div>

</div>



<div class="dashboard-card">

<div class="card-icon green">
🗄
</div>

<div>

<span>
Servers (Inventory)
</span>

<h2>
<?= number_format($inventory_total) ?>
</h2>

<p>
Active &middot; <?= h($inv_filter_label) ?>
</p>

</div>

</div>



<div class="dashboard-card">

<div class="card-icon orange">
🌐
</div>

<div>

<span>
IP Ranges
</span>

<h2>
<?= number_format($ip_total) ?>
</h2>

<p>
<?= number_format($ip_usable_sum) ?> Usable IPs
</p>

</div>

</div>





</div>


<!-- KNOWLEDGE / SOP / ISSUES KPI ROW -->

<div class="stats-grid">

    <div class="dashboard-card">
        <div class="card-icon blue">📘</div>
        <div>
            <span>Knowledge Base</span>
            <h2><?= number_format($kb_total) ?></h2>
            <p><?= count($kb_by_category) ?> categor<?= count($kb_by_category) === 1 ? 'y' : 'ies' ?></p>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-icon green">📋</div>
        <div>
            <span>SOPs</span>
            <h2><?= number_format($sop_total) ?></h2>
            <p><?= number_format($sop_published) ?> published<?= $sop_review_due > 0 ? ' · ' . number_format($sop_review_due) . ' review due' : '' ?></p>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-icon orange">⚠</div>
        <div>
            <span>Known Issues</span>
            <h2><?= number_format($ki_open) ?></h2>
            <p><?= number_format($ki_total) ?> total recorded</p>
        </div>
    </div>

    <?php if ($canManageUsers): ?>
        <div class="dashboard-card<?= $pending_user_count > 0 ? ' dash-card-attention' : '' ?>">
            <div class="card-icon red">👤</div>
            <div>
                <span>Pending Approvals</span>
                <h2><?= number_format($pending_user_count) ?></h2>
                <p><?= $pending_user_count > 0 ? 'Awaiting your review' : 'Nothing to action' ?></p>
            </div>
        </div>
    <?php else: ?>
        <div class="dashboard-card">
            <div class="card-icon red">🗂</div>
            <div>
                <span>Servers by OS</span>
                <h2><?= number_format(count($inv_by_os_version)) ?></h2>
                <p>distinct OS builds</p>
            </div>
        </div>
    <?php endif; ?>

</div>


<?php
/*
|--------------------------------------------------------------------------
| Team Away & On-Call -- who's out today (Leave Tracker) and who's
| holding the pager right now (On-Call Tracker), across the whole team --
| not just this user's own assignments (that's "My Assigned Work" above).
| Each half is gated on that module's own can_view permission, and
| filtered by the same public/team/teams/private visibility rules the
| modules' own pages use, so a private leave entry or shift never leaks
| onto a dashboard its subject didn't choose to share it on.
|--------------------------------------------------------------------------
*/

$dash_user_team = '';
try {
    $dt_stmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
    $dt_stmt->execute([$dash_user_id]);
    $dash_user_team = (string) ($dt_stmt->fetchColumn() ?: '');
} catch (Throwable $e) {
    $dash_user_team = '';
}

$team_away_today = [];

if (can('leave', 'can_view')) {
    try {
        $lv_today = date('Y-m-d');

        $lv_vis_sql = $dash_is_admin ? '1=1' : "(
            e.visibility = 'public'
            OR e.created_by_id = ?
            OR e.user_id = ?
            OR (e.visibility = 'team'  AND e.owner_team <> '' AND e.owner_team = ?)
            OR (e.visibility = 'teams' AND EXISTS (
                    SELECT 1 FROM leave_teams t
                    WHERE t.leave_id = e.id AND t.team_name = ?
            ))
        )";
        $lv_vis_params = $dash_is_admin ? [] : [$dash_user_id, $dash_user_id, $dash_user_team, $dash_user_team];

        $stmt = $pdo->prepare("
            SELECT e.person_name, e.leave_type, e.end_date
            FROM leave_entries e
            WHERE e.start_date <= ? AND e.end_date >= ?
              AND e.status NOT IN ('Cancelled', 'Rejected')
              AND $lv_vis_sql
            ORDER BY e.end_date ASC
            LIMIT 8
        ");
        $stmt->execute([$lv_today, $lv_today, ...$lv_vis_params]);
        $team_away_today = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $team_away_today = [];
    }
}

$team_oncall_now = [];

if (can('oncall', 'can_view')) {
    try {
        $oc_now = date('Y-m-d H:i:s');

        // Own primary/secondary assignment is included even when a shift
        // is private -- same reasoning as includes/notifications.php's
        // oncall_current query: a user must always see their own
        // assignment regardless of who else the shift is shared with.
        $oc_vis_sql = $dash_is_admin ? '1=1' : "(
            s.visibility = 'public'
            OR s.created_by_id = ?
            OR (s.visibility = 'team'  AND s.owner_team <> '' AND s.owner_team = ?)
            OR (s.visibility = 'teams' AND EXISTS (
                    SELECT 1 FROM oncall_teams t
                    WHERE t.oncall_id = s.id AND t.team_name = ?
            ))
            OR s.primary_user_id = ?
            OR s.secondary_user_id = ?
        )";
        $oc_vis_params = $dash_is_admin ? [] : [$dash_user_id, $dash_user_team, $dash_user_team, $dash_user_id, $dash_user_id];

        $stmt = $pdo->prepare("
            SELECT s.shift_label, s.rota_team, s.primary_name, s.secondary_name, s.ends_at
            FROM oncall_shifts s
            WHERE s.starts_at <= ? AND s.ends_at >= ?
              AND $oc_vis_sql
            ORDER BY s.ends_at ASC
            LIMIT 8
        ");
        $stmt->execute([$oc_now, $oc_now, ...$oc_vis_params]);
        $team_oncall_now = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        $team_oncall_now = [];
    }
}

$show_team_status_panel = can('leave', 'can_view') || can('oncall', 'can_view');
?>


<?php
/*
|--------------------------------------------------------------------------
| Per-user dashboard panel layout -- drag-and-drop order for every tile
| below (Asset Growth through Recent Activity), stored the same way as
| the "For You" spotlight cards above: a per-panel sort_order in
| dashboard_panel_prefs. Untouched panels fall back to their original
| document order, so a first-time user or a role that hides some panels
| (Admin Tasks, etc.) sees the same layout as before any drag ever
| happens. Widths are fixed per panel (not user-customizable) -- only
| the order changes -- expressed as a 12-column span so every panel,
| regardless of which "row" it used to belong to, can sit next to any
| other.
*/

$dashboard_panel_default_order = [
    'asset-growth', 'inv-growth', 'os-version',
    'my-assigned-work', 'team-away-oncall',
    'admin-tasks', 'pending-approvals',
    'os-family', 'managed-by', 'support-level', 'asset-types',
    'kb-by-category', 'sop-by-status', 'known-issues-severity',
    'kb-recent', 'known-issues-status',
    'notifications', 'recent-activity',
];

$dashboard_panel_spans = [
    'asset-growth' => 4, 'inv-growth' => 4, 'os-version' => 4,
    'my-assigned-work' => 12, 'team-away-oncall' => 6,
    'admin-tasks' => 8, 'pending-approvals' => 4,
    'os-family' => 3, 'managed-by' => 3, 'support-level' => 3, 'asset-types' => 3,
    'kb-by-category' => 4, 'sop-by-status' => 4, 'known-issues-severity' => 4,
    'kb-recent' => 8, 'known-issues-status' => 4,
    'notifications' => 8, 'recent-activity' => 4,
];

$dashboard_panel_prefs = [];
try {
    $stmt = $pdo->prepare("
        SELECT panel_key, sort_order
        FROM dashboard_panel_prefs
        WHERE user_id = ?
    ");
    $stmt->execute([(int) ($_SESSION['user_id'] ?? 0)]);
    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $p) {
        $dashboard_panel_prefs[$p['panel_key']] = (int) $p['sort_order'];
    }
} catch (Throwable $e) {
    $dashboard_panel_prefs = [];
}

$dashboard_panel_has_prefs = (bool) $dashboard_panel_prefs;

$dashboard_panel_pinned = [];
$dashboard_panel_unpinned = [];

foreach ($dashboard_panel_default_order as $dp_key) {
    if (isset($dashboard_panel_prefs[$dp_key])) {
        $dashboard_panel_pinned[$dp_key] = $dashboard_panel_prefs[$dp_key];
    } else {
        $dashboard_panel_unpinned[] = $dp_key;
    }
}

asort($dashboard_panel_pinned);

$dashboard_panel_order_index = array_flip(
    array_merge(array_keys($dashboard_panel_pinned), $dashboard_panel_unpinned)
);

function dashPanelAttrs(string $key): string
{
    global $dashboard_panel_spans, $dashboard_panel_order_index;
    $span = $dashboard_panel_spans[$key] ?? 4;
    $order = $dashboard_panel_order_index[$key] ?? 999;
    return 'draggable="true" data-panel-key="' . h($key) . '" class="dashboard-panel dash-span-' . $span . '" style="order:' . $order . '"';
}
?>


<!-- INVENTORY BREAKDOWN FILTER -- hoisted above the reorderable panel grid
     so it stays a fixed, non-draggable toolbar regardless of where the
     user drags the panels it filters (Servers by OS Family/Version/
     Managed By/Support Level). -->

<div class="inv-filter-bar">

    <span class="inv-filter-scope-label">Inventory scope: Active servers only</span>

    <div class="inv-filter-bar-actions">

    <form method="get" action="home.php" class="inv-filter-form" id="invFilterForm">

        <input type="hidden" name="inv_filter_applied" value="1">

        <button type="button" class="inv-filter-toggle" id="invFilterToggle" aria-expanded="false">
            Managed By: <strong><?= h($inv_filter_label) ?></strong> <span class="inv-filter-caret">&#9662;</span>
        </button>

        <div class="inv-filter-panel" id="invFilterPanel" hidden>

            <?php if (!$inv_managed_by_options): ?>

                <div class="inv-filter-empty">No inventory recorded yet.</div>

            <?php else: ?>

                <div class="inv-filter-options">
                    <?php foreach ($inv_managed_by_options as $opt): ?>
                        <label class="inv-filter-option">
                            <input type="checkbox" name="inv_managed_by[]" value="<?= h($opt) ?>"
                                <?= in_array($opt, $inv_managed_by_selected, true) ? 'checked' : '' ?>>
                            <?= h($opt) ?>
                        </label>
                    <?php endforeach; ?>
                </div>

                <div class="inv-filter-actions">
                    <button type="submit" class="inv-filter-apply">Apply</button>
                    <a href="home.php" class="inv-filter-reset">Reset to All</a>
                </div>

            <?php endif; ?>

        </div>

    </form>

    <?php if ($dashboard_panel_has_prefs): ?>
        <button type="button" class="inv-filter-toggle" id="dashboardLayoutReset" title="Restore the default panel order">
            &#8635; Reset panel layout
        </button>
    <?php endif; ?>

    </div>

</div>


<!-- CHART ROW -->

<div class="dashboard-panels-grid" id="dashboardPanelsGrid">


<div id="assetGrowthPanel" <?= dashPanelAttrs('asset-growth') ?>>

<span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>



<div class="panel-header">

<h3>
Asset Growth
</h3>

<select id="assetGrowthRangeSelect" class="chart-range-select" aria-label="Asset growth time range">
<?php foreach ($asset_growth_ranges as $range_key => $range_meta): ?>
<option value="<?= h($range_key) ?>" <?= $range_key === $asset_growth_range ? 'selected' : '' ?>><?= h($range_meta['option']) ?></option>
<?php endforeach; ?>
</select>

</div>


<div class="chart-container">

<canvas id="assetChart"></canvas>

</div>


</div>



<div id="invGrowthPanel" <?= dashPanelAttrs('inv-growth') ?>>

<span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

<div class="panel-header">

<h3>
Server Inventory Growth
</h3>

<select id="invGrowthRangeSelect" class="chart-range-select" aria-label="Server inventory growth time range">
<?php foreach ($asset_growth_ranges as $range_key => $range_meta): ?>
<option value="<?= h($range_key) ?>" <?= $range_key === $inv_growth_range ? 'selected' : '' ?>><?= h($range_meta['option']) ?></option>
<?php endforeach; ?>
</select>

</div>


<div class="chart-container">

<canvas id="inventoryGrowthChart"></canvas>

</div>


</div>



<div <?= dashPanelAttrs('os-version') ?>>

<span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

<div class="panel-header">

<h3>
Servers by OS Version
</h3>

<span><?= number_format($inventory_total) ?> total</span>

</div>


<div class="chart-container">

<?php if ($inv_by_os_version): ?>
    <canvas id="osVersionChart"></canvas>
<?php else: ?>
    <div class="dash-empty">No inventory recorded yet.</div>
<?php endif; ?>

</div>


</div>


<?php if ($my_work_cards): ?>
<!-- MY ASSIGNED WORK -->

<div <?= dashPanelAttrs('my-assigned-work') ?>>

    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

    <div class="panel-header">
        <h3>My Assigned Work</h3>
        <span>Across Decommission, Patching, SOP &amp; GRC</span>
    </div>

    <div class="dash-mywork-chips">
        <?php foreach ($my_work_cards as $mw): ?>
            <a class="dash-mywork-chip tone-<?= h($mw['color']) ?>" href="<?= h($mw['href']) ?>">
                <span class="dash-mywork-chip-icon"><?= $mw['icon'] ?></span>
                <span class="dash-mywork-chip-label"><?= h($mw['label']) ?></span>
                <span class="dash-mywork-chip-count">
                    <?= number_format($mw['total']) ?>
                    <?php if ($mw['done'] > 0): ?>
                        <small>/ <?= number_format($mw['done']) ?> done</small>
                    <?php endif; ?>
                </span>
            </a>
        <?php endforeach; ?>
    </div>

</div>
<?php endif; ?>


<?php if ($show_team_status_panel): ?>
<!-- TEAM AWAY & ON-CALL -->

<div <?= dashPanelAttrs('team-away-oncall') ?>>

    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

    <div class="panel-header">
        <h3>Away &amp; On-Call</h3>
        <span>Live from Leave &amp; On-Call Trackers</span>
    </div>

    <?php if (can('leave', 'can_view')): ?>
        <div class="dash-subhead">🌴 Away today <?= $team_away_today ? '<span class="dash-subhead-n">' . count($team_away_today) . '</span>' : '' ?></div>

        <?php if (!$team_away_today): ?>
            <div class="dash-empty">Nobody's away today.</div>
        <?php else: ?>
            <ul class="dash-task-list">
                <?php foreach ($team_away_today as $lv): ?>
                    <?php $lv_returns = $lv['end_date'] !== '' ? date('d M', strtotime($lv['end_date'] . ' +1 day')) : ''; ?>
                    <li class="dash-task">
                        <span class="dash-task-dot tone-warning"></span>
                        <span class="dash-task-label">
                            <strong><?= h($lv['person_name']) ?></strong><?= $lv['leave_type'] ? ' · ' . h($lv['leave_type']) : '' ?>
                            <?= $lv_returns !== '' ? ' — back ' . h($lv_returns) : '' ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>

    <?php if (can('oncall', 'can_view')): ?>
        <div class="dash-subhead">📟 On-call now <?= $team_oncall_now ? '<span class="dash-subhead-n">' . count($team_oncall_now) . '</span>' : '' ?></div>

        <?php if (!$team_oncall_now): ?>
            <div class="dash-empty">No active on-call shift right now.</div>
        <?php else: ?>
            <ul class="dash-task-list">
                <?php foreach ($team_oncall_now as $oc): ?>
                    <li class="dash-task">
                        <span class="dash-task-dot tone-critical"></span>
                        <span class="dash-task-label">
                            <strong><?= h($oc['primary_name'] ?: '—') ?></strong>
                            <?= $oc['secondary_name'] ? ' (backup: ' . h($oc['secondary_name']) . ')' : '' ?>
                            <?= $oc['shift_label'] ? ' · ' . h($oc['shift_label']) : ($oc['rota_team'] ? ' · ' . h($oc['rota_team']) : '') ?>
                            — until <?= h(date('d M, H:i', strtotime($oc['ends_at']))) ?>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    <?php endif; ?>

    <a class="dash-panel-cta" href="<?= can('leave', 'can_view') ? 'leave.php' : 'oncall.php' ?>">
        Open <?= can('leave', 'can_view') && can('oncall', 'can_view') ? 'Leave &amp; On-Call Trackers' : (can('leave', 'can_view') ? 'Leave Tracker' : 'On-Call Tracker') ?> &rarr;
    </a>

</div>
<?php endif; ?>


<?php if ($canManageUsers): ?>
<!-- ADMIN TASKS -->

<div <?= dashPanelAttrs('admin-tasks') ?>>

    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

    <div class="panel-header">
        <h3>Admin Tasks</h3>
        <span><a href="users.php">Manage users</a></span>
    </div>

    <?php if (!$admin_tasks): ?>

        <div class="dash-empty">Nothing needs your attention right now.</div>

    <?php else: ?>

        <ul class="dash-task-list">
            <?php foreach ($admin_tasks as $task): ?>
                <li class="dash-task">
                    <span class="dash-task-dot tone-<?= h($task['tone']) ?>"></span>
                    <span class="dash-task-label"><?= h($task['label']) ?></span>
                    <a class="dash-task-cta" href="<?= h($task['href']) ?>"><?= h($task['cta']) ?> &rarr;</a>
                </li>
            <?php endforeach; ?>
        </ul>

    <?php endif; ?>

</div>


<div <?= dashPanelAttrs('pending-approvals') ?>>

    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

    <div class="panel-header">
        <h3>Pending User Approvals</h3>
        <?php if ($pending_user_count > count($pending_users)): ?>
            <span><?= number_format($pending_user_count) ?> total</span>
        <?php endif; ?>
    </div>

    <?php if (!$pending_users): ?>

        <div class="dash-empty">No accounts are waiting for approval.</div>

    <?php else: ?>

        <ul class="dash-approval-list">
            <?php foreach ($pending_users as $pu): ?>
                <?php $puName = trim(($pu['first_name'] ?? '') . ' ' . ($pu['last_name'] ?? '')); ?>
                <li class="dash-approval">
                    <div class="dash-approval-main">
                        <strong><?= h($puName !== '' ? $puName : ($pu['ncgr_id'] ?? 'Unknown')) ?></strong>
                        <span class="dash-approval-meta">
                            <?= h($pu['ncgr_id'] ?? '') ?>
                            <?= !empty($pu['email']) ? ' · ' . h($pu['email']) : '' ?>
                        </span>
                    </div>
                    <span class="dash-source-tag tone-<?= strtolower($pu['auth_source']) === 'ldap' ? 'info' : 'neutral' ?>">
                        <?= strtolower($pu['auth_source']) === 'ldap' ? 'Directory' : 'Local' ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>

        <a class="dash-panel-cta" href="users.php">Review all approvals &rarr;</a>

    <?php endif; ?>

</div>
<?php endif; ?>


<!-- INVENTORY BREAKDOWN -->

<div <?= dashPanelAttrs('os-family') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Servers by OS Family</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <?php dashBarList($inv_by_os_family, $inventory_total); ?>
</div>

<div <?= dashPanelAttrs('managed-by') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Servers by Managed By</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <?php dashBarList($inv_by_managed_by, $inventory_total); ?>
</div>

<div <?= dashPanelAttrs('support-level') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Servers by Support Level</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <?php dashBarList($inv_by_support_level, $inventory_total); ?>
</div>

<div <?= dashPanelAttrs('asset-types') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Asset Types</h3>
        <span><?= number_format($asset_total) ?> total</span>
    </div>
    <div class="chart-container">
        <?php if ($asset_type_counts): ?>
            <canvas id="typeChart"></canvas>
        <?php else: ?>
            <div class="dash-empty">No assets recorded yet.</div>
        <?php endif; ?>
    </div>
</div>


<!-- KB / SOP / KNOWN ISSUES BREAKDOWN -->

<div <?= dashPanelAttrs('kb-by-category') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Knowledge Base by Category</h3>
        <span><a href="knowledge.php">View all</a></span>
    </div>
    <?php dashBarList($kb_by_category, $kb_total); ?>
</div>

<div <?= dashPanelAttrs('sop-by-status') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>SOPs by Status</h3>
        <span><a href="sop.php">View all</a></span>
    </div>
    <?php dashBarList($sop_by_status, $sop_total, true); ?>
</div>

<div <?= dashPanelAttrs('known-issues-severity') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Known Issues by Severity</h3>
        <span><a href="known-issues.php">View all</a></span>
    </div>
    <?php dashBarList($ki_by_severity, $ki_total, true); ?>
</div>


<!-- RECENTLY UPDATED KB -->

<?php if ($kb_recent): ?>
<div <?= dashPanelAttrs('kb-recent') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Recently Updated Knowledge Base Articles</h3>
        <span><a href="knowledge.php">View all</a></span>
    </div>

    <ul class="dash-kb-list">
        <?php foreach ($kb_recent as $kb): ?>
            <li class="dash-kb-item">
                <span class="dash-kb-num"><?= h($kb['kb_number'] ?: '—') ?></span>
                <span class="dash-kb-title"><?= h($kb['title']) ?></span>
                <span class="dash-kb-meta">
                    <?= h($kb['category'] ?: 'Uncategorized') ?>
                    <?= !empty($kb['ts']) ? ' · ' . notif_time_ago($kb['ts']) : '' ?>
                </span>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<div <?= dashPanelAttrs('known-issues-status') ?>>
    <span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>
    <div class="panel-header">
        <h3>Known Issues by Status</h3>
    </div>
    <?php dashBarList($ki_by_status, $ki_total, true); ?>
</div>
<?php endif; ?>


<!-- LOWER ROW -->

<div id="notificationsPanel" <?= dashPanelAttrs('notifications') ?>>

<span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

<div class="panel-header">

<h3>
Notifications &amp; Team Updates
</h3>

<span>
<a href="notification.php">View all</a>
</span>

</div>


<?php if (!$comm_count && !$reminder_count && !$sticky_count && !$shared_data_count && !$kb_sop_activity_count): ?>

    <div class="dash-empty">
        No open notifications, reminders, sticky notes, or shared data.
    </div>

<?php else: ?>

    <ul class="dash-notif-list">

        <?php foreach ($header_notifications['communications'] as $c): ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot priority-<?= h(strtolower($c['priority'] ?? 'normal')) ?>"></span>

                <div>
                    <strong><?= h($c['title']) ?></strong>
                    <span class="dash-notif-meta">
                        Team Note &middot; <?= h($c['note_type'] ?? 'Announcement') ?>
                        &middot; <?= notif_time_ago($c['created_at']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['reminders'] as $r): ?>

            <?php $is_overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s'); ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot <?= $is_overdue ? 'priority-critical' : 'priority-normal' ?>"></span>

                <div>
                    <strong><?= h($r['title']) ?></strong>
                    <span class="dash-notif-meta">
                        Reminder &middot;
                        <?= $is_overdue ? 'Overdue' : 'Due' ?>
                        <?= h(date('d M, H:i', strtotime($r['reminder_date']))) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['sticky_notes'] as $n): ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot priority-note"></span>

                <div>
                    <strong><?= h(infravault_truncate($n['content'], 60)) ?></strong>
                    <span class="dash-notif-meta">
                        Sticky Note &middot;
                        <?= h(trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team') ?>
                        &middot; <?= notif_time_ago($n['updated_at']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['shared_data'] as $d): ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot priority-normal"></span>

                <div>
                    <strong><?= h($d['title']) ?></strong>
                    <span class="dash-notif-meta">
                        <?= $d['visibility'] === 'Team' ? 'Shared with your team' : 'Shared with you' ?>
                        &middot; <?= h(trim(($d['owner_first'] ?? '') . ' ' . ($d['owner_last'] ?? '')) ?: 'Someone') ?>
                        &middot; <?= notif_time_ago($d['updated_at']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['kb_sop_activity'] as $a): ?>

            <?php
                $kb_sop_action_labels = [
                    'EDITED'        => 'updated',
                    'COMMENT_ADDED' => 'commented on',
                    'PUBLISHED'     => 'approved and published',
                    'REJECTED'      => 'rejected',
                ];
                $a_module_label = $a['module'] === 'sop' ? 'SOP' : 'knowledge base article';
                $a_verb = $kb_sop_action_labels[$a['action']] ?? strtolower($a['action']);
            ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot <?= $a['action'] === 'REJECTED' ? 'priority-critical' : 'priority-normal' ?>"></span>

                <div>
                    <strong><?= h($a['title']) ?></strong>
                    <span class="dash-notif-meta">
                        <?= h($a['actor_name']) ?> <?= h($a_verb) ?> this <?= $a_module_label ?>
                        &middot; <?= notif_time_ago($a['date']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>

    </ul>

<?php endif; ?>


</div>



<div id="recentActivityPanel" <?= dashPanelAttrs('recent-activity') ?>>

<span class="dash-panel-drag-handle" title="Drag to reorder">⠿</span>

<h3>
Recent Activity
</h3>


<?php if (!$recent_activity): ?>

    <div class="dash-empty">
        No recent activity recorded yet.
    </div>

<?php else: ?>

    <ul class="activity">

        <?php foreach ($recent_activity as $a): ?>

            <li>

                <span class="activity-icon">
                    <?= $activity_icons[$a['action']] ?? '•' ?>
                </span>

                <span>
                    <strong><?= h($a['module']) ?>:</strong>
                    <?= h($a['text']) ?: h($a['action']) ?>
                    <span class="activity-meta">
                        &mdash; <?= h($a['performed_by']) ?>, <?= notif_time_ago($a['timestamp']) ?>
                    </span>
                </span>

            </li>

        <?php endforeach; ?>

    </ul>

<?php endif; ?>


</div>



</div>


</main>



<?php

include "includes/footer.php";

?>



<script src="assets/js/chart.min.js"></script>


<script>


const assetChart =
document.getElementById('assetChart');


if(assetChart){


new Chart(
assetChart,
{

type:'line',

data:{


labels: <?= json_encode($asset_growth_labels) ?>,


datasets:[{

label:"Assets Created",

data: <?= json_encode($asset_growth_data) ?>,


borderColor:"#4F46E5",

backgroundColor:
"rgba(79,70,229,.1)",


fill:true,

tension:.4,

stepped:false


}]


},

options:{


responsive:true,

maintainAspectRatio:false,

scales:{
    y:{
        beginAtZero:true,
        ticks:{ precision:0 }
    }
}


}

});

}



const inventoryGrowthChart =
document.getElementById('inventoryGrowthChart');


if(inventoryGrowthChart){


new Chart(
inventoryGrowthChart,
{

type:'line',

data:{


labels: <?= json_encode($inv_growth_labels) ?>,


datasets:[{

label:"Servers Added",

data: <?= json_encode($inv_growth_data) ?>,


borderColor:"#10B981",

backgroundColor:
"rgba(16,185,129,.1)",


fill:true,

tension:.4,

stepped:false


}]


},

options:{


responsive:true,

maintainAspectRatio:false,

scales:{
    y:{
        beginAtZero:true,
        ticks:{ precision:0 }
    }
}


}

});

}



const osVersionChart =
document.getElementById('osVersionChart');


if(osVersionChart){


new Chart(
osVersionChart,
{

type:'doughnut',

data:{

labels: <?= json_encode(array_column($inv_by_os_version, 'label')) ?>,

datasets:[{

data: <?= json_encode(array_column($inv_by_os_version, 'count')) ?>,

backgroundColor:[
"#2a78d6",
"#eb6834",
"#1baf7a",
"#eda100",
"#e87ba4",
"#008300",
"#4a3aa7",
"#e34948"
],

borderWidth:2,
borderColor: getComputedStyle(document.body).getPropertyValue('--bg-content') || '#ffffff'

}]

},

options:{

responsive:true,
maintainAspectRatio:false,
cutout:'62%',

plugins:{
    legend:{
        position:'bottom',
        labels:{
            boxWidth:10,
            padding:10,
            font:{ size:11 },
            color: getComputedStyle(document.body).getPropertyValue('--text-secondary').trim() || '#64748B'
        }
    }
}

}

});

}


const typeChart =
document.getElementById('typeChart');


if(typeChart){


new Chart(

typeChart,

{

type:'doughnut',

data:{


labels: <?= json_encode(array_keys($asset_type_counts)) ?>,


datasets:[{

data: <?= json_encode(array_values($asset_type_counts)) ?>,


backgroundColor:[

"#4F46E5",
"#10B981",
"#F59E0B",
"#EF4444",
"#0EA5E9",
"#94A3B8"

]


}]


},

options:{


responsive:true,

maintainAspectRatio:false


}


}

);


}


</script>


<script>

/*
|--------------------------------------------------------------------------
| Spotlight customization -- drag to reorder, click to dismiss, both
| persisted per-user via home.php's own spotlight_action AJAX handler.
| Never touches the underlying reminder/note/sticky-note rows -- only
| this user's row in dashboard_spotlight_prefs.
|--------------------------------------------------------------------------
*/

(function () {

    const grid = document.getElementById('spotlightGrid');
    if (!grid) {
        return;
    }

    const csrfTokenEl = document.getElementById('spotlightCsrfToken');
    const csrfToken = csrfTokenEl ? csrfTokenEl.value : '';

    function postSpotlight(fields) {
        const body = new URLSearchParams({ csrf_token: csrfToken, ...fields });
        return fetch(window.location.pathname, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(r => r.json()).catch(() => ({ success: false }));
    }

    function currentOrder() {
        return Array.from(grid.querySelectorAll('.spotlight-card')).map(el => el.dataset.key);
    }

    function saveOrder() {
        postSpotlight({
            spotlight_action: 'reorder',
            order: JSON.stringify(currentOrder())
        });
    }

    let draggedEl = null;

    grid.querySelectorAll('.spotlight-card').forEach(card => {

        card.addEventListener('dragstart', () => {
            draggedEl = card;
            card.classList.add('spotlight-dragging');
        });

        card.addEventListener('dragend', () => {
            card.classList.remove('spotlight-dragging');
            draggedEl = null;
            saveOrder();
        });

        card.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (!draggedEl || draggedEl === card) {
                return;
            }
            const rect = card.getBoundingClientRect();
            const before = (e.clientX - rect.left) < (rect.width / 2);
            grid.insertBefore(draggedEl, before ? card : card.nextSibling);
        });
    });

    grid.addEventListener('click', (e) => {

        const btn = e.target.closest('.spotlight-dismiss');
        if (!btn) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        const card = btn.closest('.spotlight-card');
        const key = btn.dataset.key;

        btn.disabled = true;

        postSpotlight({ spotlight_action: 'dismiss', item_key: key }).then(res => {
            if (res && res.success) {
                // Reload rather than just remove the DOM node -- a dismissed
                // card can make room for one of the "+N more waiting" items
                // to appear, and only the server knows what that is.
                window.location.reload();
            } else {
                btn.disabled = false;
            }
        });
    });

    const resetBtn = document.getElementById('spotlightReset');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            resetBtn.disabled = true;
            postSpotlight({ spotlight_action: 'reset' }).then(() => {
                window.location.reload();
            });
        });
    }

})();

</script>


<script>

/*
|--------------------------------------------------------------------------
| Inventory "Managed By" filter -- just opens/closes the checkbox panel;
| the actual filtering happens server-side on submit (plain GET reload,
| same pattern as inventory.php's own filters).
|--------------------------------------------------------------------------
*/

(function () {

    const toggle = document.getElementById('invFilterToggle');
    const panel = document.getElementById('invFilterPanel');

    if (!toggle || !panel) {
        return;
    }

    toggle.addEventListener('click', (e) => {
        e.stopPropagation();
        const open = panel.hidden;
        panel.hidden = !open;
        toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    panel.addEventListener('click', (e) => e.stopPropagation());

    document.addEventListener('click', () => {
        panel.hidden = true;
        toggle.setAttribute('aria-expanded', 'false');
    });

})();

/*
|--------------------------------------------------------------------------
| Chart range selectors (Asset Growth, Server Inventory Growth) -- plain
| GET reload, same pattern as the "Managed By" filter above, so other
| query params on the page (e.g. each other's range, the inventory
| filter) survive the change.
|--------------------------------------------------------------------------
*/

(function () {

    function wireChartRangeSelect(selectId, paramName, anchorId) {

        const select = document.getElementById(selectId);

        if (!select) {
            return;
        }

        select.addEventListener('change', () => {
            const params = new URLSearchParams(window.location.search);
            params.set(paramName, select.value);
            window.location.href = window.location.pathname + '?' + params.toString() + '#' + anchorId;
        });
    }

    wireChartRangeSelect('assetGrowthRangeSelect', 'asset_growth_range', 'assetGrowthPanel');
    wireChartRangeSelect('invGrowthRangeSelect', 'inv_growth_range', 'invGrowthPanel');

})();

</script>


<script>

/*
|--------------------------------------------------------------------------
| Dashboard panel layout -- drag a tile by its handle (top-right corner)
| to move it anywhere among the other tiles, persisted per-user via
| home.php's own panel_layout_action AJAX handler (same pattern, and the
| same CSRF token, as the spotlight customization above). Only ever
| touches dashboard_panel_prefs for the current user.
|--------------------------------------------------------------------------
*/

(function () {

    const grid = document.getElementById('dashboardPanelsGrid');
    if (!grid) {
        return;
    }

    const csrfTokenEl = document.getElementById('spotlightCsrfToken');
    const csrfToken = csrfTokenEl ? csrfTokenEl.value : '';

    function postPanelLayout(fields) {
        const body = new URLSearchParams({ csrf_token: csrfToken, ...fields });
        return fetch(window.location.pathname, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(r => r.json()).catch(() => ({ success: false }));
    }

    function currentOrder() {
        // Panels are visually placed by their CSS `order` value (set inline,
        // swapped on drop below), not by DOM position -- so the saved
        // sequence has to be derived by sorting on that value, not just by
        // reading the elements in source order.
        return Array.from(grid.querySelectorAll('.dashboard-panel[data-panel-key]'))
            .map(el => ({ key: el.dataset.panelKey, order: parseInt(el.style.order, 10) || 0 }))
            .sort((a, b) => a.order - b.order)
            .map(item => item.key);
    }

    function saveOrder() {
        postPanelLayout({
            panel_layout_action: 'reorder',
            order: JSON.stringify(currentOrder())
        });
    }

    let draggedEl = null;
    let dragArmed = false;

    // dragstart fires with e.target set to the draggable element itself
    // (the panel), never the handle the user actually pressed down on --
    // so "did this drag start from the handle" has to be tracked via a
    // separate mousedown flag, not read off the drag event.
    document.addEventListener('mouseup', () => { dragArmed = false; });

    grid.querySelectorAll('.dashboard-panel[data-panel-key]').forEach(panel => {

        const handle = panel.querySelector('.dash-panel-drag-handle');
        if (handle) {
            handle.addEventListener('mousedown', () => { dragArmed = true; });
        }

        panel.addEventListener('dragstart', (e) => {
            if (!dragArmed) {
                e.preventDefault();
                return;
            }
            dragArmed = false;
            draggedEl = panel;
            panel.classList.add('dash-panel-dragging');
        });

        panel.addEventListener('dragend', () => {
            panel.classList.remove('dash-panel-dragging');
            grid.querySelectorAll('.dash-panel-dragover').forEach(el => el.classList.remove('dash-panel-dragover'));
            draggedEl = null;
            saveOrder();
        });

        panel.addEventListener('dragover', (e) => {
            if (!draggedEl || draggedEl === panel) {
                return;
            }
            e.preventDefault();
            grid.querySelectorAll('.dash-panel-dragover').forEach(el => el.classList.remove('dash-panel-dragover'));
            panel.classList.add('dash-panel-dragover');
        });

        panel.addEventListener('drop', (e) => {
            e.preventDefault();
            panel.classList.remove('dash-panel-dragover');
            if (!draggedEl || draggedEl === panel) {
                return;
            }
            // Swap the two panels' CSS order values -- simplest way to move
            // a tile of one width into a slot previously held by a tile of
            // a different width without reflowing everything else.
            const a = draggedEl.style.order;
            const b = panel.style.order;
            draggedEl.style.order = b;
            panel.style.order = a;
        });
    });

    const resetBtn = document.getElementById('dashboardLayoutReset');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            resetBtn.disabled = true;
            postPanelLayout({ panel_layout_action: 'reset' }).then(() => {
                window.location.reload();
            });
        });
    }

})();

</script>


<style>

/* --- inventory "Managed By" filter bar --- */

.inv-filter-bar {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-bottom: 12px;
}

.inv-filter-scope-label {
    font-size: 12.5px;
    color: var(--text-muted, #94A3B8);
}

.inv-filter-form {
    position: relative;
}

.inv-filter-bar-actions {
    display: flex;
    flex-wrap: wrap;
    align-items: center;
    gap: 10px;
}

.inv-filter-toggle {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 14px;
    font-size: 13px;
    color: var(--text-primary);
    background: var(--bg-content, #fff);
    border: 1px solid var(--border-color, #E2E8F0);
    border-radius: 8px;
    cursor: pointer;
}

.inv-filter-toggle:hover {
    border-color: var(--accent, #4338CA);
}

.inv-filter-caret {
    font-size: 10px;
    color: var(--text-muted, #94A3B8);
}

.inv-filter-panel {
    position: absolute;
    right: 0;
    top: calc(100% + 6px);
    z-index: 20;
    min-width: 220px;
    max-height: 280px;
    overflow-y: auto;
    padding: 12px;
    background: var(--bg-content, #fff);
    border: 1px solid var(--border-color, #E2E8F0);
    border-radius: 10px;
    box-shadow: var(--shadow-md, 0 4px 16px rgba(0,0,0,.12));
}

.inv-filter-options {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.inv-filter-option {
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 13px;
    color: var(--text-primary);
    cursor: pointer;
}

.inv-filter-actions {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px solid var(--border-light, #F1F5F9);
}

.inv-filter-apply {
    border: 1px solid var(--accent, #4338CA);
    background: var(--accent, #4338CA);
    color: #fff;
    font-size: 12.5px;
    font-weight: 600;
    padding: 6px 14px;
    border-radius: 7px;
    cursor: pointer;
}

.inv-filter-reset {
    font-size: 12.5px;
    color: var(--text-muted, #94A3B8);
    text-decoration: underline;
}

.inv-filter-empty {
    font-size: 12.5px;
    color: var(--text-muted, #94A3B8);
    padding: 6px 0;
}

/* --- KPI row with 3 cards (Open Notifications tile removed) ---
   .stats-grid itself is a fixed 4-column grid shared with the row
   below (still 4 cards); this modifier keeps just this row's cards
   even-width instead of leaving an empty 4th slot. Mirrors
   dashboard.css's own .stats-grid breakpoints so it collapses the
   same way on narrower screens. */

.stats-grid-3 {
    grid-template-columns: repeat(3, 1fr);
}

@media (max-width: 1200px) {
    .stats-grid-3 { grid-template-columns: repeat(2, 1fr); }
}

@media (max-width: 900px) {
    .stats-grid-3 { grid-template-columns: 1fr; }
}

.panel-header span a {
    color: #2563EB;
    text-decoration: none;
    font-weight: 600;
}

.panel-header span a:hover {
    text-decoration: underline;
}

.dash-empty {
    padding: 30px 10px;
    text-align: center;
    color: #94A3B8;
    font-size: 13.5px;
}

.dash-action-link {
    text-decoration: none;
}

.dash-notif-list {
    list-style: none;
    margin: 4px 0 0;
    padding: 0;
    max-height: 320px;
    overflow-y: auto;
}

.dash-notif-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 11px 4px;
    border-bottom: 1px solid #F1F5F9;
}

.dash-notif-item:last-child {
    border-bottom: none;
}

.dash-notif-item strong {
    display: block;
    font-size: 13.5px;
    color: var(--text-primary);
    font-weight: 600;
}

.dash-notif-meta {
    display: block;
    margin-top: 2px;
    font-size: 11.5px;
    color: #94A3B8;
}

.dash-notif-dot {
    flex: 0 0 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-top: 5px;
    background: #94A3B8;
}

.dash-notif-dot.priority-critical { background: #EF4444; }
.dash-notif-dot.priority-high { background: #F59E0B; }
.dash-notif-dot.priority-normal { background: #2563EB; }
.dash-notif-dot.priority-note { background: #10B981; }

.activity-icon {
    display: inline-block;
    width: 18px;
    color: #94A3B8;
}

.activity-meta {
    color: #94A3B8;
    font-size: 12.5px;
}


/* =====================================================
   DASHBOARD BREAKDOWNS
   -----------------------------------------------------
   Chart colours below were validated with the data-viz
   six checks (OKLCH lightness band, chroma floor, CVD
   separation under protan/deutan, normal-vision floor,
   contrast vs surface) against both the light (#ffffff)
   and dark (#1b2230) panel surfaces. The app's previous
   chart palette failed two of them -- #94A3B8 sat below
   the chroma floor and was only dE 11.8 from #0EA5E9,
   under the 15 normal-vision floor -- so these steps are
   used here instead of reusing it.
   ===================================================== */

.dash-row-3 {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
}

.dash-row-4 {
    display: grid;
    grid-template-columns: repeat(4, minmax(0, 1fr));
    gap: 18px;
}

@media (max-width: 1100px) {
    .dash-row-3 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
    .dash-row-4 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}

@media (max-width: 720px) {
    .dash-row-3 { grid-template-columns: minmax(0, 1fr); }
    .dash-row-4 { grid-template-columns: minmax(0, 1fr); }
}

/* --- per-user draggable panel grid --- */

.dashboard-panels-grid {
    display: grid;
    grid-template-columns: repeat(12, minmax(0, 1fr));
    gap: 18px;
    margin-bottom: 22px;
}

.dashboard-panels-grid .dashboard-panel {
    margin-bottom: 0;
    position: relative;
    cursor: default;
}

.dash-span-3  { grid-column: span 3; }
.dash-span-4  { grid-column: span 4; }
.dash-span-6  { grid-column: span 6; }
.dash-span-8  { grid-column: span 8; }
.dash-span-12 { grid-column: span 12; }

@media (max-width: 1100px) {
    .dash-span-3, .dash-span-4 { grid-column: span 6; }
    .dash-span-6, .dash-span-8 { grid-column: span 12; }
}

@media (max-width: 720px) {
    .dashboard-panels-grid { grid-template-columns: minmax(0, 1fr); }
    .dash-span-3, .dash-span-4, .dash-span-6, .dash-span-8, .dash-span-12 { grid-column: 1 / -1; }
}

.dash-panel-drag-handle {
    position: absolute;
    top: 10px;
    right: 14px;
    color: var(--text-muted);
    font-size: 13px;
    cursor: grab;
    user-select: none;
    line-height: 1;
    opacity: .55;
}

.dash-panel-drag-handle:hover {
    opacity: 1;
}

.dashboard-panels-grid .dashboard-panel.dash-panel-dragging {
    opacity: .4;
}

.dashboard-panels-grid .dashboard-panel.dash-panel-dragover {
    outline: 2px dashed var(--accent);
    outline-offset: -2px;
}

/* --- ranked bar list --- */

.dash-bars {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.dash-bar-row {
    display: grid;
    grid-template-columns: minmax(0, 8.5rem) 1fr auto;
    align-items: center;
    gap: 10px;
}

.dash-bar-label {
    font-size: 12.5px;
    color: var(--text-secondary, #64748B);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.dash-bar-track {
    position: relative;
    height: 8px;
    border-radius: 999px;
    background: var(--border-light, #F1F5F9);
    overflow: hidden;
}

.dash-bar-fill {
    display: block;
    height: 100%;
    border-radius: 999px;
    min-width: 3px;
}

/* Single hue: length carries the magnitude, not colour. */
.dash-bar-fill.tone-accent   { background: #4338CA; }

/* Reserved status colours -- severity and workflow state only. */
.dash-bar-fill.tone-critical { background: #B42318; }
.dash-bar-fill.tone-serious  { background: #C2410C; }
.dash-bar-fill.tone-warning  { background: #B45309; }
.dash-bar-fill.tone-good     { background: #0D9488; }
.dash-bar-fill.tone-neutral  { background: #0369A1; }

[data-theme="dark"] .dash-bar-fill.tone-accent   { background: #6366F1; }
[data-theme="dark"] .dash-bar-fill.tone-critical { background: #F43F5E; }
[data-theme="dark"] .dash-bar-fill.tone-serious  { background: #FB7185; }
[data-theme="dark"] .dash-bar-fill.tone-warning  { background: #D97706; }
[data-theme="dark"] .dash-bar-fill.tone-good     { background: #0D9488; }
[data-theme="dark"] .dash-bar-fill.tone-neutral  { background: #0284C7; }

.dash-bar-value {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-primary, #1E293B);
    font-variant-numeric: tabular-nums;
    text-align: right;
    min-width: 4.5rem;
}

.dash-bar-value small {
    display: inline-block;
    margin-left: 6px;
    font-weight: 500;
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
}

/* --- admin tasks --- */

.dash-card-attention {
    box-shadow: inset 3px 0 0 #B42318;
}

.dash-task-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
}

.dash-task {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-task:last-child { border-bottom: none; }

.dash-task-dot {
    flex: 0 0 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #94A3B8;
}

.dash-task-dot.tone-critical { background: #B42318; }
.dash-task-dot.tone-warning  { background: #B45309; }
.dash-task-dot.tone-good     { background: #0D9488; }

/* --- team away & on-call subheads (splits one panel into two lists) --- */

.dash-subhead {
    display: flex;
    align-items: center;
    gap: 8px;
    margin: 16px 0 2px;
    font-size: 12.5px;
    font-weight: 600;
    color: var(--text-muted);
    text-transform: uppercase;
    letter-spacing: .02em;
}

.dash-subhead:first-of-type { margin-top: 4px; }

.dash-subhead-n {
    background: var(--border-light, #F1F5F9);
    color: var(--text-primary);
    border-radius: 999px;
    padding: 1px 8px;
    font-size: 11.5px;
    font-weight: 700;
    text-transform: none;
    letter-spacing: normal;
}

/* --- my assigned work ---
   Compact pill chips, one per module -- each module keeps a fixed
   accent colour (not the reserved severity/status palette above) purely
   so the eye can tell Decommission/Patching/SOP/GRC apart at a glance
   across a row. Light pastel background + saturated text/icon, same
   formula as .dash-source-tag.tone-info. */

.dash-mywork-chips {
    margin-top: 10px;
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
}

.dash-mywork-chip {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 9px 14px;
    border-radius: 999px;
    text-decoration: none;
    font-size: 13px;
    border: 1px solid transparent;
    transition: box-shadow .15s ease, transform .15s ease;
}

.dash-mywork-chip:hover {
    box-shadow: var(--shadow-sm, 0 1px 3px rgba(0,0,0,.08));
    transform: translateY(-1px);
}

.dash-mywork-chip-icon {
    font-size: 15px;
    line-height: 1;
}

.dash-mywork-chip-label {
    font-weight: 600;
    color: var(--text-primary, #1E293B);
    white-space: nowrap;
}

.dash-mywork-chip-count {
    font-weight: 700;
    font-variant-numeric: tabular-nums;
    padding-left: 8px;
    border-left: 1px solid rgba(0,0,0,.08);
}

.dash-mywork-chip-count small {
    font-weight: 500;
    font-size: 11px;
    opacity: .8;
    margin-left: 2px;
}

.dash-mywork-chip.tone-sky    { background: #EFF8FF; border-color: #D3EBFF; }
.dash-mywork-chip.tone-amber  { background: #FFF8EB; border-color: #FFE9BE; }
.dash-mywork-chip.tone-indigo { background: #EEF2FF; border-color: #DBE1FF; }
.dash-mywork-chip.tone-teal   { background: #ECFBF7; border-color: #C9F1E6; }

.dash-mywork-chip.tone-sky    .dash-mywork-chip-count { color: #0369A1; }
.dash-mywork-chip.tone-amber  .dash-mywork-chip-count { color: #B45309; }
.dash-mywork-chip.tone-indigo .dash-mywork-chip-count { color: #4338CA; }
.dash-mywork-chip.tone-teal   .dash-mywork-chip-count { color: #0D9488; }

[data-theme="dark"] .dash-mywork-chip.tone-sky    { background: #12293D; border-color: #1D3C57; }
[data-theme="dark"] .dash-mywork-chip.tone-amber  { background: #2E2410; border-color: #4A3B18; }
[data-theme="dark"] .dash-mywork-chip.tone-indigo { background: #1E2144; border-color: #2E3266; }
[data-theme="dark"] .dash-mywork-chip.tone-teal   { background: #0F2C27; border-color: #17453B; }

[data-theme="dark"] .dash-mywork-chip.tone-sky    .dash-mywork-chip-count { color: #7CC4F5; }
[data-theme="dark"] .dash-mywork-chip.tone-amber  .dash-mywork-chip-count { color: #F0B94D; }
[data-theme="dark"] .dash-mywork-chip.tone-indigo .dash-mywork-chip-count { color: #A5ABF7; }
[data-theme="dark"] .dash-mywork-chip.tone-teal   .dash-mywork-chip-count { color: #4FD9BE; }

[data-theme="dark"] .dash-mywork-chip-label { color: var(--text-primary); }
[data-theme="dark"] .dash-mywork-chip-count { border-left-color: rgba(255,255,255,.12); }

.dash-task-label {
    flex: 1;
    font-size: 13.5px;
    color: var(--text-primary, #1E293B);
}

.dash-task-cta,
.dash-panel-cta {
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
    white-space: nowrap;
}

.dash-task-cta:hover,
.dash-panel-cta:hover { text-decoration: underline; }

.dash-panel-cta {
    display: inline-block;
    margin-top: 12px;
}

/* --- pending approvals --- */

.dash-approval-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
    max-height: 260px;
    overflow-y: auto;
}

.dash-approval {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 10px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-approval:last-child { border-bottom: none; }

.dash-approval-main { min-width: 0; }

.dash-approval-main strong {
    display: block;
    font-size: 13.5px;
    font-weight: 600;
    color: var(--text-primary, #1E293B);
}

.dash-approval-meta {
    display: block;
    margin-top: 2px;
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.dash-source-tag {
    flex-shrink: 0;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 9px;
    border-radius: 999px;
    background: var(--hover-bg, #F1F5F9);
    color: var(--text-secondary, #64748B);
}

.dash-source-tag.tone-info {
    background: #EFF6FF;
    color: #1D4ED8;
}

[data-theme="dark"] .dash-source-tag.tone-info {
    background: #1B2740;
    color: #7BA6FF;
}

/* --- recent KB list --- */

.dash-kb-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
}

.dash-kb-item {
    display: grid;
    grid-template-columns: auto 1fr auto;
    align-items: center;
    gap: 12px;
    padding: 11px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-kb-item:last-child { border-bottom: none; }

.dash-kb-num {
    font-size: 11.5px;
    font-weight: 700;
    color: #4338CA;
    background: #EEF2FF;
    padding: 3px 8px;
    border-radius: 6px;
    white-space: nowrap;
}

[data-theme="dark"] .dash-kb-num {
    background: #1B2740;
    color: #818CF8;
}

.dash-kb-title {
    font-size: 13.5px;
    color: var(--text-primary, #1E293B);
    font-weight: 600;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.dash-kb-meta {
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
    white-space: nowrap;
}


/* =====================================================
   FOR YOU SPOTLIGHT
   ----------------------------------------------------
   The personalized feed sits above the KPI cards on
   purpose -- it answers "what needs me by name" before
   the page gets into fleet-wide numbers. Tone colors are
   deliberately soft gradients (not the saturated status
   palette used for severity/workflow elsewhere) so six
   cards side by side read as inviting, not alarming --
   urgency is carried by the pulse dot and badge text
   instead of raw color intensity.
   ===================================================== */

.spotlight-section {
    margin-bottom: 22px;
}

.spotlight-head {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 12px;
}

.spotlight-head h2 {
    margin: 0;
    font-size: 19px;
    font-weight: 700;
    color: var(--text-primary, #1E293B);
}

.spotlight-count {
    font-size: 12px;
    font-weight: 600;
    color: #B45309;
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    padding: 4px 11px;
    border-radius: 999px;
}

[data-theme="dark"] .spotlight-count {
    color: #FBBF24;
    background: #3A2A10;
    border-color: #5A4212;
}

.spotlight-viewall {
    margin-left: auto;
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
    white-space: nowrap;
}

.spotlight-viewall:hover {
    text-decoration: underline;
}

.spotlight-reset {
    background: none;
    border: 1px solid var(--border-light, #E2E8F0);
    color: var(--text-secondary, #64748B);
    font-size: 11.5px;
    font-weight: 600;
    padding: 4px 11px;
    border-radius: 999px;
    cursor: pointer;
}

.spotlight-reset:hover {
    background: var(--hover-bg, #F1F5F9);
    color: var(--text-primary, #1E293B);
}

[data-theme="dark"] .spotlight-reset {
    border-color: #334155;
}

.spotlight-hint {
    margin: -2px 0 10px;
    font-size: 11.5px;
    color: var(--text-secondary, #64748B);
}

.spotlight-hint-icon {
    font-weight: 700;
}

.spotlight-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
    gap: 18px;
}

.spotlight-card {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 34px 18px 16px;
    border-radius: 16px;
    border: 1px solid transparent;
    overflow: hidden;
    box-shadow: var(--shadow-sm, 0 1px 3px rgba(15, 23, 42, .06));
    transition: transform .15s ease, box-shadow .15s ease, opacity .15s ease;
}

.spotlight-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 26px rgba(15, 23, 42, .14);
}

.spotlight-card.spotlight-dragging {
    opacity: .4;
}

.spotlight-controls {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.spotlight-drag {
    cursor: grab;
    font-size: 14px;
    line-height: 1;
    padding: 2px;
    color: var(--text-secondary, #64748B);
    opacity: .6;
}

.spotlight-drag:active {
    cursor: grabbing;
}

.spotlight-dismiss {
    width: 18px;
    height: 18px;
    padding: 0;
    border: none;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    line-height: 1;
    background: rgba(15, 23, 42, .08);
    color: var(--text-secondary, #64748B);
    cursor: pointer;
}

.spotlight-dismiss:hover {
    background: rgba(220, 38, 38, .15);
    color: #B42318;
}

[data-theme="dark"] .spotlight-dismiss {
    background: rgba(255, 255, 255, .08);
}

[data-theme="dark"] .spotlight-dismiss:hover {
    background: rgba(248, 113, 113, .2);
    color: #FCA5A5;
}

.spotlight-link {
    display: flex;
    flex-direction: column;
    gap: 5px;
    text-decoration: none;
    color: inherit;
}

.spotlight-icon {
    font-size: 20px;
    line-height: 1;
}

.spotlight-badge {
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.spotlight-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-primary, #1E293B);
    line-height: 1.35;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.spotlight-meta {
    font-size: 11.5px;
    color: var(--text-secondary, #64748B);
}

.spotlight-pulse {
    position: absolute;
    top: 13px;
    left: 14px;
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: #EF4444;
    animation: spotlightPulse 1.8s infinite;
}

@keyframes spotlightPulse {
    0%   { box-shadow: 0 0 0 0 rgba(239, 68, 68, .55); }
    70%  { box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
    100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
}

/* tones */

.spotlight-card.tone-assigned {
    background: linear-gradient(135deg, #EEF2FF, #E0E7FF);
    border-color: #C7D2FE;
}
.spotlight-card.tone-assigned .spotlight-badge { color: #4338CA; }

.spotlight-card.tone-critical {
    background: linear-gradient(135deg, #FEF2F2, #FEE2E2);
    border-color: #FECACA;
}
.spotlight-card.tone-critical .spotlight-badge { color: #B42318; }

.spotlight-card.tone-note {
    background: linear-gradient(135deg, #EFF6FF, #DBEAFE);
    border-color: #BFDBFE;
}
.spotlight-card.tone-note .spotlight-badge { color: #1D4ED8; }

.spotlight-card.tone-reminder {
    background: linear-gradient(135deg, #FFFBEB, #FEF3C7);
    border-color: #FDE68A;
}
.spotlight-card.tone-reminder .spotlight-badge { color: #B45309; }

.spotlight-card.tone-sticky {
    background: linear-gradient(135deg, #ECFDF5, #D1FAE5);
    border-color: #A7F3D0;
}
.spotlight-card.tone-sticky .spotlight-badge { color: #047857; }

[data-theme="dark"] .spotlight-card.tone-assigned {
    background: linear-gradient(135deg, #1E1B4B, #241F5C);
    border-color: #3730A3;
}
[data-theme="dark"] .spotlight-card.tone-assigned .spotlight-badge { color: #A5B4FC; }

[data-theme="dark"] .spotlight-card.tone-critical {
    background: linear-gradient(135deg, #3A1414, #451A1A);
    border-color: #7F1D1D;
}
[data-theme="dark"] .spotlight-card.tone-critical .spotlight-badge { color: #FCA5A5; }

[data-theme="dark"] .spotlight-card.tone-note {
    background: linear-gradient(135deg, #16213A, #1B2740);
    border-color: #2C4373;
}
[data-theme="dark"] .spotlight-card.tone-note .spotlight-badge { color: #93C5FD; }

[data-theme="dark"] .spotlight-card.tone-reminder {
    background: linear-gradient(135deg, #3A2A10, #43310F);
    border-color: #5A4212;
}
[data-theme="dark"] .spotlight-card.tone-reminder .spotlight-badge { color: #FCD34D; }

[data-theme="dark"] .spotlight-card.tone-sticky {
    background: linear-gradient(135deg, #0F2E24, #123626);
    border-color: #1F5C42;
}
[data-theme="dark"] .spotlight-card.tone-sticky .spotlight-badge { color: #6EE7B7; }

.spotlight-more {
    display: inline-block;
    margin-top: 10px;
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
}

.spotlight-more:hover {
    text-decoration: underline;
}

.spotlight-empty {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 20px;
    border-radius: 16px;
    background: linear-gradient(135deg, #ECFDF5, #F0FDF4);
    border: 1px solid #A7F3D0;
    box-shadow: var(--shadow-sm, 0 1px 3px rgba(15, 23, 42, .06));
}

[data-theme="dark"] .spotlight-empty {
    background: linear-gradient(135deg, #0F2E24, #0D2A1F);
    border-color: #1F5C42;
}

.spotlight-empty-icon {
    font-size: 26px;
    line-height: 1;
}

.spotlight-empty strong {
    display: block;
    font-size: 14px;
    color: var(--text-primary, #1E293B);
}

.spotlight-empty p {
    margin: 3px 0 0;
    font-size: 12.5px;
    color: var(--text-secondary, #64748B);
}

</style>
