<?php

session_start();

require_once __DIR__ . '/config/db.php';


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| Governed by the permissions table under page_key 'permission'.
|
| Previously a hardcoded `trim($_SESSION['role']) !== 'Admin'` check --
| a competing permission model that this very screen is supposed to
| administer. The page that configures permissions was the one page not
| obeying them.
|
| Viewing needs can_view; changing anything needs can_edit (enforced at
| the save handler, not just here).
*/

requireLogin();
requirePermission('permission', 'can_view');

$canEditPermissions = can('permission', 'can_edit');


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| PRIMARY ADMIN
|--------------------------------------------------------------------------
*/

$primaryAdminNcgr = 'ADMIN001';


/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/

$errorMessage = '';
$successMessage = '';


/*
|--------------------------------------------------------------------------
| CREATE / MIGRATE ROLES TABLE
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS roles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        role_name TEXT UNIQUE NOT NULL,
        is_system INTEGER NOT NULL DEFAULT 0,
        is_locked INTEGER NOT NULL DEFAULT 0
    )
");


/*
|--------------------------------------------------------------------------
| MIGRATE ROLES TABLE
|--------------------------------------------------------------------------
*/

$roleColumns = [];

$columns = $pdo->query("
    PRAGMA table_info(roles)
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($columns as $column) {

    $roleColumns[] = $column['name'];

}


if (!in_array('is_system', $roleColumns, true)) {

    $pdo->exec("
        ALTER TABLE roles
        ADD COLUMN is_system INTEGER NOT NULL DEFAULT 0
    ");

}


if (!in_array('is_locked', $roleColumns, true)) {

    $pdo->exec("
        ALTER TABLE roles
        ADD COLUMN is_locked INTEGER NOT NULL DEFAULT 0
    ");

}


/*
|--------------------------------------------------------------------------
| CREATE PERMISSIONS TABLE
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS permissions (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        role TEXT NOT NULL,

        page_key TEXT NOT NULL,

        can_view INTEGER NOT NULL DEFAULT 0,

        can_edit INTEGER NOT NULL DEFAULT 0,

        can_delete INTEGER NOT NULL DEFAULT 0,

        can_export INTEGER NOT NULL DEFAULT 0,

        can_import INTEGER NOT NULL DEFAULT 0,

        can_audit INTEGER NOT NULL DEFAULT 0,

        UNIQUE(role, page_key)

    )
");


/*
|--------------------------------------------------------------------------
| MIGRATE PERMISSIONS TABLE
|--------------------------------------------------------------------------
|
| This protects older installations where the permissions table
| already existed but one or more columns were missing.
|
|--------------------------------------------------------------------------
*/

$permissionColumns = [];

$columns = $pdo->query("
    PRAGMA table_info(permissions)
")->fetchAll(PDO::FETCH_ASSOC);

foreach ($columns as $column) {

    $permissionColumns[] = $column['name'];

}


$permissionColumnDefinitions = [

    'can_view'   => 'INTEGER NOT NULL DEFAULT 0',
    'can_edit'   => 'INTEGER NOT NULL DEFAULT 0',
    'can_delete' => 'INTEGER NOT NULL DEFAULT 0',
    'can_export' => 'INTEGER NOT NULL DEFAULT 0',
    'can_import' => 'INTEGER NOT NULL DEFAULT 0',
    'can_audit'  => 'INTEGER NOT NULL DEFAULT 0'

];


foreach ($permissionColumnDefinitions as $columnName => $definition) {

    if (!in_array($columnName, $permissionColumns, true)) {

        $pdo->exec("
            ALTER TABLE permissions
            ADD COLUMN {$columnName} {$definition}
        ");

    }

}


/*
|--------------------------------------------------------------------------
| CREATE PAGES TABLE
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS pages (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        page_key TEXT UNIQUE NOT NULL,

        page_name TEXT NOT NULL

    )
");


/*
|--------------------------------------------------------------------------
| REGISTER APPLICATION PAGES
|--------------------------------------------------------------------------
*/

$pagesToRegister = [

    /*
    |--------------------------------------------------------------------------
    | Dashboard
    |--------------------------------------------------------------------------
    */

    [
        'dashboard',
        'Dashboard'
    ],


    /*
    |--------------------------------------------------------------------------
    | Inventory
    |--------------------------------------------------------------------------
    */

    [
        'asset',
        'Asset Management'
    ],

    [
        'inventory',
        'Server Inventory'
    ],

    [
        'license_warranty',
        'License and EOL Tracking'
    ],

    [
        'ip',
        'IP Address Management'
    ],

    [
        'ownership',
        'Asset Ownership'
    ],

    [
        'handover',
        'Asset Handover'
    ],

    [
        'decommission',
        'Asset Decommission'
    ],

    [
        'builds',
        'New Build'
    ],

    [
        'container_platform',
        'Container Platform'
    ],

    [
        'oracle_db',
        'Oracle Databases'
    ],

    [
        'dr_mapping',
        'Production / DR Mapping'
    ],

    [
        'major_layouts',
        'Application Layout'
    ],

    [
        'project_overview',
        'Project Overview'
    ],


    /*
    |--------------------------------------------------------------------------
    | Vulnerability & Controls
    |--------------------------------------------------------------------------
    */

    [
        'patching',
        'Quarterly Patching'
    ],

    [
        'critical_exploitable',
        'Critical Exploitable'
    ],

    [
        'grc_schedule',
        'GRC Schedule'
    ],

    [
        'vulnerabilities',
        'DMZ Assessment'
    ],

    [
        'vulnerability_upload',
        'VA Report Upload'
    ],

    [
        'va_assessment',
        'VA Assessment'
    ],

    [
        'compliance',
        'Compliance'
    ],

    [
        'patch',
        'Exception Register'
    ],


    /*
    |--------------------------------------------------------------------------
    | Runbook
    |--------------------------------------------------------------------------
    */

    [
        'sop',
        'SOP'
    ],

    [
        'knowledge',
        'Knowledge Base'
    ],

    [
        'known_issues',
        'Known Issues'
    ],


    /*
    |--------------------------------------------------------------------------
    | Monitoring
    |--------------------------------------------------------------------------
    */

    [
        'splunk',
        'Splunk'
    ],

    [
        'bmc_cmdb',
        'BMC CMDB'
    ],

    [
        'grafana',
        'Grafana'
    ],


    /*
    |--------------------------------------------------------------------------
    | Utilities
    |--------------------------------------------------------------------------
    */

    [
        'mydata',
        'My Data'
    ],

    [
        'diagram_designer',
        'Draw Designs'
    ],

    [
        'hostname',
        'Hostname Generator'
    ],
	[
        'pasgen',
        'Password Generator'
    ],

    [
        'subnet_calculator',
        'Subnet Calculator'
    ],

    [
        'tcpdump_analyzer',
        'Tcpdump Analyzer'
    ],

    [
        'ticket',
        'Ticket Tracking'
    ],

    /*
    | Deliberately its own key, not folded in with tickets: this one
    | governs access to stored credentials.
    */
    [
        'vault',
        'Password Vault'
    ],

    /*
    | Quick Links carries its own per-record publication scope (only me /
    | team / multiple teams / public) on top of this page key. The key
    | governs who reaches the page at all; the scope governs which links
    | they see once there.
    */
    [
        'links',
        'Quick Links'
    ],

    [
        'ssl_manager',
        'SSL Certificate Manager'
    ],


    /*
    |--------------------------------------------------------------------------
    | Options
    |--------------------------------------------------------------------------
    */

    [
        'special_projects',
        'Special Projects'
    ],

    [
        'notification',
        'Notifications'
    ],

    [
        'reminders',
        'Reminders and Notes'
    ],

    [
        'myprofile',
        'My Profile'
    ],

    [
        'users',
        'Manage Users'
    ],

    [
        'help',
        'Help Center'
    ],

    [
        'about',
        'About'
    ],


    /*
    |--------------------------------------------------------------------------
    | Permission Management
    |--------------------------------------------------------------------------
    */

    [
        'permission',
        'Manage Permissions'
    ],


    /*
    |--------------------------------------------------------------------------
    | Settings
    |--------------------------------------------------------------------------
    */

    [
        'settings',
        'Settings'
    ]

];


/*
|--------------------------------------------------------------------------
| INSERT PAGES
|--------------------------------------------------------------------------
*/

$pageInsert = $pdo->prepare("
    INSERT OR IGNORE INTO pages
    (
        page_key,
        page_name
    )
    VALUES
    (
        ?,
        ?
    )
");

foreach ($pagesToRegister as $page) {

    $pageInsert->execute([
        $page[0],
        $page[1]
    ]);

}


/*
|--------------------------------------------------------------------------
| CREATE DEFAULT SYSTEM ROLES
|--------------------------------------------------------------------------
*/

$defaultRoles = [

    [
        'Admin',
        1,
        1
    ],

    [
        'Edit',
        1,
        0
    ],

    [
        'Read-only',
        1,
        0
    ],

    [
        'Reviewer',
        1,
        0
    ]

];


$roleInsert = $pdo->prepare("
    INSERT OR IGNORE INTO roles
    (
        role_name,
        is_system,
        is_locked
    )
    VALUES
    (
        ?,
        ?,
        ?
    )
");

foreach ($defaultRoles as $role) {

    $roleInsert->execute([
        $role[0],
        $role[1],
        $role[2]
    ]);

}


/*
|--------------------------------------------------------------------------
| ALWAYS LOCK ADMIN
|--------------------------------------------------------------------------
*/

$pdo->prepare("
    UPDATE roles
    SET
        is_system = 1,
        is_locked = 1
    WHERE role_name = 'Admin'
")->execute();


/*
|--------------------------------------------------------------------------
| LOAD ALL PAGES
|--------------------------------------------------------------------------
*/

$allPages = $pdo->query("
    SELECT page_key
    FROM pages
    ORDER BY id
")->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| LOAD ALL ROLES
|--------------------------------------------------------------------------
*/

$existingRoles = $pdo->query("
    SELECT role_name
    FROM roles
    ORDER BY id
")->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| CREATE MISSING PERMISSION ROWS
|--------------------------------------------------------------------------
*/

$permissionInsert = $pdo->prepare("
    INSERT OR IGNORE INTO permissions
    (
        role,
        page_key,
        can_view,
        can_edit,
        can_delete,
        can_export,
        can_import,
        can_audit
    )
    VALUES
    (
        ?,
        ?,
        0,
        0,
        0,
        0,
        0,
        0
    )
");


foreach ($existingRoles as $roleName) {

    foreach ($allPages as $pageKey) {

        $permissionInsert->execute([
            $roleName,
            $pageKey
        ]);

    }

}


/*
|--------------------------------------------------------------------------
| FORCE ADMIN TO FULL ACCESS
|--------------------------------------------------------------------------
|
| The Admin role is locked in the UI (its permissions can never be
| edited/downgraded through this page), so its permission rows must
| always be kept at full access here instead. Without this, a page
| newly registered above starts at all-zero permissions -- including
| for Admin -- and Admin gets silently locked out of pages it should
| always be able to use. Runs on every load; harmless if already 1s.
|--------------------------------------------------------------------------
*/

$pdo->exec("
    UPDATE permissions
    SET
        can_view = 1,
        can_edit = 1,
        can_delete = 1,
        can_export = 1,
        can_import = 1,
        can_audit = 1
    WHERE role = 'Admin'
");


/*
|--------------------------------------------------------------------------
| LOAD ROLES
|--------------------------------------------------------------------------
*/

function loadRoles(PDO $pdo)
{
    return $pdo->query("
        SELECT
            id,
            role_name,
            is_system,
            is_locked
        FROM roles
        ORDER BY
            CASE role_name
                WHEN 'Admin' THEN 1
                WHEN 'Edit' THEN 2
                WHEN 'Read-only' THEN 3
                WHEN 'Reviewer' THEN 4
                ELSE 5
            END,
            role_name
    ")->fetchAll(PDO::FETCH_ASSOC);
}


$roles = loadRoles($pdo);


/*
|--------------------------------------------------------------------------
| ROLE NAMES
|--------------------------------------------------------------------------
*/

$roleNames = [];

foreach ($roles as $role) {

    $roleNames[] = trim($role['role_name']);

}


/*
|--------------------------------------------------------------------------
| SELECTED ROLE
|--------------------------------------------------------------------------
*/

$selectedRole = trim($_GET['role'] ?? '');


if (
    $selectedRole === '' &&
    !empty($roleNames)
) {

    $selectedRole = $roleNames[0];

}


/*
|--------------------------------------------------------------------------
| HANDLE POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    /*
    | Every write on this page needs can_edit, not merely can_view.
    | Gating the action rather than only the page means a role granted
    | read access to the permission matrix cannot POST changes to it by
    | submitting the form directly.
    */
    requirePermission('permission', 'can_edit');

    $action = $_POST['action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | CREATE ROLE
    |--------------------------------------------------------------------------
    */

    if ($action === 'create_role') {

        $newRole = trim(
            $_POST['new_role'] ?? ''
        );


        if ($newRole === '') {

            $errorMessage =
                'Please enter a role name.';

        } elseif (strlen($newRole) > 100) {

            $errorMessage =
                'Role name is too long.';

        } elseif (
            preg_match(
                '/[^a-zA-Z0-9 _-]/',
                $newRole
            )
        ) {

            $errorMessage =
                'Role name contains invalid characters.';

        } elseif (
            in_array(
                strtolower($newRole),
                array_map(
                    'strtolower',
                    $roleNames
                ),
                true
            )
        ) {

            $errorMessage =
                'This role already exists.';

        } else {

            try {

                $pdo->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | INSERT ROLE
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare("
                    INSERT INTO roles
                    (
                        role_name,
                        is_system,
                        is_locked
                    )
                    VALUES
                    (
                        ?,
                        0,
                        0
                    )
                ");

                $stmt->execute([
                    $newRole
                ]);


                /*
                |--------------------------------------------------------------------------
                | CREATE DEFAULT PERMISSIONS
                |--------------------------------------------------------------------------
                */

                $insertPermission = $pdo->prepare("
                    INSERT OR IGNORE INTO permissions
                    (
                        role,
                        page_key,
                        can_view,
                        can_edit,
                        can_delete,
                        can_export,
                        can_import,
                        can_audit
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        0,
                        0,
                        0,
                        0,
                        0,
                        0
                    )
                ");


                foreach ($allPages as $pageKey) {

                    $insertPermission->execute([
                        $newRole,
                        $pageKey
                    ]);

                }


                $pdo->commit();


                $successMessage =
                    "Role '{$newRole}' created successfully.";

                $selectedRole = $newRole;


            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {

                    $pdo->rollBack();

                }

                $errorMessage =
                    'Unable to create role: ' . $e->getMessage();

            }

        }

    }


    /*
    |--------------------------------------------------------------------------
    | DELETE ROLE
    |--------------------------------------------------------------------------
    */

    elseif ($action === 'delete_role') {

        $deleteRole = trim(
            $_POST['role'] ?? ''
        );


        if ($deleteRole === 'Admin') {

            $errorMessage =
                'The Admin role is locked and cannot be deleted.';

        } else {

            $stmt = $pdo->prepare("
                SELECT
                    id,
                    role_name,
                    is_system,
                    is_locked
                FROM roles
                WHERE role_name = ?
            ");

            $stmt->execute([
                $deleteRole
            ]);

            $roleInfo =
                $stmt->fetch(PDO::FETCH_ASSOC);


            if (!$roleInfo) {

                $errorMessage =
                    'Role not found.';

            } elseif (
                (int)$roleInfo['is_locked'] === 1
            ) {

                $errorMessage =
                    'This role is locked and cannot be deleted.';

            } else {

                /*
                |--------------------------------------------------------------------------
                | CHECK ASSIGNED USERS
                |--------------------------------------------------------------------------
                |
                | Checked against user_roles rather than users.role: a user
                | can now hold this role as a secondary assignment without
                | it being their primary role, and deleting out from under
                | that assignment would silently strip privileges the next
                | time authz.php recomputes them.
                |--------------------------------------------------------------------------
                */

                $stmt = $pdo->prepare("
                    SELECT COUNT(DISTINCT user_id)
                    FROM user_roles
                    WHERE LOWER(TRIM(role_name)) = LOWER(TRIM(?))
                ");

                $stmt->execute([
                    $deleteRole
                ]);

                $assignedUsers =
                    (int)$stmt->fetchColumn();


                if ($assignedUsers > 0) {

                    $errorMessage =
                        "Cannot delete '{$deleteRole}' because "
                        . $assignedUsers
                        . " user(s) are currently assigned to this role.";

                } else {

                    try {

                        $pdo->beginTransaction();


                        /*
                        |--------------------------------------------------------------------------
                        | DELETE PERMISSIONS
                        |--------------------------------------------------------------------------
                        */

                        $stmt = $pdo->prepare("
                            DELETE FROM permissions
                            WHERE role = ?
                        ");

                        $stmt->execute([
                            $deleteRole
                        ]);


                        /*
                        |--------------------------------------------------------------------------
                        | DELETE USER_ROLES
                        |--------------------------------------------------------------------------
                        |
                        | Belt-and-braces: the assigned-user check above
                        | already guarantees this is a no-op in practice.
                        |--------------------------------------------------------------------------
                        */

                        $stmt = $pdo->prepare("
                            DELETE FROM user_roles
                            WHERE LOWER(TRIM(role_name)) = LOWER(TRIM(?))
                        ");

                        $stmt->execute([
                            $deleteRole
                        ]);


                        /*
                        |--------------------------------------------------------------------------
                        | DELETE ROLE
                        |--------------------------------------------------------------------------
                        */

                        $stmt = $pdo->prepare("
                            DELETE FROM roles
                            WHERE role_name = ?
                        ");

                        $stmt->execute([
                            $deleteRole
                        ]);


                        $pdo->commit();


                        $successMessage =
                            "Role '{$deleteRole}' deleted successfully.";


                        if ($selectedRole === $deleteRole) {

                            $selectedRole = 'Admin';

                        }


                    } catch (Throwable $e) {

                        if ($pdo->inTransaction()) {

                            $pdo->rollBack();

                        }

                        $errorMessage =
                            'Unable to delete role: ' . $e->getMessage();

                    }

                }

            }

        }

    }


    /*
    |--------------------------------------------------------------------------
    | SAVE PERMISSIONS
    |--------------------------------------------------------------------------
    */

    elseif ($action === 'save_permissions') {

        $selectedRole = trim(
            $_POST['role'] ?? ''
        );


        /*
        |--------------------------------------------------------------------------
        | VALIDATE ROLE
        |--------------------------------------------------------------------------
        */

        if (
            $selectedRole === '' ||
            !in_array(
                $selectedRole,
                $roleNames,
                true
            )
        ) {

            $errorMessage =
                'Invalid role selected.';

        } elseif ($selectedRole === 'Admin') {

            $errorMessage =
                'The Admin role is locked. Its permissions cannot be changed.';

        } elseif (
            authzWouldOrphanAdmin(
                $pdo,
                $selectedRole,
                ['can_edit' => isset($_POST['permissions']['permission']['edit']) ? 1 : 0]
            )
        ) {

            /*
            |--------------------------------------------------------------------------
            | SELF-LOCKOUT GUARD
            |--------------------------------------------------------------------------
            |
            | Now that this page is governed by the permissions table rather
            | than a hardcoded Admin check, revoking permission.can_edit from
            | the last role that still has it -- and has an approved user in
            | it -- would leave nobody able to reach this screen again. That
            | is not recoverable through the UI.
            |
            | Blocked rather than warned: the mistake is irreversible.
            |--------------------------------------------------------------------------
            */

            $errorMessage =
                'Blocked: this change would remove "Manage Permissions" edit access '
                . 'from the last role that still has it, locking everyone out of this '
                . 'screen. Grant it to another role first.';

        } else {

            try {

                $pdo->beginTransaction();


                /*
                |--------------------------------------------------------------------------
                | PREPARE UPDATE
                |--------------------------------------------------------------------------
                */

                $updateStmt = $pdo->prepare("
                    UPDATE permissions
                    SET
                        can_view = ?,
                        can_edit = ?,
                        can_delete = ?,
                        can_export = ?,
                        can_import = ?,
                        can_audit = ?
                    WHERE
                        role = ?
                        AND page_key = ?
                ");


                /*
                |--------------------------------------------------------------------------
                | PREPARE INSERT
                |--------------------------------------------------------------------------
                */

                $insertStmt = $pdo->prepare("
                    INSERT OR IGNORE INTO permissions
                    (
                        role,
                        page_key,
                        can_view,
                        can_edit,
                        can_delete,
                        can_export,
                        can_import,
                        can_audit
                    )
                    VALUES
                    (
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?,
                        ?
                    )
                ");


                /*
                |--------------------------------------------------------------------------
                | SAVE EVERY PAGE
                |--------------------------------------------------------------------------
                */

                foreach ($allPages as $pageKey) {

                    /*
                    |--------------------------------------------------------------------------
                    | IMPORTANT
                    |--------------------------------------------------------------------------
                    |
                    | The HTML uses:
                    |
                    | permissions[page_key][view]
                    |
                    | therefore this correctly retrieves:
                    |
                    | $_POST['permissions'][$pageKey]
                    |
                    |--------------------------------------------------------------------------
                    */

                    $permission =
                        $_POST['permissions'][$pageKey]
                        ?? [];


                    /*
                    |--------------------------------------------------------------------------
                    | READ VALUES
                    |--------------------------------------------------------------------------
                    */

                    $canView =
                        isset($permission['view'])
                        ? 1
                        : 0;


                    $canEdit =
                        isset($permission['edit'])
                        ? 1
                        : 0;


                    $canDelete =
                        isset($permission['delete'])
                        ? 1
                        : 0;


                    $canExport =
                        isset($permission['export'])
                        ? 1
                        : 0;


                    $canImport =
                        isset($permission['import'])
                        ? 1
                        : 0;


                    $canAudit =
                        isset($permission['audit'])
                        ? 1
                        : 0;


                    /*
                    |--------------------------------------------------------------------------
                    | VIEW IS REQUIRED
                    |--------------------------------------------------------------------------
                    */

                    if ($canView === 0) {

                        $canEdit = 0;
                        $canDelete = 0;
                        $canExport = 0;
                        $canImport = 0;
                        $canAudit = 0;

                    }


                    /*
                    |--------------------------------------------------------------------------
                    | UPDATE EXISTING ROW
                    |--------------------------------------------------------------------------
                    */

                    $updateStmt->execute([

                        $canView,

                        $canEdit,

                        $canDelete,

                        $canExport,

                        $canImport,

                        $canAudit,

                        $selectedRole,

                        $pageKey

                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | INSERT IF ROW DOES NOT EXIST
                    |--------------------------------------------------------------------------
                    */

                    if ($updateStmt->rowCount() === 0) {

                        $insertStmt->execute([

                            $selectedRole,

                            $pageKey,

                            $canView,

                            $canEdit,

                            $canDelete,

                            $canExport,

                            $canImport,

                            $canAudit

                        ]);

                    }

                }


                $pdo->commit();


                $successMessage =
                    "Permissions saved successfully for {$selectedRole}.";


            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {

                    $pdo->rollBack();

                }

                $errorMessage =
                    'Unable to save permissions: '
                    . $e->getMessage();

            }

        }

    }

}


/*
|--------------------------------------------------------------------------
| RELOAD ROLES AFTER POST
|--------------------------------------------------------------------------
*/

$roles = loadRoles($pdo);


$roleNames = [];

foreach ($roles as $role) {

    $roleNames[] =
        trim($role['role_name']);

}


/*
|--------------------------------------------------------------------------
| MAKE SURE SELECTED ROLE EXISTS
|--------------------------------------------------------------------------
*/

if (
    $selectedRole === '' ||
    !in_array(
        $selectedRole,
        $roleNames,
        true
    )
) {

    $selectedRole =
        $roleNames[0] ?? '';

}


/*
|--------------------------------------------------------------------------
| LOAD PAGES
|--------------------------------------------------------------------------
*/

$pages = $pdo->query("
    SELECT
        id,
        page_key,
        page_name
    FROM pages
    ORDER BY id
")->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| LOAD CURRENT PERMISSIONS
|--------------------------------------------------------------------------
*/

$currentPermissions = [];


if ($selectedRole !== '') {

    $stmt = $pdo->prepare("
        SELECT
            page_key,
            can_view,
            can_edit,
            can_delete,
            can_export,
            can_import,
            can_audit
        FROM permissions
        WHERE role = ?
    ");

    $stmt->execute([
        $selectedRole
    ]);


    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        as $permission
    ) {

        $currentPermissions[
            $permission['page_key']
        ] = $permission;

    }

}


/*
|--------------------------------------------------------------------------
| DEFAULT PERMISSION
|--------------------------------------------------------------------------
*/

$defaultPermission = [

    'can_view'   => 0,
    'can_edit'   => 0,
    'can_delete' => 0,
    'can_export' => 0,
    'can_import' => 0,
    'can_audit'  => 0

];


/*
|--------------------------------------------------------------------------
| ADMIN LOCK
|--------------------------------------------------------------------------
*/

$selectedRoleLocked =
    $selectedRole === 'Admin';


/*
|--------------------------------------------------------------------------
| HEADER + SIDEBAR
|--------------------------------------------------------------------------
*/

$page_title = 'Manage Permissions | InfraVault';

require_once __DIR__ . '/includes/header.php';

require_once __DIR__ . '/includes/sidebar.php';

?>


<div class="content">


<style>

.permission-container {

    max-width: 1250px;

    margin: 25px auto;

    background: var(--bg-content);

    padding: 28px;

    border-radius: 14px;

    box-shadow:
        0 5px 25px rgba(0,0,0,.08);

}


.permission-header {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    margin-bottom: 25px;

}


.permission-header h1 {

    margin: 0;

    color: var(--text-primary);

}


.permission-header p {

    margin: 6px 0 0;

    color: var(--text-secondary);

}


.message-success {

    background: #dcfce7;

    color: #166534;

    border: 1px solid #bbf7d0;

    padding: 14px;

    border-radius: 8px;

    margin-bottom: 20px;

}


.message-error {

    background: #fee2e2;

    color: #991b1b;

    border: 1px solid #fecaca;

    padding: 14px;

    border-radius: 8px;

    margin-bottom: 20px;

}


.role-management {

    display: grid;

    grid-template-columns: 1fr 1fr;

    gap: 20px;

    margin-bottom: 25px;

}


.role-box {

    background: var(--hover-bg);

    border: 1px solid var(--border-color);

    padding: 20px;

    border-radius: 10px;

}


.role-box h3 {

    margin-top: 0;

    color: var(--text-primary);

}


.role-form {

    display: flex;

    gap: 10px;

}


.role-form input,
.role-form select {

    flex: 1;

    padding: 11px 13px;

    border: 1px solid var(--border-color);

    border-radius: 7px;

    background: var(--bg-content);

}


.btn {

    border: 0;

    padding: 10px 15px;

    border-radius: 7px;

    cursor: pointer;

    font-weight: 600;

}


.btn-primary {

    background: #2563eb;

    color: #fff;

}


.btn-danger {

    background: #dc2626;

    color: #fff;

}


.btn-primary:hover {

    background: #1d4ed8;

}


.btn-danger:hover {

    background: #b91c1c;

}


.role-select {

    background: var(--hover-bg);

    border: 1px solid var(--border-color);

    padding: 20px;

    border-radius: 10px;

    margin-bottom: 20px;

}


.role-select label {

    display: block;

    font-weight: 700;

    margin-bottom: 8px;

}


.role-select select {

    min-width: 280px;

    padding: 11px 14px;

    border: 1px solid var(--border-color);

    border-radius: 7px;

}


[data-theme="dark"] .role-select select {

    background: var(--input-bg);

    color: var(--text-primary);

    border-color: var(--input-border);

}


.locked-notice {

    background: #fff7ed;

    border: 1px solid #fed7aa;

    color: #9a3412;

    padding: 14px 16px;

    border-radius: 8px;

    margin-bottom: 20px;

}


[data-theme="dark"] .locked-notice {

    background: rgba(234, 88, 12, .15);

    border-color: rgba(251, 146, 60, .35);

    color: #fdba74;

}


.info-box {

    background: #eff6ff;

    border: 1px solid #bfdbfe;

    color: #1e40af;

    padding: 14px 16px;

    border-radius: 8px;

    margin-bottom: 20px;

    line-height: 1.5;

}


[data-theme="dark"] .info-box {

    background: rgba(37, 99, 235, .15);

    border-color: rgba(59, 130, 246, .35);

    color: #93c5fd;

}


.table-wrapper {

    overflow-x: auto;

    border: 1px solid var(--border-color);

    border-radius: 10px;

}


.permission-table {

    width: 100%;

    border-collapse: collapse;

    min-width: 900px;

}


.permission-table th,
.permission-table td {

    padding: 13px;

    border-bottom: 1px solid var(--border-color);

    text-align: center;

}


.permission-table th {

    background: var(--hover-bg);

    color: var(--text-primary);

}


.permission-table th:first-child,
.permission-table td:first-child {

    text-align: left;

    min-width: 270px;

}


.permission-table tbody tr:hover {

    background: var(--hover-bg);

}


.page-name {

    display: block;

    font-weight: 700;

    color: var(--text-primary);

}


.page-key {

    display: block;

    color: var(--text-muted);

    font-size: 12px;

    margin-top: 3px;

}


.permission-table input[type="checkbox"] {

    width: 19px;

    height: 19px;

    accent-color: #2563eb;

    cursor: pointer;

}


.permission-table input[type="checkbox"]:disabled {

    cursor: not-allowed;

    opacity: .45;

}


.view-column {

    background: var(--hover-bg);

}


.actions {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 15px;

    margin-top: 20px;

}


.quick-actions {

    display: flex;

    gap: 8px;

    flex-wrap: wrap;

}


.quick-button {

    border: 1px solid var(--border-color);

    background: var(--bg-content);

    color: var(--text-primary);

    padding: 8px 12px;

    border-radius: 6px;

    cursor: pointer;

}


.quick-button:hover {

    background: var(--hover-bg);

}


.quick-button:disabled {

    opacity: .5;

    cursor: not-allowed;

}


.save-button {

    background: #2563eb;

    color: #fff;

    border: 0;

    padding: 12px 22px;

    border-radius: 7px;

    font-weight: 700;

    cursor: pointer;

}


.save-button:hover {

    background: #1d4ed8;

}


.save-button:disabled {

    background: #94a3b8;

    cursor: not-allowed;

}


.locked-badge {

    display: inline-block;

    background: #fee2e2;

    color: #991b1b;

    padding: 4px 8px;

    border-radius: 5px;

    font-size: 12px;

    font-weight: 700;

}


@media(max-width: 800px) {

    .role-management {

        grid-template-columns: 1fr;

    }

    .permission-header {

        flex-direction: column;

        align-items: flex-start;

    }

    .role-form {

        flex-direction: column;

    }

}

</style>


<div class="permission-container">


<!-- ==========================================================
     HEADER
=========================================================== -->

<div class="permission-header">

    <div>

        <h1>
            Manage Permissions
        </h1>

        <p>
            Control page visibility and application permissions
            by role.
        </p>

    </div>

</div>


<!-- ==========================================================
     MESSAGES
=========================================================== -->

<?php if ($successMessage !== ''): ?>

    <div class="message-success">

        ✓ <?= h($successMessage) ?>

    </div>

<?php endif; ?>


<?php if ($errorMessage !== ''): ?>

    <div class="message-error">

        <strong>Error:</strong>

        <?= h($errorMessage) ?>

    </div>

<?php endif; ?>


<!-- ==========================================================
     ROLE MANAGEMENT
=========================================================== -->

<div class="role-management">


<!-- CREATE ROLE -->

<div class="role-box">

    <h3>
        Add New Role
    </h3>

    <p style="color:var(--text-secondary);font-size:14px;">

        New roles start with no page permissions.

        They will automatically appear in
        <strong>User Management</strong>.

    </p>


    <form
        method="POST"
        class="role-form"
    >

        <input
            type="hidden"
            name="action"
            value="create_role"
        >


        <input
            type="text"
            name="new_role"
            placeholder="Example: Auditor"
            maxlength="100"
            required
        >


        <button
            type="submit"
            class="btn btn-primary"
        >

            + Add Role

        </button>

    </form>

</div>


<!-- DELETE ROLE -->

<div class="role-box">

    <h3>
        Delete Role
    </h3>

    <p style="color:var(--text-secondary);font-size:14px;">

        Roles assigned to users cannot be deleted.

        System roles are protected.

    </p>


    <form
        method="POST"
        class="role-form"
        onsubmit="
            return confirm(
                'Delete this role and all its permissions?'
            );
        "
    >

        <input
            type="hidden"
            name="action"
            value="delete_role"
        >


        <select
            name="role"
            required
        >

            <?php foreach ($roles as $role): ?>

                <option
                    value="<?= h($role['role_name']) ?>"
                    <?= (int)$role['is_locked'] === 1
                        ? 'disabled'
                        : '' ?>
                >

                    <?= h($role['role_name']) ?>

                    <?php if (
                        (int)$role['is_locked'] === 1
                    ): ?>

                        (Locked)

                    <?php endif; ?>

                </option>

            <?php endforeach; ?>

        </select>


        <button
            type="submit"
            class="btn btn-danger"
        >

            Delete

        </button>

    </form>

</div>


</div>


<!-- ==========================================================
     SELECT ROLE
=========================================================== -->

<div class="role-select">

    <form
        method="GET"
        action="permission.php"
    >

        <label for="role">

            Select Role

        </label>


        <select
            id="role"
            name="role"
            onchange="this.form.submit()"
        >

            <?php foreach ($roles as $role): ?>

                <option
                    value="<?= h($role['role_name']) ?>"
                    <?= $selectedRole === $role['role_name']
                        ? 'selected'
                        : '' ?>
                >

                    <?= h($role['role_name']) ?>

                    <?php if (
                        (int)$role['is_locked'] === 1
                    ): ?>

                        🔒

                    <?php endif; ?>

                </option>

            <?php endforeach; ?>

        </select>

    </form>

</div>


<!-- ==========================================================
     ADMIN LOCK
=========================================================== -->

<?php if ($selectedRoleLocked): ?>

    <div class="locked-notice">

        <strong>
            🔒 Admin permissions are locked.
        </strong>

        <br><br>

        The <strong>Admin</strong> role cannot be
        modified or deleted.

        <br><br>

        The primary account
        <strong><?= h($primaryAdminNcgr) ?></strong>
        is permanently protected.

    </div>

<?php endif; ?>


<!-- ==========================================================
     INFORMATION
=========================================================== -->

<div class="info-box">

    <strong>View</strong> controls whether the page is
    available to the selected role.

    <br><br>

    When <strong>View</strong> is disabled:

    <ul>

        <li>
            The page should disappear from the sidebar.
        </li>

        <li>
            Direct access to the page should be denied.
        </li>

        <li>
            Edit, Delete, Export, Import and Audit are
            automatically disabled.
        </li>

    </ul>

</div>


<!-- ==========================================================
     PERMISSION FORM
=========================================================== -->

<form
    method="POST"
    action="permission.php"
    id="permissionForm"
>


<input
    type="hidden"
    name="action"
    value="save_permissions"
>


<input
    type="hidden"
    name="role"
    value="<?= h($selectedRole) ?>"
>


<!-- ==========================================================
     QUICK ACTIONS
=========================================================== -->

<div
    class="actions"
    style="margin-top:0;margin-bottom:15px;"
>

    <div class="quick-actions">


        <button
            type="button"
            class="quick-button"
            onclick="setAllPermissions(true)"
            <?= $selectedRoleLocked
                ? 'disabled'
                : '' ?>
        >

            Select All

        </button>


        <button
            type="button"
            class="quick-button"
            onclick="setAllPermissions(false)"
            <?= $selectedRoleLocked
                ? 'disabled'
                : '' ?>
        >

            Clear All

        </button>


        <button
            type="button"
            class="quick-button"
            onclick="setAllView(true)"
            <?= $selectedRoleLocked
                ? 'disabled'
                : '' ?>
        >

            Show All Pages

        </button>


        <button
            type="button"
            class="quick-button"
            onclick="setAllView(false)"
            <?= $selectedRoleLocked
                ? 'disabled'
                : '' ?>
        >

            Hide All Pages

        </button>


    </div>

</div>


<!-- ==========================================================
     TABLE
=========================================================== -->

<div class="table-wrapper">


<table class="permission-table">


<thead>

<tr>

    <th>
        Page
    </th>

    <th class="view-column">
        View
    </th>

    <th>
        Edit
    </th>

    <th>
        Delete
    </th>

    <th>
        Export
    </th>

    <th>
        Import
    </th>

    <th>
        Audit
    </th>

</tr>

</thead>


<tbody>


<?php foreach ($pages as $page): ?>

<?php

$pageKey = $page['page_key'];

$permission =
    $currentPermissions[$pageKey]
    ?? $defaultPermission;

$canView =
    (int)$permission['can_view'] === 1;

?>


<tr>


<!-- PAGE -->

<td>

    <span class="page-name">

        <?= h($page['page_name']) ?>

    </span>


    <span class="page-key">

        <?= h($pageKey) ?>

    </span>

</td>


<!-- VIEW -->

<td class="view-column">

    <input
        type="checkbox"
        class="permission-checkbox view-checkbox"
        name="permissions[<?= h($pageKey) ?>][view]"
        <?= $canView ? 'checked' : '' ?>
        <?= $selectedRoleLocked ? 'disabled' : '' ?>
    >

</td>


<!-- EDIT -->

<td>

    <input
        type="checkbox"
        class="permission-checkbox child-permission"
        name="permissions[<?= h($pageKey) ?>][edit]"
        <?= (int)$permission['can_edit'] === 1
            ? 'checked'
            : '' ?>
        <?= !$canView || $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

</td>


<!-- DELETE -->

<td>

    <input
        type="checkbox"
        class="permission-checkbox child-permission"
        name="permissions[<?= h($pageKey) ?>][delete]"
        <?= (int)$permission['can_delete'] === 1
            ? 'checked'
            : '' ?>
        <?= !$canView || $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

</td>


<!-- EXPORT -->

<td>

    <input
        type="checkbox"
        class="permission-checkbox child-permission"
        name="permissions[<?= h($pageKey) ?>][export]"
        <?= (int)$permission['can_export'] === 1
            ? 'checked'
            : '' ?>
        <?= !$canView || $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

</td>


<!-- IMPORT -->

<td>

    <input
        type="checkbox"
        class="permission-checkbox child-permission"
        name="permissions[<?= h($pageKey) ?>][import]"
        <?= (int)$permission['can_import'] === 1
            ? 'checked'
            : '' ?>
        <?= !$canView || $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

</td>


<!-- AUDIT -->

<td>

    <input
        type="checkbox"
        class="permission-checkbox child-permission"
        name="permissions[<?= h($pageKey) ?>][audit]"
        <?= (int)$permission['can_audit'] === 1
            ? 'checked'
            : '' ?>
        <?= !$canView || $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

</td>


</tr>


<?php endforeach; ?>


<?php if (empty($pages)): ?>

<tr>

    <td
        colspan="7"
        style="text-align:center;color:var(--text-secondary);"
    >

        No application pages registered.

    </td>

</tr>

<?php endif; ?>


</tbody>

</table>

</div>


<!-- ==========================================================
     SAVE
=========================================================== -->

<div class="actions">


    <div
        style="
            color:var(--text-secondary);
            font-size:13px;
        "
    >

        Role:

        <strong>
            <?= h($selectedRole) ?>
        </strong>


        <?php if ($selectedRoleLocked): ?>

            <span class="locked-badge">
                LOCKED
            </span>

        <?php endif; ?>


    </div>


    <button
        type="submit"
        class="save-button"
        <?= $selectedRoleLocked
            ? 'disabled'
            : '' ?>
    >

        <?= $selectedRoleLocked
            ? '🔒 Permissions Locked'
            : '💾 Save Permissions' ?>

    </button>


</div>


</form>


</div>


<script>

/*
|--------------------------------------------------------------------------
| UPDATE ROW STATE
|--------------------------------------------------------------------------
*/

function updateRowState(viewCheckbox)
{
    const row = viewCheckbox.closest('tr');

    if (!row) {
        return;
    }

    const childPermissions =
        row.querySelectorAll('.child-permission');


    childPermissions.forEach(function(checkbox)
    {

        if (viewCheckbox.checked) {

            checkbox.disabled = false;

        } else {

            checkbox.checked = false;

            checkbox.disabled = true;

        }

    });
}


/*
|--------------------------------------------------------------------------
| SET ALL PERMISSIONS
|--------------------------------------------------------------------------
*/

function setAllPermissions(checked)
{
    document
        .querySelectorAll('.view-checkbox')
        .forEach(function(viewCheckbox)
        {
            if (!viewCheckbox.disabled) {

                viewCheckbox.checked = checked;

                updateRowState(
                    viewCheckbox
                );

            }
        });


    if (checked) {

        document
            .querySelectorAll('.child-permission')
            .forEach(function(checkbox)
            {
                if (!checkbox.disabled) {

                    checkbox.checked = true;

                }
            });

    }

}


/*
|--------------------------------------------------------------------------
| SHOW / HIDE ALL VIEW
|--------------------------------------------------------------------------
*/

function setAllView(checked)
{
    document
        .querySelectorAll('.view-checkbox')
        .forEach(function(viewCheckbox)
        {

            if (!viewCheckbox.disabled) {

                viewCheckbox.checked =
                    checked;

                updateRowState(
                    viewCheckbox
                );

            }

        });
}


/*
|--------------------------------------------------------------------------
| VIEW CHECKBOX CHANGE
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll('.view-checkbox')
    .forEach(function(viewCheckbox)
    {

        viewCheckbox.addEventListener(
            'change',
            function()
            {
                updateRowState(this);
            }
        );

    });


/*
|--------------------------------------------------------------------------
| INITIALIZE ROW STATES
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll('.view-checkbox')
    .forEach(function(viewCheckbox)
    {

        if (!viewCheckbox.disabled) {

            updateRowState(
                viewCheckbox
            );

        }

    });


/*
|--------------------------------------------------------------------------
| PROTECT ADMIN ON CLIENT SIDE
|--------------------------------------------------------------------------
*/

const permissionForm =
    document.getElementById(
        'permissionForm'
    );


if (permissionForm) {

    permissionForm.addEventListener(
        'submit',
        function(event)
        {

            const roleInput =
                this.querySelector(
                    'input[name="role"]'
                );


            if (
                roleInput &&
                roleInput.value === 'Admin'
            ) {

                event.preventDefault();

                alert(
                    'Admin permissions are locked.'
                );

            }

        }
    );

}

</script>


<?php

require_once __DIR__ . '/includes/footer.php';

?>
