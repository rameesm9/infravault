<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('grc_schedule', 'can_view');
requirePermission('grc_schedule', 'can_export');



/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| SQLite Helpers
|--------------------------------------------------------------------------
*/

/**
 * Return all columns from a SQLite table.
 */
function sqlite_table_columns(
    PDO $pdo,
    string $table
): array {

    $stmt = $pdo->query(
        'PRAGMA table_info("' .
        str_replace('"', '""', $table) .
        '")'
    );

    $columns = [];

    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        as $row
    ) {
        $columns[] = $row['name'];
    }

    return $columns;
}


/**
 * Check if a table exists.
 */
function sqlite_table_exists(
    PDO $pdo,
    string $table
): bool {

    $stmt = $pdo->prepare("
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
        AND name = ?
        LIMIT 1
    ");

    $stmt->execute([
        $table
    ]);

    return (bool) $stmt->fetchColumn();
}


/**
 * Get a value safely from an array.
 */
function row_value(
    array $row,
    string $column,
    $default = ''
) {

    return array_key_exists(
        $column,
        $row
    )
        ? $row[$column]
        : $default;
}


/*
|--------------------------------------------------------------------------
| Check database
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {
    exit('Database connection not available.');
}


/*
|--------------------------------------------------------------------------
| Find Tables
|--------------------------------------------------------------------------
*/

$schedule_table = 'grc_schedules';
$inventory_table = 'inventory';
$users_table = 'users';


if (
    !sqlite_table_exists(
        $pdo,
        $schedule_table
    )
) {

    http_response_code(500);

    exit(
        'SQLite table grc_schedules does not exist.'
    );
}


$schedule_columns =
    sqlite_table_columns(
        $pdo,
        $schedule_table
    );


$inventory_exists =
    sqlite_table_exists(
        $pdo,
        $inventory_table
    );


$users_exists =
    sqlite_table_exists(
        $pdo,
        $users_table
    );


$inventory_columns =
    $inventory_exists
        ? sqlite_table_columns(
            $pdo,
            $inventory_table
        )
        : [];


$user_columns =
    $users_exists
        ? sqlite_table_columns(
            $pdo,
            $users_table
        )
        : [];


/*
|--------------------------------------------------------------------------
| Build Export
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| We do NOT assume inventory_id exists.
|
| We do NOT assume comments exists in another host table.
|
| We export whatever exists in grc_schedules.
|
|--------------------------------------------------------------------------
*/


$export_rows = [];


/*
|--------------------------------------------------------------------------
| Apply Filters
|--------------------------------------------------------------------------
*/

$where = [];
$params = [];

$project_filter = trim($_GET['project'] ?? '');
$support_filter = trim($_GET['support_level'] ?? '');
$status_filter = trim($_GET['status'] ?? '');
$search = trim($_GET['search'] ?? '');

if ($project_filter !== '') {
    $where[] = 'project = ?';
    $params[] = $project_filter;
}

if ($support_filter !== '') {
    $where[] = 'support_level = ?';
    $params[] = $support_filter;
}

if ($status_filter !== '') {
    $where[] = 'status = ?';
    $params[] = $status_filter;
}

if ($search !== '') {
    $where[] = "(project LIKE ? OR support_level LIKE ? OR change_request LIKE ?)";
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
    $params[] = '%' . $search . '%';
}

$where_sql = $where ? 'WHERE ' . implode(' AND ', $where) : '';


/*
|--------------------------------------------------------------------------
| Basic Schedule Query
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM grc_schedules
    $where_sql
    ORDER BY
        project ASC,
        support_level ASC
");

$stmt->execute($params);

$schedules =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| Inventory Lookup
|--------------------------------------------------------------------------
|
| If your SQLite grc_schedules has inventory_id,
| we enrich the export with inventory information.
|
*/

$inventory_by_id = [];


if (
    $inventory_exists &&
    in_array(
        'id',
        $inventory_columns,
        true
    )
) {

    $inventory_stmt =
        $pdo->query("
            SELECT *
            FROM inventory
        ");

    foreach (
        $inventory_stmt->fetchAll(
            PDO::FETCH_ASSOC
        )
        as $inventory
    ) {

        $inventory_by_id[
            (string) $inventory['id']
        ] = $inventory;
    }
}


/*
|--------------------------------------------------------------------------
| User Lookup
|--------------------------------------------------------------------------
*/

$users_by_id = [];


if (
    $users_exists &&
    in_array(
        'id',
        $user_columns,
        true
    )
) {

    $user_stmt =
        $pdo->query("
            SELECT *
            FROM users
        ");

    foreach (
        $user_stmt->fetchAll(
            PDO::FETCH_ASSOC
        )
        as $user
    ) {

        $users_by_id[
            (string) $user['id']
        ] = $user;
    }
}


/*
|--------------------------------------------------------------------------
| Export Columns
|--------------------------------------------------------------------------
*/

$headers = [

    'Hostname',

    'IP Address',

    'Application',

    'OS Family',

    'Current OS Version',

    'Current Kernel',

    'Project',

    'Support Level',

    'Recurrence Days',

    'Scheduled Time',

    'Patched Time',

    'Next Date',

    'Assignee',

    'Assignee Email',

    'Status',

    'New OS Version',

    'New Kernel Version',

    'Change Request',

    'Comments',

    'Attachment',

    'Created At',

    'Updated At'

];


/*
|--------------------------------------------------------------------------
| Build Rows
|--------------------------------------------------------------------------
*/

foreach ($schedules as $row) {


    /*
    |--------------------------------------------------------------------------
    | Inventory
    |--------------------------------------------------------------------------
    */

    $inventory = [];


    /*
    | New schema
    */

    if (
        isset($row['inventory_id']) &&
        isset(
            $inventory_by_id[
                (string) $row['inventory_id']
            ]
        )
    ) {

        $inventory =
            $inventory_by_id[
                (string) $row['inventory_id']
            ];
    }


    /*
    | Older schema may store hostname directly
    */

    $hostname =
        row_value(
            $row,
            'hostname'
        );


    if (
        $hostname === '' &&
        isset($inventory['hostname'])
    ) {

        $hostname =
            $inventory['hostname'];
    }


    $ip_address =
        row_value(
            $row,
            'ip_address'
        );


    if (
        $ip_address === '' &&
        isset($inventory['ip_address'])
    ) {

        $ip_address =
            $inventory['ip_address'];
    }


    $application =
        row_value(
            $row,
            'application'
        );


    if (
        $application === '' &&
        isset($inventory['application'])
    ) {

        $application =
            $inventory['application'];
    }


    $os_family =
        row_value(
            $row,
            'os_family'
        );


    if (
        $os_family === '' &&
        isset($inventory['os_family'])
    ) {

        $os_family =
            $inventory['os_family'];
    }


    $current_os =
        row_value(
            $row,
            'os_version'
        );


    if (
        $current_os === '' &&
        isset($inventory['os_version'])
    ) {

        $current_os =
            $inventory['os_version'];
    }


    $current_kernel =
        row_value(
            $row,
            'kernel_version'
        );


    if (
        $current_kernel === '' &&
        isset($inventory['kernel_version'])
    ) {

        $current_kernel =
            $inventory['kernel_version'];
    }


    /*
    |--------------------------------------------------------------------------
    | Assignee
    |--------------------------------------------------------------------------
    */

    $assignee = trim((string) ($row['assignee_name'] ?? ''));

    $assignee_email = '';


    if (
        $assignee === '' &&
        isset($row['assignee_id']) &&
        isset(
            $users_by_id[
                (string) $row['assignee_id']
            ]
        )
    ) {

        $user =
            $users_by_id[
                (string) $row['assignee_id']
            ];


        $assignee =
            trim(
                row_value(
                    $user,
                    'first_name'
                ) .
                ' ' .
                row_value(
                    $user,
                    'last_name'
                )
            );


        $assignee_email =
            row_value(
                $user,
                'email'
            );
    }


    /*
    |--------------------------------------------------------------------------
    | Direct assignee name fallback
    |--------------------------------------------------------------------------
    */

    if (
        $assignee === '' &&
        isset($row['assignee'])
    ) {

        $assignee =
            $row['assignee'];
    }


    /*
    |--------------------------------------------------------------------------
    | Attachment
    |--------------------------------------------------------------------------
    */

    $attachment =
        row_value(
            $row,
            'attachment_original_name'
        );


    /*
    |--------------------------------------------------------------------------
    | Add Export Row
    |--------------------------------------------------------------------------
    */

    $export_rows[] = [

        $hostname,

        $ip_address,

        $application,

        $os_family,

        $current_os,

        $current_kernel,

        row_value(
            $row,
            'project'
        ),

        row_value(
            $row,
            'support_level'
        ),

        row_value(
            $row,
            'recurrence_interval_days'
        ),

        row_value(
            $row,
            'scheduled_time'
        ),

        row_value(
            $row,
            'patched_time'
        ),

        row_value(
            $row,
            'next_date'
        ),

        $assignee,

        $assignee_email,

        row_value(
            $row,
            'status'
        ),

        row_value(
            $row,
            'new_os_version'
        ),

        row_value(
            $row,
            'new_kernel_version'
        ),

        row_value(
            $row,
            'change_request'
        ),

        row_value(
            $row,
            'comments'
        ),

        $attachment,

        row_value(
            $row,
            'created_at'
        ),

        row_value(
            $row,
            'updated_at'
        )

    ];
}


/*
|--------------------------------------------------------------------------
| CSV Headers
|--------------------------------------------------------------------------
*/

$filename =
    'grc_schedule_' .
    date('Y-m-d_H-i-s') .
    '.csv';


header(
    'Content-Type: text/csv; charset=utf-8'
);

header(
    'Content-Disposition: attachment; filename="' .
    $filename .
    '"'
);

header(
    'Pragma: no-cache'
);

header(
    'Expires: 0'
);


/*
|--------------------------------------------------------------------------
| Output CSV
|--------------------------------------------------------------------------
*/

$output =
    fopen(
        'php://output',
        'w'
    );


/*
|--------------------------------------------------------------------------
| UTF-8 BOM
|--------------------------------------------------------------------------
|
| Makes Excel display UTF-8 correctly.
|
*/

fprintf(
    $output,
    chr(0xEF) .
    chr(0xBB) .
    chr(0xBF)
);


/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

fputcsv(
    $output,
    $headers
);


/*
|--------------------------------------------------------------------------
| Data
|--------------------------------------------------------------------------
*/

foreach (
    $export_rows
    as $export_row
) {

    fputcsv(
        $output,
        $export_row
    );
}


fclose($output);

exit;
