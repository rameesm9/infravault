<?php
/**
 * Runs every schema module, in dependency order.
 *
 * Extracted from config/db.php so that db.php can skip the whole sequence
 * when the schema is already up to date. Measured on this codebase, running
 * it costs ~180 ms per request -- 196 CREATE TABLE/INDEX IF NOT EXISTS plus
 * 25 INSERT OR IGNORE statements, none of which does anything after the
 * first run. That was roughly 97% of the cost of serving a page.
 *
 * opcache does not help with it: opcache caches compiled PHP, and this cost
 * is statement execution against SQLite, not compilation. Measured
 * separately, tokenising all 35 files takes 4 ms and reading them 3 ms.
 *
 * Order matters where a module seeds into a table an earlier one creates
 * (for example license_warranty seeds into pages/permissions), so this is
 * kept in exactly the order db.php used before.
 */

function runAllSchemaModules(PDO $pdo): void
{
    require_once __DIR__ . '/schema/users.php';

    // Early, because every module below that registers a page key reads
    // `roles` to decide which roles to grant or deny. On a fresh database
    // that table used to be created only by permission.php, so those
    // registrations failed silently on a new installation.
    require_once __DIR__ . '/schema/roles.php';
    runRolesSchema($pdo);

    // Multiple roles per user (combined privileges). After roles.php and
    // users.php above, since it backfills from users.role.
    require_once __DIR__ . '/schema/user_roles.php';
    runUserRolesSchema($pdo);

    require_once __DIR__ . '/schema/communications.php';
    require_once __DIR__ . '/schema/ownership.php';
    require_once __DIR__ . '/schema/sops.php';
    require_once __DIR__ . '/schema/patch_exceptions.php';
    require_once __DIR__ . '/schema/audit.php';
    require_once __DIR__ . '/schema/assets.php';
    require_once __DIR__ . '/schema/inventory.php';
    require_once __DIR__ . '/schema/reminders.php';
    require_once __DIR__ . '/schema/builds.php';
    require_once __DIR__ . '/schema/handovers.php';
    require_once __DIR__ . '/schema/help.php';
    require_once __DIR__ . '/schema/ip.php';

    // Must run after both assets.php (asset.port_group) and ip.php
    // (ip_ranges) above.
    require_once __DIR__ . '/schema/asset_port_group_backfill.php';
    runAssetPortGroupBackfill($pdo);

    // Team-scoped visibility for handovers. After handovers.php above,
    // whose table it alters.
    require_once __DIR__ . '/schema/handover_visibility.php';
    runHandoverVisibilitySchema($pdo);

    require_once __DIR__ . '/schema/decommission.php';
    require_once __DIR__ . '/schema/knowledge_base.php';
    require_once __DIR__ . '/schema/mydata.php';
    require_once __DIR__ . '/schema/known_issues.php';
    require_once __DIR__ . '/schema/hostname.php';
    require_once __DIR__ . '/schema/compliance.php';
    require_once __DIR__ . '/schema/permissions.php';
    require_once __DIR__ . '/schema/license_warranty.php';
    require_once __DIR__ . '/schema/diagrams.php';

    require_once __DIR__ . '/schema/team-permissions-migration.php';
    runTeamPermissionsMigration($pdo);

    require_once __DIR__ . '/schema/kb_visibility_migration.php';
    runKbVisibilityMigration($pdo);

    // The shared Word-export header/footer template for SOPs. After
    // team-permissions-migration.php above, which defines columnExists().
    require_once __DIR__ . '/schema/sop_document.php';
    runSopDocumentSchema($pdo);

    require_once __DIR__ . '/schema/mail_settings.php';
    runMailSettingsSchema($pdo);

    require_once __DIR__ . '/schema/reminder_mail.php';
    runReminderMailSchema($pdo);

    // Self-service password reset. After mail_settings.php above, whose
    // mail_module_toggles table it seeds its own row into.
    require_once __DIR__ . '/schema/password_reset.php';
    runPasswordResetSchema($pdo);

    require_once __DIR__ . '/schema/ldap_settings.php';
    runLdapSettingsSchema($pdo);

    require_once __DIR__ . '/schema/patch_exception_audit.php';
    runPatchExceptionAuditSchema($pdo);

    require_once __DIR__ . '/schema/security_settings.php';
    runSecuritySchema($pdo);

    // Application name + logo shown in the header, sidebar, auth pages and
    // the AI assistant widget. No dependency on any module above.
    require_once __DIR__ . '/schema/branding.php';
    runBrandingSchema($pdo);

    // Major Layouts: container platform, Oracle estate, DR mapping,
    // application layouts. Runs after permissions/roles exist, because it
    // registers its own two new page keys.
    require_once __DIR__ . '/schema/platform.php';
    runPlatformSchema($pdo);

    require_once __DIR__ . '/schema/uid_gid.php';
    runUidGidSchema($pdo);

    // Utilities: ticket tracking, the credential vault and quick links.
    // Registers its own page keys, so it runs after permissions/roles exist.
    require_once __DIR__ . '/schema/utilities.php';
    runUtilitiesSchema($pdo);

    // Special Projects: tracked infrastructure programmes. Registers its own
    // page key, so it runs after permissions/roles exist.
    require_once __DIR__ . '/schema/projects.php';
    runProjectsSchema($pdo);

    // Team registry. Must run after users.php above, because it backfills
    // itself from the team names already present on users.team.
    require_once __DIR__ . '/schema/teams.php';
    runTeamsSchema($pdo);

    // Team Workspace: the on-call rota and the leave register. After
    // teams.php, whose registry backs their "share with teams" pickers,
    // and after permissions/roles, since it registers two page keys.
    require_once __DIR__ . '/schema/workspace.php';
    runWorkspaceSchema($pdo);

    // Org & Escalation Charts. Registers its own page key, so it runs
    // after permissions/roles exist.
    require_once __DIR__ . '/schema/org_charts.php';
    runOrgChartsSchema($pdo);

    // Presentation & Document Designer. Registers its page key (no
    // permission dependency of its own beyond permissions/roles existing).
    require_once __DIR__ . '/schema/presentation_designer.php';
    runPresentationDesignerSchema($pdo);

    // Saved decks for the designer above -- the one piece of server-side
    // storage it has, added when "save permanently" was requested.
    require_once __DIR__ . '/schema/presentation_designer_decks.php';
    runPresentationDesignerDecksSchema($pdo);

    // Per-user dashboard spotlight customization (reorder/dismiss cards
    // in home.php's "For You" panel). No dependency on any module above.
    require_once __DIR__ . '/schema/dashboard_spotlight_prefs.php';
    runDashboardSpotlightPrefsSchema($pdo);

    // Per-user dashboard panel layout (drag-and-drop tile order on
    // home.php, e.g. Asset Growth / Asset Types / the breakdown panels).
    // No dependency on any module above.
    require_once __DIR__ . '/schema/dashboard_panel_prefs.php';
    runDashboardPanelPrefsSchema($pdo);

    // Per-user page bookmarks (header star dropdown). No dependency on
    // any module above -- page_key is just a string, checked against the
    // permissions table at read time, not a foreign key.
    require_once __DIR__ . '/schema/bookmarks.php';
    runBookmarksSchema($pdo);

    // Per-user read-tracking for the header notification bell (team
    // notes + reminders). No dependency on any module above.
    require_once __DIR__ . '/schema/notification_reads.php';
    runNotificationReadsSchema($pdo);

    // VA Assessment: multi-file CSV combiner, separate from the
    // vulnerabilities.php per-report tracking module. Registers its own
    // page key, so it runs after permissions/roles exist.
    require_once __DIR__ . '/schema/va_assessment.php';
    runVaAssessmentSchema($pdo);
}


/**
 * Fingerprints the schema sources, so a change to any of them re-runs the
 * bootstrap automatically.
 *
 * Name + mtime + size rather than file contents: hashing the contents would
 * mean reading 35 files on every request, which is the cost being avoided.
 * Stat alone is ~0.7 ms. An editor that rewrites a file always moves its
 * mtime, and a container image bakes fixed mtimes, so both the development
 * and deployment cases re-run exactly once when they should.
 */
function schemaSignature(): string
{
    $files = glob(__DIR__ . '/schema/*.php') ?: [];
    sort($files);

    $sig = '';
    foreach ($files as $f) {
        $sig .= basename($f) . ':' . filemtime($f) . ':' . filesize($f) . "\n";
    }

    return md5($sig);
}
