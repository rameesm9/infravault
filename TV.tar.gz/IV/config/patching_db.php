<?php

/*
|--------------------------------------------------------------------------
| Patching Schedule Database
|--------------------------------------------------------------------------
|
| Uses the application's existing SQLite connection from config/db.php.
|
| Features:
|
| - Patch schedule management
| - Project + Support Level assignment
| - Optional Application
| - Per-server selection
| - Per-server assignee
| - Existing installation migration
|
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/db.php';


/*
|--------------------------------------------------------------------------
| Validate PDO
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {

    throw new RuntimeException(
        'Database connection $pdo is not available from config/db.php.'
    );
}


$pdo->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);


/*
|--------------------------------------------------------------------------
| Enable foreign keys
|--------------------------------------------------------------------------
*/

$pdo->exec(
    'PRAGMA foreign_keys = ON'
);


/*
|--------------------------------------------------------------------------
| Main patch schedule table
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_schedules (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        year INTEGER NOT NULL,

        quarter INTEGER NOT NULL,

        project TEXT NOT NULL,

        application TEXT NOT NULL DEFAULT '',

        support_level TEXT DEFAULT '',

        assigned_to INTEGER,

        cr TEXT DEFAULT '',

        status TEXT NOT NULL DEFAULT 'Assigned',

        scheduled_date DATE,

        notes TEXT DEFAULT '',

        reminder_sent_at DATETIME,

        created_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (assigned_to)
            REFERENCES users(id)
            ON DELETE SET NULL,

        FOREIGN KEY (created_by)
            REFERENCES users(id)
            ON DELETE SET NULL
    )
");


/*
|--------------------------------------------------------------------------
| Per-server patch tracking table
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_schedule_servers (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        schedule_id INTEGER NOT NULL,

        hostname TEXT NOT NULL,

        selected INTEGER NOT NULL DEFAULT 0,

        assigned_to INTEGER,

        patch_date DATE,

        status TEXT DEFAULT '',

        comment TEXT DEFAULT '',

        cr TEXT DEFAULT '',

        -- Quarterly patch tracking fields.
        --
        -- These are the per-host values the hostname-level CSV round trip
        -- reads and writes. Everything the patching module can derive from
        -- inventory or license_warranty is deliberately NOT stored here --
        -- it is looked up live at export time so this table can never hold
        -- a stale copy of inventory master data.
        --
        -- last_kernel_patch is the exception, and is meant to be stale: it
        -- is a frozen snapshot of inventory.kernel_version taken when the
        -- host first enters a quarter, so the kernel version from before
        -- that quarter patch survives inventory being updated afterwards.
        -- Nothing may overwrite it once set.

        -- new_os_version / new_kernel_version are what the host was moved
        -- TO by this quarter patch. They are promoted into inventory as the
        -- current values once the row is marked Completed; until then
        -- inventory still reflects the pre-patch state.

        new_os_version TEXT DEFAULT '',

        new_kernel_version TEXT DEFAULT '',

        applied_patch TEXT DEFAULT '',

        applied_patch_release_date TEXT,

        patch_level TEXT DEFAULT '',

        latest_available_patch TEXT DEFAULT '',

        last_kernel_patch TEXT DEFAULT '',

        kernel_patch_n_level TEXT DEFAULT '',

        downtime_required TEXT DEFAULT '',

        updated_by INTEGER,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (schedule_id)
            REFERENCES patch_schedules(id)
            ON DELETE CASCADE,

        FOREIGN KEY (assigned_to)
            REFERENCES users(id)
            ON DELETE SET NULL,

        FOREIGN KEY (updated_by)
            REFERENCES users(id)
            ON DELETE SET NULL,

        UNIQUE(schedule_id, hostname)
    )
");


/*
|--------------------------------------------------------------------------
| Check existing patch_schedule_servers columns
|--------------------------------------------------------------------------
*/

$columns = [];

$columnStmt = $pdo->query(
    'PRAGMA table_info(patch_schedule_servers)'
);

foreach (
    $columnStmt->fetchAll(PDO::FETCH_ASSOC)
    as $column
) {

    if (
        isset($column['name']) &&
        $column['name'] !== ''
    ) {

        $columns[$column['name']] = true;
    }
}


/*
|--------------------------------------------------------------------------
| Add selected column if missing
|--------------------------------------------------------------------------
*/

if (!isset($columns['selected'])) {

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN selected INTEGER NOT NULL DEFAULT 0
    ");


    /*
    | Existing rows were already part of an assignment,
    | so mark them selected.
    */

    $pdo->exec("
        UPDATE patch_schedule_servers
        SET selected = 1
        WHERE selected = 0
    ");
}


/*
|--------------------------------------------------------------------------
| Add assigned_to column if missing
|--------------------------------------------------------------------------
*/

if (!isset($columns['assigned_to'])) {

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN assigned_to INTEGER
        REFERENCES users(id)
        ON DELETE SET NULL
    ");
}


/*
|--------------------------------------------------------------------------
| Add quarterly patch tracking columns if missing
|--------------------------------------------------------------------------
|
| CREATE TABLE IF NOT EXISTS above is a no-op once the table exists, so
| columns added after a deployment went live have to be ALTERed in here
| as well. Add new columns in BOTH places.
|
*/

$patchTrackingColumns = [
    'new_os_version'             => "TEXT DEFAULT ''",
    'new_kernel_version'         => "TEXT DEFAULT ''",
    'applied_patch'              => "TEXT DEFAULT ''",
    'applied_patch_release_date' => 'TEXT',
    'patch_level'                => "TEXT DEFAULT ''",
    'latest_available_patch'     => "TEXT DEFAULT ''",
    'last_kernel_patch'          => "TEXT DEFAULT ''",
    'kernel_patch_n_level'       => "TEXT DEFAULT ''",
    'downtime_required'          => "TEXT DEFAULT ''",
];

foreach ($patchTrackingColumns as $trackingColumn => $trackingType) {

    if (isset($columns[$trackingColumn])) {
        continue;
    }

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN {$trackingColumn} {$trackingType}
    ");
}


/*
|--------------------------------------------------------------------------
| Backfill last_kernel_patch for rows that predate the column
|--------------------------------------------------------------------------
|
| A snapshot taken now is not the true "kernel before this quarter's
| patch" for a host that was already patched, but it is far better than
| a permanently blank column: the value is frozen from here on, so every
| future quarter records a correct one. Only rows with no snapshot are
| touched, so this cannot overwrite a real one on a later run.
|
*/

if (!isset($columns['last_kernel_patch'])) {

    $pdo->exec("
        UPDATE patch_schedule_servers
        SET last_kernel_patch = COALESCE(
            (
                SELECT i.kernel_version
                FROM inventory i
                WHERE i.hostname = patch_schedule_servers.hostname
            ),
            ''
        )
        WHERE last_kernel_patch IS NULL OR last_kernel_patch = ''
    ");
}


/*
|--------------------------------------------------------------------------
| Make sure patch_schedules.application exists
|--------------------------------------------------------------------------
*/

$scheduleColumns = [];

$scheduleColumnStmt = $pdo->query(
    'PRAGMA table_info(patch_schedules)'
);

foreach (
    $scheduleColumnStmt->fetchAll(PDO::FETCH_ASSOC)
    as $column
) {

    if (
        isset($column['name']) &&
        $column['name'] !== ''
    ) {

        $scheduleColumns[$column['name']] = true;
    }
}


/*
|--------------------------------------------------------------------------
| Existing database migration:
|
| Add application if it doesn't exist.
|--------------------------------------------------------------------------
*/

if (!isset($scheduleColumns['application'])) {

    $pdo->exec("
        ALTER TABLE patch_schedules
        ADD COLUMN application TEXT NOT NULL DEFAULT ''
    ");
}


/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_year_quarter
    ON patch_schedules(year, quarter)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_assigned
    ON patch_schedules(assigned_to)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_project
    ON patch_schedules(project, application)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_reminder
    ON patch_schedules(
        scheduled_date,
        reminder_sent_at
    )
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_schedule
    ON patch_schedule_servers(schedule_id)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_assigned
    ON patch_schedule_servers(assigned_to)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_selected
    ON patch_schedule_servers(
        schedule_id,
        selected
    )
");


/*
|--------------------------------------------------------------------------
| Permanent assignee-name snapshots
|--------------------------------------------------------------------------
|
| assigned_to_name is a snapshot of the assignee's display name, stamped
| automatically by triggers below whenever assigned_to is set or changed --
| not maintained by application code, so no INSERT/UPDATE call site (and
| there are many across patching.php/patch_planning.php/patch_servers.php)
| can forget to populate it. This is what keeps "who was assigned" readable
| in both current records and history even after that portal user is
| reassigned elsewhere or deleted from users entirely.
|--------------------------------------------------------------------------
*/

if (!isset($scheduleColumns['assigned_to_name'])) {
    $pdo->exec("ALTER TABLE patch_schedules ADD COLUMN assigned_to_name TEXT");
}

if (!isset($columns['assigned_to_name'])) {
    $pdo->exec("ALTER TABLE patch_schedule_servers ADD COLUMN assigned_to_name TEXT");
}

$patchAssigneeNameExpr = "
    (SELECT TRIM(u.first_name || ' ' || u.last_name) ||
            CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
     FROM users u WHERE u.id = NEW.assigned_to)
";

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_patch_schedules_assignee_name_ins
    AFTER INSERT ON patch_schedules
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE patch_schedules SET assigned_to_name = $patchAssigneeNameExpr WHERE id = NEW.id;
    END
");

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_patch_schedules_assignee_name_upd
    AFTER UPDATE OF assigned_to ON patch_schedules
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE patch_schedules SET assigned_to_name = $patchAssigneeNameExpr WHERE id = NEW.id;
    END
");

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_patch_schedule_servers_assignee_name_ins
    AFTER INSERT ON patch_schedule_servers
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE patch_schedule_servers SET assigned_to_name = $patchAssigneeNameExpr WHERE id = NEW.id;
    END
");

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_patch_schedule_servers_assignee_name_upd
    AFTER UPDATE OF assigned_to ON patch_schedule_servers
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE patch_schedule_servers SET assigned_to_name = $patchAssigneeNameExpr WHERE id = NEW.id;
    END
");

// One-time backfill for rows that predate these triggers/columns.
$pdo->exec("
    UPDATE patch_schedules
    SET assigned_to_name = (
        SELECT TRIM(u.first_name || ' ' || u.last_name) ||
               CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
        FROM users u WHERE u.id = patch_schedules.assigned_to
    )
    WHERE assigned_to IS NOT NULL AND (assigned_to_name IS NULL OR TRIM(assigned_to_name) = '')
");

$pdo->exec("
    UPDATE patch_schedule_servers
    SET assigned_to_name = (
        SELECT TRIM(u.first_name || ' ' || u.last_name) ||
               CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
        FROM users u WHERE u.id = patch_schedule_servers.assigned_to
    )
    WHERE assigned_to IS NOT NULL AND (assigned_to_name IS NULL OR TRIM(assigned_to_name) = '')
");

/*
|--------------------------------------------------------------------------
| One-time backfill: resolve raw user ids in existing audit-history text
|--------------------------------------------------------------------------
|
| Before assigned_to_name existed, the update-diff logged in
| patch_schedule_history.details showed the raw id, e.g.
| 'Assigned To (User ID): "5" -> "7"'. This rewrites every such line to the
| resolved name where the id still exists in `users` (an id belonging to an
| already-deleted user is left as-is -- it cannot be recovered). Guarded by
| a marker table so it only ever runs once.
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_history_assignee_backfill_marker (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        done_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

$patchHistoryAssigneeBackfilled = (bool) $pdo->query(
    "SELECT COUNT(*) FROM patch_history_assignee_backfill_marker"
)->fetchColumn();

if (!$patchHistoryAssigneeBackfilled) {

    $histRows = $pdo->query("
        SELECT id, details FROM patch_schedule_history
        WHERE details LIKE '%Assigned To (User ID):%'
    ")->fetchAll(PDO::FETCH_ASSOC);

    $updateHistDetails = $pdo->prepare(
        "UPDATE patch_schedule_history SET details = ? WHERE id = ?"
    );

    foreach ($histRows as $histRow) {

        $newDetails = preg_replace_callback(
            '/Assigned To \(User ID\): "([^"]*)" -> "([^"]*)"/',
            function (array $m) use ($pdo): string {
                $resolve = static function (string $raw) use ($pdo): string {
                    if ($raw === '' || $raw === '(empty)' || !ctype_digit($raw)) {
                        return $raw;
                    }
                    $name = patchingResolveAssigneeName($pdo, (int) $raw);
                    return $name ?? $raw;
                };
                return 'Assigned To: "' . $resolve($m[1]) . '" -> "' . $resolve($m[2]) . '"';
            },
            (string) $histRow['details']
        );

        if ($newDetails !== $histRow['details']) {
            $updateHistDetails->execute([$newDetails, $histRow['id']]);
        }
    }

    $pdo->exec("INSERT INTO patch_history_assignee_backfill_marker (id) VALUES (1)");
}


/*
|--------------------------------------------------------------------------
| Done
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| SHARED PATCHING HELPERS
|--------------------------------------------------------------------------
|
| These live here rather than in patching.php because patch_servers.php
| and patch_export.php need them too, and neither can include the
| patching page without running it. They all require this one already.
*/

function logPatchHistory(PDO $pdo, ?int $scheduleId, string $actionType, string $performedBy, string $details): void
{
    try {
        $stmt = $pdo->prepare("INSERT INTO patch_schedule_history (schedule_id, action_type, performed_by, details) VALUES (?, ?, ?, ?)");
        $stmt->execute([$scheduleId, $actionType, $performedBy, $details]);
    } catch (Throwable $e) {
        error_log('Unable to log patch schedule history: ' . $e->getMessage());
    }
}

// Resolves an assignee's permanent display label ("First Last (NCGR)"),
// matching what the assigned_to_name trigger stamps onto patch_schedules /
// patch_schedule_servers. Used for audit-diff text, which needs the name
// at the moment of the change rather than a raw id.
function patchingResolveAssigneeName(PDO $pdo, ?int $userId): ?string
{
    if (!$userId) {
        return null;
    }
    $stmt = $pdo->prepare("SELECT first_name, last_name, ncgr_id FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$u) {
        return null;
    }
    $name = trim(trim((string) $u['first_name']) . ' ' . trim((string) $u['last_name']));
    $ncgr = trim((string) ($u['ncgr_id'] ?? ''));
    return $ncgr !== '' ? "$name ($ncgr)" : $name;
}

function patchingCsvHeaders(int $quarter, array $quarterRanges): array
{
    $range = $quarterRanges[$quarter] ?? '';

    return [
        'Hostname',
        'IP',
        'Project',
        'Criticality',
        'Support Group',
        'Environment',
        'Technical Owner',
        'Application Owner',
        'OS Type',
        'OS Version',
        'Applied Patch',
        'Applied Patch Release Date',
        'Patch Level (N, N-1, N-2)',
        'Product Release Premier Support End Date',
        'Latest Available Patch Details (N)',
        'Last Kernel Patch',
        'Applied Kernel Patch',
        'Kernel Patch N Level',
        'Patch Planned Time Q' . $quarter . ($range !== '' ? ' (' . $range . ')' : ''),
        'Q' . $quarter . ' Change Number',
        'Q' . $quarter . ' Status',
        'Downtime Required',
        'Note',
        'Last Update',
        'Assignee',
    ];
}

/*
| Product support end date, sourced from license_warranty.
|
| Keyed on a squashed product name + version so "Red Hat Enterprise Linux"
| / "RHEL 8.6" style spelling differences between the two modules do not
| silently produce a blank column. Two fallbacks are kept, each narrower
| than a wildcard match:
|
|   name + major version  -- license_warranty tracks "8", inventory "8.6"
|   name only             -- a licence row that covers every version
*/
function patchingSupportEndDates(PDO $pdo): array
{
    $map = [];

    try {
        $rows = $pdo->query("
            SELECT product_name, product_version, support_expiry_date
            FROM license_warranty
            WHERE support_expiry_date IS NOT NULL
              AND TRIM(support_expiry_date) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('Unable to read license_warranty support dates: ' . $e->getMessage());
        return [];
    }

    $squash = function ($value) {
        return preg_replace('/[^a-z0-9.]+/', '', strtolower(trim((string) $value)));
    };

    foreach ($rows as $row) {
        $name = $squash($row['product_name'] ?? '');

        if ($name === '') {
            continue;
        }

        $version = $squash($row['product_version'] ?? '');
        $expiry = trim((string) $row['support_expiry_date']);

        /*
         * First writer wins rather than last, so a specific row is not
         * clobbered by a later duplicate entry for the same product.
         */
        foreach ([$name . '|' . $version, $name . '|'] as $key) {
            if (!isset($map[$key])) {
                $map[$key] = $expiry;
            }
        }
    }

    return $map;
}

function patchingLookupSupportEndDate(array $map, ?string $osType, ?string $osVersion): string
{
    $squash = function ($value) {
        return preg_replace('/[^a-z0-9.]+/', '', strtolower(trim((string) $value)));
    };

    $name = $squash($osType);

    if ($name === '') {
        return '';
    }

    $version = $squash($osVersion);
    $major = strpos($version, '.') !== false
        ? substr($version, 0, strpos($version, '.'))
        : $version;

    foreach ([$version, $major, ''] as $candidate) {
        if (isset($map[$name . '|' . $candidate])) {
            return $map[$name . '|' . $candidate];
        }
    }

    return '';
}


/*
| Server statuses that count as "no longer being worked on" for the
| purpose of the assignment-level Status. patch_schedules.status is never
| set by hand (see patching.php) -- it is always derived from where the
| assignment's own selected servers currently stand.
*/
function patchingCompleteServerStatuses(): array
{
    return ['Completed', 'N/A', 'EOL', 'Excluded', 'Decommissioned', 'To Be Decom'];
}

/*
| Recomputes and persists patch_schedules.status for one assignment from
| the status of its selected (selected = 1) servers:
|
|   every selected server complete-like (Completed / N/A / EOL /
|   Excluded / Decommissioned / To Be Decom, in any combination) -> Completed
|
|   a mix of complete-like and still-pending (blank/Pending, Planned,
|   In Progress, Rescheduled)                                     -> Partial
|
|   every selected server still pending                           -> In Progress
|
|   no selected servers at all                                    -> Assigned
|
| Returns [oldStatus, newStatus, changed] so callers can decide whether to
| log the change; the row is updated only when the status actually moves.
*/
function patchingRecomputeScheduleStatus(PDO $pdo, int $scheduleId): array
{
    $completeSet = patchingCompleteServerStatuses();

    $stmt = $pdo->prepare("
        SELECT status FROM patch_schedule_servers
        WHERE schedule_id = ? AND selected = 1
    ");
    $stmt->execute([$scheduleId]);
    $serverStatuses = $stmt->fetchAll(PDO::FETCH_COLUMN);

    $hasComplete = false;
    $hasPending = false;

    foreach ($serverStatuses as $serverStatus) {
        if (in_array(trim((string) $serverStatus), $completeSet, true)) {
            $hasComplete = true;
        } else {
            $hasPending = true;
        }
    }

    if ($hasComplete && $hasPending) {
        $newStatus = 'Partial';
    } elseif ($hasComplete) {
        $newStatus = 'Completed';
    } elseif ($hasPending) {
        $newStatus = 'In Progress';
    } else {
        $newStatus = 'Assigned';
    }

    $oldStmt = $pdo->prepare('SELECT status FROM patch_schedules WHERE id = ?');
    $oldStmt->execute([$scheduleId]);
    $oldStatus = (string) ($oldStmt->fetchColumn() ?: '');

    if ($oldStatus !== $newStatus) {
        $pdo->prepare('UPDATE patch_schedules SET status = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
            ->execute([$newStatus, $scheduleId]);
    }

    return [$oldStatus, $newStatus, $oldStatus !== $newStatus];
}


/*
|--------------------------------------------------------------------------
| Done
|--------------------------------------------------------------------------
*/

return true;
