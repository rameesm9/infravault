<?php
/**
 * Major Layouts: container platform, Oracle estate, DR mapping and
 * application layouts.
 *
 * Servers are referenced by hostname rather than by an inventory id, the
 * same convention patch_schedule_servers already uses: hostname is what
 * people type, search and paste from a CMDB export, and it survives an
 * inventory row being re-imported. Joins back to `inventory` are done on
 * hostname where richer detail (OS, IP, owner) is needed.
 */

function runPlatformSchema(PDO $pdo): void
{
    /*
    |--------------------------------------------------------------------------
    | CONTAINER PLATFORM
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS container_clusters (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            cluster_name TEXT NOT NULL,
            platform TEXT NOT NULL DEFAULT 'OpenShift',
            distribution_version TEXT,
            kubernetes_version TEXT,

            environment TEXT,
            project TEXT,
            location TEXT,
            support_level TEXT,
            managed_by TEXT,

            api_endpoint TEXT,
            console_url TEXT,
            ingress_domain TEXT,

            master_count INTEGER NOT NULL DEFAULT 0,
            infra_count INTEGER NOT NULL DEFAULT 0,
            worker_count INTEGER NOT NULL DEFAULT 0,

            total_cpu_cores INTEGER NOT NULL DEFAULT 0,
            total_memory_gb INTEGER NOT NULL DEFAULT 0,
            total_storage_tb REAL NOT NULL DEFAULT 0,

            network_plugin TEXT,
            storage_backend TEXT,
            registry_type TEXT,

            subscription_type TEXT,
            subscription_expiry DATE,

            technical_owner TEXT,
            technical_owner_email TEXT,

            status TEXT NOT NULL DEFAULT 'Active',
            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    // Named nodes belonging to a cluster.
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS container_nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            cluster_id INTEGER NOT NULL,
            hostname TEXT NOT NULL,
            node_role TEXT NOT NULL DEFAULT 'worker',
            cpu_cores INTEGER NOT NULL DEFAULT 0,
            memory_gb INTEGER NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'Ready',
            notes TEXT,
            UNIQUE(cluster_id, hostname),
            FOREIGN KEY (cluster_id) REFERENCES container_clusters(id) ON DELETE CASCADE
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | ORACLE DATABASES
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS oracle_databases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            db_name TEXT NOT NULL,
            db_unique_name TEXT,
            oracle_sid TEXT,

            deployment_type TEXT NOT NULL DEFAULT 'Standalone',
            oracle_version TEXT,
            edition TEXT,
            patch_level TEXT,

            environment TEXT,
            project TEXT,
            application TEXT,
            support_level TEXT,
            managed_by TEXT,

            cluster_name TEXT,
            scan_name TEXT,
            scan_ips TEXT,
            listener_port TEXT,

            storage_type TEXT,
            asm_diskgroups TEXT,
            size_gb REAL NOT NULL DEFAULT 0,
            character_set TEXT,

            archivelog_mode TEXT,
            dataguard_role TEXT,
            dataguard_peer TEXT,

            backup_tool TEXT,
            backup_schedule TEXT,
            last_backup_date DATE,

            technical_owner TEXT,
            technical_owner_email TEXT,
            dba_owner TEXT,

            status TEXT NOT NULL DEFAULT 'Active',
            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    // RAC nodes / Data Guard members. A standalone database simply has one.
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS oracle_db_nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            db_id INTEGER NOT NULL,
            hostname TEXT NOT NULL,
            instance_name TEXT,
            node_role TEXT NOT NULL DEFAULT 'Node',
            vip_address TEXT,
            status TEXT NOT NULL DEFAULT 'Up',
            notes TEXT,
            UNIQUE(db_id, hostname),
            FOREIGN KEY (db_id) REFERENCES oracle_databases(id) ON DELETE CASCADE
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | PRODUCTION / DR MAPPING
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS dr_mappings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            application TEXT NOT NULL,
            project TEXT,
            component_type TEXT,
            criticality TEXT,

            prod_site TEXT,
            dr_site TEXT,

            prod_hostname TEXT,
            dr_hostname TEXT,

            replication_type TEXT,
            replication_status TEXT,
            failover_type TEXT,

            rpo_minutes INTEGER,
            rto_minutes INTEGER,

            last_dr_test DATE,
            dr_test_result TEXT,
            next_dr_test DATE,

            runbook_link TEXT,

            technical_owner TEXT,
            technical_owner_email TEXT,

            status TEXT NOT NULL DEFAULT 'Active',
            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | APPLICATION LAYOUT
    |--------------------------------------------------------------------------
    |
    | Three levels: a layout has ordered tiers, a tier has components, a
    | component has servers. Stored relationally rather than as a saved
    | picture, so the same data can be listed, exported and reported on --
    | and so a server appearing here can be joined back to inventory
    | instead of being a label that silently goes stale.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_layouts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app_name TEXT NOT NULL,
            project TEXT,
            environment TEXT,
            description TEXT,
            technical_owner TEXT,
            status TEXT NOT NULL DEFAULT 'Active',
            deployment_type TEXT,
            deployment_detail TEXT,
            location TEXT,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    /* Added after the initial release -- existing databases need the
       columns added on, CREATE TABLE IF NOT EXISTS above only applies to
       a brand-new install. */
    try {
        $appLayoutColumns = [];
        foreach ($pdo->query('PRAGMA table_info(app_layouts)')->fetchAll(PDO::FETCH_ASSOC) as $col) {
            $appLayoutColumns[] = $col['name'];
        }
        foreach (['deployment_type', 'deployment_detail', 'location'] as $col) {
            if (!in_array($col, $appLayoutColumns, true)) {
                $pdo->exec("ALTER TABLE app_layouts ADD COLUMN $col TEXT");
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to migrate app_layouts columns: ' . $e->getMessage());
    }

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_layout_tiers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            layout_id INTEGER NOT NULL,
            tier_name TEXT NOT NULL,
            tier_type TEXT,
            tier_order INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (layout_id) REFERENCES app_layouts(id) ON DELETE CASCADE
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_layout_components (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            tier_id INTEGER NOT NULL,
            component_name TEXT NOT NULL,
            component_type TEXT,
            technology TEXT,
            port TEXT,
            notes TEXT,
            component_order INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (tier_id) REFERENCES app_layout_tiers(id) ON DELETE CASCADE
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS app_layout_servers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            component_id INTEGER NOT NULL,
            hostname TEXT NOT NULL,
            server_role TEXT,
            UNIQUE(component_id, hostname),
            FOREIGN KEY (component_id) REFERENCES app_layout_components(id) ON DELETE CASCADE
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | AUDIT HISTORY
    |--------------------------------------------------------------------------
    |
    | One shared table with a module column, rather than four near-identical
    | ones. The per-module *_history tables elsewhere in this app were
    | written before that pattern settled; there is no reason to add four
    | more copies of it.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS platform_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module TEXT NOT NULL,
            record_id INTEGER,
            action_type TEXT,
            performed_by TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_platform_history ON platform_history(module, record_id, timestamp)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_container_nodes ON container_nodes(cluster_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oracle_nodes ON oracle_db_nodes(db_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_dr_app ON dr_mappings(application)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_layout_tiers ON app_layout_tiers(layout_id, tier_order)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_layout_components ON app_layout_components(tier_id, component_order)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_layout_servers ON app_layout_servers(component_id)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    |
    | Two of these page keys are new. Registering them here means the
    | Manage Permissions screen lists them, and -- because authzCan()
    | denies any key with no row -- that every role starts denied rather
    | than the gate failing open.
    |
    | Admin is granted all six verbs so the new pages are reachable
    | immediately; every other role gets an explicit all-zero row.
    */

    $newPages = [
        'oracle_db'         => 'Oracle Databases',
        'dr_mapping'        => 'Production / DR Mapping',
        'project_overview'  => 'Project Overview',
    ];

    try {
        $registerPage = $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)");

        foreach ($newPages as $key => $name) {
            $registerPage->execute([$key, $name]);
        }

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 1, 1, 1, 1, 1, 1)
        ");

        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 0, 0, 0, 0, 0, 0)
        ");

        foreach (array_keys($newPages) as $key) {
            foreach ($roles as $role) {
                if (strtolower(trim((string) $role)) === 'admin') {
                    $grantAll->execute([$role, $key]);
                } else {
                    $denyAll->execute([$role, $key]);
                }
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register Major Layouts page permissions: ' . $e->getMessage());
    }
}
