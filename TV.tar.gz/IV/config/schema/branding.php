<?php
/**
 * Application branding: the display name and logo shown across the header,
 * sidebar, login/signup/reset pages and the AI assistant widget.
 *
 * Stored in the database (like mail_settings/security_settings) so it is
 * editable from the Settings UI at runtime and persists via whatever volume
 * config/infravault.db is mounted on, without an image rebuild.
 */

function runBrandingSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS branding_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            app_name TEXT NOT NULL DEFAULT 'InfraVault',
            logo_path TEXT NOT NULL DEFAULT '',
            updated_by TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Singleton row -- the settings form always edits id=1.
    $pdo->exec("INSERT OR IGNORE INTO branding_settings (id) VALUES (1)");
}
