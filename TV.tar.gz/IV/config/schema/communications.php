<?php

// ============================================================
// COMMUNICATIONS (Team Notes / Handover Board -- notification.php)
// ============================================================
//
// notification.php adds category/expiry_date/updated_at/etc. via
// its own runtime ALTER TABLE migration on every load, so only the
// original base columns need to be created here.
//

$pdo->exec("
    CREATE TABLE IF NOT EXISTS communications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        title TEXT NOT NULL,

        message TEXT NOT NULL,

        note_type TEXT DEFAULT 'Announcement',

        assigned_to INTEGER,

        priority TEXT DEFAULT 'Normal',

        status TEXT DEFAULT 'Pending',

        target_date TEXT,

        completion_date TEXT,

        created_by INTEGER NOT NULL,

        visibility TEXT DEFAULT 'public',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOT FOR assigned_to
// ------------------------------------------------------------
// assigned_to_name is stamped automatically by triggers whenever
// assigned_to is set or changed, so the assignee stays readable in the
// Team Notes / Handover Board even after that portal user is reassigned
// elsewhere or deleted from users entirely.
// ============================================================

try {
    $pdo->exec("ALTER TABLE communications ADD COLUMN assigned_to_name TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

$commUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_communications_assigned_to_name_ins
    AFTER INSERT ON communications
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE communications SET assigned_to_name = {$commUserNameExpr('NEW.assigned_to')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_communications_assigned_to_name_upd
    AFTER UPDATE OF assigned_to ON communications
    FOR EACH ROW WHEN NEW.assigned_to IS NOT NULL
    BEGIN
        UPDATE communications SET assigned_to_name = {$commUserNameExpr('NEW.assigned_to')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    UPDATE communications
    SET assigned_to_name = {$commUserNameExpr('communications.assigned_to')}
    WHERE assigned_to IS NOT NULL AND (assigned_to_name IS NULL OR TRIM(assigned_to_name) = '')
");

// Migrate existing records to have visibility column if not present
try {
    $pdo->exec("ALTER TABLE communications ADD COLUMN visibility TEXT DEFAULT 'public'");
} catch (Exception $e) {
    // Column already exists, ignore
}


// ============================================================
// COMMUNICATION TEAM SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS communication_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        communication_id INTEGER NOT NULL,
        team_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(communication_id) REFERENCES communications(id) ON DELETE CASCADE,
        UNIQUE(communication_id, team_name)
    )
");


// ============================================================
// COMMUNICATION USER SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS communication_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        communication_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(communication_id) REFERENCES communications(id) ON DELETE CASCADE,
        UNIQUE(communication_id, user_id)
    )
");


// ============================================================
// COMMUNICATION AUDIT TRAIL
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS communication_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        communication_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        performed_by_id INTEGER,
        user_name TEXT NOT NULL,
        action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        details TEXT,
        FOREIGN KEY(communication_id) REFERENCES communications(id) ON DELETE CASCADE
    )
");
