<?php
/**
 * VA Assessment -- batch vulnerability-scan CSV combiner.
 *
 * Distinct from vulnerabilities.php ("DMZ Assessment"), which tracks one
 * report at a time with a per-finding remediation workflow. This module is
 * a folder of raw scanner exports (one CSV per project/application) that
 * get combined into a single dataset and downloaded as a two-sheet
 * spreadsheet -- there is no per-row tracking state here, so a much
 * simpler schema is enough: a folder, the files uploaded into it, and the
 * rows those files contained.
 *
 * Project and the RHEL / RHEL-Kernel tag are deliberately NOT stored on
 * each row. Both are derived -- project from matching ip_address against
 * inventory.ip_address, the tag from family/steps_to_remediate text -- and
 * inventory can change after a CSV is uploaded. Storing them would go
 * stale the same way asset.php's VLAN/Port Group once did; they are
 * recomputed every time the folder is read instead (see
 * includes/va-assessment-helpers.php).
 */

function runVaAssessmentSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS va_folders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            created_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS va_folder_files (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            original_filename TEXT NOT NULL,
            stored_filename TEXT NOT NULL,
            file_path TEXT NOT NULL,
            uploaded_by INTEGER,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            record_count INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (folder_id) REFERENCES va_folders(id) ON DELETE CASCADE,
            FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
        )
    ");

    /*
    |--------------------------------------------------------------------------
    | PERMANENT NAME SNAPSHOTS FOR created_by / uploaded_by
    |--------------------------------------------------------------------------
    |
    | The declared ON DELETE SET NULL above never actually fires in
    | practice (this app never turns PRAGMA foreign_keys on for the
    | connection users.php uses to delete a user), so a deleted user's id
    | is left dangling anyway. These *_name columns are stamped
    | automatically by triggers whenever the *_id column is set or
    | changed, so "who created this folder / uploaded this file" stays
    | readable regardless.
    |--------------------------------------------------------------------------
    */

    try {
        $pdo->exec("ALTER TABLE va_folders ADD COLUMN created_by_name TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }

    try {
        $pdo->exec("ALTER TABLE va_folder_files ADD COLUMN uploaded_by_name TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }

    $vaUserNameExpr = static function (string $idExpr): string {
        return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                    CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
                 FROM users u WHERE u.id = $idExpr)";
    };

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_va_folders_created_by_name_ins
        AFTER INSERT ON va_folders
        FOR EACH ROW WHEN NEW.created_by IS NOT NULL
        BEGIN
            UPDATE va_folders SET created_by_name = {$vaUserNameExpr('NEW.created_by')} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE va_folders
        SET created_by_name = {$vaUserNameExpr('va_folders.created_by')}
        WHERE created_by IS NOT NULL AND (created_by_name IS NULL OR TRIM(created_by_name) = '')
    ");

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_va_folder_files_uploaded_by_name_ins
        AFTER INSERT ON va_folder_files
        FOR EACH ROW WHEN NEW.uploaded_by IS NOT NULL
        BEGIN
            UPDATE va_folder_files SET uploaded_by_name = {$vaUserNameExpr('NEW.uploaded_by')} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE va_folder_files
        SET uploaded_by_name = {$vaUserNameExpr('va_folder_files.uploaded_by')}
        WHERE uploaded_by IS NOT NULL AND (uploaded_by_name IS NULL OR TRIM(uploaded_by_name) = '')
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS va_folder_rows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            folder_id INTEGER NOT NULL,
            file_id INTEGER NOT NULL,

            plugin TEXT,
            plugin_name TEXT,
            family TEXT,
            severity TEXT,
            ip_address TEXT,
            port TEXT,
            exploit TEXT,
            repository TEXT,
            mac_address TEXT,
            dns_name TEXT,
            netbios_name TEXT,
            plugin_output TEXT,
            steps_to_remediate TEXT,
            cve TEXT,
            first_discovered TEXT,
            last_observed TEXT,
            synopsis TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (folder_id) REFERENCES va_folders(id) ON DELETE CASCADE,
            FOREIGN KEY (file_id) REFERENCES va_folder_files(id) ON DELETE CASCADE
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_files_folder ON va_folder_files(folder_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_rows_folder ON va_folder_rows(folder_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_rows_file ON va_folder_rows(file_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_rows_ip ON va_folder_rows(ip_address)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_rows_severity ON va_folder_rows(severity)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_va_folder_rows_family ON va_folder_rows(family)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    */

    try {
        $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)")
            ->execute(['va_assessment', 'VA Assessment']);

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'va_assessment', 1, 1, 1, 1, 1, 1)
        ");
        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'va_assessment', 0, 0, 0, 0, 0, 0)
        ");

        foreach ($roles as $role) {
            if (strtolower(trim((string) $role)) === 'admin') {
                $grantAll->execute([$role]);
            } else {
                $denyAll->execute([$role]);
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register va_assessment permissions: ' . $e->getMessage());
    }
}
