<?php

/**
 * Per-user page bookmarks (header star dropdown). Independent of
 * links.php's "Quick Links" -- that is a team-shared list of external
 * URLs; this is one user's own shortcuts to InfraVault pages.
 */
function runBookmarksSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_bookmarks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            page_key TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now')),
            UNIQUE(user_id, page_key)
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_user_bookmarks_user
        ON user_bookmarks(user_id)
    ");
}
