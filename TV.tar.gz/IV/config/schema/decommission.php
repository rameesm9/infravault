<?php

// ============================================================
// DECOMMISSION
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL,

        server_state TEXT,

        support_level TEXT,

        project TEXT,

        application_name TEXT,

        ip_address TEXT,

        additional_ips TEXT,

        decommission_start_date TEXT,

        decommission_end_date TEXT,

        created_by TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT,

        updated_at DATETIME
    )
");


// ============================================================
// DECOMMISSION TASKS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        decommission_id INTEGER,

        task_name TEXT NOT NULL,

        status TEXT DEFAULT 'Pending',

        remarks TEXT
    )
");


// ============================================================
// DECOMMISSION HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        decommission_id INTEGER,

        action_type TEXT,

        performed_by TEXT,

        details TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// SAFE DECOMMISSION TASK COLUMN UPGRADES
// ============================================================

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN status TEXT DEFAULT 'Pending'
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN remarks TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN req_no TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission
        ADD COLUMN attachment TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}


// ============================================================
// DECOMMISSION HOSTS
// ------------------------------------------------------------
// A decommission entry (above) is now a batch identified by a
// user-chosen unique_id, covering one or more hosts. Each host's
// inventory details are snapshotted here at the time it is attached,
// so the record stays accurate even if inventory changes later.
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_hosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        decommission_id INTEGER NOT NULL,

        hostname TEXT NOT NULL,

        project TEXT,
        support_level TEXT,
        application_name TEXT,
        ip_address TEXT,
        additional_ips TEXT,
        technical_owner TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// DECOMMISSION ENTRY: batch redesign columns
// ============================================================

try {
    $pdo->exec("ALTER TABLE decommission ADD COLUMN unique_id TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

try {
    $pdo->exec("ALTER TABLE decommission ADD COLUMN req_no TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

try {
    $pdo->exec("ALTER TABLE decommission ADD COLUMN assignee_id INTEGER");
} catch (PDOException $e) {
    // Column already exists.
}

// assignee_name is a permanent snapshot of the assignee's display name,
// captured whenever assignee_id is set. Display code must prefer this
// column over a live JOIN to users, so a reassigned or deleted portal
// user never erases who was assigned, now or in decommission_history.
try {
    $pdo->exec("ALTER TABLE decommission ADD COLUMN assignee_name TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

$decom_assignee_name_backfilled = (bool) $pdo->query("
    SELECT COUNT(*) FROM decommission
    WHERE assignee_id IS NOT NULL AND (assignee_name IS NULL OR TRIM(assignee_name) = '')
")->fetchColumn();

if ($decom_assignee_name_backfilled) {
    $pdo->exec("
        UPDATE decommission
        SET assignee_name = (
            SELECT TRIM(u.first_name || ' ' || u.last_name)
            FROM users u WHERE u.id = decommission.assignee_id
        )
        WHERE assignee_id IS NOT NULL AND (assignee_name IS NULL OR TRIM(assignee_name) = '')
    ");
}


// ============================================================
// ONE-TIME BACKFILL
// ------------------------------------------------------------
// Entries created before this redesign stored a single hostname (plus
// its project/support_level/application_name/ip_address/additional_ips)
// directly on the decommission row. Move that data into decommission_hosts
// and give the row a unique_id so it works in the redesigned UI. Guarded
// by a marker table so this only ever runs once, regardless of how many
// times the schema file executes.
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_hosts_backfill_marker (
        id INTEGER PRIMARY KEY CHECK (id = 1),
        done_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

$decom_already_backfilled = (bool) $pdo->query("SELECT COUNT(*) FROM decommission_hosts_backfill_marker")->fetchColumn();

if (!$decom_already_backfilled) {

    $legacy_stmt = $pdo->query("
        SELECT id, hostname, project, support_level, application_name, ip_address, additional_ips
        FROM decommission
        WHERE hostname IS NOT NULL AND TRIM(hostname) != ''
    ");
    $legacy_rows = $legacy_stmt->fetchAll(PDO::FETCH_ASSOC);

    $owner_stmt = $pdo->prepare("SELECT technical_owner FROM inventory WHERE hostname = ? LIMIT 1");
    $host_insert = $pdo->prepare("
        INSERT INTO decommission_hosts
        (decommission_id, hostname, project, support_level, application_name, ip_address, additional_ips, technical_owner)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $uid_update = $pdo->prepare("
        UPDATE decommission SET unique_id = ?
        WHERE id = ? AND (unique_id IS NULL OR TRIM(unique_id) = '')
    ");

    foreach ($legacy_rows as $legacy_row) {
        $owner_stmt->execute([$legacy_row['hostname']]);
        $technical_owner = $owner_stmt->fetchColumn();

        $host_insert->execute([
            $legacy_row['id'],
            $legacy_row['hostname'],
            $legacy_row['project'],
            $legacy_row['support_level'],
            $legacy_row['application_name'],
            $legacy_row['ip_address'],
            $legacy_row['additional_ips'],
            $technical_owner ?: '',
        ]);

        $uid_update->execute([$legacy_row['hostname'], $legacy_row['id']]);
    }

    // Any row that somehow still has no unique_id (no legacy hostname
    // either) gets a generated placeholder so it remains usable.
    $pdo->exec("UPDATE decommission SET unique_id = 'DECOM-' || id WHERE unique_id IS NULL OR TRIM(unique_id) = ''");

    $pdo->exec("INSERT INTO decommission_hosts_backfill_marker (id) VALUES (1)");
}
