<?php

// ============================================================
// USERS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ncgr_id TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        email TEXT NOT NULL,
        team TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'Read-only',
        is_approved INTEGER DEFAULT 0,
        avatar TEXT DEFAULT 'initials'
    )
");

// Add avatar column if it doesn't exist (for existing databases)
try {
    $pdo->exec("ALTER TABLE users ADD COLUMN avatar TEXT DEFAULT 'initials'");
} catch (Exception $e) {
    // Column already exists, ignore
}

/*
| Phone number: captured at signup, editable by the user (myprofile.php)
| and by an admin (users.php), and consumed by oncall.php as the default
| "Contact number" when that person is scheduled as primary/secondary --
| see oncall.php's ocFill() and $portalById.
*/
try {
    $users_existing_columns = [];
    foreach ($pdo->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC) as $users_column) {
        $users_existing_columns[] = $users_column['name'];
    }
    if (!in_array('phone', $users_existing_columns, true)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN phone TEXT");
    }
} catch (Throwable $e) {
    error_log('Unable to migrate users.phone column: ' . $e->getMessage());
}

/*
| Dark/light mode preference: per-user, set via the header toggle
| (theme_save.php) and mirrored into $_SESSION['theme'] at login so
| includes/header.php can render the correct data-theme attribute
| server-side without affecting any other logged-in user.
*/
try {
    $users_existing_columns = [];
    foreach ($pdo->query('PRAGMA table_info(users)')->fetchAll(PDO::FETCH_ASSOC) as $users_column) {
        $users_existing_columns[] = $users_column['name'];
    }
    if (!in_array('theme', $users_existing_columns, true)) {
        $pdo->exec("ALTER TABLE users ADD COLUMN theme TEXT DEFAULT 'light'");
    }
} catch (Throwable $e) {
    error_log('Unable to migrate users.theme column: ' . $e->getMessage());
}

// Safely insert default admin if not already present
$hashed_password = password_hash('admin123', PASSWORD_DEFAULT);

$stmt = $pdo->prepare("
    INSERT OR IGNORE INTO users
    (
        ncgr_id,
        first_name,
        last_name,
        email,
        team,
        password,
        role,
        is_approved
    )
    VALUES
    (
        'ADMIN001',
        'System',
        'Admin',
        'admin@infravault.local',
        'Cloud',
        ?,
        'Admin',
        1
    )
");

$stmt->execute([$hashed_password]);
