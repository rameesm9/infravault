<?php

// ============================================================
// NOTIFICATION BELL -- PER-USER READ TRACKING
// ============================================================
//
// Marks an individual team note / reminder as read for one user, so the
// header bell's unread badge (includes/notifications.php) can exclude it
// going forward. item_key identifies the underlying row (e.g. "comm_14",
// "reminder_9") -- never alters the underlying communications/reminders
// row itself, and never affects any other user's badge count.

function runNotificationReadsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS notification_reads (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,
            item_key TEXT NOT NULL,

            read_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            UNIQUE(user_id, item_key)
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_notification_reads_user
        ON notification_reads(user_id)
    ");
}
