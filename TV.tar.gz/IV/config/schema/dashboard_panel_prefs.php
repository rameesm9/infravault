<?php

// ============================================================
// DASHBOARD -- PER-USER PANEL LAYOUT
// ============================================================
//
// Lets each user drag-and-drop the dashboard's own tiles (Asset Growth,
// Server Inventory Growth, Asset Types, the breakdown panels, etc.) into
// whatever order they prefer. panel_key is a stable id hardcoded per tile
// in home.php (e.g. "asset-growth") -- never a database id -- so this
// table only ever stores a personal display order, never anything about
// the underlying data. Same shape as dashboard_spotlight_prefs, which
// does the equivalent job for the "For You" spotlight cards.

function runDashboardPanelPrefsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS dashboard_panel_prefs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,
            panel_key TEXT NOT NULL,

            sort_order INTEGER NOT NULL,

            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            UNIQUE(user_id, panel_key)
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_dashboard_panel_prefs_user
        ON dashboard_panel_prefs(user_id)
    ");
}
