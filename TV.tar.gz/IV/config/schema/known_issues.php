<?php

// ============================================================
// KNOWN ISSUES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_number TEXT UNIQUE NOT NULL,

        title TEXT NOT NULL,

        description TEXT,

        category TEXT,

        severity TEXT DEFAULT 'Medium',

        status TEXT DEFAULT 'Open',

        owner_id INTEGER NOT NULL,

        affected_team TEXT,

        affected_system TEXT,

        environment TEXT,

        symptoms_html TEXT,

        cause_html TEXT,

        workaround_html TEXT,

        resolution_html TEXT,

        notes_html TEXT,

        visibility TEXT DEFAULT 'Private',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        resolved_at DATETIME,

        FOREIGN KEY (owner_id)
            REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOT FOR owner_id
// ------------------------------------------------------------
// owner_name is stamped automatically by triggers whenever owner_id is set
// or changed, so the Owner field stays readable even after that portal
// user is reassigned elsewhere or deleted from users entirely (previously
// it rendered the literal word "Unknown" on lookup miss).
// ============================================================

try {
    $pdo->exec("ALTER TABLE known_issues ADD COLUMN owner_name TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

$kiUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_known_issues_owner_name_ins
    AFTER INSERT ON known_issues
    FOR EACH ROW WHEN NEW.owner_id IS NOT NULL
    BEGIN
        UPDATE known_issues SET owner_name = {$kiUserNameExpr('NEW.owner_id')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_known_issues_owner_name_upd
    AFTER UPDATE OF owner_id ON known_issues
    FOR EACH ROW WHEN NEW.owner_id IS NOT NULL
    BEGIN
        UPDATE known_issues SET owner_name = {$kiUserNameExpr('NEW.owner_id')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    UPDATE known_issues
    SET owner_name = {$kiUserNameExpr('known_issues.owner_id')}
    WHERE owner_id IS NOT NULL AND (owner_name IS NULL OR TRIM(owner_name) = '')
");


// ============================================================
// KNOWN ISSUE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issue_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (issue_id)
            REFERENCES known_issues(id),

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");
