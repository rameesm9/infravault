<?php

// ============================================================
// BUILDS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS builds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        build_no TEXT NOT NULL,

        project TEXT NOT NULL,

        status TEXT NOT NULL,

        build_by INTEGER NOT NULL,

        supported_by TEXT,

        build_from TEXT,

        user_id INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOTS FOR build_by / user_id
// ------------------------------------------------------------
// *_name columns are stamped automatically by triggers whenever the
// matching *_id column is set or changed, so "who built this" / "who
// created this record" stays readable even after that portal user is
// reassigned elsewhere or deleted from users entirely.
// ============================================================

foreach (['build_by_name', 'user_id_name'] as $buildNameColumn) {
    try {
        $pdo->exec("ALTER TABLE builds ADD COLUMN $buildNameColumn TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }
}

$buildUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

foreach ([
    'build_by' => 'build_by_name',
    'user_id'  => 'user_id_name',
] as $buildIdCol => $buildNameCol) {

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_builds_{$buildIdCol}_name_ins
        AFTER INSERT ON builds
        FOR EACH ROW WHEN NEW.$buildIdCol IS NOT NULL
        BEGIN
            UPDATE builds SET $buildNameCol = {$buildUserNameExpr('NEW.' . $buildIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_builds_{$buildIdCol}_name_upd
        AFTER UPDATE OF $buildIdCol ON builds
        FOR EACH ROW WHEN NEW.$buildIdCol IS NOT NULL
        BEGIN
            UPDATE builds SET $buildNameCol = {$buildUserNameExpr('NEW.' . $buildIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE builds
        SET $buildNameCol = {$buildUserNameExpr('builds.' . $buildIdCol)}
        WHERE $buildIdCol IS NOT NULL AND ($buildNameCol IS NULL OR TRIM($buildNameCol) = '')
    ");
}


// ============================================================
// BUILD ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS build_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        build_id INTEGER NOT NULL,

        filename TEXT NOT NULL,

        filepath TEXT NOT NULL,

        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (build_id)
            REFERENCES builds(id)
            ON DELETE CASCADE
    )
");
