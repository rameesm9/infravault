<?php
/**
 * Multiple roles per user.
 *
 * `users.role` remains the single "primary" role: it still backs every
 * hardcoded `$_SESSION['role'] === 'Admin'` style check scattered across the
 * older pages, the login session, CSV exports, and sort/search on the users
 * screen. Rewriting all of those to understand a set of roles was judged too
 * large and too risky to bundle with this change.
 *
 * user_roles is the actual source of truth for "what roles does this user
 * hold" -- a user can now have several rows here. includes/authz.php reads
 * it to OR-combine permissions across every role a signed-in user holds, so
 * the pages that already funnel through can()/authzCan() (the majority of
 * the application) get real combined privileges. Anything still comparing
 * $_SESSION['role'] by hand only ever sees the one primary role.
 *
 * Backfill only touches users with zero rows here yet, so it never
 * overwrites an admin's later multi-role assignment on a subsequent
 * request -- this module is safe to run on every schema bootstrap.
 */

function runUserRolesSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            role_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
            UNIQUE(user_id, role_name)
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_user_roles_user ON user_roles(user_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_user_roles_role ON user_roles(role_name)");

    try {
        $pdo->exec("
            INSERT OR IGNORE INTO user_roles (user_id, role_name)
            SELECT id, TRIM(role)
            FROM users
            WHERE role IS NOT NULL
              AND TRIM(role) <> ''
              AND id NOT IN (SELECT DISTINCT user_id FROM user_roles)
        ");
    } catch (Throwable $e) {
        error_log('user_roles backfill failed: ' . $e->getMessage());
    }
}
