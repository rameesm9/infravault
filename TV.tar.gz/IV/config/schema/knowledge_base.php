<?php

// ============================================================
// KNOWLEDGE BASE
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_number TEXT NOT NULL UNIQUE,

        title TEXT NOT NULL,

        category TEXT NOT NULL,

        description TEXT,

        visibility TEXT NOT NULL DEFAULT 'Private'
            CHECK (visibility IN ('Private', 'Public')),

        content_html TEXT,

        created_by INTEGER NOT NULL,

        updated_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (created_by)
            REFERENCES users(id),

        FOREIGN KEY (updated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOTS FOR created_by / updated_by
// ------------------------------------------------------------
// *_name columns are stamped automatically by triggers whenever the
// matching *_id column is set or changed, so the author/editor stays
// readable even after that portal user is reassigned elsewhere or deleted
// from users entirely. Same pattern as patch_schedules.assigned_to_name in
// config/patching_db.php.
// ============================================================

foreach (['created_by_name', 'updated_by_name'] as $kbNameColumn) {
    try {
        $pdo->exec("ALTER TABLE knowledge_base ADD COLUMN $kbNameColumn TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }
}

$kbUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

foreach ([
    'created_by' => 'created_by_name',
    'updated_by' => 'updated_by_name',
] as $kbIdCol => $kbNameCol) {

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_knowledge_base_{$kbIdCol}_name_ins
        AFTER INSERT ON knowledge_base
        FOR EACH ROW WHEN NEW.$kbIdCol IS NOT NULL
        BEGIN
            UPDATE knowledge_base SET $kbNameCol = {$kbUserNameExpr('NEW.' . $kbIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_knowledge_base_{$kbIdCol}_name_upd
        AFTER UPDATE OF $kbIdCol ON knowledge_base
        FOR EACH ROW WHEN NEW.$kbIdCol IS NOT NULL
        BEGIN
            UPDATE knowledge_base SET $kbNameCol = {$kbUserNameExpr('NEW.' . $kbIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE knowledge_base
        SET $kbNameCol = {$kbUserNameExpr('knowledge_base.' . $kbIdCol)}
        WHERE $kbIdCol IS NOT NULL AND ($kbNameCol IS NULL OR TRIM($kbNameCol) = '')
    ");
}


// ============================================================
// KNOWLEDGE BASE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_visibility
    ON knowledge_base(visibility)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_created_by
    ON knowledge_base(created_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_category
    ON knowledge_base(category)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_updated_at
    ON knowledge_base(updated_at)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_attachments_kb_id
    ON knowledge_base_attachments(kb_id)
");


// ============================================================
// KNOWLEDGE BASE REVISION HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        version TEXT NOT NULL DEFAULT '1.0',

        title TEXT,

        content_html TEXT,

        changed_by INTEGER,

        change_summary TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (changed_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE REVISION INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_kb_id
    ON knowledge_base_revisions(kb_id)
");


// ============================================================
// PERMANENT NAME SNAPSHOT FOR REVISION changed_by
// ============================================================

try {
    $pdo->exec("ALTER TABLE knowledge_base_revisions ADD COLUMN changed_by_name TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_knowledge_base_revisions_changed_by_name_ins
    AFTER INSERT ON knowledge_base_revisions
    FOR EACH ROW WHEN NEW.changed_by IS NOT NULL
    BEGIN
        UPDATE knowledge_base_revisions SET changed_by_name = {$kbUserNameExpr('NEW.changed_by')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    UPDATE knowledge_base_revisions
    SET changed_by_name = {$kbUserNameExpr('knowledge_base_revisions.changed_by')}
    WHERE changed_by IS NOT NULL AND (changed_by_name IS NULL OR TRIM(changed_by_name) = '')
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_changed_by
    ON knowledge_base_revisions(changed_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_created_at
    ON knowledge_base_revisions(created_at)
");
