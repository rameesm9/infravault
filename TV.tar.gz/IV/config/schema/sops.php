<?php

// ============================================================
// SOPS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sop_number TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        criticality TEXT DEFAULT 'Medium',
        owner_id INTEGER NOT NULL,
        reviewer_id INTEGER,
        version TEXT DEFAULT '1.0',
        status TEXT DEFAULT 'Draft',
        content_html TEXT,
        prerequisites_html TEXT,
        validation_html TEXT,
        rollback_html TEXT,
        escalation_html TEXT,
        review_comment TEXT,
        rejection_reason TEXT,
        review_date DATE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        submitted_at DATETIME,
        reviewed_at DATETIME,
        published_at DATETIME,
        FOREIGN KEY (owner_id) REFERENCES users(id),
        FOREIGN KEY (reviewer_id) REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOTS FOR owner_id / reviewer_id
// ------------------------------------------------------------
// *_name columns are stamped automatically by triggers whenever the
// matching *_id column is set or changed, so "who owns/reviews this SOP"
// stays readable even after that portal user is reassigned elsewhere or
// deleted from users entirely. Same pattern as patch_schedules in
// config/patching_db.php.
// ============================================================

foreach (['owner_name', 'reviewer_name'] as $sopNameColumn) {
    try {
        $pdo->exec("ALTER TABLE sops ADD COLUMN $sopNameColumn TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }
}

$sopUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

foreach ([
    'owner_id'    => 'owner_name',
    'reviewer_id' => 'reviewer_name',
] as $sopIdCol => $sopNameCol) {

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_sops_{$sopIdCol}_name_ins
        AFTER INSERT ON sops
        FOR EACH ROW WHEN NEW.$sopIdCol IS NOT NULL
        BEGIN
            UPDATE sops SET $sopNameCol = {$sopUserNameExpr('NEW.' . $sopIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_sops_{$sopIdCol}_name_upd
        AFTER UPDATE OF $sopIdCol ON sops
        FOR EACH ROW WHEN NEW.$sopIdCol IS NOT NULL
        BEGIN
            UPDATE sops SET $sopNameCol = {$sopUserNameExpr('NEW.' . $sopIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE sops
        SET $sopNameCol = {$sopUserNameExpr('sops.' . $sopIdCol)}
        WHERE $sopIdCol IS NOT NULL AND ($sopNameCol IS NULL OR TRIM($sopNameCol) = '')
    ");
}


// ============================================================
// SOP REVISIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sop_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sop_id INTEGER NOT NULL,

        version TEXT NOT NULL,

        title TEXT NOT NULL,

        content_html TEXT,

        changed_by INTEGER NOT NULL,

        change_summary TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (sop_id) REFERENCES sops(id),

        FOREIGN KEY (changed_by) REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOT FOR REVISION changed_by
// ============================================================

try {
    $pdo->exec("ALTER TABLE sop_revisions ADD COLUMN changed_by_name TEXT");
} catch (PDOException $e) {
    // Column already exists.
}

$pdo->exec("
    CREATE TRIGGER IF NOT EXISTS trg_sop_revisions_changed_by_name_ins
    AFTER INSERT ON sop_revisions
    FOR EACH ROW WHEN NEW.changed_by IS NOT NULL
    BEGIN
        UPDATE sop_revisions SET changed_by_name = {$sopUserNameExpr('NEW.changed_by')} WHERE id = NEW.id;
    END
");

$pdo->exec("
    UPDATE sop_revisions
    SET changed_by_name = {$sopUserNameExpr('sop_revisions.changed_by')}
    WHERE changed_by IS NOT NULL AND (changed_by_name IS NULL OR TRIM(changed_by_name) = '')
");


// ============================================================
// SOP ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sop_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sop_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (sop_id) REFERENCES sops(id),

        FOREIGN KEY (uploaded_by) REFERENCES users(id)
    )
");
