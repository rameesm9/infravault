<?php

// ============================================================
// PATCH EXCEPTIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exceptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        reference_no TEXT UNIQUE NOT NULL,

        title TEXT NOT NULL,
        exception_type TEXT NOT NULL DEFAULT 'Patch Exception',
        version TEXT NOT NULL DEFAULT '1.0',

        short_description TEXT DEFAULT '',
        system_name TEXT DEFAULT '',
        application_name TEXT DEFAULT '',

        current_version TEXT DEFAULT '',
        target_version TEXT DEFAULT '',

        reason TEXT DEFAULT '',
        risk_description TEXT DEFAULT '',
        mitigation TEXT DEFAULT '',

        owner_id INTEGER NOT NULL,
        team TEXT DEFAULT '',

        visibility TEXT NOT NULL DEFAULT 'Private',

        start_date DATE,
        expiry_date DATE,

        status TEXT NOT NULL DEFAULT 'Draft',

        requested_by INTEGER NOT NULL,

        approved_by INTEGER,
        approved_at DATETIME,

        rejection_reason TEXT DEFAULT '',
        review_comment TEXT DEFAULT '',

        additional_details TEXT DEFAULT '',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (owner_id) REFERENCES users(id),
        FOREIGN KEY (requested_by) REFERENCES users(id),
        FOREIGN KEY (approved_by) REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOTS FOR owner_id / requested_by / approved_by
// ------------------------------------------------------------
// *_name columns are stamped automatically by triggers below whenever the
// matching *_id column is set or changed, so "who owns/requested/approved
// this exception" stays readable even after that portal user is later
// reassigned elsewhere or deleted from users entirely. See the identical
// pattern in config/patching_db.php for patch_schedules.assigned_to_name.
// ============================================================

foreach (['owner_name', 'requested_by_name', 'approved_by_name'] as $peNameColumn) {
    try {
        $pdo->exec("ALTER TABLE patch_exceptions ADD COLUMN $peNameColumn TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }
}

$peUserNameExpr = static function (string $idExpr): string {
    return "(SELECT TRIM(u.first_name || ' ' || u.last_name) ||
                CASE WHEN TRIM(COALESCE(u.ncgr_id, '')) != '' THEN ' (' || u.ncgr_id || ')' ELSE '' END
             FROM users u WHERE u.id = $idExpr)";
};

foreach ([
    'owner_id'      => 'owner_name',
    'requested_by'  => 'requested_by_name',
    'approved_by'   => 'approved_by_name',
] as $peIdCol => $peNameCol) {

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_patch_exceptions_{$peIdCol}_name_ins
        AFTER INSERT ON patch_exceptions
        FOR EACH ROW WHEN NEW.$peIdCol IS NOT NULL
        BEGIN
            UPDATE patch_exceptions SET $peNameCol = {$peUserNameExpr('NEW.' . $peIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_patch_exceptions_{$peIdCol}_name_upd
        AFTER UPDATE OF $peIdCol ON patch_exceptions
        FOR EACH ROW WHEN NEW.$peIdCol IS NOT NULL
        BEGIN
            UPDATE patch_exceptions SET $peNameCol = {$peUserNameExpr('NEW.' . $peIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE patch_exceptions
        SET $peNameCol = {$peUserNameExpr('patch_exceptions.' . $peIdCol)}
        WHERE $peIdCol IS NOT NULL AND ($peNameCol IS NULL OR TRIM($peNameCol) = '')
    ");
}


// ============================================================
// PATCH EXCEPTION ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exception_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        exception_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        file_path TEXT NOT NULL,

        mime_type TEXT DEFAULT 'application/octet-stream',
        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (exception_id)
            REFERENCES patch_exceptions(id)
            ON DELETE CASCADE,

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// PATCH EXCEPTION REVISIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exception_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        exception_id INTEGER NOT NULL,

        version TEXT NOT NULL DEFAULT '1.0',

        title TEXT NOT NULL,
        exception_type TEXT NOT NULL,

        short_description TEXT DEFAULT '',
        system_name TEXT DEFAULT '',
        application_name TEXT DEFAULT '',

        current_version TEXT DEFAULT '',
        target_version TEXT DEFAULT '',

        reason TEXT DEFAULT '',
        risk_description TEXT DEFAULT '',
        mitigation TEXT DEFAULT '',

        owner_id INTEGER,
        team TEXT DEFAULT '',

        visibility TEXT DEFAULT 'Private',

        start_date DATE,
        expiry_date DATE,

        status TEXT DEFAULT 'Draft',

        additional_details TEXT DEFAULT '',

        changed_by INTEGER NOT NULL,

        change_summary TEXT DEFAULT '',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (exception_id)
            REFERENCES patch_exceptions(id)
            ON DELETE CASCADE,

        FOREIGN KEY (changed_by)
            REFERENCES users(id)
    )
");


// ============================================================
// PERMANENT NAME SNAPSHOTS FOR REVISION owner_id / changed_by
// ------------------------------------------------------------
// Without this, a past revision's owner_id/changed_by becomes unresolvable
// the moment that user is deleted, even though the revision row itself is
// otherwise a full point-in-time snapshot of the exception.
// ============================================================

foreach (['owner_name', 'changed_by_name'] as $perNameColumn) {
    try {
        $pdo->exec("ALTER TABLE patch_exception_revisions ADD COLUMN $perNameColumn TEXT");
    } catch (PDOException $e) {
        // Column already exists.
    }
}

foreach ([
    'owner_id'    => 'owner_name',
    'changed_by'  => 'changed_by_name',
] as $perIdCol => $perNameCol) {

    $pdo->exec("
        CREATE TRIGGER IF NOT EXISTS trg_patch_exception_revisions_{$perIdCol}_name_ins
        AFTER INSERT ON patch_exception_revisions
        FOR EACH ROW WHEN NEW.$perIdCol IS NOT NULL
        BEGIN
            UPDATE patch_exception_revisions SET $perNameCol = {$peUserNameExpr('NEW.' . $perIdCol)} WHERE id = NEW.id;
        END
    ");

    $pdo->exec("
        UPDATE patch_exception_revisions
        SET $perNameCol = {$peUserNameExpr('patch_exception_revisions.' . $perIdCol)}
        WHERE $perIdCol IS NOT NULL AND ($perNameCol IS NULL OR TRIM($perNameCol) = '')
    ");
}
