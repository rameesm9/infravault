<?php
/**
 * Role registry.
 *
 * This table was previously created only by the pages that manage it
 * (permission.php and users.php). That left a gap on a fresh installation:
 * every schema module that registers its own page key does so by iterating
 * `SELECT role_name FROM roles`, and on a new database that table does not
 * exist yet -- so the registration threw, was caught and logged, and the
 * pages were silently never registered. The affected modules were the newer
 * ones (Major Layouts, UID/GID, Utilities, Special Projects), which is
 * exactly the set whose permissions a new deployment would find missing.
 *
 * Creating it here, early in the bootstrap, means permission registration
 * works on the very first request against an empty database.
 *
 * permission.php still creates and seeds the same rows with
 * CREATE TABLE IF NOT EXISTS / INSERT OR IGNORE, so this is additive and
 * changes nothing for an existing database.
 */

function runRolesSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_name TEXT UNIQUE NOT NULL,
            is_system INTEGER NOT NULL DEFAULT 0,
            is_locked INTEGER NOT NULL DEFAULT 0
        )
    ");

    /*
     * The same system roles permission.php seeds. Admin is locked
     * because removing it would leave the installation with no way back in.
     */
    $seed = $pdo->prepare("
        INSERT OR IGNORE INTO roles (role_name, is_system, is_locked)
        VALUES (?, ?, ?)
    ");

    foreach ([['Admin', 1, 1], ['Edit', 1, 0], ['Read-only', 1, 0], ['Reviewer', 1, 0]] as $role) {
        $seed->execute($role);
    }
}
