<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/ai-chat-helpers.php';

header('Content-Type: application/json');

if (!authzIsLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not logged in.']);
    exit;
}

csrfVerifyOrDie();

$message = trim((string) ($_POST['message'] ?? ''));

$history = json_decode((string) ($_POST['history'] ?? '[]'), true);
$history = is_array($history) ? $history : [];

if ($message === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Message cannot be empty.']);
    exit;
}

$reply = aiChatSend($history, $message);

if ($reply === null) {
    http_response_code(502);
    echo json_encode([
        'success' => false,
        'error'   => 'The AI assistant is unavailable. Confirm the "llm" container is running and reachable.',
    ]);
    exit;
}

echo json_encode(['success' => true, 'reply' => $reply]);
