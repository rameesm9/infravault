<?php

require_once __DIR__ . '/config/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

requireLogin();
requirePermission('tcpdump_analyzer', 'can_view');

$page_title = 'Tcpdump Analyzer | InfraVault';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<style>

* {
    box-sizing: border-box;
}

.ta-page {
    position: fixed;
    left: 250px;
    right: 0;
    top: var(--header-height, 60px);
    bottom: 0;
    background: var(--bg-main);
    overflow-y: auto;
    transition: .3s ease;
}

body.sidebar-collapsed .ta-page {
    left: 72px;
}

/* ---------------------------------------------------------
   HEADER
--------------------------------------------------------- */

.ta-header {
    background: var(--bg-content);
    border-bottom: 1px solid var(--border-color);
    padding: 20px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.ta-title-area {
    display: flex;
    align-items: center;
    gap: 14px;
}

.ta-title-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #EEF2FF;
    color: #4338CA;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 21px;
    font-weight: 800;
}

.ta-title {
    font-size: 20px;
    font-weight: 750;
    color: var(--text-primary);
}

.ta-subtitle {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 3px;
}

.ta-offline {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 8px;
    background: #ECFDF5;
    color: #047857;
    font-size: 11px;
    font-weight: 700;
    white-space: nowrap;
}

.ta-offline-dot {
    width: 7px;
    height: 7px;
    background: #10B981;
    border-radius: 50%;
}

/* ---------------------------------------------------------
   CONTENT
--------------------------------------------------------- */

.ta-content {
    padding: 22px;
    max-width: 1700px;
    margin: 0 auto;
}

.ta-card {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    box-shadow: 0 2px 10px rgba(15, 23, 42, .035);
    overflow: hidden;
}

.ta-card + .ta-card {
    margin-top: 16px;
}

.ta-card-header {
    padding: 15px 18px;
    border-bottom: 1px solid var(--border-light);
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
}

.ta-card-title {
    font-size: 13px;
    font-weight: 750;
    color: var(--text-primary);
}

.ta-card-subtitle {
    font-size: 11px;
    color: var(--text-muted);
    margin-top: 3px;
}

.ta-card-body {
    padding: 18px;
}

/* ---------------------------------------------------------
   DROPZONE
--------------------------------------------------------- */

.ta-dropzone {
    border: 2px dashed #C7D2FE;
    border-radius: 12px;
    background: #F5F6FF;
    padding: 46px 20px;
    text-align: center;
    cursor: pointer;
    transition: .15s ease;
}

.ta-dropzone:hover,
.ta-dropzone.drag {
    background: #EEF2FF;
    border-color: #818CF8;
}

.ta-dropzone-icon {
    font-size: 34px;
    margin-bottom: 10px;
}

.ta-dropzone-title {
    font-size: 14px;
    font-weight: 750;
    color: var(--text-primary);
}

.ta-dropzone-sub {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 5px;
}

.ta-dropzone input[type=file] {
    display: none;
}

.ta-error {
    margin-top: 12px;
    padding: 10px 12px;
    border-radius: 8px;
    display: none;
    font-size: 12px;
    font-weight: 600;
    background: #FEF2F2;
    color: #B91C1C;
    border: 1px solid #FECACA;
}

.ta-error.show {
    display: block;
}

/* ---------------------------------------------------------
   SUMMARY
--------------------------------------------------------- */

.ta-summary {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
    gap: 10px;
    padding: 16px 18px;
}

.ta-stat {
    background: var(--hover-bg);
    border: 1px solid #E8EDF3;
    border-radius: 10px;
    padding: 11px 12px;
}

.ta-stat-label {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: var(--text-muted);
    font-weight: 750;
    margin-bottom: 5px;
}

.ta-stat-value {
    font-size: 15px;
    font-weight: 750;
    color: var(--text-primary);
    word-break: break-word;
}

/* ---------------------------------------------------------
   TOOLBAR
--------------------------------------------------------- */

.ta-toolbar {
    display: flex;
    gap: 8px;
    flex-wrap: wrap;
    align-items: center;
}

.ta-input {
    height: 38px;
    border: 1px solid #DDE4EC;
    border-radius: 9px;
    padding: 0 12px;
    background: var(--hover-bg);
    color: var(--text-primary);
    font-family: inherit;
    font-size: 12px;
    min-width: 220px;
}

.ta-input:focus {
    outline: none;
    border-color: #4338CA;
    background: var(--bg-content);
    box-shadow: 0 0 0 3px rgba(67, 56, 202, .10);
}

.ta-btn {
    height: 38px;
    border-radius: 9px;
    border: 1px solid var(--border-color);
    background: var(--bg-content);
    padding: 0 14px;
    cursor: pointer;
    font-family: inherit;
    font-size: 12px;
    font-weight: 700;
    color: var(--text-primary);
    transition: .15s ease;
    white-space: nowrap;
}

.ta-btn:hover {
    background: var(--hover-bg);
}

.ta-btn-primary {
    background: #4338CA;
    border-color: #4338CA;
    color: #FFFFFF;
}

.ta-btn-primary:hover {
    background: #3730A3;
}

/* ---------------------------------------------------------
   PACKET TABLE
--------------------------------------------------------- */

.ta-table-wrapper {
    overflow-x: auto;
    max-height: 480px;
    overflow-y: auto;
}

.ta-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 11.5px;
}

.ta-table th {
    position: sticky;
    top: 0;
    z-index: 1;
    text-align: left;
    background: var(--hover-bg);
    color: var(--text-secondary);
    font-weight: 750;
    padding: 8px 10px;
    border-bottom: 1px solid var(--border-color);
    white-space: nowrap;
}

.ta-table td {
    padding: 6px 10px;
    border-bottom: 1px solid var(--border-light);
    color: var(--text-primary);
    white-space: nowrap;
}

.ta-table td.wrap {
    white-space: normal;
    max-width: 420px;
    overflow: hidden;
    text-overflow: ellipsis;
}

.ta-table tbody tr {
    cursor: pointer;
}

.ta-table tbody tr:hover td {
    background: var(--hover-bg);
}

.ta-table tbody tr.sel td {
    background: #EEF2FF;
}

.ta-proto {
    display: inline-block;
    padding: 2px 7px;
    border-radius: 5px;
    font-size: 10px;
    font-weight: 750;
    background: #F1F5F9;
    color: #475569;
}

.ta-proto.tcp { background: #EFF6FF; color: #1D4ED8; }
.ta-proto.udp { background: #ECFDF5; color: #047857; }
.ta-proto.icmp,
.ta-proto.icmpv6 { background: #FEF3C7; color: #B45309; }
.ta-proto.arp { background: #F3E8FF; color: #7E22CE; }
.ta-proto.dns { background: #E0F2FE; color: #0369A1; }
.ta-proto.http { background: #DCFCE7; color: #15803D; }
.ta-proto.tls { background: #FCE7F3; color: #BE185D; }

.ta-pagination {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 8px;
    padding: 10px 14px;
    border-top: 1px solid var(--border-light);
    font-size: 11px;
    color: var(--text-muted);
}

.ta-pagination button {
    height: 28px;
    padding: 0 10px;
    border-radius: 6px;
    border: 1px solid var(--border-color);
    background: var(--bg-content);
    cursor: pointer;
    font-size: 11px;
    font-weight: 700;
    color: var(--text-primary);
}

.ta-pagination button:disabled {
    opacity: .4;
    cursor: default;
}

/* ---------------------------------------------------------
   DETAIL SPLIT
--------------------------------------------------------- */

.ta-detail-grid {
    display: grid;
    grid-template-columns: minmax(320px, 1fr) minmax(380px, 1fr);
    gap: 16px;
}

.ta-empty {
    padding: 30px;
    text-align: center;
    color: var(--text-muted);
    font-size: 12px;
}

.ta-tree {
    font-size: 12px;
}

.ta-tree-node {
    border-bottom: 1px solid var(--border-light);
}

.ta-tree-node > summary {
    padding: 9px 12px;
    cursor: pointer;
    font-weight: 750;
    color: var(--text-primary);
    list-style: none;
    display: flex;
    align-items: center;
    gap: 6px;
}

.ta-tree-node > summary::-webkit-details-marker {
    display: none;
}

.ta-tree-node > summary::before {
    content: '▸';
    font-size: 9px;
    color: var(--text-muted);
    transition: .12s ease;
}

.ta-tree-node[open] > summary::before {
    transform: rotate(90deg);
}

.ta-tree-fields {
    padding: 2px 12px 10px 26px;
}

.ta-tree-field {
    display: flex;
    gap: 8px;
    padding: 3px 0;
    font-size: 11.5px;
}

.ta-tree-field .k {
    color: var(--text-muted);
    min-width: 150px;
    flex-shrink: 0;
}

.ta-tree-field .v {
    color: var(--text-primary);
    font-weight: 600;
    word-break: break-word;
}

.ta-hex {
    font-family: Consolas, Monaco, monospace;
    font-size: 11px;
    line-height: 1.75;
    background: #0F172A;
    color: #CBD5E1;
    padding: 14px;
    overflow: auto;
    max-height: 460px;
}

.ta-hex .off {
    color: #64748B;
}

.ta-hex .ascii {
    color: #93C5FD;
}

/* ---------------------------------------------------------
   DARK MODE
--------------------------------------------------------- */

[data-theme="dark"] .ta-title-icon {
    background: #1e2a4a;
    color: #7BA6FF;
}

[data-theme="dark"] .ta-offline {
    background: #123528;
    color: #4CC49A;
}

[data-theme="dark"] .ta-offline-dot {
    background: #4CC49A;
}

[data-theme="dark"] .ta-dropzone {
    background: #1a2138;
    border-color: #354573;
}

[data-theme="dark"] .ta-dropzone:hover,
[data-theme="dark"] .ta-dropzone.drag {
    background: #1e2a4a;
    border-color: #5B75B8;
}

[data-theme="dark"] .ta-error {
    background: #3a1a1a;
    color: #F1837A;
    border-color: #5c2a2a;
}

[data-theme="dark"] .ta-btn-primary {
    background: #5B67D6;
    border-color: #5B67D6;
}

[data-theme="dark"] .ta-btn-primary:hover {
    background: #4A54BE;
}

[data-theme="dark"] .ta-table tbody tr.sel td {
    background: #1e2a4a;
}

[data-theme="dark"] .ta-proto {
    background: #26324a;
    color: #a3afc2;
}

[data-theme="dark"] .ta-proto.tcp { background: #1e2a4a; color: #7BA6FF; }
[data-theme="dark"] .ta-proto.udp { background: #123528; color: #4CC49A; }
[data-theme="dark"] .ta-proto.icmp,
[data-theme="dark"] .ta-proto.icmpv6 { background: #3a2a14; color: #F5B054; }
[data-theme="dark"] .ta-proto.arp { background: #2A1B3D; color: #C4A0F0; }
[data-theme="dark"] .ta-proto.dns { background: #122433; color: #5FA8DC; }
[data-theme="dark"] .ta-proto.http { background: #123528; color: #4CC49A; }
[data-theme="dark"] .ta-proto.tls { background: #3a1a2e; color: #E893BC; }

/* ---------------------------------------------------------
   RESPONSIVE
--------------------------------------------------------- */

@media (max-width: 1150px) {

    .ta-detail-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 700px) {

    .ta-page {
        left: 0;
        top: 70px;
    }

    body.sidebar-collapsed .ta-page {
        left: 0;
    }

    .ta-header {
        padding: 15px;
    }

    .ta-content {
        padding: 12px;
    }

    .ta-offline {
        display: none;
    }

}

</style>


<div class="ta-page">

    <!-- HEADER -->
    <div class="ta-header">

        <div class="ta-title-area">

            <div class="ta-title-icon">
                ⇄
            </div>

            <div>
                <div class="ta-title">
                    Tcpdump / Pcap Analyzer
                </div>

                <div class="ta-subtitle">
                    Decode .pcap / .pcapng captures entirely in your browser
                </div>
            </div>

        </div>

        <div class="ta-offline">
            <span class="ta-offline-dot"></span>
            100% Offline
        </div>

    </div>


    <div class="ta-content">

        <!-- UPLOAD -->

        <div class="ta-card" id="taUploadCard">

            <div class="ta-card-body">

                <div class="ta-dropzone" id="taDropzone">

                    <div class="ta-dropzone-icon">📦</div>

                    <div class="ta-dropzone-title">
                        Drop a .pcap or .pcapng file here, or click to browse
                    </div>

                    <div class="ta-dropzone-sub">
                        Parsed locally with JavaScript. The file is never uploaded anywhere.
                    </div>

                    <input type="file" id="taFileInput" accept=".pcap,.pcapng,.cap">

                </div>

                <div class="ta-error" id="taError"></div>

            </div>

        </div>


        <!-- RESULTS (hidden until a capture is loaded) -->

        <div id="taResults" style="display:none;">

            <div class="ta-card">

                <div class="ta-card-header">

                    <div>
                        <div class="ta-card-title" id="taFileName">capture.pcap</div>
                        <div class="ta-card-subtitle" id="taFileMeta">—</div>
                    </div>

                    <button class="ta-btn" id="taLoadAnother">Load another file</button>

                </div>

                <div class="ta-summary" id="taSummary"></div>

            </div>


            <div class="ta-card">

                <div class="ta-card-header">

                    <div class="ta-toolbar">

                        <input
                            type="text"
                            id="taFilter"
                            class="ta-input"
                            placeholder="Filter: ip, port, protocol or text in Info…"
                            autocomplete="off"
                        >

                        <button class="ta-btn" id="taClearFilter">Clear</button>

                    </div>

                    <div class="ta-card-subtitle" id="taCount">0 packets</div>

                </div>

                <div class="ta-table-wrapper">

                    <table class="ta-table">

                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Time</th>
                                <th>Source</th>
                                <th>Destination</th>
                                <th>Protocol</th>
                                <th>Length</th>
                                <th>Info</th>
                            </tr>
                        </thead>

                        <tbody id="taTableBody"></tbody>

                    </table>

                </div>

                <div class="ta-pagination">
                    <span id="taPageInfo"></span>
                    <button id="taPrevPage">‹ Prev</button>
                    <button id="taNextPage">Next ›</button>
                </div>

            </div>


            <div class="ta-card">

                <div class="ta-card-header">
                    <div class="ta-card-title">Packet Detail</div>
                    <div class="ta-card-subtitle" id="taDetailSub">Select a packet above</div>
                </div>

                <div class="ta-card-body">

                    <div class="ta-detail-grid">

                        <div class="ta-card" style="box-shadow:none;">
                            <div class="ta-tree" id="taTree">
                                <div class="ta-empty">No packet selected</div>
                            </div>
                        </div>

                        <div class="ta-card" style="box-shadow:none;">
                            <div class="ta-hex" id="taHex">No packet selected</div>
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<script>
(function () {
'use strict';

/* =====================================================================
   STATE
===================================================================== */

var state = {
    linkType: 1,
    tsResol: 1e-6,
    packets: [],       // { num, time, src, dst, proto, len, info, layers, raw:Uint8Array }
    filtered: null,
    page: 0,
    pageSize: 500,
    selected: -1
};

var els = {
    dropzone: document.getElementById('taDropzone'),
    fileInput: document.getElementById('taFileInput'),
    error: document.getElementById('taError'),
    uploadCard: document.getElementById('taUploadCard'),
    results: document.getElementById('taResults'),
    fileName: document.getElementById('taFileName'),
    fileMeta: document.getElementById('taFileMeta'),
    summary: document.getElementById('taSummary'),
    filter: document.getElementById('taFilter'),
    clearFilter: document.getElementById('taClearFilter'),
    count: document.getElementById('taCount'),
    tableBody: document.getElementById('taTableBody'),
    pageInfo: document.getElementById('taPageInfo'),
    prevPage: document.getElementById('taPrevPage'),
    nextPage: document.getElementById('taNextPage'),
    tree: document.getElementById('taTree'),
    hex: document.getElementById('taHex'),
    detailSub: document.getElementById('taDetailSub'),
    loadAnother: document.getElementById('taLoadAnother')
};

function showError(msg) {
    els.error.textContent = msg;
    els.error.classList.add('show');
}

function clearError() {
    els.error.textContent = '';
    els.error.classList.remove('show');
}

/* =====================================================================
   BYTE HELPERS
===================================================================== */

function mac(bytes, off) {
    var out = [];
    for (var i = 0; i < 6; i++) {
        out.push(bytes[off + i].toString(16).padStart(2, '0'));
    }
    return out.join(':');
}

function ip4(bytes, off) {
    return bytes[off] + '.' + bytes[off + 1] + '.' + bytes[off + 2] + '.' + bytes[off + 3];
}

function ip6(bytes, off) {
    var groups = [];
    for (var i = 0; i < 8; i++) {
        var v = (bytes[off + i * 2] << 8) | bytes[off + i * 2 + 1];
        groups.push(v.toString(16));
    }
    // collapse the longest run of zero groups into "::"
    var best = { start: -1, len: 0 }, cur = { start: -1, len: 0 };
    for (var g = 0; g < groups.length; g++) {
        if (groups[g] === '0') {
            if (cur.start === -1) cur = { start: g, len: 0 };
            cur.len++;
            if (cur.len > best.len) best = cur;
        } else {
            cur = { start: -1, len: 0 };
        }
    }
    if (best.len > 1) {
        var head = groups.slice(0, best.start);
        var tail = groups.slice(best.start + best.len);
        return head.join(':') + '::' + tail.join(':');
    }
    return groups.join(':');
}

function hexByte(b) {
    return b.toString(16).padStart(2, '0');
}

function esc(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function fmtTime(sec) {
    var d = new Date(sec * 1000);
    if (isNaN(d.getTime())) return String(sec);
    return d.toISOString().replace('T', ' ').replace('Z', '');
}

function fmtBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1024 * 1024) return (n / 1024).toFixed(1) + ' KB';
    return (n / (1024 * 1024)).toFixed(2) + ' MB';
}

/* =====================================================================
   PCAP (classic) PARSER
   https://wiki.wireshark.org/Development/LibpcapFileFormat
===================================================================== */

function parseClassicPcap(buf) {
    var dv = new DataView(buf);
    var magic = dv.getUint32(0, false);
    var little, nano = false;

    if (magic === 0xa1b2c3d4) { little = true; }
    else if (magic === 0xd4c3b2a1) { little = false; }
    else if (magic === 0xa1b23c4d) { little = true; nano = true; }
    else if (magic === 0x4d3cb2a1) { little = false; nano = true; }
    else throw new Error('Not a recognized classic pcap file (bad magic number).');

    var linkType = dv.getUint32(16, little);
    state.linkType = linkType;
    state.tsResol = nano ? 1e-9 : 1e-6;

    var off = 24;
    var packets = [];
    var num = 1;

    while (off + 16 <= buf.byteLength) {
        var tsSec = dv.getUint32(off, little);
        var tsFrac = dv.getUint32(off + 4, little);
        var inclLen = dv.getUint32(off + 8, little);
        var origLen = dv.getUint32(off + 12, little);
        off += 16;

        if (off + inclLen > buf.byteLength) break;

        var raw = new Uint8Array(buf, off, inclLen);
        var time = tsSec + tsFrac * state.tsResol;
        packets.push(buildPacket(num, time, origLen, raw, linkType));

        off += inclLen;
        num++;
    }

    return packets;
}

/* =====================================================================
   PCAPNG PARSER (Section Header / Interface Description / Enhanced
   Packet blocks — covers the files modern tcpdump / dumpcap produce)
   https://www.ietf.org/archive/id/draft-ietf-opsawg-pcapng-03.html
===================================================================== */

function parsePcapng(buf) {
    var dv = new DataView(buf);
    var off = 0;
    var little = true;
    var linkTypes = {};   // interface id -> linktype
    var tsResols = {};    // interface id -> seconds-per-tick
    var ifaceCount = 0;
    var packets = [];
    var num = 1;
    var lastLinkType = 1;

    while (off + 8 <= buf.byteLength) {
        var blockType = dv.getUint32(off, little);

        if (blockType === 0x0A0D0D0A) {
            // Section Header Block re-establishes byte order.
            var bom = dv.getUint32(off + 8, true);
            if (bom === 0x1A2B3C4D) little = true;
            else if (bom === 0x4D3C2B1A) little = false;
            else throw new Error('Invalid pcapng section header (bad byte-order magic).');
        }

        var blockLen = dv.getUint32(off + 4, little);
        if (blockLen < 12 || off + blockLen > buf.byteLength) break;

        if (blockType === 0x00000001) {
            // Interface Description Block
            var ifLinkType = dv.getUint16(off + 8, little);
            var ifId = ifaceCount++;
            linkTypes[ifId] = ifLinkType;
            lastLinkType = ifLinkType;

            var tsResol = 1e-6;
            var optOff = off + 16;
            var optEnd = off + blockLen - 4;
            while (optOff + 4 <= optEnd) {
                var optCode = dv.getUint16(optOff, little);
                var optLen = dv.getUint16(optOff + 2, little);
                if (optCode === 0) break;
                if (optCode === 9 && optLen >= 1) {
                    var raw = dv.getUint8(optOff + 4);
                    var neg = !!(raw & 0x80);
                    var exp = raw & 0x7f;
                    tsResol = neg ? Math.pow(2, -exp) : Math.pow(10, -exp);
                }
                optOff += 4 + optLen + ((4 - (optLen % 4)) % 4);
            }
            tsResols[ifId] = tsResol;
        } else if (blockType === 0x00000006) {
            // Enhanced Packet Block
            var ifaceId = dv.getUint32(off + 8, little);
            var tsHigh = dv.getUint32(off + 12, little);
            var tsLow = dv.getUint32(off + 16, little);
            var capLen = dv.getUint32(off + 20, little);
            var origLen = dv.getUint32(off + 24, little);

            var dataOff = off + 28;
            if (dataOff + capLen <= buf.byteLength) {
                var raw = new Uint8Array(buf, dataOff, capLen);
                var resol = tsResols.hasOwnProperty(ifaceId) ? tsResols[ifaceId] : 1e-6;
                var ts64 = tsHigh * 4294967296 + tsLow;
                var time = ts64 * resol;
                var lt = linkTypes.hasOwnProperty(ifaceId) ? linkTypes[ifaceId] : lastLinkType;
                packets.push(buildPacket(num, time, origLen, raw, lt));
                num++;
            }
        } else if (blockType === 0x00000003) {
            // Simple Packet Block (rare; assumes single interface)
            var origLen2 = dv.getUint32(off + 8, little);
            var dataOff2 = off + 12;
            var capLen2 = Math.min(origLen2, blockLen - 16);
            if (dataOff2 + capLen2 <= buf.byteLength) {
                var raw2 = new Uint8Array(buf, dataOff2, capLen2);
                packets.push(buildPacket(num, 0, origLen2, raw2, lastLinkType));
                num++;
            }
        }

        off += blockLen;
    }

    state.linkType = lastLinkType;
    return packets;
}

/* =====================================================================
   LAYER DECODERS
===================================================================== */

var IP_PROTOCOLS = {
    1: 'ICMP', 2: 'IGMP', 6: 'TCP', 17: 'UDP', 41: 'IPv6', 47: 'GRE',
    50: 'ESP', 51: 'AH', 58: 'ICMPv6', 88: 'EIGRP', 89: 'OSPF', 132: 'SCTP'
};

var ICMP_TYPES = {
    0: 'Echo Reply', 3: 'Destination Unreachable', 5: 'Redirect',
    8: 'Echo Request', 9: 'Router Advertisement', 10: 'Router Solicitation',
    11: 'Time Exceeded', 12: 'Parameter Problem'
};

var ICMPV6_TYPES = {
    1: 'Destination Unreachable', 2: 'Packet Too Big', 3: 'Time Exceeded',
    128: 'Echo Request', 129: 'Echo Reply', 133: 'Router Solicitation',
    134: 'Router Advertisement', 135: 'Neighbor Solicitation', 136: 'Neighbor Advertisement'
};

function decodeEthernet(raw) {
    if (raw.length < 14) return null;
    var etherType = (raw[12] << 8) | raw[13];
    var l3Off = 14;

    var vlan = null;
    if (etherType === 0x8100 && raw.length >= 18) {
        var tci = (raw[14] << 8) | raw[15];
        vlan = { id: tci & 0x0FFF, priority: (tci >> 13) & 0x7 };
        etherType = (raw[16] << 8) | raw[17];
        l3Off = 18;
    }

    return {
        layer: {
            name: 'Ethernet II',
            fields: [
                ['Destination', mac(raw, 0)],
                ['Source', mac(raw, 6)],
                ['Type', '0x' + etherType.toString(16).padStart(4, '0')]
            ].concat(vlan ? [['VLAN ID', vlan.id], ['VLAN Priority', vlan.priority]] : [])
        },
        etherType: etherType,
        srcMac: mac(raw, 6),
        dstMac: mac(raw, 0),
        l3Off: l3Off
    };
}

function decodeLinuxSLL(raw) {
    if (raw.length < 16) return null;
    var pktType = (raw[0] << 8) | raw[1];
    var addrLen = (raw[4] << 8) | raw[5];
    var addr = '';
    for (var i = 0; i < Math.min(addrLen, 6); i++) {
        addr += (i ? ':' : '') + hexByte(raw[6 + i]);
    }
    var etherType = (raw[14] << 8) | raw[15];
    return {
        layer: {
            name: 'Linux cooked capture (SLL)',
            fields: [
                ['Packet type', pktType],
                ['Link-layer address', addr || 'n/a'],
                ['Protocol', '0x' + etherType.toString(16).padStart(4, '0')]
            ]
        },
        etherType: etherType,
        srcMac: addr || '-',
        dstMac: '-',
        l3Off: 16
    };
}

function decodeIPv4(raw, off) {
    if (raw.length < off + 20) return null;
    var b0 = raw[off];
    var ihl = (b0 & 0x0F) * 4;
    var totalLen = (raw[off + 2] << 8) | raw[off + 3];
    var flagsFrag = (raw[off + 6] << 8) | raw[off + 7];
    var proto = raw[off + 9];
    var ttl = raw[off + 8];
    var src = ip4(raw, off + 12);
    var dst = ip4(raw, off + 16);

    return {
        layer: {
            name: 'Internet Protocol Version 4',
            fields: [
                ['Version', 4],
                ['Header Length', ihl + ' bytes'],
                ['Total Length', totalLen],
                ['TTL', ttl],
                ['Protocol', proto + ' (' + (IP_PROTOCOLS[proto] || 'Unknown') + ')'],
                ['Flags', (flagsFrag & 0x4000 ? 'Don’t Fragment ' : '') + (flagsFrag & 0x2000 ? 'More Fragments' : '')],
                ['Fragment Offset', flagsFrag & 0x1FFF],
                ['Source', src],
                ['Destination', dst]
            ]
        },
        proto: proto,
        src: src,
        dst: dst,
        headerLen: ihl,
        payloadOff: off + ihl,
        totalLen: totalLen
    };
}

function decodeIPv6(raw, off) {
    if (raw.length < off + 40) return null;
    var payloadLen = (raw[off + 4] << 8) | raw[off + 5];
    var nextHeader = raw[off + 6];
    var hopLimit = raw[off + 7];
    var src = ip6(raw, off + 8);
    var dst = ip6(raw, off + 24);

    return {
        layer: {
            name: 'Internet Protocol Version 6',
            fields: [
                ['Version', 6],
                ['Payload Length', payloadLen],
                ['Next Header', nextHeader + ' (' + (IP_PROTOCOLS[nextHeader] || 'Unknown') + ')'],
                ['Hop Limit', hopLimit],
                ['Source', src],
                ['Destination', dst]
            ]
        },
        proto: nextHeader,
        src: src,
        dst: dst,
        payloadOff: off + 40,
        totalLen: payloadLen + 40
    };
}

function decodeARP(raw, off) {
    if (raw.length < off + 28) return null;
    var opcode = (raw[off + 6] << 8) | raw[off + 7];
    var senderMac = mac(raw, off + 8);
    var senderIp = ip4(raw, off + 14);
    var targetMac = mac(raw, off + 18);
    var targetIp = ip4(raw, off + 24);

    return {
        layer: {
            name: 'Address Resolution Protocol',
            fields: [
                ['Opcode', opcode === 1 ? 'request' : opcode === 2 ? 'reply' : opcode],
                ['Sender MAC', senderMac],
                ['Sender IP', senderIp],
                ['Target MAC', targetMac],
                ['Target IP', targetIp]
            ]
        },
        opcode: opcode,
        senderMac: senderMac,
        senderIp: senderIp,
        targetMac: targetMac,
        targetIp: targetIp
    };
}

var TCP_FLAG_BITS = [
    ['FIN', 0x01], ['SYN', 0x02], ['RST', 0x04], ['PSH', 0x08],
    ['ACK', 0x10], ['URG', 0x20], ['ECE', 0x40], ['CWR', 0x80]
];

function decodeTCP(raw, off) {
    if (raw.length < off + 20) return null;
    var srcPort = (raw[off] << 8) | raw[off + 1];
    var dstPort = (raw[off + 2] << 8) | raw[off + 3];
    var seq = (raw[off + 4] * 16777216) + (raw[off + 5] << 16) + (raw[off + 6] << 8) + raw[off + 7];
    var ack = (raw[off + 8] * 16777216) + (raw[off + 9] << 16) + (raw[off + 10] << 8) + raw[off + 11];
    var dataOff = (raw[off + 12] >> 4) * 4;
    var flagsByte = raw[off + 13];
    var window = (raw[off + 14] << 8) | raw[off + 15];

    var flags = [];
    for (var i = 0; i < TCP_FLAG_BITS.length; i++) {
        if (flagsByte & TCP_FLAG_BITS[i][1]) flags.push(TCP_FLAG_BITS[i][0]);
    }

    return {
        layer: {
            name: 'Transmission Control Protocol',
            fields: [
                ['Source Port', srcPort],
                ['Destination Port', dstPort],
                ['Sequence Number', seq],
                ['Acknowledgment Number', ack],
                ['Header Length', dataOff + ' bytes'],
                ['Flags', '0x' + flagsByte.toString(16).padStart(2, '0') + ' [' + flags.join(', ') + ']'],
                ['Window Size', window]
            ]
        },
        srcPort: srcPort,
        dstPort: dstPort,
        seq: seq,
        ack: ack,
        flags: flags,
        window: window,
        headerLen: dataOff,
        payloadOff: off + dataOff
    };
}

function decodeUDP(raw, off) {
    if (raw.length < off + 8) return null;
    var srcPort = (raw[off] << 8) | raw[off + 1];
    var dstPort = (raw[off + 2] << 8) | raw[off + 3];
    var length = (raw[off + 4] << 8) | raw[off + 5];

    return {
        layer: {
            name: 'User Datagram Protocol',
            fields: [
                ['Source Port', srcPort],
                ['Destination Port', dstPort],
                ['Length', length]
            ]
        },
        srcPort: srcPort,
        dstPort: dstPort,
        length: length,
        payloadOff: off + 8
    };
}

function decodeICMP(raw, off, v6) {
    if (raw.length < off + 4) return null;
    var type = raw[off];
    var code = raw[off + 1];
    var names = v6 ? ICMPV6_TYPES : ICMP_TYPES;

    return {
        layer: {
            name: v6 ? 'Internet Control Message Protocol v6' : 'Internet Control Message Protocol',
            fields: [
                ['Type', type + ' (' + (names[type] || 'Unknown') + ')'],
                ['Code', code]
            ]
        },
        type: type,
        code: code,
        typeName: names[type] || ('type ' + type)
    };
}

function readDnsName(raw, off, startOff) {
    var labels = [];
    var jumped = false;
    var guard = 0;
    var pos = off;

    while (pos < raw.length && guard++ < 64) {
        var len = raw[pos];
        if (len === 0) { pos++; break; }
        if ((len & 0xC0) === 0xC0) {
            if (!jumped) startOff = pos + 2;
            pos = ((len & 0x3F) << 8) | raw[pos + 1];
            jumped = true;
            continue;
        }
        labels.push(String.fromCharCode.apply(null, raw.slice(pos + 1, pos + 1 + len)));
        pos += len + 1;
    }

    return { name: labels.join('.'), next: jumped ? startOff : pos };
}

var DNS_QTYPES = { 1: 'A', 2: 'NS', 5: 'CNAME', 6: 'SOA', 12: 'PTR', 15: 'MX', 16: 'TXT', 28: 'AAAA', 33: 'SRV' };

function decodeDNS(raw, off) {
    if (raw.length < off + 12) return null;
    var id = (raw[off] << 8) | raw[off + 1];
    var flags = (raw[off + 2] << 8) | raw[off + 3];
    var isResponse = !!(flags & 0x8000);
    var qdcount = (raw[off + 4] << 8) | raw[off + 5];
    var ancount = (raw[off + 6] << 8) | raw[off + 7];

    var questions = [];
    var pos = off + 12;
    for (var i = 0; i < qdcount && pos < raw.length; i++) {
        var r = readDnsName(raw, pos, pos);
        pos = r.next;
        if (pos + 4 > raw.length) break;
        var qtype = (raw[pos] << 8) | raw[pos + 1];
        questions.push({ name: r.name, type: DNS_QTYPES[qtype] || qtype });
        pos += 4;
    }

    var fields = [
        ['Transaction ID', '0x' + id.toString(16).padStart(4, '0')],
        ['Response', isResponse ? 'Yes' : 'No'],
        ['Questions', qdcount],
        ['Answer RRs', ancount]
    ];
    questions.forEach(function (q, idx) {
        fields.push(['Query ' + (idx + 1), q.name + ' (' + q.type + ')']);
    });

    return {
        layer: { name: 'Domain Name System', fields: fields },
        isResponse: isResponse,
        questions: questions
    };
}

function asciiSlice(raw, off, len) {
    var out = '';
    var end = Math.min(off + len, raw.length);
    for (var i = off; i < end; i++) out += String.fromCharCode(raw[i]);
    return out;
}

function decodeHTTPGuess(raw, off) {
    if (raw.length <= off) return null;
    var text = asciiSlice(raw, off, Math.min(200, raw.length - off));
    var m = text.match(/^(GET|POST|PUT|DELETE|HEAD|OPTIONS|PATCH) \S+ HTTP\/\d\.\d/);
    if (m) {
        var line = text.split('\r\n')[0];
        return { layer: { name: 'Hypertext Transfer Protocol', fields: [['Request Line', line]] }, info: line };
    }
    var m2 = text.match(/^HTTP\/\d\.\d \d{3}/);
    if (m2) {
        var line2 = text.split('\r\n')[0];
        return { layer: { name: 'Hypertext Transfer Protocol', fields: [['Status Line', line2]] }, info: line2 };
    }
    return null;
}

var TLS_CONTENT_TYPES = { 20: 'Change Cipher Spec', 21: 'Alert', 22: 'Handshake', 23: 'Application Data' };
var TLS_HANDSHAKE_TYPES = { 1: 'Client Hello', 2: 'Server Hello', 11: 'Certificate', 12: 'Server Key Exchange', 14: 'Server Hello Done', 16: 'Client Key Exchange' };

function decodeTLSGuess(raw, off) {
    if (raw.length < off + 6) return null;
    var contentType = raw[off];
    if (!TLS_CONTENT_TYPES[contentType]) return null;
    var verMajor = raw[off + 1], verMinor = raw[off + 2];
    if (verMajor !== 3) return null;

    var fields = [
        ['Content Type', contentType + ' (' + TLS_CONTENT_TYPES[contentType] + ')'],
        ['Version', 'TLS 1.' + (verMinor - 1 >= 0 ? verMinor - 1 : verMinor)]
    ];
    var info = TLS_CONTENT_TYPES[contentType];

    if (contentType === 22 && raw.length > off + 5) {
        var hsType = raw[off + 5];
        fields.push(['Handshake Type', hsType + ' (' + (TLS_HANDSHAKE_TYPES[hsType] || 'Unknown') + ')']);
        info = TLS_HANDSHAKE_TYPES[hsType] || info;
    }

    return { layer: { name: 'Transport Layer Security', fields: fields }, info: info };
}

/* =====================================================================
   PACKET BUILDER — walks the layer stack and produces a table row
   plus the full layer list used for the detail tree.
===================================================================== */

function buildPacket(num, time, origLen, raw, linkType) {
    var layers = [{ name: 'Frame', fields: [
        ['Frame Number', num],
        ['Captured Length', raw.length + ' bytes'],
        ['Original Length', origLen + ' bytes'],
        ['Epoch Time', time.toFixed(6) + ' s']
    ] }];

    var src = '-', dst = '-', proto = 'RAW', info = '';
    var l3Off = 0, etherType = null;

    if (linkType === 1) {
        var eth = decodeEthernet(raw);
        if (eth) { layers.push(eth.layer); l3Off = eth.l3Off; etherType = eth.etherType; src = eth.srcMac; dst = eth.dstMac; }
    } else if (linkType === 113) {
        var sll = decodeLinuxSLL(raw);
        if (sll) { layers.push(sll.layer); l3Off = sll.l3Off; etherType = sll.etherType; src = sll.srcMac; dst = sll.dstMac; }
    } else if (linkType === 101) {
        etherType = 0x0800; // LINKTYPE_RAW: no L2 header, assume IPv4/IPv6 sniff below
        if (raw.length > 0 && (raw[0] >> 4) === 6) etherType = 0x86DD;
        l3Off = 0;
    } else if (linkType === 0) {
        // BSD loopback: 4-byte address family header (host byte order)
        if (raw.length >= 4) {
            var af = raw[0] | (raw[1] << 8) | (raw[2] << 16) | (raw[3] << 24);
            etherType = (af === 24 || af === 28 || af === 30) ? 0x86DD : 0x0800;
            l3Off = 4;
        }
    }

    if (etherType === 0x0806) {
        var arp = decodeARP(raw, l3Off);
        if (arp) {
            layers.push(arp.layer);
            proto = 'ARP';
            src = arp.senderIp;
            dst = arp.targetIp;
            info = arp.opcode === 1
                ? 'Who has ' + arp.targetIp + '? Tell ' + arp.senderIp
                : arp.senderIp + ' is at ' + arp.senderMac;
        }
    } else if (etherType === 0x0800 || etherType === 0x86DD) {
        var ipInfo = etherType === 0x0800 ? decodeIPv4(raw, l3Off) : decodeIPv6(raw, l3Off);
        if (ipInfo) {
            layers.push(ipInfo.layer);
            src = ipInfo.src;
            dst = ipInfo.dst;
            proto = IP_PROTOCOLS[ipInfo.proto] || ('IP proto ' + ipInfo.proto);

            if (ipInfo.proto === 6) {
                var tcp = decodeTCP(raw, ipInfo.payloadOff);
                if (tcp) {
                    layers.push(tcp.layer);
                    proto = 'TCP';
                    info = tcp.srcPort + ' → ' + tcp.dstPort +
                        ' [' + tcp.flags.join(', ') + '] Seq=' + tcp.seq + ' Ack=' + tcp.ack + ' Win=' + tcp.window;

                    var appOff = tcp.payloadOff;
                    if (raw.length > appOff) {
                        var http = decodeHTTPGuess(raw, appOff);
                        var tls = !http ? decodeTLSGuess(raw, appOff) : null;
                        if (http) { layers.push(http.layer); proto = 'HTTP'; info = http.info; }
                        else if (tls) { layers.push(tls.layer); proto = 'TLS'; info = tls.info + ' (' + tcp.srcPort + ' → ' + tcp.dstPort + ')'; }
                    }
                }
            } else if (ipInfo.proto === 17) {
                var udp = decodeUDP(raw, ipInfo.payloadOff);
                if (udp) {
                    layers.push(udp.layer);
                    proto = 'UDP';
                    info = udp.srcPort + ' → ' + udp.dstPort + ' Len=' + udp.length;

                    if (udp.srcPort === 53 || udp.dstPort === 53) {
                        var dns = decodeDNS(raw, udp.payloadOff);
                        if (dns) {
                            layers.push(dns.layer);
                            proto = 'DNS';
                            var q = dns.questions[0];
                            info = (dns.isResponse ? 'Response' : 'Query') + (q ? ': ' + q.name + ' (' + q.type + ')' : '');
                        }
                    }
                }
            } else if (ipInfo.proto === 1 || ipInfo.proto === 58) {
                var icmp = decodeICMP(raw, ipInfo.payloadOff, ipInfo.proto === 58);
                if (icmp) {
                    layers.push(icmp.layer);
                    proto = ipInfo.proto === 58 ? 'ICMPv6' : 'ICMP';
                    info = icmp.typeName;
                }
            }
        }
    } else if (l3Off >= raw.length) {
        proto = 'Unsupported link layer';
    }

    return {
        num: num,
        time: time,
        src: src,
        dst: dst,
        proto: proto,
        len: origLen,
        info: info,
        layers: layers,
        raw: raw
    };
}

/* =====================================================================
   RENDERING
===================================================================== */

function protoClass(p) {
    return p.toLowerCase().replace(/[^a-z0-9]/g, '');
}

function renderSummary(packets, meta) {
    var protoCounts = {};
    var totalBytes = 0;
    var minTime = Infinity, maxTime = -Infinity;

    packets.forEach(function (p) {
        protoCounts[p.proto] = (protoCounts[p.proto] || 0) + 1;
        totalBytes += p.len;
        if (p.time < minTime) minTime = p.time;
        if (p.time > maxTime) maxTime = p.time;
    });

    var topProtos = Object.keys(protoCounts)
        .sort(function (a, b) { return protoCounts[b] - protoCounts[a]; })
        .slice(0, 4)
        .map(function (k) { return k + ' (' + protoCounts[k] + ')'; })
        .join(', ');

    var duration = (isFinite(maxTime) && isFinite(minTime)) ? Math.max(0, maxTime - minTime) : 0;
    var linkNames = { 0: 'BSD loopback', 1: 'Ethernet', 101: 'Raw IP', 113: 'Linux cooked (SLL)' };

    var stats = [
        ['Packets', packets.length.toLocaleString()],
        ['Total Size', fmtBytes(totalBytes)],
        ['Duration', duration.toFixed(3) + ' s'],
        ['Link Type', linkNames[state.linkType] || ('Type ' + state.linkType)],
        ['Top Protocols', topProtos || '—']
    ];

    els.summary.innerHTML = stats.map(function (s) {
        return '<div class="ta-stat"><div class="ta-stat-label">' + esc(s[0]) + '</div><div class="ta-stat-value">' + esc(s[1]) + '</div></div>';
    }).join('');
}

function matchesFilter(p, needle) {
    if (!needle) return true;
    var hay = (p.src + ' ' + p.dst + ' ' + p.proto + ' ' + p.info + ' ' + p.len).toLowerCase();
    return hay.indexOf(needle) !== -1;
}

function getFiltered() {
    var needle = els.filter.value.trim().toLowerCase();
    if (!needle) return state.packets;
    return state.packets.filter(function (p) { return matchesFilter(p, needle); });
}

function renderTable() {
    var list = getFiltered();
    state.filtered = list;

    var totalPages = Math.max(1, Math.ceil(list.length / state.pageSize));
    if (state.page >= totalPages) state.page = totalPages - 1;
    if (state.page < 0) state.page = 0;

    var start = state.page * state.pageSize;
    var pageItems = list.slice(start, start + state.pageSize);

    els.count.textContent = list.length.toLocaleString() + ' packet' + (list.length === 1 ? '' : 's') +
        (list.length !== state.packets.length ? ' (of ' + state.packets.length.toLocaleString() + ')' : '');

    var rows = pageItems.map(function (p) {
        var cls = protoClass(p.proto);
        return '<tr data-num="' + p.num + '"' + (p.num === state.selected ? ' class="sel"' : '') + '>' +
            '<td>' + p.num + '</td>' +
            '<td>' + esc(p.time.toFixed(6)) + '</td>' +
            '<td>' + esc(p.src) + '</td>' +
            '<td>' + esc(p.dst) + '</td>' +
            '<td><span class="ta-proto ' + cls + '">' + esc(p.proto) + '</span></td>' +
            '<td>' + p.len + '</td>' +
            '<td class="wrap">' + esc(p.info) + '</td>' +
            '</tr>';
    }).join('');

    els.tableBody.innerHTML = rows || '<tr><td colspan="7" style="text-align:center;color:var(--text-muted);padding:20px;">No packets match this filter</td></tr>';

    els.pageInfo.textContent = list.length
        ? 'Page ' + (state.page + 1) + ' of ' + totalPages + ' (' + state.pageSize + ' / page)'
        : '';
    els.prevPage.disabled = state.page <= 0;
    els.nextPage.disabled = state.page >= totalPages - 1;
}

function renderDetail(packet) {
    if (!packet) {
        els.tree.innerHTML = '<div class="ta-empty">No packet selected</div>';
        els.hex.textContent = 'No packet selected';
        els.detailSub.textContent = 'Select a packet above';
        return;
    }

    els.detailSub.textContent = 'Packet #' + packet.num + ' — ' + packet.proto;

    els.tree.innerHTML = packet.layers.map(function (layer, idx) {
        var fields = layer.fields.map(function (f) {
            return '<div class="ta-tree-field"><span class="k">' + esc(f[0]) + '</span><span class="v">' + esc(f[1]) + '</span></div>';
        }).join('');
        return '<details class="ta-tree-node"' + (idx < 2 ? ' open' : '') + '>' +
            '<summary>' + esc(layer.name) + '</summary>' +
            '<div class="ta-tree-fields">' + fields + '</div>' +
            '</details>';
    }).join('');

    els.hex.innerHTML = renderHexDump(packet.raw);
}

function renderHexDump(raw) {
    var lines = [];
    for (var i = 0; i < raw.length; i += 16) {
        var chunk = raw.slice(i, i + 16);
        var hexParts = [];
        var asciiParts = [];
        for (var j = 0; j < 16; j++) {
            if (j < chunk.length) {
                hexParts.push(hexByte(chunk[j]));
                var c = chunk[j];
                asciiParts.push((c >= 32 && c <= 126) ? String.fromCharCode(c) : '.');
            } else {
                hexParts.push('  ');
            }
            if (j === 7) hexParts.push('');
        }
        var offsetStr = i.toString(16).padStart(6, '0');
        lines.push('<span class="off">' + offsetStr + '</span>  ' + hexParts.join(' ') + '  <span class="ascii">' + esc(asciiParts.join('')) + '</span>');
    }
    return lines.join('\n') || '(empty packet)';
}

/* =====================================================================
   FILE HANDLING
===================================================================== */

function loadFile(file) {
    clearError();

    var reader = new FileReader();
    reader.onerror = function () {
        showError('Could not read the file.');
    };
    reader.onload = function (e) {
        try {
            var buf = e.target.result;
            if (buf.byteLength < 4) throw new Error('File is too small to be a valid capture.');

            var dv = new DataView(buf);
            var magic = dv.getUint32(0, false);
            var packets;

            if (magic === 0x0A0D0D0A) {
                packets = parsePcapng(buf);
            } else if (magic === 0xa1b2c3d4 || magic === 0xd4c3b2a1 || magic === 0xa1b23c4d || magic === 0x4d3cb2a1) {
                packets = parseClassicPcap(buf);
            } else {
                throw new Error('Unrecognized file format. Expected a .pcap or .pcapng capture.');
            }

            if (!packets.length) throw new Error('No packets could be parsed from this file.');

            state.packets = packets;
            state.page = 0;
            state.selected = -1;

            els.fileName.textContent = file.name;
            els.fileMeta.textContent = fmtBytes(file.size) + ' — loaded ' + packets.length.toLocaleString() + ' packets';

            renderSummary(packets);
            els.filter.value = '';
            renderTable();
            renderDetail(null);

            els.uploadCard.style.display = 'none';
            els.results.style.display = 'block';
        } catch (err) {
            showError(err.message || 'Failed to parse this capture file.');
        }
    };
    reader.readAsArrayBuffer(file);
}

/* =====================================================================
   EVENTS
===================================================================== */

els.dropzone.addEventListener('click', function () { els.fileInput.click(); });

els.fileInput.addEventListener('change', function () {
    if (this.files && this.files[0]) loadFile(this.files[0]);
});

['dragenter', 'dragover'].forEach(function (evt) {
    els.dropzone.addEventListener(evt, function (e) {
        e.preventDefault();
        els.dropzone.classList.add('drag');
    });
});

['dragleave', 'drop'].forEach(function (evt) {
    els.dropzone.addEventListener(evt, function (e) {
        e.preventDefault();
        els.dropzone.classList.remove('drag');
    });
});

els.dropzone.addEventListener('drop', function (e) {
    var file = e.dataTransfer.files && e.dataTransfer.files[0];
    if (file) loadFile(file);
});

els.filter.addEventListener('input', function () {
    state.page = 0;
    renderTable();
});

els.clearFilter.addEventListener('click', function () {
    els.filter.value = '';
    state.page = 0;
    renderTable();
});

els.tableBody.addEventListener('click', function (e) {
    var row = e.target.closest('tr[data-num]');
    if (!row) return;
    var num = parseInt(row.getAttribute('data-num'), 10);
    state.selected = num;
    var packet = state.packets.find(function (p) { return p.num === num; });
    renderTable();
    renderDetail(packet);
});

els.prevPage.addEventListener('click', function () {
    if (state.page > 0) { state.page--; renderTable(); }
});

els.nextPage.addEventListener('click', function () {
    state.page++; renderTable();
});

els.loadAnother.addEventListener('click', function () {
    els.fileInput.value = '';
    state.packets = [];
    state.selected = -1;
    els.results.style.display = 'none';
    els.uploadCard.style.display = 'block';
    clearError();
});

})();
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
