<?php

/*
| No session_start() here on purpose.
|
| config/db.php runs securityBootstrap(), which starts the session with
| hardened cookie flags (HttpOnly, SameSite=Lax, Secure over TLS) and
| session.use_strict_mode. Starting the session first would create the
| cookie before those parameters could be applied -- on the login page of
| all places, where the session that gets issued is the authenticated one.
*/

require_once "config/db.php";
require_once "includes/ldap-helpers.php";
require_once "includes/branding-helpers.php";

$appName = getAppName($pdo);
$appLogoUrl = getAppLogoUrl($pdo);

$message = "";
$lockoutNotice = "";

// Shown after securityEnforceSessionTimeouts() expires an idle session.
if (isset($_GET['timeout'])) {
    $message = "Your session expired after a period of inactivity. Please sign in again.";
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $ncgr_id  = trim($_POST['ncgr_id']);
    $password = $_POST['password'];

    // Opportunistic housekeeping -- keeps login_attempts bounded in a
    // deployment with no cron.
    pruneLoginAttempts($pdo);

    $lockout = checkLoginLockout($pdo, $ncgr_id);

    if ($lockout['locked']) {

        /*
        | Locked: no credential check happens at all, so a locked-out
        | attacker cannot keep testing passwords, and cannot use response
        | differences to tell a real account from a non-existent one.
        */
        $minutes = (int) ceil($lockout['seconds_remaining'] / 60);
        $message = "Too many failed sign-in attempts. Try again in {$minutes} minute"
            . ($minutes === 1 ? '' : 's') . ".";

        $user = null;
        $ncgr_id = '';

    } else {

    $stmt = $pdo->prepare("
        SELECT *
        FROM users
        WHERE ncgr_id = ?
        LIMIT 1
    ");

    $stmt->execute([$ncgr_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($user && ($user['auth_source'] ?? 'local') === 'ldap') {

        /*
        |--------------------------------------------------------------------------
        | Existing LDAP-sourced account -- always re-verified live against the
        | directory. The local password column holds an unusable placeholder
        | hash for these accounts (see the creation branch below); it is
        | never checked.
        |--------------------------------------------------------------------------
        */

        $ldapResult = authenticateAgainstLdap($pdo, $ncgr_id, $password);

        if (!$ldapResult['success']) {

            recordLoginAttempt($pdo, $ncgr_id, false);
            $message = "Invalid password.";

        } elseif ((int) $user['is_approved'] !== 1) {

            // The bind succeeded, so this is not a credential failure and
            // must not count toward the lockout.
            recordLoginAttempt($pdo, $ncgr_id, true);
            $message = "Your account is waiting for administrator approval.";

        } else {

            // Keep name/email in sync with the directory on every login.
            $attrs = $ldapResult['attributes'];
            $pdo->prepare("
                UPDATE users SET first_name = ?, last_name = ?, email = ?
                WHERE id = ?
            ")->execute([$attrs['first_name'], $attrs['last_name'], $attrs['email'], $user['id']]);

            recordLoginAttempt($pdo, $ncgr_id, true);

            // Rotates the session id and stamps the idle/absolute timers
            // that securityEnforceSessionTimeouts() reads on later requests.
            securityOnLogin();

            $_SESSION['user_id'] = $user['id'];
            $_SESSION['name'] = $attrs['first_name'] . " " . $attrs['last_name'];
            $_SESSION['role'] = $user['role'];
            $_SESSION['team'] = $user['team'] ?? '';
            $_SESSION['avatar'] = $user['avatar'] ?? 'initials';
            $_SESSION['theme'] = $user['theme'] ?? 'light';

            // Read once by home.php to play a one-time arrival animation --
            // never set for ordinary in-app navigation back to the dashboard.
            $_SESSION['just_logged_in'] = 1;

            header("Location: home.php");
            exit;
        }

    } elseif ($user) {

        /*
        |--------------------------------------------------------------------------
        | Local account -- unchanged behavior.
        |--------------------------------------------------------------------------
        */

        if (password_verify($password, $user['password'])) {


            if ($user['is_approved'] == 1) {


                recordLoginAttempt($pdo, $ncgr_id, true);

                securityOnLogin();


                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] =
                    $user['first_name']." ".$user['last_name'];

                $_SESSION['role'] = $user['role'];
                $_SESSION['team'] = $user['team'] ?? '';
                $_SESSION['avatar'] = $user['avatar'] ?? 'initials';
                $_SESSION['theme'] = $user['theme'] ?? 'light';


                /*
                | Set by forgot-password.php when it mails a temporary
                | password. securityEnforcePasswordChange() reads this copy on
                | every subsequent request, so the redirect below cannot be
                | stepped around by typing another URL.
                |
                | Only local accounts can carry it: an LDAP password is never
                | stored here, so the branch above has nothing to rotate.
                */
                if ((int) ($user['must_change_password'] ?? 0) === 1) {

                    $_SESSION['must_change_password'] = 1;

                    header("Location: change-password.php");
                    exit;
                }


                // Read once by home.php to play a one-time arrival animation --
                // never set for ordinary in-app navigation back to the dashboard.
                $_SESSION['just_logged_in'] = 1;

                header("Location: home.php");
                exit;


            } else {

                // Correct password, unapproved account -- not a credential
                // failure, so it must not count toward the lockout.
                recordLoginAttempt($pdo, $ncgr_id, true);

                $message =
                "Your account is waiting for administrator approval.";

            }


        } else {

            recordLoginAttempt($pdo, $ncgr_id, false);

            $message = "Invalid password.";

        }


    } elseif (isLdapEnabled($pdo)) {

        /*
        |--------------------------------------------------------------------------
        | Not a known local or previously-seen LDAP account. If LDAP auth is
        | on, try it as a first-time LDAP login: a successful bind creates a
        | new pending account (is_approved=0) that goes through the exact
        | same admin-approval flow in users.php that signup.php uses.
        |--------------------------------------------------------------------------
        */

        $ldapResult = authenticateAgainstLdap($pdo, $ncgr_id, $password);

        if (!$ldapResult['success']) {

            recordLoginAttempt($pdo, $ncgr_id, false);
            $message = "User not found.";

        } else {

            $attrs = $ldapResult['attributes'];

            // A real password is never known/stored for LDAP accounts --
            // this placeholder can't match any password a user could type,
            // it only exists to satisfy the NOT NULL column.
            $unusablePassword = password_hash(bin2hex(random_bytes(32)), PASSWORD_DEFAULT);

            $ldapSettings = getLdapSettingsRow($pdo);

            try {
                $pdo->prepare("
                    INSERT INTO users
                        (ncgr_id, first_name, last_name, email, team, password, role, is_approved, auth_source)
                    VALUES
                        (?, ?, ?, ?, '', ?, ?, 0, 'ldap')
                ")->execute([
                    $attrs['samaccountname'],
                    $attrs['first_name'],
                    $attrs['last_name'],
                    $attrs['email'],
                    $unusablePassword,
                    $ldapSettings['default_role'],
                ]);

                $message = "Account created from directory login. Your account is waiting for administrator approval.";

            } catch (Throwable $e) {
                $message = "Unable to create your account: " . $e->getMessage();
            }
        }

    } else {

        // Unknown account still counts, otherwise the lockout could be
        // sidestepped entirely by guessing usernames rather than passwords.
        recordLoginAttempt($pdo, $ncgr_id, false);

        $message = "User not found.";

    }

    } // end: not locked out

}

$isTimeoutNotice = ($message !== '' && isset($_GET['timeout']));

?>


<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login | <?= htmlspecialchars($appName) ?></title>
<link rel="icon" href="<?= htmlspecialchars($appLogoUrl) ?>">

<style>

@font-face {
    font-family: Inter;
    src: url("assets/webfonts/Inter-Regular.woff2") format("woff2");
    font-weight: 400 700;
}

:root {
    --navy-950: #020617;
    --navy-900: #0B1220;
    --navy-800: #0F172A;
    --accent: #22D3EE;
    --accent-2: #2563EB;
    --accent-2-hover: #1D4ED8;
    --indigo: #4F46E5;
    --ink: #0F172A;
    --muted: #64748B;
    --border: #E2E8F0;
    --danger-bg: #FEF2F2;
    --danger-border: #FECACA;
    --danger-ink: #991B1B;
    --info-bg: #EFF6FF;
    --info-border: #BFDBFE;
    --info-ink: #1D4ED8;
}

* {
    box-sizing: border-box;
}

html, body {
    height: 100%;
}

body {
    margin: 0;
    min-height: 100vh;
    background: var(--navy-950);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    color: var(--ink);
    position: relative;
    overflow-x: hidden;
}

/* =========================
   DATACENTER BACKDROP
========================= */

.backdrop {
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    z-index: 0;
}

.backdrop svg {
    width: 100%;
    height: 100%;
    display: block;
}

/* =========================
   PAGE LAYOUT
========================= */

.page {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 56px 20px 40px;
}

.lockup {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 34px;
}

.lockup img {
    width: 30px;
    height: 30px;
}

.lockup span {
    font-size: 15px;
    font-weight: 800;
    letter-spacing: .02em;
    color: #F1F5F9;
}

/* =========================
   CARD
========================= */

.card-wrap {
    position: relative;
    width: 100%;
    max-width: 430px;
}

.badge {
    position: absolute;
    top: -30px;
    left: 50%;
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-2), var(--accent));
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 12px 30px rgba(34, 211, 238, .35), 0 0 0 6px rgba(255, 255, 255, .06);
    z-index: 2;
    animation: badgeFloat 3.6s ease-in-out infinite;
}

@keyframes badgeFloat {
    0%, 100% {
        transform: translateX(-50%) translateY(0);
        box-shadow: 0 12px 30px rgba(34, 211, 238, .35), 0 0 0 6px rgba(255, 255, 255, .06);
    }
    50% {
        transform: translateX(-50%) translateY(-7px);
        box-shadow: 0 18px 40px rgba(34, 211, 238, .5), 0 0 0 6px rgba(255, 255, 255, .06);
    }
}

@media (prefers-reduced-motion: reduce) {
    .badge {
        animation: none;
    }
}

.badge svg {
    width: 26px;
    height: 26px;
    color: #fff;
}

.card {
    position: relative;
    background: rgba(255, 255, 255, .78);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, .6);
    border-radius: 28px;
    padding: 52px 40px 36px;
    box-shadow: 0 25px 70px rgba(2, 6, 23, .45), inset 0 1px 0 rgba(255, 255, 255, .6);
    text-align: center;
}

.card h2 {
    font-size: 25px;
    font-weight: 800;
    color: var(--ink);
    margin: 0 0 6px;
    letter-spacing: -.01em;
}

.card-sub {
    color: var(--muted);
    font-size: 13.5px;
    margin: 0;
}

.banner {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 10px;
    margin: 18px 0 4px;
    font-size: 13px;
    line-height: 1.5;
    text-align: left;
    border: 1px solid transparent;
}

.banner svg {
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    margin-top: 1px;
}

.banner.error {
    background: var(--danger-bg);
    border-color: var(--danger-border);
    color: var(--danger-ink);
}

.banner.info {
    background: var(--info-bg);
    border-color: var(--info-border);
    color: var(--info-ink);
}

form {
    margin-top: 14px;
    text-align: left;
}

.field {
    margin-top: 16px;
}

.field label {
    display: block;
    margin-bottom: 7px;
    font-size: 12.5px;
    font-weight: 700;
    color: #334155;
}

.field-input {
    position: relative;
    display: flex;
    align-items: center;
}

.field-input svg.leading-icon {
    position: absolute;
    left: 15px;
    width: 16px;
    height: 16px;
    color: #94A3B8;
    pointer-events: none;
}

.field input {
    width: 100%;
    padding: 12px 14px 12px 42px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, .12);
    background: rgba(255, 255, 255, .7);
    font-size: 14px;
    font-family: inherit;
    color: var(--ink);
    transition: .15s;
}

.field input:focus {
    outline: none;
    border-color: var(--accent-2);
    background: rgba(255, 255, 255, .95);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .14);
}

.toggle-visibility {
    position: absolute;
    right: 5px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    background: transparent;
    color: #94A3B8;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.toggle-visibility:hover {
    background: #E2E8F0;
    color: #475569;
}

.toggle-visibility svg {
    width: 17px;
    height: 17px;
}

button.submit {
    width: 100%;
    margin-top: 26px;
    padding: 14px;
    border: none;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-2), var(--indigo));
    color: #fff;
    font-size: 14.5px;
    font-weight: 700;
    letter-spacing: .01em;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    transition: filter .15s, transform .1s;
}

button.submit:hover {
    filter: brightness(1.08);
}

button.submit:active {
    transform: translateY(1px);
}

button.submit:focus-visible {
    outline: none;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .3);
}

button.submit[disabled] {
    opacity: .75;
    cursor: not-allowed;
}

.spinner {
    width: 15px;
    height: 15px;
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, .4);
    border-top-color: #fff;
    animation: spin .7s linear infinite;
    display: none;
}

button.submit.loading .spinner {
    display: inline-block;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

/* Sits between the submit button and the "or" divider: a quiet text link,
   not a second button, so it never competes with Create New Account below. */
.forgot {
    margin-top: 16px;
    text-align: center;
}

.forgot a {
    font-size: 13px;
    font-weight: 600;
    color: var(--muted);
    text-decoration: none;
}

.forgot a:hover {
    color: var(--accent-2);
    text-decoration: underline;
}

.divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 18px 0 18px;
    color: #94A3B8;
    font-size: 11.5px;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.divider::before,
.divider::after {
    content: "";
    flex: 1;
    height: 1px;
    background: var(--border);
}

.signup a {
    display: block;
    padding: 12px;
    border-radius: 999px;
    border: 1px solid var(--border);
    color: #334155;
    text-decoration: none;
    font-weight: 700;
    font-size: 13.5px;
    transition: .15s;
}

.signup a:hover {
    background: #F8FAFC;
    border-color: #CBD5E1;
}

/* =========================
   CAPTION + TRUST STRIP
========================= */

.caption {
    margin-top: 34px;
    text-align: center;
    font-size: 12.5px;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgba(226, 232, 240, .75);
}

.trust-strip {
    margin-top: 18px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
}

.trust-chip {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 14px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .06);
    border: 1px solid rgba(255, 255, 255, .1);
    color: #CBD5E1;
    font-size: 12px;
    font-weight: 500;
}

.trust-chip svg {
    width: 13px;
    height: 13px;
    color: var(--accent);
}

.page-footer {
    margin-top: 26px;
    text-align: center;
    font-size: 11.5px;
    color: rgba(148, 163, 184, .6);
}

@media (max-width: 480px) {
    .card {
        padding: 46px 26px 30px;
    }
}

/* =========================
   LED BLINK (backdrop)
========================= */

@keyframes ledGlowBlink {
    0%, 44% { opacity: var(--glow-op, 0.55); }
    45%, 100% { opacity: 0.05; }
}

@keyframes ledCoreBlink {
    0%, 44% { opacity: 1; }
    45%, 100% { opacity: 0.12; }
}

.led-glow {
    animation-name: ledGlowBlink;
    animation-timing-function: steps(1, end);
    animation-iteration-count: infinite;
}

.led-core {
    animation-name: ledCoreBlink;
    animation-timing-function: steps(1, end);
    animation-iteration-count: infinite;
}

@keyframes blobBreathe {
    0%, 100% { opacity: var(--blob-op, 0.28); transform: scale(1); }
    50% { opacity: calc(var(--blob-op, 0.28) + 0.14); transform: scale(1.1); }
}

.glow-blob {
    transform-box: fill-box;
    transform-origin: center;
    animation-name: blobBreathe;
    animation-timing-function: ease-in-out;
    animation-iteration-count: infinite;
}

@keyframes particleRise {
    0% { transform: translateY(0); opacity: 0; }
    12% { opacity: .55; }
    88% { opacity: .35; }
    100% { transform: translateY(-860px); opacity: 0; }
}

.particle {
    animation-name: particleRise;
    animation-timing-function: linear;
    animation-iteration-count: infinite;
}

@media (prefers-reduced-motion: reduce) {
    .led-glow, .led-core, .glow-blob, .particle, .badge {
        animation: none;
    }
}

/* =========================
   SIGN-IN TRANSITION OVERLAY
========================= */

.auth-transition {
    position: fixed;
    inset: 0;
    z-index: 100000;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 18px;
    background: radial-gradient(circle at 30% 20%, var(--navy-800) 0%, var(--navy-900) 45%, var(--navy-950) 100%);
    opacity: 0;
    visibility: hidden;
    pointer-events: none;
    transition: opacity .35s ease;
}

.auth-transition.show {
    opacity: 1;
    visibility: visible;
    pointer-events: auto;
}

.auth-transition-orb {
    position: relative;
    width: 84px;
    height: 84px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-2), var(--accent));
    box-shadow: 0 0 60px rgba(34, 211, 238, .45);
    animation: authOrbPulse 1.4s ease-in-out infinite;
}

.auth-transition-orb::before {
    content: "";
    position: absolute;
    inset: -10px;
    border-radius: 50%;
    border: 3px solid transparent;
    border-top-color: var(--accent);
    border-right-color: var(--indigo);
    animation: authOrbSpin .9s linear infinite;
}

.auth-transition-orb svg {
    width: 36px;
    height: 36px;
    color: #fff;
}

.auth-transition-text {
    color: #F1F5F9;
    font: 700 16px/1.3 Inter, "Segoe UI", Arial, sans-serif;
    letter-spacing: .01em;
}

.auth-transition-bar {
    width: 160px;
    height: 4px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .1);
    overflow: hidden;
}

.auth-transition-bar span {
    display: block;
    height: 100%;
    width: 0%;
    border-radius: 999px;
    background: linear-gradient(90deg, var(--accent-2), var(--accent));
}

.auth-transition.show .auth-transition-bar span {
    animation: authBarFill 1.6s ease-out forwards;
}

@keyframes authOrbSpin {
    to { transform: rotate(360deg); }
}

@keyframes authOrbPulse {
    0%, 100% { transform: scale(1); }
    50% { transform: scale(1.06); }
}

@keyframes authBarFill {
    from { width: 0%; }
    to { width: 92%; }
}

@media (prefers-reduced-motion: reduce) {
    .auth-transition-orb,
    .auth-transition-orb::before,
    .auth-transition.show .auth-transition-bar span {
        animation: none;
    }
    .auth-transition.show .auth-transition-bar span {
        width: 92%;
    }
}

/* =========================
   CURSOR SPARKLE TRAIL
========================= */

#sparkle-layer {
    position: fixed;
    inset: 0;
    pointer-events: none;
    z-index: 9999;
}

.sparkle {
    position: fixed;
    top: 0;
    left: 0;
    width: var(--size);
    height: var(--size);
    background: radial-gradient(circle, #fff 0%, var(--sparkle-color) 55%, transparent 75%);
    clip-path: polygon(50% 0%, 61% 35%, 100% 50%, 61% 65%, 50% 100%, 39% 65%, 0% 50%, 39% 35%);
    pointer-events: none;
    animation: sparklePop .75s ease-out forwards;
}

@keyframes sparklePop {
    0% { transform: translate(-50%, -50%) rotate(var(--rot)) scale(0); opacity: 1; }
    35% { transform: translate(-50%, -50%) rotate(var(--rot)) scale(1); opacity: 1; }
    100% { transform: translate(-50%, -50%) translateY(-16px) rotate(var(--rot)) scale(.15); opacity: 0; }
}

</style>

</head>
<body>

<div class="backdrop" aria-hidden="true">
    <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">

        <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#020617"/>
                <stop offset="55%" stop-color="#0B1220"/>
                <stop offset="100%" stop-color="#0F172A"/>
            </linearGradient>

            <pattern id="floorGrid" width="64" height="64" patternUnits="userSpaceOnUse">
                <path d="M64 0H0V64" fill="none" stroke="#FFFFFF" stroke-opacity="0.045"/>
            </pattern>

            <filter id="blurBlob" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="75"/>
            </filter>

            <filter id="blurRacks" x="-30%" y="-30%" width="160%" height="160%">
                <feGaussianBlur stdDeviation="9"/>
            </filter>

            <filter id="ledGlow" x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur stdDeviation="6"/>
            </filter>
        </defs>

        <rect width="1600" height="900" fill="url(#bgGrad)"/>
        <rect width="1600" height="900" fill="url(#floorGrid)"/>

        <!-- ambient glow blobs -->
        <circle cx="230" cy="170" r="230" fill="#22D3EE" opacity="0.28" filter="url(#blurBlob)" class="glow-blob" style="--blob-op:0.28; animation-duration:7s; animation-delay:0s;"/>
        <circle cx="1370" cy="740" r="290" fill="#4F46E5" opacity="0.32" filter="url(#blurBlob)" class="glow-blob" style="--blob-op:0.32; animation-duration:8.5s; animation-delay:1.5s;"/>
        <circle cx="1250" cy="160" r="160" fill="#2563EB" opacity="0.18" filter="url(#blurBlob)" class="glow-blob" style="--blob-op:0.18; animation-duration:6.2s; animation-delay:.8s;"/>

        <!-- rising data-mote particles -->
        <g class="particles">
            <circle class="particle" cx="90"   cy="860" r="2.4" fill="#67E8F9" style="animation-duration:11s; animation-delay:0s;"/>
            <circle class="particle" cx="230"  cy="880" r="1.8" fill="#A5B4FC" style="animation-duration:9.5s; animation-delay:1.8s;"/>
            <circle class="particle" cx="410"  cy="850" r="2.2" fill="#67E8F9" style="animation-duration:12.5s; animation-delay:3.2s;"/>
            <circle class="particle" cx="560"  cy="890" r="1.6" fill="#6EE7B7" style="animation-duration:10.2s; animation-delay:.6s;"/>
            <circle class="particle" cx="700"  cy="870" r="2.6" fill="#93C5FD" style="animation-duration:13s;   animation-delay:2.4s;"/>
            <circle class="particle" cx="830"  cy="900" r="1.9" fill="#67E8F9" style="animation-duration:9s;   animation-delay:4.1s;"/>
            <circle class="particle" cx="960"  cy="860" r="2.1" fill="#A5B4FC" style="animation-duration:11.8s; animation-delay:1.1s;"/>
            <circle class="particle" cx="1080" cy="880" r="1.7" fill="#6EE7B7" style="animation-duration:10.6s; animation-delay:3.7s;"/>
            <circle class="particle" cx="1210" cy="850" r="2.5" fill="#67E8F9" style="animation-duration:12s;  animation-delay:.3s;"/>
            <circle class="particle" cx="1330" cy="895" r="1.8" fill="#93C5FD" style="animation-duration:9.8s; animation-delay:2.9s;"/>
            <circle class="particle" cx="1460" cy="865" r="2.3" fill="#A5B4FC" style="animation-duration:13.4s; animation-delay:1.6s;"/>
            <circle class="particle" cx="1550" cy="885" r="1.6" fill="#67E8F9" style="animation-duration:10.9s; animation-delay:4.6s;"/>
            <circle class="particle" cx="150"  cy="820" r="1.7" fill="#6EE7B7" style="animation-duration:12.2s; animation-delay:5.2s;"/>
            <circle class="particle" cx="1280" cy="820" r="1.9" fill="#93C5FD" style="animation-duration:11.2s; animation-delay:2.1s;"/>
        </g>

        <!-- server rack skyline, deliberately blurred so it reads as soft
             background depth behind the login card rather than sharp detail -->
        <g filter="url(#blurRacks)" opacity="0.65">

            <!-- rack 1 -->
            <rect x="60" y="720" width="110" height="180" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="750" x2="160" y2="750" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="790" x2="160" y2="790" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="830" x2="160" y2="830" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="870" x2="160" y2="870" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="148" cy="738" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.6s; animation-delay:0s;"/>
            <circle cx="148" cy="738" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.6s; animation-delay:0s;"/>
            <circle cx="148" cy="818" r="7" fill="#34D399" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.8s; animation-delay:0.4s;"/>
            <circle cx="148" cy="818" r="2.5" fill="#6EE7B7" class="led-core" style="animation-duration:.8s; animation-delay:0.4s;"/>

            <!-- rack 2 -->
            <rect x="200" y="660" width="110" height="240" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="690" x2="300" y2="690" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="730" x2="300" y2="730" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="770" x2="300" y2="770" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="810" x2="300" y2="810" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="850" x2="300" y2="850" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="288" cy="678" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.7s; animation-delay:0.9s;"/>
            <circle cx="288" cy="678" r="2.5" fill="#FDE68A" class="led-core" style="animation-duration:.7s; animation-delay:0.9s;"/>
            <circle cx="288" cy="758" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.5s; animation-delay:1.3s;"/>
            <circle cx="288" cy="758" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.5s; animation-delay:1.3s;"/>

            <!-- rack 3 -->
            <rect x="340" y="750" width="110" height="150" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="778" x2="440" y2="778" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="812" x2="440" y2="812" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="846" x2="440" y2="846" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="428" cy="766" r="6" fill="#34D399" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.85s; animation-delay:0.2s;"/>
            <circle cx="428" cy="766" r="2.2" fill="#6EE7B7" class="led-core" style="animation-duration:.85s; animation-delay:0.2s;"/>

            <!-- rack 4 -->
            <rect x="480" y="690" width="110" height="210" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="718" x2="580" y2="718" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="754" x2="580" y2="754" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="790" x2="580" y2="790" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="826" x2="580" y2="826" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="862" x2="580" y2="862" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="568" cy="706" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.6s; animation-delay:1.6s;"/>
            <circle cx="568" cy="706" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.6s; animation-delay:1.6s;"/>
            <circle cx="568" cy="838" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.75s; animation-delay:0.6s;"/>
            <circle cx="568" cy="838" r="2.5" fill="#FDE68A" class="led-core" style="animation-duration:.75s; animation-delay:0.6s;"/>

            <!-- right skyline (mirrored spacing) -->

            <!-- rack 5 -->
            <rect x="1010" y="700" width="110" height="200" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="728" x2="1110" y2="728" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="764" x2="1110" y2="764" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="800" x2="1110" y2="800" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="836" x2="1110" y2="836" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1098" cy="716" r="7" fill="#34D399" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.65s; animation-delay:1.1s;"/>
            <circle cx="1098" cy="716" r="2.5" fill="#6EE7B7" class="led-core" style="animation-duration:.65s; animation-delay:1.1s;"/>

            <!-- rack 6 -->
            <rect x="1150" y="640" width="110" height="260" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="668" x2="1250" y2="668" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="704" x2="1250" y2="704" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="740" x2="1250" y2="740" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="776" x2="1250" y2="776" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="812" x2="1250" y2="812" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="848" x2="1250" y2="848" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1238" cy="656" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.8s; animation-delay:0.3s;"/>
            <circle cx="1238" cy="656" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.8s; animation-delay:0.3s;"/>
            <circle cx="1238" cy="788" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.55s; animation-delay:1.8s;"/>
            <circle cx="1238" cy="788" r="2.5" fill="#FDE68A" class="led-core" style="animation-duration:.55s; animation-delay:1.8s;"/>

            <!-- rack 7 -->
            <rect x="1290" y="760" width="110" height="140" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1300" y1="788" x2="1390" y2="788" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1300" y1="820" x2="1390" y2="820" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1378" cy="776" r="6" fill="#34D399" opacity="0.5" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.5; animation-duration:.7s; animation-delay:0.7s;"/>
            <circle cx="1378" cy="776" r="2.2" fill="#6EE7B7" class="led-core" style="animation-duration:.7s; animation-delay:0.7s;"/>

            <!-- rack 8 -->
            <rect x="1430" y="670" width="110" height="230" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="698" x2="1530" y2="698" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="734" x2="1530" y2="734" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="770" x2="1530" y2="770" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="806" x2="1530" y2="806" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="842" x2="1530" y2="842" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1518" cy="686" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.9s; animation-delay:1.4s;"/>
            <circle cx="1518" cy="686" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.9s; animation-delay:1.4s;"/>
            <circle cx="1518" cy="818" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)" class="led-glow" style="--glow-op:0.55; animation-duration:.45s; animation-delay:0.5s;"/>
            <circle cx="1518" cy="818" r="2.5" fill="#67E8F9" class="led-core" style="animation-duration:.45s; animation-delay:0.5s;"/>

        </g>

        <!-- floor shadow to seat the racks and darken the lower edge -->
        <rect x="0" y="860" width="1600" height="40" fill="#020617" opacity="0.55"/>

    </svg>
</div>

<div class="page">

    <div class="lockup">
        <img src="<?= htmlspecialchars($appLogoUrl) ?>" alt="<?= htmlspecialchars($appName) ?>">
        <span><?= htmlspecialchars($appName) ?></span>
    </div>

    <div class="card-wrap">

        <div class="badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
        </div>

        <div class="card">

            <h2>Welcome back</h2>
            <p class="card-sub">Sign in to your <?= htmlspecialchars($appName) ?> account</p>

            <?php if ($message): ?>

                <div class="banner <?= $isTimeoutNotice ? 'info' : 'error' ?>">
                    <?php if ($isTimeoutNotice): ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <path d="M12 7v5l3.5 2"/>
                        </svg>
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <line x1="12" y1="8" x2="12" y2="13"/>
                            <line x1="12" y1="16" x2="12" y2="16"/>
                        </svg>
                    <?php endif; ?>
                    <span><?= htmlspecialchars($message) ?></span>
                </div>

            <?php endif; ?>

            <form method="POST" id="loginForm">

                <div class="field">
                    <label for="ncgr_id">NCGR ID</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        <input
                            type="text"
                            id="ncgr_id"
                            name="ncgr_id"
                            autocomplete="username"
                            value="<?= htmlspecialchars($ncgr_id ?? '') ?>"
                            required
                            autofocus
                        >
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="11" width="16" height="9" rx="2"/>
                            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                        </svg>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            autocomplete="current-password"
                            required
                        >
                        <button type="button" class="toggle-visibility" id="togglePassword" aria-label="Show password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <button type="submit" class="submit" id="submitBtn">
                    <span class="spinner"></span>
                    <span>Sign In</span>
                </button>

            </form>

            <div class="forgot">
                <a href="forgot-password.php">Forgot your password?</a>
            </div>

            <div class="divider">or</div>

            <div class="signup">
                <a href="signup.php">Create New Account</a>
            </div>

        </div>

    </div>

    <div class="caption">Enterprise IT Management Platform</div>

    <div class="trust-strip">

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Secure Asset Management
        </span>

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="3" width="20" height="7" rx="1.5"/>
                <rect x="2" y="14" width="20" height="7" rx="1.5"/>
            </svg>
            Infrastructure Control
        </span>

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="11" width="18" height="10" rx="2"/>
                <path d="M7 11V7a5 5 0 0 1 9.9-1"/>
            </svg>
            Offline Enterprise Platform
        </span>

    </div>

    <div class="page-footer">
        &copy; <?= date('Y') ?> <?= htmlspecialchars($appName) ?> &middot; Internal Enterprise Platform &middot; All access is logged
    </div>

</div>

<div class="auth-transition" id="authTransition" aria-hidden="true">
    <div class="auth-transition-orb">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
        </svg>
    </div>
    <div class="auth-transition-text">Signing you in&hellip;</div>
    <div class="auth-transition-bar"><span></span></div>
</div>

<script>
(function () {
    const toggleBtn = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');

    toggleBtn.addEventListener('click', function () {
        const isHidden = passwordInput.type === 'password';
        passwordInput.type = isHidden ? 'text' : 'password';
        toggleBtn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
    });

    const form = document.getElementById('loginForm');
    const submitBtn = document.getElementById('submitBtn');
    const authTransition = document.getElementById('authTransition');

    form.addEventListener('submit', function () {
        submitBtn.classList.add('loading');
        submitBtn.setAttribute('disabled', 'disabled');
        if (authTransition) {
            authTransition.classList.add('show');
        }
    });
})();

(function () {
    const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduceMotion) return;

    const colors = ['#22D3EE', '#67E8F9', '#A5B4FC', '#FFFFFF', '#4F46E5'];

    const layer = document.createElement('div');
    layer.id = 'sparkle-layer';
    document.body.appendChild(layer);

    let lastSpawn = 0;

    document.addEventListener('mousemove', function (e) {
        const now = performance.now();
        if (now - lastSpawn < 45) return;
        lastSpawn = now;

        if (layer.childElementCount > 40) return;

        const sparkle = document.createElement('span');
        sparkle.className = 'sparkle';
        const size = 6 + Math.random() * 9;
        sparkle.style.setProperty('--size', size + 'px');
        sparkle.style.setProperty('--rot', (Math.random() * 360) + 'deg');
        sparkle.style.setProperty('--sparkle-color', colors[Math.floor(Math.random() * colors.length)]);
        sparkle.style.left = (e.clientX + (Math.random() * 14 - 7)) + 'px';
        sparkle.style.top = (e.clientY + (Math.random() * 14 - 7)) + 'px';

        sparkle.addEventListener('animationend', function () {
            sparkle.remove();
        });

        layer.appendChild(sparkle);
    }, { passive: true });
})();
</script>

</body>
</html>
