<?php
session_start();
require "config/db.php";
if(!isset($_SESSION['user_id'])){
    header("Location:index.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('ip', 'can_view');
requirePermission('ip', 'can_audit');



/*
|--------------------------------------------------------------------------
| PERMISSION HELPER (same page_key/model as ip.php)
|--------------------------------------------------------------------------
*/

function ipHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'ip', $permission);
}


$role = trim($_SESSION['role'] ?? '');
$canAudit = ipHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| RECORD ID (per-row drill-down from ip.php's History button)
|--------------------------------------------------------------------------
|
| When ?id=<ip_ranges.id> is present, this is the AJAX call made from
| the modal on ip.php (openHistory(id) -> fetch("ip-history.php?id=...")).
| That call expects back a small HTML fragment -- just the log rows for
| that ONE record -- not the full page. Rendering the full page here
| (header, sidebar, search box, doctype) was the bug: the entire page's
| HTML was being stuffed into the modal's innerHTML.
|
| When id is absent, this is a normal full-page visit (the toolbar's
| "History" link), so it keeps the full page layout with search.
|
*/

$recordId = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$isFragment = $recordId > 0;


/*
|--------------------------------------------------------------------------
| PERMISSION CHECK
|--------------------------------------------------------------------------
*/

if (!$canAudit) {

    http_response_code(403);

    if ($isFragment) {
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
    } else {
        echo 'You do not have permission to view audit history.';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| FRAGMENT MODE (per-record, no header/sidebar)
|--------------------------------------------------------------------------
*/

if ($isFragment) {

    $stmt = $pdo->prepare("
        SELECT
            h.*,
            i.ip_range
        FROM ip_ranges_history h
        LEFT JOIN ip_ranges i
            ON i.id = h.ip_range_id
        WHERE h.ip_range_id = ?
        ORDER BY h.id DESC
    ");

    $stmt->execute([$recordId]);

    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($history) > 0) {

        echo '<table class="ip-table audit-table">';
        echo '<thead><tr>
                <th>Action</th>
                <th>Performed By</th>
                <th>Details</th>
                <th>Date</th>
              </tr></thead>';
        echo '<tbody>';

        foreach ($history as $h) {

            echo '<tr>';

            echo '<td>';
            if ($h['action_type'] === 'CREATE') {
                echo '<span class="environment" style="background:#dcfce7;color:#166534">CREATE</span>';
            } elseif ($h['action_type'] === 'UPDATE') {
                echo '<span class="environment" style="background:#fef3c7;color:#92400e">UPDATE</span>';
            } else {
                echo '<span class="environment" style="background:#fee2e2;color:#991b1b">' . htmlspecialchars((string)($h['action_type'] ?? '')) . '</span>';
            }
            echo '</td>';

            echo '<td>' . htmlspecialchars((string)($h['performed_by'] ?? '')) . '</td>';
            echo '<td class="audit-details">' . nl2br(htmlspecialchars((string)($h['details'] ?? ''))) . '</td>';
            echo '<td>' . htmlspecialchars((string)($h['timestamp'] ?? '')) . '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';

    } else {

        echo '<p class="empty-state">No history found for this IP range.</p>';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| FULL PAGE MODE (toolbar's "History" link -- browse everything)
|--------------------------------------------------------------------------
*/

$page_title = "IP History | InfraVault";

include "includes/header.php";
include "includes/sidebar.php";

$keyword = trim($_GET['keyword'] ?? "");

if($keyword!=""){
$stmt=$pdo->prepare("
SELECT 
h.*,
i.ip_range
FROM ip_ranges_history h
LEFT JOIN ip_ranges i
ON i.id=h.ip_range_id
WHERE 
i.ip_range LIKE ?
OR h.performed_by LIKE ?
OR h.action_type LIKE ?
ORDER BY h.id DESC
");
$search="%".$keyword."%";
$stmt->execute([
$search,
$search,
$search
]);
}else{
$stmt=$pdo->query("
SELECT
h.*,
i.ip_range
FROM ip_ranges_history h
LEFT JOIN ip_ranges i
ON i.id=h.ip_range_id
ORDER BY h.id DESC
");
}
$history=$stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<link rel="stylesheet" href="assets/css/ip.css">
<div class="content">
<div class="ip-page">
<div class="page-header">
<div>
<h1>
IP Address History
</h1>
<p>
Audit trail for IP range changes
</p>
</div>
<a href="ip.php"
class="secondary-btn">
Back to IPAM
</a>
</div>
<div class="ip-toolbar">
<form method="GET">
<input
type="text"
name="keyword"
placeholder="Search IP, User, Action..."
value="<?=htmlspecialchars($keyword)?>"
>
<button class="primary-btn">
Search
</button>
</form>
</div>
<div class="ip-card">
<table class="ip-table">
<thead>
<tr>
<th>
IP Range
</th>
<th>
Action
</th>
<th>
Performed By
</th>
<th>
Details
</th>
<th>
Date
</th>
</tr>
</thead>
<tbody>
<?php if(count($history)): ?>
<?php foreach($history as $h): ?>
<tr>
<td>
<span class="ip-tag">
<?=htmlspecialchars($h['ip_range'] ?? 'Deleted Record')?>
</span>
</td>
<td>
<?php if($h['action_type']=="CREATE"): ?>
<span class="environment"
style="background:#dcfce7;color:#166534">
CREATE
</span>
<?php elseif($h['action_type']=="UPDATE"): ?>
<span class="environment"
style="background:#fef3c7;color:#92400e">
UPDATE
</span>
<?php else: ?>
<span class="environment"
style="background:#fee2e2;color:#991b1b">
DELETE
</span>
<?php endif; ?>
</td>
<td>
<?=htmlspecialchars($h['performed_by'])?>
</td>
<td>
<?=htmlspecialchars($h['details'])?>
</td>
<td>
<?=htmlspecialchars($h['timestamp'])?>
</td>
</tr>
<?php endforeach; ?>
<?php else: ?>
<tr>
<td colspan="5"
class="empty">
No history found
</td>
</tr>
<?php endif; ?>
</tbody>
</table>
</div>
</div>
</div>
<?php include "includes/footer.php"; ?>
