<?php
session_start();
require 'config/db.php';
require_once 'includes/pagination-helpers.php';

// PHP 8.4-safe POST helper. Prevents trim(null) deprecation warnings.
function postValue(string $key, string $default = ''): string
{
    if (!isset($_POST[$key]) || $_POST[$key] === null) {
        return $default;
    }
    return trim((string) $_POST[$key]);
}

// Enterprise-style inline SVG icons (no external icon library required).
function svgIcon(string $name, string $class = 'ui-icon'): string
{
    $paths = [
        'plus' => '<path d="M12 5v14M5 12h14"/>',
        'upload' => '<path d="M12 16V4m0 0-4 4m4-4 4 4"/><path d="M5 13v5a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-5"/>',
        'download' => '<path d="M12 4v12m0 0-4-4m4 4 4-4"/><path d="M5 20h14"/>',
        'history' => '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/><path d="M12 7v5l3 2"/>',
        'settings' => '<path d="M12 15.5a3.5 3.5 0 1 0 0-7 3.5 3.5 0 0 0 0 7Z"/><path d="m19.4 15 .1.1a2 2 0 0 1-2.8 2.8l-.1-.1a2 2 0 0 0-3.4 1.4V19a2 2 0 0 1-4 0v-.1A2 2 0 0 0 5.8 17l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1A2 2 0 0 0 1.6 11H1.5a2 2 0 0 1 0-4h.1A2 2 0 0 0 3 3.6l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1A2 2 0 0 0 9.2 2V1.9a2 2 0 0 1 4 0V2a2 2 0 0 0 3.4 1.4l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1A2 2 0 0 0 20.8 10h.1a2 2 0 0 1 0 4h-.1a2 2 0 0 0-1.4 1Z" transform="scale(.75) translate(4 4)"/>',
        'search' => '<circle cx="11" cy="11" r="6.5"/><path d="m16 16 4 4"/>',
        'filter' => '<path d="M4 5h16M7 12h10M10 19h4"/>',
        'eye' => '<path d="M2.5 12s3.2-6 9.5-6 9.5 6 9.5 6-3.2 6-9.5 6-9.5-6-9.5-6Z"/><circle cx="12" cy="12" r="2.5"/>',
        'edit' => '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14.5 7.5 3 3"/>',
        'clone' => '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
        'trash' => '<path d="M4 7h16M10 11v5m4-5v5M6 7l1 13h10l1-13M9 7V4h6v3"/>',
        'save' => '<path d="M5 4h11l3 3v13H5V4Z"/><path d="M8 4v6h8V4M8 20v-6h8v6"/>',
        'close' => '<path d="m6 6 12 12M18 6 6 18"/>',
        'check' => '<path d="m5 12 4 4L19 6"/>',
        'copy' => '<rect x="8" y="8" width="11" height="11" rx="2"/><path d="M16 8V6a2 2 0 0 0-2-2H6a2 2 0 0 0-2 2v8a2 2 0 0 0 2 2h2"/>',
    ];
    $body = $paths[$name] ?? $paths['settings'];
    return '<svg class="'.htmlspecialchars($class, ENT_QUOTES, 'UTF-8').'" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$body.'</svg>';
}

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$role = trim((string)($_SESSION['role'] ?? ''));
$user_id = (int)($_SESSION['user_id'] ?? 0);

/*
 * Resolve the current username from the users table instead of relying on
 * session first_name/ncgr_id values. This keeps inventory history consistent.
 */
$username = 'Unknown User';

if ($user_id > 0) {
    try {
        $userStmt = $pdo->prepare("
            SELECT first_name, last_name, ncgr_id
            FROM users
            WHERE id = ?
            LIMIT 1
        ");
        $userStmt->execute([$user_id]);
        $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

        if ($currentUser) {
            $firstName = trim((string)($currentUser['first_name'] ?? ''));
            $lastName  = trim((string)($currentUser['last_name'] ?? ''));
            $ncgrId    = trim((string)($currentUser['ncgr_id'] ?? ''));

            $fullName = trim($firstName . ' ' . $lastName);

            if ($fullName !== '' && $ncgrId !== '') {
                $username = $fullName . ' (' . $ncgrId . ')';
            } elseif ($fullName !== '') {
                $username = $fullName;
            } elseif ($ncgrId !== '') {
                $username = $ncgrId;
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to resolve current inventory username: ' . $e->getMessage());
    }
}

/*
 * Inventory permission model.
 *
 * permissions:
 * role, page_key, can_view, can_edit, can_delete,
 * can_export, can_import, can_audit
 */
function inventoryHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'inventory', $permission);
}

$canView       = inventoryHasPermission($pdo, $role, 'can_view');
$canEdit       = inventoryHasPermission($pdo, $role, 'can_edit');
$canDelete     = inventoryHasPermission($pdo, $role, 'can_delete');
$canExport     = inventoryHasPermission($pdo, $role, 'can_export');
$canImport     = inventoryHasPermission($pdo, $role, 'can_import');
$canViewHistory = inventoryHasPermission($pdo, $role, 'can_audit');

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view the Inventory page.');
}

$msg = "";
$error = "";

// AJAX HW Model Lookup from asset table
if (isset($_GET['action']) && $_GET['action'] === 'search_hardware') {
    header('Content-Type: application/json; charset=utf-8');
    $q = trim((string)($_GET['q'] ?? ''));
    try {
        $stmt = $pdo->prepare("SELECT asset_name, manufacturer, model, location FROM asset WHERE asset_name LIKE :q OR model LIKE :q LIMIT 15");
        $stmt->execute([':q' => '%' . $q . '%']);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $output = [];
        foreach ($results as $row) {
            $output[] = [
                'asset_name' => $row['asset_name'] ?? '',
                'manufacturer' => $row['manufacturer'] ?? ($row['model'] ?? 'N/A'),
                'location' => $row['location'] ?? ''
            ];
        }
        echo json_encode($output);
    } catch (Throwable $e) {
        echo json_encode([]);
    }
    exit;
}

function lookupIPDetails($pdo, $ip) {
    $ip = trim((string)$ip);
    if ($ip === '') return ['port_group' => '', 'vlan' => ''];

    try {
        $ranges = $pdo->query("SELECT ip_range, portgroup, vlan FROM ip_ranges")->fetchAll(PDO::FETCH_ASSOC);
        foreach ($ranges as $r) {
            $range = trim((string)($r['ip_range'] ?? ''));
            if ($range === '') continue;

            $lastDot = strrpos($range, '.');
            if ($lastDot === false) continue;

            $subnet_base = substr($range, 0, $lastDot + 1);
            if (strpos($ip, $subnet_base) === 0) {
                return [
                    'port_group' => $r['portgroup'] ?? '',
                    'vlan' => $r['vlan'] ?? ''
                ];
            }
        }
    } catch (Throwable $e) {
        // Return empty details if IPAM lookup fails.
    }

    return ['port_group' => '', 'vlan' => ''];
}

function lookupEolStatus($pdo, $product_name) {
    $product_name = trim((string)$product_name);
    if ($product_name === '') return ['matched' => false, 'eol_date' => '', 'is_past' => false];

    $stmt = $pdo->prepare("SELECT eol_date FROM license_warranty WHERE LOWER(TRIM(product_name)) = LOWER(?) AND eol_date IS NOT NULL AND eol_date != '' ORDER BY eol_date DESC LIMIT 1");
    $stmt->execute([$product_name]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) return ['matched' => false, 'eol_date' => '', 'is_past' => false];

    $eol_date = (string)$row['eol_date'];
    return [
        'matched' => true,
        'eol_date' => $eol_date,
        'is_past' => $eol_date < date('Y-m-d')
    ];
}

function lookupOwnershipDetails($pdo, $project, $support_level) {
    $project = trim((string)$project);
    $support_level = trim((string)$support_level);

    if ($project === '' || $support_level === '') return [];

    // ownership.support_level can now be a comma-joined list (one
    // owner covering several support levels, e.g. "Production,DR")
    // instead of a single exact value -- match against any entry in
    // that list rather than requiring an exact equal string.
    $stmt = $pdo->prepare("SELECT * FROM ownership WHERE project = ? AND (',' || support_level || ',') LIKE ? LIMIT 1");
    $stmt->execute([$project, '%,' . $support_level . ',%']);
    $own = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($own) {
        return [
            'technical_owner' => $own['technical_owner'] ?? '',
            'technical_owner_email' => $own['technical_owner_email'] ?? '',
            'team_dl' => $own['team_dl'] ?? '',
            'technical_manager' => $own['technical_manager'] ?? '',
            'technical_manager_email' => $own['technical_manager_email'] ?? '',
            'sdm_name' => $own['sdm_name'] ?? '',
            'sdm_email' => $own['sdm_email'] ?? '',
            'ncgr_owner' => $own['ncgr_owner'] ?? '',
            'ncgr_owner_email' => $own['ncgr_owner_email'] ?? ''
        ];
    }
    return [];
}

/*
 * Builds extra AND-ed WHERE clauses for the Advanced Search / Filters drawer.
 * Shared by the main listing query and the CSV export so both stay in sync.
 * Returns [ $clauses, $params ].
 */
function buildInventoryFilterClause(array $source): array
{
    $exactMap = [
        'filter_os_family' => 'os_family',
        'filter_support_level' => 'support_level',
        'filter_project' => 'project',
        'filter_server_state' => 'server_state',
        'filter_server_type' => 'server_type',
        'filter_criticality' => 'criticality',
        'filter_domain' => 'domain',
        'filter_managed_by' => 'managed_by',
        'filter_dmz' => 'dmz',
    ];

    $likeMap = [
        'filter_location' => 'location',
        'filter_application' => 'application',
    ];

    $clauses = [];
    $params = [];

    foreach ($exactMap as $key => $column) {
        $value = trim((string)($source[$key] ?? ''));
        if ($value !== '') {
            $clauses[] = "$column = ?";
            $params[] = $value;
        }
    }

    foreach ($likeMap as $key => $column) {
        $value = trim((string)($source[$key] ?? ''));
        if ($value !== '') {
            $clauses[] = "$column LIKE ?";
            $params[] = "%$value%";
        }
    }

    return [$clauses, $params];
}

$inventory_columns = [
    'hostname' => 'Hostname',
    'ip_address' => 'IP Address',
    'additional_ips' => 'Additional IPs',
    'os_family' => 'OS Family',
    'os_version' => 'OS Version',
    'kernel_version' => 'Kernel Version',
    'cpu' => 'CPU',
    'memory' => 'Memory',
    'support_level' => 'Support Level',
    'server_state' => 'Server State',
    'domain' => 'Domain',
    'joined_in' => 'Joined In',
    'role' => 'Role',
    'cluster_name' => 'Cluster Name',
    'managed_by' => 'Managed By',
    'cluster_type' => 'Cluster Type',
    'project' => 'Project',
    'application' => 'Application',
    'technical_owner' => 'Technical Owner',
    'technical_owner_email' => 'Technical Owner Email',
    'team_dl' => 'Team DL',
    'technical_manager' => 'Technical Manager',
    'technical_manager_email' => 'Technical Manager Email',
    'sdm_name' => 'SDM Name',
    'sdm_email' => 'SDM Email',
    'ncgr_owner' => 'NCGR Owner',
    'ncgr_owner_email' => 'NCGR Owner Email',
    'server_type' => 'Server Type',
    'appliance' => 'Appliance',
    'port_group' => 'Port Group',
    'vlan' => 'VLAN',
    'location' => 'Location',
    'criticality' => 'Criticality',
    'project_code' => 'Project Code',
    'commissioned_date' => 'Commissioned Date',
    'host_type' => 'Host Type',
    'hw_model' => 'HW Model',
    'esxi_cluster' => 'ESXI Cluster',
    'vendor' => 'Vendor',
    'dmz' => 'DMZ',
    'db_type' => 'DB Type',
    'live' => 'Live',
    'eol' => 'EOL',
    'grc' => 'GRC',
    'ugrp' => 'UGRP',
    'backup' => 'Backup',
    'monitoring' => 'Monitoring',
    'infra' => 'Infra'
];

/*
 * Derived columns are shown and exported like any other, but they are NOT
 * columns of the inventory table.
 *
 * $inventory_columns stays the list of REAL columns: it builds the
 * "INSERT INTO inventory (...)" column lists and the search WHERE clause,
 * and a derived name in either would be a "no such column" error on the
 * next import or search. Everything that only displays -- the column
 * picker, the table, the export, the sort whitelist -- uses
 * $inventory_display_columns instead.
 *
 * Last Patch Date is the most recent per-server Date recorded for that
 * hostname in the Quarterly Patching module. It is derived live rather
 * than stored so it can never drift from what patching shows, and it
 * stays right when an assignment is edited or deleted.
 */
$inventory_derived_columns = [
    'last_patch_date' => 'Last Patch Date',
];

$inventory_display_columns = $inventory_columns + $inventory_derived_columns;

/*
 * Hostnames are compared lower-cased and trimmed because inventory and
 * the patching tables disagree about case (SRL002 vs srl008).
 *
 * Falls back to NULL when the patching module has never been opened on
 * this installation and its tables do not exist yet -- inventory must not
 * fail to load because of that.
 */
$inventory_patching_available = false;

try {
    $inventory_patching_available = (bool) $pdo->query(
        "SELECT 1 FROM sqlite_master WHERE type = 'table' AND name = 'patch_schedule_servers'"
    )->fetchColumn();
} catch (Throwable $e) {
    error_log('Unable to check for patch_schedule_servers: ' . $e->getMessage());
}

$inventory_last_patch_sql = $inventory_patching_available
    ? "(
        SELECT MAX(pss.patch_date)
        FROM patch_schedule_servers pss
        WHERE LOWER(TRIM(pss.hostname)) = LOWER(TRIM(inventory.hostname))
          AND pss.patch_date IS NOT NULL
          AND TRIM(pss.patch_date) <> ''
      )"
    : "NULL";

/*
 * All-column matching lives in includes/search-helpers.php, shared with
 * asset.php so both lists behave the same and neither drifts back to a
 * hand-picked subset of columns.
 */
require_once 'includes/search-helpers.php';

// Per-user inventory column preferences.
// The existing database uses one row per user/column:
// user_id, column_key, is_visible, updated_at
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_column_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        column_key TEXT NOT NULL,
        is_visible INTEGER NOT NULL DEFAULT 1,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, column_key)
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize inventory column preferences: ' . $e->getMessage());
}

$default_visible_columns = ['hostname', 'ip_address', 'os_family', 'support_level', 'project'];
$visible_columns = $default_visible_columns;
$user_id = (int)($_SESSION['user_id'] ?? 0);

if ($user_id > 0) {
    try {
        $prefStmt = $pdo->prepare("
            SELECT column_key
            FROM inventory_column_preferences
            WHERE user_id = ? AND is_visible = 1
            ORDER BY column_key
        ");
        $prefStmt->execute([$user_id]);
        $savedColumns = $prefStmt->fetchAll(PDO::FETCH_COLUMN);
        if (is_array($savedColumns) && count($savedColumns) > 0) {
            $visible_columns = array_values(array_intersect(
                array_keys($inventory_display_columns),
                array_map('strval', $savedColumns)
            ));
            if (count($visible_columns) === 0) {
                $visible_columns = $default_visible_columns;
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to load inventory column preferences: ' . $e->getMessage());
    }
}

// Save per-user field visibility.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && postValue('form_action') === 'save_columns') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $user_id = (int)($_SESSION['user_id'] ?? 0);
        if ($user_id <= 0) {
            throw new Exception('Invalid user session.');
        }

        $requested = json_decode(postValue('visible_columns'), true);
        if (!is_array($requested)) {
            $requested = [];
        }

        $requested = array_values(array_unique(array_intersect(
            array_keys($inventory_display_columns),
            array_map('strval', $requested)
        )));

        if (count($requested) === 0) {
            throw new Exception('Select at least one field.');
        }

        $pdo->beginTransaction();

        $deleteStmt = $pdo->prepare(
            "DELETE FROM inventory_column_preferences WHERE user_id = ?"
        );
        $deleteStmt->execute([$user_id]);

        $insertStmt = $pdo->prepare("
            INSERT INTO inventory_column_preferences
                (user_id, column_key, is_visible, updated_at)
            VALUES
                (?, ?, ?, CURRENT_TIMESTAMP)
        ");

        foreach (array_keys($inventory_display_columns) as $columnKey) {
            $insertStmt->execute([
                $user_id,
                $columnKey,
                in_array($columnKey, $requested, true) ? 1 : 0
            ]);
        }

        $pdo->commit();

        echo json_encode([
            'ok' => true,
            'message' => 'Your inventory field layout has been saved.'
        ]);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Saving inventory column preferences failed: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode([
            'ok' => false,
            'message' => 'Unable to save field preferences: ' . $e->getMessage()
        ]);
    }
    exit;
}

// Export CSV
if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export inventory records.');
    }

    /*
     * Rebuild exactly the same search/filter conditions used by the listing.
     * Export intentionally does NOT use LIMIT/OFFSET, so all matching records
     * across all pages are exported.
     */
    $export_keyword = trim((string)($_GET['keyword'] ?? ''));
    $export_advanced_search = trim((string)($_GET['advanced_search'] ?? ''));
    $export_active_servers = (string)($_GET['active_servers'] ?? '');

    $exportWhere = "1=1";
    $exportParams = [];

    /*
     * The normal inventory search uses advanced_search in preference to
     * keyword search. Keep the same behavior for export.
     */
    if ($export_advanced_search !== '') {
        // Check if search contains AND/OR operators
        $has_operators = preg_match('/\b(AND|OR)\b/i', $export_advanced_search);

        if ($has_operators) {
            // Parse Boolean operators (same logic as main search)
            $search_with_operators = preg_replace_callback(
                '/\b([A-Za-z0-9._@\-]+)\b/i',
                function($m) {
                    $term = trim($m[1]);
                    if (strtoupper($term) === 'AND' || strtoupper($term) === 'OR') {
                        return ' ' . strtoupper($term) . ' ';
                    }
                    return 'TERM:' . $term;
                },
                $export_advanced_search
            );

            $parts = preg_split('/\s+(AND|OR)\s+/i', $search_with_operators, -1, PREG_SPLIT_DELIM_CAPTURE);
            $search_clauses = [];
            $current_operator = 'OR';

            foreach ($parts as $part) {
                $part = trim($part);
                if (strtoupper($part) === 'AND' || strtoupper($part) === 'OR') {
                    $current_operator = strtoupper($part);
                    continue;
                }

                if (empty($part)) continue;

                preg_match_all('/TERM:([A-Za-z0-9._@\-]+)/i', $part, $matches);
                foreach ($matches[1] as $term) {
                    $term = trim($term);
                    if (empty($term)) continue;

                    [$field_clause, $termParams] = allColumnSearchClause($term, $inventory_columns);
                    $search_clauses[] = ['clause' => $field_clause, 'operator' => $current_operator, 'term' => $term];

                    $exportParams = array_merge($exportParams, $termParams);
                }
            }

            if (count($search_clauses) > 0) {
                $where_parts = [];
                $current_op = $search_clauses[0]['operator'];
                $clause_group = [];

                foreach ($search_clauses as $item) {
                    if ($item['operator'] !== $current_op && count($clause_group) > 0) {
                        $where_parts[] = ['op' => $current_op, 'clauses' => $clause_group];
                        $clause_group = [];
                        $current_op = $item['operator'];
                    }
                    $clause_group[] = $item['clause'];
                }

                if (count($clause_group) > 0) {
                    $where_parts[] = ['op' => $current_op, 'clauses' => $clause_group];
                }

                $final_where = [];
                foreach ($where_parts as $part) {
                    $final_where[] = "(" . implode(" OR ", $part['clauses']) . ")";
                }
                $exportWhere .= " AND (" . implode(" AND ", $final_where) . ")";
            }
        } else {
            // Same matcher as the on-screen list, including "field: value"
            // scoping, so an export contains exactly the rows the page was
            // showing rather than a wider set.
            $exportSearch = multiValueSearchClause($export_advanced_search, $inventory_columns);

            if ($exportSearch !== null) {
                [$expClause, $expParams] = $exportSearch;
                $exportWhere .= " AND " . $expClause;
                $exportParams = array_merge($exportParams, $expParams);
            }
        }
    } elseif ($export_keyword !== '') {
        // Was five hardcoded columns, and it also *replaced* $exportParams
        // rather than appending -- so any filter bound before it lost its
        // values and the placeholders went out of step with the bindings.
        $exportQuick = multiValueSearchClause($export_keyword, $inventory_columns);

        if ($exportQuick !== null) {
            [$eqClause, $eqParams] = $exportQuick;
            $exportWhere .= " AND " . $eqClause;
            $exportParams = array_merge($exportParams, $eqParams);
        }
    }

    if ($export_active_servers === '1') {
        $exportWhere .= "
            AND LOWER(server_state) = 'powered on'
            AND LOWER(live) = 'yes'
        ";
    }

    [$exportFilterClauses, $exportFilterParams] = buildInventoryFilterClause($_GET);
    if (count($exportFilterClauses) > 0) {
        $exportWhere .= " AND (" . implode(" AND ", $exportFilterClauses) . ")";
        $exportParams = array_merge($exportParams, $exportFilterParams);
    }

    header('Content-Type: text/csv; charset=utf-8');
    header(
        'Content-Disposition: attachment; filename=inventory_export_' .
        date('Y-m-d_H-i-s') .
        '.csv'
    );
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    $cols = array_keys($inventory_display_columns);
    $display_names = array_values($inventory_display_columns);
    fputcsv($output, $display_names);

    $stmt = $pdo->prepare("
        SELECT inventory.*, $inventory_last_patch_sql AS last_patch_date
        FROM inventory
        WHERE $exportWhere
        ORDER BY id DESC
    ");
    $stmt->execute($exportParams);

    while ($r = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $line = [];

        foreach ($cols as $c) {
            $line[] = $r[$c] ?? '';
        }

        fputcsv($output, $line);
    }

    fclose($output);
    exit;
}

// Audit History AJAX
// Supports two modes:
//   - Global history: inventory.php?action=get_history
//   - Per-record history: inventory.php?action=get_history&inventory_id=123
// Both are gated on can_audit ($canViewHistory).
if (isset($_GET['action']) && $_GET['action'] === 'get_history') {
    if (!$canViewHistory) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyInventoryId = isset($_GET['inventory_id']) ? (int)$_GET['inventory_id'] : 0;

    try {
        if ($historyInventoryId > 0) {
            $histStmt = $pdo->prepare("SELECT * FROM inventory_history WHERE inventory_id = ? ORDER BY timestamp DESC");
            $histStmt->execute([$historyInventoryId]);
            $logs = $histStmt->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $logs = $pdo->query("SELECT * FROM inventory_history ORDER BY timestamp DESC")->fetchAll(PDO::FETCH_ASSOC);
        }
    } catch (Throwable $e) {
        error_log('Unable to load inventory history: ' . $e->getMessage());
        $logs = [];
    }

    if (count($logs) > 0) {
        echo '<table class="audit-table"><thead><tr><th>Action</th><th>User</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $l) {
            // Details may contain a multi-line field-level diff (see save handler);
            // escape first, then convert the newlines to <br> so each changed field
            // renders on its own line instead of running together.
            $detailsHtml = nl2br(htmlspecialchars((string)($l['details'] ?? '')));
            echo '<tr><td><strong>' . htmlspecialchars((string)($l['action_type'] ?? '')) . '</strong></td><td>' . htmlspecialchars((string)($l['performed_by'] ?? '')) . '</td><td class="audit-details">' . $detailsHtml . '</td><td>' . htmlspecialchars((string)($l['timestamp'] ?? '')) . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">' . ($historyInventoryId > 0 ? 'No history records found for this record.' : 'No history records found.') . '</p>';
    }
    exit;
}

// AJAX Ownership Lookup
if (isset($_GET['action']) && $_GET['action'] === 'get_ownership_details') {
    header('Content-Type: application/json; charset=utf-8');
    $project = trim((string)($_GET['project'] ?? ''));
    $support_level = trim((string)($_GET['support_level'] ?? ''));
    echo json_encode(lookupOwnershipDetails($pdo, $project, $support_level));
    exit;
}

// AJAX IP Details Lookup
if (isset($_GET['action']) && $_GET['action'] === 'get_ip_details') {
    header('Content-Type: application/json; charset=utf-8');
    $ip = trim((string)($_GET['ip'] ?? ''));
    echo json_encode(lookupIPDetails($pdo, $ip));
    exit;
}

// AJAX EOL Lookup -- compares OS Version against license_warranty.product_name
if (isset($_GET['action']) && $_GET['action'] === 'get_eol_status') {
    header('Content-Type: application/json; charset=utf-8');
    $os_version = trim((string)($_GET['os_version'] ?? ''));
    echo json_encode(lookupEolStatus($pdo, $os_version));
    exit;
}

// Form Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = postValue('form_action');

    // CSV Bulk Import
    if ($act === 'import_csv' && $canImport) {
        $csv_data_raw = postValue('csv_data');
        $imported_count = 0;
        $failed_count = 0;

        // Broken out so a failed import says which reason applies. A
        // hostname/IP match is no longer skipped -- it replaces the
        // existing record -- so only these two reasons remain.
        $skip_missing = 0;    // no hostname or no IP after header mapping
        $skip_error = 0;      // the INSERT/UPDATE itself threw
        $replaced_count = 0;  // existing records overwritten rather than created

        $lines = [];
        if (isset($_FILES['csv_file']['tmp_name']) && !empty($_FILES['csv_file']['tmp_name'])) {
            $lines = file($_FILES['csv_file']['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        } elseif ($csv_data_raw !== '') {
            $lines = preg_split('/\r\n|\r|\n/', $csv_data_raw);
        }

        if (count($lines) > 0) {
            $start_index = 0;
            $first_line = strtolower(trim((string)$lines[0]));
            if (strpos($first_line, 'hostname') !== false) $start_index = 1;

            /*
             * Support both the exported CSV (which starts with id) and a
             * normal inventory CSV (which starts with hostname).
             *
             * Header cells are normalised to the database column key before
             * use, because a header may legitimately carry either form:
             * the key ("ip_address") or the display label the export and the
             * on-screen table use ("IP Address").
             *
             * Without this, only "Hostname" matched -- it is the single
             * column whose label lowercases to exactly its key. Every
             * multi-word column ("IP Address" -> "ip address") missed, so
             * $ip_address came out empty and every row was silently counted
             * as a failure.
             */
            $headerLookup = [];
            foreach ($inventory_columns as $key => $label) {
                $headerLookup[$key] = $key;
                $headerLookup[preg_replace('/[^a-z0-9]+/', '_', strtolower($label))] = $key;
            }

            $normaliseHeaderCell = static function ($cell) use ($headerLookup) {
                $raw = strtolower(trim((string) $cell));
                if ($raw === '') { return ''; }
                $slug = trim(preg_replace('/[^a-z0-9]+/', '_', $raw), '_');
                return $headerLookup[$slug] ?? $headerLookup[$raw] ?? $slug;
            };

            $csvHeader = null;
            if (count($lines) > 0) {
                $candidateHeader = array_map($normaliseHeaderCell, str_getcsv(trim((string)$lines[0])));
                if (in_array('hostname', $candidateHeader, true)) {
                    $csvHeader = $candidateHeader;
                    $start_index = 1;
                }
            }

            $expectedCsvFields = array_keys($inventory_columns);

            foreach (array_slice($lines, $start_index) as $line) {
                $row_data = str_getcsv(trim((string)$line));
                if (count($row_data) < 2) continue;

                // Convert the CSV row into field => value pairs.
                $csvRecord = [];
                if ($csvHeader !== null) {
                    foreach ($csvHeader as $index => $field) {
                        if ($field === 'id' || $field === '') continue;
                        $csvRecord[$field] = trim((string)($row_data[$index] ?? ''));
                    }
                } else {
                    foreach ($expectedCsvFields as $index => $field) {
                        $csvRecord[$field] = trim((string)($row_data[$index] ?? ''));
                    }
                }

                $hostname = trim((string)($csvRecord['hostname'] ?? ''));
                $ip_address = trim((string)($csvRecord['ip_address'] ?? ''));
                if ($hostname === '' || $ip_address === '') {
                    $failed_count++;
                    $skip_missing++;
                    continue;
                }

                // Matched by hostname first (the column with the unique
                // index), falling back to IP address, so a re-upload of the
                // same host replaces it instead of being skipped.
                $chk = $pdo->prepare("SELECT id FROM inventory WHERE hostname = ? LIMIT 1");
                $chk->execute([$hostname]);
                $existing_id = $chk->fetchColumn();

                if (!$existing_id) {
                    $chk = $pdo->prepare("SELECT id FROM inventory WHERE ip_address = ? LIMIT 1");
                    $chk->execute([$ip_address]);
                    $existing_id = $chk->fetchColumn();
                }

                $support_level = trim((string)($csvRecord['support_level'] ?? 'production'));
                $project = trim((string)($csvRecord['project'] ?? ''));

                $ip_match = lookupIPDetails($pdo, $ip_address);
                $own_match = lookupOwnershipDetails($pdo, $project, $support_level);

                $record = $csvRecord;
                $record['support_level'] = $support_level;
                $record['project'] = $project;
                // Always derive these from IPAM rather than trusting CSV values.
                $record['port_group'] = $ip_match['port_group'];
                $record['vlan'] = $ip_match['vlan'];

                foreach ([
                    'technical_owner','technical_owner_email','team_dl','technical_manager','technical_manager_email',
                    'sdm_name','sdm_email','ncgr_owner','ncgr_owner_email'
                ] as $field) {
                    if (isset($own_match[$field])) $record[$field] = $own_match[$field];
                }

                if ($record['server_type'] === '') $record['server_type'] = 'Virtual';
                if ($record['appliance'] === '') $record['appliance'] = 'no';
                if ($record['server_state'] === '') $record['server_state'] = 'powered on';

                $fieldValues = [];
                foreach (array_keys($inventory_columns) as $field) {
                    $fieldValues[$field] = $record[$field] ?? '';
                }

                try {
                    if ($existing_id) {
                        // Replace the existing record's fields entirely with the CSV row.
                        $setSql = implode(', ', array_map(fn($f) => "$f = ?", array_keys($fieldValues)));
                        $stmt = $pdo->prepare(
                            "UPDATE inventory SET $setSql, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?"
                        );
                        $stmt->execute(array_merge(array_values($fieldValues), [$username, $existing_id]));
                        $new_id = $existing_id;
                        $history_action = 'CSV_IMPORT';
                        $history_details = "Replaced via CSV bulk import: $hostname";
                        $replaced_count++;
                    } else {
                        $insertColumns = array_keys($fieldValues);
                        $insertColumns[] = 'created_by';
                        $placeholders = implode(',', array_fill(0, count($insertColumns), '?'));
                        $stmt = $pdo->prepare(
                            "INSERT INTO inventory (" . implode(',', $insertColumns) . ") VALUES (" . $placeholders . ")"
                        );
                        $stmt->execute(array_merge(array_values($fieldValues), [$username]));
                        $new_id = $pdo->lastInsertId();
                        $history_action = 'CSV_IMPORT';
                        $history_details = "Bulk imported inventory record: $hostname";
                    }

                    $imported_count++;
                    $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, ?, ?, ?)")
                        ->execute([$new_id, $history_action, $username, $history_details]);
                } catch (Throwable $e) {
                    $failed_count++;
                    $skip_error++;
                    error_log('Inventory CSV import failed for ' . $hostname . ': ' . $e->getMessage());
                }
            }

            $msg = "CSV Import completed. Successfully imported: $imported_count records";
            if ($replaced_count > 0) {
                $msg .= " ($replaced_count replaced existing records)";
            }

            if ($failed_count > 0) {
                $reasons = [];
                if ($skip_missing > 0)   { $reasons[] = "$skip_missing missing hostname or IP"; }
                if ($skip_error > 0)     { $reasons[] = "$skip_error insert/update errors (see server log)"; }

                $msg .= ", skipped: $failed_count (" . implode('; ', $reasons) . ")";

                // The overwhelmingly common cause of a whole-file skip is a
                // header the importer could not map onto column keys, which
                // leaves every row looking like it has no IP address.
                if ($imported_count === 0 && $skip_missing === $failed_count) {
                    $msg .= ". Every row was missing a hostname or IP -- check that the first"
                          . " row is a header naming the columns (either 'ip_address' or 'IP Address').";
                }
            }
        } else {
            $error = "No valid data found in CSV upload or text area.";
        }
    }

    // Save/Create/Edit
    if ($act === 'save' && $canEdit) {
        $id = postValue('id');
        $hostname = postValue('hostname');
        $ip_address = postValue('ip_address');
        $support_level = postValue('support_level');
        $project = postValue('project');
        $clone_mode = postValue('clone_mode') === '1';
        $clone_source_id = postValue('clone_source_id');

        if ($hostname === '' || $ip_address === '') {
            $error = "Hostname and IP Address are mandatory fields.";
        } else {
            if ($id === '') {
                $dup = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE LOWER(TRIM(hostname)) = LOWER(TRIM(?)) OR TRIM(ip_address) = TRIM(?)");
                $dup->execute([$hostname, $ip_address]);
                if ((int)$dup->fetchColumn() > 0) {
                    $error = "Error: A record with this Hostname or IP Address already exists.";
                }
            } else {
                $dup = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE (LOWER(TRIM(hostname)) = LOWER(TRIM(?)) OR TRIM(ip_address) = TRIM(?)) AND id != ?");
                $dup->execute([$hostname, $ip_address, $id]);
                if ((int)$dup->fetchColumn() > 0) {
                    $error = "Error: Another record with this Hostname or IP Address already exists.";
                }
            }

            if ($error === '') {
                try {
                    $ip_match = lookupIPDetails($pdo, $ip_address);
                    $port_group = $ip_match['port_group'];
                    $vlan = $ip_match['vlan'];

                    $own_match = lookupOwnershipDetails($pdo, $project, $support_level);
                    $technical_owner = $own_match['technical_owner'] ?? postValue('technical_owner');
                    $technical_owner_email = $own_match['technical_owner_email'] ?? postValue('technical_owner_email');
                    $team_dl = $own_match['team_dl'] ?? postValue('team_dl');
                    $technical_manager = $own_match['technical_manager'] ?? postValue('technical_manager');
                    $technical_manager_email = $own_match['technical_manager_email'] ?? postValue('technical_manager_email');
                    $sdm_name = $own_match['sdm_name'] ?? postValue('sdm_name');
                    $sdm_email = $own_match['sdm_email'] ?? postValue('sdm_email');
                    $ncgr_owner = $own_match['ncgr_owner'] ?? postValue('ncgr_owner');
                    $ncgr_owner_email = $own_match['ncgr_owner_email'] ?? postValue('ncgr_owner_email');

                    $hw_model = postValue('hw_model');
                    $vendor = postValue('vendor');
                    $location = postValue('location');

                    // Authoritative EOL check: if OS Version matches a License/Warranty
                    // product whose EOL date has already passed, force EOL=yes here on
                    // save rather than relying on the client-side AJAX check, which can
                    // lose the race if the form is submitted before it responds.
                    $eol_value = postValue('eol');
                    $eolCheck = lookupEolStatus($pdo, postValue('os_version'));
                    if ($eolCheck['matched'] && $eolCheck['is_past']) {
                        $eol_value = 'yes';
                    }

                    if ($hw_model !== '') {
                        $v_stmt = $pdo->prepare("SELECT manufacturer, location FROM asset WHERE asset_name = ? LIMIT 1");
                        $v_stmt->execute([$hw_model]);
                        $asset_data = $v_stmt->fetch(PDO::FETCH_ASSOC);
                        if ($asset_data) {
                            if ($vendor === '') $vendor = trim((string)($asset_data['manufacturer'] ?? ''));
                            if ($location === '') $location = trim((string)($asset_data['location'] ?? ''));
                        }
                    }

                    if ($id === '') {
                        // Build INSERT dynamically from the exact field list to prevent placeholder-count errors.
                        $insertColumns = array_keys($inventory_columns);
                        $insertColumns[] = 'created_by';
                        $placeholders = implode(',', array_fill(0, count($insertColumns), '?'));

                        $values = [
                            $hostname,
                            $ip_address,
                            postValue('additional_ips'),
                            postValue('os_family'),
                            postValue('os_version'),
                            postValue('kernel_version'),
                            postValue('cpu'),
                            postValue('memory'),
                            $support_level,
                            postValue('server_state'),
                            postValue('domain'),
                            postValue('joined_in'),
                            postValue('role'),
                            postValue('cluster_name'),
                            postValue('managed_by'),
                            postValue('cluster_type'),
                            $project,
                            postValue('application'),
                            $technical_owner,
                            $technical_owner_email,
                            $team_dl,
                            $technical_manager,
                            $technical_manager_email,
                            $sdm_name,
                            $sdm_email,
                            $ncgr_owner,
                            $ncgr_owner_email,
                            postValue('server_type'),
                            postValue('appliance'),
                            $port_group,
                            $vlan,
                            $location,
                            postValue('criticality'),
                            postValue('project_code'),
                            postValue('commissioned_date'),
                            postValue('host_type'),
                            $hw_model,
                            postValue('esxi_cluster'),
                            $vendor,
                            postValue('dmz'),
                            postValue('db_type'),
                            postValue('live'),
                            $eol_value,
                            postValue('grc'),
                            postValue('ugrp'),
                            postValue('backup'),
                            postValue('monitoring'),
                            postValue('infra'),
                            $username
                        ];

                        if (count($values) !== count($insertColumns)) {
                            throw new RuntimeException('Inventory INSERT value count mismatch: ' . count($values) . ' values for ' . count($insertColumns) . ' columns.');
                        }

                        $stmt = $pdo->prepare(
                            "INSERT INTO inventory (" . implode(',', $insertColumns) . ") VALUES (" . $placeholders . ")"
                        );
                        $stmt->execute($values);

                        $new_id = $pdo->lastInsertId();
                        $historyAction = $clone_mode ? 'CLONED' : 'CREATED';
                        $historyDetails = $clone_mode
                            ? "Cloned inventory record #" . (string)$clone_source_id . " to new server: $hostname"
                            : "Created inventory record: $hostname";
                        $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, ?, ?, ?)")
                            ->execute([$new_id, $historyAction, $username, $historyDetails]);
                        $msg = $clone_mode ? "Server inventory entry cloned successfully." : "Server inventory entry created successfully.";
                    } else {
                        $edit_comments = postValue('edit_comments');

                        // Capture the pre-update state so we can log exactly which
                        // fields changed (and their old -> new values) in the audit trail.
                        $oldStmt = $pdo->prepare("SELECT * FROM inventory WHERE id = ? LIMIT 1");
                        $oldStmt->execute([$id]);
                        $oldRecord = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                        $stmt = $pdo->prepare("UPDATE inventory SET
                            hostname=?, ip_address=?, additional_ips=?, os_family=?, os_version=?, kernel_version=?, cpu=?, memory=?,
                            support_level=?, server_state=?, domain=?, joined_in=?, role=?, cluster_name=?, managed_by=?, cluster_type=?,
                            project=?, application=?, technical_owner=?, technical_owner_email=?, team_dl=?, technical_manager=?,
                            technical_manager_email=?, sdm_name=?, sdm_email=?, ncgr_owner=?, ncgr_owner_email=?, server_type=?, appliance=?,
                            port_group=?, vlan=?, location=?, criticality=?, project_code=?, commissioned_date=?, host_type=?, hw_model=?,
                            esxi_cluster=?, vendor=?, dmz=?, db_type=?, live=?, eol=?, grc=?, ugrp=?, backup=?, monitoring=?, infra=?,
                            edit_comments=?, updated_by=?, updated_at=CURRENT_TIMESTAMP
                            WHERE id=?");

                        // Keyed by column so we can diff old vs new value per field below.
                        // Order matches $inventory_columns / the UPDATE SET clause above.
                        $newValuesByColumn = [
                            'hostname' => $hostname,
                            'ip_address' => $ip_address,
                            'additional_ips' => postValue('additional_ips'),
                            'os_family' => postValue('os_family'),
                            'os_version' => postValue('os_version'),
                            'kernel_version' => postValue('kernel_version'),
                            'cpu' => postValue('cpu'),
                            'memory' => postValue('memory'),
                            'support_level' => $support_level,
                            'server_state' => postValue('server_state'),
                            'domain' => postValue('domain'),
                            'joined_in' => postValue('joined_in'),
                            'role' => postValue('role'),
                            'cluster_name' => postValue('cluster_name'),
                            'managed_by' => postValue('managed_by'),
                            'cluster_type' => postValue('cluster_type'),
                            'project' => $project,
                            'application' => postValue('application'),
                            'technical_owner' => $technical_owner,
                            'technical_owner_email' => $technical_owner_email,
                            'team_dl' => $team_dl,
                            'technical_manager' => $technical_manager,
                            'technical_manager_email' => $technical_manager_email,
                            'sdm_name' => $sdm_name,
                            'sdm_email' => $sdm_email,
                            'ncgr_owner' => $ncgr_owner,
                            'ncgr_owner_email' => $ncgr_owner_email,
                            'server_type' => postValue('server_type'),
                            'appliance' => postValue('appliance'),
                            'port_group' => $port_group,
                            'vlan' => $vlan,
                            'location' => $location,
                            'criticality' => postValue('criticality'),
                            'project_code' => postValue('project_code'),
                            'commissioned_date' => postValue('commissioned_date'),
                            'host_type' => postValue('host_type'),
                            'hw_model' => $hw_model,
                            'esxi_cluster' => postValue('esxi_cluster'),
                            'vendor' => $vendor,
                            'dmz' => postValue('dmz'),
                            'db_type' => postValue('db_type'),
                            'live' => postValue('live'),
                            'eol' => $eol_value,
                            'grc' => postValue('grc'),
                            'ugrp' => postValue('ugrp'),
                            'backup' => postValue('backup'),
                            'monitoring' => postValue('monitoring'),
                            'infra' => postValue('infra'),
                        ];

                        $values = array_values($newValuesByColumn);
                        $values[] = $edit_comments;
                        $values[] = $username;
                        $values[] = $id;

                        $stmt->execute($values);

                        // Build a field-level diff: only fields whose value actually
                        // changed are recorded, each with its old -> new value.
                        $changedFields = [];
                        foreach ($newValuesByColumn as $columnKey => $newVal) {
                            $oldValStr = trim((string)($oldRecord[$columnKey] ?? ''));
                            $newValStr = trim((string)$newVal);
                            if ($oldValStr !== $newValStr) {
                                $fieldLabel = $inventory_columns[$columnKey] ?? $columnKey;
                                $oldDisplay = $oldValStr === '' ? '(empty)' : $oldValStr;
                                $newDisplay = $newValStr === '' ? '(empty)' : $newValStr;
                                $changedFields[] = "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                            }
                        }

                        $detail_msg = "Updated inventory record: $hostname\n";
                        $detail_msg .= (count($changedFields) > 0)
                            ? implode("\n", $changedFields)
                            : "No field value changes detected.";
                        if ($edit_comments !== '') {
                            $detail_msg .= "\nComment: $edit_comments";
                        }

                        $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)")
                            ->execute([$id, $username, $detail_msg]);
                        $msg = "Server inventory entry updated successfully.";
                    }
                } catch (Throwable $e) {
                    error_log('Inventory save failed: ' . $e->getMessage());
                    $error = "Unable to save inventory record: " . $e->getMessage();
                }
            }
        }
    }

    // Delete
    if ($act === 'delete' && $canDelete) {
        $id = postValue('id');
        try {
            $h_name = $pdo->prepare("SELECT hostname FROM inventory WHERE id=?");
            $h_name->execute([$id]);
            $val = $h_name->fetchColumn();

            $pdo->prepare("DELETE FROM inventory WHERE id=?")->execute([$id]);
            $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)")
                ->execute([$id, $username, "Deleted inventory record: " . (string)$val]);
            $msg = "Server deleted successfully.";
        } catch (Throwable $e) {
            error_log('Inventory delete failed: ' . $e->getMessage());
            $error = "Unable to delete inventory record: " . $e->getMessage();
        }
    }
}

// Pagination & Search
$limit = resolveUserPageSize($pdo, $user_id);
$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$start = ($page - 1) * $limit;
$keyword = trim((string)($_GET['keyword'] ?? ''));
$advanced_search = trim((string)($_GET['advanced_search'] ?? ''));
$active_servers = (string)($_GET['active_servers'] ?? '');

// Sorting
$sort_by = trim((string)($_GET['sort_by'] ?? 'id'));
$sort_dir = strtoupper(trim((string)($_GET['sort_dir'] ?? 'DESC')));

// Validate sort_by to prevent SQL injection
$valid_sort_columns = array_keys($inventory_display_columns);
$valid_sort_columns[] = 'id';
$valid_sort_columns[] = 'created_at';
$valid_sort_columns[] = 'created_by';
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'id';
}

// Validate sort direction
if ($sort_dir !== 'ASC' && $sort_dir !== 'DESC') {
    $sort_dir = 'DESC';
}

// Toggle direction for next click (ASC -> DESC, DESC -> ASC)
$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

// Advanced Search / Filters drawer fields.
$filter_os_family     = trim((string)($_GET['filter_os_family'] ?? ''));
$filter_support_level = trim((string)($_GET['filter_support_level'] ?? ''));
$filter_project       = trim((string)($_GET['filter_project'] ?? ''));
$filter_server_state  = trim((string)($_GET['filter_server_state'] ?? ''));
$filter_server_type   = trim((string)($_GET['filter_server_type'] ?? ''));
$filter_criticality   = trim((string)($_GET['filter_criticality'] ?? ''));
$filter_domain        = trim((string)($_GET['filter_domain'] ?? ''));
$filter_managed_by    = trim((string)($_GET['filter_managed_by'] ?? ''));
$filter_dmz           = trim((string)($_GET['filter_dmz'] ?? ''));
$filter_location      = trim((string)($_GET['filter_location'] ?? ''));
$filter_application   = trim((string)($_GET['filter_application'] ?? ''));

$where = "1=1";
$params = [];

if ($advanced_search !== '') {
    // Check if search contains AND/OR operators
    $has_operators = preg_match('/\b(AND|OR)\b/i', $advanced_search);

    if ($has_operators) {
        // Parse Boolean operators
        $search_with_operators = preg_replace_callback(
            '/\b([A-Za-z0-9._@\-]+)\b/i',
            function($m) {
                $term = trim($m[1]);
                if (strtoupper($term) === 'AND' || strtoupper($term) === 'OR') {
                    return ' ' . strtoupper($term) . ' ';
                }
                return 'TERM:' . $term;
            },
            $advanced_search
        );

        // Split by AND/OR and process
        $parts = preg_split('/\s+(AND|OR)\s+/i', $search_with_operators, -1, PREG_SPLIT_DELIM_CAPTURE);
        $search_clauses = [];
        $current_operator = 'OR';

        foreach ($parts as $part) {
            $part = trim($part);
            if (strtoupper($part) === 'AND' || strtoupper($part) === 'OR') {
                $current_operator = strtoupper($part);
                continue;
            }

            if (empty($part)) continue;

            // Extract terms from TERM: prefix
            preg_match_all('/TERM:([A-Za-z0-9._@\-]+)/i', $part, $matches);
            foreach ($matches[1] as $term) {
                $term = trim($term);
                if (empty($term)) continue;

                [$field_clause, $termParams] = allColumnSearchClause($term, $inventory_columns);
                $search_clauses[] = ['clause' => $field_clause, 'operator' => $current_operator, 'term' => $term];

                $params = array_merge($params, $termParams);
            }
        }

        if (count($search_clauses) > 0) {
            $where_parts = [];
            $current_op = $search_clauses[0]['operator'];
            $clause_group = [];

            foreach ($search_clauses as $idx => $item) {
                if ($item['operator'] !== $current_op && count($clause_group) > 0) {
                    $where_parts[] = ['op' => $current_op, 'clauses' => $clause_group];
                    $clause_group = [];
                    $current_op = $item['operator'];
                }
                $clause_group[] = $item['clause'];
            }

            if (count($clause_group) > 0) {
                $where_parts[] = ['op' => $current_op, 'clauses' => $clause_group];
            }

            $final_where = [];
            foreach ($where_parts as $part) {
                $final_where[] = "(" . implode(" OR ", $part['clauses']) . ")";
            }
            $where .= " AND (" . implode(" AND ", $final_where) . ")";
        }
    } else {
        /*
         * Plain list, plus optional "field: value" scoping. A flat list is
         * OR-ed as before; a line naming a column restricts to that column
         * and ORs the comma-separated values within it, so
         *
         *     os_family: RHEL
         *     os_version: 7, 8
         *
         * means RHEL AND (7 or 8) -- which a flat list cannot express,
         * since "RHEL, 7, 8" also matches any row with a 7 in its CPU
         * count or IP address.
         */
        $advanced = multiValueSearchClause($advanced_search, $inventory_columns);

        if ($advanced !== null) {
            [$advClause, $advParams] = $advanced;
            $where .= " AND " . $advClause;
            $params = array_merge($params, $advParams);
        }
    }
} elseif ($keyword !== '') {
    // The quick box understands the same syntax as the panel, so both
    // find the same records.
    $quick = multiValueSearchClause($keyword, $inventory_columns);

    if ($quick !== null) {
        [$kwClause, $kwParams] = $quick;
        $where .= " AND " . $kwClause;
        $params = array_merge($params, $kwParams);
    }
}

if ($active_servers === '1') {
    $where .= " AND LOWER(server_state) = 'powered on' AND LOWER(live) = 'yes'";
}

[$filterClauses, $filterParams] = buildInventoryFilterClause($_GET);
if (count($filterClauses) > 0) {
    $where .= " AND (" . implode(" AND ", $filterClauses) . ")";
    $params = array_merge($params, $filterParams);
}

// Drives the "filters applied" banner and whether the drawer auto-opens on load.
$has_drawer_filters = $advanced_search !== '' || count($filterClauses) > 0;
$has_active_filters = $has_drawer_filters || $keyword !== '' || $active_servers === '1';

// Reused to build the Export link, pagination links, and the drawer's own
// hidden fields so every filter survives navigation.
$filterQueryParams = [
    'keyword' => $keyword,
    'advanced_search' => $advanced_search,
    'active_servers' => $active_servers,
    'filter_os_family' => $filter_os_family,
    'filter_support_level' => $filter_support_level,
    'filter_project' => $filter_project,
    'filter_server_state' => $filter_server_state,
    'filter_server_type' => $filter_server_type,
    'filter_criticality' => $filter_criticality,
    'filter_domain' => $filter_domain,
    'filter_managed_by' => $filter_managed_by,
    'filter_dmz' => $filter_dmz,
    'filter_location' => $filter_location,
    'filter_application' => $filter_application,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
];
$filterQueryParams = array_filter($filterQueryParams, static fn($v) => $v !== '' && $v !== 'id' && $v !== 'DESC');

// Hidden fields so the page-size selector preserves the current
// search/filter/sort state instead of resetting it.
$hidden_filter_fields = '';
foreach ($filterQueryParams as $fk => $fv) {
    $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
}

$total = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE $where");
$total->execute($params);
$total_records = (int)$total->fetchColumn();
$total_pages = (int)ceil($total_records / $limit);
if ($total_pages > 0 && $page > $total_pages) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

/*
 * ORDER BY can name last_patch_date because it is selected as an alias
 * here -- SQLite resolves an ORDER BY term against the result columns.
 */
$stmt = $pdo->prepare("
    SELECT inventory.*, $inventory_last_patch_sql AS last_patch_date
    FROM inventory
    WHERE $where
    ORDER BY `$sort_by` $sort_dir
    LIMIT $limit OFFSET $start
");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$os_families = ['Windows', 'RHEL', 'RHCOS', 'Ubuntu', 'Rocky Linux', 'Debian', 'Appliance', 'Datapower', 'Suse linux', 'Fedora', 'Centos', 'Oralce Linux', 'FreeBSD', 'others', 'other linux'];
$server_states = ['powered on', 'powered off', 'decommissioned', 'to be decomm'];
$domains = ['mof.gov.sa', 'ncgr.gov.sa', 'moftest.com', 'mof.dmz', 'other'];
$joined_in_opts = ['redhat IPA', 'ldap', 'active directory', 'local'];
$roles_opts = ['APP', 'DB', 'WEB'];
$managed_by_opts = ['HCL', 'Ejada', 'STC', 'Alfa', 'MOF', 'NCGR', 'UGRP', 'Others', 'GRC', 'ADT'];
$cluster_opts = ['kubernetes', 'openshift', 'oracle ASM', 'Redhat pcs', 'nkp', 'others', 'rancher', 'no cluster'];
$server_types = ['Physical', 'Virtual'];
$yes_no = ['yes', 'no'];
$criticalities = ['critical', 'low', 'high', 'Mission critical', 'Business critical', 'medium', 'VIP', 'N/A'];
$db_opts = ['no', 'oracle', 'other DBs'];

$os_version_products = $pdo->query("SELECT DISTINCT product_name FROM license_warranty WHERE product_name IS NOT NULL AND product_name != '' ORDER BY product_name ASC")->fetchAll(PDO::FETCH_COLUMN);

$ownership_projects = $pdo->query("SELECT DISTINCT project FROM ownership WHERE project IS NOT NULL AND project != '' ORDER BY project ASC")->fetchAll(PDO::FETCH_COLUMN);

// ownership.support_level can hold a comma-joined list of levels
// (one owner covering several, e.g. "Production,DR") -- split every
// row back into individual level names before taking the distinct
// set, otherwise a combo like "Production,DR" would show up here as
// its own bogus dropdown option instead of two real ones.
$ownership_support_level_raw = $pdo->query("SELECT support_level FROM ownership WHERE support_level IS NOT NULL AND support_level != ''")->fetchAll(PDO::FETCH_COLUMN);
$ownership_support_levels = [];
foreach ($ownership_support_level_raw as $raw) {
    foreach (explode(',', $raw) as $lvl) {
        $lvl = trim($lvl);
        if ($lvl !== '' && !in_array($lvl, $ownership_support_levels, true)) {
            $ownership_support_levels[] = $lvl;
        }
    }
}
sort($ownership_support_levels);
if (empty($ownership_support_levels)) {
    $ownership_support_levels = ['production', 'pre-prod', 'sit', 'test', 'development', 'sandbox', 'DR', 'POC', 'Management'];
}

$page_title = "Inventory | InfraVault";
require 'includes/header.php';
?>
<link rel="stylesheet" href="assets/css/inventory.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">
    <div class="dashboard-header">
        <div>
            <h1>Server &amp; Application Inventory</h1>
            <p>Full lifecycle inventory of servers and applications, cross-linked with Ownership and IPAM.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="btn btn-primary enterprise-btn" onclick="openCreateModal()"><?php echo svgIcon('plus'); ?><span>Add Inventory</span></button>
            <?php endif; ?>

            <?php if ($canImport): ?>
                <button type="button" class="btn btn-success enterprise-btn" onclick="openImportModal()"><?php echo svgIcon('upload'); ?><span>Import</span></button>
            <?php endif; ?>

            <?php if ($canExport): ?>
                <a href="inventory.php?action=export&amp;<?php echo htmlspecialchars(http_build_query($filterQueryParams)); ?>" class="btn enterprise-btn"><?php echo svgIcon('download'); ?><span>Export</span></a>
            <?php endif; ?>

            <?php if ($canViewHistory): ?>
                <button type="button" class="btn enterprise-btn" onclick="openHistoryModal()"><?php echo svgIcon('history'); ?><span>History</span></button>
            <?php endif; ?>
            <button type="button" class="btn enterprise-btn" onclick="openColumnsModal()"><?php echo svgIcon('settings'); ?><span>Customize</span></button>
            <button type="button" class="btn btn-accent enterprise-btn" onclick="openAdvancedSearchModal()"><?php echo svgIcon('filter'); ?><span>Search Multiple Values</span></button>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="panel" style="padding:12px 22px;">
        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">
            <form method="GET" action="inventory.php" style="display:flex;gap:0.5rem;align-items:center;flex-wrap:wrap;">
                <input type="hidden" name="advanced_search" value="<?php echo htmlspecialchars($advanced_search); ?>">
                <?php foreach ($filterQueryParams as $fk => $fv): ?>
                    <?php if ($fk === 'keyword' || $fk === 'active_servers' || $fk === 'advanced_search') continue; ?>
                    <input type="hidden" name="<?php echo htmlspecialchars($fk); ?>" value="<?php echo htmlspecialchars($fv); ?>">
                <?php endforeach; ?>
                <label style="display:flex;align-items:center;gap:0.3rem;font-size:0.85rem;font-weight:600;cursor:pointer;">
                    <input type="checkbox" name="active_servers" value="1" <?php if($active_servers === '1') echo 'checked'; ?> onclick="this.form.submit();"> Active Servers
                </label>
                <input type="text" name="keyword" class="form-control" placeholder="Search hostname, IP, project..." value="<?php echo htmlspecialchars($keyword); ?>" style="width:280px;margin:0;" data-live-search="500">
                <button type="submit" class="btn btn-primary enterprise-btn"><?php echo svgIcon('search'); ?><span>Search</span></button>
                <button type="button" class="btn enterprise-btn" data-live-search-toggle onclick="toggleLiveSearch()" title="Toggle searching automatically as you type"></button>
            </form>

            <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
        </div>
    </div>

    <?php if ($has_active_filters):
        $filterSummaryParts = [];
        if ($advanced_search !== '') $filterSummaryParts[] = 'Multi-Search: ' . str_replace(["\r", "\n"], ' | ', $advanced_search);
        if ($keyword !== '') $filterSummaryParts[] = 'Keyword: ' . $keyword;
        if ($active_servers === '1') $filterSummaryParts[] = 'Active Servers only';
        $filterLabelMap = [
            'filter_os_family' => 'OS Family', 'filter_support_level' => 'Support Level', 'filter_project' => 'Project',
            'filter_server_state' => 'Server State', 'filter_server_type' => 'Server Type', 'filter_criticality' => 'Criticality',
            'filter_domain' => 'Domain', 'filter_managed_by' => 'Managed By', 'filter_dmz' => 'DMZ',
            'filter_location' => 'Location', 'filter_application' => 'Application',
        ];
        foreach ($filterLabelMap as $gkey => $flabel) {
            if (!empty($filterQueryParams[$gkey])) $filterSummaryParts[] = $flabel . ': ' . $filterQueryParams[$gkey];
        }
    ?>
        <div class="alert alert-info">
            <span><strong>Filters Applied:</strong> <?php echo htmlspecialchars(implode(' • ', $filterSummaryParts)); ?></span>
            <a href="inventory.php" class="btn btn-sm">Reset All Filters</a>
        </div>
    <?php endif; ?>

    <div class="panel" style="padding:0;">
        <div class="table-wrap" style="padding:0 22px;">
            <table class="data-table" id="inventoryTable">
                <thead><tr>
                    <?php foreach ($inventory_display_columns as $col_key => $col_label): ?>
                        <?php $is_visible = in_array($col_key, $visible_columns, true); ?>
                        <?php $is_sorted = ($sort_by === $col_key); ?>
                        <?php $sort_query = array_merge($filterQueryParams, ['sort_by' => $col_key, 'sort_dir' => ($is_sorted ? $next_sort_dir : 'ASC'), 'page' => 1]); ?>
                        <th class="col-th-<?php echo htmlspecialchars($col_key); ?> <?php echo $is_visible ? '' : 'hidden-col'; ?>" style="cursor:pointer;user-select:none;position:relative;">
                            <a href="inventory.php?<?php echo htmlspecialchars(http_build_query($sort_query)); ?>" style="text-decoration:none;color:inherit;display:flex;align-items:center;gap:6px;">
                                <span><?php echo htmlspecialchars($col_label); ?></span>
                                <?php if ($is_sorted): ?>
                                    <span style="font-size:11px;font-weight:bold;color:#2563EB;">
                                        <?php echo ($sort_dir === 'ASC') ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                    <?php endforeach; ?>
                    <th style="text-align:center;">Actions</th>
                </tr></thead>
                <tbody>
                <?php if (count($rows) > 0): ?>
                    <?php foreach ($rows as $r): ?>
                    <tr>
                        <?php foreach ($inventory_display_columns as $col_key => $col_label): ?>
                            <td class="col-td-<?php echo htmlspecialchars($col_key); ?> <?php echo in_array($col_key, $visible_columns, true) ? '' : 'hidden-col'; ?>">
                                <?php if ($col_key === 'hostname'): ?>
                                    <span class="cell-primary"><?php echo htmlspecialchars((string)($r[$col_key] ?? '')); ?></span>
                                <?php elseif ($col_key === 'support_level'): ?>
                                    <span class="badge"><?php echo htmlspecialchars((string)($r[$col_key] ?? '')); ?></span>
                                <?php elseif ($col_key === 'last_patch_date'): ?>
                                    <?php
                                    /*
                                     * Never patched is a real answer, not a
                                     * blank cell -- a blank here reads as
                                     * missing data.
                                     */
                                    $lastPatch = trim((string)($r['last_patch_date'] ?? ''));
                                    ?>
                                    <?php if ($lastPatch === ''): ?>
                                        <span style="color:var(--text-muted,#94A3B8);">Never</span>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($lastPatch); ?>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php echo htmlspecialchars((string)($r[$col_key] ?? '')); ?>
                                <?php endif; ?>
                            </td>
                        <?php endforeach; ?>
                        <td style="text-align:center;white-space:nowrap;">
                            <div class="row-actions enterprise-row-actions">
                                <button type="button" class="btn btn-sm enterprise-icon-btn" title="View details" aria-label="View details" onclick='openViewModal(<?php echo htmlspecialchars(json_encode($r, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8'); ?>)'><?php echo svgIcon('eye'); ?><span class="action-label">View</span></button>
                                <?php if ($canViewHistory): ?>
                                    <button type="button" class="btn btn-sm enterprise-icon-btn" title="View audit history for this record" aria-label="View audit history for this record" onclick='openHistoryModal(<?php echo (int)$r['id']; ?>)'><?php echo svgIcon('history'); ?><span class="action-label">History</span></button>
                                <?php endif; ?>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="btn btn-sm btn-primary enterprise-icon-btn" title="Edit inventory" aria-label="Edit inventory" onclick='openEditModal(<?php echo htmlspecialchars(json_encode($r, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8'); ?>)'><?php echo svgIcon('edit'); ?><span class="action-label">Edit</span></button>
                                    <button type="button" class="btn btn-sm enterprise-icon-btn" title="Clone inventory entry" aria-label="Clone inventory entry" onclick='openCloneModal(<?php echo htmlspecialchars(json_encode($r, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8'); ?>)'><?php echo svgIcon('clone'); ?><span class="action-label">Clone</span></button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="btn btn-sm btn-danger enterprise-icon-btn" title="Delete inventory" aria-label="Delete inventory" onclick='openDeleteModal(<?php echo (int)$r['id']; ?>, <?php echo json_encode((string)($r['hostname'] ?? '')); ?>)'><?php echo svgIcon('trash'); ?><span class="action-label">Delete</span></button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="<?php echo count($inventory_display_columns)+1; ?>"><p class="empty-state">No inventory entries available.</p></td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php echo ivPager($page, $total_pages, $filterQueryParams, [
            'base'          => 'inventory.php',
            'total_records' => $total_records,
            'per_page'      => $limit,
        ]); ?>
    </div>
</div>

<!-- ADVANCED SEARCH / FILTERS DRAWER (slides in from the right) -->
<div id="filterDrawerOverlay" class="filter-drawer-overlay" onclick="if (event.target === this) closeFilterDrawer();">
    <aside id="filterDrawer" class="filter-drawer" role="dialog" aria-label="Advanced Search and Filters">
        <div class="filter-drawer-header">
            <h3><?php echo svgIcon('filter'); ?><span>Search Multiple Values &amp; Filters</span></h3>
            <button type="button" class="close-modal" onclick="closeFilterDrawer()" aria-label="Close">&times;</button>
        </div>
        <form method="GET" action="inventory.php" class="filter-drawer-body-wrap">
            <?php if ($keyword !== ''): ?><input type="hidden" name="keyword" value="<?php echo htmlspecialchars($keyword); ?>"><?php endif; ?>
            <?php if ($active_servers === '1'): ?><input type="hidden" name="active_servers" value="1"><?php endif; ?>

            <div class="filter-drawer-body">
                <div class="form-group">
                    <label>Multi-Value Search (searches every column)</label>
                    <p class="filter-hint">One value per line, or separate with commas. Every column is searched, so a VLAN, rack, owner or serial finds its server.</p>
                    <p class="filter-hint" style="font-size:11px;color:#8B8B8B;">
                        <strong>Narrow to a column</strong> by naming it exactly as it appears in the table header &mdash;
                        values on one line are OR&#8209;ed, separate lines are AND&#8209;ed.<br>
                        <code style="background:var(--hover-bg);padding:2px 4px;border-radius:3px;">OS Family: RHEL</code> then
                        <code style="background:var(--hover-bg);padding:2px 4px;border-radius:3px;">OS Version: 7, 8</code>
                        finds RHEL 7 <em>or</em> 8 only &mdash; a plain list of <code style="background:var(--hover-bg);padding:2px 4px;border-radius:3px;">RHEL, 7, 8</code>
                        would also match any row with a 7 in its CPU count or IP.<br>
                        Use <code style="background:var(--hover-bg);padding:2px 4px;border-radius:3px;">=</code> instead of
                        <code style="background:var(--hover-bg);padding:2px 4px;border-radius:3px;">:</code> to match exactly rather than partially.
                    </p>
                    <textarea name="advanced_search" class="form-control" rows="5" placeholder="OS Family: RHEL&#10;OS Version: 7, 8&#10;Kernel Version: 9&#10;&#10;or a plain list:&#10;server-app-01&#10;192.168.1.50"><?php echo htmlspecialchars($advanced_search); ?></textarea>

                    <?php /* The column names, listed rather than left to be
                             guessed -- clicking one inserts it, so nobody has
                             to know the underlying database column. */ ?>
                    <details class="iv-fieldlist">
                        <summary>Column names you can use (<?php echo count($inventory_columns); ?>)</summary>
                        <div class="iv-fieldlist-items">
                            <?php foreach ($inventory_columns as $colKey => $colLabel): ?>
                                <button type="button" class="iv-fieldchip"
                                        data-field="<?php echo htmlspecialchars($colLabel, ENT_QUOTES); ?>"
                                        title="Insert &quot;<?php echo htmlspecialchars($colLabel, ENT_QUOTES); ?>:&quot;"><?php echo htmlspecialchars($colLabel); ?></button>
                            <?php endforeach; ?>
                        </div>
                    </details>
                </div>

                <div class="filter-drawer-grid">
                    <div class="form-group">
                        <label>OS Family</label>
                        <select name="filter_os_family" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($os_families as $o): ?><option value="<?php echo htmlspecialchars($o); ?>" <?php echo $filter_os_family === $o ? 'selected' : ''; ?>><?php echo htmlspecialchars($o); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Support Level</label>
                        <select name="filter_support_level" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($ownership_support_levels as $s): ?><option value="<?php echo htmlspecialchars($s); ?>" <?php echo $filter_support_level === $s ? 'selected' : ''; ?>><?php echo htmlspecialchars($s); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Project</label>
                        <select name="filter_project" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($ownership_projects as $proj): ?><option value="<?php echo htmlspecialchars($proj); ?>" <?php echo $filter_project === $proj ? 'selected' : ''; ?>><?php echo htmlspecialchars($proj); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Server State</label>
                        <select name="filter_server_state" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($server_states as $st): ?><option value="<?php echo htmlspecialchars($st); ?>" <?php echo $filter_server_state === $st ? 'selected' : ''; ?>><?php echo htmlspecialchars($st); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Server Type</label>
                        <select name="filter_server_type" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($server_types as $st): ?><option value="<?php echo htmlspecialchars($st); ?>" <?php echo $filter_server_type === $st ? 'selected' : ''; ?>><?php echo htmlspecialchars($st); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Criticality</label>
                        <select name="filter_criticality" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($criticalities as $cr): ?><option value="<?php echo htmlspecialchars($cr); ?>" <?php echo $filter_criticality === $cr ? 'selected' : ''; ?>><?php echo htmlspecialchars($cr); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Domain</label>
                        <select name="filter_domain" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($domains as $d): ?><option value="<?php echo htmlspecialchars($d); ?>" <?php echo $filter_domain === $d ? 'selected' : ''; ?>><?php echo htmlspecialchars($d); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Managed By</label>
                        <select name="filter_managed_by" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($managed_by_opts as $m): ?><option value="<?php echo htmlspecialchars($m); ?>" <?php echo $filter_managed_by === $m ? 'selected' : ''; ?>><?php echo htmlspecialchars($m); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>DMZ</label>
                        <select name="filter_dmz" class="form-control">
                            <option value="">Any</option>
                            <?php foreach ($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>" <?php echo $filter_dmz === $yn ? 'selected' : ''; ?>><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Location</label>
                        <input type="text" name="filter_location" class="form-control" placeholder="e.g. Riyadh DC1" value="<?php echo htmlspecialchars($filter_location); ?>">
                    </div>
                    <div class="form-group">
                        <label>Application</label>
                        <input type="text" name="filter_application" class="form-control" placeholder="e.g. Core Banking" value="<?php echo htmlspecialchars($filter_application); ?>">
                    </div>
                </div>
            </div>

            <div class="filter-drawer-footer">
                <a href="inventory.php" class="btn"><?php echo svgIcon('close'); ?><span>Reset All</span></a>
                <?php if ($canExport): ?>
                    <button type="submit" formaction="inventory.php?action=export" class="btn btn-success"><?php echo svgIcon('download'); ?><span>Export</span></button>
                <?php endif; ?>
                <button type="submit" class="btn btn-accent"><?php echo svgIcon('search'); ?><span>Search</span></button>
            </div>
        </form>
    </aside>
</div>

<!-- CREATE / EDIT MODAL -->
<div id="recordModal" class="modal-overlay">
    <div class="modal-content" style="max-width:950px;">
        <div class="modal-header"><div><h3 id="modalTitle">Add Server Inventory</h3><div id="modalSubtitle" class="modal-subtitle"></div></div><button type="button" class="close-modal" onclick="closeModal('recordModal')">&times;</button></div>
        <form method="POST" action="inventory.php">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="rec_id">
            <input type="hidden" name="clone_mode" id="rec_clone_mode" value="0">
            <input type="hidden" name="clone_source_id" id="rec_clone_source_id" value="">
            <div class="modal-grid">
                <div class="form-group"><label>Hostname *</label><input type="text" name="hostname" id="rec_hostname" class="form-control" required></div>
                <div class="form-group"><label>IP Address *</label><input type="text" name="ip_address" id="rec_ip_address" class="form-control" onblur="fetchIPDetails()" onchange="fetchIPDetails()" required></div>
                <div class="form-group"><label>Additional IPs (comma)</label><input type="text" name="additional_ips" id="rec_additional_ips" class="form-control"></div>
                <div class="form-group"><label>OS Family</label><select name="os_family" id="rec_os_family" class="form-control"><option value="">-- Select --</option><?php foreach($os_families as $o): ?><option value="<?php echo htmlspecialchars($o); ?>"><?php echo htmlspecialchars($o); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>OS Version</label><input type="text" name="os_version" id="rec_os_version" class="form-control" list="os_version_products" placeholder="Select or type a product..." onblur="checkEolStatus()" onchange="checkEolStatus()"><datalist id="os_version_products"><?php foreach($os_version_products as $p): ?><option value="<?php echo htmlspecialchars($p); ?>"><?php endforeach; ?></datalist></div>
                <div class="form-group"><label>Kernel Version</label><input type="text" name="kernel_version" id="rec_kernel_version" class="form-control"></div>
                <div class="form-group"><label>CPU</label><input type="text" name="cpu" id="rec_cpu" class="form-control"></div>
                <div class="form-group"><label>Memory</label><input type="text" name="memory" id="rec_memory" class="form-control"></div>
                <div class="form-group"><label>Support Level *</label><select name="support_level" id="rec_support_level" class="form-control" onchange="fetchOwnershipData()" required><option value="">-- Select --</option><?php foreach($ownership_support_levels as $s): ?><option value="<?php echo htmlspecialchars($s); ?>"><?php echo htmlspecialchars($s); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Server State</label><select name="server_state" id="rec_server_state" class="form-control"><?php foreach($server_states as $st): ?><option value="<?php echo htmlspecialchars($st); ?>"><?php echo htmlspecialchars($st); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Domain</label><select name="domain" id="rec_domain" class="form-control"><?php foreach($domains as $d): ?><option value="<?php echo htmlspecialchars($d); ?>"><?php echo htmlspecialchars($d); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Joined In</label><select name="joined_in" id="rec_joined_in" class="form-control"><?php foreach($joined_in_opts as $j): ?><option value="<?php echo htmlspecialchars($j); ?>"><?php echo htmlspecialchars($j); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Role</label><select name="role" id="rec_role" class="form-control"><option value="">-- Select --</option><?php foreach($roles_opts as $r): ?><option value="<?php echo htmlspecialchars($r); ?>"><?php echo htmlspecialchars($r); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Cluster Name</label><input type="text" name="cluster_name" id="rec_cluster_name" class="form-control"></div>
                <div class="form-group"><label>Managed By</label><select name="managed_by" id="rec_managed_by" class="form-control"><?php foreach($managed_by_opts as $m): ?><option value="<?php echo htmlspecialchars($m); ?>"><?php echo htmlspecialchars($m); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Cluster Type</label><select name="cluster_type" id="rec_cluster_type" class="form-control"><option value="">-- Select --</option><?php foreach($cluster_opts as $c): ?><option value="<?php echo htmlspecialchars($c); ?>"><?php echo htmlspecialchars($c); ?></option><?php endforeach; ?></select></div>
                <div class="form-group" style="position:relative;"><label>Project *</label><input type="text" name="project" id="rec_project" class="form-control" placeholder="Search project..." autocomplete="off" required oninput="searchProjects(this.value)" onfocus="searchProjects(this.value)"><div id="projectSuggestions" class="autocomplete-suggestions" style="display:none;"></div></div>
                <div class="form-group"><label>Application</label><input type="text" name="application" id="rec_application" class="form-control"></div>
                <?php
                $ownershipFields = [
                    'technical_owner'=>'Technical Owner','technical_owner_email'=>'Technical Owner Email','team_dl'=>'Team DL',
                    'technical_manager'=>'Technical Manager','technical_manager_email'=>'Technical Manager Email','sdm_name'=>'SDM Name',
                    'sdm_email'=>'SDM Email','ncgr_owner'=>'NCGR Owner','ncgr_owner_email'=>'NCGR Owner Email'
                ];
                foreach ($ownershipFields as $field=>$label):
                ?>
                    <div class="form-group"><label><?php echo htmlspecialchars($label); ?></label><input type="text" name="<?php echo $field; ?>" id="rec_<?php echo $field; ?>" class="form-control auto-filled-field" readonly></div>
                <?php endforeach; ?>
                <div class="form-group"><label>Server Type</label><select name="server_type" id="rec_server_type" class="form-control"><option value="">-- Select --</option><?php foreach($server_types as $st): ?><option value="<?php echo htmlspecialchars($st); ?>"><?php echo htmlspecialchars($st); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Appliance</label><select name="appliance" id="rec_appliance" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Port Group</label><input type="text" name="port_group" id="rec_port_group" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>VLAN</label><input type="text" name="vlan" id="rec_vlan" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>Location</label><input type="text" name="location" id="rec_location" class="form-control"></div>
                <div class="form-group"><label>Criticality</label><select name="criticality" id="rec_criticality" class="form-control"><option value="">-- Select --</option><?php foreach($criticalities as $cr): ?><option value="<?php echo htmlspecialchars($cr); ?>"><?php echo htmlspecialchars($cr); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Project Code</label><input type="text" name="project_code" id="rec_project_code" class="form-control"></div>
                <div class="form-group"><label>Commissioned Date</label><input type="date" name="commissioned_date" id="rec_commissioned_date" class="form-control"></div>
                <div class="form-group"><label>Host Type</label><input type="text" name="host_type" id="rec_host_type" class="form-control"></div>
                <div class="form-group" style="position:relative;"><label>HW Model (Asset Name)</label><input type="text" name="hw_model" id="rec_hw_model" class="form-control" placeholder="Search asset name..." autocomplete="off" oninput="searchHardware(this.value)"><div id="hwSuggestions" class="autocomplete-suggestions" style="display:none;"></div></div>
                <div class="form-group"><label>ESXI Cluster</label><input type="text" name="esxi_cluster" id="rec_esxi_cluster" class="form-control"></div>
                <div class="form-group"><label>Vendor</label><input type="text" name="vendor" id="rec_vendor" class="form-control"></div>
                <div class="form-group"><label>DMZ</label><select name="dmz" id="rec_dmz" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>DB Type</label><select name="db_type" id="rec_db_type" class="form-control"><option value="">-- Select --</option><?php foreach($db_opts as $db): ?><option value="<?php echo htmlspecialchars($db); ?>"><?php echo htmlspecialchars($db); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Live</label><select name="live" id="rec_live" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>EOL</label><select name="eol" id="rec_eol" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>GRC</label><select name="grc" id="rec_grc" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>UGRP</label><select name="ugrp" id="rec_ugrp" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Backup</label><select name="backup" id="rec_backup" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Monitoring</label><select name="monitoring" id="rec_monitoring" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Infra</label><select name="infra" id="rec_infra" class="form-control"><option value="">-- Select --</option><?php foreach($yes_no as $yn): ?><option value="<?php echo htmlspecialchars($yn); ?>"><?php echo htmlspecialchars($yn); ?></option><?php endforeach; ?></select></div>
            </div>
            <div class="form-group" id="commentFieldGroup" style="display:none;margin-top:1rem;"><label>Edit Comments (Required/Recorded in history)</label><textarea name="edit_comments" id="rec_edit_comments" class="form-control" rows="2" placeholder="Describe edits..."></textarea></div>
            <div class="modal-footer"><button type="button" class="btn" onclick="closeModal('recordModal')">Cancel</button><button type="submit" class="btn btn-primary">Save Inventory</button></div>
        </form>
    </div>
</div>

<!-- CSV IMPORT MODAL -->
<div id="importModal" class="modal-overlay">
    <div class="modal-content" style="max-width:600px;">
        <div class="modal-header"><h3>Bulk Import Inventory (CSV / Multi-Line)</h3><button type="button" class="close-modal" onclick="closeModal('importModal')">&times;</button></div>
        <form method="POST" action="inventory.php" enctype="multipart/form-data">
            <input type="hidden" name="form_action" value="import_csv">
            <div class="form-group" style="margin-top:1rem;"><label><strong>Option A: Upload CSV File</strong></label><input type="file" name="csv_file" accept=".csv,.txt" class="form-control"></div>
            <hr style="margin:1.5rem 0;border:0;border-top:1px solid var(--border-color);">
            <div class="form-group"><label><strong>Option B: Paste Multi-Line CSV Data</strong></label><p style="font-size:0.8rem;color:var(--text-secondary);margin-bottom:0.5rem;">Paste comma-separated rows. Each line represents one server record matching the export structure.</p><textarea name="csv_data" class="form-control" rows="8" placeholder="hostname,ip_address,additional_ips,os_family,..."></textarea></div>
            <div class="modal-footer"><button type="button" class="btn" onclick="closeModal('importModal')">Cancel</button><button type="submit" class="btn btn-success">Import Records</button></div>
        </form>
    </div>
</div>

<!-- VIEW MODAL -->
<div id="viewModal" class="modal-overlay">
    <div class="modal-content" style="max-width:650px;">
        <div class="modal-header"><h3>Server Inventory Details</h3><button type="button" class="close-modal" onclick="closeModal('viewModal')">&times;</button></div>
        <div id="viewContent" style="max-height:60vh;overflow-y:auto;margin-top:1rem;font-size:0.9rem;line-height:1.6;display:grid;grid-template-columns:1fr 1fr;gap:0.5rem;"></div>
        <div class="modal-footer" style="justify-content:flex-end;"><button type="button" class="btn btn-primary" onclick="closeModal('viewModal')">Close</button></div>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content" style="max-width:400px;text-align:center;">
        <div class="modal-header"><h3>Confirm Delete</h3><button type="button" class="close-modal" onclick="closeModal('deleteModal')">&times;</button></div>
        <p style="margin:1rem 0;color:var(--text-secondary);">Delete server <strong id="del_name"></strong>?</p>
        <form method="POST" action="inventory.php"><input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" id="del_id"><div class="modal-footer" style="justify-content:center;"><button type="button" class="btn" onclick="closeModal('deleteModal')">Cancel</button><button type="submit" class="btn btn-danger">Delete</button></div></form>
    </div>
</div>

<!-- HISTORY MODAL -->
<div id="historyModal" class="modal-overlay">
    <div class="modal-content" style="max-width:700px;"><div class="modal-header"><h3 id="historyModalTitle">Audit History</h3><button type="button" class="close-modal" onclick="closeModal('historyModal')">&times;</button></div><div id="historyContent" style="max-height:50vh;overflow-y:auto;margin-top:1rem;"><p class="empty-state">Loading...</p></div></div>
</div>

<!-- COLUMNS MODAL -->
<div id="columnsModal" class="modal-overlay">
    <div class="modal-content columns-preferences-modal">
        <div class="modal-header">
            <div>
                <h3>Customize Visible Fields</h3>
                <div class="modal-subtitle">Your layout is saved to your user profile and will be restored on your next login.</div>
            </div>
            <button type="button" class="close-modal" onclick="closeModal('columnsModal')" aria-label="Close"><?php echo svgIcon('close'); ?></button>
        </div>
        <form id="columnPreferencesForm" onsubmit="saveColumnPreferences(event)">
            <input type="hidden" name="form_action" value="save_columns">
            <input type="hidden" name="visible_columns" id="visibleColumnsInput">
            <div class="column-preferences-grid">
                <?php foreach ($inventory_display_columns as $col_key => $col_label): ?>
                    <?php $is_checked = in_array($col_key, $visible_columns, true); ?>
                    <label class="column-preference-item">
                        <input type="checkbox" data-column="<?php echo htmlspecialchars($col_key); ?>" <?php echo $is_checked ? 'checked' : ''; ?> onchange="toggleCol('<?php echo htmlspecialchars($col_key); ?>', this.checked)">
                        <span><?php echo htmlspecialchars($col_label); ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <div class="modal-footer preference-footer">
                <button type="button" class="btn enterprise-btn" onclick="resetColumnPreferences()">Reset Defaults</button>
                <span id="columnSaveStatus" class="save-status"></span>
                <button type="button" class="btn" onclick="closeModal('columnsModal')">Cancel</button>
                <button type="submit" class="btn btn-primary enterprise-btn"><?php echo svgIcon('save'); ?><span>Save Preferences</span></button>
            </div>
        </form>
    </div>
</div>

<script>
const PROJECT_LIST = <?php echo json_encode(array_values($ownership_projects), JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_AMP|JSON_HEX_QUOT); ?>;

function clearRecordForm() {
    document.querySelectorAll('#recordModal input').forEach(i => {
        if (i.type !== 'hidden') i.value = '';
    });
    document.querySelectorAll('#recordModal textarea').forEach(t => t.value = '');
    document.querySelectorAll('#recordModal select').forEach(s => s.selectedIndex = 0);
    document.getElementById('rec_clone_mode').value = '0';
    document.getElementById('rec_clone_source_id').value = '';
    document.getElementById('commentFieldGroup').style.display = 'none';
    document.getElementById('hwSuggestions').style.display = 'none';
    document.getElementById('modalSubtitle').innerText = '';
}

function openCreateModal() {
    document.getElementById('modalTitle').innerText = 'Add Server Inventory';
    clearRecordForm();
    document.getElementById('rec_id').value = '';
    document.getElementById('recordModal').style.display = 'flex';
}

function openImportModal() { document.getElementById('importModal').style.display = 'flex'; }
function openAdvancedSearchModal() { document.getElementById('filterDrawerOverlay').classList.add('open'); }
function closeFilterDrawer() { document.getElementById('filterDrawerOverlay').classList.remove('open'); }

function openEditModal(d) {
    document.getElementById('modalTitle').innerText = 'Edit Server Inventory';
    document.getElementById('rec_id').value = d.id || '';
    document.getElementById('rec_clone_mode').value = '0';
    document.getElementById('rec_clone_source_id').value = '';
    document.getElementById('modalSubtitle').innerText = 'Update the inventory record and save your changes.';

    // Reset textarea and fields first.
    document.querySelectorAll('#recordModal input').forEach(i => {
        if (i.type !== 'hidden') i.value = '';
    });
    document.querySelectorAll('#recordModal textarea').forEach(t => t.value = '');

    for (let k in d) {
        const el = document.getElementById('rec_' + k);
        if (el) {
            const value = d[k] === null || d[k] === undefined ? '' : d[k];
            if (el.tagName === 'SELECT') {
                const optionExists = Array.from(el.options).some(o => o.value == value);
                if (!optionExists && value !== '') {
                    const option = new Option(value, value);
                    el.add(option);
                }
                el.value = value;
            } else {
                el.value = value;
            }
        }
    }

    document.getElementById('commentFieldGroup').style.display = 'block';
    document.getElementById('recordModal').style.display = 'flex';
    checkEolStatus();
}

function openCloneModal(d) {
    document.getElementById('modalTitle').innerText = 'Clone Server Inventory';
    document.getElementById('modalSubtitle').innerText = 'Enter a new unique hostname and IP address. All other inventory fields are copied from the source record.';
    document.getElementById('rec_id').value = '';
    document.getElementById('rec_clone_mode').value = '1';
    document.getElementById('rec_clone_source_id').value = d.id || '';

    document.querySelectorAll('#recordModal input').forEach(i => {
        if (i.type !== 'hidden') i.value = '';
    });
    document.querySelectorAll('#recordModal textarea').forEach(t => t.value = '');

    for (let k in d) {
        if (k === 'id' || k === 'hostname' || k === 'ip_address' || k === 'created_by' || k === 'edit_comments' || k === 'updated_by' || k === 'updated_at') continue;
        const el = document.getElementById('rec_' + k);
        if (!el) continue;
        const value = d[k] === null || d[k] === undefined ? '' : d[k];
        if (el.tagName === 'SELECT') {
            const optionExists = Array.from(el.options).some(o => o.value == value);
            if (!optionExists && value !== '') el.add(new Option(value, value));
            el.value = value;
        } else {
            el.value = value;
        }
    }

    // New identity fields are intentionally blank; IPAM/ownership will be recalculated.
    document.getElementById('rec_hostname').value = '';
    document.getElementById('rec_ip_address').value = '';
    document.getElementById('rec_port_group').value = '';
    document.getElementById('rec_vlan').value = '';
    document.getElementById('rec_edit_comments').value = '';
    document.getElementById('commentFieldGroup').style.display = 'none';
    document.getElementById('recordModal').style.display = 'flex';
    setTimeout(() => document.getElementById('rec_hostname').focus(), 50);
}

function openViewModal(d) {
    let html = '';
    for (let k in d) {
        const label = k.replace(/_/g, ' ');
        const value = d[k] === null || d[k] === undefined || d[k] === '' ? '-' : String(d[k]);
        html += `<div style="padding:0.25rem 0;border-bottom:1px solid var(--border-light);"><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</div>`;
    }
    document.getElementById('viewContent').innerHTML = html;
    document.getElementById('viewModal').style.display = 'flex';
}

function escapeHtml(value) {
    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

function openDeleteModal(id, name) {
    document.getElementById('del_id').value = id;
    document.getElementById('del_name').innerText = name;
    document.getElementById('deleteModal').style.display = 'flex';
}
function openColumnsModal() {
    document.getElementById('columnsModal').style.display = 'flex';
    document.getElementById('columnSaveStatus').innerText = '';
}

function closeModal(id) { document.getElementById(id).style.display = 'none'; }

function toggleCol(colKey, show) {
    document.querySelectorAll('.col-th-' + colKey + ', .col-td-' + colKey).forEach(el => {
        el.classList.toggle('hidden-col', !show);
    });
}

function getSelectedColumns() {
    return Array.from(document.querySelectorAll('#columnsModal input[type="checkbox"][data-column]:checked'))
        .map(cb => cb.dataset.column);
}

function saveColumnPreferences(event) {
    event.preventDefault();
    const selected = getSelectedColumns();
    if (selected.length === 0) {
        document.getElementById('columnSaveStatus').innerText = 'Select at least one field.';
        return;
    }

    const formData = new FormData();
    formData.append('form_action', 'save_columns');
    formData.append('visible_columns', JSON.stringify(selected));

    const status = document.getElementById('columnSaveStatus');
    status.innerText = 'Saving...';
    fetch('inventory.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            status.innerText = data.message || (data.ok ? 'Saved.' : 'Unable to save.');
            if (data.ok) setTimeout(() => closeModal('columnsModal'), 700);
        })
        .catch(() => { status.innerText = 'Unable to save preferences.'; });
}

function resetColumnPreferences() {
    const defaults = ['hostname','ip_address','os_family','support_level','project'];
    document.querySelectorAll('#columnsModal input[type="checkbox"][data-column]').forEach(cb => {
        cb.checked = defaults.includes(cb.dataset.column);
        toggleCol(cb.dataset.column, cb.checked);
    });
}

// Opens the audit history modal.
// Call with no argument for the full/global history (toolbar button).
// Call with an inventory record id to scope the history to that single record
// (per-row "History" button). Both paths are gated server-side on can_audit.
function openHistoryModal(id) {
    document.getElementById('historyModal').style.display = 'flex';
    document.getElementById('historyModalTitle').innerText = id ? 'Audit History (Record #' + id + ')' : 'Audit History';
    document.getElementById('historyContent').innerHTML = '<p class="empty-state">Loading...</p>';

    const url = id
        ? `inventory.php?action=get_history&inventory_id=${encodeURIComponent(id)}`
        : 'inventory.php?action=get_history';

    fetch(url)
        .then(r => r.text())
        .then(h => document.getElementById('historyContent').innerHTML = h)
        .catch(() => document.getElementById('historyContent').innerHTML = '<p class="empty-state">Unable to load history.</p>');
}

function fetchOwnershipData() {
    const project = document.getElementById('rec_project').value;
    const supportLevel = document.getElementById('rec_support_level').value;
    if (!project || !supportLevel) return;

    fetch(`inventory.php?action=get_ownership_details&project=${encodeURIComponent(project)}&support_level=${encodeURIComponent(supportLevel)}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('rec_technical_owner').value = data.technical_owner || '';
            document.getElementById('rec_technical_owner_email').value = data.technical_owner_email || '';
            document.getElementById('rec_team_dl').value = data.team_dl || '';
            document.getElementById('rec_technical_manager').value = data.technical_manager || '';
            document.getElementById('rec_technical_manager_email').value = data.technical_manager_email || '';
            document.getElementById('rec_sdm_name').value = data.sdm_name || '';
            document.getElementById('rec_sdm_email').value = data.sdm_email || '';
            document.getElementById('rec_ncgr_owner').value = data.ncgr_owner || '';
            document.getElementById('rec_ncgr_owner_email').value = data.ncgr_owner_email || '';
        })
        .catch(err => console.error('Error fetching ownership details:', err));
}

function fetchIPDetails() {
    const ip = document.getElementById('rec_ip_address').value;
    if (!ip) return;

    fetch(`inventory.php?action=get_ip_details&ip=${encodeURIComponent(ip)}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('rec_port_group').value = data.port_group || '';
            document.getElementById('rec_vlan').value = data.vlan || '';
        })
        .catch(err => console.error('Error fetching IP details:', err));
}

function checkEolStatus() {
    const osVersion = document.getElementById('rec_os_version').value.trim();
    if (!osVersion) return;

    fetch(`inventory.php?action=get_eol_status&os_version=${encodeURIComponent(osVersion)}`)
        .then(response => response.json())
        .then(data => {
            if (data.matched && data.is_past) {
                document.getElementById('rec_eol').value = 'yes';
            }
        })
        .catch(err => console.error('Error checking EOL status:', err));
}

function searchHardware(query) {
    const container = document.getElementById('hwSuggestions');
    if (!query || query.trim().length < 1) {
        container.style.display = 'none';
        container.innerHTML = '';
        return;
    }

    fetch(`inventory.php?action=search_hardware&q=${encodeURIComponent(query.trim())}`)
        .then(res => res.json())
        .then(data => {
            if (Array.isArray(data) && data.length > 0) {
                container.innerHTML = '';
                data.forEach(item => {
                    const suggestion = document.createElement('div');
                    suggestion.className = 'autocomplete-suggestion';
                    const name = item.asset_name || '';
                    const mfg = item.manufacturer || 'N/A';
                    const loc = item.location || '';
                    suggestion.textContent = `${name} (${mfg})${loc ? ' — ' + loc : ''}`;
                    suggestion.addEventListener('click', () => selectHardware(name, mfg, loc));
                    container.appendChild(suggestion);
                });
                container.style.display = 'block';
            } else {
                container.style.display = 'none';
                container.innerHTML = '';
            }
        })
        .catch(err => {
            console.error('Error searching hardware:', err);
            container.style.display = 'none';
        });
}

// Fixed function name: HTML/JS calls selectHardware().
function selectHardware(assetName, manufacturer, location) {
    document.getElementById('rec_hw_model').value = assetName || '';
    document.getElementById('rec_vendor').value = (manufacturer && manufacturer !== 'N/A') ? manufacturer : '';

    const locationField = document.getElementById('rec_location');
    if (locationField && location && location.trim() !== '') locationField.value = location;

    document.getElementById('hwSuggestions').style.display = 'none';
}

document.addEventListener('click', function(e) {
    const hwInput = document.getElementById('rec_hw_model');
    const container = document.getElementById('hwSuggestions');
    if (hwInput && container && !hwInput.contains(e.target) && !container.contains(e.target)) {
        container.style.display = 'none';
    }
});

// Client-side searchable Project field -- the list is already on the page
// (PROJECT_LIST), so filtering it locally avoids a round trip per keystroke.
function searchProjects(query) {
    const container = document.getElementById('projectSuggestions');
    const q = (query || '').trim().toLowerCase();
    const matches = q === '' ? PROJECT_LIST : PROJECT_LIST.filter(p => p.toLowerCase().includes(q));

    if (matches.length === 0) {
        container.style.display = 'none';
        container.innerHTML = '';
        return;
    }

    container.innerHTML = '';
    matches.slice(0, 30).forEach(name => {
        const suggestion = document.createElement('div');
        suggestion.className = 'autocomplete-suggestion';
        suggestion.textContent = name;
        suggestion.addEventListener('click', () => selectProject(name));
        container.appendChild(suggestion);
    });
    container.style.display = 'block';
}

function selectProject(name) {
    document.getElementById('rec_project').value = name;
    document.getElementById('projectSuggestions').style.display = 'none';
    fetchOwnershipData();
}

document.addEventListener('click', function(e) {
    const projectInput = document.getElementById('rec_project');
    const container = document.getElementById('projectSuggestions');
    if (projectInput && container && !projectInput.contains(e.target) && !container.contains(e.target)) {
        container.style.display = 'none';
    }
});

// Close modal when clicking outside the modal content.
// Modals that hold user-entered form data (Add/Edit and CSV Import) are
// excluded so an accidental click on the backdrop doesn't discard input.
var NO_BACKDROP_CLOSE = ['recordModal', 'importModal'];
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target !== modal) return;
        if (NO_BACKDROP_CLOSE.indexOf(modal.id) !== -1) return;
        modal.style.display = 'none';
    });
});

document.addEventListener('keydown', function(e) {
    if (e.key === 'Escape') closeFilterDrawer();
});

<?php if ($has_drawer_filters): ?>
document.addEventListener('DOMContentLoaded', function() { openAdvancedSearchModal(); });
<?php endif; ?>

</script>

<style>
.enterprise-btn{display:inline-flex;align-items:center;justify-content:center;gap:.45rem;}
.ui-icon{width:16px;height:16px;display:inline-block;flex:0 0 16px;}
.enterprise-row-actions{display:flex;align-items:center;justify-content:center;gap:.3rem;}
.enterprise-icon-btn{display:inline-flex;align-items:center;justify-content:center;gap:0;width:32px;height:32px;min-width:32px;padding:0;}
.enterprise-icon-btn .ui-icon{width:15px;height:15px;}
.enterprise-icon-btn .action-label{position:absolute;width:1px;height:1px;padding:0;margin:-1px;overflow:hidden;clip:rect(0,0,0,0);white-space:nowrap;border:0;}
.modal-subtitle{font-size:.78rem;color:var(--text-secondary);margin-top:.2rem;font-weight:400;}
.columns-preferences-modal{max-width:720px;}
.column-preferences-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:.55rem;max-height:55vh;overflow-y:auto;margin-top:1rem;padding:.15rem .2rem .4rem;}
.column-preference-item{display:flex;align-items:center;gap:.65rem;padding:.65rem .75rem;border:1px solid var(--border-color);border-radius:8px;background:var(--bg-content);cursor:pointer;transition:border-color .15s ease,background .15s ease,box-shadow .15s ease;}
.column-preference-item:hover{border-color:var(--text-muted);background:var(--hover-bg);}
.column-preference-item input{width:16px;height:16px;accent-color:#2563EB;}
.preference-footer{align-items:center;}
.save-status{font-size:.8rem;color:#16A34A;margin-right:auto;}
.audit-details{font-size:.82rem;line-height:1.5;max-width:340px;white-space:normal;}
@media (max-width:760px){.column-preferences-grid{grid-template-columns:1fr}.enterprise-row-actions{gap:.2rem}}

/* Searchable column names, listed under the multi-value box so the field
   names are readable rather than guessed. */
.iv-fieldlist{margin-top:.5rem;font-size:11.5px;}
.iv-fieldlist summary{cursor:pointer;color:#2563EB;user-select:none;padding:.25rem 0;}
.iv-fieldlist summary:hover{text-decoration:underline;}
.iv-fieldlist-items{display:flex;flex-wrap:wrap;gap:5px;margin-top:.5rem;max-height:190px;overflow-y:auto;padding:.15rem;}
.iv-fieldchip{border:1px solid var(--border-color);background:var(--hover-bg);color:var(--text-primary);border-radius:6px;padding:3px 8px;font-size:11.5px;font-family:inherit;cursor:pointer;transition:border-color .12s,background .12s,color .12s;}
.iv-fieldchip:hover{border-color:#2563EB;background:#EFF6FF;color:#1D4ED8;}
[data-theme="dark"] .iv-fieldchip{background:rgba(255,255,255,.05);border-color:var(--border-color);color:#CBD5E1;}
</style>

<script>
/*
 * Clicking a column name appends "Label: " on its own line in the
 * multi-value box, so the exact spelling never has to be typed or looked
 * up. Appending rather than replacing keeps whatever is already there.
 */
document.addEventListener('click', function (e) {
    const chip = e.target.closest('.iv-fieldchip');
    if (!chip) { return; }

    const box = document.querySelector('textarea[name="advanced_search"]');
    if (!box) { return; }

    const line = chip.dataset.field + ': ';
    const current = box.value;

    box.value = current === '' ? line
        : (current.endsWith('\n') ? current + line : current + '\n' + line);

    box.focus();
    box.selectionStart = box.selectionEnd = box.value.length;
});
</script>

<?php require 'includes/footer.php'; ?>
