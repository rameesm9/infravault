<?php
/**
 * Ticket tracking -- a local record of change/incident tickets raised in
 * whatever external system the team uses.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('ticket', 'can_view');

$canEdit   = can('ticket', 'can_edit');
$canDelete = can('ticket', 'can_delete');
$canExport = can('ticket', 'can_export');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

$statuses   = ['Open', 'In Progress', 'Pending', 'On Hold', 'Resolved', 'Closed', 'Cancelled'];
$priorities = ['Critical', 'High', 'Medium', 'Low'];
$categories = ['Incident', 'Change Request', 'Service Request', 'Problem', 'Task', 'Access Request'];
$systems    = ['ServiceNow', 'Jira', 'Remedy', 'BMC', 'Manual', 'Other'];

$tFields = [
    'ticket_number' => 'Ticket Number',
    'title'         => 'Title',
    'description'   => 'Description',
    'ticket_date'   => 'Date Raised',
    'due_date'      => 'Due Date',
    'closed_date'   => 'Closed Date',
    'status'        => 'Status',
    'priority'      => 'Priority',
    'category'      => 'Category',
    'ticket_system' => 'System',
    'project'       => 'Project',
    'application'   => 'Application',
    'hostname'      => 'Hostname',
    'requester'     => 'Requester',
    'assigned_to_id' => 'Assigned To',
    'external_link' => 'Link',
    'resolution'    => 'Resolution',
    'notes'         => 'Notes',
];


/* ---------------- FILTERS ---------------- */

$q        = trim((string) ($_GET['q'] ?? ''));
$fStatus  = trim((string) ($_GET['f_status'] ?? ''));
$fPrio    = trim((string) ($_GET['f_prio'] ?? ''));
$fCat     = trim((string) ($_GET['f_cat'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(t.ticket_number LIKE ? OR t.title LIKE ? OR t.description LIKE ? OR t.hostname LIKE ?
                 OR u.first_name LIKE ? OR u.last_name LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fStatus !== '') { $where[] = 't.status = ?';   $params[] = $fStatus; }
if ($fPrio !== '')   { $where[] = 't.priority = ?'; $params[] = $fPrio; }
if ($fCat !== '')    { $where[] = 't.category = ?'; $params[] = $fCat; }

$whereSql = implode(' AND ', $where);

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('ticket', 'can_export');

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=tickets_' . date('Y-m-d') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, array_values($tFields));

    $stmt = $pdo->prepare("
        SELECT t.*, u.first_name AS assignee_first, u.last_name AS assignee_last
        FROM tickets t
        LEFT JOIN users u ON u.id = t.assigned_to_id
        WHERE $whereSql
        ORDER BY t.id DESC
    ");
    $stmt->execute($params);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $line = [];
        foreach (array_keys($tFields) as $col) {
            if ($col === 'assigned_to_id') {
                $assignee = trim((string) ($row['assigned_to_name'] ?? ''));
                if ($assignee === '') {
                    $assignee = trim(($row['assignee_first'] ?? '') . ' ' . ($row['assignee_last'] ?? ''));
                }
                $line[] = $assignee;
                continue;
            }
            $line[] = $row[$col] ?? '';
        }
        fputcsv($out, $line);
    }

    fclose($out);
    exit;
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('ticket', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);
        $data = [];
        foreach (array_keys($tFields) as $col) {
            if ($col === 'assigned_to_id') {
                $raw = trim((string) ($_POST['assigned_to_id'] ?? ''));
                $data[$col] = $raw !== '' ? (int) $raw : null;
                continue;
            }
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        if ($data['ticket_number'] === '') {
            $err = 'Ticket number is required.';
        } else {
            try {
                if ($id > 0) {
                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $pdo->prepare("UPDATE tickets SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($data), $username, $id]);
                    $msg = 'Ticket updated.';
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $pdo->prepare("INSERT INTO tickets ($cols, created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($data), $username]);
                    $msg = 'Ticket added.';
                }
            } catch (Throwable $e) {
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('ticket', 'can_delete');
        $pdo->prepare("DELETE FROM tickets WHERE id = ?")->execute([(int) ($_POST['id'] ?? 0)]);
        $msg = 'Ticket deleted.';
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("
    SELECT t.*, u.first_name AS assignee_first, u.last_name AS assignee_last
    FROM tickets t
    LEFT JOIN users u ON u.id = t.assigned_to_id
    WHERE $whereSql ORDER BY
        CASE WHEN t.closed_date IS NULL OR t.closed_date = '' THEN 0 ELSE 1 END,
        t.ticket_date DESC, t.id DESC
");
$stmt->execute($params);
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($tickets as &$t) {
    $t['assignee_name'] = trim((string) ($t['assigned_to_name'] ?? ''));
    if ($t['assignee_name'] === '') {
        $t['assignee_name'] = trim(($t['assignee_first'] ?? '') . ' ' . ($t['assignee_last'] ?? ''));
    }
}
unset($t);

$total = count($tickets);
$open = $overdue = $critical = 0;
$today = date('Y-m-d');

foreach ($tickets as $t) {
    $isClosed = in_array((string) $t['status'], ['Resolved', 'Closed', 'Cancelled'], true);
    if (!$isClosed) { $open++; }
    if (!$isClosed && !empty($t['due_date']) && $t['due_date'] < $today) { $overdue++; }
    if (!$isClosed && (string) $t['priority'] === 'Critical') { $critical++; }
}

$hostnames = platformHostnames($pdo);

$assigneeOptions = $pdo->query("
    SELECT id, first_name, last_name, ncgr_id FROM users
    WHERE is_approved = 1
    ORDER BY first_name ASC, last_name ASC
")->fetchAll(PDO::FETCH_ASSOC);

$page_title = 'Ticket Tracking | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🎫</div>
            <div>
                <h1>Ticket Tracking</h1>
                <p>Change, incident and service tickets raised for this infrastructure.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="tkOpen()">+ Add Ticket</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_status=<?= urlencode($fStatus) ?>&amp;f_prio=<?= urlencode($fPrio) ?>&amp;f_cat=<?= urlencode($fCat) ?>">Export CSV</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $total ?></b><span>Shown</span></div>
        <div class="plat-stat tone-warn"><b><?= $open ?></b><span>Open</span></div>
        <div class="plat-stat tone-crit"><b><?= $critical ?></b><span>Critical Open</span></div>
        <div class="plat-stat tone-crit"><b><?= $overdue ?></b><span>Past Due</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search &amp; Filters</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Number, title, description, host…">
                </div>
                <div class="plat-field">
                    <label>Status</label>
                    <select name="f_status">
                        <option value="">All</option>
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Priority</label>
                    <select name="f_prio">
                        <option value="">All</option>
                        <?php foreach ($priorities as $p): ?><option value="<?= plat_h($p) ?>" <?= $fPrio === $p ? 'selected' : '' ?>><?= plat_h($p) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Category</label>
                    <select name="f_cat">
                        <option value="">All</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>" <?= $fCat === $c ? 'selected' : '' ?>><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="tickets.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Tickets</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $total ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Ticket</th><th>Description</th><th>Date</th><th>Priority</th>
                        <th>Status</th><th>Assigned To</th><th>System / Host</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$tickets): ?>
                    <tr><td colspan="8"><p class="plat-empty">No tickets recorded yet.</p></td></tr>
                <?php else: foreach ($tickets as $t): ?>
                    <?php
                        $isClosed = in_array((string) $t['status'], ['Resolved', 'Closed', 'Cancelled'], true);
                        $isOverdue = !$isClosed && !empty($t['due_date']) && $t['due_date'] < $today;
                        $prioTone = match ((string) $t['priority']) {
                            'Critical' => 'crit', 'High' => 'warn', 'Low' => 'neutral', default => 'neutral',
                        };
                        $statusTone = $isClosed ? 'ok' : ((string) $t['status'] === 'On Hold' ? 'warn' : 'neutral');
                    ?>
                    <tr>
                        <td>
                            <?php if ($t['external_link']): ?>
                                <a class="plat-primary" target="_blank" rel="noopener"
                                   href="<?= plat_h($t['external_link']) ?>"><?= plat_h($t['ticket_number']) ?></a>
                            <?php else: ?>
                                <span class="plat-primary"><?= plat_h($t['ticket_number']) ?></span>
                            <?php endif; ?>
                            <span class="plat-sub"><?= plat_h($t['category'] ?: '—') ?></span>
                        </td>
                        <td>
                            <?= plat_h($t['title'] ?: mb_strimwidth((string) $t['description'], 0, 70, '…')) ?>
                            <?php if ($t['title'] && $t['description']): ?>
                                <span class="plat-sub"><?= plat_h(mb_strimwidth((string) $t['description'], 0, 70, '…')) ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= plat_h($t['ticket_date'] ?: '—') ?>
                            <?php if ($isOverdue): ?>
                                <span class="plat-sub"><span class="plat-pill crit">Due <?= plat_h($t['due_date']) ?></span></span>
                            <?php elseif ($t['due_date'] && !$isClosed): ?>
                                <span class="plat-sub">Due <?= plat_h($t['due_date']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><span class="plat-pill <?= $prioTone ?>"><?= plat_h($t['priority']) ?></span></td>
                        <td><span class="plat-pill <?= $statusTone ?>"><?= plat_h($t['status']) ?></span></td>
                        <td><?= plat_h($t['assignee_name'] ?: '—') ?><span class="plat-sub"><?= plat_h($t['requester']) ?></span></td>
                        <td>
                            <?= plat_h($t['ticket_system'] ?: '—') ?>
                            <?php if ($t['hostname']): ?><span class="plat-sub"><span class="plat-chip"><?= plat_h($t['hostname']) ?></span></span><?php endif; ?>
                        </td>
                        <td>
                            <div class="plat-row-actions">
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='tkOpen(<?= json_encode($t, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="tkDelete(<?= (int) $t['id'] ?>, '<?= plat_h(addslashes($t['ticket_number'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="plat-modal" id="tkModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="tkTitle">Add Ticket</h2>
            <button type="button" class="plat-close" onclick="platClose('tkModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Ticket number and date are the minimum; the rest is optional.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="tk_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Ticket Number *</label><input type="text" name="ticket_number" id="tk_ticket_number" required placeholder="INC0012345"></div>
                <div class="plat-field"><label>Date Raised</label><input type="date" name="ticket_date" id="tk_ticket_date" value="<?= date('Y-m-d') ?>"></div>
                <div class="plat-field"><label>System</label>
                    <select name="ticket_system" id="tk_ticket_system">
                        <option value="">—</option>
                        <?php foreach ($systems as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field full"><label>Title</label><input type="text" name="title" id="tk_title"></div>
                <div class="plat-field full"><label>Description</label><textarea name="description" id="tk_description" rows="3"></textarea></div>

                <div class="plat-field"><label>Status</label>
                    <select name="status" id="tk_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Priority</label>
                    <select name="priority" id="tk_priority">
                        <?php foreach ($priorities as $p): ?><option value="<?= plat_h($p) ?>" <?= $p === 'Medium' ? 'selected' : '' ?>><?= plat_h($p) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Category</label>
                    <select name="category" id="tk_category">
                        <option value="">—</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>"><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Due Date</label><input type="date" name="due_date" id="tk_due_date"></div>
                <div class="plat-field"><label>Closed Date</label><input type="date" name="closed_date" id="tk_closed_date"></div>
                <div class="plat-field"><label>Hostname</label><input list="platHostnames" name="hostname" id="tk_hostname"></div>

                <div class="plat-field"><label>Project</label><input type="text" name="project" id="tk_project"></div>
                <div class="plat-field"><label>Application</label><input type="text" name="application" id="tk_application"></div>
                <div class="plat-field"><label>Requester</label><input type="text" name="requester" id="tk_requester"></div>

                <div class="plat-field"><label>Assigned To</label>
                    <select name="assigned_to_id" id="tk_assigned_to_id">
                        <option value="">— Unassigned —</option>
                        <?php foreach ($assigneeOptions as $opt): ?>
                            <option value="<?= (int) $opt['id'] ?>"><?= plat_h(trim($opt['first_name'] . ' ' . $opt['last_name']) . ' (' . $opt['ncgr_id'] . ')') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field full"><label>External Link</label><input type="url" name="external_link" id="tk_external_link" placeholder="https://servicenow…"></div>

                <div class="plat-field full"><label>Resolution</label><textarea name="resolution" id="tk_resolution" rows="2"></textarea></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="tk_notes" rows="2"></textarea></div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('tkModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Ticket</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="tkDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete ticket</h2>
            <button type="button" class="plat-close" onclick="platClose('tkDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete ticket <strong id="tkDelName"></strong>?</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="tkDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('tkDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<script>
const TK_FIELDS = <?= json_encode(array_keys($tFields)) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function tkOpen(data) {
    const editing = !!data;
    document.getElementById('tkTitle').innerText = editing ? 'Edit Ticket' : 'Add Ticket';
    document.getElementById('tk_id').value = editing ? data.id : '';

    TK_FIELDS.forEach(f => {
        const el = document.getElementById('tk_' + f);
        if (!el) return;
        if (editing) {
            el.value = data[f] ?? '';
        } else if (f === 'ticket_date') {
            el.value = new Date().toISOString().slice(0, 10);
        } else if (f === 'priority') {
            el.value = 'Medium';
        } else if (f === 'status') {
            el.value = 'Open';
        } else {
            el.value = '';
        }
    });

    platOpen('tkModal');
}

function tkDelete(id, name) {
    document.getElementById('tkDelId').value = id;
    document.getElementById('tkDelName').innerText = name;
    platOpen('tkDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
