<?php
/*
| Shared helpers for the Decommission module (decommission.php,
| decommission-import.php). A decommission entry is a batch identified by
| a user-chosen unique_id/REQ, covering one or more hosts (decommission_hosts).
| Kept in one place so the "what counts as a default checklist" and
| "how do we snapshot a host from inventory" answers can't drift between
| the UI and the CSV importer.
*/

function decomDefaultTasks(): array
{
    return [
        ["name" => "CRQ Raised and Approved (it Must be CR).", "has_req" => false],
        ["name" => "System Owner approval attached.", "has_req" => false],
        ["name" => "Taken a full server backup as per the defined retention policy.", "has_req" => true],
        ["name" => "Removed NFS exports (if applicable) and inform Storage team to remove from ACL (tick if no NFS).", "has_req" => true],
        ["name" => "Raised ticket with the Splunk team to remove monitoring alerts.", "has_req" => true],
        ["name" => "Removed from the maintenance calendar for the decommission activity.", "has_req" => false],
        ["name" => "Deleted CMDB records", "has_req" => true],
        ["name" => "Informed SecOps team to remove the rules.", "has_req" => true],
        ["name" => "Security tools removed such as SEP, XDR.", "has_req" => true],
        ["name" => "Powered off the server.", "has_req" => false],
        ["name" => "Rename the server by appending '_tbd' in the Vcenter", "has_req" => false],
        ["name" => "server powered off for 1–2 weeks to identify any dependency or accessibility issues.", "has_req" => false],
        ["name" => "Released the Production and Management IP addresses and remove the DNS entries.", "has_req" => false],
        ["name" => "Removed the iLO and Virtual Connect (VC) configuration.", "has_req" => false],
        ["name" => "Removed the server from IPA.", "has_req" => false],
        ["name" => "Removed the server from Satellite", "has_req" => false],
        ["name" => "Deleted the server.", "has_req" => true],
        ["name" => "Updated all relevant tracking documents (Patch Calendar, Decommission Tracker, Inventory, etc.).", "has_req" => false],
        ["name" => "Closed the Change Request (CR).", "has_req" => false],
        ["name" => "Updated the server status in the Ramp-Down/Decommission list.", "has_req" => false],
    ];
}

function decomCreateDefaultTasks(PDO $pdo, int $decommission_id): void
{
    $t_stmt = $pdo->prepare("INSERT INTO decommission_tasks (decommission_id, task_name, status, req_no) VALUES (?, ?, 'Pending', '')");
    foreach (decomDefaultTasks() as $t) {
        $t_stmt->execute([$decommission_id, $t['name']]);
    }
}

// Snapshots the fields a decommission host row cares about from inventory
// at the moment a host is attached to an entry. Returns null if the
// hostname isn't in inventory at all.
function decomInventorySnapshot(PDO $pdo, string $hostname): ?array
{
    $stmt = $pdo->prepare("SELECT project, support_level, application, ip_address, additional_ips, technical_owner FROM inventory WHERE hostname = ? LIMIT 1");
    $stmt->execute([$hostname]);
    $inv = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$inv) {
        return null;
    }
    return [
        'project'          => $inv['project'] ?? '',
        'support_level'    => $inv['support_level'] ?? '',
        'application_name' => $inv['application'] ?? '',
        'ip_address'       => $inv['ip_address'] ?? '',
        'additional_ips'   => $inv['additional_ips'] ?? '',
        'technical_owner'  => $inv['technical_owner'] ?? '',
    ];
}

function decomAttachHost(PDO $pdo, int $decommission_id, string $hostname): void
{
    $snap = decomInventorySnapshot($pdo, $hostname) ?? [
        'project' => '', 'support_level' => '', 'application_name' => '',
        'ip_address' => '', 'additional_ips' => '', 'technical_owner' => '',
    ];

    $ins = $pdo->prepare("
        INSERT INTO decommission_hosts
        (decommission_id, hostname, project, support_level, application_name, ip_address, additional_ips, technical_owner)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    ");
    $ins->execute([
        $decommission_id, $hostname, $snap['project'], $snap['support_level'],
        $snap['application_name'], $snap['ip_address'], $snap['additional_ips'], $snap['technical_owner'],
    ]);
}

// Resolves a CSV/free-text assignee reference (NCGR ID or email) to a
// users.id. Returns null on no match rather than guessing.
function decomResolveAssigneeId(PDO $pdo, string $identifier): ?int
{
    $identifier = trim($identifier);
    if ($identifier === '') {
        return null;
    }
    $stmt = $pdo->prepare("SELECT id FROM users WHERE LOWER(ncgr_id) = LOWER(?) OR LOWER(email) = LOWER(?) LIMIT 1");
    $stmt->execute([$identifier, $identifier]);
    $id = $stmt->fetchColumn();
    return $id ? (int) $id : null;
}

// Resolves an assignee's permanent display label ("First Last (NCGR)") at
// the moment they're assigned. This gets stored in decommission.assignee_name
// so the label survives that portal user later being reassigned elsewhere or
// deleted entirely -- display code must read the stored column, never
// re-resolve it live from `users`.
function decomResolveAssigneeName(PDO $pdo, ?int $assignee_id): ?string
{
    if (!$assignee_id) {
        return null;
    }
    $stmt = $pdo->prepare("SELECT first_name, last_name, ncgr_id FROM users WHERE id = ?");
    $stmt->execute([$assignee_id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$u) {
        return null;
    }
    $name = trim(trim((string) $u['first_name']) . ' ' . trim((string) $u['last_name']));
    $ncgr = trim((string) ($u['ncgr_id'] ?? ''));
    return $ncgr !== '' ? "$name ($ncgr)" : $name;
}

function decomAssigneeLabel(?string $assigneeName): string
{
    $assigneeName = trim((string) $assigneeName);
    return $assigneeName !== '' ? $assigneeName : 'Unassigned';
}

// Maps a free-text server state to a CSS badge modifier class.
function decom_state_class($state)
{
    $state = strtolower(trim($state ?? ''));
    if (strpos($state, 'decommission') !== false) return 'state-decommissioned';
    if (strpos($state, 'to be') !== false) return 'state-pending';
    if (strpos($state, 'off') !== false) return 'state-off';
    if (strpos($state, 'on') !== false) return 'state-on';
    return '';
}

function decom_support_class($level)
{
    $level = strtolower(trim($level ?? ''));
    if ($level === 'production') return 'support-prod';
    if (in_array($level, ['pre-prod', 'preprod', 'dr'])) return 'support-preprod';
    if (in_array($level, ['sit', 'test', 'poc'])) return 'support-test';
    if (in_array($level, ['development', 'sandbox'])) return 'support-dev';
    return 'support-other';
}
