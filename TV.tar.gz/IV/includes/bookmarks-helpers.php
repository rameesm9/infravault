<?php

require_once __DIR__ . '/bookmarkable-pages.php';

/**
 * A user's bookmarked page_keys, most recently bookmarked first.
 */
function bookmarks_get_user(PDO $pdo, int $userId): array
{
    if ($userId <= 0) {
        return [];
    }

    $stmt = $pdo->prepare("
        SELECT page_key
        FROM user_bookmarks
        WHERE user_id = ?
        ORDER BY created_at DESC, id DESC
    ");
    $stmt->execute([$userId]);

    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

/**
 * Filters a list of page_keys down to the ones the given role may
 * actually view -- the same rule sidebar.php's canViewPage() applies.
 *
 * Delegates to authz.php's authzCan(), rather than re-querying the
 * permissions table directly: an earlier version here ran its own
 * `WHERE role = ?` lookup, which was exact-match and single-role, so a
 * page granted only through a second role_names row (user_roles) --
 * visible in the sidebar -- silently never appeared in the bookmark
 * list. authzCan() is the one place that combines every role a user
 * holds and trims/case-folds the match; reuse it instead of drifting
 * out of sync with it again.
 *
 * 'home' has no permissions row (the Dashboard link in sidebar.php isn't
 * gated either) and is always considered visible.
 */
function bookmarks_filter_visible(PDO $pdo, string $role, array $pageKeys): array
{
    $pageKeys = array_values(array_unique(array_filter(
        $pageKeys,
        fn($k) => $k !== null && $k !== ''
    )));

    $visible = array_values(array_intersect($pageKeys, ['home']));

    $gated = array_values(array_diff($pageKeys, ['home']));

    if ($gated === [] || $role === '') {
        return $visible;
    }

    foreach ($gated as $pageKey) {
        if (authzCan($pdo, $role, $pageKey, 'can_view')) {
            $visible[] = $pageKey;
        }
    }

    return $visible;
}

/**
 * Adds or removes one bookmark. Returns the new state (true = now
 * bookmarked, false = now removed).
 */
function bookmarks_toggle(PDO $pdo, int $userId, string $pageKey): bool
{
    $existing = $pdo->prepare("
        SELECT id FROM user_bookmarks WHERE user_id = ? AND page_key = ?
    ");
    $existing->execute([$userId, $pageKey]);

    if ($existing->fetchColumn()) {
        $pdo->prepare("
            DELETE FROM user_bookmarks WHERE user_id = ? AND page_key = ?
        ")->execute([$userId, $pageKey]);

        return false;
    }

    $pdo->prepare("
        INSERT INTO user_bookmarks (user_id, page_key) VALUES (?, ?)
    ")->execute([$userId, $pageKey]);

    return true;
}
