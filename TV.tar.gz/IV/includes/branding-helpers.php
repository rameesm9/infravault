<?php
/**
 * Centralized application branding (name + logo).
 *
 * Every page that renders the standard chrome (header/sidebar/footer) or an
 * auth screen (login/signup/reset) should read the name/logo through here
 * rather than hardcoding "InfraVault" or the default logo path, so changing
 * either in Settings takes effect everywhere at once.
 */

const BRANDING_DEFAULT_APP_NAME = 'InfraVault';
const BRANDING_DEFAULT_LOGO_URL = 'assets/images/infravault-logo.svg';
const BRANDING_UPLOAD_DIR_FS = __DIR__ . '/../uploads/branding';
const BRANDING_UPLOAD_URL_PREFIX = 'uploads/branding/';
const BRANDING_ALLOWED_LOGO_EXTS = ['svg', 'png', 'jpg', 'jpeg', 'webp'];
const BRANDING_MAX_LOGO_BYTES = 2 * 1024 * 1024; // 2MB

/**
 * Load the stored branding row, falling back to safe defaults if the
 * schema hasn't migrated yet for some reason.
 */
function getBrandingRow(PDO $pdo): array
{
    $row = $pdo->query("SELECT * FROM branding_settings WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        $row = [
            'app_name' => BRANDING_DEFAULT_APP_NAME,
            'logo_path' => '',
            'updated_by' => null,
            'updated_at' => null,
        ];
    }

    return $row;
}

/**
 * The application's display name, used for the header/sidebar brand, page
 * titles, auth screens and the AI assistant widget.
 */
function getAppName(PDO $pdo): string
{
    $name = trim((string) (getBrandingRow($pdo)['app_name'] ?? ''));
    return $name !== '' ? $name : BRANDING_DEFAULT_APP_NAME;
}

/**
 * URL (relative to the web root) of the logo to display -- the uploaded
 * one if set, otherwise the app's built-in SVG mark.
 */
function getAppLogoUrl(PDO $pdo): string
{
    $path = trim((string) (getBrandingRow($pdo)['logo_path'] ?? ''));
    return $path !== '' ? $path : BRANDING_DEFAULT_LOGO_URL;
}

/**
 * Validates and stores an uploaded logo file from $_FILES['logo'].
 *
 * Returns the new relative path (e.g. "uploads/branding/xxxx.png") on
 * success, or null if no file was submitted. Throws a RuntimeException
 * with a user-facing message on validation failure.
 */
function brandingSaveLogoUpload(array $file): ?string
{
    if (empty($file['name']) || ($file['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        throw new RuntimeException('Logo upload failed (error code ' . (int) $file['error'] . ').');
    }

    if ((int) $file['size'] > BRANDING_MAX_LOGO_BYTES) {
        throw new RuntimeException('Logo file is too large -- maximum size is 2MB.');
    }

    $orig = basename((string) $file['name']);
    $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));

    if (!in_array($ext, BRANDING_ALLOWED_LOGO_EXTS, true)) {
        throw new RuntimeException('Unsupported logo file type -- use SVG, PNG, JPG or WEBP.');
    }

    if (!is_dir(BRANDING_UPLOAD_DIR_FS)) {
        mkdir(BRANDING_UPLOAD_DIR_FS, 0755, true);
    }

    $stored = bin2hex(random_bytes(12)) . '.' . $ext;
    $destination = BRANDING_UPLOAD_DIR_FS . '/' . $stored;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        throw new RuntimeException('Could not save the uploaded logo file.');
    }

    return BRANDING_UPLOAD_URL_PREFIX . $stored;
}

/**
 * Removes a previously uploaded logo file from disk, if it's one of ours
 * (never touches the built-in default asset).
 */
function brandingDeleteUploadedLogo(?string $path): void
{
    if (!$path || strpos($path, BRANDING_UPLOAD_URL_PREFIX) !== 0) {
        return;
    }

    $fsPath = __DIR__ . '/../' . $path;

    if (is_file($fsPath)) {
        @unlink($fsPath);
    }
}
