<?php

/*
|--------------------------------------------------------------------------
| Shared notification feed
|--------------------------------------------------------------------------
|
| Pulls together the things a user actually needs to see in one place:
| open team communications/handover tasks (communications table), their
| visible reminders, and their visible sticky notes -- same visibility
| rule used by reminders.php / sticky notes: public, their own user_id,
| admin sees everything, or shared via the reminder_teams/reminder_users
| and sticky_note_teams/sticky_note_users join tables (team or specific
| users).
|
| Used by both includes/header.php (notification bell) and home.php
| (dashboard notifications panel) so the two stay in sync.
|
*/

require_once __DIR__ . '/permission-helpers.php';

/*
|--------------------------------------------------------------------------
| Plain-PHP text truncation (no mbstring dependency -- this app runs
| fully offline on a minimal PHP setup that may not have it enabled)
|--------------------------------------------------------------------------
*/

if (!function_exists('infravault_truncate')) {
function infravault_truncate(string $text, int $length = 60): string
{
    $text = trim($text);

    if (strlen($text) <= $length) {
        return $text;
    }

    return rtrim(substr($text, 0, $length)) . '...';
}
}


function infravault_get_notifications(
    PDO $pdo,
    int $user_id,
    string $role,
    string $team = ''
): array {

    $role_lower = strtolower(trim($role));


    /*
    |----------------------------------------------------------------
    | Per-user read state -- which "comm_<id>" / "reminder_<id>" item
    | keys this user has already opened, via the bell dropdown's
    | notification_read.php. Only affects this user's own unread badge;
    | the underlying communications/reminders rows are untouched.
    |----------------------------------------------------------------
    */

    $read_keys = [];

    try {
        $stmt = $pdo->prepare("SELECT item_key FROM notification_reads WHERE user_id = ?");
        $stmt->execute([$user_id]);
        $read_keys = array_flip($stmt->fetchAll(PDO::FETCH_COLUMN));
    } catch (Throwable $e) {
        $read_keys = [];
    }


    /*
    |----------------------------------------------------------------
    | Team Communications / Handover Tasks (still open)
    |----------------------------------------------------------------
    */

    $communications = [];

    try {

        $stmt = $pdo->query("
            SELECT
                c.id,
                c.title,
                c.note_type,
                c.priority,
                c.status,
                c.created_at,
                u.first_name AS creator_first,
                u.last_name AS creator_last
            FROM communications c
            LEFT JOIN users u
                ON u.id = c.created_by
            WHERE c.status != 'Completed'
            ORDER BY c.created_at DESC
            LIMIT 6
        ");

        $communications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $communications = [];
    }

    $unread_communications_count = 0;

    foreach ($communications as &$c_row) {
        $c_row['item_key'] = 'comm_' . $c_row['id'];
        $c_row['read'] = isset($read_keys[$c_row['item_key']]);
        if (!$c_row['read']) {
            $unread_communications_count++;
        }
    }
    unset($c_row);


    /*
    |----------------------------------------------------------------
    | Communications assigned specifically to this user (Handover
    | Tasks -- the only note_type that sets assigned_to). Pulled as
    | its own query, not sliced from $communications above, so a busy
    | team-notes feed can never push a personal assignment out of view.
    |----------------------------------------------------------------
    */

    $assigned_to_me = [];

    try {

        $stmt = $pdo->prepare("
            SELECT
                c.id,
                c.title,
                c.note_type,
                c.priority,
                c.status,
                c.target_date,
                c.created_at,
                u.first_name AS creator_first,
                u.last_name AS creator_last
            FROM communications c
            LEFT JOIN users u
                ON u.id = c.created_by
            WHERE c.assigned_to = ?
              AND c.status != 'Completed'
            ORDER BY
                CASE WHEN c.target_date IS NOT NULL AND TRIM(c.target_date) != ''
                     THEN c.target_date ELSE c.created_at END ASC
            LIMIT 8
        ");

        $stmt->execute([$user_id]);

        $assigned_to_me = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $assigned_to_me = [];
    }


    /*
    |----------------------------------------------------------------
    | Reminders visible to this user
    |----------------------------------------------------------------
    */

    $reminders = [];
    $overdue_count = 0;
    $overdue_unread_count = 0;

    try {

        $stmt = $pdo->prepare("
            SELECT
                r.id,
                r.title,
                r.reminder_date,
                r.visibility
            FROM reminders r
            WHERE
                r.visibility = 'public'
                OR r.user_id = ?
                OR ? = 'admin'
                OR (r.visibility = 'team' AND EXISTS (
                    SELECT 1 FROM reminder_teams rt
                    WHERE rt.reminder_id = r.id AND rt.team_name = ?
                ))
                OR (r.visibility = 'user' AND EXISTS (
                    SELECT 1 FROM reminder_users ru
                    WHERE ru.reminder_id = r.id AND ru.user_id = ?
                ))
            ORDER BY r.reminder_date ASC
            LIMIT 6
        ");

        $stmt->execute([
            $user_id,
            $role_lower,
            $team,
            $user_id
        ]);

        $reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $now = date('Y-m-d H:i:s');

        foreach ($reminders as &$r) {

            $r['item_key'] = 'reminder_' . $r['id'];
            $r['read'] = isset($read_keys[$r['item_key']]);

            $is_overdue = !empty($r['reminder_date']) && $r['reminder_date'] < $now;

            if ($is_overdue) {
                $overdue_count++;
                if (!$r['read']) {
                    $overdue_unread_count++;
                }
            }
        }
        unset($r);

    } catch (Throwable $e) {
        $reminders = [];
    }


    /*
    |----------------------------------------------------------------
    | Sticky notes visible to this user
    |----------------------------------------------------------------
    */

    $sticky_notes = [];

    try {

        $stmt = $pdo->prepare("
            SELECT
                n.id,
                n.content,
                n.visibility,
                n.updated_at,
                u.first_name,
                u.last_name
            FROM sticky_notes n
            LEFT JOIN users u
                ON u.id = n.user_id
            WHERE
                n.visibility = 'public'
                OR n.user_id = ?
                OR ? = 'admin'
                OR (n.visibility = 'team' AND EXISTS (
                    SELECT 1 FROM sticky_note_teams st
                    WHERE st.sticky_note_id = n.id AND st.team_name = ?
                ))
                OR (n.visibility = 'user' AND EXISTS (
                    SELECT 1 FROM sticky_note_users su
                    WHERE su.sticky_note_id = n.id AND su.user_id = ?
                ))
            ORDER BY n.updated_at DESC
            LIMIT 5
        ");

        $stmt->execute([
            $user_id,
            $role_lower,
            $team,
            $user_id
        ]);

        $sticky_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $sticky_notes = [];
    }


    /*
    |----------------------------------------------------------------
    | My Data shared with this user -- mydata.php's own visibility
    | model (Private/Public/Team/Person, via the team_name/shared_user_id
    | columns directly -- see can_view_data() in mydata.php). Only
    | records shared *with* this user surface here (Public, their team,
    | or named to them directly); records they own themselves are
    | excluded since sharing something is not news to the person who
    | just shared it.
    |----------------------------------------------------------------
    */

    $shared_data = [];

    try {

        $stmt = $pdo->prepare("
            SELECT
                d.id,
                d.title,
                d.visibility,
                d.team_name,
                d.updated_at,
                d.owner_id,
                owner.first_name AS owner_first,
                owner.last_name AS owner_last
            FROM my_data d
            LEFT JOIN users owner
                ON owner.id = d.owner_id
            WHERE
                d.owner_id != ?
                AND (
                    ? = 'admin'
                    OR d.visibility = 'Public'
                    OR (d.visibility = 'Team' AND d.team_name = ?)
                    OR (d.visibility = 'Person' AND d.shared_user_id = ?)
                )
            ORDER BY d.updated_at DESC
            LIMIT 6
        ");

        $stmt->execute([
            $user_id,
            $role_lower,
            $team,
            $user_id
        ]);

        $shared_data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($shared_data as &$d_row) {
            $d_row['item_key'] = 'mydata_' . $d_row['id'];
            $d_row['read'] = isset($read_keys[$d_row['item_key']]);
        }
        unset($d_row);

    } catch (Throwable $e) {
        $shared_data = [];
    }

    $unread_shared_data_count = 0;
    foreach ($shared_data as $d_row) {
        if (!$d_row['read']) {
            $unread_shared_data_count++;
        }
    }


    /*
    |----------------------------------------------------------------
    | Knowledge Base & SOP activity -- comments, edits, and review
    | decisions (approve/reject, with the reviewer's note). Pulled from
    | each module's own audit trail (knowledge_base_audit / sop_audit --
    | see logItemAction() in includes/permission-helpers.php) rather
    | than a separate feed, so this can never drift from what each
    | module's own "History" view shows.
    |
    | Filtered through the same getItemAccessLevel() visibility engine
    | knowledge.php / sop.php use for viewing (public / team / teams /
    | private, or the author) -- an event only reaches users who could
    | already open the article/SOP it happened on. The action's own
    | performer is excluded: you don't need to be told about your own
    | edit or your own review decision.
    |----------------------------------------------------------------
    */

    $kb_sop_activity = [];

    try {

        $activity_actions = ['EDITED', 'COMMENT_ADDED', 'PUBLISHED', 'REJECTED'];
        $placeholders = implode(',', array_fill(0, count($activity_actions), '?'));

        $stmt = $pdo->prepare("
            SELECT
                a.id AS audit_id,
                a.action,
                a.performed_by_id,
                a.user_name,
                a.action_date,
                a.details,
                k.id AS kb_id,
                k.title AS kb_title,
                k.visibility AS kb_visibility,
                k.owner_team AS kb_owner_team,
                k.created_by AS kb_created_by
            FROM knowledge_base_audit a
            JOIN knowledge_base k ON k.id = a.kb_id
            WHERE a.performed_by_id != ?
              AND a.action IN ($placeholders)
            ORDER BY a.action_date DESC
            LIMIT 20
        ");
        $stmt->execute(array_merge([$user_id], $activity_actions));
        $kb_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($kb_rows as $row) {

            $shared_teams = ($row['kb_visibility'] ?? '') === 'teams'
                ? getSharedTeams($pdo, 'knowledge_base', (int) $row['kb_id'])
                : [];

            $access = getItemAccessLevel(
                $pdo, $user_id, $role, $team,
                (int) $row['kb_created_by'], $row['kb_visibility'] ?? 'public', $row['kb_owner_team'] ?? '',
                $shared_teams, 'knowledge_base'
            );

            if ($access === 'none') {
                continue;
            }

            $kb_sop_activity[] = [
                'item_key'   => 'kbaudit_' . $row['audit_id'],
                'module'     => 'knowledge_base',
                'action'     => $row['action'],
                'title'      => $row['kb_title'],
                'actor_name' => $row['user_name'],
                'date'       => $row['action_date'],
                'href'       => 'knowledge.php?action=view&id=' . (int) $row['kb_id'],
                'read'       => isset($read_keys['kbaudit_' . $row['audit_id']]),
            ];
        }

        $stmt = $pdo->prepare("
            SELECT
                a.id AS audit_id,
                a.action,
                a.performed_by_id,
                a.user_name,
                a.action_date,
                a.details,
                s.id AS sop_id,
                s.title AS sop_title,
                s.visibility AS sop_visibility,
                s.owner_team AS sop_owner_team,
                s.owner_id AS sop_owner_id
            FROM sop_audit a
            JOIN sops s ON s.id = a.sop_id
            WHERE a.performed_by_id != ?
              AND a.action IN ($placeholders)
            ORDER BY a.action_date DESC
            LIMIT 20
        ");
        $stmt->execute(array_merge([$user_id], $activity_actions));
        $sop_rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($sop_rows as $row) {

            $shared_teams = ($row['sop_visibility'] ?? '') === 'teams'
                ? getSharedTeams($pdo, 'sop', (int) $row['sop_id'])
                : [];

            $access = getItemAccessLevel(
                $pdo, $user_id, $role, $team,
                (int) $row['sop_owner_id'], $row['sop_visibility'] ?? 'public', $row['sop_owner_team'] ?? '',
                $shared_teams, 'sop'
            );

            if ($access === 'none') {
                continue;
            }

            $kb_sop_activity[] = [
                'item_key'   => 'sopaudit_' . $row['audit_id'],
                'module'     => 'sop',
                'action'     => $row['action'],
                'title'      => $row['sop_title'],
                'actor_name' => $row['user_name'],
                'date'       => $row['action_date'],
                'href'       => 'sop.php?action=view&id=' . (int) $row['sop_id'],
                'read'       => isset($read_keys['sopaudit_' . $row['audit_id']]),
            ];
        }

        usort($kb_sop_activity, function ($a, $b) {
            return strcmp($b['date'], $a['date']);
        });

        $kb_sop_activity = array_slice($kb_sop_activity, 0, 6);

    } catch (Throwable $e) {
        $kb_sop_activity = [];
    }

    $unread_kb_sop_count = 0;
    foreach ($kb_sop_activity as $a_row) {
        if (!$a_row['read']) {
            $unread_kb_sop_count++;
        }
    }


    /*
    |----------------------------------------------------------------
    | Assigned-work counts -- decommission, patching, SOP review, GRC.
    | Counts only, not item lists: a busy patching quarter can run to
    | hundreds of hostnames, and the bell/dashboard summary is meant
    | to say "how many", not enumerate every one (that's what each
    | module's own page is for). Each is gated on that module's own
    | can_view permission so a role without access never sees its
    | numbers leak into the shared feed. The patching/GRC tables are
    | created lazily by their own pages (not the global schema
    | bootstrap), so a fresh install that has never opened them throws
    | here -- caught, count just stays 0 rather than breaking the feed.
    |----------------------------------------------------------------
    */

    $my_decommission_count = 0;

    try {
        if (authzCan($pdo, $role, 'decommission', 'can_view')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM decommission
                WHERE assignee_id = ?
                  AND LOWER(TRIM(COALESCE(server_state, ''))) != 'decommissioned'
            ");
            $stmt->execute([$user_id]);
            $my_decommission_count = (int) $stmt->fetchColumn();
        }
    } catch (Throwable $e) {
        $my_decommission_count = 0;
    }

    $my_patching_count = 0;

    try {
        if (authzCan($pdo, $role, 'patching', 'can_view')) {

            // Scoped to the current quarter, same as home.php's "My Assigned
            // Work" card -- an incomplete host from a past quarter is that
            // quarter's own overdue problem, not something to keep counting
            // here indefinitely.
            $patch_this_year = (int) date('Y');
            $patch_this_quarter = (int) ceil(((int) date('n')) / 3);

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM patch_schedule_servers pss
                JOIN patch_schedules ps ON ps.id = pss.schedule_id
                WHERE pss.assigned_to = ?
                  AND pss.selected = 1
                  AND ps.year = ?
                  AND ps.quarter = ?
                  AND COALESCE(pss.status, '') NOT IN ('Completed', 'Decommissioned', 'N/A', 'Excluded')
            ");
            $stmt->execute([$user_id, $patch_this_year, $patch_this_quarter]);
            $my_patching_count = (int) $stmt->fetchColumn();
        }
    } catch (Throwable $e) {
        $my_patching_count = 0;
    }

    $my_sop_review_count = 0;

    try {
        if (authzCan($pdo, $role, 'sop', 'can_view')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM sops
                WHERE reviewer_id = ? AND status = 'Pending Review'
            ");
            $stmt->execute([$user_id]);
            $my_sop_review_count = (int) $stmt->fetchColumn();
        }
    } catch (Throwable $e) {
        $my_sop_review_count = 0;
    }

    $my_grc_count = 0;

    try {
        if (authzCan($pdo, $role, 'grc_schedule', 'can_view')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM grc_schedules
                WHERE assignee_id = ?
                  AND status NOT IN ('Patched', 'Cancelled', 'Skipped')
            ");
            $stmt->execute([$user_id]);
            $my_grc_count = (int) $stmt->fetchColumn();
        }
    } catch (Throwable $e) {
        $my_grc_count = 0;
    }

    $my_ticket_count = 0;

    try {
        if (authzCan($pdo, $role, 'ticket', 'can_view')) {
            $stmt = $pdo->prepare("
                SELECT COUNT(*) FROM tickets
                WHERE assigned_to_id = ?
                  AND status NOT IN ('Resolved', 'Closed', 'Cancelled')
            ");
            $stmt->execute([$user_id]);
            $my_ticket_count = (int) $stmt->fetchColumn();
        }
    } catch (Throwable $e) {
        $my_ticket_count = 0;
    }


    /*
    |----------------------------------------------------------------
    | On-call -- the shift covering right now (if any), else the next
    | upcoming one this user is on. Membership is by primary/secondary
    | user id, so a user always sees their own shift regardless of
    | that shift's visibility scope (private/team/teams/public).
    |----------------------------------------------------------------
    */

    $oncall_current = null;
    $oncall_next = null;

    try {

        if (authzCan($pdo, $role, 'oncall', 'can_view')) {

            $now = date('Y-m-d H:i:s');

            $stmt = $pdo->prepare("
                SELECT s.*,
                       CASE WHEN s.primary_user_id = ? THEN 'Primary' ELSE 'Secondary' END AS my_role
                FROM oncall_shifts s
                WHERE (s.primary_user_id = ? OR s.secondary_user_id = ?)
                  AND s.ends_at >= ?
                ORDER BY s.starts_at ASC
            ");

            $stmt->execute([$user_id, $user_id, $user_id, $now]);

            $my_shifts = $stmt->fetchAll(PDO::FETCH_ASSOC);

            foreach ($my_shifts as $s) {
                if ((string) $s['starts_at'] <= $now && (string) $s['ends_at'] >= $now) {
                    $oncall_current = $s;
                    break;
                }
            }

            if (!$oncall_current && $my_shifts) {
                $oncall_next = $my_shifts[0];
            }
        }

    } catch (Throwable $e) {
        $oncall_current = null;
        $oncall_next = null;
    }


    /*
    |----------------------------------------------------------------
    | Bucket-level read state for the assigned-work counts and on-call.
    | These aren't itemized (see comment above), so each bucket is
    | treated as a single dismissible notification keyed on its current
    | count (or shift id for on-call): reading it clears that bucket
    | from the badge, but if the count later changes -- e.g. a new host
    | gets assigned -- the key changes too and it's unread again.
    |----------------------------------------------------------------
    */

    $decomm_item_key = 'decomm_' . $my_decommission_count;
    $decomm_read = $my_decommission_count > 0 && isset($read_keys[$decomm_item_key]);

    $patch_item_key = 'patch_' . $my_patching_count;
    $patch_read = $my_patching_count > 0 && isset($read_keys[$patch_item_key]);

    $sop_item_key = 'sop_' . $my_sop_review_count;
    $sop_read = $my_sop_review_count > 0 && isset($read_keys[$sop_item_key]);

    $grc_item_key = 'grc_' . $my_grc_count;
    $grc_read = $my_grc_count > 0 && isset($read_keys[$grc_item_key]);

    $ticket_item_key = 'ticket_' . $my_ticket_count;
    $ticket_read = $my_ticket_count > 0 && isset($read_keys[$ticket_item_key]);

    $oncall_item_key = $oncall_current ? ('oncall_' . $oncall_current['id']) : null;
    $oncall_read = $oncall_item_key && isset($read_keys[$oncall_item_key]);

    return [
        'communications'        => $communications,
        'assigned_to_me'        => $assigned_to_me,
        'reminders'             => $reminders,
        'sticky_notes'          => $sticky_notes,
        'shared_data'           => $shared_data,
        'kb_sop_activity'       => $kb_sop_activity,
        'my_decommission_count' => $my_decommission_count,
        'my_patching_count'     => $my_patching_count,
        'my_sop_review_count'   => $my_sop_review_count,
        'my_grc_count'          => $my_grc_count,
        'my_ticket_count'       => $my_ticket_count,
        'oncall_current'        => $oncall_current,
        'oncall_next'           => $oncall_next,
        'decomm_item_key'       => $decomm_item_key,
        'decomm_read'           => $decomm_read,
        'patch_item_key'        => $patch_item_key,
        'patch_read'            => $patch_read,
        'sop_item_key'          => $sop_item_key,
        'sop_read'              => $sop_read,
        'grc_item_key'          => $grc_item_key,
        'grc_read'              => $grc_read,
        'ticket_item_key'       => $ticket_item_key,
        'ticket_read'           => $ticket_read,
        'oncall_item_key'       => $oncall_item_key,
        'oncall_read'           => $oncall_read,
        'badge_count'           => $unread_communications_count + $overdue_unread_count
            + $unread_shared_data_count
            + $unread_kb_sop_count
            + ($my_decommission_count && !$decomm_read ? 1 : 0)
            + ($my_patching_count && !$patch_read ? 1 : 0)
            + ($my_sop_review_count && !$sop_read ? 1 : 0)
            + ($my_grc_count && !$grc_read ? 1 : 0)
            + ($my_ticket_count && !$ticket_read ? 1 : 0)
            + ($oncall_current && !$oncall_read ? 1 : 0),
    ];
}
