<?php

/**
 * The flat list of pages a user can bookmark from the header star
 * dropdown. Deliberately kept as its own static list rather than derived
 * from includes/sidebar.php: the sidebar mixes real links with '#'
 * placeholders (Critical Exploitable, Splunk, BMC CMDB, Grafana) that
 * don't go anywhere yet, and sidebar.php's structure is markup, not data
 * -- there's nothing to iterate there without re-parsing HTML.
 *
 * 'group' is only used to organise the "Add Bookmark" list in the
 * dropdown and mirrors the sidebar's menu-group names.
 *
 * Whether a page actually shows up for a given user is decided at
 * render/toggle time by bookmarks_filter_visible() against the
 * permissions table, using the same page_key as canViewPage() in
 * sidebar.php -- this list is not itself permission-checked.
 */
function bookmarks_registry(): array
{
    return [
        ['key' => 'home',                'label' => 'Dashboard',                'href' => 'home.php',                  'group' => 'Dashboard'],

        ['key' => 'asset',               'label' => 'Asset Management',         'href' => 'asset.php',                 'group' => 'Inventory'],
        ['key' => 'inventory',           'label' => 'Server Inventory',         'href' => 'inventory.php',             'group' => 'Inventory'],
        ['key' => 'license_warranty',    'label' => 'License and EOL Tracking', 'href' => 'license_warranty.php',      'group' => 'Inventory'],
        ['key' => 'ip',                  'label' => 'IP Address Management',    'href' => 'ip.php',                    'group' => 'Inventory'],
        ['key' => 'ownership',           'label' => 'Asset Ownership',          'href' => 'ownership.php',             'group' => 'Inventory'],
        ['key' => 'uid_gid',             'label' => 'UID/GID Tracking',         'href' => 'uid-gid-tracking.php',      'group' => 'Inventory'],
        ['key' => 'handover',            'label' => 'Asset Handover',           'href' => 'handover.php',              'group' => 'Inventory'],
        ['key' => 'decommission',        'label' => 'Asset Decommission',       'href' => 'decommission.php',          'group' => 'Inventory'],
        ['key' => 'builds',              'label' => 'New Build',                'href' => 'builds.php',                'group' => 'Inventory'],
        ['key' => 'container_platform',  'label' => 'Container Platform',       'href' => 'container_platform.php',    'group' => 'Inventory'],
        ['key' => 'oracle_db',           'label' => 'Oracle Databases',         'href' => 'oracle_db.php',             'group' => 'Inventory'],
        ['key' => 'dr_mapping',          'label' => 'Production / DR Mapping',  'href' => 'dr_mapping.php',            'group' => 'Inventory'],
        ['key' => 'major_layouts',       'label' => 'Application Layout',       'href' => 'app_layout.php',            'group' => 'Inventory'],
        ['key' => 'project_overview',    'label' => 'Project Overview',         'href' => 'project_overview.php',      'group' => 'Inventory'],

        ['key' => 'patching',            'label' => 'Quarterly Patching',       'href' => 'patching.php',              'group' => 'Vulnerability & Controls'],
        ['key' => 'grc_schedule',        'label' => 'GRC Schedule',             'href' => 'grc_schedule.php',          'group' => 'Vulnerability & Controls'],
        ['key' => 'vulnerabilities',     'label' => 'DMZ Assessment',           'href' => 'vulnerabilities.php',       'group' => 'Vulnerability & Controls'],
        ['key' => 'va_assessment',       'label' => 'VA Assessment',            'href' => 'va_assessment.php',         'group' => 'Vulnerability & Controls'],
        ['key' => 'compliance',          'label' => 'Compliance',               'href' => 'compliance.php',            'group' => 'Vulnerability & Controls'],
        ['key' => 'patch',               'label' => 'Exception Register',       'href' => 'patch.php',                 'group' => 'Vulnerability & Controls'],

        ['key' => 'sop',                 'label' => 'SOP',                      'href' => 'sop-summary.php',           'group' => 'Runbook'],
        ['key' => 'knowledge',           'label' => 'Knowledge Base',           'href' => 'knowledge-summary.php',     'group' => 'Runbook'],
        ['key' => 'known_issues',        'label' => 'Known Issues',             'href' => 'known-issues-summary.php',  'group' => 'Runbook'],

        ['key' => 'oncall',              'label' => 'On-Call Tracker',          'href' => 'oncall.php',                'group' => 'Team Workspace'],
        ['key' => 'leave',               'label' => 'Leave Tracker',            'href' => 'leave.php',                 'group' => 'Team Workspace'],
        ['key' => 'special_projects',    'label' => 'Special Projects',         'href' => 'special_projects.php',      'group' => 'Team Workspace'],
        ['key' => 'ticket',              'label' => 'Ticket Tracking',          'href' => 'tickets.php',               'group' => 'Team Workspace'],
        ['key' => 'links',               'label' => 'Quick Links',              'href' => 'links.php',                 'group' => 'Team Workspace'],
        ['key' => 'mydata',              'label' => 'My Data',                  'href' => 'mydata.php',                'group' => 'Team Workspace'],

        ['key' => 'vault',                'label' => 'Password Vault',           'href' => 'vault.php',                 'group' => 'Utilities'],
        ['key' => 'diagram_designer',     'label' => 'Draw Designs',             'href' => 'diagram_designer.php',      'group' => 'Utilities'],
        ['key' => 'org_charts',           'label' => 'Org & Escalation Charts',  'href' => 'org_charts.php',            'group' => 'Utilities'],
        ['key' => 'hostname',             'label' => 'Hostname Generator',       'href' => 'hostname.php',              'group' => 'Utilities'],
        ['key' => 'subnet_calculator',    'label' => 'Subnet Calculator',        'href' => 'subnet_calculator.php',     'group' => 'Utilities'],
        ['key' => 'tcpdump_analyzer',     'label' => 'Tcpdump Analyzer',         'href' => 'tcpdump_analyzer.php',      'group' => 'Utilities'],
        ['key' => 'pasgen',               'label' => 'Password Generator',       'href' => 'pasgen.php',                'group' => 'Utilities'],
        ['key' => 'ssl_manager',          'label' => 'SSL Certificate Manager',  'href' => 'ssl_manager.php',           'group' => 'Utilities'],
        ['key' => 'presentation_designer','label' => 'Presentation Designer',    'href' => 'presentation-designer.php', 'group' => 'Utilities'],

        ['key' => 'notification',        'label' => 'Notifications',            'href' => 'notification.php',          'group' => 'Options'],
        ['key' => 'reminders',           'label' => 'Reminders and Notes',      'href' => 'reminders.php',             'group' => 'Options'],
        ['key' => 'myprofile',           'label' => 'My Profile',               'href' => 'myprofile.php',             'group' => 'Options'],
        ['key' => 'users',               'label' => 'Manage Users',             'href' => 'users.php',                 'group' => 'Options'],
        ['key' => 'settings',            'label' => 'Settings',                 'href' => 'settings.php',              'group' => 'Options'],
        ['key' => 'help',                'label' => 'Help Center',              'href' => 'help.php',                  'group' => 'Options'],
        ['key' => 'about',               'label' => 'About',                    'href' => 'about.php',                 'group' => 'Options'],
    ];
}
