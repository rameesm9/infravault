<?php

/**
 * AUDIT HELPER FUNCTIONS
 *
 * Functions for logging audit entries for reminders, sticky notes,
 * communications, and mydata modules.
 */

/**
 * Log a reminder action
 */
function logReminderAudit($pdo, $reminder_id, $action, $user_id, $user_name, $details = null)
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO reminder_audit
            (reminder_id, action, performed_by_id, user_name, action_date, details)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $reminder_id,
            $action,
            $user_id,
            $user_name,
            // Bound PHP date(), not SQL CURRENT_TIMESTAMP -- SQLite evaluates
            // CURRENT_TIMESTAMP in UTC always, ignoring date_default_timezone_set()
            // (config/db.php, Asia/Riyadh), which silently shifted every audit
            // entry's displayed time by the UTC/Riyadh offset.
            date('Y-m-d H:i:s'),
            $details
        ]);
    } catch (Exception $e) {
        // Log silently - don't break main operation
        error_log("Reminder audit logging failed: " . $e->getMessage());
    }
}

/**
 * Log a sticky note action
 */
function logStickyNoteAudit($pdo, $sticky_note_id, $action, $user_id, $user_name, $details = null)
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO sticky_note_audit
            (sticky_note_id, action, performed_by_id, user_name, action_date, details)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $sticky_note_id,
            $action,
            $user_id,
            $user_name,
            // See logReminderAudit() above -- bound PHP date(), not SQL
            // CURRENT_TIMESTAMP, which SQLite always evaluates in UTC.
            date('Y-m-d H:i:s'),
            $details
        ]);
    } catch (Exception $e) {
        // Log silently - don't break main operation
        error_log("Sticky note audit logging failed: " . $e->getMessage());
    }
}

/**
 * Log a communication action
 */
function logCommunicationAudit($pdo, $communication_id, $action, $user_id, $user_name, $details = null)
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO communication_audit
            (communication_id, action, performed_by_id, user_name, action_date, details)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $communication_id,
            $action,
            $user_id,
            $user_name,
            // See logReminderAudit() above -- bound PHP date(), not SQL
            // CURRENT_TIMESTAMP, which SQLite always evaluates in UTC.
            date('Y-m-d H:i:s'),
            $details
        ]);
    } catch (Exception $e) {
        // Log silently - don't break main operation
        error_log("Communication audit logging failed: " . $e->getMessage());
    }
}

/**
 * Log a mydata action
 */
function logMydataAudit($pdo, $mydata_id, $action, $user_id, $user_name, $details = null)
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO mydata_audit
            (mydata_id, action, performed_by_id, user_name, action_date, details)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $mydata_id,
            $action,
            $user_id,
            $user_name,
            // See logReminderAudit() above -- bound PHP date(), not SQL
            // CURRENT_TIMESTAMP, which SQLite always evaluates in UTC.
            date('Y-m-d H:i:s'),
            $details
        ]);
    } catch (Exception $e) {
        // Log silently - don't break main operation
        error_log("Mydata audit logging failed: " . $e->getMessage());
    }
}

/**
 * Check if user can edit a record
 * Returns true if:
 * - User has can_edit permission for the module, OR
 * - User is the author/creator of the record
 */
function canEdit($pdo, $user_id, $role, $module, $record_owner_id = null)
{
    // Admins always have edit access
    if (strtolower($role) === 'admin') {
        return true;
    }

    // Author/owner can always edit their own records
    if ($record_owner_id !== null && (int)$record_owner_id === (int)$user_id) {
        return true;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT can_edit
            FROM permissions
            WHERE LOWER(role) = LOWER(?)
            AND page_key = ?
            LIMIT 1
        ");

        $stmt->execute([$role, $module]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result && (int)$result['can_edit'] === 1;
    } catch (Exception $e) {
        // Default to false if permission check fails
        return false;
    }
}

/**
 * Check if user can delete a record
 * Returns true if:
 * - User has can_delete permission for the module, OR
 * - User is the author/creator of the record
 */
function canDelete($pdo, $user_id, $role, $module, $record_owner_id = null)
{
    // Admins always have delete access
    if (strtolower($role) === 'admin') {
        return true;
    }

    // Author/owner can always delete their own records
    if ($record_owner_id !== null && (int)$record_owner_id === (int)$user_id) {
        return true;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT can_delete
            FROM permissions
            WHERE LOWER(role) = LOWER(?)
            AND page_key = ?
            LIMIT 1
        ");

        $stmt->execute([$role, $module]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result && (int)$result['can_delete'] === 1;
    } catch (Exception $e) {
        // Default to false if permission check fails
        return false;
    }
}

/**
 * Get user's audit permission
 */
function canAudit($pdo, $user_id, $role, $module)
{
    // Admins always have audit access
    if (strtolower($role) === 'admin') {
        return true;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT can_audit
            FROM permissions
            WHERE LOWER(role) = LOWER(?)
            AND page_key = ?
            LIMIT 1
        ");

        $stmt->execute([$role, $module]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);

        return $result && (int)$result['can_audit'] === 1;
    } catch (Exception $e) {
        // Default to false if permission check fails
        return false;
    }
}

/**
 * Get audit history for a reminder
 */
function getReminderAuditHistory($pdo, $reminder_id)
{
    try {
        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM reminder_audit
            WHERE reminder_id = ?
            ORDER BY action_date DESC
        ");

        $stmt->execute([$reminder_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get audit history for a sticky note
 */
function getStickyNoteAuditHistory($pdo, $sticky_note_id)
{
    try {
        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM sticky_note_audit
            WHERE sticky_note_id = ?
            ORDER BY action_date DESC
        ");

        $stmt->execute([$sticky_note_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get audit history for a communication
 */
function getCommunicationAuditHistory($pdo, $communication_id)
{
    try {
        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM communication_audit
            WHERE communication_id = ?
            ORDER BY action_date DESC
        ");

        $stmt->execute([$communication_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get audit history for mydata
 */
function getMydataAuditHistory($pdo, $mydata_id)
{
    try {
        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM mydata_audit
            WHERE mydata_id = ?
            ORDER BY action_date DESC
        ");

        $stmt->execute([$mydata_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Get all audit history for a module type
 */
function getAllAuditHistory($pdo, $type)
{
    try {
        $table = '';
        switch ($type) {
            case 'reminder':
                $table = 'reminder_audit';
                break;
            case 'sticky_note':
                $table = 'sticky_note_audit';
                break;
            case 'communication':
                $table = 'communication_audit';
                break;
            case 'mydata':
                $table = 'mydata_audit';
                break;
            default:
                return [];
        }

        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM $table
            ORDER BY action_date DESC
        ");

        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}

/**
 * Format audit action for display
 */
function formatAuditEntry($entry)
{
    $action = htmlspecialchars($entry['action']);
    $user = htmlspecialchars($entry['user_name']);
    $date = htmlspecialchars($entry['action_date']);

    // Parse datetime
    $dateObj = DateTime::createFromFormat('Y-m-d H:i:s', $entry['action_date']);
    $formattedDate = $dateObj ? $dateObj->format('Y-m-d') : $date;
    $formattedTime = $dateObj ? $dateObj->format('H:i:s') : '';

    $details = '';
    if (!empty($entry['details'])) {
        $details = ' (' . htmlspecialchars($entry['details']) . ')';
    }

    return "$user $action on $formattedDate at $formattedTime$details";
}
