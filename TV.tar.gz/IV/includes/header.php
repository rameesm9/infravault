<?php

if(session_status() === PHP_SESSION_NONE){
    session_start();
}


require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notifications.php';
require_once __DIR__ . '/bookmarks-helpers.php';
require_once __DIR__ . '/branding-helpers.php';


$appName = getAppName($pdo);
$appLogoUrl = getAppLogoUrl($pdo);

// Pages set their own $page_title (usually "Page | InfraVault") before
// requiring this file -- rewriting the literal default name here means a
// rebrand in Settings takes effect on every title without editing each
// page individually.
$page_title = str_replace(BRANDING_DEFAULT_APP_NAME, $appName, $page_title ?? BRANDING_DEFAULT_APP_NAME);

$header_notifications = infravault_get_notifications(
    $pdo,
    (int) ($_SESSION['user_id'] ?? 0),
    (string) ($_SESSION['role'] ?? ''),
    (string) ($_SESSION['team'] ?? '')
);

$header_bookmark_registry = bookmarks_registry();

$header_bookmarked_keys = bookmarks_get_user(
    $pdo,
    (int) ($_SESSION['user_id'] ?? 0)
);

$header_bookmark_visible_keys = bookmarks_filter_visible(
    $pdo,
    (string) ($_SESSION['role'] ?? ''),
    array_column($header_bookmark_registry, 'key')
);

// "Add Bookmark" list: every visible page, grouped in registry order.
$header_bookmark_groups = [];
foreach ($header_bookmark_registry as $p) {
    if (!in_array($p['key'], $header_bookmark_visible_keys, true)) {
        continue;
    }
    $header_bookmark_groups[$p['group']][] = $p;
}

// "Your Bookmarks" list: the user's own picks, most recent first.
$header_bookmark_by_key = [];
foreach ($header_bookmark_registry as $p) {
    $header_bookmark_by_key[$p['key']] = $p;
}

$header_bookmarked_pages = [];
foreach ($header_bookmarked_keys as $k) {
    if (
        isset($header_bookmark_by_key[$k]) &&
        in_array($k, $header_bookmark_visible_keys, true)
    ) {
        $header_bookmarked_pages[] = $header_bookmark_by_key[$k];
    }
}

if (!function_exists('notif_time_ago')) {
function notif_time_ago(?string $datetime): string
{
    if (!$datetime) {
        return '';
    }

    $timestamp = strtotime($datetime);

    if (!$timestamp) {
        return '';
    }

    $diff = time() - $timestamp;

    if ($diff < 60) {
        return 'just now';
    }
    if ($diff < 3600) {
        return floor($diff / 60) . 'm ago';
    }
    if ($diff < 86400) {
        return floor($diff / 3600) . 'h ago';
    }
    if ($diff < 2592000) {
        return floor($diff / 86400) . 'd ago';
    }

    return date('d M Y', $timestamp);
}
}

require_once __DIR__ . '/avatars.php';

if (!function_exists('get_user_avatar')) {
/**
 * Renders a user's chosen avatar.
 *
 * The emoji map that used to live here has moved to includes/avatars.php
 * as illustrated SVG portraits -- emoji rendered differently on every
 * OS, and half the old options (star, sun, moon, heart, clown) were not
 * people at all. Saved values from the old set are mapped across by
 * avatarResolveKey(), so no existing profile loses its selection.
 */
function get_user_avatar($user_id, $avatar_choice, $name): string
{
    $colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];
    $color = $colors[((int) $user_id) % count($colors)];

    return '<div class="avatar-icon avatar-svg">'
         . renderAvatar((string) $avatar_choice, 40, (string) ($name ?? 'U'), $color)
         . '</div>';
}
}

?>


<!DOCTYPE html>

<html lang="en" data-theme="<?= ($_SESSION['theme'] ?? 'light') === 'dark' ? 'dark' : 'light' ?>">


<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
<?= htmlspecialchars($page_title); ?>
</title>

<?php /* Without an explicit icon the browser requests /favicon.ico on every
         page load and logs a 404, since the project ships no .ico file.
         Pointing at the existing SVG logo stops that request entirely. */ ?>
<link rel="icon" href="<?= htmlspecialchars($appLogoUrl); ?>">



<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/components.css">

<link rel="stylesheet" href="assets/css/header.css">

<link rel="stylesheet" href="assets/css/dashboard.css">

<link rel="stylesheet" href="assets/css/chat-widget.css">

<link rel="stylesheet" href="assets/css/page-transitions.css">

<?php /* Blocking (no defer/async) so its enter-pose class lands on <html>
         before .content is ever painted in its resting state -- see the
         file's own header comment for why. */ ?>
<script src="assets/js/page-transitions.js"></script>

<noscript><style>.content{ opacity: 1 !important; transform: none !important; }</style></noscript>

</head>



<body>


<?php /* Applied before the header/hotzone markup so a pinned header is
         already reserved-space and visible on first paint -- same
         no-flash reasoning as includes/sidebar.php's collapsed-state
         script. */ ?>
<script>
(function(){
    if(localStorage.getItem("headerPinned") === "1"){
        document.body.classList.add("header-pinned");
    }
})();
</script>


<!-- Hovering this thin strip reveals the auto-hidden header below. -->
<div id="headerHotzone"></div>


<header class="top-header">



<!-- LEFT BRAND -->


<div class="header-brand">







<div class="brand-subtitle">

Enterprise IT Management Platform




</div>


</div>








<!-- CENTER MENU -->


<nav class="header-navigation">


<a href="home.php" class="active" title="Dashboard">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M3 13h8V3H3z"/>
<path d="M13 21h8v-8h-8z"/>
<path d="M13 3h8v6h-8z"/>
<path d="M3 17h8v4H3z"/>
</svg>
</a>


<a href="inventory.php" title="Inventory">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M21 16V8"/>
<path d="M3 8v8"/>
<path d="M12 3v18"/>
<path d="M3 8l9-5 9 5-9 5-9-5z"/>
</svg>
</a>


<a href="#" title="Security">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
</svg>
</a>


<a href="#" title="Monitoring">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
</svg>
</a>


<a href="#" title="Reports">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
<polyline points="14 2 14 8 20 8"/>
<line x1="16" y1="13" x2="8" y2="13"/>
<line x1="16" y1="17" x2="8" y2="17"/>
</svg>
</a>


</nav>








<!-- RIGHT AREA -->


<div class="header-right">












<!-- PIN HEADER -->

<button
    id="headerPinToggle"
    class="header-button"
    type="button"
    title="Pin header"
    aria-label="Pin header"
    aria-pressed="false"
>
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
        <path d="M12 17v5"></path>
        <path d="M9 10.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24V16a1 1 0 0 0 1 1h12a1 1 0 0 0 1-1v-.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V7a1 1 0 0 1 1-1 2 2 0 0 0 0-4H8a2 2 0 0 0 0 4 1 1 0 0 1 1 1z"></path>
    </svg>
</button>

<!-- DARK MODE TOGGLE -->

<button
    id="themeToggle"
    class="header-button"
    type="button"
    title="Toggle dark/light mode"
    aria-label="Toggle dark/light mode"
>
    <svg id="sunIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: none;">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
    </svg>
    <svg id="moonIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
    </svg>
</button>

<!-- NOTIFICATION -->


<div class="notif-wrap">

<button
    class="header-button notification-btn"
    id="notifBellBtn"
    type="button"
    aria-haspopup="true"
    aria-expanded="false"
>


<svg viewBox="0 0 24 24">


<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"></path>


<path d="M13 21h-2"></path>


</svg>


<?php if ($header_notifications['badge_count'] > 0): ?>
<span><?= $header_notifications['badge_count'] > 9 ? '9+' : (int) $header_notifications['badge_count'] ?></span>
<?php endif; ?>


</button>


<div class="notif-panel" id="notifPanel">

    <div class="notif-panel-header">
        <strong>Notifications</strong>
        <a href="notification.php">View all</a>
    </div>

    <div class="notif-panel-body">

        <?php if (
            !$header_notifications['communications'] &&
            !$header_notifications['reminders'] &&
            !$header_notifications['sticky_notes'] &&
            !$header_notifications['shared_data'] &&
            !$header_notifications['kb_sop_activity'] &&
            !$header_notifications['my_decommission_count'] &&
            !$header_notifications['my_patching_count'] &&
            !$header_notifications['my_sop_review_count'] &&
            !$header_notifications['my_grc_count'] &&
            !$header_notifications['my_ticket_count'] &&
            !$header_notifications['oncall_current']
        ): ?>

            <div class="notif-empty">
                You're all caught up.
            </div>

        <?php endif; ?>


        <?php if ($header_notifications['oncall_current']): ?>

            <div class="notif-section">

                <span class="notif-section-title">On-Call</span>

                <a href="oncall.php" class="notif-item<?= $header_notifications['oncall_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['oncall_item_key']) ?>">

                    <span class="notif-dot priority-critical"></span>

                    <span class="notif-item-text">
                        <span class="notif-item-title">
                            You're on call now (<?= htmlspecialchars($header_notifications['oncall_current']['my_role']) ?>)
                        </span>
                        <span class="notif-item-meta">
                            <?= htmlspecialchars($header_notifications['oncall_current']['shift_label'] ?: $header_notifications['oncall_current']['rota_team'] ?: 'On-Call Shift') ?>
                            &middot;
                            until <?= htmlspecialchars(date('d M, H:i', strtotime($header_notifications['oncall_current']['ends_at']))) ?>
                        </span>
                    </span>

                </a>

            </div>

        <?php elseif ($header_notifications['oncall_next']): ?>

            <div class="notif-section">

                <span class="notif-section-title">On-Call</span>

                <a href="oncall.php" class="notif-item">

                    <span class="notif-dot priority-normal"></span>

                    <span class="notif-item-text">
                        <span class="notif-item-title">
                            Next on-call shift (<?= htmlspecialchars($header_notifications['oncall_next']['my_role']) ?>)
                        </span>
                        <span class="notif-item-meta">
                            Starts <?= htmlspecialchars(date('d M, H:i', strtotime($header_notifications['oncall_next']['starts_at']))) ?>
                        </span>
                    </span>

                </a>

            </div>

        <?php endif; ?>


        <?php if (
            $header_notifications['my_decommission_count'] ||
            $header_notifications['my_patching_count'] ||
            $header_notifications['my_sop_review_count'] ||
            $header_notifications['my_grc_count'] ||
            $header_notifications['my_ticket_count']
        ): ?>

            <div class="notif-section">

                <span class="notif-section-title">Assigned to You</span>

                <?php if ($header_notifications['my_decommission_count']): ?>
                    <a href="decommission.php" class="notif-item<?= $header_notifications['decomm_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['decomm_item_key']) ?>">
                        <span class="notif-dot priority-normal"></span>
                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= (int) $header_notifications['my_decommission_count'] ?> decommission batch<?= $header_notifications['my_decommission_count'] === 1 ? '' : 'es' ?> assigned to you
                            </span>
                            <span class="notif-item-meta">Not yet decommissioned</span>
                        </span>
                    </a>
                <?php endif; ?>

                <?php if ($header_notifications['my_patching_count']): ?>
                    <a href="patching.php" class="notif-item<?= $header_notifications['patch_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['patch_item_key']) ?>">
                        <span class="notif-dot priority-normal"></span>
                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= (int) $header_notifications['my_patching_count'] ?> server<?= $header_notifications['my_patching_count'] === 1 ? '' : 's' ?> assigned to you in Quarterly Patching
                            </span>
                            <span class="notif-item-meta">This quarter &middot; not yet completed</span>
                        </span>
                    </a>
                <?php endif; ?>

                <?php if ($header_notifications['my_sop_review_count']): ?>
                    <a href="sop.php" class="notif-item<?= $header_notifications['sop_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['sop_item_key']) ?>">
                        <span class="notif-dot priority-normal"></span>
                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= (int) $header_notifications['my_sop_review_count'] ?> SOP<?= $header_notifications['my_sop_review_count'] === 1 ? '' : 's' ?> awaiting your review
                            </span>
                            <span class="notif-item-meta">Pending Review</span>
                        </span>
                    </a>
                <?php endif; ?>

                <?php if ($header_notifications['my_grc_count']): ?>
                    <a href="grc_schedule.php" class="notif-item<?= $header_notifications['grc_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['grc_item_key']) ?>">
                        <span class="notif-dot priority-normal"></span>
                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= (int) $header_notifications['my_grc_count'] ?> GRC schedule<?= $header_notifications['my_grc_count'] === 1 ? '' : 's' ?> assigned to you
                            </span>
                            <span class="notif-item-meta">Not yet patched</span>
                        </span>
                    </a>
                <?php endif; ?>

                <?php if ($header_notifications['my_ticket_count']): ?>
                    <a href="tickets.php" class="notif-item<?= $header_notifications['ticket_read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($header_notifications['ticket_item_key']) ?>">
                        <span class="notif-dot priority-normal"></span>
                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= (int) $header_notifications['my_ticket_count'] ?> ticket<?= $header_notifications['my_ticket_count'] === 1 ? '' : 's' ?> assigned to you
                            </span>
                            <span class="notif-item-meta">Not yet closed</span>
                        </span>
                    </a>
                <?php endif; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['communications']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Team Notes</span>

                <?php foreach ($header_notifications['communications'] as $c): ?>

                    <a href="notification.php" class="notif-item<?= $c['read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($c['item_key']) ?>">

                        <span class="notif-dot priority-<?= htmlspecialchars(strtolower($c['priority'] ?? 'normal')) ?>"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($c['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= htmlspecialchars($c['note_type'] ?? 'Announcement') ?>
                                &middot;
                                <?= notif_time_ago($c['created_at']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['reminders']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Reminders</span>

                <?php foreach ($header_notifications['reminders'] as $r): ?>

                    <?php $is_overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s'); ?>

                    <a href="reminders.php" class="notif-item<?= $r['read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($r['item_key']) ?>">

                        <span class="notif-dot <?= $is_overdue ? 'priority-critical' : 'priority-normal' ?>"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($r['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= $is_overdue ? 'Overdue' : 'Due' ?>
                                <?= htmlspecialchars(date('d M, H:i', strtotime($r['reminder_date']))) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['sticky_notes']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Sticky Notes</span>

                <?php foreach ($header_notifications['sticky_notes'] as $n): ?>

                    <a href="reminders.php" class="notif-item">

                        <span class="notif-dot priority-note"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= htmlspecialchars(infravault_truncate($n['content'], 60)) ?>
                            </span>
                            <span class="notif-item-meta">
                                <?= htmlspecialchars(trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team') ?>
                                &middot;
                                <?= notif_time_ago($n['updated_at']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['shared_data']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Shared Data</span>

                <?php foreach ($header_notifications['shared_data'] as $d): ?>

                    <a href="mydata.php?view=<?= (int) $d['id'] ?>" class="notif-item<?= $d['read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($d['item_key']) ?>">

                        <span class="notif-dot priority-normal"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($d['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= $d['visibility'] === 'Team'
                                    ? 'Shared with your team'
                                    : 'Shared with you' ?>
                                &middot;
                                <?= htmlspecialchars(trim(($d['owner_first'] ?? '') . ' ' . ($d['owner_last'] ?? '')) ?: 'Someone') ?>
                                &middot;
                                <?= notif_time_ago($d['updated_at']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['kb_sop_activity']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Knowledge Base &amp; SOP</span>

                <?php foreach ($header_notifications['kb_sop_activity'] as $a): ?>

                    <?php
                        $kb_sop_action_labels = [
                            'EDITED'        => 'updated',
                            'COMMENT_ADDED' => 'commented on',
                            'PUBLISHED'     => 'approved and published',
                            'REJECTED'      => 'rejected',
                        ];
                        $a_module_label = $a['module'] === 'sop' ? 'SOP' : 'knowledge base article';
                        $a_verb = $kb_sop_action_labels[$a['action']] ?? strtolower($a['action']);
                        $a_is_critical = $a['action'] === 'REJECTED';
                    ?>

                    <a href="<?= htmlspecialchars($a['href']) ?>" class="notif-item<?= $a['read'] ? ' notif-item-read' : '' ?>" data-item-key="<?= htmlspecialchars($a['item_key']) ?>">

                        <span class="notif-dot <?= $a_is_critical ? 'priority-critical' : 'priority-normal' ?>"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($a['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= htmlspecialchars($a['actor_name']) ?> <?= $a_verb ?> this <?= $a_module_label ?>
                                &middot;
                                <?= notif_time_ago($a['date']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

</div>

</div>


<script>
(function(){
    const btn = document.getElementById('notifBellBtn');
    const panel = document.getElementById('notifPanel');

    if (!btn || !panel) {
        return;
    }

    btn.addEventListener('click', function(e){
        e.stopPropagation();
        const open = panel.classList.toggle('open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    document.addEventListener('click', function(e){
        if (!panel.classList.contains('open')) {
            return;
        }
        if (e.target.closest('.notif-wrap')) {
            return;
        }
        panel.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
    });
})();
</script>


<!-- BOOKMARKS -->


<div class="notif-wrap bookmark-wrap">

<button
    class="header-button notification-btn"
    id="bookmarkBtn"
    type="button"
    aria-haspopup="true"
    aria-expanded="false"
    title="Bookmarks"
>


<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01L12 2z"/>
</svg>


</button>


<div class="notif-panel" id="bookmarkPanel">

    <div class="notif-panel-header">
        <strong>Bookmarks</strong>
    </div>

    <div class="notif-panel-body">

        <?php if ($header_bookmarked_pages): ?>

            <div class="notif-section">

                <span class="notif-section-title">Your Bookmarks</span>

                <?php foreach ($header_bookmarked_pages as $bp): ?>

                    <div class="notif-item bookmark-item">

                        <a href="<?= htmlspecialchars($bp['href']) ?>" class="bookmark-item-link">
                            <span class="notif-item-text">
                                <span class="notif-item-title"><?= htmlspecialchars($bp['label']) ?></span>
                                <span class="notif-item-meta"><?= htmlspecialchars($bp['group']) ?></span>
                            </span>
                        </a>

                        <button
                            type="button"
                            class="bookmark-remove-btn bm-toggle"
                            data-page-key="<?= htmlspecialchars($bp['key']) ?>"
                            title="Remove bookmark"
                        >&times;</button>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <div class="notif-empty">
                No bookmarks yet. Star a page below to add it here.
            </div>

        <?php endif; ?>


        <div class="notif-section">

            <button
                type="button"
                class="bookmark-add-toggle"
                id="bookmarkAddToggle"
                aria-expanded="false"
                aria-controls="bookmarkAddList"
            >
                <span>Add Bookmark</span>
                <span class="bookmark-add-arrow">▾</span>
            </button>

            <div class="bookmark-add-list" id="bookmarkAddList" hidden>

                <?php foreach ($header_bookmark_groups as $groupName => $bookmarkGroupPages): ?>

                    <div class="bookmark-group-title"><?= htmlspecialchars($groupName) ?></div>

                    <?php foreach ($bookmarkGroupPages as $p): ?>

                        <?php $isBookmarked = in_array($p['key'], $header_bookmarked_keys, true); ?>

                        <button
                            type="button"
                            class="notif-item bookmark-toggle-row bm-toggle <?= $isBookmarked ? 'is-bookmarked' : '' ?>"
                            data-page-key="<?= htmlspecialchars($p['key']) ?>"
                        >

                            <span class="bookmark-star">
                                <svg viewBox="0 0 24 24">
                                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87L18.18 21 12 17.77 5.82 21 7 14.14l-5-4.87 6.91-1.01L12 2z"/>
                                </svg>
                            </span>

                            <span class="notif-item-title"><?= htmlspecialchars($p['label']) ?></span>

                        </button>

                    <?php endforeach; ?>

                <?php endforeach; ?>

            </div>

        </div>

    </div>

</div>

</div>


<script>
window.__bmCsrf = <?= json_encode(csrfToken()) ?>;

(function(){
    const btn = document.getElementById('bookmarkBtn');
    const panel = document.getElementById('bookmarkPanel');

    if (!btn || !panel) {
        return;
    }

    btn.addEventListener('click', function(e){
        e.stopPropagation();
        const open = panel.classList.toggle('open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    document.addEventListener('click', function(e){
        if (!panel.classList.contains('open')) {
            return;
        }
        if (e.target.closest('.bookmark-wrap')) {
            return;
        }
        panel.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
    });

    const addToggle = document.getElementById('bookmarkAddToggle');
    const addList = document.getElementById('bookmarkAddList');

    if (addToggle && addList) {
        addToggle.addEventListener('click', function(e){
            e.stopPropagation();
            const open = addList.hidden;
            addList.hidden = !open;
            addToggle.classList.toggle('open', open);
            addToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
        });
    }

    panel.addEventListener('click', function(e){
        const toggle = e.target.closest('.bm-toggle');

        if (!toggle) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        if (toggle.disabled) {
            return;
        }

        const pageKey = toggle.dataset.pageKey;
        toggle.disabled = true;

        const body = new URLSearchParams();
        body.set('page_key', pageKey);
        body.set('csrf_token', window.__bmCsrf || '');

        fetch('bookmark_toggle.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        })
        .then(function(r){ return r.json(); })
        .then(function(data){
            if (data && data.success) {
                location.reload();
                return;
            }
            alert((data && data.error) || 'Could not update bookmark.');
            toggle.disabled = false;
        })
        .catch(function(){
            alert('Could not update bookmark.');
            toggle.disabled = false;
        });
    });
})();

/*
|--------------------------------------------------------------------------
| Notification bell -- mark an item read on click, then follow its link.
| Only ever writes this user's own row in notification_reads (via
| notification_read.php); the underlying communications/reminders row is
| untouched, so the item still shows here, just no longer counted in the
| unread badge on the next page load.
|--------------------------------------------------------------------------
*/
(function(){
    const notifPanel = document.getElementById('notifPanel');
    if (!notifPanel) {
        return;
    }

    notifPanel.addEventListener('click', function(e){

        const item = e.target.closest('.notif-item[data-item-key]');

        if (!item || item.classList.contains('notif-item-read')) {
            return;
        }

        e.preventDefault();

        const body = new URLSearchParams();
        body.set('item_key', item.dataset.itemKey);
        body.set('csrf_token', window.__bmCsrf || '');

        fetch('notification_read.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            keepalive: true
        })
        .catch(function(){})
        .finally(function(){
            window.location = item.href;
        });
    });
})();
</script>


<script>
/*
|--------------------------------------------------------------------------
| Dark/light mode -- per-user, not per-browser. The initial data-theme
| attribute is rendered server-side from $_SESSION['theme'] (see the
| <html> tag above), so this only reflects icon state and persists a
| change via theme_save.php, which writes users.theme for this account
| only. Nothing here reads/writes localStorage, so a shared browser
| never leaks one user's preference into another user's session.
|--------------------------------------------------------------------------
*/
(function(){
    const themeToggle = document.getElementById('themeToggle');
    const sunIcon = document.getElementById('sunIcon');
    const moonIcon = document.getElementById('moonIcon');
    const html = document.documentElement;

    function updateIcons(theme) {
        if (theme === 'dark') {
            sunIcon.style.display = 'block';
            moonIcon.style.display = 'none';
        } else {
            sunIcon.style.display = 'none';
            moonIcon.style.display = 'block';
        }
    }

    updateIcons(html.getAttribute('data-theme') || 'light');

    themeToggle.addEventListener('click', function() {
        const currentTheme = html.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';

        html.setAttribute('data-theme', newTheme);
        updateIcons(newTheme);

        const body = new URLSearchParams();
        body.set('theme', newTheme);
        body.set('csrf_token', window.__bmCsrf || '');

        fetch('theme_save.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString(),
            keepalive: true
        }).catch(function(){});
    });
})();
</script>







<!-- USER -->


<div class="header-user">



<div class="user-avatar">
<a href="myprofile.php" title="Edit Profile">

<?= get_user_avatar(
    (int) ($_SESSION['user_id'] ?? 0),
    (string) ($_SESSION['avatar'] ?? 'initials'),
    (string) ($_SESSION['name'] ?? 'User')
); ?>

</a>
</div>





<div class="user-details">

<strong>

<?= htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?>

</strong>

</div>



</div>








<!-- SIGN OUT -->


<a href="logout.php" class="header-signout"
onclick="return confirm('Are you sure you want to sign out?');">
    <i class="fa-solid fa-right-from-bracket"></i>
<span>
Sign Out
</span>

</a>



</div>



</header>


<?php /* Auto-hide header: reveals on hover over the hotzone strip or the
         header itself, hides again shortly after the pointer leaves both.
         A hover over a descendant of .top-header (e.g. an open notif/
         bookmark dropdown, which renders outside the header's visual box
         via position:absolute but is still in its DOM subtree) does not
         count as leaving it -- mouseenter/mouseleave only fire on a true
         boundary crossing of the element's own subtree -- so an open
         dropdown does not get yanked away mid-use.

         The hotzone is taller than the header's own top padding (48px,
         so it's actually easy to land the cursor on) which means once
         the header slides down, the hotzone's box physically overlaps
         the header's own buttons -- and since the hotzone sits at a
         higher z-index (so it's reachable while the header is still
         off-screen), it would otherwise sit on top of and swallow
         clicks meant for the notification bell / bookmark star /
         dark-mode toggle for as long as the header stays visible.
         Switching the hotzone to pointer-events:none exactly while
         the header is shown hands those clicks through to the header
         underneath; it goes back to catching hovers once the header
         actually hides again. */ ?>
<script>
(function(){
    var header = document.querySelector(".top-header");
    var hotzone = document.getElementById("headerHotzone");
    var pinBtn = document.getElementById("headerPinToggle");

    if(!header || !hotzone){
        return;
    }

    function isPinned(){
        return document.body.classList.contains("header-pinned");
    }

    var hideTimer = null;

    function show(){
        clearTimeout(hideTimer);
        header.classList.add("header-visible");
        hotzone.style.pointerEvents = "none";
    }

    function scheduleHide(){
        clearTimeout(hideTimer);

        // Pinned: stays visible, no hover-driven hide -- the point of
        // pinning is that it no longer depends on where the cursor is.
        if(isPinned()){
            return;
        }

        hideTimer = setTimeout(function(){
            header.classList.remove("header-visible");
            hotzone.style.pointerEvents = "";
        }, 400);
    }

    hotzone.addEventListener("mouseenter", show);
    hotzone.addEventListener("mouseleave", scheduleHide);

    header.addEventListener("mouseenter", show);
    header.addEventListener("mouseleave", scheduleHide);


    // PIN TOGGLE
    // body.header-pinned (applied inline earlier for a flash-free first
    // paint, see the script right after <body>) drives the actual CSS
    // -- .content/.main-container reserving the header's height again,
    // the header forced visible -- via header.css. This click handler
    // only has to flip that class, persist the choice, and keep the
    // button's own visual state in sync.
    if(pinBtn){

        function syncPinButton(){
            var pinned = isPinned();
            pinBtn.classList.toggle("is-pinned", pinned);
            pinBtn.setAttribute("aria-pressed", pinned ? "true" : "false");
            pinBtn.title = pinned ? "Unpin header" : "Pin header";

            if(pinned){
                show();
            } else {
                // Unpinning happens with the cursor still over the header
                // (the button is inside it), so the ordinary hover-driven
                // hide would otherwise wait for a mouseleave that may not
                // come for a while. Force it the moment the header is no
                // longer pinned instead of waiting on that.
                header.classList.remove("header-visible");
                hotzone.style.pointerEvents = "";
            }
        }

        syncPinButton();

        pinBtn.addEventListener("click", function(){
            document.body.classList.toggle("header-pinned");

            try{
                localStorage.setItem(
                    "headerPinned",
                    isPinned() ? "1" : "0"
                );
            } catch(err){}

            syncPinButton();
        });
    }
})();
</script>




<!-- PAGE START -->

<div class="main-container">
