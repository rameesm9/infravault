</div>


<!-- Hovering this thin strip reveals the auto-hidden footer above it. -->
<div id="footerHotzone"></div>


<footer>


<?= htmlspecialchars($appName ?? getAppName($pdo)); ?> © <?= date("Y"); ?>

&nbsp; | &nbsp;

Enterprise IT Inventory Management


</footer>


<?php /* Auto-hide footer: mirrors the header's hotzone/hover behaviour
         in includes/header.php. */ ?>
<script>
(function(){
    var footer = document.querySelector("footer");
    var hotzone = document.getElementById("footerHotzone");

    if(!footer || !hotzone){
        return;
    }

    var hideTimer = null;

    function show(){
        clearTimeout(hideTimer);
        footer.classList.add("footer-visible");
    }

    function scheduleHide(){
        clearTimeout(hideTimer);
        hideTimer = setTimeout(function(){
            footer.classList.remove("footer-visible");
        }, 400);
    }

    hotzone.addEventListener("mouseenter", show);
    hotzone.addEventListener("mouseleave", scheduleHide);

    footer.addEventListener("mouseenter", show);
    footer.addEventListener("mouseleave", scheduleHide);
})();
</script>



<?php
/*
| The footer's inline <style> block was removed rather than updated.
|
| It re-declared `footer { ... }` with hardcoded background:white,
| color:#64748B and border-top:#E2E8F0. Being later in the document at
| the same specificity as the rule in assets/css/style.css, it won the
| cascade -- so the footer stayed white with light-grey text in dark
| mode, ignoring --bg-footer entirely.
|
| style.css already styles the footer fully (fixed position, flex
| centring, height, and the themed colours), so the padding/text-align
| here were redundant against a flex-centred bar.
*/
?>

<script src="assets/js/app.js"></script>
<script src="assets/js/sidebar.js"></script>

<?php /* .content exists in the DOM by now -- wires up the exit-click
         interception and plays this page's entrance motion. See
         assets/js/page-transitions.js. */ ?>
<script>window.__ptInit && window.__ptInit();</script>

<?php require __DIR__ . '/chat-widget.php'; ?>

</body>

</html>
