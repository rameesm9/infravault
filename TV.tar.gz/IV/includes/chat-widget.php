<?php

/*
| Floating AI assistant widget, backed entirely by the offline "llm"
| container (see compose.yaml) -- no request from here ever leaves the
| host. Included from includes/footer.php so it's available on every
| page that renders the standard layout.
|
| require_once here is deliberate defense: this file assumes $pdo/session
| already exist (header.php always loads config/db.php first), but a
| stray direct include elsewhere should not fatal instead of just being
| a no-op.
*/

require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/branding-helpers.php';

if (!authzIsLoggedIn()) {
    return;
}

$chatAppName = getAppName($pdo);

?>

<div id="aiChatWidget">

    <button
        type="button"
        id="aiChatToggle"
        class="ai-chat-toggle"
        title="AI Assistant"
        aria-label="Open AI assistant"
        aria-expanded="false"
    >
        <svg viewBox="0 0 24 24">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
    </button>

    <div class="ai-chat-panel" id="aiChatPanel">

        <div class="ai-chat-panel-header">
            <div>
                <strong><?= htmlspecialchars($chatAppName) ?> Assistant</strong>
                <span>Chat with me</span>
            </div>
            <button type="button" id="aiChatClose" class="ai-chat-close" aria-label="Close">&times;</button>
        </div>

        <div class="ai-chat-messages" id="aiChatMessages">
            <div class="ai-chat-msg ai-chat-msg-assistant">
            Hi! 
            You can ask me about anything...
            </div>
        </div>

        <div class="ai-chat-input-row">
            <textarea
                id="aiChatInput"
                class="ai-chat-input"
                rows="1"
                placeholder="Type a message..."
            ></textarea>
            <button type="button" id="aiChatSend" class="ai-chat-send" aria-label="Send message">
                <svg viewBox="0 0 24 24">
                    <line x1="22" y1="2" x2="11" y2="13"/>
                    <polygon points="22 2 15 22 11 13 2 9 22 2"/>
                </svg>
            </button>
        </div>

    </div>

</div>

<script>
window.__aiChatCsrf = <?= json_encode(csrfToken()) ?>;

(function(){
    const toggle   = document.getElementById('aiChatToggle');
    const panel    = document.getElementById('aiChatPanel');
    const closeBtn = document.getElementById('aiChatClose');
    const messages = document.getElementById('aiChatMessages');
    const input    = document.getElementById('aiChatInput');
    const sendBtn  = document.getElementById('aiChatSend');

    if (!toggle || !panel) {
        return;
    }

    // Kept in memory only -- reloading the page starts a fresh
    // conversation. This is a small test widget, not a persisted chat log.
    let history = [];
    let busy = false;

    function open(){
        panel.classList.add('open');
        toggle.setAttribute('aria-expanded', 'true');
        input.focus();
    }

    function close(){
        panel.classList.remove('open');
        toggle.setAttribute('aria-expanded', 'false');
    }

    toggle.addEventListener('click', function(){
        panel.classList.contains('open') ? close() : open();
    });

    if (closeBtn) {
        closeBtn.addEventListener('click', close);
    }

    document.addEventListener('keydown', function(e){
        if (e.key === 'Escape' && panel.classList.contains('open')) {
            close();
        }
    });

    function addMessage(role, text){
        const div = document.createElement('div');
        div.className = 'ai-chat-msg ai-chat-msg-' + role;
        div.textContent = text;
        messages.appendChild(div);
        messages.scrollTop = messages.scrollHeight;
        return div;
    }

    function send(){
        const text = input.value.trim();

        if (!text || busy) {
            return;
        }

        addMessage('user', text);
        input.value = '';
        input.style.height = 'auto';

        busy = true;
        sendBtn.disabled = true;

        const thinking = addMessage('assistant', 'Thinking...');
        thinking.classList.add('ai-chat-msg-pending');

        const body = new URLSearchParams();
        body.set('message', text);
        body.set('history', JSON.stringify(history));
        body.set('csrf_token', window.__aiChatCsrf || '');

        fetch('ai_chat.php', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        })
        .then(function(r){ return r.json(); })
        .then(function(data){
            thinking.remove();

            if (data && data.success) {
                addMessage('assistant', data.reply);
                history.push({ role: 'user', content: text });
                history.push({ role: 'assistant', content: data.reply });
            } else {
                addMessage('assistant', (data && data.error) || 'Something went wrong.');
            }
        })
        .catch(function(){
            thinking.remove();
            addMessage('assistant', 'Could not reach the assistant. the function not ready yet..!');
        })
        .finally(function(){
            busy = false;
            sendBtn.disabled = false;
        });
    }

    sendBtn.addEventListener('click', send);

    input.addEventListener('keydown', function(e){
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            send();
        }
    });

    input.addEventListener('input', function(){
        input.style.height = 'auto';
        input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    });
})();
</script>
