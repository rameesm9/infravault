<?php
/**
 * VA Assessment -- shared CSV parsing, project/RHEL-tag derivation, and
 * spreadsheet export helpers.
 *
 * The CSV parsing (header normalization, alias resolution, delimiter
 * detection, encoding handling) mirrors vulnerability_upload.php's proven
 * pattern: column order never matters and a wording difference between
 * scanner exports doesn't stop an import, it just leaves that field blank
 * for the rows where it wasn't found.
 */


/*
|--------------------------------------------------------------------------
| HEADER NORMALIZATION / ALIAS MATCHING
|--------------------------------------------------------------------------
*/

function vaAssessNormalizeHeader(string $value): string
{
    $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);   // UTF-8 BOM
    $value = preg_replace('/^\xFF\xFE/', '', $value);       // UTF-16 LE BOM
    $value = preg_replace('/^\xFE\xFF/', '', $value);       // UTF-16 BE BOM

    $value = str_replace(["\xC2\xA0", "\xA0", "\r", "\n", "\t"], ' ', $value);
    $value = trim($value);
    $value = strtolower($value);
    $value = preg_replace('/[^a-z0-9]/', '', $value);

    return $value;
}

/**
 * Every recognized field, matched against the exact CSV header names the
 * user's exports use plus common synonyms other scanners use for the same
 * data. Order of the file's columns never matters.
 */
function vaAssessFieldAliases(): array
{
    return [
        'plugin'             => ['Plugin', 'Plugin ID', 'PluginID'],
        'plugin_name'        => ['Plugin Name', 'PluginName', 'Vulnerability Name', 'Finding Name', 'Finding', 'Title'],
        'family'             => ['Family', 'Plugin Family'],
        'severity'           => ['Severity', 'Risk', 'Risk Rating', 'Risk Level'],
        'ip_address'         => ['IP Address', 'IPAddress', 'IPv4 Address', 'IPv4', 'Host IP', 'Asset IP', 'IP'],
        'port'               => ['Port', 'Port Number', 'Port/Protocol'],
        'exploit'            => ['Exploit?', 'Exploit', 'Exploitable', 'Exploit Available'],
        'repository'         => ['Repository', 'Repo'],
        'mac_address'        => ['MAC Address', 'MACAddress', 'MAC'],
        'dns_name'           => ['DNS Name', 'DNS', 'FQDN'],
        'netbios_name'       => ['NetBIOS Name', 'Netbios Name', 'NetBIOS'],
        'plugin_output'      => ['Plugin Output', 'Output', 'Result', 'Evidence'],
        'steps_to_remediate' => ['Steps to Remediate', 'Steps To Remediate', 'Remediation', 'Solution', 'Fix', 'Recommendation'],
        'cve'                => ['CVE', 'CVE ID', 'CVEs', 'CVE-ID', 'CVE Number'],
        'first_discovered'   => ['First Discovered', 'First Seen', 'Discovered Date'],
        'last_observed'      => ['Last Observed', 'Last Seen', 'Last Detected'],
        'synopsis'           => ['Synopsis', 'Summary'],
    ];
}

function vaAssessFieldLabels(): array
{
    return [
        'plugin' => 'Plugin', 'plugin_name' => 'Plugin Name', 'family' => 'Family',
        'severity' => 'Severity', 'ip_address' => 'IP Address', 'port' => 'Port',
        'exploit' => 'Exploit?', 'repository' => 'Repository', 'mac_address' => 'MAC Address',
        'dns_name' => 'DNS Name', 'netbios_name' => 'NetBIOS Name', 'plugin_output' => 'Plugin Output',
        'steps_to_remediate' => 'Steps to Remediate', 'cve' => 'CVE',
        'first_discovered' => 'First Discovered', 'last_observed' => 'Last Observed',
        'synopsis' => 'Synopsis',
    ];
}

/**
 * 1) Exact match against the known aliases (order-independent).
 * 2) Fuzzy fallback: a header that CONTAINS (or is contained by) an alias
 *    still resolves, so small wording differences work automatically.
 */
function vaAssessResolveFieldIndex(array $headerMap, array $aliases): ?int
{
    foreach ($aliases as $alias) {
        $normalized = vaAssessNormalizeHeader($alias);
        if (isset($headerMap[$normalized])) {
            return $headerMap[$normalized];
        }
    }

    foreach ($aliases as $alias) {
        $normalized = vaAssessNormalizeHeader($alias);

        if (strlen($normalized) < 4) {
            continue;
        }

        foreach ($headerMap as $fileHeader => $index) {
            if (
                str_contains($fileHeader, $normalized) ||
                str_contains($normalized, $fileHeader)
            ) {
                return $index;
            }
        }
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| CSV ENCODING
|--------------------------------------------------------------------------
| Supports: UTF-8, UTF-8 BOM, UTF-16 LE, UTF-16 BE
|--------------------------------------------------------------------------
*/

function vaAssessPrepareCsvFile(string $sourceFile): string
{
    $data = file_get_contents($sourceFile);

    if ($data === false) {
        throw new RuntimeException('Unable to read the uploaded CSV file.');
    }

    if (substr($data, 0, 2) === "\xFF\xFE") {

        if (!function_exists('mb_convert_encoding')) {
            throw new RuntimeException('PHP mbstring extension is required for UTF-16 CSV files.');
        }

        $data = mb_convert_encoding($data, 'UTF-8', 'UTF-16LE');

    } elseif (substr($data, 0, 2) === "\xFE\xFF") {

        if (!function_exists('mb_convert_encoding')) {
            throw new RuntimeException('PHP mbstring extension is required for UTF-16 CSV files.');
        }

        $data = mb_convert_encoding($data, 'UTF-8', 'UTF-16BE');

    } elseif (substr($data, 0, 3) === "\xEF\xBB\xBF") {

        $data = substr($data, 3);
    }

    $data = str_replace(["\r\n", "\r"], "\n", $data);
    $data = preg_replace('/^\xEF\xBB\xBF/', '', $data);

    $temporaryFile = tempnam(sys_get_temp_dir(), 'va_folder_csv_');

    if ($temporaryFile === false) {
        throw new RuntimeException('Unable to create temporary CSV file.');
    }

    if (file_put_contents($temporaryFile, $data) === false) {
        @unlink($temporaryFile);
        throw new RuntimeException('Unable to prepare CSV file.');
    }

    return $temporaryFile;
}


/*
|--------------------------------------------------------------------------
| XLSX READING
|--------------------------------------------------------------------------
| No ext-zip, ext-dom, SimpleXML or ext-xml (expat) is available in this
| environment. An .xlsx is a zip of XML parts, and PharData (part of
| ext-phar, which IS available) can read a zip archive without ext-zip --
| confirmed directly rather than assumed, since Phar's zip support isn't
| guaranteed present in every build. What's missing is an XML parser, so
| the two parts that matter (xl/sharedStrings.xml and the first
| worksheet's XML) are read with a small regex-based extractor instead of
| a real one. This is deliberately narrow: it handles the well-known,
| very regular shape Excel and every export tool actually write (shared
| or inline strings, gaps in cell references treated as blank rather than
| shifting later columns, formula cells read from their cached <v>) -- it
| is not a general SpreadsheetML parser. Verified against a hand-built
| multi-part .xlsx with shared strings, a missing cell in the middle of a
| row, a self-closed empty cell, and XML-escaped special characters.
|
| Not handled: numbers Excel displays as dates via cell *formatting*
| (styles.xml) come back as their raw serial-number value, since that
| would require also parsing styles.xml's number formats. Scanner CSV
| exports normally carry dates as plain text, not native Excel date
| cells, so this hasn't been a problem in practice -- flag it if a real
| upload ever shows a date column as a plain number.
|--------------------------------------------------------------------------
*/

function vaAssessXlsxCodepointToUtf8(int $cp): string
{
    if ($cp < 0x80) {
        return chr($cp);
    }
    if ($cp < 0x800) {
        return chr(0xC0 | ($cp >> 6)) . chr(0x80 | ($cp & 0x3F));
    }
    if ($cp < 0x10000) {
        return chr(0xE0 | ($cp >> 12)) . chr(0x80 | (($cp >> 6) & 0x3F)) . chr(0x80 | ($cp & 0x3F));
    }
    return chr(0xF0 | ($cp >> 18)) . chr(0x80 | (($cp >> 12) & 0x3F))
        . chr(0x80 | (($cp >> 6) & 0x3F)) . chr(0x80 | ($cp & 0x3F));
}

function vaAssessXlsxUnescape(string $s): string
{
    $s = preg_replace_callback(
        '/&#x([0-9a-fA-F]+);/',
        static fn($m) => vaAssessXlsxCodepointToUtf8(hexdec($m[1])),
        $s
    );
    $s = preg_replace_callback(
        '/&#(\d+);/',
        static fn($m) => vaAssessXlsxCodepointToUtf8((int) $m[1]),
        $s
    );
    return str_replace(['&lt;', '&gt;', '&quot;', '&apos;', '&amp;'], ['<', '>', '"', "'", '&'], $s);
}

function vaAssessColLetterToIndex(string $letters): int
{
    $letters = strtoupper($letters);
    $idx = 0;
    for ($i = 0, $n = strlen($letters); $i < $n; $i++) {
        $idx = $idx * 26 + (ord($letters[$i]) - 64);
    }
    return $idx - 1; // zero-based
}

/** @return array<int,string> shared string index => text */
function vaAssessParseSharedStrings(string $xml): array
{
    $strings = [];

    if (!preg_match_all('/<si\b[^>]*>(.*?)<\/si>/s', $xml, $siMatches)) {
        return $strings;
    }

    foreach ($siMatches[1] as $siInner) {
        if (preg_match_all('/<t\b[^>]*>(.*?)<\/t>/s', $siInner, $tMatches)) {
            $strings[] = vaAssessXlsxUnescape(implode('', $tMatches[1]));
        } else {
            $strings[] = '';
        }
    }

    return $strings;
}

/**
 * @param array<int,string> $sharedStrings
 * @return array<int,array<int,string>> one array per row, zero-based
 *   column index => cell text; a row's array length matches its own
 *   highest populated column, same shape fgetcsv() would produce.
 */
function vaAssessParseSheetRows(string $xml, array $sharedStrings): array
{
    $rows = [];

    if (!preg_match_all('/<row\b[^>]*>(.*?)<\/row>|<row\b[^>]*\/>/s', $xml, $rowMatches, PREG_SET_ORDER)) {
        return $rows;
    }

    foreach ($rowMatches as $rowMatch) {
        $rowInner = $rowMatch[1] ?? '';
        $rowCells = [];
        $maxCol = -1;

        if ($rowInner !== '' && preg_match_all('/<c\b([^>]*?)(?:\/>|>(.*?)<\/c>)/s', $rowInner, $cellMatches, PREG_SET_ORDER)) {

            foreach ($cellMatches as $cellMatch) {
                $attrs = $cellMatch[1];
                $inner = $cellMatch[2] ?? '';

                if (!preg_match('/r="([A-Z]+)\d+"/', $attrs, $refMatch)) {
                    continue; // malformed cell reference -- skip defensively
                }
                $colIndex = vaAssessColLetterToIndex($refMatch[1]);

                $type = 'n';
                if (preg_match('/\bt="([a-zA-Z]+)"/', $attrs, $typeMatch)) {
                    $type = $typeMatch[1];
                }

                $value = '';

                if ($type === 'inlineStr') {
                    if (
                        preg_match('/<is>(.*?)<\/is>/s', $inner, $isMatch)
                        && preg_match_all('/<t\b[^>]*>(.*?)<\/t>/s', $isMatch[1], $tMatches)
                    ) {
                        $value = vaAssessXlsxUnescape(implode('', $tMatches[1]));
                    }
                } elseif (preg_match('/<v>(.*?)<\/v>/s', $inner, $vMatch)) {
                    $raw = $vMatch[1];
                    $value = $type === 's'
                        ? ($sharedStrings[(int) $raw] ?? '')
                        : vaAssessXlsxUnescape($raw);
                }

                $rowCells[$colIndex] = $value;
                if ($colIndex > $maxCol) {
                    $maxCol = $colIndex;
                }
            }
        }

        $line = [];
        for ($i = 0; $i <= $maxCol; $i++) {
            $line[] = $rowCells[$i] ?? '';
        }
        $rows[] = $line;
    }

    return $rows;
}

/**
 * Reads the first worksheet of an .xlsx file into the same shape a CSV
 * read into memory would have: an array of rows, each an array of cell
 * strings, row 0 being whatever the file's first row contains (the
 * caller treats it as a header the same way it does for a CSV).
 *
 * @return array<int,array<int,string>>
 */
function vaAssessReadXlsxAsRows(string $xlsxPath): array
{
    try {
        $pd = new PharData($xlsxPath);
    } catch (Throwable $e) {
        throw new RuntimeException('This does not look like a valid .xlsx file.');
    }

    $sheetEntry = null;

    foreach (new RecursiveIteratorIterator($pd) as $file) {
        if (preg_match('#/xl/worksheets/sheet1\.xml$#', $file->getPathname())) {
            $sheetEntry = $file->getPathname();
            break;
        }
    }

    if ($sheetEntry === null) {
        $candidates = [];
        foreach (new RecursiveIteratorIterator($pd) as $file) {
            if (preg_match('#/xl/worksheets/sheet(\d+)\.xml$#', $file->getPathname(), $m)) {
                $candidates[(int) $m[1]] = $file->getPathname();
            }
        }
        if ($candidates) {
            ksort($candidates);
            $sheetEntry = reset($candidates);
        }
    }

    if ($sheetEntry === null) {
        throw new RuntimeException('No worksheet found inside this .xlsx file.');
    }

    $sheetXml = file_get_contents($sheetEntry);

    if ($sheetXml === false) {
        throw new RuntimeException('Unable to read the worksheet inside this .xlsx file.');
    }

    $sharedStrings = [];
    $sharedStringsPath = 'phar://' . realpath($xlsxPath) . '/xl/sharedStrings.xml';

    if (is_file($sharedStringsPath)) {
        $sharedStringsXml = file_get_contents($sharedStringsPath);
        if ($sharedStringsXml !== false) {
            $sharedStrings = vaAssessParseSharedStrings($sharedStringsXml);
        }
    }

    return vaAssessParseSheetRows($sheetXml, $sharedStrings);
}


/*
|--------------------------------------------------------------------------
| DERIVED FIELDS: PROJECT (from inventory) AND RHEL TAG
|--------------------------------------------------------------------------
| Neither is stored on the row -- both are recomputed every time a folder
| is read, so a later inventory change or a corrected Family value is
| always reflected rather than frozen at upload time.
|--------------------------------------------------------------------------
*/

/**
 * lower(trim(ip_address)) => project name, built once per request.
 * First inventory row wins if the same IP appears more than once.
 */
function vaAssessBuildIpProjectMap(PDO $pdo): array
{
    $map = [];

    $stmt = $pdo->query("
        SELECT ip_address, project
        FROM inventory
        WHERE ip_address IS NOT NULL AND TRIM(ip_address) <> ''
    ");

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $key = strtolower(trim((string) $row['ip_address']));

        if ($key === '' || isset($map[$key])) {
            continue;
        }

        $map[$key] = trim((string) ($row['project'] ?? ''));
    }

    return $map;
}

function vaAssessLookupProject(array $ipProjectMap, string $ipAddress): string
{
    $key = strtolower(trim($ipAddress));

    if ($key === '') {
        return '';
    }

    return $ipProjectMap[$key] ?? '';
}

/**
 * '' (not Red Hat) | 'RHEL' (Red Hat family) | 'RHEL-Kernel' (Red Hat
 * family AND the plugin name mentions a kernel update).
 */
function vaAssessComputeOsTag(string $family, string $pluginName): string
{
    if (stripos($family, 'red hat') === false) {
        return '';
    }

    return (stripos($pluginName, 'kernel') !== false) ? 'RHEL-Kernel' : 'RHEL';
}


/*
|--------------------------------------------------------------------------
| PIVOT SUMMARY
|--------------------------------------------------------------------------
*/

function vaAssessSeverityCanonicalOrder(): array
{
    return ['Critical', 'High', 'Medium', 'Low', 'Info', 'Unspecified'];
}

function vaAssessNormalizeSeverity(string $raw): string
{
    $raw = trim($raw);

    if ($raw === '') {
        return 'Unspecified';
    }

    return ucfirst(strtolower($raw));
}

/**
 * Groups already-tagged rows (each with 'project', 'os_tag', 'severity'
 * keys) into: Project -> RHEL|RHEL-Kernel -> Severity -> count.
 *
 * Only rows with a non-empty os_tag are included -- the pivot is
 * deliberately RHEL / RHEL-Kernel only, matching the reference report.
 *
 * @return array{severities: array<int,string>, projects: array<string,array<string,array<string,int>>>}
 */
function vaAssessBuildPivot(array $rows): array
{
    $severitiesSeen = [];
    $projects = [];

    foreach ($rows as $row) {
        if ($row['os_tag'] === '') {
            continue;
        }

        $project = $row['project'] !== '' ? $row['project'] : 'Unmatched';
        $osTag = $row['os_tag'];
        $severity = vaAssessNormalizeSeverity((string) $row['severity']);

        $severitiesSeen[$severity] = true;

        if (!isset($projects[$project])) {
            $projects[$project] = ['RHEL' => [], 'RHEL-Kernel' => []];
        }

        if (!isset($projects[$project][$osTag][$severity])) {
            $projects[$project][$osTag][$severity] = 0;
        }

        $projects[$project][$osTag][$severity]++;
    }

    $canonical = vaAssessSeverityCanonicalOrder();
    $orderedSeverities = [];

    foreach ($canonical as $sev) {
        if (isset($severitiesSeen[$sev])) {
            $orderedSeverities[] = $sev;
            unset($severitiesSeen[$sev]);
        }
    }

    $remaining = array_keys($severitiesSeen);
    sort($remaining, SORT_STRING);
    $orderedSeverities = array_merge($orderedSeverities, $remaining);

    uksort($projects, static fn($a, $b) => strcasecmp($a, $b));

    if (isset($projects['Unmatched'])) {
        $unmatched = $projects['Unmatched'];
        unset($projects['Unmatched']);
        $projects['Unmatched'] = $unmatched;
    }

    return [
        'severities' => $orderedSeverities,
        'projects'   => $projects,
    ];
}

/**
 * Sums two Severity => count maps together (used for project totals and
 * the grand total row).
 */
function vaAssessSumSeverityCounts(array $a, array $b): array
{
    $sum = $a;

    foreach ($b as $severity => $count) {
        $sum[$severity] = ($sum[$severity] ?? 0) + $count;
    }

    return $sum;
}


/*
|--------------------------------------------------------------------------
| SPREADSHEETML (multi-sheet .xls) OUTPUT
|--------------------------------------------------------------------------
| No PhpSpreadsheet/ext-zip is available in this environment (see
| config/vulnerability_db.php's own note on the same constraint). Excel's
| XML Spreadsheet format supports multiple worksheets in one plain-text
| XML file, so it needs no extension beyond what PHP ships with. Excel
| opens a ".xls" file with this content directly -- Excel shows one "the
| file format doesn't match the extension" warning to click past.
|--------------------------------------------------------------------------
*/

function vaAssessXmlEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

function vaAssessXmlCell($value, bool $numeric = false, ?string $styleId = null): string
{
    $styleAttr = $styleId !== null ? ' ss:StyleID="' . $styleId . '"' : '';

    if ($numeric) {
        $number = is_numeric($value) ? $value : 0;
        return '<Cell' . $styleAttr . '><Data ss:Type="Number">' . vaAssessXmlEscape($number) . '</Data></Cell>';
    }

    if ($value === '' || $value === null) {
        return '<Cell' . $styleAttr . '/>';
    }

    return '<Cell' . $styleAttr . '><Data ss:Type="String">' . vaAssessXmlEscape($value) . '</Data></Cell>';
}

function vaAssessXmlRow(array $cellsXml): string
{
    return '<Row>' . implode('', $cellsXml) . "</Row>\n";
}
