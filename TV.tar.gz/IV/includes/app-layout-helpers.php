<?php
/**
 * Shared rendering for the Application Layout module, used by both
 * app_layout.php (one application's own board) and project_overview.php
 * (many applications side by side under a project). Written once here
 * rather than copied, so the two pages can never drift into two
 * different-looking cards for the same data.
 */

require_once __DIR__ . '/platform-helpers.php';

/**
 * Loads one layout as a nested tiers -> components -> servers structure.
 */
function alLoadBoard(PDO $pdo, int $layoutId): array
{
    $tiers = $pdo->prepare("SELECT * FROM app_layout_tiers WHERE layout_id = ? ORDER BY tier_order, id");
    $tiers->execute([$layoutId]);
    $tiers = $tiers->fetchAll(PDO::FETCH_ASSOC);

    if (!$tiers) {
        return [];
    }

    $tierIds = array_column($tiers, 'id');
    $ph = implode(',', array_fill(0, count($tierIds), '?'));

    $comps = $pdo->prepare("SELECT * FROM app_layout_components WHERE tier_id IN ($ph) ORDER BY component_order, id");
    $comps->execute($tierIds);
    $comps = $comps->fetchAll(PDO::FETCH_ASSOC);

    $servers = [];
    if ($comps) {
        $compIds = array_column($comps, 'id');
        $ph2 = implode(',', array_fill(0, count($compIds), '?'));
        $s = $pdo->prepare("SELECT * FROM app_layout_servers WHERE component_id IN ($ph2) ORDER BY hostname");
        $s->execute($compIds);
        foreach ($s->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $servers[(int) $row['component_id']][] = $row;
        }
    }

    $byTier = [];
    foreach ($comps as $c) {
        $c['servers'] = $servers[(int) $c['id']] ?? [];
        $byTier[(int) $c['tier_id']][] = $c;
    }

    foreach ($tiers as &$t) {
        $t['components'] = $byTier[(int) $t['id']] ?? [];
    }
    unset($t);

    return alAttachEnvInfo($pdo, $tiers);
}

/**
 * A "server entry" here can be a real hostname (the normal case) or --
 * for a VIP row -- one of that host's `inventory.additional_ips` (a
 * comma-separated list of extra/floating IPs configured on it), typed or
 * picked in place of a hostname. Either way it should still resolve back
 * to the owning inventory record for its environment and primary IP, so
 * this indexes inventory once by every identifier a server entry could
 * plausibly be: hostname, primary IP, and each additional IP.
 *
 * Inventory here is small enough (low hundreds of rows) that loading it
 * whole and indexing in PHP is simpler and fast enough -- matching an
 * arbitrary value against a comma-separated column has no efficient
 * indexed SQL form, so a query-per-lookup approach would need a LIKE scan
 * per server anyway.
 */
function alInventoryIndex(PDO $pdo): array
{
    static $cache = null;
    if ($cache !== null) { return $cache; }

    $index = [];
    $rows = $pdo->query("SELECT hostname, ip_address, additional_ips, support_level FROM inventory")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $r) {
        $h = strtolower(trim((string) $r['hostname']));
        if ($h !== '' && !isset($index[$h])) { $index[$h] = $r; }

        $ip = strtolower(trim((string) $r['ip_address']));
        if ($ip !== '' && !isset($index[$ip])) { $index[$ip] = $r; }

        foreach (explode(',', (string) $r['additional_ips']) as $extra) {
            $extra = strtolower(trim($extra));
            if ($extra !== '' && !isset($index[$extra])) { $index[$extra] = $r; }
        }
    }

    return $cache = $index;
}

/**
 * Every additional/VIP IP recorded in Inventory, for the "+ Add VIP"
 * picker in the editor -- @return array<string,string> ip => owning hostname.
 */
function alAdditionalIpList(PDO $pdo): array
{
    $out = [];
    $rows = $pdo->query("SELECT hostname, additional_ips FROM inventory WHERE additional_ips IS NOT NULL AND TRIM(additional_ips) <> ''")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $r) {
        foreach (explode(',', (string) $r['additional_ips']) as $ip) {
            $ip = trim($ip);
            if ($ip !== '') { $out[$ip] = trim((string) $r['hostname']); }
        }
    }

    ksort($out, SORT_STRING);
    return $out;
}

/**
 * Tags every server in a loaded board with its environment and IP, read
 * live from Inventory (matched by hostname OR IP OR additional IP -- see
 * alInventoryIndex()) rather than anything typed into the layout -- a
 * server moving from Production to DR in Inventory is reflected here
 * immediately, with nothing to keep in sync by hand.
 */
function alAttachEnvInfo(PDO $pdo, array $board): array
{
    $index = alInventoryIndex($pdo);

    foreach ($board as &$t) {
        foreach ($t['components'] as &$c) {
            foreach ($c['servers'] as &$s) {
                $match = $index[strtolower(trim((string) $s['hostname']))] ?? null;
                $level = $match['support_level'] ?? null;
                $s['support_level'] = $level;
                $s['env_bucket']    = alEnvBucket($level);
                $s['env_label']     = alEnvLabel($level);
                $s['ip_address']    = $match['ip_address'] ?? null;
                $s['matched_host']  = $match['hostname'] ?? null;
            }
            unset($s);
        }
        unset($c);
    }
    unset($t);

    return $board;
}

/**
 * A hostname not found in inventory at all ('unknown') is deliberately
 * kept distinct from a real, recognised non-prod/DR value ('other') --
 * the former usually means the host needs onboarding into Inventory, the
 * latter is just a normal Test/SIT/Sandbox server.
 */
function alEnvBucket(?string $level): string
{
    $l = strtolower(trim((string) $level));
    if ($l === '') { return 'unknown'; }
    if ($l === 'production' || $l === 'prod') { return 'production'; }
    if ($l === 'dr') { return 'dr'; }
    return 'other';
}

function alEnvLabel(?string $level): string
{
    $l = trim((string) $level);
    if ($l === '') { return 'Not in Inventory'; }

    $known = [
        'production' => 'Production', 'dr' => 'DR', 'pre-prod' => 'Pre-Prod', 'preprod' => 'Pre-Prod',
        'sit' => 'SIT', 'test' => 'Test', 'development' => 'Development', 'dev' => 'Development',
        'sandbox' => 'Sandbox', 'poc' => 'POC',
    ];
    return $known[strtolower($l)] ?? ucwords($l);
}

/**
 * For a VIP row whose "hostname" is actually one of a real host's
 * additional IPs (see alInventoryIndex()), the owning host's name --
 * empty when the entry resolved directly by its own hostname, so nothing
 * extra is shown for the normal case.
 */
function alOwnerCaption(array $server): string
{
    $owner   = trim((string) ($server['matched_host'] ?? ''));
    $entered = trim((string) ($server['hostname'] ?? ''));
    if ($owner === '' || strcasecmp($owner, $entered) === 0) { return ''; }
    return $owner;
}

/**
 * Groups a component's servers by their SPECIFIC environment label (e.g.
 * "Test", "SIT", "Pre-Prod"), not by the coarse Production/DR/other/unknown
 * bucket -- a host tagged 'test' in Inventory must read as "Test" here, not
 * a generic "Other" that throws away exactly the information this feature
 * exists to surface. The bucket is kept per group only to drive sort order
 * and colour, never as display text.
 *
 * Production first, then DR, then every other real value alphabetically,
 * then "Not in Inventory" last -- the order the eye should scan a prod/DR
 * pair in, with "needs onboarding" pushed to the end.
 *
 * @return array<int,array{bucket:string,label:string,servers:array}>
 */
function alGroupServersByEnv(array $servers): array
{
    $groups = [];
    foreach ($servers as $s) {
        $label = $s['env_label'] ?: 'Not in Inventory';
        if (!isset($groups[$label])) {
            $groups[$label] = ['bucket' => $s['env_bucket'] ?? 'unknown', 'label' => $label, 'servers' => []];
        }
        $groups[$label]['servers'][] = $s;
    }

    $rank = ['production' => 0, 'dr' => 1, 'other' => 2, 'unknown' => 3];
    uasort($groups, function ($a, $b) use ($rank) {
        $ra = $rank[$a['bucket']] ?? 2;
        $rb = $rank[$b['bucket']] ?? 2;
        return $ra !== $rb ? $ra <=> $rb : strcasecmp($a['label'], $b['label']);
    });

    return array_values($groups);
}

/**
 * Every application in a project, with its board and DR rows preloaded --
 * one batch of queries rather than N+1 per card, for project_overview.php.
 *
 * @return array<int,array{layout:array,board:array,dr:array}>
 */
function alLoadProjectCards(PDO $pdo, string $project, bool $includeDr): array
{
    $s = $pdo->prepare("SELECT * FROM app_layouts WHERE project = ? ORDER BY app_name");
    $s->execute([$project]);
    $layouts = $s->fetchAll(PDO::FETCH_ASSOC);

    $out = [];
    foreach ($layouts as $layout) {
        $drRows = [];
        if ($includeDr) {
            $d = $pdo->prepare("
                SELECT * FROM dr_mappings
                WHERE LOWER(TRIM(application)) = LOWER(TRIM(?))
                ORDER BY component_type, id
            ");
            $d->execute([$layout['app_name']]);
            $drRows = $d->fetchAll(PDO::FETCH_ASSOC);
        }

        $out[] = [
            'layout' => $layout,
            'board'  => alLoadBoard($pdo, (int) $layout['id']),
            'dr'     => $drRows,
        ];
    }

    return $out;
}

/*
 * Small, purely-cosmetic lookups so the board reads like an architecture
 * diagram rather than a data table: a consistent colour and icon per
 * tier/component/deployment kind, plus a stable fallback for whatever
 * free-text name a tier was given (tiers are free text on purpose).
 */
function alTierTone(string $tierName): string
{
    $tones = [
        'load balancer' => 'purple', 'web' => 'blue', 'application' => 'indigo',
        'middleware' => 'teal', 'cache' => 'amber', 'database' => 'green',
        'storage' => 'slate', 'integration' => 'pink', 'batch' => 'gray',
    ];
    $key = strtolower(trim($tierName));
    if (isset($tones[$key])) { return $tones[$key]; }

    $palette = ['blue', 'indigo', 'teal', 'purple', 'amber', 'green', 'pink', 'slate'];
    return $palette[crc32($key) % count($palette)];
}

function alTierIcon(string $tierName): string
{
    $icons = [
        'load balancer' => '⇆', 'web' => '◧', 'application' => '▣',
        'middleware' => '⛓', 'cache' => '⚡', 'database' => '⛁',
        'storage' => '▤', 'integration' => '⇄', 'batch' => '⏱',
    ];
    return $icons[strtolower(trim($tierName))] ?? '▢';
}

function alCompIcon(?string $compType): string
{
    $icons = [
        'Web Server' => '◧', 'App Server' => '▣', 'Database' => '⛁', 'Cache' => '⚡',
        'Queue' => '☰', 'Load Balancer' => '⇆', 'API Gateway' => '◈', 'Batch Job' => '⏱', 'Storage' => '▤',
    ];
    return $icons[trim((string) $compType)] ?? '●';
}

function alDeploymentTone(?string $deploymentType): string
{
    $d = strtolower(trim((string) $deploymentType));
    if ($d === '') { return 'neutral'; }
    if (str_contains($d, 'cluster')) { return 'ok'; }
    if (str_contains($d, 'standalone')) { return 'neutral'; }
    return 'neutral';
}

function alDeploymentIcon(?string $deploymentType): string
{
    $d = strtolower(trim((string) $deploymentType));
    if (str_contains($d, 'cluster')) { return '◎'; }
    if (str_contains($d, 'standalone')) { return '▭'; }
    return '▢';
}

/**
 * Renders one application as a self-contained architecture card: a
 * load-balancer-style top box (the first tier, if any) fanning out to
 * every component in the tiers below it, deployment/location facts, and
 * -- inside this same card, not a separate section -- a DR panel when
 * dr_mapping.php has data for this application.
 *
 * $board is alLoadBoard()'s result; $drRows is already permission- and
 * application-filtered by the caller (this function does no access
 * control of its own, matching how the rest of this module's rendering
 * works -- callers decide what a viewer is allowed to see).
 */
function alAppCard(array $layout, array $board, array $drRows, bool $compact = false, ?int $badgeNumber = null): string
{
    $cls = 'al-appcard' . ($compact ? ' al-appcard-compact' : '');

    $html = '<div class="' . $cls . '">';

    // ---- head ----
    $html .= '<div class="al-appcard-head">';
    if ($badgeNumber !== null) {
        $html .= '<span class="al-appcard-badge">' . (int) $badgeNumber . '</span>';
    }
    $html .= '<div class="al-appcard-title">';
    $html .= '<h4>' . plat_h($layout['app_name']) . '</h4>';
    $html .= '<div class="al-appcard-meta">';
    $html .= 'Owner: <b>' . plat_h($layout['technical_owner'] ?: '—') . '</b>';
    $html .= ' &middot; Project: <b>' . plat_h($layout['project'] ?: '—') . '</b>';
    $html .= '</div></div></div>';

    // ---- deployment badge ----
    $deployType = trim((string) ($layout['deployment_type'] ?? ''));
    if ($deployType !== '') {
        $detail = trim((string) ($layout['deployment_detail'] ?? ''));
        $html .= '<div class="al-deploy-badge tone-' . alDeploymentTone($deployType) . '">'
               . '<span aria-hidden="true">' . alDeploymentIcon($deployType) . '</span> '
               . plat_h($deployType) . ($detail !== '' ? ' <small>(' . plat_h($detail) . ')</small>' : '')
               . '</div>';
    }

    // ---- flow diagram ----
    // Every tier is its own stage, rendered in tier_order with a connector
    // between each pair -- Web -> App -> DB reads as a real left-to-right
    // (well, top-to-bottom) chain, and re-ordering tiers in the editor
    // (the up/down arrows on each tier) changes this chain directly, so an
    // application whose DB sits in front of its App tier draws that way.
    if (!$board) {
        $html .= '<p class="plat-empty" style="margin:10px 0;">No tiers yet.</p>';
    } else {
        $html .= '<div class="al-flow">';

        foreach ($board as $i => $tier) {
            if ($i > 0) {
                $html .= '<div class="al-connector" aria-hidden="true"></div>';
            }

            // The first tier is the entry point (typically a load balancer
            // or web tier) and keeps the flat-pill "top box" look; every
            // later tier renders as a labelled stage of component boxes.
            if ($i === 0) {
                $html .= '<div class="al-top-box al-tone-' . alTierTone($tier['tier_name']) . '">';
                $html .= '<div class="al-top-box-label"><span aria-hidden="true">' . alTierIcon($tier['tier_name']) . '</span> ' . plat_h($tier['tier_name']) . '</div>';

                if (!$tier['components']) {
                    $html .= '<div class="al-no-servers">No components</div>';
                } else {
                    $topServers = [];
                    foreach ($tier['components'] as $c) {
                        foreach ($c['servers'] as $s) { $topServers[] = $s; }
                    }

                    if (!$topServers) {
                        $html .= '<div class="al-no-servers">No servers assigned</div>';
                    } else {
                        $html .= '<div class="al-top-servers">';
                        foreach ($topServers as $s) {
                            $owner = alOwnerCaption($s);
                            $html .= '<span class="al-server-pill al-env-' . ($s['env_bucket'] ?? 'unknown') . '">';
                            $html .= '<b>' . plat_h($s['hostname']) . '</b>';
                            if ($owner !== '') { $html .= '<span class="al-pill-owner">on ' . plat_h($owner) . '</span>'; }
                            if (!empty($s['ip_address'])) {
                                $html .= '<span class="al-pill-ip">' . plat_h($s['ip_address']) . '</span>';
                            }
                            $html .= '<span class="al-pill-tags">';
                            if ($s['server_role']) { $html .= '<em>' . plat_h($s['server_role']) . '</em>'; }
                            $html .= '<small>' . plat_h($s['env_label'] ?? '') . '</small>';
                            $html .= '</span></span>';
                        }
                        $html .= '</div>';
                    }
                }
                $html .= '</div>';
                continue;
            }

            $html .= '<div class="al-stage">';
            $html .= '<div class="al-stage-label al-tone-' . alTierTone($tier['tier_name']) . '"><span aria-hidden="true">' . alTierIcon($tier['tier_name']) . '</span> ' . plat_h($tier['tier_name']) . '</div>';

            if (!$tier['components']) {
                $html .= '<div class="al-no-servers">No components</div>';
            } else {
                $html .= '<div class="al-fanout">';
                foreach ($tier['components'] as $c) {
                    $html .= '<div class="al-comp-box al-tone-' . alTierTone($tier['tier_name']) . '">';
                    $html .= '<div class="al-comp-box-label"><span aria-hidden="true">' . alCompIcon($c['component_type']) . '</span> ' . plat_h($c['component_name']) . '</div>';

                    if (!$c['servers']) {
                        $html .= '<div class="al-no-servers">No servers</div>';
                    } else {
                        // Grouped by the SPECIFIC live inventory environment
                        // (e.g. "Test", "SIT", not a generic "Other"), Production
                        // and DR first -- this is the "prod vs DR" design the
                        // card exists to show.
                        $html .= '<div class="al-comp-servers">';
                        $perGroupCap = $compact ? 2 : 3;
                        foreach (alGroupServersByEnv($c['servers']) as $group) {
                            $shown = array_slice($group['servers'], 0, $perGroupCap);
                            $extra = count($group['servers']) - count($shown);

                            $html .= '<div class="al-env-row al-env-' . $group['bucket'] . '">';
                            $html .= '<span class="al-env-tag">' . plat_h($group['label']) . '</span>';
                            $html .= '<div class="al-env-hosts">';
                            foreach ($shown as $s) {
                                $owner = alOwnerCaption($s);
                                $html .= '<div class="al-env-host">';
                                $html .= '<span class="al-env-host-name">' . plat_h($s['hostname']) . '</span>';
                                if ($owner !== '') { $html .= '<span class="al-env-host-owner">on ' . plat_h($owner) . '</span>'; }
                                if (!empty($s['ip_address'])) {
                                    $html .= '<span class="al-env-host-ip">' . plat_h($s['ip_address']) . '</span>';
                                }
                                if (!empty($s['server_role'])) {
                                    $html .= '<span class="al-env-host-role">' . plat_h($s['server_role']) . '</span>';
                                }
                                $html .= '</div>';
                            }
                            if ($extra > 0) { $html .= '<span class="al-comp-more">+' . $extra . ' more</span>'; }
                            $html .= '</div></div>';
                        }
                        $html .= '</div>';
                    }
                    $html .= '</div>';
                }
                $html .= '</div>';
            }
            $html .= '</div>'; // .al-stage
        }

        $html .= '</div>'; // .al-flow
    }

    // ---- deployment / location facts ----
    $location = trim((string) ($layout['location'] ?? ''));
    if ($deployType !== '' || $location !== '') {
        $html .= '<div class="al-info-row">';
        if ($deployType !== '') {
            $html .= '<div><label>Deployment</label><span>' . plat_h($deployType) . '</span></div>';
        }
        if ($location !== '') {
            $html .= '<div><label>Location</label><span>' . plat_h($location) . '</span></div>';
        }
        $html .= '</div>';
    }

    // ---- DR, inside this same card ----
    if ($drRows) {
        $html .= '<div class="al-dr-box">';
        $html .= '<div class="al-dr-box-head"><span aria-hidden="true">🛡</span> DR Site<small>(Optional)</small></div>';
        foreach ($drRows as $d) {
            $tone = match ((string) $d['replication_status']) {
                'In Sync' => 'ok', 'Broken' => 'crit', 'Lagging' => 'warn', default => 'neutral',
            };
            $html .= '<div class="al-dr-row">';
            $html .= '<div class="al-dr-row-main">';
            $html .= '<span class="al-server-pill">' . plat_h($d['dr_hostname'] ?: '—') . '<small>' . plat_h($d['dr_site'] ?: 'DR site') . '</small></span>';
            if ($d['failover_type']) {
                $html .= '<span class="al-dr-failover">Failover: ' . plat_h($d['failover_type']) . '</span>';
            }
            $html .= '</div>';
            $html .= '<div class="al-dr-row-meta">';
            if ($d['component_type']) { $html .= '<span>' . plat_h($d['component_type']) . '</span>'; }
            if ($d['replication_status']) { $html .= '<span class="plat-pill ' . $tone . '">' . plat_h($d['replication_status']) . '</span>'; }
            $html .= '</div>';
            $html .= '</div>';
        }
        $html .= '</div>';
    }

    $html .= '</div>'; // .al-appcard

    return $html;
}
