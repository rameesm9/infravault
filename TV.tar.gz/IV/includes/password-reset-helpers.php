<?php
/**
 * Self-service password reset: generation, throttling and delivery.
 *
 * Split out of forgot-password.php so the page itself is only a form and a
 * decision, and so the "did this actually work" logic has one home. Backed by
 * config/schema/password_reset.php.
 */

require_once __DIR__ . '/mail-helpers.php';
require_once __DIR__ . '/security-helpers.php';
require_once __DIR__ . '/branding-helpers.php';

/** Settings -> Mail toggle this feature answers to. */
const PASSWORD_RESET_MAIL_MODULE = 'password_reset';

/**
 * Throttle window and ceilings.
 *
 * Two limits, for the same reason the login lockout keys on identifier AND
 * IP: capping per-identifier alone lets one host walk a list of NCGR IDs and
 * mail every user in the directory, and capping per-IP alone lets a
 * distributed source keep hammering one account's inbox.
 */
const PASSWORD_RESET_WINDOW_SECONDS   = 900;  // 15 minutes
const PASSWORD_RESET_MAX_PER_ACCOUNT  = 3;
const PASSWORD_RESET_MAX_PER_IP       = 8;

/** How long a request row is kept before housekeeping drops it. */
const PASSWORD_RESET_RETENTION_SECONDS = 604800; // 7 days


/**
 * A temporary password that satisfies the configured policy.
 *
 * Deliberately stricter than the policy: one character from each of the four
 * classes is always included, whatever Settings -> Security asks for. Nothing
 * in validatePasswordPolicy() forbids a class, so over-satisfying it can never
 * fail, and this password has to survive being read out of an email.
 *
 * Visually ambiguous characters (I, l, 1, O, 0) are left out for the same
 * reason -- it is going to be retyped by hand at least once.
 */
function generateTemporaryPassword(PDO $pdo): string
{
    $policy = getSecuritySettings($pdo);

    $upper  = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    $lower  = 'abcdefghijkmnopqrstuvwxyz';
    $digits = '23456789';
    $symbols = '!@#$%^&*?-_=+';

    // 14 floor rather than the policy minimum: a mailed password is exposed
    // for as long as it sits in an inbox, so it should not be the shortest
    // thing the policy would accept.
    $length = max(14, (int) $policy['password_min_length']);

    $chars = [
        $upper[random_int(0, strlen($upper) - 1)],
        $lower[random_int(0, strlen($lower) - 1)],
        $digits[random_int(0, strlen($digits) - 1)],
        $symbols[random_int(0, strlen($symbols) - 1)],
    ];

    $pool = $upper . $lower . $digits . $symbols;

    while (count($chars) < $length) {
        $chars[] = $pool[random_int(0, strlen($pool) - 1)];
    }

    // Fisher-Yates with random_int, not shuffle(): shuffle() uses the
    // non-cryptographic Mt19937 generator, and without this the first four
    // positions would always be upper/lower/digit/symbol in that order.
    for ($i = count($chars) - 1; $i > 0; $i--) {
        $j = random_int(0, $i);
        $swap = $chars[$i];
        $chars[$i] = $chars[$j];
        $chars[$j] = $swap;
    }

    return implode('', $chars);
}


/**
 * Records an attempt. Called on every path through the page, including the
 * ones that do nothing, so the table shows what was tried and not just what
 * succeeded.
 *
 * $outcome is one of: sent, no_match, not_approved, ldap_account,
 * mail_failed, rate_limited.
 */
function recordPasswordResetRequest(PDO $pdo, string $identifier, string $outcome, string $detail = ''): void
{
    try {
        $pdo->prepare("
            INSERT INTO password_reset_requests
                (identifier, ip_address, outcome, detail, requested_at, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ")->execute([
            strtolower(trim($identifier)),
            clientIpAddress(),
            $outcome,
            substr($detail, 0, 500),
            time(),
            substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        ]);
    } catch (Throwable $e) {
        error_log('Unable to record password reset request: ' . $e->getMessage());
    }
}


/**
 * True when this identifier or this client address has already used up its
 * allowance for the current window.
 *
 * Counts every recorded attempt, not just successful ones -- otherwise
 * guessing NCGR IDs that do not exist would be free and unlimited.
 *
 * @return bool
 */
function passwordResetIsRateLimited(PDO $pdo, string $identifier): bool
{
    $since = time() - PASSWORD_RESET_WINDOW_SECONDS;

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM password_reset_requests
            WHERE requested_at >= ? AND identifier = ?
        ");
        $stmt->execute([$since, strtolower(trim($identifier))]);

        if ((int) $stmt->fetchColumn() >= PASSWORD_RESET_MAX_PER_ACCOUNT) {
            return true;
        }

        $stmt = $pdo->prepare("
            SELECT COUNT(*) FROM password_reset_requests
            WHERE requested_at >= ? AND ip_address = ?
        ");
        $stmt->execute([$since, clientIpAddress()]);

        return (int) $stmt->fetchColumn() >= PASSWORD_RESET_MAX_PER_IP;

    } catch (Throwable $e) {
        // Fail open rather than refusing every reset in a working system
        // because of a query error. The failure is logged for follow-up.
        error_log('Unable to evaluate password reset rate limit: ' . $e->getMessage());
        return false;
    }
}


/**
 * Housekeeping, called opportunistically from the reset page so the table
 * cannot grow without bound in a deployment that has no cron -- the same
 * arrangement pruneLoginAttempts() has on the login page.
 */
function prunePasswordResetRequests(PDO $pdo): void
{
    try {
        $pdo->prepare("DELETE FROM password_reset_requests WHERE requested_at < ?")
            ->execute([time() - PASSWORD_RESET_RETENTION_SECONDS]);
    } catch (Throwable $e) {
        error_log('Unable to prune password_reset_requests: ' . $e->getMessage());
    }
}


/**
 * Issues a temporary password to $user and mails it.
 *
 * Order matters: the mail is sent BEFORE the new hash is written. If SMTP is
 * unreachable or the module is switched off in Settings, the account keeps the
 * password it had. Writing first and mailing second would lock the user out of
 * their own account with no way back in, which is a worse failure than the
 * reset simply not happening.
 *
 * @param array $user A users row (needs id, first_name, email).
 * @return array{success: bool, message: string}
 */
function issueTemporaryPassword(PDO $pdo, array $user): array
{
    $tempPassword = generateTemporaryPassword($pdo);
    $appName = getAppName($pdo);

    $name = trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));

    $result = sendAppMail(
        $pdo,
        PASSWORD_RESET_MAIL_MODULE,
        (string) $user['email'],
        $name,
        $appName . ' temporary password',
        passwordResetEmailHtml($user, $tempPassword, $appName),
        passwordResetEmailText($user, $tempPassword, $appName)
    );

    if (!$result['success']) {
        return $result;
    }

    try {
        $pdo->prepare("
            UPDATE users
            SET password = ?, must_change_password = 1
            WHERE id = ?
        ")->execute([
            password_hash($tempPassword, PASSWORD_DEFAULT),
            $user['id'],
        ]);
    } catch (Throwable $e) {
        error_log('Password reset: mail sent but hash could not be stored: ' . $e->getMessage());
        return ['success' => false, 'message' => 'Unable to store the new password: ' . $e->getMessage()];
    }

    /*
     * Clear the failure history for this identifier. Someone who has forgotten
     * their password has usually just spent several attempts proving it, and
     * arriving at the login page already one attempt from a lockout -- holding
     * a password that only works once -- is a dead end.
     */
    try {
        $pdo->prepare("DELETE FROM login_attempts WHERE identifier = ? AND success = 0")
            ->execute([strtolower(trim((string) $user['ncgr_id']))]);
    } catch (Throwable $e) {
        error_log('Unable to clear login attempts after password reset: ' . $e->getMessage());
    }

    return ['success' => true, 'message' => 'Sent'];
}


function passwordResetEmailHtml(array $user, string $tempPassword, string $appName = BRANDING_DEFAULT_APP_NAME): string
{
    $first = htmlspecialchars((string) ($user['first_name'] ?? ''), ENT_QUOTES, 'UTF-8');
    $id    = htmlspecialchars((string) ($user['ncgr_id'] ?? ''), ENT_QUOTES, 'UTF-8');
    $pw    = htmlspecialchars($tempPassword, ENT_QUOTES, 'UTF-8');
    $app   = htmlspecialchars($appName, ENT_QUOTES, 'UTF-8');

    return
        '<p>Hello ' . $first . ',</p>'
        . '<p>A password reset was requested for your ' . $app . ' account. '
        . 'Sign in with the temporary password below &mdash; you will be asked to set a new one straight away.</p>'
        . '<p><strong>NCGR ID:</strong> ' . $id . '<br>'
        . '<strong>Temporary password:</strong> '
        . '<code style="font-family:Consolas,Menlo,monospace;font-size:15px;background:#f1f5f9;'
        . 'padding:4px 8px;border-radius:6px;letter-spacing:.5px;">' . $pw . '</code></p>'
        . '<p>This temporary password replaces your previous one, so your old password will no longer work. '
        . 'It can only be used to sign in and set a new password.</p>'
        . '<p><strong>If you did not request this,</strong> contact your ' . $app . ' administrator now &mdash; '
        . 'someone else has reset your account password.</p>'
        . '<p style="color:#64748b;font-size:12px;">Sent by ' . $app . '. Please do not reply to this message.</p>';
}


function passwordResetEmailText(array $user, string $tempPassword, string $appName = BRANDING_DEFAULT_APP_NAME): string
{
    return
        'Hello ' . (string) ($user['first_name'] ?? '') . ",\r\n\r\n"
        . "A password reset was requested for your {$appName} account. Sign in with the\r\n"
        . "temporary password below - you will be asked to set a new one straight away.\r\n\r\n"
        . '  NCGR ID:            ' . (string) ($user['ncgr_id'] ?? '') . "\r\n"
        . '  Temporary password: ' . $tempPassword . "\r\n\r\n"
        . "This temporary password replaces your previous one, so your old password will\r\n"
        . "no longer work. It can only be used to sign in and set a new password.\r\n\r\n"
        . "If you did not request this, contact your {$appName} administrator now -\r\n"
        . "someone else has reset your account password.\r\n\r\n"
        . "Sent by {$appName}. Please do not reply to this message.\r\n";
}
