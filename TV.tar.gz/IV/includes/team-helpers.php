<?php
/**
 * Team registry helpers.
 *
 * Required from config/db.php so every page (including signup.php, which
 * includes nothing else) can render a team dropdown from one source
 * instead of its own hardcoded copy of the list.
 *
 * See config/schema/teams.php for why the registry exists.
 */

/**
 * Valid team names, alphabetically.
 *
 * @return string[]
 */
function getTeamNames(PDO $pdo): array
{
    try {
        return $pdo->query("
            SELECT team_name
            FROM teams
            ORDER BY team_name COLLATE NOCASE ASC
        ")->fetchAll(PDO::FETCH_COLUMN);

    } catch (Throwable $e) {
        error_log('Unable to load team names: ' . $e->getMessage());
        return [];
    }
}

/**
 * Teams with how many users are assigned to each.
 *
 * The count is what makes deletion safe to reason about on screen: a
 * team with members cannot be deleted, and the admin needs to see that
 * before clicking rather than after.
 *
 * Matching is TRIM'd and case-insensitive on both sides because
 * users.team holds a free-text name that predates this registry.
 *
 * @return array<int, array{id:int, team_name:string, description:?string,
 *                          created_by:?string, created_at:?string,
 *                          member_count:int}>
 */
function getTeamsWithMemberCounts(PDO $pdo): array
{
    try {
        return $pdo->query("
            SELECT
                t.id,
                t.team_name,
                t.team_email,
                t.description,
                t.created_by,
                t.created_at,
                (
                    SELECT COUNT(*)
                    FROM users u
                    WHERE TRIM(u.team) = t.team_name COLLATE NOCASE
                ) AS member_count
            FROM teams t
            ORDER BY t.team_name COLLATE NOCASE ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        error_log('Unable to load teams with member counts: ' . $e->getMessage());
        return [];
    }
}

/**
 * How many users are assigned to a given team name.
 */
function countTeamMembers(PDO $pdo, string $team_name): int
{
    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM users
            WHERE TRIM(team) = ? COLLATE NOCASE
        ");
        $stmt->execute([trim($team_name)]);
        return (int) $stmt->fetchColumn();

    } catch (Throwable $e) {
        error_log('Unable to count team members: ' . $e->getMessage());
        return 0;
    }
}

/**
 * The shared mailbox for one team, set in Manage Teams (users.php). Used
 * to route "team"-visibility reminders/notes -- see
 * includes/reminder-mail.php.
 *
 * Matching is TRIM'd and case-insensitive for the same reason
 * countTeamMembers() is: the caller usually has a name off
 * reminder_teams.team_name / users.team, not the registry's own casing.
 *
 * @return string|null null when the team has no email set (or doesn't exist)
 */
function getTeamEmail(PDO $pdo, string $team_name): ?string
{
    try {
        $stmt = $pdo->prepare("
            SELECT team_email
            FROM teams
            WHERE TRIM(team_name) = ? COLLATE NOCASE
        ");
        $stmt->execute([trim($team_name)]);
        $email = $stmt->fetchColumn();

        return ($email !== false && trim((string) $email) !== '') ? trim((string) $email) : null;

    } catch (Throwable $e) {
        error_log('Unable to load team email: ' . $e->getMessage());
        return null;
    }
}

/**
 * Every team's mailbox that has one set, as team_name => team_email.
 * Used to broadcast "public" visibility to all teams -- see
 * includes/reminder-mail.php.
 *
 * @return array<string,string>
 */
function getAllTeamEmails(PDO $pdo): array
{
    try {
        $rows = $pdo->query("
            SELECT team_name, team_email
            FROM teams
            WHERE team_email IS NOT NULL AND TRIM(team_email) != ''
            ORDER BY team_name COLLATE NOCASE ASC
        ")->fetchAll(PDO::FETCH_ASSOC);

        $emails = [];
        foreach ($rows as $row) {
            $emails[$row['team_name']] = trim($row['team_email']);
        }

        return $emails;

    } catch (Throwable $e) {
        error_log('Unable to load team emails: ' . $e->getMessage());
        return [];
    }
}
