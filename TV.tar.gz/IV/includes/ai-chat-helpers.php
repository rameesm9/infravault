<?php

/*
| Talks to the offline LLM sidecar (the "llm" service in compose.yaml,
| running Ollama) over the internal container network -- never over the
| public internet, so this keeps working with no outbound access at all.
*/

/**
 * Sends one chat turn to the local LLM and returns its reply text, or
 * null if the LLM sidecar could not be reached or returned something
 * unexpected.
 *
 * $history is the prior turns as [['role' => 'user'|'assistant', 'content' => string], ...],
 * oldest first -- the caller (ai_chat.php) round-trips this from the
 * browser rather than this app persisting a conversation anywhere.
 */
function aiChatSend(array $history, string $message): ?string
{
    $url   = rtrim(getenv('APP_LLM_URL') ?: 'http://llm:11434', '/') . '/api/chat';
    $model = getenv('APP_LLM_MODEL') ?: 'llama3.2:3b';

    $messages = [];

    foreach ($history as $turn) {
        $role    = ($turn['role'] ?? '') === 'assistant' ? 'assistant' : 'user';
        $content = trim((string) ($turn['content'] ?? ''));

        if ($content !== '') {
            $messages[] = ['role' => $role, 'content' => $content];
        }
    }

    $messages[] = ['role' => 'user', 'content' => $message];

    // Bound the payload to the last few turns -- a short support chat never
    // needs the full history, and an unbounded one would grow every
    // request's payload (and the model's context window) without limit.
    $messages = array_slice($messages, -20);

    $payload = json_encode([
        'model'    => $model,
        'stream'   => false,
        'messages' => $messages,
    ]);

    $ch = curl_init($url);

    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => $payload,
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        // Local model inference on CPU can be slow; generous but bounded
        // so a stuck request doesn't hold the PHP worker forever.
        CURLOPT_TIMEOUT        => 90,
    ]);

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $curlErr  = curl_error($ch);

    curl_close($ch);

    if ($response === false || $httpCode !== 200) {
        error_log('AI chat request failed (HTTP ' . $httpCode . '): ' . $curlErr);
        return null;
    }

    $decoded = json_decode($response, true);
    $content = $decoded['message']['content'] ?? null;

    return (is_string($content) && $content !== '') ? $content : null;
}
