<?php

require_once __DIR__ . '/config/db.php';

header('Content-Type: application/json');

if (!authzIsLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not logged in.']);
    exit;
}

csrfVerifyOrDie();

$item_key = trim((string) ($_POST['item_key'] ?? ''));

if ($item_key === '') {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Missing item.']);
    exit;
}

$stmt = $pdo->prepare("
    INSERT OR IGNORE INTO notification_reads (user_id, item_key)
    VALUES (?, ?)
");
$stmt->execute([(int) ($_SESSION['user_id'] ?? 0), $item_key]);

echo json_encode(['success' => true]);
