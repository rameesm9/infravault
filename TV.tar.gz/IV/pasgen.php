<?php

session_start();

/*
| Authorization. This page had no login check and no permission check --
| it went straight from session_start() to including the layout, so it
| rendered for anonymous visitors exactly as home.php did.
|
| config/db.php is required explicitly (rather than arriving via
| header.php) so the guards run before any output.
*/
require_once __DIR__ . '/config/db.php';

requireLogin();
requirePermission('pasgen', 'can_view');

$page_title = "Password Generator | InfraVault";

include "includes/header.php";
include "includes/sidebar.php";

?>

<main class="content">

    <div class="dashboard-header">

        <div>
            <h1>
                Password Generator 🔐
            </h1>

            <p>
                Generate secure passwords with customizable complexity
            </p>
        </div>

    </div>


    <div class="password-generator-layout">


        <!-- SETTINGS PANEL -->

        <div class="dashboard-panel password-settings">

            <div class="panel-header">

                <div>
                    <h3>Password Settings</h3>

                    <span>
                        Configure your password complexity
                    </span>
                </div>

            </div>


            <!-- PASSWORD LENGTH -->

            <div class="form-group">

                <label for="passwordLength">
                    Password Length
                </label>

                <div class="length-controls">

                    <input
                        type="range"
                        id="passwordLengthRange"
                        min="4"
                        max="64"
                        value="16"
                    >

                    <input
                        type="number"
                        id="passwordLength"
                        min="4"
                        max="64"
                        value="16"
                    >

                </div>

            </div>


            <!-- MAX LENGTH -->

            <div class="form-group">

                <label for="maxLength">
                    Maximum Length
                </label>

                <input
                    type="number"
                    id="maxLength"
                    min="4"
                    max="128"
                    value="64"
                >

                <small>
                    The password length cannot exceed this value.
                </small>

            </div>


            <!-- COMPLEXITY -->

            <div class="complexity-section">

                <h4>
                    Character Requirements
                </h4>


                <label class="checkbox-row">

                    <input
                        type="checkbox"
                        id="includeUppercase"
                        checked
                    >

                    <span>
                        Uppercase letters
                    </span>

                    <small>
                        A-Z
                    </small>

                </label>


                <label class="checkbox-row">

                    <input
                        type="checkbox"
                        id="includeLowercase"
                        checked
                    >

                    <span>
                        Lowercase letters
                    </span>

                    <small>
                        a-z
                    </small>

                </label>


                <label class="checkbox-row">

                    <input
                        type="checkbox"
                        id="includeNumbers"
                        checked
                    >

                    <span>
                        Numbers
                    </span>

                    <small>
                        0-9
                    </small>

                </label>


                <label class="checkbox-row">

                    <input
                        type="checkbox"
                        id="includeSpecial"
                        checked
                    >

                    <span>
                        Special characters
                    </span>

                    <small>
                        !@#$%
                    </small>

                </label>

            </div>


            <!-- GENERATE -->

            <button
                type="button"
                class="generate-btn"
                id="generatePassword"
            >
                🔐 Generate Password
            </button>

        </div>


        <!-- RESULT PANEL -->

        <div class="dashboard-panel password-result-panel">

            <div class="panel-header">

                <div>
                    <h3>Generated Password</h3>

                    <span>
                        Your secure password
                    </span>
                </div>

            </div>


            <div class="password-display">

                <input
                    type="text"
                    id="generatedPassword"
                    value=""
                    readonly
                    autocomplete="off"
                >

                <button
                    type="button"
                    id="copyPassword"
                    class="copy-btn"
                    title="Copy password"
                >
                    📋
                </button>

            </div>


            <!-- STRENGTH -->

            <div class="strength-container">

                <div class="strength-header">

                    <span>
                        Password Strength
                    </span>

                    <strong id="strengthText">
                        Strong
                    </strong>

                </div>


                <div class="strength-bar">

                    <div
                        id="strengthBar"
                        class="strength-progress strong"
                        style="width: 100%;"
                    ></div>

                </div>

            </div>


            <!-- REQUIREMENTS -->

            <div class="requirements">

                <h4>
                    Requirements
                </h4>


                <div
                    id="requirementLength"
                    class="requirement-item"
                >
                    <span>✓</span>
                    Password length
                </div>


                <div
                    id="requirementUppercase"
                    class="requirement-item"
                >
                    <span>✓</span>
                    At least 1 uppercase character
                </div>


                <div
                    id="requirementNumber"
                    class="requirement-item"
                >
                    <span>✓</span>
                    At least 1 number
                </div>


                <div
                    id="requirementSpecial"
                    class="requirement-item"
                >
                    <span>✓</span>
                    At least 1 special character
                </div>

            </div>


        </div>

    </div>

</main>


<style>

.password-generator-layout {

    display: grid;

    grid-template-columns:
        minmax(320px, 1fr)
        minmax(320px, 1fr);

    gap: 24px;

    margin-top: 24px;

}


.password-settings,
.password-result-panel {

    min-height: 480px;

}


.form-group {

    margin-bottom: 25px;

}


.form-group label {

    display: block;

    font-weight: 600;

    color: var(--text-primary);

    margin-bottom: 10px;

}


.form-group small {

    display: block;

    margin-top: 7px;

    color: var(--text-secondary);

    font-size: 12px;

}


.length-controls {

    display: grid;

    grid-template-columns: 1fr 80px;

    gap: 15px;

    align-items: center;

}


input[type="range"] {

    width: 100%;

    accent-color: #4F46E5;

}


input[type="number"] {

    width: 100%;

    box-sizing: border-box;

    padding: 11px 12px;

    border: 1px solid var(--border-color);

    border-radius: 8px;

    font-size: 14px;

    outline: none;

}


input[type="number"]:focus {

    border-color: #4F46E5;

    box-shadow: 0 0 0 3px rgba(79,70,229,.1);

}


[data-theme="dark"] input[type="number"] {

    background: var(--input-bg);

    color: var(--text-primary);

    border-color: var(--input-border);

}


.complexity-section {

    margin-top: 25px;

    padding-top: 20px;

    border-top: 1px solid var(--border-color);

}


.complexity-section h4 {

    margin: 0 0 15px;

    color: var(--text-primary);

}


.checkbox-row {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 11px 0;

    cursor: pointer;

}


.checkbox-row input {

    width: 17px;

    height: 17px;

    accent-color: #4F46E5;

}


.checkbox-row span {

    flex: 1;

    font-size: 14px;

    color: var(--text-primary);

}


.checkbox-row small {

    color: var(--text-muted);

    font-size: 12px;

}


.generate-btn {

    width: 100%;

    margin-top: 25px;

    padding: 13px 20px;

    border: none;

    border-radius: 8px;

    background: #4F46E5;

    color: white;

    font-size: 15px;

    font-weight: 600;

    cursor: pointer;

    transition: .2s;

}


.generate-btn:hover {

    background: #4338CA;

    transform: translateY(-1px);

}


.password-display {

    display: grid;

    grid-template-columns: 1fr 52px;

    gap: 10px;

    margin-top: 30px;

}


.password-display input {

    width: 100%;

    box-sizing: border-box;

    padding: 15px;

    border: 1px solid var(--border-color);

    border-radius: 8px;

    background: var(--hover-bg);

    color: var(--text-primary);

    font-size: 16px;

    font-family: monospace;

    letter-spacing: 1px;

}


.copy-btn {

    border: none;

    border-radius: 8px;

    background: var(--border-color);

    color: var(--text-primary);

    cursor: pointer;

    font-size: 18px;

}


.copy-btn:hover {

    background: var(--border-color);

}


.strength-container {

    margin-top: 30px;

}


.strength-header {

    display: flex;

    justify-content: space-between;

    margin-bottom: 10px;

    font-size: 14px;

}


.strength-header strong {

    color: #10B981;

}


.strength-bar {

    width: 100%;

    height: 8px;

    background: var(--border-color);

    border-radius: 10px;

    overflow: hidden;

}


.strength-progress {

    height: 100%;

    border-radius: 10px;

    transition: width .3s, background .3s;

}


.strength-progress.weak {

    background: #EF4444;

}


.strength-progress.medium {

    background: #F59E0B;

}


.strength-progress.strong {

    background: #10B981;

}


.requirements {

    margin-top: 35px;

    padding-top: 20px;

    border-top: 1px solid var(--border-color);

}


.requirements h4 {

    margin: 0 0 15px;

    color: var(--text-primary);

}


.requirement-item {

    display: flex;

    align-items: center;

    gap: 10px;

    padding: 8px 0;

    color: var(--text-secondary);

    font-size: 14px;

}


.requirement-item span {

    width: 22px;

    height: 22px;

    display: flex;

    align-items: center;

    justify-content: center;

    border-radius: 50%;

    background: #DCFCE7;

    color: #16A34A;

    font-size: 12px;

    font-weight: bold;

}


.requirement-item.invalid span {

    background: #FEE2E2;

    color: #DC2626;

}


@media (max-width: 900px) {

    .password-generator-layout {

        grid-template-columns: 1fr;

    }

}


@media (max-width: 500px) {

    .length-controls {

        grid-template-columns: 1fr 70px;

    }

    .password-display {

        grid-template-columns: 1fr 45px;

    }

}

</style>


<script>

document.addEventListener("DOMContentLoaded", function () {


    const passwordLength =
        document.getElementById("passwordLength");

    const passwordLengthRange =
        document.getElementById("passwordLengthRange");

    const maxLength =
        document.getElementById("maxLength");

    const generatedPassword =
        document.getElementById("generatedPassword");

    const generateButton =
        document.getElementById("generatePassword");

    const copyButton =
        document.getElementById("copyPassword");


    const includeUppercase =
        document.getElementById("includeUppercase");

    const includeLowercase =
        document.getElementById("includeLowercase");

    const includeNumbers =
        document.getElementById("includeNumbers");

    const includeSpecial =
        document.getElementById("includeSpecial");


    const strengthText =
        document.getElementById("strengthText");

    const strengthBar =
        document.getElementById("strengthBar");


    const requirementLength =
        document.getElementById("requirementLength");

    const requirementUppercase =
        document.getElementById("requirementUppercase");

    const requirementNumber =
        document.getElementById("requirementNumber");

    const requirementSpecial =
        document.getElementById("requirementSpecial");


    const uppercaseChars =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    const lowercaseChars =
        "abcdefghijklmnopqrstuvwxyz";

    const numberChars =
        "0123456789";

    const specialChars =
        "!@#$%^&*()-_=+[]{};:,.?/";


    /*
     * Secure random character selection.
     *
     * crypto.getRandomValues() is used instead
     * of Math.random().
     */

    function secureRandom(max) {

        const array = new Uint32Array(1);

        window.crypto.getRandomValues(array);

        return array[0] % max;

    }


    function randomCharacter(characters) {

        return characters[
            secureRandom(characters.length)
        ];

    }


    /*
     * Shuffle using Fisher-Yates and
     * cryptographically secure random numbers.
     */

    function secureShuffle(array) {

        for (
            let i = array.length - 1;
            i > 0;
            i--
        ) {

            const j = secureRandom(i + 1);

            [
                array[i],
                array[j]
            ] = [
                array[j],
                array[i]
            ];

        }

        return array;

    }


    function getLength() {

        let max = parseInt(
            maxLength.value,
            10
        );


        if (
            isNaN(max) ||
            max < 4
        ) {

            max = 4;

            maxLength.value = max;

        }


        if (max > 128) {

            max = 128;

            maxLength.value = max;

        }


        /*
         * Keep the range slider synchronized
         * with the maximum length.
         */

        passwordLengthRange.max = max;


        let length = parseInt(
            passwordLength.value,
            10
        );


        if (isNaN(length)) {

            length = Math.min(16, max);

        }


        if (length < 4) {

            length = 4;

        }


        if (length > max) {

            length = max;

        }


        passwordLength.value = length;

        passwordLengthRange.value = length;


        return length;

    }


    function generatePassword() {

        const length = getLength();


        const selectedSets = [];


        if (includeUppercase.checked) {

            selectedSets.push(uppercaseChars);

        }


        if (includeLowercase.checked) {

            selectedSets.push(lowercaseChars);

        }


        if (includeNumbers.checked) {

            selectedSets.push(numberChars);

        }


        if (includeSpecial.checked) {

            selectedSets.push(specialChars);

        }


        if (selectedSets.length === 0) {

            alert(
                "Please select at least one character type."
            );

            return;

        }


        /*
         * The password must contain at least
         * one character from every selected
         * character group.
         */

        if (selectedSets.length > length) {

            alert(
                "Password length is too short for the selected requirements."
            );

            return;

        }


        const password = [];


        /*
         * Guarantee at least one character
         * from every selected category.
         */

        selectedSets.forEach(function (characters) {

            password.push(
                randomCharacter(characters)
            );

        });


        /*
         * Combine all selected character sets.
         */

        let allCharacters = "";

        selectedSets.forEach(function (characters) {

            allCharacters += characters;

        });


        /*
         * Fill the remaining password length.
         */

        while (password.length < length) {

            password.push(
                randomCharacter(allCharacters)
            );

        }


        /*
         * Shuffle so required characters are
         * not always at the beginning.
         */

        secureShuffle(password);


        generatedPassword.value =
            password.join("");


        updateRequirements();

        updateStrength();

    }


    function updateRequirements() {

        const password =
            generatedPassword.value;


        const lengthValid =
            password.length >= 4 &&
            password.length <=
            parseInt(maxLength.value, 10);


        const uppercaseValid =
            !includeUppercase.checked ||
            /[A-Z]/.test(password);


        const numberValid =
            !includeNumbers.checked ||
            /[0-9]/.test(password);


        const specialValid =
            !includeSpecial.checked ||
            /[^A-Za-z0-9]/.test(password);


        setRequirement(
            requirementLength,
            lengthValid
        );


        setRequirement(
            requirementUppercase,
            uppercaseValid
        );


        setRequirement(
            requirementNumber,
            numberValid
        );


        setRequirement(
            requirementSpecial,
            specialValid
        );

    }


    function setRequirement(element, valid) {

        if (valid) {

            element.classList.remove(
                "invalid"
            );

            element.querySelector("span")
                .textContent = "✓";

        } else {

            element.classList.add(
                "invalid"
            );

            element.querySelector("span")
                .textContent = "×";

        }

    }


    function updateStrength() {

        const password =
            generatedPassword.value;


        let score = 0;


        if (password.length >= 8) {

            score++;

        }


        if (password.length >= 12) {

            score++;

        }


        if (/[A-Z]/.test(password)) {

            score++;

        }


        if (/[a-z]/.test(password)) {

            score++;

        }


        if (/[0-9]/.test(password)) {

            score++;

        }


        if (/[^A-Za-z0-9]/.test(password)) {

            score++;

        }


        strengthBar.classList.remove(
            "weak",
            "medium",
            "strong"
        );


        if (score <= 2) {

            strengthText.textContent =
                "Weak";

            strengthText.style.color =
                "#EF4444";

            strengthBar.classList.add(
                "weak"
            );

            strengthBar.style.width =
                "35%";

        }
        else if (score <= 4) {

            strengthText.textContent =
                "Medium";

            strengthText.style.color =
                "#F59E0B";

            strengthBar.classList.add(
                "medium"
            );

            strengthBar.style.width =
                "65%";

        }
        else {

            strengthText.textContent =
                "Strong";

            strengthText.style.color =
                "#10B981";

            strengthBar.classList.add(
                "strong"
            );

            strengthBar.style.width =
                "100%";

        }

    }


    /*
     * Range slider -> number field
     */

    passwordLengthRange.addEventListener(
        "input",
        function () {

            passwordLength.value =
                this.value;

        }
    );


    /*
     * Number field -> range slider
     */

    passwordLength.addEventListener(
        "input",
        function () {

            let max =
                parseInt(
                    maxLength.value,
                    10
                );


            let value =
                parseInt(
                    this.value,
                    10
                );


            if (value < 4) {

                value = 4;

            }


            if (value > max) {

                value = max;

            }


            this.value = value;

            passwordLengthRange.max = max;

            passwordLengthRange.value = value;

        }
    );


    /*
     * Maximum length changes the
     * available password length.
     */

    maxLength.addEventListener(
        "input",
        function () {

            let max =
                parseInt(
                    this.value,
                    10
                );


            if (isNaN(max)) {

                return;

            }


            if (max < 4) {

                max = 4;

                this.value = max;

            }


            if (max > 128) {

                max = 128;

                this.value = max;

            }


            passwordLengthRange.max = max;


            if (
                parseInt(
                    passwordLength.value,
                    10
                ) > max
            ) {

                passwordLength.value = max;

            }


            passwordLengthRange.value =
                passwordLength.value;

        }
    );


    /*
     * Generate password
     */

    generateButton.addEventListener(
        "click",
        generatePassword
    );


    /*
     * Copy password
     */

    copyButton.addEventListener(
        "click",
        async function () {

            const password =
                generatedPassword.value;


            if (!password) {

                return;

            }


            try {

                await navigator.clipboard.writeText(
                    password
                );


                const originalText =
                    this.textContent;


                this.textContent = "✓";


                setTimeout(
                    () => {

                        this.textContent =
                            originalText;

                    },
                    1500
                );

            } catch (error) {

                /*
                 * Fallback for browsers where
                 * Clipboard API is unavailable.
                 */

                generatedPassword.select();

                document.execCommand("copy");

            }

        }
    );


    /*
     * Regenerate when complexity settings
     * change.
     */

    [
        includeUppercase,
        includeLowercase,
        includeNumbers,
        includeSpecial
    ].forEach(function (checkbox) {

        checkbox.addEventListener(
            "change",
            function () {

                if (
                    generatedPassword.value
                ) {

                    generatePassword();

                }

            }
        );

    });


    /*
     * Generate the first password
     * automatically when the page loads.
     */

    generatePassword();

});

</script>


<?php

include "includes/footer.php";

?>
