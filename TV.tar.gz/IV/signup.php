<?php

require_once "config/db.php";
require_once "includes/branding-helpers.php";

$appName = getAppName($pdo);
$appLogoUrl = getAppLogoUrl($pdo);

$message = "";
$message_type = "";


/**
 * Accepts the punctuation people actually type into a phone box -- spaces,
 * dashes, dots, parentheses and a single leading "+" -- then counts the
 * digits that are left. 7 to 15 covers a local extension-free number at the
 * short end and the E.164 maximum at the long end.
 */
function isValidSignupPhone($phone)
{
    if (!preg_match('/^\+?[0-9 ().\-]+$/', $phone)) {
        return false;
    }

    $digits = preg_replace('/\D/', '', $phone);

    return strlen($digits) >= 7 && strlen($digits) <= 15;
}


if ($_SERVER["REQUEST_METHOD"] === "POST") {


    $ncgr_id    = trim($_POST['ncgr_id'] ?? '');
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $team       = trim($_POST['team'] ?? '');
    $password   = $_POST['password'] ?? '';
    $confirm    = $_POST['confirm_password'] ?? '';



    if (
        empty($ncgr_id) ||
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($phone) ||
        empty($team) ||
        empty($password)
    ) {

        $message = "Please complete all required fields.";
        $message_type = "error";


    } elseif (!isValidSignupPhone($phone)) {


        /*
        | The phone number is not optional: oncall.php uses it as the default
        | "Contact number" for whoever is on shift, so an account that reaches
        | approval without a dialable number leaves the rota with a blank.
        | The HTML "required" attribute alone only stops an empty box -- it
        | happily accepts "n/a", so the number is shape-checked here too.
        */
        $message = "Please enter a valid phone number (7 to 15 digits, optionally starting with +).";
        $message_type = "error";


    } elseif ($password !== $confirm) {


        $message = "Passwords do not match.";
        $message_type = "error";


    } elseif (($policyErrors = validatePasswordPolicy($pdo, $password)) !== []) {


        // Password policy from Settings -> Security. Enforced here rather
        // than only shown as guidance, otherwise the setting would have no
        // effect on the accounts it is meant to govern.
        $message = implode(' ', $policyErrors);
        $message_type = "error";


    } else {


        $check = $pdo->prepare("
            SELECT id
            FROM users
            WHERE ncgr_id = ?
        ");


        $check->execute([$ncgr_id]);


        if ($check->fetch()) {


            $message = "NCGR ID already exists.";
            $message_type = "error";


        } else {


            $hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            $stmt = $pdo->prepare("
                INSERT INTO users
                (
                    ncgr_id,
                    first_name,
                    last_name,
                    email,
                    phone,
                    team,
                    password,
                    role,
                    is_approved
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    'Read-only',
                    0
                )
            ");



            $stmt->execute([
                $ncgr_id,
                $first_name,
                $last_name,
                $email,
                $phone,
                $team,
                $hash
            ]);



            $message =
            "Registration completed. Your account is waiting for administrator approval.";

            $message_type = "success";

            // Every field is now sticky across a failed submit, so clear the
            // posted values here or the completed form stays filled in behind
            // the success notice.
            $_POST = [];


        }

    }

}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Sign Up | <?= htmlspecialchars($appName) ?></title>
<link rel="icon" href="<?= htmlspecialchars($appLogoUrl) ?>">

<style>

/*
| Same design system as index.php, deliberately duplicated rather than
| extracted: these three screens (login, registration, password reset) are
| the only pages that render outside the app shell, and they load none of
| assets/css/. Keeping each one self-contained is what makes them survive a
| change to the authenticated layout's stylesheets.
*/

@font-face {
    font-family: Inter;
    src: url("assets/webfonts/Inter-Regular.woff2") format("woff2");
    font-weight: 400 700;
}

:root {
    --navy-950: #020617;
    --accent: #22D3EE;
    --accent-2: #2563EB;
    --accent-2-hover: #1D4ED8;
    --indigo: #4F46E5;
    --ink: #0F172A;
    --muted: #64748B;
    --border: #E2E8F0;
    --danger-bg: #FEF2F2;
    --danger-border: #FECACA;
    --danger-ink: #991B1B;
    --success-bg: #F0FDF4;
    --success-border: #BBF7D0;
    --success-ink: #166534;
}

* {
    box-sizing: border-box;
}

html, body {
    height: 100%;
}

body {
    margin: 0;
    min-height: 100vh;
    background: var(--navy-950);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    color: var(--ink);
    position: relative;
    overflow-x: hidden;
}

/* =========================
   DATACENTER BACKDROP
========================= */

.backdrop {
    position: fixed;
    inset: 0;
    width: 100%;
    height: 100%;
    z-index: 0;
}

.backdrop svg {
    width: 100%;
    height: 100%;
    display: block;
}

/* =========================
   PAGE LAYOUT
========================= */

.page {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 56px 20px 40px;
}

.lockup {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 34px;
}

.lockup img {
    width: 30px;
    height: 30px;
}

.lockup span {
    font-size: 15px;
    font-weight: 800;
    letter-spacing: .02em;
    color: #F1F5F9;
}

/* =========================
   CARD
========================= */

.card-wrap {
    position: relative;
    width: 100%;
    /* Wider than the login card's 430px: this form carries seven fields and
       a side-by-side name row, which cramps at that width. */
    max-width: 480px;
}

.badge {
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-2), var(--accent));
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 12px 30px rgba(34, 211, 238, .35), 0 0 0 6px rgba(255, 255, 255, .06);
    z-index: 2;
}

.badge svg {
    width: 26px;
    height: 26px;
    color: #fff;
}

.card {
    position: relative;
    background: rgba(255, 255, 255, .78);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, .6);
    border-radius: 28px;
    padding: 52px 40px 36px;
    box-shadow: 0 25px 70px rgba(2, 6, 23, .45), inset 0 1px 0 rgba(255, 255, 255, .6);
    text-align: center;
}

.card h2 {
    font-size: 25px;
    font-weight: 800;
    color: var(--ink);
    margin: 0 0 6px;
    letter-spacing: -.01em;
}

.card-sub {
    color: var(--muted);
    font-size: 13.5px;
    margin: 0;
}

.banner {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 10px;
    margin: 18px 0 4px;
    font-size: 13px;
    line-height: 1.5;
    text-align: left;
    border: 1px solid transparent;
}

.banner svg {
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    margin-top: 1px;
}

.banner.error {
    background: var(--danger-bg);
    border-color: var(--danger-border);
    color: var(--danger-ink);
}

.banner.success {
    background: var(--success-bg);
    border-color: var(--success-border);
    color: var(--success-ink);
}

/* =========================
   FORM
========================= */

form {
    margin-top: 14px;
    text-align: left;
}

.field {
    margin-top: 16px;
}

.field label {
    display: block;
    margin-bottom: 7px;
    font-size: 12.5px;
    font-weight: 700;
    color: #334155;
}

.field-input {
    position: relative;
    display: flex;
    align-items: center;
}

.field-input svg.leading-icon {
    position: absolute;
    left: 15px;
    width: 16px;
    height: 16px;
    color: #94A3B8;
    pointer-events: none;
}

.field input,
.field select {
    width: 100%;
    padding: 12px 14px 12px 42px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, .12);
    background: rgba(255, 255, 255, .7);
    font-size: 14px;
    font-family: inherit;
    color: var(--ink);
    transition: .15s;
}

/* Reserve room on the right for the eye toggle / chevron so long values
   don't slide underneath them. */
.field-input.has-trailing input,
.field select {
    padding-right: 40px;
}

.field select {
    appearance: none;
    -webkit-appearance: none;
    cursor: pointer;
}

.field input:focus,
.field select:focus {
    outline: none;
    border-color: var(--accent-2);
    background: rgba(255, 255, 255, .95);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .14);
}

.select-chevron {
    position: absolute;
    right: 16px;
    width: 15px;
    height: 15px;
    color: #94A3B8;
    pointer-events: none;
}

.toggle-visibility {
    position: absolute;
    right: 5px;
    width: 30px;
    height: 30px;
    border-radius: 50%;
    border: none;
    background: transparent;
    color: #94A3B8;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
}

.toggle-visibility:hover {
    background: #E2E8F0;
    color: #475569;
}

.toggle-visibility svg {
    width: 17px;
    height: 17px;
}

.field-hint {
    margin: 7px 0 0 16px;
    font-size: 12px;
    color: var(--muted);
}

/* First / last name share a line. min-width:0 stops the two flex children
   refusing to shrink below their inputs' intrinsic width. */
.row {
    display: flex;
    gap: 12px;
}

.row .field {
    flex: 1;
    min-width: 0;
}

.policy-hint {
    margin: 14px 0 0;
    padding: 10px 14px;
    border-radius: 10px;
    background: rgba(148, 163, 184, .12);
    font-size: 12px;
    line-height: 1.5;
    color: var(--muted);
}

button.submit {
    width: 100%;
    margin-top: 22px;
    padding: 14px;
    border: none;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-2), var(--indigo));
    color: #fff;
    font-size: 14.5px;
    font-weight: 700;
    letter-spacing: .01em;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    transition: filter .15s, transform .1s;
}

button.submit:hover {
    filter: brightness(1.08);
}

button.submit:active {
    transform: translateY(1px);
}

button.submit:focus-visible {
    outline: none;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .3);
}

button.submit[disabled] {
    opacity: .75;
    cursor: not-allowed;
}

.spinner {
    width: 15px;
    height: 15px;
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, .4);
    border-top-color: #fff;
    animation: spin .7s linear infinite;
    display: none;
}

button.submit.loading .spinner {
    display: inline-block;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 24px 0 18px;
    color: #94A3B8;
    font-size: 11.5px;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.divider::before,
.divider::after {
    content: "";
    flex: 1;
    height: 1px;
    background: var(--border);
}

.signin a {
    display: block;
    padding: 12px;
    border-radius: 999px;
    border: 1px solid var(--border);
    color: #334155;
    text-decoration: none;
    font-weight: 700;
    font-size: 13.5px;
    transition: .15s;
}

.signin a:hover {
    background: #F8FAFC;
    border-color: #CBD5E1;
}

/* =========================
   CAPTION + TRUST STRIP
========================= */

.caption {
    margin-top: 34px;
    text-align: center;
    font-size: 12.5px;
    font-weight: 700;
    letter-spacing: .12em;
    text-transform: uppercase;
    color: rgba(226, 232, 240, .75);
}

.trust-strip {
    margin-top: 18px;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 10px;
}

.trust-chip {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 14px;
    border-radius: 999px;
    background: rgba(255, 255, 255, .06);
    border: 1px solid rgba(255, 255, 255, .1);
    color: #CBD5E1;
    font-size: 12px;
    font-weight: 500;
}

.trust-chip svg {
    width: 13px;
    height: 13px;
    color: var(--accent);
}

.page-footer {
    margin-top: 26px;
    text-align: center;
    font-size: 11.5px;
    color: rgba(148, 163, 184, .6);
}

@media (max-width: 520px) {
    .card {
        padding: 46px 26px 30px;
    }

    /* Two 12px-gapped inputs stop being usable well before the card itself
       does, so the name row unstacks earlier than the card padding changes. */
    .row {
        display: block;
    }
}

</style>

</head>
<body>

<div class="backdrop" aria-hidden="true">
    <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">

        <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#020617"/>
                <stop offset="55%" stop-color="#0B1220"/>
                <stop offset="100%" stop-color="#0F172A"/>
            </linearGradient>

            <pattern id="floorGrid" width="64" height="64" patternUnits="userSpaceOnUse">
                <path d="M64 0H0V64" fill="none" stroke="#FFFFFF" stroke-opacity="0.045"/>
            </pattern>

            <filter id="blurBlob" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="75"/>
            </filter>

            <filter id="blurRacks" x="-30%" y="-30%" width="160%" height="160%">
                <feGaussianBlur stdDeviation="9"/>
            </filter>

            <filter id="ledGlow" x="-300%" y="-300%" width="700%" height="700%">
                <feGaussianBlur stdDeviation="6"/>
            </filter>
        </defs>

        <rect width="1600" height="900" fill="url(#bgGrad)"/>
        <rect width="1600" height="900" fill="url(#floorGrid)"/>

        <!-- ambient glow blobs -->
        <circle cx="230" cy="170" r="230" fill="#22D3EE" opacity="0.28" filter="url(#blurBlob)"/>
        <circle cx="1370" cy="740" r="290" fill="#4F46E5" opacity="0.32" filter="url(#blurBlob)"/>
        <circle cx="1250" cy="160" r="160" fill="#2563EB" opacity="0.18" filter="url(#blurBlob)"/>

        <!-- server rack skyline, deliberately blurred so it reads as soft
             background depth behind the card rather than sharp detail -->
        <g filter="url(#blurRacks)" opacity="0.65">

            <!-- rack 1 -->
            <rect x="60" y="720" width="110" height="180" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="750" x2="160" y2="750" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="790" x2="160" y2="790" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="830" x2="160" y2="830" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="70" y1="870" x2="160" y2="870" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="148" cy="738" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="148" cy="738" r="2.5" fill="#67E8F9"/>
            <circle cx="148" cy="818" r="7" fill="#34D399" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="148" cy="818" r="2.5" fill="#6EE7B7"/>

            <!-- rack 2 -->
            <rect x="200" y="660" width="110" height="240" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="690" x2="300" y2="690" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="730" x2="300" y2="730" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="770" x2="300" y2="770" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="810" x2="300" y2="810" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="210" y1="850" x2="300" y2="850" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="288" cy="678" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="288" cy="678" r="2.5" fill="#FDE68A"/>
            <circle cx="288" cy="758" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="288" cy="758" r="2.5" fill="#67E8F9"/>

            <!-- rack 3 -->
            <rect x="340" y="750" width="110" height="150" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="778" x2="440" y2="778" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="812" x2="440" y2="812" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="350" y1="846" x2="440" y2="846" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="428" cy="766" r="6" fill="#34D399" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="428" cy="766" r="2.2" fill="#6EE7B7"/>

            <!-- rack 4 -->
            <rect x="480" y="690" width="110" height="210" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="718" x2="580" y2="718" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="754" x2="580" y2="754" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="790" x2="580" y2="790" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="826" x2="580" y2="826" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="490" y1="862" x2="580" y2="862" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="568" cy="706" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="568" cy="706" r="2.5" fill="#67E8F9"/>
            <circle cx="568" cy="838" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="568" cy="838" r="2.5" fill="#FDE68A"/>

            <!-- right skyline (mirrored spacing) -->

            <!-- rack 5 -->
            <rect x="1010" y="700" width="110" height="200" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="728" x2="1110" y2="728" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="764" x2="1110" y2="764" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="800" x2="1110" y2="800" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1020" y1="836" x2="1110" y2="836" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1098" cy="716" r="7" fill="#34D399" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="1098" cy="716" r="2.5" fill="#6EE7B7"/>

            <!-- rack 6 -->
            <rect x="1150" y="640" width="110" height="260" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="668" x2="1250" y2="668" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="704" x2="1250" y2="704" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="740" x2="1250" y2="740" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="776" x2="1250" y2="776" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="812" x2="1250" y2="812" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1160" y1="848" x2="1250" y2="848" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1238" cy="656" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="1238" cy="656" r="2.5" fill="#67E8F9"/>
            <circle cx="1238" cy="788" r="7" fill="#FBBF24" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="1238" cy="788" r="2.5" fill="#FDE68A"/>

            <!-- rack 7 -->
            <rect x="1290" y="760" width="110" height="140" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1300" y1="788" x2="1390" y2="788" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1300" y1="820" x2="1390" y2="820" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1378" cy="776" r="6" fill="#34D399" opacity="0.5" filter="url(#ledGlow)"/>
            <circle cx="1378" cy="776" r="2.2" fill="#6EE7B7"/>

            <!-- rack 8 -->
            <rect x="1430" y="670" width="110" height="230" rx="8" fill="#0B1220" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="698" x2="1530" y2="698" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="734" x2="1530" y2="734" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="770" x2="1530" y2="770" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="806" x2="1530" y2="806" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <line x1="1440" y1="842" x2="1530" y2="842" stroke="#FFFFFF" stroke-opacity="0.08"/>
            <circle cx="1518" cy="686" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="1518" cy="686" r="2.5" fill="#67E8F9"/>
            <circle cx="1518" cy="818" r="7" fill="#22D3EE" opacity="0.55" filter="url(#ledGlow)"/>
            <circle cx="1518" cy="818" r="2.5" fill="#67E8F9"/>

        </g>

        <!-- floor shadow to seat the racks and darken the lower edge -->
        <rect x="0" y="860" width="1600" height="40" fill="#020617" opacity="0.55"/>

    </svg>
</div>

<div class="page">

    <div class="lockup">
        <img src="<?= htmlspecialchars($appLogoUrl) ?>" alt="<?= htmlspecialchars($appName) ?>">
        <span><?= htmlspecialchars($appName) ?></span>
    </div>

    <div class="card-wrap">

        <div class="badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/>
                <circle cx="9" cy="7" r="4"/>
                <line x1="19" y1="8" x2="19" y2="14"/>
                <line x1="22" y1="11" x2="16" y2="11"/>
            </svg>
        </div>

        <div class="card">

            <h2>Create your account</h2>
            <p class="card-sub">Register for <?= htmlspecialchars($appName) ?> access</p>

            <?php if ($message): ?>

                <div class="banner <?= $message_type === 'success' ? 'success' : 'error' ?>">
                    <?php if ($message_type === 'success'): ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <path d="m8.5 12.5 2.5 2.5 4.5-5"/>
                        </svg>
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <line x1="12" y1="8" x2="12" y2="13"/>
                            <line x1="12" y1="16" x2="12" y2="16"/>
                        </svg>
                    <?php endif; ?>
                    <span><?= htmlspecialchars($message) ?></span>
                </div>

            <?php endif; ?>

            <form method="POST" id="signupForm">

                <div class="field">
                    <label for="ncgr_id">NCGR ID</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="2" y="5" width="20" height="14" rx="2"/>
                            <circle cx="9" cy="11" r="2"/>
                            <path d="M6 16c.6-1.3 1.7-2 3-2s2.4.7 3 2"/>
                            <line x1="15" y1="10" x2="19" y2="10"/>
                            <line x1="15" y1="14" x2="19" y2="14"/>
                        </svg>
                        <input
                            type="text"
                            id="ncgr_id"
                            name="ncgr_id"
                            placeholder="Example: 91xxx"
                            autocomplete="username"
                            value="<?= htmlspecialchars($_POST['ncgr_id'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                            required
                            autofocus
                        >
                    </div>
                </div>

                <div class="row">

                    <div class="field">
                        <label for="first_name">First Name</label>
                        <div class="field-input">
                            <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input
                                type="text"
                                id="first_name"
                                name="first_name"
                                autocomplete="given-name"
                                value="<?= htmlspecialchars($_POST['first_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                required
                            >
                        </div>
                    </div>

                    <div class="field">
                        <label for="last_name">Last Name</label>
                        <div class="field-input">
                            <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                                <circle cx="12" cy="7" r="4"/>
                            </svg>
                            <input
                                type="text"
                                id="last_name"
                                name="last_name"
                                autocomplete="family-name"
                                value="<?= htmlspecialchars($_POST['last_name'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                                required
                            >
                        </div>
                    </div>

                </div>

                <div class="field">
                    <label for="email">Email</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="5" width="18" height="14" rx="2"/>
                            <path d="m3 7 9 6 9-6"/>
                        </svg>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            placeholder="example@ncgr.gov.sa"
                            autocomplete="email"
                            value="<?= htmlspecialchars($_POST['email'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                            required
                        >
                    </div>
                </div>

                <div class="field">
                    <label for="phone">Phone Number</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1 1 .4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.7 2z"/>
                        </svg>
                        <input
                            type="tel"
                            id="phone"
                            name="phone"
                            inputmode="tel"
                            placeholder="+966xxxx"
                            pattern="\+?[0-9 ().\-]{7,20}"
                            title="7 to 15 digits, optionally starting with +"
                            autocomplete="tel"
                            value="<?= htmlspecialchars($_POST['phone'] ?? '', ENT_QUOTES, 'UTF-8') ?>"
                            required
                        >
                    </div>
                    <p class="field-hint">Used as your default on-call contact number.</p>
                </div>

                <div class="field">
                    <label for="team">Team</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                            <circle cx="9" cy="7" r="4"/>
                            <path d="M23 21v-2a4 4 0 0 0-3-3.9"/>
                            <path d="M16 3.1a4 4 0 0 1 0 7.8"/>
                        </svg>

                        <select id="team" name="team" required>

                            <option value="">Select Team</option>

                            <?php
                            /*
                            | Read from the teams registry rather than a hardcoded list. The list
                            | that used to live here had drifted from the one in users.php -- it
                            | offered "AD and Exchage", which the admin screen could not select, so
                            | anyone who signed up into it was silently reassigned on the next save.
                            */
                            foreach (getTeamNames($pdo) as $signup_team): ?>

                                <option
                                    value="<?= htmlspecialchars($signup_team, ENT_QUOTES, 'UTF-8') ?>"
                                    <?= (($_POST['team'] ?? '') === $signup_team) ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($signup_team, ENT_QUOTES, 'UTF-8') ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <svg class="select-chevron" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                            <path d="m6 9 6 6 6-6"/>
                        </svg>
                    </div>
                </div>

                <div class="field">
                    <label for="password">Password</label>
                    <div class="field-input has-trailing">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="11" width="16" height="9" rx="2"/>
                            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                        </svg>
                        <input
                            type="password"
                            id="password"
                            name="password"
                            autocomplete="new-password"
                            required
                        >
                        <button type="button" class="toggle-visibility" data-target="password" aria-label="Show password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <div class="field">
                    <label for="confirm_password">Confirm Password</label>
                    <div class="field-input has-trailing">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="4" y="11" width="16" height="9" rx="2"/>
                            <path d="M8 11V7a4 4 0 0 1 8 0v4"/>
                        </svg>
                        <input
                            type="password"
                            id="confirm_password"
                            name="confirm_password"
                            autocomplete="new-password"
                            required
                        >
                        <button type="button" class="toggle-visibility" data-target="confirm_password" aria-label="Show password">
                            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/>
                                <circle cx="12" cy="12" r="3"/>
                            </svg>
                        </button>
                    </div>
                </div>

                <?php
                /*
                | The policy was already enforced on submit (validatePasswordPolicy
                | above) but never stated, so a rejection was the first the user
                | heard of it. Same helper change-password.php uses, so the two
                | screens cannot describe the rules differently.
                */
                ?>
                <p class="policy-hint"><?= htmlspecialchars(describePasswordPolicy($pdo), ENT_QUOTES, 'UTF-8') ?></p>

                <button type="submit" class="submit" id="submitBtn">
                    <span class="spinner"></span>
                    <span>Create Account</span>
                </button>

            </form>

            <div class="divider">or</div>

            <div class="signin">
                <a href="index.php">Already have an account? Sign In</a>
            </div>

        </div>

    </div>

    <div class="caption">Enterprise IT Management Platform</div>

    <div class="trust-strip">

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
            </svg>
            Secure Access Control
        </span>

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="3" width="20" height="7" rx="1.5"/>
                <rect x="2" y="14" width="20" height="7" rx="1.5"/>
            </svg>
            IT Infrastructure Platform
        </span>

        <span class="trust-chip">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M9 12.5 11 14.5 15.5 10"/>
                <path d="M20 12a8 8 0 1 1-3.2-6.4"/>
            </svg>
            Administrator Approval Required
        </span>

    </div>

    <div class="page-footer">
        &copy; <?= date('Y') ?> <?= htmlspecialchars($appName) ?> &middot; Internal Enterprise Platform &middot; All access is logged
    </div>

</div>

<script>
(function () {
    document.querySelectorAll('.toggle-visibility').forEach(function (btn) {
        btn.addEventListener('click', function () {
            const input = document.getElementById(btn.getAttribute('data-target'));
            const isHidden = input.type === 'password';
            input.type = isHidden ? 'text' : 'password';
            btn.setAttribute('aria-label', isHidden ? 'Hide password' : 'Show password');
        });
    });

    const form = document.getElementById('signupForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function () {
        submitBtn.classList.add('loading');
        submitBtn.setAttribute('disabled', 'disabled');
    });
})();
</script>

</body>
</html>
