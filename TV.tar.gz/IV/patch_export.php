<?php

/*
|--------------------------------------------------------------------------
| patch_export.php
|--------------------------------------------------------------------------
|
| Hostname-level patch export.
|
| Usage:
|
|   Current quarter:
|   patch_export.php?year=2026&quarter=3
|
|   Single assignment:
|   patch_export.php?schedule_id=123
|
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    exit('You must be signed in.');
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('patch', 'can_view');
requirePermission('patch', 'can_export');


require_once __DIR__ . '/config/patching_db.php';

$currentUserId = (int) ($_SESSION['user_id'] ?? 0);

$role = strtolower(trim($_SESSION['role'] ?? ''));

$isAdmin = in_array(
    $role,
    ['admin', 'administrator', 'super admin', 'superadmin'],
    true
);

$year =
    isset($_GET['year'])
        ? (int) $_GET['year']
        : (int) date('Y');

$quarter =
    isset($_GET['quarter'])
        ? (int) $_GET['quarter']
        : (int) ceil(((int) date('n')) / 3);

$scheduleId =
    isset($_GET['schedule_id'])
        ? (int) $_GET['schedule_id']
        : 0;

/*
|--------------------------------------------------------------------------
| Build schedule filter
|--------------------------------------------------------------------------
*/

$params = [];

$where = [];

if ($scheduleId > 0) {

    $where[] = 'ps.id = ?';
    $params[] = $scheduleId;

} else {

    if ($quarter < 1 || $quarter > 4) {
        $quarter = 1;
    }

    $where[] = 'ps.year = ?';
    $params[] = $year;

    $where[] = 'ps.quarter = ?';
    $params[] = $quarter;
}

/*
|--------------------------------------------------------------------------
| Permission scope
|--------------------------------------------------------------------------
*/

if (!$isAdmin) {

    $where[] = 'ps.assigned_to = ?';
    $params[] = $currentUserId;
}

$sql = "
    SELECT
        ps.id AS schedule_id,
        ps.year,
        ps.quarter,
        ps.project,
        ps.application,
        ps.support_level,
        ps.assigned_to AS schedule_assigned_to,
        ps.cr AS schedule_cr,
        ps.status AS schedule_status,
        ps.scheduled_date,
        ps.notes AS schedule_notes,

        pss.hostname,
        pss.selected,
        pss.assigned_to AS server_assigned_to,
        pss.patch_date,
        pss.status AS server_status,
        pss.comment AS server_comment,
        pss.cr AS server_cr,
        pss.updated_at AS server_updated_at,

        i.ip_address,
        i.os_family,
        i.os_version,
        i.kernel_version,

        pss.assigned_to_name AS server_assigned_to_name,
        su.first_name AS server_first_name,
        su.last_name AS server_last_name,

        ps.assigned_to_name AS schedule_assigned_to_name,
        au.first_name AS schedule_first_name,
        au.last_name AS schedule_last_name

    FROM patch_schedules ps

    LEFT JOIN patch_schedule_servers pss
        ON pss.schedule_id = ps.id

    LEFT JOIN inventory i
        ON i.hostname = pss.hostname
        AND i.project = ps.project
        AND i.application = ps.application

    LEFT JOIN users su
        ON su.id = pss.assigned_to

    LEFT JOIN users au
        ON au.id = ps.assigned_to

    WHERE "
    . implode(' AND ', $where) .
    "
    ORDER BY
        ps.year,
        ps.quarter,
        ps.project,
        ps.application,
        pss.hostname
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);

$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$rows) {

    http_response_code(404);
    exit('No patching records found for the selected scope.');
}

/*
|--------------------------------------------------------------------------
| Filename
|--------------------------------------------------------------------------
*/

if ($scheduleId > 0) {

    $filename =
        'patching-assignment-' .
        $scheduleId .
        '-' .
        date('Ymd-His') .
        '.csv';

} else {

    $filename =
        'patching-Q' .
        $quarter .
        '-' .
        $year .
        '-' .
        date('Ymd-His') .
        '.csv';
}

/*
|--------------------------------------------------------------------------
| CSV response
|--------------------------------------------------------------------------
*/

header('Content-Type: text/csv; charset=UTF-8');
header(
    'Content-Disposition: attachment; filename="' .
    $filename .
    '"'
);

header('Pragma: no-cache');
header('Expires: 0');

$output = fopen('php://output', 'w');

/*
 * UTF-8 BOM makes Excel recognize UTF-8 correctly.
 */
fprintf($output, "\xEF\xBB\xBF");

/*
|--------------------------------------------------------------------------
| Header
|--------------------------------------------------------------------------
*/

fputcsv($output, [
    'Schedule ID',
    'Year',
    'Quarter',
    'Project',
    'Application',
    'Support Level',

    'Schedule Assigned To',
    'Schedule CR',
    'Schedule Status',
    'Scheduled Date',
    'Schedule Notes',

    'Hostname',
    'Selected',
    'IP Address',
    'OS Family',
    'OS Version',
    'Kernel Version',

    'Server Assigned To',
    'Server Status',
    'Patch Date',
    'Server CR',
    'Server Comment',
    'Last Updated'
]);

/*
|--------------------------------------------------------------------------
| Data
|--------------------------------------------------------------------------
*/

foreach ($rows as $row) {

    $scheduleAssignee = trim((string) ($row['schedule_assigned_to_name'] ?? ''));
    if ($scheduleAssignee === '') {
        $scheduleAssignee = trim(
            ($row['schedule_first_name'] ?? '') .
            ' ' .
            ($row['schedule_last_name'] ?? '')
        );
    }

    $serverAssignee = trim((string) ($row['server_assigned_to_name'] ?? ''));
    if ($serverAssignee === '') {
        $serverAssignee = trim(
            ($row['server_first_name'] ?? '') .
            ' ' .
            ($row['server_last_name'] ?? '')
        );
    }

    fputcsv($output, [
        $row['schedule_id'],
        $row['year'],
        'Q' . $row['quarter'],
        $row['project'],
        $row['application'],
        $row['support_level'] ?: 'All Support Levels',

        $scheduleAssignee ?: 'Unassigned',
        $row['schedule_cr'] ?: '',
        $row['schedule_status'],
        $row['scheduled_date'] ?: '',
        $row['schedule_notes'] ?: '',

        $row['hostname'] ?: '',
        ((int) ($row['selected'] ?? 0) === 1)
            ? 'Yes'
            : 'No',

        $row['ip_address'] ?: '',
        $row['os_family'] ?: '',
        $row['os_version'] ?: '',
        $row['kernel_version'] ?: '',

        $serverAssignee ?: 'Unassigned',
        $row['server_status'] ?: 'Pending',
        $row['patch_date'] ?: '',
        $row['server_cr'] ?: '',
        $row['server_comment'] ?: '',
        $row['server_updated_at'] ?: ''
    ]);
}

fclose($output);
exit;
