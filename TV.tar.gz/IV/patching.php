<?php
// patching.php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/pagination-helpers.php';
require_once __DIR__ . '/includes/branding-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

require_once __DIR__ . '/config/patching_db.php';
require_once __DIR__ . '/includes/mail-helpers.php';
registerMailModule($pdo, 'patch_reminder', 'Patch Reminder Notifications');

$currentUserId = (int) ($_SESSION['user_id'] ?? 0);
$role = trim($_SESSION['role'] ?? '');

/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

function patchingHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'patching', $permission);
}

$canView   = patchingHasPermission($pdo, $role, 'can_view');
$canEdit   = patchingHasPermission($pdo, $role, 'can_edit');
$canDelete = patchingHasPermission($pdo, $role, 'can_delete');
$canExport = patchingHasPermission($pdo, $role, 'can_export');
$canImport = patchingHasPermission($pdo, $role, 'can_import');
$canAudit  = patchingHasPermission($pdo, $role, 'can_audit');

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| RESOLVE CURRENT USERNAME (for audit history "performed by")
|--------------------------------------------------------------------------
*/

$currentUsername = 'Unknown User';

if ($currentUserId > 0) {
    $userStmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1");
    $userStmt->execute([$currentUserId]);
    $curUserRow = $userStmt->fetch(PDO::FETCH_ASSOC);

    if ($curUserRow) {
        $fullName = trim(($curUserRow['first_name'] ?? '') . ' ' . ($curUserRow['last_name'] ?? ''));
        if ($fullName !== '') {
            $currentUsername = $fullName;
        }
    }
}

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

function checkCsrf(): void
{
    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}

/*
|--------------------------------------------------------------------------
| AUDIT HISTORY TABLE + LOGGER
|--------------------------------------------------------------------------
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS patch_schedule_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_id INTEGER,
        action_type TEXT NOT NULL,
        performed_by TEXT,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize patch_schedule_history: ' . $e->getMessage());
}



/*
|--------------------------------------------------------------------------
| GLOBAL + PER-SCHEDULE HISTORY AJAX
|--------------------------------------------------------------------------
|
| ?action=get_history               -> full module log (toolbar button)
| ?action=get_history&schedule_id=X -> just that one assignment's log
|   (per-row "History" button)
|
*/

/*
|--------------------------------------------------------------------------
| HOSTNAME-LEVEL CSV ROUND TRIP -- SHARED DEFINITIONS
|--------------------------------------------------------------------------
|
| Export and import both go through these, so the two can never drift
| into disagreeing about a column name or a value format.
|
| One row per hostname. Columns fall into three classes:
|
|   Derived  -- read live from inventory / license_warranty on export and
|               IGNORED on import. The patching CSV is not a back door
|               into the inventory master data.
|   Frozen   -- Last_Kernel_Patch. Snapshotted once when the host enters a
|               quarter, ignored on import.
|   Writable -- the per-host patch tracking fields. Import writes these.
|
*/

$patchQuarterRanges = [
    1 => 'Jan-Mar',
    2 => 'Apr-Jun',
    3 => 'Jul-Sep',
    4 => 'Oct-Dec',
];

/*
| Must stay in step with $serverStatuses in patch_servers.php -- that list
| gates what the grid will save, this one gates what the CSV import will
| accept, and a status in one but not the other is silently reset to
| Pending on the next save.
*/
$patchServerStatuses = [
    '',
    'Planned',
    'In Progress',
    'Completed',
    'Rescheduled',
    'N/A',
    'Excluded',
    'Decommissioned',
    'To Be Decom',
];



/*
| Header matching has to survive Excel round trips, so the comparison is
| done on a squashed form: case, spaces, hyphens and underscores are all
| dropped, and parenthesised hints are stripped -- "Patch-Level (N, N-1)"
| and "patch_level" both reduce to "patchlevel". The planned-time column
| carries the quarter in its own name, so the trailing Qn is normalised
| away as well; a Q3 file imported into Q4 still lands in the right field.
*/
function patchingNormalizeCsvHeader(string $header): string
{
    $header = preg_replace('/^\xEF\xBB\xBF/', '', $header);
    $header = strtolower(trim($header));
    $header = preg_replace('/\([^)]*\)/', ' ', $header);
    $header = (string) preg_replace('/[^a-z0-9]+/', '', (string) $header);

    /*
     * Quarter-stamped columns lose their Qn so a Q3 file imported into Q4
     * still lands in the right field, and so the pre-rename headers
     * ("Patch_Status") keep matching the current ones ("Q3 Status").
     */
    $header = (string) preg_replace('/^patchplannedtimeq[1-4]$/', 'patchplannedtime', $header);
    $header = (string) preg_replace('/^q[1-4]changenumber$/', 'changenumber', $header);
    $header = (string) preg_replace('/^q[1-4]status$/', 'patchstatus', $header);

    return $header;
}

/*
| Date cell -> YYYY-MM-DD, or null when the value cannot be read with
| certainty. The caller leaves the stored value alone on null, because a
| date this function had to guess at is worse than one it did not write.
|
| The deliberate refusal is the ambiguous case: 03/04/2026 is the 3rd of
| April to most of the world and the 4th of March to strtotime(), and
| there is nothing in the cell to say which was meant. Day-first dates
| where the first part is above 12 carry their own proof and are read as
| written, which covers what Excel produces from a non-US locale.
*/
/*
| $dayFirst decides only the cases nothing else can: both parts 12 or
| under and not equal. Callers pass what patchingDetectCsvDateOrder()
| found in the file; day-first is the default when the file offers no
| evidence either way.
*/
function patchingNormalizeCsvDate(string $value, bool $dayFirst = true): ?string
{
    $value = trim($value);

    if ($value === '') {
        return null;
    }

    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value)) {
        return $value;
    }

    if (preg_match('/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2}|\d{4})$/', $value, $parts)) {

        $first = (int) $parts[1];
        $second = (int) $parts[2];
        $year = (int) $parts[3];

        // Excel writes two-digit years readily enough to be worth accepting.
        if (strlen($parts[3]) === 2) {
            $year += 2000;
        }

        /*
         * One part over 12 settles it on its own, whatever the file's
         * convention, and so does a date like 9/9 where both readings give
         * the same day. Only a genuinely ambiguous pair falls through to
         * $dayFirst, which the caller infers from the rest of the file and
         * otherwise defaults to day-first (d/m/yyyy).
         *
         * This used to reject every pair of values under 13 outright,
         * which rejected most dates in any file Excel had re-saved --
         * including 9/9/2026, where there is nothing to be ambiguous
         * about.
         */
        if ($first > 12 && $second <= 12) {
            $day = $first;
            $month = $second;
        } elseif ($second > 12 && $first <= 12) {
            $day = $second;
            $month = $first;
        } elseif ($first > 12 && $second > 12) {
            return null;
        } elseif ($dayFirst) {
            $day = $first;
            $month = $second;
        } else {
            $day = $second;
            $month = $first;
        }

        return checkdate($month, $day, $year)
            ? sprintf('%04d-%02d-%02d', $year, $month, $day)
            : null;
    }

    $timestamp = strtotime($value);

    return $timestamp !== false ? date('Y-m-d', $timestamp) : null;
}

/*
| Works out whether a file writes dates day-first or month-first, by
| looking for values that can only be read one way -- a 25 in the first
| position means day-first, a 25 in the second means month-first.
|
| Excel rewrites the exported YYYY-MM-DD into the machine's locale on
| save, so a file coming back from a spreadsheet can be in either order
| and carries nothing to say which. Reading the file's own unambiguous
| dates is more reliable than assuming, and stops a US-locale export from
| having its ambiguous dates silently read day-first.
|
| Returns true for day-first, false for month-first, and null when the
| file gives no evidence or contradicts itself.
*/
function patchingDetectCsvDateOrder(array $sampleValues): ?bool
{
    $dayFirstEvidence = 0;
    $monthFirstEvidence = 0;

    foreach ($sampleValues as $sampleValue) {

        $sampleValue = trim((string) $sampleValue);

        if (!preg_match('/^(\d{1,2})[\/.\-](\d{1,2})[\/.\-](\d{2}|\d{4})$/', $sampleValue, $parts)) {
            continue;
        }

        $first = (int) $parts[1];
        $second = (int) $parts[2];

        if ($first > 12 && $second <= 12) {
            $dayFirstEvidence++;
        } elseif ($second > 12 && $first <= 12) {
            $monthFirstEvidence++;
        }
    }

    if ($dayFirstEvidence > 0 && $monthFirstEvidence === 0) {
        return true;
    }

    if ($monthFirstEvidence > 0 && $dayFirstEvidence === 0) {
        return false;
    }

    return null;
}

/*
| Normalised header -> writable field. Columns absent from this map are
| the derived and frozen ones: they are exported for context and silently
| ignored on import by design, not by oversight.
*/
function patchingWritableCsvColumns(): array
{
    /*
     * 'patchplannedtime' maps to scheduled_date, which is NOT a column of
     * patch_schedule_servers -- it belongs to the assignment. It is listed
     * here only so the importer can find the column; the import writes it
     * to patch_schedules for the assignment the host belongs to, never
     * onto the server row.
     */
    return [
        'patchplannedtime'            => 'scheduled_date',
        'appliedpatch'                => 'applied_patch',
        'appliedpatchreleasedate'     => 'applied_patch_release_date',
        'patchlevel'                  => 'patch_level',

        // Singular and plural both accepted -- the label has used each.
        'latestavailablepatchdetail'  => 'latest_available_patch',
        'latestavailablepatchdetails' => 'latest_available_patch',

        'appliedkernelpatch'          => 'new_kernel_version',
        'newkernelversion'            => 'new_kernel_version',
        'newosversion'                => 'new_os_version',
        'kernelpatchnlevel'           => 'kernel_patch_n_level',
        'changenumber'                => 'cr',
        'patchstatus'                 => 'status',
        'downtimerequired'            => 'downtime_required',
        'note'                        => 'comment',
        'assignee'                    => 'assignee',
    ];
}

/*
| Builds the OR'd WHERE fragment for an assignee-id filter (0 = unassigned),
| appending its bound values to $params in place. Returns null when
| $assigneeIds is empty.
|
| A schedule matches an id two ways: its own Default Assignment User is
| that id, or one of its selected servers is individually assigned to
| that id -- the per-host assignee shown in the Server modal, which
| changes day to day and is frequently different from the assignment's
| default. Checking assigned_to alone left an "Unassigned" filter unable
| to find schedules that had a default assignee but one or more
| individually-unassigned hosts underneath.
*/
function patchingAssigneeWhere(array $assigneeIds, array &$params): ?string
{
    $assigneeIds = array_values(array_unique($assigneeIds));

    if (!$assigneeIds) {
        return null;
    }

    $clauses = [];

    foreach ($assigneeIds as $assigneeId) {
        if ($assigneeId > 0) {
            $clauses[] = "(ps.assigned_to = ? OR EXISTS (
                SELECT 1 FROM patch_schedule_servers pss
                WHERE pss.schedule_id = ps.id AND pss.selected = 1 AND pss.assigned_to = ?
            ))";
            $params[] = $assigneeId;
            $params[] = $assigneeId;
        } else {
            $clauses[] = "(ps.assigned_to IS NULL OR EXISTS (
                SELECT 1 FROM patch_schedule_servers pss
                WHERE pss.schedule_id = ps.id AND pss.selected = 1 AND pss.assigned_to IS NULL
            ))";
        }
    }

    return '(' . implode(' OR ', $clauses) . ')';
}

/*
| WHERE fragment for the Reminder advanced-search filter. Mirrors the
| badge logic used in the table row ($reminderBadge / $reminderText
| further down): "Due" includes overdue schedules (a negative days-until
| still reads as due), and "Not due yet" is everything else that hasn't
| had a reminder sent.
*/
function patchingReminderWhereClause(string $reminderFilter): ?string
{
    switch ($reminderFilter) {
        case 'sent':
            return "ps.reminder_sent_at IS NOT NULL";
        case 'due':
            return "ps.reminder_sent_at IS NULL AND ps.scheduled_date IS NOT NULL
                AND (julianday(ps.scheduled_date) - julianday('now')) <= 7";
        case 'not_due':
            return "ps.reminder_sent_at IS NULL AND (ps.scheduled_date IS NULL
                OR (julianday(ps.scheduled_date) - julianday('now')) > 7)";
        default:
            return null;
    }
}





/*
|--------------------------------------------------------------------------
| CSV EXPORT (respecting filters)
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'export_csv') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export patching records.');
    }

    /*
     * Defaults come from the calendar, not from $selectedYear /
     * $selectedQuarter -- those are resolved further down the file and are
     * still undefined at this point.
     */
    $exportYear = isset($_GET['year']) ? (int) $_GET['year'] : (int) date('Y');
    $exportQuarter = isset($_GET['quarter'])
        ? (int) $_GET['quarter']
        : (int) ceil(((int) date('n')) / 3);

    if ($exportQuarter < 1 || $exportQuarter > 4) {
        $exportQuarter = (int) ceil(((int) date('n')) / 3);
    }

    // Build WHERE clause with same filters
    $exportWhereClauses = ["ps.year = ? AND ps.quarter = ?"];
    $exportParams = [$exportYear, $exportQuarter];

    if (!empty($_GET['search'])) {
        $k = trim($_GET['search']);
        $exportWhereClauses[] = "(ps.project LIKE ? OR ps.application LIKE ? OR ps.cr LIKE ?)";
        array_push($exportParams, "%$k%", "%$k%", "%$k%");
    }
    if (!empty($_GET['s_project'])) {
        $exportWhereClauses[] = "ps.project LIKE ?";
        $exportParams[] = "%" . trim($_GET['s_project']) . "%";
    }
    if (!empty($_GET['s_application'])) {
        $exportWhereClauses[] = "ps.application LIKE ?";
        $exportParams[] = "%" . trim($_GET['s_application']) . "%";
    }
    if (!empty($_GET['s_status'])) {
        $exportWhereClauses[] = "ps.status = ?";
        $exportParams[] = trim($_GET['s_status']);
    }
    if (!empty($_GET['s_support_level'])) {
        $exportWhereClauses[] = "ps.support_level LIKE ?";
        $exportParams[] = "%" . trim($_GET['s_support_level']) . "%";
    }
    if (!empty($_GET['s_cr'])) {
        $exportWhereClauses[] = "ps.cr LIKE ?";
        $exportParams[] = "%" . trim($_GET['s_cr']) . "%";
    }
    if (!empty($_GET['s_reminder'])) {
        $exportReminderClause = patchingReminderWhereClause(trim((string) $_GET['s_reminder']));
        if ($exportReminderClause !== null) {
            $exportWhereClauses[] = $exportReminderClause;
        }
    }
    if (!empty($_GET['s_date_from']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['s_date_from'])) {
        $exportWhereClauses[] = "ps.scheduled_date >= ?";
        $exportParams[] = $_GET['s_date_from'];
    }
    if (!empty($_GET['s_date_to']) && preg_match('/^\d{4}-\d{2}-\d{2}$/', $_GET['s_date_to'])) {
        $exportWhereClauses[] = "ps.scheduled_date <= ?";
        $exportParams[] = $_GET['s_date_to'];
    }

    /*
     * The toolbar's two view filters, applied here as well so the export
     * matches the rows the page is actually showing.
     */
    if (!empty($_GET['hide_completed'])) {
        $exportWhereClauses[] = "ps.status <> 'Completed'";
    }

    if (isset($_GET['f_assignee']) && trim((string) $_GET['f_assignee']) !== '') {

        $exportAssigneeIds = [];

        foreach (explode(',', (string) $_GET['f_assignee']) as $rawExportAssignee) {
            $rawExportAssignee = trim($rawExportAssignee);

            if ($rawExportAssignee !== '' && ctype_digit($rawExportAssignee)) {
                $exportAssigneeIds[] = (int) $rawExportAssignee;
            }
        }

        $exportAssigneeWhere = patchingAssigneeWhere($exportAssigneeIds, $exportParams);

        if ($exportAssigneeWhere !== null) {
            $exportWhereClauses[] = $exportAssigneeWhere;
        }
    }

    $exportWhereSQL = implode(" AND ", $exportWhereClauses);

    header('Content-Type: text/csv; charset=utf-8');
    header(
        'Content-Disposition: attachment; filename=patching_Q' . $exportQuarter .
        '_' . $exportYear . '_' . date('Y-m-d_H-i-s') . '.csv'
    );
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    // UTF-8 BOM so Excel reads the file as UTF-8 rather than the local codepage.
    fprintf($output, "\xEF\xBB\xBF");

    fputcsv($output, patchingCsvHeaders($exportQuarter, $patchQuarterRanges));

    $supportEndDates = patchingSupportEndDates($pdo);

    /*
     * One row per selected host. inventory.hostname carries a unique index,
     * so joining on hostname alone is correct and complete -- matching on
     * project/application as well would drop any host whose inventory
     * record has since been re-projected.
     *
     * Assignee falls back to the assignment-level owner, which is what the
     * per-host value is seeded from when a host first enters a quarter.
     */
    $exportStmt = $pdo->prepare("
        SELECT
            pss.hostname,
            pss.applied_patch,
            pss.applied_patch_release_date,
            pss.patch_level,
            pss.latest_available_patch,
            pss.last_kernel_patch,
            pss.new_kernel_version,
            pss.kernel_patch_n_level,
            pss.status AS server_status,
            pss.downtime_required,
            pss.comment,
            pss.cr AS server_cr,
            pss.updated_at,
            pss.assigned_to_name AS server_assigned_to_name,

            ps.project AS schedule_project,
            ps.scheduled_date,
            ps.cr AS schedule_cr,
            ps.assigned_to_name AS schedule_assigned_to_name,

            i.ip_address,
            i.project AS inventory_project,
            i.criticality,
            i.managed_by,
            i.support_level AS environment,
            i.technical_owner,
            i.ncgr_owner,
            i.os_family,
            i.os_version,

            su.first_name AS server_first_name,
            su.last_name  AS server_last_name,
            su.email      AS server_email,

            au.first_name AS schedule_first_name,
            au.last_name  AS schedule_last_name,
            au.email      AS schedule_email

        FROM patch_schedules ps
        INNER JOIN patch_schedule_servers pss
            ON pss.schedule_id = ps.id AND pss.selected = 1
        LEFT JOIN inventory i ON i.hostname = pss.hostname
        LEFT JOIN users su ON su.id = pss.assigned_to
        LEFT JOIN users au ON au.id = ps.assigned_to
        WHERE $exportWhereSQL
        ORDER BY ps.project, ps.application, pss.hostname
    ");
    $exportStmt->execute($exportParams);

    while (($row = $exportStmt->fetch(PDO::FETCH_ASSOC)) !== false) {

        $assignee = trim((string) ($row['server_assigned_to_name'] ?? ''));

        if ($assignee === '') {
            $assignee = trim(($row['server_first_name'] ?? '') . ' ' . ($row['server_last_name'] ?? ''));
        }

        if ($assignee === '') {
            $assignee = trim((string) ($row['server_email'] ?? ''));
        }

        if ($assignee === '') {
            $assignee = trim((string) ($row['schedule_assigned_to_name'] ?? ''));
        }

        if ($assignee === '') {
            $assignee = trim(($row['schedule_first_name'] ?? '') . ' ' . ($row['schedule_last_name'] ?? ''));
        }

        if ($assignee === '') {
            $assignee = trim((string) ($row['schedule_email'] ?? ''));
        }

        fputcsv($output, [
            $row['hostname'],
            $row['ip_address'] ?? '',
            ($row['inventory_project'] ?? '') !== '' ? $row['inventory_project'] : ($row['schedule_project'] ?? ''),
            $row['criticality'] ?? '',
            $row['managed_by'] ?? '',
            $row['environment'] ?? '',
            $row['technical_owner'] ?? '',
            $row['ncgr_owner'] ?? '',
            $row['os_family'] ?? '',
            $row['os_version'] ?? '',

            $row['applied_patch'] ?? '',
            $row['applied_patch_release_date'] ?? '',
            $row['patch_level'] ?? '',

            patchingLookupSupportEndDate(
                $supportEndDates,
                $row['os_family'] ?? '',
                $row['os_version'] ?? ''
            ),

            $row['latest_available_patch'] ?? '',
            $row['last_kernel_patch'] ?? '',
            $row['new_kernel_version'] ?? '',
            $row['kernel_patch_n_level'] ?? '',

            $row['scheduled_date'] ?? '',

            /*
             * Per-server CR is the specific one; the assignment CR is the
             * fallback for the common case of one change covering every
             * host in the assignment.
             */
            ($row['server_cr'] ?? '') !== '' ? $row['server_cr'] : ($row['schedule_cr'] ?? ''),

            ($row['server_status'] ?? '') !== '' ? $row['server_status'] : 'Planned',
            $row['downtime_required'] ?? '',
            $row['comment'] ?? '',
            $row['updated_at'] ?? '',
            $assignee,
        ]);
    }
    fclose($output);
    exit;
}

/*
|--------------------------------------------------------------------------
| GLOBAL + PER-SCHEDULE HISTORY AJAX
|--------------------------------------------------------------------------
|
| ?action=get_history               -> full module log (toolbar button)
| ?action=get_history&schedule_id=X -> just that one assignment's log
|   (per-row "History" button)
|
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="pt-empty">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyScheduleId = isset($_GET['schedule_id']) ? (int) $_GET['schedule_id'] : 0;

    if ($historyScheduleId > 0) {
        $hStmt = $pdo->prepare("SELECT * FROM patch_schedule_history WHERE schedule_id = ? ORDER BY timestamp DESC, id DESC");
        $hStmt->execute([$historyScheduleId]);
    } else {
        $hStmt = $pdo->query("SELECT * FROM patch_schedule_history ORDER BY timestamp DESC, id DESC");
    }

    $logs = $hStmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table class="audit-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $badgeColor = 'background:var(--border-color);color:var(--text-primary);';
            if ($log['action_type'] === 'CREATED') $badgeColor = 'background:#dcfce7;color:#166534;';
            if ($log['action_type'] === 'DELETED') $badgeColor = 'background:#fee2e2;color:#991b1b;';
            if ($log['action_type'] === 'UPDATED') $badgeColor = 'background:#fef9c3;color:#854d0e;';
            if ($log['action_type'] === 'CLONED') $badgeColor = 'background:#dbeafe;color:#1e40af;';
            if ($log['action_type'] === 'COPIED') $badgeColor = 'background:#dbeafe;color:#1e40af;';
            if ($log['action_type'] === 'STATUS_UPDATED') $badgeColor = 'background:#f3e8ff;color:#7e22ce;';
            if ($log['action_type'] === 'REMINDER_SENT') $badgeColor = 'background:#e0f2fe;color:#0369a1;';
            if ($log['action_type'] === 'BULK IMPORT') $badgeColor = 'background:#dbeafe;color:#1e40af;';

            echo '<tr>';
            echo '<td><span class="audit-badge" style="' . $badgeColor . '">' . h($log['action_type']) . '</span></td>';
            echo '<td>' . h($log['performed_by'] ?? '') . '</td>';
            echo '<td class="audit-details">' . nl2br(h($log['details'] ?? '')) . '</td>';
            echo '<td>' . h($log['timestamp'] ?? '') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="pt-empty">' . ($historyScheduleId > 0 ? 'No history found for this assignment.' : 'No audit history records found.') . '</p>';
    }
    exit;
}

/*
|--------------------------------------------------------------------------
| CONSTANTS
|--------------------------------------------------------------------------
*/

$scheduleStatuses = [
    'Assigned',
    'In Progress',
    'Partial',
    'Completed',
    'N/A',
    'Rescheduled',
    'Excluded'
];

function statusClass(string $status): string
{
    return 'st-' . strtolower(str_replace(['/', ' '], ['', ''], $status));
}

function redirectPatching(int $year, int $quarter, string $msgKey = '', string $msg = ''): void
{
    if ($msgKey !== '') {
        $_SESSION[$msgKey] = $msg;
    }

    header("Location: patching.php?year={$year}&quarter={$quarter}");
    exit;
}

/*
|--------------------------------------------------------------------------
| YEAR / QUARTER
|--------------------------------------------------------------------------
*/

$thisYear = (int) date('Y');
$thisQuarter = (int) ceil(((int) date('n')) / 3);

$selectedYear = isset($_GET['year']) ? (int) $_GET['year'] : $thisYear;
$selectedQuarter = isset($_GET['quarter']) ? (int) $_GET['quarter'] : $thisQuarter;

if ($selectedQuarter < 1 || $selectedQuarter > 4) {
    $selectedQuarter = $thisQuarter;
}

/*
| The year strip used to be a fixed range($thisYear - 1, $thisYear + 3),
| which made every year past that window unreachable -- planning a cycle
| further out simply had no button. It is now a sliding five-year window
| that always contains $selectedYear, with prev/next arrows either side,
| so any year inside $ptMinYear..$ptMaxYear can be walked to and linked
| to directly. The dropdowns in the modals get their own, wider list.
*/
$ptMinYear = 2000;
$ptMaxYear = 2100;

if ($selectedYear < $ptMinYear || $selectedYear > $ptMaxYear) {
    $selectedYear = $thisYear;
}

$yearStripStart = $thisYear - 1;

if ($selectedYear < $yearStripStart) {
    $yearStripStart = $selectedYear;
} elseif ($selectedYear > $yearStripStart + 4) {
    $yearStripStart = $selectedYear - 4;
}

$yearStripStart = max($ptMinYear, min($yearStripStart, $ptMaxYear - 4));

$yearOptions = range($yearStripStart, $yearStripStart + 4);

/* Wider list for the modal <select>s, which have no arrows to walk with. */
$yearSelectOptions = range(
    max($ptMinYear, min($thisYear - 2, $selectedYear - 2)),
    min($ptMaxYear, max($thisYear + 6, $selectedYear + 6))
);

$prevStripYear = max($ptMinYear, $selectedYear - 1);
$nextStripYear = min($ptMaxYear, $selectedYear + 1);

$quarterLabels = [
    1 => ['Q1', 'Jan – Mar'],
    2 => ['Q2', 'Apr – Jun'],
    3 => ['Q3', 'Jul – Sep'],
    4 => ['Q4', 'Oct – Dec'],
];

/*
|--------------------------------------------------------------------------
| SYNC MATCHING INVENTORY SERVERS
|--------------------------------------------------------------------------
*/

function syncScheduleServersFromInventory(
    PDO $pdo,
    int $scheduleId,
    string $project,
    string $application,
    string $supportLevel,
    ?int $defaultAssignee,
    int $updatedBy
): void {
    if ($application !== '') {
        $stmt = $pdo->prepare("
            SELECT hostname, kernel_version
            FROM inventory
            WHERE project = ?
              AND application = ?
              AND support_level = ?
              AND managed_by = 'HCL'
            ORDER BY hostname
        ");
        $stmt->execute([$project, $application, $supportLevel]);
    } else {
        $stmt = $pdo->prepare("
            SELECT hostname, kernel_version
            FROM inventory
            WHERE project = ?
              AND support_level = ?
              AND managed_by = 'HCL'
            ORDER BY hostname
        ");
        $stmt->execute([$project, $supportLevel]);
    }

    $servers = $stmt->fetchAll(PDO::FETCH_ASSOC);

    /*
    | INSERT OR IGNORE is what freezes last_kernel_patch: a host already
    | present in this assignment is skipped entirely, so the snapshot
    | taken when it first entered the quarter is never overwritten by a
    | later re-sync that sees a newer inventory kernel version.
    */
    $insert = $pdo->prepare("
        INSERT OR IGNORE INTO patch_schedule_servers
        (schedule_id, hostname, selected, assigned_to, last_kernel_patch, updated_by, updated_at)
        VALUES (?, ?, 1, ?, ?, ?, CURRENT_TIMESTAMP)
    ");

    foreach ($servers as $server) {
        $hostname = trim((string) ($server['hostname'] ?? ''));

        if ($hostname === '') {
            continue;
        }

        $insert->execute([
            $scheduleId,
            $hostname,
            $defaultAssignee,
            trim((string) ($server['kernel_version'] ?? '')),
            $updatedBy,
        ]);
    }
}

/*
|--------------------------------------------------------------------------
| UNASSIGNED SERVERS
|--------------------------------------------------------------------------
|
| ITAM rows that are in scope for patching but hold no place in the
| selected cycle -- what the removed Patch Planning page used to answer,
| now a button on this page so the answer and the fix sit together.
|
| In scope means all four of these, which is the same "active server"
| rule Inventory's own export uses:
|
|     managed_by   = HCL
|     live         = yes
|     eol          = no
|     server_state = powered on
|
| "Already in the cycle" is decided by hostname across every assignment
| of that year/quarter, compared LOWER(TRIM()) on both sides: inventory
| and the patching tables disagree about case (SRL002 vs srl008), and an
| exact compare would report hosts as unassigned that are scheduled.
*/

function patchingEligibleWhere(string $alias = 'i'): string
{
    return "
        LOWER(TRIM(COALESCE($alias.managed_by, ''))) = 'hcl'
        AND LOWER(TRIM(COALESCE($alias.live, ''))) = 'yes'
        AND LOWER(TRIM(COALESCE($alias.eol, ''))) = 'no'
        AND LOWER(TRIM(COALESCE($alias.server_state, ''))) = 'powered on'
        AND TRIM(COALESCE($alias.hostname, '')) <> ''
    ";
}

function patchingUnassignedServers(PDO $pdo, int $year, int $quarter): array
{
    $stmt = $pdo->prepare("
        SELECT i.hostname, i.ip_address, i.project, i.application, i.support_level,
               i.os_family, i.os_version, i.kernel_version, i.criticality
        FROM inventory i
        WHERE " . patchingEligibleWhere('i') . "
          AND LOWER(TRIM(i.hostname)) NOT IN (
              SELECT LOWER(TRIM(pss.hostname))
              FROM patch_schedule_servers pss
              INNER JOIN patch_schedules ps ON ps.id = pss.schedule_id
              WHERE ps.year = ? AND ps.quarter = ?
          )
        ORDER BY i.project, i.application, i.support_level, i.hostname
    ");
    $stmt->execute([$year, $quarter]);

    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
| Where a host would land if it were saved now.
|
| An assignment for the host's exact project + application + support
| level is its home. Failing that, the project's "all applications"
| assignment (application = '') covers it, because that is what an empty
| application means everywhere else in this module. Only when neither
| exists is a new assignment needed.
|
| Returns [scheduleId|null, label] so the list, the save and the summary
| all describe the same destination.
*/
function patchingFindHomeAssignment(array $cycleSchedules, string $project, string $application, string $supportLevel): array
{
    $exact = $project . '|' . $application . '|' . $supportLevel;

    if (isset($cycleSchedules[$exact])) {
        return [(int) $cycleSchedules[$exact], $application !== '' ? $application : 'All applications'];
    }

    $allApps = $project . '||' . $supportLevel;

    if ($application !== '' && isset($cycleSchedules[$allApps])) {
        return [(int) $cycleSchedules[$allApps], 'All applications'];
    }

    return [null, ''];
}

function patchingCycleSchedules(PDO $pdo, int $year, int $quarter): array
{
    $stmt = $pdo->prepare("
        SELECT id, project, application, support_level
        FROM patch_schedules
        WHERE year = ? AND quarter = ?
        ORDER BY id
    ");
    $stmt->execute([$year, $quarter]);

    $map = [];

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $key = trim((string) $row['project']) . '|'
            . trim((string) $row['application']) . '|'
            . trim((string) $row['support_level']);

        // First id wins -- duplicates of a group are joined, never forked.
        if (!isset($map[$key])) {
            $map[$key] = (int) $row['id'];
        }
    }

    return $map;
}

/*
|--------------------------------------------------------------------------
| UNASSIGNED SERVERS AJAX FRAGMENT
|--------------------------------------------------------------------------
|
| Loaded into the modal on demand rather than rendered with the page: the
| list is one row per unscheduled host with a user picker on each, and
| building that on every page view would be paid for by everyone who
| never opens it.
*/

if (isset($_GET['action']) && $_GET['action'] === 'unassigned_servers') {

    $fragmentServers = patchingUnassignedServers($pdo, $selectedYear, $selectedQuarter);
    $fragmentSchedules = patchingCycleSchedules($pdo, $selectedYear, $selectedQuarter);

    $fragmentUsers = $pdo->query("
        SELECT id, first_name, last_name
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name, last_name
    ")->fetchAll(PDO::FETCH_ASSOC);

    if (!$fragmentServers) {
        echo '<p class="pt-empty">Every eligible Inventory server is already scheduled for Q'
            . (int) $selectedQuarter . ' ' . (int) $selectedYear . '.</p>';
        exit;
    }

    $newGroups = [];

    foreach ($fragmentServers as $fragmentServer) {
        [$homeId] = patchingFindHomeAssignment(
            $fragmentSchedules,
            trim((string) $fragmentServer['project']),
            trim((string) $fragmentServer['application']),
            trim((string) $fragmentServer['support_level'])
        );

        if ($homeId === null) {
            $newGroups[trim((string) $fragmentServer['project']) . '|'
                . trim((string) $fragmentServer['application']) . '|'
                . trim((string) $fragmentServer['support_level'])] = true;
        }
    }
    ?>
    <div class="pt-stats" style="margin-bottom:14px;">
        <div class="pt-stat-card">
            <span>Not yet scheduled</span>
            <strong><?= count($fragmentServers) ?></strong>
            <small class="pp-stat-note">HCL, live, not EOL, powered on</small>
        </div>
        <div class="pt-stat-card">
            <span>New assignments needed</span>
            <strong><?= count($newGroups) ?></strong>
            <small class="pp-stat-note">the rest join an assignment that already exists</small>
        </div>
        <div class="pt-stat-card">
            <span>Assignments in this cycle</span>
            <strong><?= count($fragmentSchedules) ?></strong>
            <small class="pp-stat-note">Q<?= (int) $selectedQuarter ?> <?= (int) $selectedYear ?></small>
        </div>
    </div>

    <?php if (!$canEdit): ?>
        <p class="pt-empty">You do not have permission to assign servers.</p>
    <?php endif; ?>

    <form id="unassignedForm" method="POST" action="patching.php">
        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
        <input type="hidden" name="form_action" value="assign_unassigned">
        <input type="hidden" name="year" value="<?= (int) $selectedYear ?>">
        <input type="hidden" name="quarter" value="<?= (int) $selectedQuarter ?>">

        <?php if ($canEdit): ?>
            <div class="pp-bulk" style="margin-top:0;">
                <button type="button" class="pt-btn pt-btn-secondary" onclick="ptUnassignedSelectAll(true)">Select all shown</button>
                <button type="button" class="pt-btn pt-btn-secondary" onclick="ptUnassignedSelectAll(false)">Clear selection</button>

                <input type="text" id="unassignedFilter" class="pp-bulk-select" style="min-width:220px;"
                       placeholder="Filter by host, project, application..." oninput="ptFilterUnassignedRows()">

                <select id="unassignedBulkUser" class="pp-bulk-select">
                    <option value="">-- Assign ticked servers to --</option>
                    <option value="0">Unassigned</option>
                    <?php foreach ($fragmentUsers as $fragmentUser): ?>
                        <option value="<?= (int) $fragmentUser['id'] ?>">
                            <?= h(trim($fragmentUser['first_name'] . ' ' . $fragmentUser['last_name'])) ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <button type="button" class="pt-btn pt-btn-secondary" onclick="ptApplyUnassignedBulk()">Apply</button>
                <span class="pp-save-hint" id="unassignedCount">0 selected</span>
            </div>
        <?php endif; ?>

        <div class="pt-table-wrap" style="max-height:46vh;overflow-y:auto;margin-top:12px;">
            <table class="pt-table">
                <thead>
                    <tr>
                        <?php if ($canEdit): ?><th style="width:52px;">Assign</th><?php endif; ?>
                        <th>Hostname</th>
                        <th>IP</th>
                        <th>Project</th>
                        <th>Application</th>
                        <th>Support Level</th>
                        <th>OS</th>
                        <th>Goes to</th>
                        <?php if ($canEdit): ?><th style="width:190px;">Assignee</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody id="unassignedRows">
                    <?php foreach ($fragmentServers as $fragmentServer): ?>
                        <?php
                        $fragmentHost = trim((string) $fragmentServer['hostname']);
                        $hostKey = strtolower($fragmentHost);
                        $fragmentProject = trim((string) $fragmentServer['project']);
                        $fragmentApplication = trim((string) $fragmentServer['application']);
                        $fragmentSupport = trim((string) $fragmentServer['support_level']);

                        [$homeId, $homeLabel] = patchingFindHomeAssignment(
                            $fragmentSchedules,
                            $fragmentProject,
                            $fragmentApplication,
                            $fragmentSupport
                        );

                        $searchText = strtolower(
                            $fragmentHost . ' ' . $fragmentProject . ' '
                            . $fragmentApplication . ' ' . $fragmentSupport
                        );
                        ?>
                        <tr data-search="<?= h($searchText) ?>">
                            <?php if ($canEdit): ?>
                                <td>
                                    <input type="checkbox" class="pt-unassigned-check"
                                           name="servers[<?= h($hostKey) ?>][include]" value="1"
                                           onchange="ptUpdateUnassignedCount()">
                                </td>
                            <?php endif; ?>

                            <td><strong><?= h($fragmentHost) ?></strong></td>
                            <td><?= h($fragmentServer['ip_address'] ?: '-') ?></td>
                            <td><?= h($fragmentProject ?: '-') ?></td>
                            <td><?= h($fragmentApplication !== '' ? $fragmentApplication : '-') ?></td>
                            <td><?= h($fragmentSupport ?: '-') ?></td>
                            <td><?= h(trim(($fragmentServer['os_family'] ?? '') . ' ' . ($fragmentServer['os_version'] ?? '')) ?: '-') ?></td>

                            <td>
                                <?php if ($homeId !== null): ?>
                                    <span class="pt-badge pt-goes-existing" title="Joins assignment #<?= $homeId ?>">
                                        Existing &mdash; <?= h($homeLabel) ?>
                                    </span>
                                <?php else: ?>
                                    <span class="pt-badge pt-goes-new">New assignment</span>
                                <?php endif; ?>
                            </td>

                            <?php if ($canEdit): ?>
                                <td>
                                    <select class="pp-bulk-select pt-unassigned-user" style="width:100%;"
                                            name="servers[<?= h($hostKey) ?>][assigned_to]">
                                        <option value="0">-- Unassigned --</option>
                                        <?php foreach ($fragmentUsers as $fragmentUser): ?>
                                            <option value="<?= (int) $fragmentUser['id'] ?>">
                                                <?= h(trim($fragmentUser['first_name'] . ' ' . $fragmentUser['last_name'])) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <?php if ($canEdit): ?>
            <div class="pp-save-bar" style="padding:18px 0 0;">
                <div class="pt-field" style="margin:0;">
                    <label>Scheduled date</label>
                    <input type="date" name="scheduled_date" id="unassignedDate">
                    <small>
                        Written to assignments this save creates. An assignment that already
                        has a date keeps it unless you tick the box below.
                    </small>
                </div>

                <div class="pt-field" style="margin:0;align-self:center;">
                    <label style="display:flex;align-items:center;gap:8px;font-weight:600;">
                        <input type="checkbox" name="overwrite_dates" value="1" style="width:auto;">
                        Overwrite dates on existing assignments
                    </label>
                </div>

                <div class="pp-save-actions">
                    <button type="submit" class="pt-btn pt-btn-primary">
                        Assign to Q<?= (int) $selectedQuarter ?> <?= (int) $selectedYear ?>
                    </button>
                </div>
            </div>
        <?php endif; ?>
    </form>
    <?php
    exit;
}

/*
|--------------------------------------------------------------------------
| Field labels used for the update diff shown in audit history
|--------------------------------------------------------------------------
*/

$scheduleFieldLabels = [
    'year'            => 'Year',
    'quarter'         => 'Quarter',
    'project'         => 'Project',
    'application'     => 'Application',
    'support_level'   => 'Support Level',
    'assigned_to'     => 'Assigned To',
    'cr'              => 'CR',
    'status'          => 'Status',
    'scheduled_date'  => 'Scheduled Date',
    'notes'           => 'Notes',
];

/*
|--------------------------------------------------------------------------
| POST HANDLERS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    checkCsrf();

    $formAction = $_POST['form_action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | CREATE / UPDATE ASSIGNMENT
    |--------------------------------------------------------------------------
    */

    if ($formAction === 'save_schedule') {

        if (!$canEdit) {
            http_response_code(403);
            exit('You do not have permission to edit the patching schedule.');
        }

        $scheduleId = (int) ($_POST['schedule_id'] ?? 0);
        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);
        $project = trim($_POST['project'] ?? '');
        $application = trim($_POST['application'] ?? '');
        $supportLevel = trim($_POST['support_level'] ?? '');
        $assignedTo = (int) ($_POST['assigned_to'] ?? 0);
        $assignedTo = $assignedTo > 0 ? $assignedTo : null;
        $cr = trim($_POST['cr'] ?? '');
        $scheduledDate = trim($_POST['scheduled_date'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        /*
         * Status is never accepted from this form -- see the note by
         * patchingRecomputeScheduleStatus() in config/patching_db.php. It
         * is always derived from the assignment's own selected servers,
         * recomputed below once the server list has been synced.
         * 'Assigned' here is only the placeholder the INSERT needs to
         * satisfy the NOT NULL column; the UPDATE path keeps whatever
         * status the record already has until the recompute overwrites it.
         */
        $status = 'Assigned';

        if ($project === '' || $supportLevel === '' || $quarter < 1 || $quarter > 4) {
            redirectPatching($year, $quarter, 'pt_error', 'Project, Support Level, and a valid quarter are required.');
        }

        if ($scheduleId === 0) {

            $stmt = $pdo->prepare("
                INSERT INTO patch_schedules
                (year, quarter, project, application, support_level, assigned_to, cr, status, scheduled_date, notes, created_by)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $year, $quarter, $project, $application, $supportLevel,
                $assignedTo, $cr, $status, $scheduledDate ?: null, $notes, $currentUserId
            ]);

            $newScheduleId = (int) $pdo->lastInsertId();

            /*
             * Pull in every matching inventory server straight away, the
             * same way the edit path does. Without this a newly created
             * assignment started with an empty patch_schedule_servers
             * set and stayed at "0 / N selected" until it was edited.
             */
            syncScheduleServersFromInventory($pdo, $newScheduleId, $project, $application, $supportLevel, $assignedTo, $currentUserId);

            patchingRecomputeScheduleStatus($pdo, $newScheduleId);

            $createdAssigneeName = patchingResolveAssigneeName($pdo, $assignedTo);
            $createDetail = "Created assignment: $project" . ($application !== '' ? " / $application" : '') . " ($supportLevel) for Q{$quarter} {$year}";
            if ($createdAssigneeName) {
                $createDetail .= ". Assigned To: $createdAssigneeName";
            }

            logPatchHistory(
                $pdo,
                $newScheduleId,
                'CREATED',
                $currentUsername,
                $createDetail
            );

            redirectPatching($year, $quarter, 'pt_success', 'Assignment created.');

        } else {

            $oldStmt = $pdo->prepare("SELECT * FROM patch_schedules WHERE id = ?");
            $oldStmt->execute([$scheduleId]);
            $oldRecord = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

            $oldDate = $oldRecord['scheduled_date'] ?? '';

            /*
             * The raw UPDATE keeps the record's current status -- see the
             * note above -- and the recompute right after the server sync
             * is what actually moves it, if it needs to move at all.
             */
            $status = (string) ($oldRecord['status'] ?? 'Assigned');

            $stmt = $pdo->prepare("
                UPDATE patch_schedules
                SET
                    year = ?,
                    quarter = ?,
                    project = ?,
                    application = ?,
                    support_level = ?,
                    assigned_to = ?,
                    cr = ?,
                    status = ?,
                    scheduled_date = ?,
                    notes = ?,
                    reminder_sent_at = CASE
                        WHEN scheduled_date <> ?
                        THEN NULL
                        ELSE reminder_sent_at
                    END,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $year, $quarter, $project, $application, $supportLevel,
                $assignedTo, $cr, $status, $scheduledDate ?: null, $notes,
                $scheduledDate ?: '', $scheduleId
            ]);

            /*
             * If the schedule-level assignee changes, do not overwrite
             * individual server assignments. Server-specific assignments
             * remain independent.
             */
            syncScheduleServersFromInventory($pdo, $scheduleId, $project, $application, $supportLevel, $assignedTo, $currentUserId);

            [$oldComputedStatus, $newComputedStatus, $computedStatusChanged] =
                patchingRecomputeScheduleStatus($pdo, $scheduleId);

            // Field-level diff for the audit trail.
            $newValuesByColumn = [
                'year'           => (string) $year,
                'quarter'        => (string) $quarter,
                'project'        => $project,
                'application'    => $application,
                'support_level'  => $supportLevel,
                'assigned_to'    => (string) (patchingResolveAssigneeName($pdo, $assignedTo) ?? ''),
                'cr'             => $cr,
                'status'         => $status,
                'scheduled_date' => $scheduledDate,
                'notes'          => $notes,
            ];

            $changedFields = [];
            foreach ($newValuesByColumn as $columnKey => $newVal) {
                $oldValStr = $columnKey === 'assigned_to'
                    ? trim((string) ($oldRecord['assigned_to_name'] ?? ''))
                    : trim((string) ($oldRecord[$columnKey] ?? ''));
                $newValStr = trim((string) $newVal);
                if ($oldValStr !== $newValStr) {
                    $fieldLabel = $scheduleFieldLabels[$columnKey] ?? $columnKey;
                    $oldDisplay = $oldValStr === '' ? '(empty)' : $oldValStr;
                    $newDisplay = $newValStr === '' ? '(empty)' : $newValStr;
                    $changedFields[] = "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                }
            }

            $detailMsg = "Updated assignment: $project" . ($application !== '' ? " / $application" : '') . "\n";
            $detailMsg .= count($changedFields) > 0 ? implode("\n", $changedFields) : 'No field value changes detected.';

            logPatchHistory($pdo, $scheduleId, 'UPDATED', $currentUsername, $detailMsg);

            if ($computedStatusChanged) {
                logPatchHistory(
                    $pdo,
                    $scheduleId,
                    'STATUS_UPDATED',
                    $currentUsername,
                    "Status changed: \"$oldComputedStatus\" -> \"$newComputedStatus\" (auto-computed from server statuses)"
                );
            }

            redirectPatching($year, $quarter, 'pt_success', 'Assignment updated.');
        }
    }

    /*
    |--------------------------------------------------------------------------
    | QUICK STATUS
    |--------------------------------------------------------------------------
    |
    | Status used to be hand-editable here via a quick per-row dropdown
    | (form_action = update_status). It no longer is: the assignment's
    | Status is always derived from where its own selected servers stand
    | -- see patchingRecomputeScheduleStatus() in config/patching_db.php,
    | which runs after every server save, schedule save, and CSV import.
    | There is deliberately no POST handler left that accepts a status
    | value from the client.
    */

    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($formAction === 'delete_schedule') {

        if (!$canDelete) {
            http_response_code(403);
            exit('You do not have permission to delete patching assignments.');
        }

        $scheduleId = (int) ($_POST['schedule_id'] ?? 0);
        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        $delLookup = $pdo->prepare("SELECT project, application, support_level FROM patch_schedules WHERE id = ?");
        $delLookup->execute([$scheduleId]);
        $delRow = $delLookup->fetch(PDO::FETCH_ASSOC);

        $pdo->prepare("DELETE FROM patch_schedules WHERE id = ?")->execute([$scheduleId]);

        if ($delRow) {
            logPatchHistory(
                $pdo,
                $scheduleId,
                'DELETED',
                $currentUsername,
                'Deleted assignment: ' . $delRow['project'] . ($delRow['application'] ? ' / ' . $delRow['application'] : '') . ' (' . $delRow['support_level'] . ')'
            );
        }

        redirectPatching($year, $quarter, 'pt_success', 'Assignment deleted.');
    }

    /*
    |--------------------------------------------------------------------------
    | CLONE NEXT QUARTER
    |--------------------------------------------------------------------------
    */

    if ($formAction === 'clone_schedule') {

        if (!$canEdit) {
            http_response_code(403);
            exit('You do not have permission to clone patching assignments.');
        }

        $scheduleId = (int) ($_POST['schedule_id'] ?? 0);
        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        $stmt = $pdo->prepare("SELECT * FROM patch_schedules WHERE id = ?");
        $stmt->execute([$scheduleId]);
        $source = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$source) {
            redirectPatching($year, $quarter, 'pt_error', 'Assignment not found.');
        }

        $nextQuarter = (int) $source['quarter'] + 1;
        $nextYear = (int) $source['year'];

        if ($nextQuarter > 4) {
            $nextQuarter = 1;
            $nextYear++;
        }

        $exists = $pdo->prepare("
            SELECT id FROM patch_schedules
            WHERE year = ? AND quarter = ? AND project = ? AND application = ? AND support_level = ?
        ");
        $exists->execute([$nextYear, $nextQuarter, $source['project'], $source['application'], $source['support_level']]);

        if ($exists->fetch()) {
            redirectPatching($year, $quarter, 'pt_error', 'That project/application is already scheduled for the next cycle.');
        }

        $insert = $pdo->prepare("
            INSERT INTO patch_schedules
            (year, quarter, project, application, support_level, assigned_to, cr, status, scheduled_date, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, '', 'Assigned', NULL, ?, ?)
        ");

        $insert->execute([
            $nextYear, $nextQuarter, $source['project'], $source['application'],
            $source['support_level'], $source['assigned_to'], $source['notes'], $currentUserId
        ]);

        $newScheduleId = (int) $pdo->lastInsertId();

        /*
         * Clone selected server assignments into the new cycle,
         * but reset patch progress.
         */
        $serverRows = $pdo->prepare("
            SELECT hostname, selected, assigned_to
            FROM patch_schedule_servers
            WHERE schedule_id = ? AND selected = 1
        ");
        $serverRows->execute([$scheduleId]);
        $serverRows = $serverRows->fetchAll(PDO::FETCH_ASSOC);

        if ($serverRows) {
            /*
             * last_kernel_patch is snapshotted fresh from inventory rather
             * than cloned: the new cycle's "kernel before this quarter's
             * patch" is whatever the host runs now, which is precisely the
             * result of the cycle being cloned from.
             */
            $cloneServer = $pdo->prepare("
                INSERT INTO patch_schedule_servers
                (schedule_id, hostname, selected, assigned_to, patch_date, status, comment, cr, last_kernel_patch, updated_by, updated_at)
                VALUES (?, ?, 1, ?, NULL, '', '', '', ?, ?, CURRENT_TIMESTAMP)
            ");

            $cloneKernel = $pdo->prepare("SELECT kernel_version FROM inventory WHERE hostname = ? LIMIT 1");

            foreach ($serverRows as $server) {
                $cloneKernel->execute([$server['hostname']]);
                $cloneKernelVersion = (string) ($cloneKernel->fetchColumn() ?: '');

                $cloneServer->execute([
                    $newScheduleId,
                    $server['hostname'],
                    $server['assigned_to'],
                    $cloneKernelVersion,
                    $currentUserId,
                ]);
            }
        }

        logPatchHistory(
            $pdo,
            $scheduleId,
            'CLONED',
            $currentUsername,
            "Cloned to Q{$nextQuarter} {$nextYear} (new assignment #{$newScheduleId})"
        );
        logPatchHistory(
            $pdo,
            $newScheduleId,
            'CREATED',
            $currentUsername,
            "Created by cloning assignment #{$scheduleId} from Q{$quarter} {$year}"
        );

        redirectPatching($year, $quarter, 'pt_success', "Cloned to Q{$nextQuarter} {$nextYear}.");
    }

    /*
    |--------------------------------------------------------------------------
    | COPY ASSIGNMENTS TO ANOTHER CYCLE
    |--------------------------------------------------------------------------
    |
    | Rolls a whole quarter forward in one go: tick every assignment, or
    | just the applications wanted, pick the target cycle, and each ticked
    | line is recreated there.
    |
    | The server list of a copied assignment is NOT copied from the source
    | rows. It is re-read from inventory with the same
    | syncScheduleServersFromInventory() the create/edit paths use, so a
    | host added to inventory after the source quarter was set up is picked
    | up by the copy instead of being silently left behind.
    |
    | Progress fields (CR, status, reminder) start clean; the assignee is
    | carried over from the source unless a single override user is chosen,
    | and the scheduled date is whatever the form asked for.
    */

    if ($formAction === 'copy_to_quarter') {

        if (!$canEdit) {
            http_response_code(403);
            exit('You do not have permission to copy patching assignments.');
        }

        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        $targetYear = (int) ($_POST['target_year'] ?? 0);
        $targetQuarter = (int) ($_POST['target_quarter'] ?? 0);
        $targetDate = trim((string) ($_POST['target_scheduled_date'] ?? ''));

        /*
        | '' keeps each source row's own assignee -- the default, and what
        | "same assignee" means when several lines are copied at once. A
        | user id overrides every copied line; '0' clears the assignee.
        */
        $assigneeMode = (string) ($_POST['target_assigned_to'] ?? '');

        $sourceIds = $_POST['copy_ids'] ?? [];
        if (!is_array($sourceIds)) {
            $sourceIds = [$sourceIds];
        }

        $sourceIds = array_values(array_unique(array_filter(
            array_map('intval', $sourceIds),
            static fn(int $id): bool => $id > 0
        )));

        if ($targetYear < $ptMinYear || $targetYear > $ptMaxYear || $targetQuarter < 1 || $targetQuarter > 4) {
            redirectPatching($year, $quarter, 'pt_error', 'Pick a valid target year and quarter to copy into.');
        }

        if (!$sourceIds) {
            redirectPatching($year, $quarter, 'pt_error', 'Select at least one assignment to copy.');
        }

        if ($targetDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $targetDate)) {
            redirectPatching($year, $quarter, 'pt_error', 'The new scheduled date is not a valid date.');
        }

        $overrideAssignee = null;
        $useOverrideAssignee = false;

        if ($assigneeMode !== '') {
            $useOverrideAssignee = true;
            $overrideAssignee = (int) $assigneeMode > 0 ? (int) $assigneeMode : null;
        }

        $placeholders = implode(',', array_fill(0, count($sourceIds), '?'));
        $sourceStmt = $pdo->prepare("
            SELECT * FROM patch_schedules
            WHERE id IN ($placeholders)
            ORDER BY project, application, support_level
        ");
        $sourceStmt->execute($sourceIds);
        $sourceRows = $sourceStmt->fetchAll(PDO::FETCH_ASSOC);

        if (!$sourceRows) {
            redirectPatching($year, $quarter, 'pt_error', 'None of the selected assignments could be found.');
        }

        $existsStmt = $pdo->prepare("
            SELECT id FROM patch_schedules
            WHERE year = ? AND quarter = ? AND project = ? AND application = ? AND support_level = ?
        ");

        $insertStmt = $pdo->prepare("
            INSERT INTO patch_schedules
            (year, quarter, project, application, support_level, assigned_to, cr, status, scheduled_date, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, '', 'Assigned', ?, ?, ?)
        ");

        $copied = 0;
        $skipped = [];

        $pdo->beginTransaction();

        try {
            foreach ($sourceRows as $source) {
                $project = (string) $source['project'];
                $application = (string) $source['application'];
                $supportLevel = (string) $source['support_level'];

                /*
                | Copying a cycle onto itself would only ever collide with
                | its own rows, so it is refused up front rather than
                | reported as four hundred skips.
                */
                if ((int) $source['year'] === $targetYear && (int) $source['quarter'] === $targetQuarter) {
                    $skipped[] = ($application !== '' ? $application : $project) . ' (already in the target cycle)';
                    continue;
                }

                $existsStmt->execute([$targetYear, $targetQuarter, $project, $application, $supportLevel]);

                if ($existsStmt->fetch()) {
                    $skipped[] = ($application !== '' ? "$project / $application" : $project) . ' (already scheduled)';
                    continue;
                }

                $newAssignee = $useOverrideAssignee
                    ? $overrideAssignee
                    : ($source['assigned_to'] !== null ? (int) $source['assigned_to'] : null);

                $insertStmt->execute([
                    $targetYear,
                    $targetQuarter,
                    $project,
                    $application,
                    $supportLevel,
                    $newAssignee,
                    $targetDate !== '' ? $targetDate : null,
                    (string) $source['notes'],
                    $currentUserId,
                ]);

                $newScheduleId = (int) $pdo->lastInsertId();

                syncScheduleServersFromInventory(
                    $pdo,
                    $newScheduleId,
                    $project,
                    $application,
                    $supportLevel,
                    $newAssignee,
                    $currentUserId
                );

                logPatchHistory(
                    $pdo,
                    (int) $source['id'],
                    'COPIED',
                    $currentUsername,
                    "Copied to Q{$targetQuarter} {$targetYear} (new assignment #{$newScheduleId})"
                );
                logPatchHistory(
                    $pdo,
                    $newScheduleId,
                    'CREATED',
                    $currentUsername,
                    "Created by copying assignment #{$source['id']} from Q{$source['quarter']} {$source['year']}; "
                        . 'servers re-read from inventory'
                );

                $copied++;
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            redirectPatching($year, $quarter, 'pt_error', 'Copy failed: ' . $e->getMessage());
        }

        if ($copied === 0) {
            redirectPatching(
                $year,
                $quarter,
                'pt_error',
                'Nothing was copied - ' . implode('; ', array_slice($skipped, 0, 10))
                    . (count($skipped) > 10 ? ' and ' . (count($skipped) - 10) . ' more' : '')
            );
        }

        $message = $copied . ' assignment' . ($copied === 1 ? '' : 's')
            . " copied to Q{$targetQuarter} {$targetYear}.";

        if ($skipped) {
            $message .= ' ' . count($skipped) . ' skipped: '
                . implode('; ', array_slice($skipped, 0, 5))
                . (count($skipped) > 5 ? ' and ' . (count($skipped) - 5) . ' more' : '') . '.';
        }

        /* Land on the target cycle so the copied lines are right there. */
        redirectPatching($targetYear, $targetQuarter, 'pt_success', $message);
    }

    /*
    |--------------------------------------------------------------------------
    | ASSIGN UNASSIGNED SERVERS
    |--------------------------------------------------------------------------
    |
    | Takes the hosts the Unassigned Servers modal listed and gives each one
    | a place in the selected cycle.
    |
    | It APPENDS rather than creating a parallel schedule: a host whose
    | project + application + support level already has an assignment is
    | added to it as an extra hostname, and one whose group has no
    | assignment gets a new line. So a project that is already half
    | scheduled grows by the missing hosts instead of gaining a duplicate
    | assignment beside the one it has.
    |
    | Only hosts the modal actually offered can be saved -- the list is
    | recomputed here rather than trusted from the form, so a stale tab
    | cannot schedule a host that has since been decommissioned or already
    | picked up by someone else's save.
    */

    if ($formAction === 'assign_unassigned') {

        if (!$canEdit) {
            http_response_code(403);
            exit('You do not have permission to assign servers.');
        }

        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        if ($quarter < 1 || $quarter > 4 || $year < $ptMinYear || $year > $ptMaxYear) {
            redirectPatching($thisYear, $thisQuarter, 'pt_error', 'Invalid cycle to assign into.');
        }

        $scheduledDate = trim((string) ($_POST['scheduled_date'] ?? ''));

        if ($scheduledDate !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $scheduledDate)) {
            redirectPatching($year, $quarter, 'pt_error', 'The scheduled date is not a valid date.');
        }

        $overwriteDates = !empty($_POST['overwrite_dates']);

        $rows = $_POST['servers'] ?? [];

        if (!is_array($rows)) {
            $rows = [];
        }

        /* Recomputed, not trusted: see the note above. */
        $offered = [];
        foreach (patchingUnassignedServers($pdo, $year, $quarter) as $offeredServer) {
            $offered[strtolower(trim((string) $offeredServer['hostname']))] = $offeredServer;
        }

        $cycleSchedules = patchingCycleSchedules($pdo, $year, $quarter);

        $createSchedule = $pdo->prepare("
            INSERT INTO patch_schedules
            (year, quarter, project, application, support_level, assigned_to, cr, status, scheduled_date, notes, created_by)
            VALUES (?, ?, ?, ?, ?, ?, '', 'Assigned', ?, 'Created from Unassigned Servers', ?)
        ");

        $attachServer = $pdo->prepare("
            INSERT INTO patch_schedule_servers
            (schedule_id, hostname, selected, assigned_to, status, last_kernel_patch, updated_by, updated_at)
            VALUES (?, ?, 1, ?, '', ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(schedule_id, hostname) DO NOTHING
        ");

        $readScheduleDate = $pdo->prepare("SELECT scheduled_date FROM patch_schedules WHERE id = ?");
        $setScheduleDate = $pdo->prepare("UPDATE patch_schedules SET scheduled_date = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");

        $assignedCount = 0;
        $createdSchedules = 0;
        $datedSchedules = 0;
        $skippedHosts = 0;
        $appendedTo = [];
        $datesHandled = [];

        $pdo->beginTransaction();

        try {
            foreach ($rows as $postedHost => $rowInput) {

                if (!is_array($rowInput) || empty($rowInput['include'])) {
                    continue;
                }

                $hostKey = strtolower(trim((string) $postedHost));

                if (!isset($offered[$hostKey])) {
                    $skippedHosts++;
                    continue;
                }

                $server = $offered[$hostKey];

                $project = trim((string) $server['project']);
                $application = trim((string) $server['application']);
                $supportLevel = trim((string) $server['support_level']);

                $assignee = (int) ($rowInput['assigned_to'] ?? 0);
                $assignee = $assignee > 0 ? $assignee : null;

                [$scheduleId] = patchingFindHomeAssignment($cycleSchedules, $project, $application, $supportLevel);

                if ($scheduleId === null) {

                    $createSchedule->execute([
                        $year,
                        $quarter,
                        $project,
                        $application,
                        $supportLevel,
                        $assignee,
                        $scheduledDate !== '' ? $scheduledDate : null,
                        $currentUserId,
                    ]);

                    $scheduleId = (int) $pdo->lastInsertId();
                    $createdSchedules++;

                    /*
                     * Registered straight away so the next host of the same
                     * group joins this new line instead of creating a second
                     * one beside it.
                     */
                    $cycleSchedules[$project . '|' . $application . '|' . $supportLevel] = $scheduleId;
                    $datesHandled[$scheduleId] = true;

                    logPatchHistory(
                        $pdo,
                        $scheduleId,
                        'CREATED',
                        $currentUsername,
                        "Created from Unassigned Servers for Q{$quarter} {$year}: $project"
                            . ($application !== '' ? " / $application" : ' / all applications')
                            . ' (' . ($supportLevel !== '' ? $supportLevel : 'no support level') . ')'
                    );

                } elseif ($scheduledDate !== '' && empty($datesHandled[$scheduleId])) {

                    /*
                     * An existing assignment's date belongs to the hosts
                     * already on it, so it is only filled in when blank --
                     * unless the save explicitly asked to move it.
                     */
                    $readScheduleDate->execute([$scheduleId]);
                    $currentDate = trim((string) ($readScheduleDate->fetchColumn() ?: ''));

                    if ($overwriteDates || $currentDate === '') {
                        if ($currentDate !== $scheduledDate) {
                            $setScheduleDate->execute([$scheduledDate, $scheduleId]);
                            $datedSchedules++;
                        }
                    }

                    $datesHandled[$scheduleId] = true;
                }

                $attachServer->execute([
                    $scheduleId,
                    $server['hostname'],
                    $assignee,
                    trim((string) ($server['kernel_version'] ?? '')),
                    $currentUserId,
                ]);

                $assignedCount++;
                $appendedTo[$scheduleId] = ($appendedTo[$scheduleId] ?? 0) + 1;
            }

            foreach ($appendedTo as $touchedId => $touchedCount) {
                logPatchHistory(
                    $pdo,
                    $touchedId,
                    'UPDATED',
                    $currentUsername,
                    "Added {$touchedCount} previously unscheduled server(s) from Unassigned Servers"
                );
            }

            $pdo->commit();
        } catch (Throwable $e) {
            $pdo->rollBack();
            redirectPatching($year, $quarter, 'pt_error', 'Nothing was saved: ' . $e->getMessage());
        }

        if ($assignedCount === 0) {
            redirectPatching(
                $year,
                $quarter,
                'pt_error',
                $skippedHosts > 0
                    ? 'Nothing was saved - the ' . $skippedHosts . ' ticked host(s) are no longer unassigned. Reopen the list.'
                    : 'Nothing was saved - no servers were ticked.'
            );
        }

        $message = "{$assignedCount} server(s) assigned to Q{$quarter} {$year}.";

        if ($createdSchedules > 0) {
            $message .= " New assignments created: {$createdSchedules}.";
        }

        if ($datedSchedules > 0) {
            $message .= " Scheduled date set on {$datedSchedules} existing assignment(s).";
        }

        if ($skippedHosts > 0) {
            $message .= " {$skippedHosts} host(s) were skipped - they were no longer unassigned.";
        }

        redirectPatching($year, $quarter, 'pt_success', $message);
    }

    /*
    |--------------------------------------------------------------------------
    | SEND REMINDER NOW
    |--------------------------------------------------------------------------
    */

    if ($formAction === 'send_reminder_now') {

        if (!$canEdit) {
            http_response_code(403);
            exit('You do not have permission to send patching reminders.');
        }

        $scheduleId = (int) ($_POST['schedule_id'] ?? 0);
        $year = (int) ($_POST['year'] ?? $thisYear);
        $quarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        $stmt = $pdo->prepare("
            SELECT ps.*, u.first_name, u.last_name, u.email
            FROM patch_schedules ps
            LEFT JOIN users u ON u.id = ps.assigned_to
            WHERE ps.id = ?
        ");
        $stmt->execute([$scheduleId]);
        $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$schedule || empty($schedule['email'])) {
            redirectPatching($year, $quarter, 'pt_error', 'No assigned user with an email address on this assignment.');
        }

        $assigneeName = trim($schedule['first_name'] . ' ' . $schedule['last_name']);
        $subject = "Patch Reminder: {$schedule['project']} / {$schedule['application']}";

        $html =
            '<p>Hi ' . h($assigneeName) . ',</p>' .
            '<p>This is a reminder for the patching activity assigned to you:</p>' .
            '<table cellpadding="6" style="border-collapse:collapse;">' .
            '<tr><td><strong>Project</strong></td><td>' . h($schedule['project']) . '</td></tr>' .
            '<tr><td><strong>Application</strong></td><td>' . h($schedule['application']) . '</td></tr>' .
            '<tr><td><strong>Support Level</strong></td><td>' . h($schedule['support_level']) . '</td></tr>' .
            '<tr><td><strong>Cycle</strong></td><td>Q' . (int) $schedule['quarter'] . ' ' . (int) $schedule['year'] . '</td></tr>' .
            '<tr><td><strong>Scheduled Date</strong></td><td>' . h($schedule['scheduled_date'] ?: 'Not set') . '</td></tr>' .
            '<tr><td><strong>CR</strong></td><td>' . h($schedule['cr'] ?: '-') . '</td></tr>' .
            '<tr><td><strong>Status</strong></td><td>' . h($schedule['status']) . '</td></tr>' .
            '</table>' .
            '<p>Please review and update the patching activity in ' . h(getAppName($pdo)) . '.</p>';

        $result = sendAppMail($pdo, 'patch_reminder', $schedule['email'], $assigneeName, $subject, $html);

        if ($result['success']) {

            $pdo->prepare("UPDATE patch_schedules SET reminder_sent_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$scheduleId]);

            logPatchHistory(
                $pdo,
                $scheduleId,
                'REMINDER_SENT',
                $currentUsername,
                "Reminder email sent to {$assigneeName} <{$schedule['email']}>"
            );

            redirectPatching($year, $quarter, 'pt_success', 'Reminder email sent to ' . $schedule['email'] . '.');

        } else {
            redirectPatching($year, $quarter, 'pt_error', 'Could not send reminder: ' . $result['message']);
        }
    }

    /*
    |--------------------------------------------------------------------------
    | BULK UPLOAD (CSV) -- hostname level
    |--------------------------------------------------------------------------
    |
    | Same 23-column layout the export writes. Each row is matched to an
    | existing host in the selected cycle by Hostname and updated in place;
    | rows for a hostname that is not already scheduled in that cycle are
    | reported and skipped rather than creating anything. Hosts enter a
    | quarter from inventory, so an unmatched hostname means the CSV and
    | inventory disagree -- which is worth seeing, not worth acting on.
    |
    | Only the writable columns are read. The inventory-sourced columns,
    | the license_warranty-sourced support end date, Last_Kernel_Patch and
    | Last_Update are ignored on purpose.
    |
    */

    if ($formAction === 'upload_csv') {

        if (!$canImport) {
            http_response_code(403);
            exit('You do not have permission to import patching assignments.');
        }

        $uploadYear = (int) ($_POST['year'] ?? $thisYear);
        $uploadQuarter = (int) ($_POST['quarter'] ?? $thisQuarter);

        if ($uploadQuarter < 1 || $uploadQuarter > 4) {
            redirectPatching($uploadYear, $thisQuarter, 'pt_error', 'Please select a valid quarter to import into.');
        }

        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
            redirectPatching($uploadYear, $uploadQuarter, 'pt_error', 'Please upload a valid CSV file.');
        }

        $handle = fopen($_FILES['csv_file']['tmp_name'], 'r');
        if (!$handle) {
            redirectPatching($uploadYear, $uploadQuarter, 'pt_error', 'Unable to read the uploaded CSV file.');
        }

        $header = fgetcsv($handle);
        if (!$header) {
            fclose($handle);
            redirectPatching($uploadYear, $uploadQuarter, 'pt_error', 'CSV file is empty.');
        }

        $writableColumns = patchingWritableCsvColumns();

        $indexes = [];
        $hostnameIndex = null;

        foreach ($header as $i => $col) {
            $normalized = patchingNormalizeCsvHeader((string) $col);

            if ($normalized === 'hostname') {
                $hostnameIndex = $i;
                continue;
            }

            if (isset($writableColumns[$normalized])) {
                $indexes[$writableColumns[$normalized]] = $i;
            }
        }

        if ($hostnameIndex === null) {
            fclose($handle);
            redirectPatching($uploadYear, $uploadQuarter, 'pt_error', "CSV must contain a 'Hostname' column.");
        }

        if (!$indexes) {
            fclose($handle);
            redirectPatching(
                $uploadYear,
                $uploadQuarter,
                'pt_error',
                'CSV contains no updatable columns. Export the quarter first and edit that file.'
            );
        }

        /*
         * Hostname -> the per-server rows for it in this cycle. A host can
         * legitimately sit in two assignments of the same quarter (same
         * project, different CR), so every matching row is updated and the
         * summary counts hosts rather than rows.
         */
        $targetStmt = $pdo->prepare("
            SELECT pss.id, pss.schedule_id, pss.hostname
            FROM patch_schedule_servers pss
            INNER JOIN patch_schedules ps ON ps.id = pss.schedule_id
            WHERE ps.year = ? AND ps.quarter = ?
        ");
        $targetStmt->execute([$uploadYear, $uploadQuarter]);

        $targets = [];
        foreach ($targetStmt->fetchAll(PDO::FETCH_ASSOC) as $target) {
            $key = strtolower(trim((string) $target['hostname']));

            if ($key === '') {
                continue;
            }

            $targets[$key][] = [
                'id'          => (int) $target['id'],
                'schedule_id' => (int) $target['schedule_id'],
            ];
        }

        /*
         * An empty quarter is no longer a dead end: a row whose host is not
         * scheduled yet is onboarded below (assignment found or created,
         * host attached), so a CSV can populate a quarter from nothing.
         */

        /*
         * Assignee resolution. Email is exact; a display name is accepted
         * because that is what the export writes, but a name shared by two
         * users resolves to nothing rather than to an arbitrary one of them.
         */
        /*
         * Work out the file's date order before reading any values, by
         * sampling every date column across the whole file, then rewind to
         * the first data row. The file is read twice; these are hostname
         * lists, not bulk data.
         */
        $dateColumnFields = ['scheduled_date', 'applied_patch_release_date', 'patch_date'];
        $dateSamples = [];
        $firstDataRowOffset = ftell($handle);

        while (($sampleRow = fgetcsv($handle)) !== false) {
            foreach ($dateColumnFields as $dateColumnField) {
                if (isset($indexes[$dateColumnField])) {
                    $dateSamples[] = (string) ($sampleRow[$indexes[$dateColumnField]] ?? '');
                }
            }
        }

        if ($firstDataRowOffset !== false) {
            fseek($handle, $firstDataRowOffset);
        } else {
            rewind($handle);
            fgetcsv($handle);
        }

        $csvDayFirst = patchingDetectCsvDateOrder($dateSamples);
        $csvDateOrderDetected = $csvDayFirst !== null;

        // Day-first when the file says nothing either way.
        $csvDayFirst = $csvDayFirst ?? true;

        $userRows = $pdo->query("SELECT id, first_name, last_name, email FROM users")->fetchAll(PDO::FETCH_ASSOC);

        $assigneeLookup = [];
        $ambiguousNames = [];

        foreach ($userRows as $userRow) {
            $uid = (int) $userRow['id'];

            $userEmail = strtolower(trim((string) ($userRow['email'] ?? '')));
            if ($userEmail !== '') {
                $assigneeLookup[$userEmail] = $uid;
            }

            $userName = strtolower(trim(
                ($userRow['first_name'] ?? '') . ' ' . ($userRow['last_name'] ?? '')
            ));

            if ($userName === '') {
                continue;
            }

            if (isset($assigneeLookup[$userName]) && $assigneeLookup[$userName] !== $uid) {
                $ambiguousNames[$userName] = true;
            } else {
                $assigneeLookup[$userName] = $uid;
            }
        }

        foreach (array_keys($ambiguousNames) as $ambiguousName) {
            unset($assigneeLookup[$ambiguousName]);
        }

        $updatedHosts = 0;
        $unmatchedHosts = 0;
        $unchangedRows = 0;
        $valueWarnings = 0;
        $touchedSchedules = [];

        /*
        | Auto-onboarding.
        |
        | A CSV row for a host that is not yet scheduled in this quarter
        | gets an assignment found or created for it and is attached, so
        | uploading a file is enough to make the page show those servers.
        |
        | The assignment is resolved from INVENTORY's project and support
        | level for that host rather than from the CSV's own Project and
        | Environment cells. Inventory is the source of truth the server
        | list is built from -- an assignment created from an edited or
        | mistyped cell would not match, and syncScheduleServersFromInventory()
        | would drop the host again on the next open. (The export writes
        | i.support_level as the Environment column, so for an untouched
        | file the two agree anyway.)
        |
        | Hosts inventory does not know are skipped and named in the result:
        | the page reads IP, OS, owners and criticality from inventory, so a
        | host it has never heard of would appear as a row of blanks.
        */
        $onboardedHosts = 0;
        $createdSchedules = 0;
        $unknownHosts = [];

        /*
        | Assignment-level values carried by the CSV.
        |
        | Patch Planned Time and Assignee describe the ASSIGNMENT, not the
        | individual host -- the export writes the same value on every row
        | of an assignment. They are collected per schedule here and applied
        | once after the row loop, rather than firing an UPDATE per host.
        |
        | Planned date: first non-empty value wins; a later row of the same
        | assignment carrying a different date is counted and reported
        | rather than silently overwriting.
        |
        | Assignee: last value wins -- an assignment has a single owner, so
        | there is nothing to reconcile.
        */
        $scheduleDateUpdates = [];
        $scheduleDateConflicts = 0;
        $scheduleAssigneeUpdates = [];

        $inventoryLookup = $pdo->prepare("
            SELECT hostname, project, application, support_level, kernel_version
            FROM inventory
            WHERE LOWER(TRIM(hostname)) = ? AND managed_by = 'HCL'
            LIMIT 1
        ");

        /*
         * Prefers an existing assignment that already covers this host --
         * an all-applications one first, then an application-specific one.
         */
        $scheduleLookup = $pdo->prepare("
            SELECT id
            FROM patch_schedules
            WHERE year = ? AND quarter = ? AND project = ? AND support_level = ?
              AND (application = '' OR application IS NULL OR application = ?)
            ORDER BY CASE WHEN application = '' OR application IS NULL THEN 0 ELSE 1 END, id
            LIMIT 1
        ");

        $scheduleInsert = $pdo->prepare("
            INSERT INTO patch_schedules
                (year, quarter, project, application, support_level, assigned_to, cr, status, scheduled_date, notes, created_by)
            VALUES (?, ?, ?, '', ?, NULL, '', 'Assigned', NULL, ?, ?)
        ");

        $serverAttach = $pdo->prepare("
            INSERT INTO patch_schedule_servers
                (schedule_id, hostname, selected, last_kernel_patch, updated_by, updated_at)
            VALUES (?, ?, 1, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(schedule_id, hostname) DO NOTHING
        ");

        $attachedRowLookup = $pdo->prepare("
            SELECT id FROM patch_schedule_servers WHERE schedule_id = ? AND hostname = ? LIMIT 1
        ");

        while (($csvRow = fgetcsv($handle)) !== false) {

            if (count($csvRow) === 1 && trim((string) $csvRow[0]) === '') {
                continue;
            }

            $hostname = trim((string) ($csvRow[$hostnameIndex] ?? ''));

            if ($hostname === '') {
                continue;
            }

            $hostKey = strtolower($hostname);

            if (!isset($targets[$hostKey])) {

                $inventoryLookup->execute([$hostKey]);
                $inventoryRow = $inventoryLookup->fetch(PDO::FETCH_ASSOC);

                if (!$inventoryRow) {
                    // Not an HCL-managed host inventory knows about.
                    $unmatchedHosts++;

                    if (count($unknownHosts) < 25) {
                        $unknownHosts[] = $hostname;
                    }

                    continue;
                }

                $hostProject = (string) ($inventoryRow['project'] ?? '');
                $hostSupportLevel = (string) ($inventoryRow['support_level'] ?? '');
                $hostApplication = (string) ($inventoryRow['application'] ?? '');

                $scheduleLookup->execute([
                    $uploadYear,
                    $uploadQuarter,
                    $hostProject,
                    $hostSupportLevel,
                    $hostApplication,
                ]);

                $onboardScheduleId = (int) ($scheduleLookup->fetchColumn() ?: 0);

                if ($onboardScheduleId === 0) {

                    $scheduleInsert->execute([
                        $uploadYear,
                        $uploadQuarter,
                        $hostProject,
                        $hostSupportLevel,
                        'Created automatically by CSV import',
                        $currentUserId,
                    ]);

                    $onboardScheduleId = (int) $pdo->lastInsertId();
                    $createdSchedules++;

                    logPatchHistory(
                        $pdo,
                        $onboardScheduleId,
                        'CREATE',
                        $currentUsername,
                        'Assignment created by CSV import for Q' . $uploadQuarter . ' ' . $uploadYear
                            . ': ' . $hostProject . ' (' . ($hostSupportLevel ?: 'all support levels') . ')'
                    );
                }

                $serverAttach->execute([
                    $onboardScheduleId,
                    $inventoryRow['hostname'],
                    (string) ($inventoryRow['kernel_version'] ?? ''),
                    $currentUserId,
                ]);

                $attachedRowLookup->execute([$onboardScheduleId, $inventoryRow['hostname']]);
                $attachedRowId = (int) ($attachedRowLookup->fetchColumn() ?: 0);

                if ($attachedRowId === 0) {
                    $unmatchedHosts++;
                    continue;
                }

                $targets[$hostKey] = [[
                    'id'          => $attachedRowId,
                    'schedule_id' => $onboardScheduleId,
                ]];

                $onboardedHosts++;
            }

            $cell = function (string $field) use ($indexes, $csvRow) {
                if (!isset($indexes[$field])) {
                    return null;
                }
                return trim((string) ($csvRow[$indexes[$field]] ?? ''));
            };

            $set = [];
            $values = [];

            /*
             * Free-text fields are written through as-is, including when
             * blanked -- clearing a note in the spreadsheet has to clear it
             * here too, or the round trip is not a round trip.
             */
            foreach (
                [
                    'applied_patch',
                    'patch_level',
                    'latest_available_patch',
                    'kernel_patch_n_level',
                    'new_os_version',
                    'new_kernel_version',
                    'cr',
                    'comment',
                ]
                as $textField
            ) {
                $textValue = $cell($textField);

                if ($textValue === null) {
                    continue;
                }

                $set[] = $textField . ' = ?';
                $values[] = $textValue;
            }

            /*
             * Dates: an empty cell clears the field, a readable date is
             * stored as YYYY-MM-DD, and anything unreadable or ambiguous
             * leaves the stored value alone and is counted -- a typo or a
             * locale mix-up must not silently rewrite a real date.
             */
            foreach (['applied_patch_release_date', 'patch_date'] as $dateField) {
                $dateValue = $cell($dateField);

                if ($dateValue === null) {
                    continue;
                }

                if ($dateValue === '') {
                    $set[] = $dateField . ' = ?';
                    $values[] = null;
                    continue;
                }

                $normalizedDate = patchingNormalizeCsvDate($dateValue, $csvDayFirst);

                if ($normalizedDate === null) {
                    $valueWarnings++;
                    continue;
                }

                $set[] = $dateField . ' = ?';
                $values[] = $normalizedDate;
            }

            $statusValue = $cell('status');

            if ($statusValue !== null) {

                $matchedStatus = null;

                foreach ($patchServerStatuses as $candidateStatus) {
                    if (strcasecmp($candidateStatus, $statusValue) === 0) {
                        $matchedStatus = $candidateStatus;
                        break;
                    }
                }

                if ($matchedStatus === null) {
                    $valueWarnings++;
                } else {
                    $set[] = 'status = ?';
                    $values[] = $matchedStatus;
                }
            }

            $downtimeValue = $cell('downtime_required');

            if ($downtimeValue !== null) {

                $downtimeKey = strtolower($downtimeValue);

                if (in_array($downtimeKey, ['yes', 'y', 'true', '1', 'required'], true)) {
                    $downtimeValue = 'Yes';
                } elseif (in_array($downtimeKey, ['no', 'n', 'false', '0', 'not required'], true)) {
                    $downtimeValue = 'No';
                }

                $set[] = 'downtime_required = ?';
                $values[] = $downtimeValue;
            }

            /*
             * A blank Assignee leaves the current owner in place; clearing
             * one is explicit, via the literal "Unassigned" the export
             * itself never writes but a person reasonably might.
             */
            $assigneeValue = $cell('assignee');

            // false = this row said nothing about the assignee.
            $resolvedAssignee = false;

            if ($assigneeValue !== null && $assigneeValue !== '') {

                $assigneeKey = strtolower($assigneeValue);

                if ($assigneeKey === 'unassigned') {
                    $resolvedAssignee = null;
                    $set[] = 'assigned_to = ?';
                    $values[] = null;
                } elseif (isset($assigneeLookup[$assigneeKey])) {
                    $resolvedAssignee = $assigneeLookup[$assigneeKey];
                    $set[] = 'assigned_to = ?';
                    $values[] = $resolvedAssignee;
                } else {
                    $valueWarnings++;
                }
            }

            /*
             * Assignment-level values. Collected before the "nothing to
             * update" check below, so a file that carries only a planned
             * date or only an assignee still takes effect.
             */
            $plannedValue = $cell('scheduled_date');

            if ($plannedValue !== null && $plannedValue !== '') {

                $plannedDate = patchingNormalizeCsvDate($plannedValue, $csvDayFirst);

                if ($plannedDate === null) {
                    $valueWarnings++;
                } else {
                    foreach ($targets[$hostKey] as $target) {

                        $targetScheduleId = $target['schedule_id'];

                        if (
                            isset($scheduleDateUpdates[$targetScheduleId])
                            && $scheduleDateUpdates[$targetScheduleId] !== $plannedDate
                        ) {
                            $scheduleDateConflicts++;
                            continue;
                        }

                        $scheduleDateUpdates[$targetScheduleId] = $plannedDate;
                    }
                }
            }

            if ($resolvedAssignee !== false) {
                foreach ($targets[$hostKey] as $target) {
                    $scheduleAssigneeUpdates[$target['schedule_id']] = $resolvedAssignee;
                }
            }

            if (!$set) {
                $unchangedRows++;
                continue;
            }

            $set[] = 'updated_by = ?';
            $values[] = $currentUserId;

            $set[] = 'updated_at = CURRENT_TIMESTAMP';

            $updateStmt = $pdo->prepare(
                'UPDATE patch_schedule_servers SET ' . implode(', ', $set) . ' WHERE id = ?'
            );

            foreach ($targets[$hostKey] as $target) {
                $updateStmt->execute(array_merge($values, [$target['id']]));

                $touchedSchedules[$target['schedule_id']] =
                    ($touchedSchedules[$target['schedule_id']] ?? 0) + 1;
            }

            $updatedHosts++;
        }

        fclose($handle);

        /*
         * Apply the assignment-level values the CSV carried: the planned
         * date and the owner for that project / support level.
         */
        $scheduleDateStmt = $pdo->prepare("UPDATE patch_schedules SET scheduled_date = ? WHERE id = ?");
        $scheduleAssigneeStmt = $pdo->prepare("UPDATE patch_schedules SET assigned_to = ? WHERE id = ?");

        $scheduleDatesApplied = 0;
        $scheduleAssigneesApplied = 0;

        foreach ($scheduleDateUpdates as $dateScheduleId => $newScheduledDate) {

            $currentDateStmt = $pdo->prepare("SELECT scheduled_date FROM patch_schedules WHERE id = ?");
            $currentDateStmt->execute([$dateScheduleId]);
            $existingScheduledDate = (string) ($currentDateStmt->fetchColumn() ?: '');

            if ($existingScheduledDate === $newScheduledDate) {
                continue;
            }

            $scheduleDateStmt->execute([$newScheduledDate, $dateScheduleId]);
            $scheduleDatesApplied++;

            logPatchHistory(
                $pdo,
                $dateScheduleId,
                'BULK IMPORT',
                $currentUsername,
                'Patch planned date set to ' . $newScheduledDate . ' via CSV import'
                    . ($existingScheduledDate !== '' ? ' (was ' . $existingScheduledDate . ')' : '')
            );
        }

        foreach ($scheduleAssigneeUpdates as $assigneeScheduleId => $newAssigneeId) {

            $currentAssigneeStmt = $pdo->prepare("SELECT assigned_to FROM patch_schedules WHERE id = ?");
            $currentAssigneeStmt->execute([$assigneeScheduleId]);
            $existingAssigneeRaw = $currentAssigneeStmt->fetchColumn();

            $existingAssigneeId = ($existingAssigneeRaw === null || $existingAssigneeRaw === false)
                ? null
                : (int) $existingAssigneeRaw;

            if ($existingAssigneeId === $newAssigneeId) {
                continue;
            }

            $scheduleAssigneeStmt->execute([$newAssigneeId, $assigneeScheduleId]);
            $scheduleAssigneesApplied++;

            logPatchHistory(
                $pdo,
                $assigneeScheduleId,
                'BULK IMPORT',
                $currentUsername,
                'Assignment owner set via CSV import'
                    . ($newAssigneeId === null ? ' to Unassigned' : ' to ' . (patchingResolveAssigneeName($pdo, $newAssigneeId) ?? 'user #' . $newAssigneeId))
            );
        }

        foreach ($touchedSchedules as $touchedScheduleId => $touchedCount) {
            logPatchHistory(
                $pdo,
                $touchedScheduleId,
                'BULK IMPORT',
                $currentUsername,
                "Updated {$touchedCount} server record(s) via hostname CSV import for Q{$uploadQuarter} {$uploadYear}"
            );

            /*
             * The assignment's Status is never set by hand -- it is always
             * derived from where its own selected servers currently stand,
             * so a CSV that changed server statuses has to recompute it too.
             */
            [$oldImportStatus, $newImportStatus, $importStatusChanged] =
                patchingRecomputeScheduleStatus($pdo, $touchedScheduleId);

            if ($importStatusChanged) {
                logPatchHistory(
                    $pdo,
                    $touchedScheduleId,
                    'STATUS_UPDATED',
                    $currentUsername,
                    "Status changed: \"$oldImportStatus\" -> \"$newImportStatus\" (auto-computed from server statuses)"
                );
            }
        }

        $msg = "Import complete. Hosts updated: {$updatedHosts}";

        if ($onboardedHosts > 0) {
            $msg .= ", newly scheduled in Q{$uploadQuarter} {$uploadYear}: {$onboardedHosts}";
        }

        if ($createdSchedules > 0) {
            $msg .= ", assignments created: {$createdSchedules}";
        }

        if ($scheduleDatesApplied > 0) {
            $msg .= ", planned dates set: {$scheduleDatesApplied}";
        }

        if ($scheduleAssigneesApplied > 0) {
            $msg .= ", assignment owners set: {$scheduleAssigneesApplied}";
        }

        if ($scheduleDateConflicts > 0) {
            $msg .= ", rows with a conflicting planned date (first kept): {$scheduleDateConflicts}";
        }

        /*
         * Naming the skipped hosts matters -- "skipped: 4" on its own gives
         * no way to tell a typo from a genuinely unknown server.
         */
        if ($unmatchedHosts > 0) {
            $msg .= ", not found in Inventory as HCL-managed (skipped): {$unmatchedHosts}";

            if ($unknownHosts) {
                $msg .= ' [' . implode(', ', $unknownHosts)
                     . ($unmatchedHosts > count($unknownHosts) ? ', …' : '') . ']';
            }
        }

        if ($unchangedRows > 0) {
            $msg .= ", rows with nothing to update: {$unchangedRows}";
        }

        if ($valueWarnings > 0) {
            $msg .= ", unreadable values left unchanged: {$valueWarnings}";
        }

        /*
         * Say which way slash-dates were read. Silently guessing wrong
         * would put a real date on the wrong day with nothing on screen to
         * suggest it.
         */
        if ($dateSamples && array_filter($dateSamples, static fn($v): bool => trim((string) $v) !== '')) {
            $msg .= '. Dates like 3/7/2026 were read as '
                 . ($csvDayFirst ? 'day/month/year' : 'month/day/year')
                 . ($csvDateOrderDetected ? ' (detected from the file)' : ' (default)');
        }

        redirectPatching($uploadYear, $uploadQuarter, 'pt_success', $msg);
    }
}

/*
|--------------------------------------------------------------------------
| FLASH
|--------------------------------------------------------------------------
*/

$successMsg = $_SESSION['pt_success'] ?? '';
$errorMsg = $_SESSION['pt_error'] ?? '';
unset($_SESSION['pt_success'], $_SESSION['pt_error']);

/*
|--------------------------------------------------------------------------
| PORTAL USERS
|--------------------------------------------------------------------------
*/

$portalUsers = $pdo->query("
    SELECT id, first_name, last_name, email
    FROM users
    WHERE is_approved = 1
    ORDER BY first_name, last_name
")->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| INVENTORY COMBINATIONS
|--------------------------------------------------------------------------
*/

$comboStmt = $pdo->query("
    SELECT DISTINCT project, application, support_level
    FROM inventory
    WHERE project IS NOT NULL AND project <> ''
    ORDER BY project, application, support_level
");
$inventoryCombos = $comboStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Inventory counts
|--------------------------------------------------------------------------
*/

/*
| Two maps, because an assignment's application may be empty, which
| means "every application under this project + support level" -- the
| same rule patch_servers.php uses when it builds the server list.
|
| A single map grouped by application cannot answer that: every
| inventory row carries a concrete application, so the "all
| applications" key (project|''|support) matched nothing and such
| assignments always rendered "0 / 0 selected".
|
| Both maps are scoped to managed_by = 'HCL' to stay consistent with
| the server list and with syncScheduleServersFromInventory().
*/

$invCounts = [];
$countStmt = $pdo->query("
    SELECT project, application, support_level, COUNT(*) AS cnt
    FROM inventory
    WHERE managed_by = 'HCL'
    GROUP BY project, application, support_level
");
foreach ($countStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $key = $row['project'] . '|' . $row['application'] . '|' . $row['support_level'];
    $invCounts[$key] = (int) $row['cnt'];
}

$invCountsAllApps = [];
$countAllStmt = $pdo->query("
    SELECT project, support_level, COUNT(*) AS cnt
    FROM inventory
    WHERE managed_by = 'HCL'
    GROUP BY project, support_level
");
foreach ($countAllStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $key = $row['project'] . '|' . $row['support_level'];
    $invCountsAllApps[$key] = (int) $row['cnt'];
}

/*
|--------------------------------------------------------------------------
| Selected server counts
|--------------------------------------------------------------------------
*/

/*
| Keyed by schedule id, not by project/application/support level:
| patch_schedule_servers rows belong to one specific assignment, and
| two assignments in the same cycle can legitimately share the same
| project + application + support level (different CR, different
| assignee). Grouping on those columns merged their server counts
| and reported the combined total against each row.
*/

$selectedCounts = [];
$selectedStmt = $pdo->prepare("
    SELECT pss.schedule_id, COUNT(pss.id) AS selected_count
    FROM patch_schedules ps
    INNER JOIN patch_schedule_servers pss ON pss.schedule_id = ps.id AND pss.selected = 1
    WHERE ps.year = ? AND ps.quarter = ?
    GROUP BY pss.schedule_id
");
$selectedStmt->execute([$selectedYear, $selectedQuarter]);
foreach ($selectedStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $selectedCounts[(int) $row['schedule_id']] = (int) $row['selected_count'];
}

/*
| Per-assignment breakdown of how many of its selected servers sit in
| each status ("Completed: 3, Planned: 2, ..."), shown under the server
| count in the list so the overall Status (Completed/Partial/In Progress
| -- see patchingRecomputeScheduleStatus()) isn't the only visible signal
| of what is actually driving it. Blank status is grouped under 'Pending'
| here for display; the database keeps it as ''.
*/
/*
| Named distinctly from $statusCounts further down (that one is a totally
| different map -- assignment counts by their OWN status, for the
| dashboard stat cards -- and reusing the name here silently clobbered
| this map before the table loop ever read it).
*/
$serverStatusCounts = [];
$statusCountStmt = $pdo->prepare("
    SELECT pss.schedule_id, pss.status, COUNT(pss.id) AS status_count
    FROM patch_schedules ps
    INNER JOIN patch_schedule_servers pss ON pss.schedule_id = ps.id AND pss.selected = 1
    WHERE ps.year = ? AND ps.quarter = ?
    GROUP BY pss.schedule_id, pss.status
");
$statusCountStmt->execute([$selectedYear, $selectedQuarter]);
foreach ($statusCountStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $statusLabel = trim((string) $row['status']) !== '' ? $row['status'] : 'Pending';
    $serverStatusCounts[(int) $row['schedule_id']][$statusLabel] = (int) $row['status_count'];
}

/*
|--------------------------------------------------------------------------
| PAGINATION & SEARCH / SORTING
|--------------------------------------------------------------------------
*/

$pageSize = resolveUserPageSize($pdo, $currentUserId);

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$start = ($page - 1) * $pageSize;

// Search filters
$searchKeyword = trim($_GET['search'] ?? '');
$searchProject = trim($_GET['s_project'] ?? '');
$searchApplication = trim($_GET['s_application'] ?? '');
$searchStatus = trim($_GET['s_status'] ?? '');
$searchSupportLevel = trim($_GET['s_support_level'] ?? '');
$searchCr = trim($_GET['s_cr'] ?? '');
$searchReminder = trim($_GET['s_reminder'] ?? '');
$searchDateFrom = trim($_GET['s_date_from'] ?? '');
$searchDateTo = trim($_GET['s_date_to'] ?? '');

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $searchDateFrom)) {
    $searchDateFrom = '';
}
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $searchDateTo)) {
    $searchDateTo = '';
}

/*
| Toolbar view filters.
|
| These are query filters rather than client-side row hiding on purpose:
| the table is paginated, so hiding rows in the browser would leave a
| short page and a count that disagrees with what is on screen.
|
| f_assignee is a comma-separated list of user ids, with 0 meaning
| "unassigned", so one control covers me / one user / several / all.
*/
$hideCompleted = !empty($_GET['hide_completed']);

$assigneeFilter = [];

if (isset($_GET['f_assignee']) && trim((string) $_GET['f_assignee']) !== '') {

    foreach (explode(',', (string) $_GET['f_assignee']) as $rawAssigneeId) {

        $rawAssigneeId = trim($rawAssigneeId);

        if ($rawAssigneeId === '' || !ctype_digit($rawAssigneeId)) {
            continue;
        }

        $assigneeFilter[] = (int) $rawAssigneeId;
    }

    $assigneeFilter = array_values(array_unique($assigneeFilter));
}

// Sorting
$sortBy = trim((string) ($_GET['sort_by'] ?? 'project'));
$sortDir = trim((string) ($_GET['sort_dir'] ?? 'ASC'));

$validSortColumns = ['id', 'project', 'application', 'support_level', 'status', 'scheduled_date', 'assigned_to', 'cr'];
if (!in_array($sortBy, $validSortColumns, true)) {
    $sortBy = 'project';
}
if (!in_array($sortDir, ['ASC', 'DESC'], true)) {
    $sortDir = 'ASC';
}

$nextSortDir = ($sortDir === 'ASC') ? 'DESC' : 'ASC';

// Build WHERE clause
$whereClauses = ["ps.year = ? AND ps.quarter = ?"];
$params = [$selectedYear, $selectedQuarter];

if (!empty($searchKeyword)) {
    $whereClauses[] = "(ps.project LIKE ? OR ps.application LIKE ? OR ps.cr LIKE ?)";
    array_push($params, "%$searchKeyword%", "%$searchKeyword%", "%$searchKeyword%");
}
if (!empty($searchProject)) {
    $whereClauses[] = "ps.project LIKE ?";
    $params[] = "%$searchProject%";
}
if (!empty($searchApplication)) {
    $whereClauses[] = "ps.application LIKE ?";
    $params[] = "%$searchApplication%";
}
if (!empty($searchStatus)) {
    $whereClauses[] = "ps.status = ?";
    $params[] = $searchStatus;
}
if (!empty($searchSupportLevel)) {
    $whereClauses[] = "ps.support_level LIKE ?";
    $params[] = "%$searchSupportLevel%";
}
if (!empty($searchCr)) {
    $whereClauses[] = "ps.cr LIKE ?";
    $params[] = "%$searchCr%";
}
if (!empty($searchReminder)) {
    $reminderClause = patchingReminderWhereClause($searchReminder);
    if ($reminderClause !== null) {
        $whereClauses[] = $reminderClause;
    }
}
if ($searchDateFrom !== '') {
    $whereClauses[] = "ps.scheduled_date >= ?";
    $params[] = $searchDateFrom;
}
if ($searchDateTo !== '') {
    $whereClauses[] = "ps.scheduled_date <= ?";
    $params[] = $searchDateTo;
}

if ($hideCompleted) {
    $whereClauses[] = "ps.status <> 'Completed'";
}

if ($assigneeFilter) {
    // 0 is the "Unassigned" option in the picker.
    $assigneeWhere = patchingAssigneeWhere($assigneeFilter, $params);

    if ($assigneeWhere !== null) {
        $whereClauses[] = $assigneeWhere;
    }
}

$whereSQL = implode(" AND ", $whereClauses);

// Count total records
$countStmt = $pdo->prepare("SELECT COUNT(*) FROM patch_schedules ps WHERE $whereSQL");
$countStmt->execute($params);
$totalRecords = $countStmt->fetchColumn();
$totalPages = max(1, (int) ceil($totalRecords / $pageSize));

// Correct page if out of range
if ($page > $totalPages && $totalRecords > 0) {
    $page = $totalPages;
    $start = ($page - 1) * $pageSize;
}

/*
| Every link that reloads this page has to carry the full filter state.
| The sort links used to spell the query string out inline, once each,
| which is why adding a filter here means adding it in six places -- and
| why forgetting one silently drops the filter on sort. This builds the
| set once; callers pass only what they are changing.
*/
$patchingUrlParams = [
    'year'          => $selectedYear,
    'quarter'       => $selectedQuarter,
    'sort_by'       => $sortBy,
    'sort_dir'      => $sortDir,
    'page'          => $page,
    'search'        => $searchKeyword,
    's_project'     => $searchProject,
    's_application' => $searchApplication,
    's_status'      => $searchStatus,
    's_support_level' => $searchSupportLevel,
    's_cr'          => $searchCr,
    's_reminder'    => $searchReminder,
    's_date_from'   => $searchDateFrom,
    's_date_to'     => $searchDateTo,
];

if ($hideCompleted) {
    $patchingUrlParams['hide_completed'] = 1;
}

if ($assigneeFilter) {
    $patchingUrlParams['f_assignee'] = implode(',', $assigneeFilter);
}

$ptUrl = static function (array $overrides = []) use ($patchingUrlParams): string {
    return 'patching.php?' . http_build_query(array_merge($patchingUrlParams, $overrides));
};

/*
|--------------------------------------------------------------------------
| Schedules
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT ps.*, u.first_name, u.last_name
    FROM patch_schedules ps
    LEFT JOIN users u ON u.id = ps.assigned_to
    WHERE $whereSQL
    ORDER BY ps.`$sortBy` $sortDir
    LIMIT $pageSize OFFSET $start
");
$stmt->execute($params);
$schedules = $stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Summary (count all matching records, not just current page)
|--------------------------------------------------------------------------
*/

$statusCounts = [];
$allStmt = $pdo->prepare("
    SELECT ps.status, COUNT(*) as cnt
    FROM patch_schedules ps
    WHERE $whereSQL
    GROUP BY ps.status
");
$allStmt->execute($params);
foreach ($allStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $statusCounts[$row['status']] = (int) $row['cnt'];
}

/*
| Same filtered assignment set, but counted by HOSTNAME (selected = 1
| server rows) rather than by assignment -- one assignment can hold
| anywhere from one to hundreds of servers, so "3 assignments" and "300
| hosts" are both real answers and the stat cards below show both.
| Reuses $whereSQL/$params so this always matches whatever the toolbar's
| search/status/assignee filters are currently narrowed to.
*/
$hostStatusCounts = [];
$hostStmt = $pdo->prepare("
    SELECT pss.status, COUNT(*) as cnt
    FROM patch_schedules ps
    INNER JOIN patch_schedule_servers pss ON pss.schedule_id = ps.id AND pss.selected = 1
    WHERE $whereSQL
    GROUP BY pss.status
");
$hostStmt->execute($params);
foreach ($hostStmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $statusLabel = trim((string) $row['status']) !== '' ? $row['status'] : 'Pending';
    $hostStatusCounts[$statusLabel] = (int) $row['cnt'];
}
$totalHostCount = array_sum($hostStatusCounts);

/*
|--------------------------------------------------------------------------
| Source list for the "Copy to Quarter" modal
|--------------------------------------------------------------------------
|
| Deliberately the whole selected cycle, not $schedules -- that one is
| filtered, sorted and paginated, and copying a quarter forward should
| offer every line in it, not just the page currently on screen. The
| modal has its own filter box for narrowing down to one application.
*/

$copySourceRows = [];
$copyDefaultYear = $selectedYear;
$copyDefaultQuarter = $selectedQuarter + 1;

if ($copyDefaultQuarter > 4) {
    $copyDefaultQuarter = 1;
    $copyDefaultYear++;
}

if ($copyDefaultYear > $ptMaxYear) {
    $copyDefaultYear = $ptMaxYear;
}

if ($canEdit) {
    $copyStmt = $pdo->prepare("
        SELECT ps.id, ps.project, ps.application, ps.support_level,
               ps.assigned_to, ps.assigned_to_name, ps.scheduled_date,
               u.first_name, u.last_name
        FROM patch_schedules ps
        LEFT JOIN users u ON u.id = ps.assigned_to
        WHERE ps.year = ? AND ps.quarter = ?
        ORDER BY ps.project, ps.application, ps.support_level
    ");
    $copyStmt->execute([$selectedYear, $selectedQuarter]);
    $copySourceRows = $copyStmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
| Badge on the Unassigned Servers button. A COUNT rather than
| patchingUnassignedServers(), which builds the full row set -- that one is
| only worth running when the modal is actually opened.
*/
$unassignedCountStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM inventory i
    WHERE " . patchingEligibleWhere('i') . "
      AND LOWER(TRIM(i.hostname)) NOT IN (
          SELECT LOWER(TRIM(pss.hostname))
          FROM patch_schedule_servers pss
          INNER JOIN patch_schedules ps ON ps.id = pss.schedule_id
          WHERE ps.year = ? AND ps.quarter = ?
      )
");
$unassignedCountStmt->execute([$selectedYear, $selectedQuarter]);
$unassignedCount = (int) $unassignedCountStmt->fetchColumn();

$page_title = 'Patching Schedule | InfraVault';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/patching.css">

<style>
    /* Audit history table (used inside the History modal) --
       matches the look used elsewhere in InfraVault, added here since
       this module didn't have any history UI before. */
    .audit-table { width: 100%; font-size: 13px; border-collapse: collapse; }
    .audit-table th { text-align: left; color: #64748B; font-size: 11.5px; text-transform: uppercase; padding: 8px 10px; border-bottom: 1px solid #E5E7EB; }
    .audit-table td { padding: 10px; border-bottom: 1px solid #F1F5F9; color: #334155; vertical-align: top; }
    .audit-details { line-height: 1.5; }
    .audit-badge { padding: 3px 9px; border-radius: 6px; font-size: 11.5px; font-weight: 700; }
    .pt-empty { text-align: center; padding: 30px 10px; color: #94A3B8; font-size: 13.5px; }

    /* Picker rows inside the "Copy to Quarter" modal. */
    .pt-copy-row {
        display: flex;
        align-items: center;
        gap: 10px;
        padding: 9px 12px;
        border-bottom: 1px solid var(--border-color);
        font-size: 13px;
        color: var(--text-secondary);
        cursor: pointer;
    }
    /* Author `display:flex` above beats the UA rule for [hidden], so the
       filter's hidden rows need this to actually disappear. */
    .pt-copy-row[hidden] { display: none; }
    .pt-copy-row:last-child { border-bottom: none; }
    .pt-copy-row:hover { background: var(--hover-bg); }
    .pt-copy-app { font-weight: 700; color: var(--text-primary); }
    .pt-copy-meta { color: var(--text-muted); margin-left: auto; white-space: nowrap; }
    .pt-copy-row .pt-copy-meta + .pt-copy-meta { margin-left: 16px; }
</style>

<div class="content">

<div class="pt-page-header">
    <div>
        <h1>Patching Schedule</h1>
        <p>Schedule patching jobs, select individual servers, assign them to users, and track hostname-level progress.</p>
    </div>

    <div class="pt-header-actions">
        <?php if ($canEdit): ?>
            <button type="button" class="pt-btn pt-btn-primary" onclick="openScheduleModal()">+ Add Record</button>
            <button type="button" class="pt-btn pt-btn-info" onclick="openCopyModal()">⧉ Copy to Quarter</button>
        <?php endif; ?>

        <button type="button"
                class="pt-btn <?= $unassignedCount > 0 ? 'pt-btn-orange' : 'pt-btn-secondary' ?>"
                onclick="openUnassignedModal()"
                title="Inventory servers (HCL, live, not EOL, powered on) with no place in this cycle">
            ⚠ Unassigned Servers (<?= $unassignedCount ?>)
        </button>

        <?php if ($canImport): ?>
            <button type="button" class="pt-btn pt-btn-indigo" onclick="openUploadModal()">Import CSV</button>
        <?php endif; ?>

        <?php if ($canExport): ?>
            <?php
            $exportParams = [
                'action' => 'export_csv',
                'year' => $selectedYear,
                'quarter' => $selectedQuarter
            ];
            if (!empty($searchKeyword)) $exportParams['search'] = $searchKeyword;
            if (!empty($searchProject)) $exportParams['s_project'] = $searchProject;
            if (!empty($searchApplication)) $exportParams['s_application'] = $searchApplication;
            if (!empty($searchStatus)) $exportParams['s_status'] = $searchStatus;
            if (!empty($searchSupportLevel)) $exportParams['s_support_level'] = $searchSupportLevel;
            if (!empty($searchCr)) $exportParams['s_cr'] = $searchCr;
            if (!empty($searchReminder)) $exportParams['s_reminder'] = $searchReminder;
            if ($searchDateFrom !== '') $exportParams['s_date_from'] = $searchDateFrom;
            if ($searchDateTo !== '') $exportParams['s_date_to'] = $searchDateTo;
            // The export follows the same view the toolbar filters produce.
            if ($hideCompleted) $exportParams['hide_completed'] = 1;
            if ($assigneeFilter) $exportParams['f_assignee'] = implode(',', $assigneeFilter);
            $exportUrl = 'patching.php?' . http_build_query($exportParams);
            ?>
            <a href="<?= h($exportUrl) ?>" class="pt-btn pt-btn-indigo">Export CSV</a>
        <?php endif; ?>

        <?php if ($canAudit): ?>
            <button type="button" class="pt-btn pt-btn-orange" onclick="openHistoryModal()">⏱ History</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($successMsg): ?>
    <div class="pt-alert success"><?= h($successMsg) ?></div>
<?php endif; ?>

<?php if ($errorMsg): ?>
    <div class="pt-alert error"><?= h($errorMsg) ?></div>
<?php endif; ?>

<!-- YEAR -->
<div class="pt-year-row">
    <a href="patching.php?year=<?= $prevStripYear ?>&quarter=<?= $selectedQuarter ?>"
       class="pt-year-btn"
       title="Previous year"
       aria-label="Previous year"
       <?= $selectedYear <= $ptMinYear ? 'aria-disabled="true" style="pointer-events:none;opacity:.4;"' : '' ?>>&laquo;</a>

    <?php foreach ($yearOptions as $year): ?>
        <a href="patching.php?year=<?= $year ?>&quarter=<?= $selectedQuarter ?>" class="pt-year-btn <?= $year === $selectedYear ? 'active' : '' ?>">
            <?= $year ?>
        </a>
    <?php endforeach; ?>

    <a href="patching.php?year=<?= $nextStripYear ?>&quarter=<?= $selectedQuarter ?>"
       class="pt-year-btn"
       title="Next year"
       aria-label="Next year"
       <?= $selectedYear >= $ptMaxYear ? 'aria-disabled="true" style="pointer-events:none;opacity:.4;"' : '' ?>>&raquo;</a>
</div>

<!-- QUARTER -->
<div class="pt-quarter-row">
    <?php foreach ($quarterLabels as $qNum => [$qLabel, $qRange]): ?>
        <a href="patching.php?year=<?= $selectedYear ?>&quarter=<?= $qNum ?>" class="pt-quarter-btn <?= $qNum === $selectedQuarter ? 'active' : '' ?>">
            <?= $qLabel ?>
            <small><?= $qRange ?></small>
        </a>
    <?php endforeach; ?>
</div>

<!-- SEARCH PANEL -->
<div class="pt-panel">
    <div class="pt-panel-header" style="margin-bottom:14px;">
        <h3 class="pt-panel-title" style="margin:0;">Search &amp; Filters</h3>
        <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">
            Search Multiple Values &#9662;
        </span>
    </div>

    <form method="GET" action="patching.php" style="display:flex;gap:10px;flex-wrap:wrap;">
        <input type="hidden" name="year" value="<?= $selectedYear ?>">
        <input type="hidden" name="quarter" value="<?= $selectedQuarter ?>">
        <input type="text" name="search" class="pt-search-input" placeholder="Search project, application, CR..." value="<?= h($searchKeyword) ?>">
        <button type="submit" class="pt-btn pt-btn-primary">Search</button>
        <?php if ($searchKeyword !== '' || $searchProject !== '' || $searchApplication !== '' || $searchStatus !== '' || $searchSupportLevel !== '' || $searchCr !== '' || $searchReminder !== '' || $searchDateFrom !== '' || $searchDateTo !== ''): ?>
            <a href="patching.php?year=<?= $selectedYear ?>&quarter=<?= $selectedQuarter ?>" class="pt-btn">Clear</a>
        <?php endif; ?>
    </form>

    <div id="advancedSearchPanel" style="display:<?php echo ($searchProject !== '' || $searchApplication !== '' || $searchStatus !== '' || $searchSupportLevel !== '' || $searchCr !== '' || $searchReminder !== '' || $searchDateFrom !== '' || $searchDateTo !== '') ? 'block' : 'none'; ?>;margin-top:18px;padding:20px;background:var(--hover-bg);border-radius:10px;border:1px solid #E5E7EB;">
        <form method="GET" action="patching.php" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;">
            <input type="hidden" name="year" value="<?= $selectedYear ?>">
            <input type="hidden" name="quarter" value="<?= $selectedQuarter ?>">

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Project</label>
                <input type="text" name="s_project" class="pt-form-input" placeholder="Project..." value="<?= h($searchProject) ?>">
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Application</label>
                <input type="text" name="s_application" class="pt-form-input" placeholder="Application..." value="<?= h($searchApplication) ?>">
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Status</label>
                <select name="s_status" class="pt-form-input">
                    <option value="">All Statuses</option>
                    <?php foreach ($scheduleStatuses as $statusOpt): ?>
                        <option value="<?= h($statusOpt) ?>" <?= $searchStatus === $statusOpt ? 'selected' : '' ?>><?= h($statusOpt) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Support Level</label>
                <input type="text" name="s_support_level" class="pt-form-input" placeholder="Support level..." value="<?= h($searchSupportLevel) ?>">
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">CR</label>
                <input type="text" name="s_cr" class="pt-form-input" placeholder="Change number..." value="<?= h($searchCr) ?>">
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Reminder</label>
                <select name="s_reminder" class="pt-form-input">
                    <option value="">Any</option>
                    <option value="sent" <?= $searchReminder === 'sent' ? 'selected' : '' ?>>Sent</option>
                    <option value="due" <?= $searchReminder === 'due' ? 'selected' : '' ?>>Due</option>
                    <option value="not_due" <?= $searchReminder === 'not_due' ? 'selected' : '' ?>>Not due yet</option>
                </select>
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Scheduled From</label>
                <input type="date" name="s_date_from" class="pt-form-input" value="<?= h($searchDateFrom) ?>">
            </div>

            <div class="pt-form-group">
                <label style="font-weight:700;font-size:12px;color:#64748B;text-transform:uppercase;display:block;margin-bottom:8px;">Scheduled To</label>
                <input type="date" name="s_date_to" class="pt-form-input" value="<?= h($searchDateTo) ?>">
            </div>

            <div style="grid-column:1/-1;display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" class="pt-btn pt-btn-primary" style="flex:1;min-width:120px;">🔍 Apply Filters</button>
                <a href="patching.php?year=<?= $selectedYear ?>&quarter=<?= $selectedQuarter ?>" class="pt-btn" style="flex:1;min-width:120px;text-align:center;">↺ Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- SUMMARY -->
<div class="pt-stats">
    <div class="pt-stat-card"><span>Total Assignments</span><strong><?= $totalRecords ?></strong></div>
    <div class="pt-stat-card"><span>Completed</span><strong><?= $statusCounts['Completed'] ?? 0 ?></strong></div>
    <div class="pt-stat-card"><span>In Progress</span><strong><?= $statusCounts['In Progress'] ?? 0 ?></strong></div>
    <div class="pt-stat-card"><span>Partial</span><strong><?= $statusCounts['Partial'] ?? 0 ?></strong></div>
    <div class="pt-stat-card"><span>Not Started</span><strong><?= $statusCounts['Assigned'] ?? 0 ?></strong></div>
</div>

<!-- SUMMARY: HOSTNAMES -->
<div class="pt-stats" style="margin-top:10px;">
    <div class="pt-stat-card"><span>Total Hostnames</span><strong><?= $totalHostCount ?></strong></div>
    <div class="pt-stat-card"><span>Completed</span><strong><?= $hostStatusCounts['Completed'] ?? 0 ?></strong></div>
    <div class="pt-stat-card"><span>In Progress</span><strong><?= $hostStatusCounts['In Progress'] ?? 0 ?></strong></div>
    <?php
    /*
     * Any hostname sitting in a status other than the two headline ones
     * above -- Pending, Planned, Rescheduled, N/A, Excluded,
     * Decommissioned, To Be Decom -- gets its own card, but only when at
     * least one host is actually in it. A quarter with nothing Excluded
     * or Decommissioned shouldn't show an empty "Excluded: 0" card.
     */
    $otherHostStatuses = $hostStatusCounts;
    unset($otherHostStatuses['Completed'], $otherHostStatuses['In Progress']);
    ?>
    <?php foreach ($otherHostStatuses as $otherStatusLabel => $otherStatusCount): ?>
        <?php if ($otherStatusCount > 0): ?>
            <div class="pt-stat-card"><span><?= h($otherStatusLabel) ?></span><strong><?= $otherStatusCount ?></strong></div>
        <?php endif; ?>
    <?php endforeach; ?>
</div>

<!-- TABLE -->
<div class="pt-panel" style="padding:0;">
    <div style="padding:22px 22px 0;">
        <div class="pt-panel-header" style="margin-bottom:0;">
            <span class="pt-panel-title" style="margin-bottom:0;">Patch Schedules</span>
            <span style="color:#64748B;font-size:13px;"><?php echo (int)$totalRecords; ?> total</span>
        </div>

        <?php
        /*
         * View filters. Both reload the page with a query parameter rather
         * than hiding rows in the browser, so they work correctly with
         * pagination and are carried into the CSV export.
         */
        $assigneeFilterUsers = $pdo->query("
            SELECT id, first_name, last_name
            FROM users
            WHERE is_approved = 1
            ORDER BY first_name, last_name
        ")->fetchAll(PDO::FETCH_ASSOC);

        if (count($assigneeFilter) === 0) {
            $assigneeLabel = 'Assignee: All';
        } elseif ($assigneeFilter === [$currentUserId]) {
            $assigneeLabel = 'Assignee: Me';
        } elseif (count($assigneeFilter) === 1) {
            $assigneeLabel = 'Assignee: ' . ($assigneeFilter[0] === 0 ? 'Unassigned' : 'Selected');

            foreach ($assigneeFilterUsers as $assigneeFilterUser) {
                if ((int) $assigneeFilterUser['id'] === $assigneeFilter[0]) {
                    $assigneeLabel = 'Assignee: ' . trim(
                        $assigneeFilterUser['first_name'] . ' ' . $assigneeFilterUser['last_name']
                    );
                }
            }
        } else {
            $assigneeLabel = 'Assignee: ' . count($assigneeFilter) . ' selected';
        }
        ?>

        <div class="pt-view-filters">
            <a class="pt-btn pt-btn-ghost pt-btn-sm <?= $hideCompleted ? 'pt-filter-active' : '' ?>"
               href="<?= h($ptUrl(['hide_completed' => $hideCompleted ? null : 1, 'page' => 1])) ?>">
                <?= $hideCompleted ? 'Show Completed' : 'Hide Completed' ?>
            </a>

            <div class="pt-assignee-filter">
                <button type="button" id="ptAssigneeBtn"
                        class="pt-btn pt-btn-ghost pt-btn-sm <?= $assigneeFilter ? 'pt-filter-active' : '' ?>"
                        onclick="ptToggleAssigneePanel(event)"><?= h($assigneeLabel) ?> &#9662;</button>

                <form method="GET" action="patching.php" class="pt-assignee-panel" id="ptAssigneePanel" hidden>
                    <?php
                    foreach ($patchingUrlParams as $keepKey => $keepValue) {
                        if (in_array($keepKey, ['f_assignee', 'page'], true) || $keepValue === '' || $keepValue === null) {
                            continue;
                        }
                        echo '<input type="hidden" name="' . h($keepKey) . '" value="' . h($keepValue) . '">';
                    }
                    ?>
                    <input type="hidden" name="page" value="1">
                    <input type="hidden" name="f_assignee" id="ptAssigneeValue" value="<?= h(implode(',', $assigneeFilter)) ?>">

                    <div class="pt-assignee-panel-actions">
                        <button type="button" onclick="ptAssigneeQuick('me')">Just me</button>
                        <button type="button" onclick="ptAssigneeQuick('all')">All</button>
                    </div>

                    <label class="pt-assignee-option-row">
                        <input type="checkbox" class="pt-assignee-option" value="0"
                            <?= in_array(0, $assigneeFilter, true) ? 'checked' : '' ?>> Unassigned
                    </label>

                    <?php foreach ($assigneeFilterUsers as $assigneeFilterUser): ?>
                        <label class="pt-assignee-option-row">
                            <input type="checkbox" class="pt-assignee-option" value="<?= (int) $assigneeFilterUser['id'] ?>"
                                <?= in_array((int) $assigneeFilterUser['id'], $assigneeFilter, true) ? 'checked' : '' ?>>
                            <?= h(trim($assigneeFilterUser['first_name'] . ' ' . $assigneeFilterUser['last_name'])) ?><?= (int) $assigneeFilterUser['id'] === $currentUserId ? ' (me)' : '' ?>
                        </label>
                    <?php endforeach; ?>

                    <div class="pt-assignee-panel-actions" style="border-top:1px solid var(--border-light);border-bottom:none;padding-top:8px;margin-top:6px;margin-bottom:0;">
                        <button type="submit" class="pt-assignee-apply">Apply</button>
                    </div>
                </form>
            </div>

            <?php if ($hideCompleted || $assigneeFilter): ?>
                <a class="pt-view-filter-clear" href="<?= h($ptUrl(['hide_completed' => null, 'f_assignee' => null, 'page' => 1])) ?>">Clear filters</a>
            <?php endif; ?>
        </div>
    </div>

    <div class="pt-table-wrap">
    <table class="pt-table">
        <thead>
            <tr>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'application', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        Application
                        <?php if ($sortBy === 'application'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'support_level', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        Support Level
                        <?php if ($sortBy === 'support_level'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'assigned_to', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        Assigned To
                        <?php if ($sortBy === 'assigned_to'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'cr', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        CR
                        <?php if ($sortBy === 'cr'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'status', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        Status
                        <?php if ($sortBy === 'status'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>
                    <a href="<?= h($ptUrl(['sort_by' => 'scheduled_date', 'sort_dir' => $nextSortDir, 'page' => 1])) ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                        Scheduled Date
                        <?php if ($sortBy === 'scheduled_date'): ?>
                            <span style="color:#2563EB;"><?= $sortDir === 'ASC' ? '↑' : '↓'; ?></span>
                        <?php endif; ?>
                    </a>
                </th>
                <th>Servers</th>
                <th>Reminder</th>
                <th style="text-align:center;">Actions</th>
            </tr>
        </thead>
        <tbody>
        <?php if (!$schedules): ?>
            <tr>
                <td colspan="9" class="pt-empty">
                    No patch assignments for Q<?= $selectedQuarter ?> <?= $selectedYear ?> yet.
                </td>
            </tr>
        <?php else: ?>
            <?php foreach ($schedules as $row): ?>
                <?php
                $assigneeName = trim((string) ($row['assigned_to_name'] ?? ''));
                if ($assigneeName === '') {
                    $assigneeName = trim(($row['first_name'] ?? '') . ' ' . ($row['last_name'] ?? ''));
                }
                $canManage = $canEdit;
                $canUpdateStatus = $canEdit;

                /*
                 * An empty application means "all applications under this
                 * project + support level" -- the same rule the server
                 * list itself applies -- so it reads from the all-apps map.
                 */
                if (trim((string) $row['application']) !== '') {
                    $countKey = $row['project'] . '|' . $row['application'] . '|' . $row['support_level'];
                    $serverCount = $invCounts[$countKey] ?? 0;
                } else {
                    $countKey = $row['project'] . '|' . $row['support_level'];
                    $serverCount = $invCountsAllApps[$countKey] ?? 0;
                }

                $selectedServerCount = $selectedCounts[(int) $row['id']] ?? 0;

                $reminderBadge = 'reminder-pending';
                $reminderText = 'Not due yet';

                if (!empty($row['reminder_sent_at'])) {
                    $reminderBadge = 'reminder-sent';
                    $reminderText = 'Sent';
                } elseif (!empty($row['scheduled_date'])) {
                    $daysUntil = (strtotime($row['scheduled_date']) - strtotime(date('Y-m-d'))) / 86400;
                    if ($daysUntil <= 7) {
                        $reminderBadge = 'reminder-due';
                        $reminderText = 'Due';
                    }
                }
                ?>
                <tr>
                    <td>
                        <button type="button" class="pt-app-link" onclick="openServerModal(<?= (int) $row['id'] ?>, false)">
                            <?= h($row['application']) ?>
                        </button>
                        <span class="pt-project-tag"><?= h($row['project']) ?></span>
                    </td>

                    <td><?= h($row['support_level'] ?: '-') ?></td>
                    <td><?= h($assigneeName ?: 'Unassigned') ?></td>
                    <td><?= h($row['cr'] ?: '-') ?></td>

                    <td>
                        <span class="pt-status-select <?= statusClass($row['status']) ?>"
                              title="Computed automatically from this assignment's server statuses"><?= h($row['status']) ?></span>
                    </td>

                    <td><?= h($row['scheduled_date'] ?: '-') ?></td>

                    <td>
                        <button type="button" class="pt-server-count-link" onclick="openServerModal(<?= (int) $row['id'] ?>, <?= $canUpdateStatus ? 'true' : 'false' ?>)">
                            <?= $selectedServerCount ?> / <?= $serverCount ?> selected
                        </button>

                        <?php
                        /*
                         * Per-status breakdown of this assignment's selected
                         * servers -- the same counts that drive the computed
                         * Status badge above, made visible rather than
                         * implied by it.
                         */
                        $rowStatusCounts = $serverStatusCounts[(int) $row['id']] ?? [];
                        $statusBreakdownOrder = [
                            'Completed', 'In Progress', 'Planned', 'Rescheduled', 'Pending',
                            'N/A', 'Excluded', 'Decommissioned', 'To Be Decom',
                        ];
                        ?>
                        <?php if ($rowStatusCounts): ?>
                            <div class="pt-server-status-breakdown">
                                <?php foreach ($statusBreakdownOrder as $statusLabel): ?>
                                    <?php if (!empty($rowStatusCounts[$statusLabel])): ?>
                                        <span class="pt-server-badge <?= strtolower(str_replace(['/', ' '], '', $statusLabel)) ?>">
                                            <?= h($statusLabel) ?>: <?= (int) $rowStatusCounts[$statusLabel] ?>
                                        </span>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>
                    </td>

                    <td>
                        <span class="pt-badge <?= $reminderBadge ?>"><?= $reminderText ?></span>
                    </td>

                    <td style="text-align:center;white-space:nowrap;">
                        <div class="pt-row-actions">
                            <button type="button" class="pt-btn pt-btn-secondary pt-btn-icon" title="View Servers" aria-label="View Servers" onclick="openServerModal(<?= (int) $row['id'] ?>, false)">👁</button>

                            <?php if ($canUpdateStatus): ?>
                                <button type="button" class="pt-btn pt-btn-info pt-btn-icon" title="Edit Servers" aria-label="Edit Servers" onclick="openServerModal(<?= (int) $row['id'] ?>, true)">✏️</button>
                            <?php endif; ?>

                            <?php if ($canManage): ?>
                                <button type="button" class="pt-btn pt-btn-primary pt-btn-icon" title="Edit" aria-label="Edit" onclick='openScheduleModal(<?= json_encode($row) ?>)'>✎</button>
                                <button type="button" class="pt-btn pt-btn-info pt-btn-icon" title="Copy to another quarter" aria-label="Copy to another quarter" onclick="openCopyModal(<?= (int) $row['id'] ?>)">⧉</button>
                            <?php endif; ?>

                            <?php if ($canDelete): ?>
                                <button type="button" class="pt-btn pt-btn-danger pt-btn-icon" title="Delete" aria-label="Delete" onclick="if (confirm('Delete this assignment? This cannot be undone.')) { document.forms['deleteForm<?= (int) $row['id'] ?>'].submit(); }">🗑</button>
                                <form method="POST" id="deleteForm<?= (int) $row['id'] ?>" style="display:none;">
                                    <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
                                    <input type="hidden" name="form_action" value="delete_schedule">
                                    <input type="hidden" name="schedule_id" value="<?= (int) $row['id'] ?>">
                                    <input type="hidden" name="year" value="<?= $selectedYear ?>">
                                    <input type="hidden" name="quarter" value="<?= $selectedQuarter ?>">
                                </form>
                            <?php endif; ?>

                            <?php if ($canAudit): ?>
                                <button type="button" class="pt-btn pt-btn-orange pt-btn-icon" title="Audit History" aria-label="Audit History" onclick="openHistoryModal(<?= (int) $row['id'] ?>)">⏱</button>
                            <?php endif; ?>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
    </div>

    <!-- PAGINATION & PAGE SIZE -->
    <?php if ($totalPages > 1 || $pageSize !== 15): ?>
        <div style="padding:18px 22px;border-top:1px solid #E5E7EB;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:16px;">
            <?php
                /*
                 * Both the pager and the page-size form reuse the same
                 * preserved parameter set as the sort links, minus 'page'
                 * which each of them supplies itself.
                 */
                $patchingPagerParams = $patchingUrlParams;
                unset($patchingPagerParams['page']);
                $patchingPagerParams['page_size'] = $pageSize;
            ?>
            <?= ivPager($page, $totalPages, $patchingPagerParams,
                ['base' => 'patching.php', 'total_records' => $totalRecords ?? null, 'per_page' => $pageSize]) ?>
            <div style="display:flex;align-items:center;gap:8px;">
                <?php
                    $patching_hidden_fields = '';
                    foreach ($patchingPagerParams as $pfk => $pfv) {
                        if ($pfk === 'page_size') {
                            continue;
                        }
                        if ($pfv !== '' && $pfv !== null) {
                            $patching_hidden_fields .= '<input type="hidden" name="' . h($pfk) . '" value="' . h($pfv) . '">';
                        }
                    }
                ?>
                <?= pageSizeSelectorHtml($pageSize, $patching_hidden_fields) ?>
            </div>
        </div>
    <?php endif; ?>
</div>

</div>

<!-- =====================================================
     SCHEDULE MODAL
====================================================== -->
<div id="scheduleModal" class="pt-modal">
<div class="pt-modal-content">
    <button type="button" class="pt-modal-close" onclick="closeModal('scheduleModal')">&times;</button>
    <h2 class="pt-modal-title" id="scheduleModalTitle">New Assignment</h2>
    <p class="pt-modal-subtitle">
        Create a patching job for a project/application. Individual servers can then be selected and assigned to specific users.
    </p>

    <form method="POST" action="patching.php">
        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
        <input type="hidden" name="form_action" value="save_schedule">
        <input type="hidden" name="schedule_id" id="sch_id" value="0">

        <div class="pt-form-grid cols-3">
            <div class="pt-field">
                <label>Year</label>
                <select name="year" id="sch_year">
                    <?php foreach ($yearSelectOptions as $year): ?>
                        <option value="<?= $year ?>" <?= $year === $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-field">
                <label>Quarter</label>
                <select name="quarter" id="sch_quarter">
                    <?php foreach ($quarterLabels as $qNum => [$qLabel, $qRange]): ?>
                        <option value="<?= $qNum ?>" <?= $qNum === $selectedQuarter ? 'selected' : '' ?>><?= $qLabel ?> (<?= $qRange ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-field">
                <label>Status</label>
                <select name="status" id="sch_status" disabled>
                    <?php foreach ($scheduleStatuses as $statusOption): ?>
                        <option value="<?= h($statusOption) ?>"><?= h($statusOption) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>Computed automatically from this assignment's server statuses -- not editable here.</small>
            </div>
        </div>

        <div class="pt-form-grid">
            <div class="pt-field">
                <label>Project *</label>
                <select name="project" id="sch_project" required onchange="onProjectChange()">
                    <option value="">-- Select Project --</option>
                    <?php foreach (array_unique(array_column($inventoryCombos, 'project')) as $projectName): ?>
                        <option value="<?= h($projectName) ?>"><?= h($projectName) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-field">
                <label>Application</label>
                <select name="application" id="sch_application" onchange="onApplicationChange()">
                    <option value="">-- All Applications --</option>
                </select>
            </div>
        </div>

        <div class="pt-form-grid">
            <div class="pt-field">
                <label>Support Level *</label>
                <select name="support_level" id="sch_support_level" required>
                    <option value="">-- Select Support Level --</option>
                </select>
            </div>

            <div class="pt-field">
                <label>Default Assignment User</label>
                <select name="assigned_to" id="sch_assigned_to">
                    <option value="0">-- Unassigned --</option>
                    <?php foreach ($portalUsers as $user): ?>
                        <option value="<?= (int) $user['id'] ?>"><?= h(trim($user['first_name'] . ' ' . $user['last_name'])) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>This is the schedule-level default. Individual servers can be assigned to different users.</small>
            </div>
        </div>

        <div class="pt-form-grid">
            <div class="pt-field">
                <label>CR</label>
                <input type="text" name="cr" id="sch_cr" placeholder="Change Request number">
            </div>

            <div class="pt-field">
                <label>Scheduled Date</label>
                <input type="date" name="scheduled_date" id="sch_date">
            </div>
        </div>

        <div class="pt-field full">
            <label>Notes</label>
            <textarea name="notes" id="sch_notes" rows="3" placeholder="Optional notes for this cycle"></textarea>
        </div>

        <div class="pt-modal-footer-row">
            <button type="button" class="pt-btn pt-btn-secondary" onclick="closeModal('scheduleModal')">Cancel</button>
            <button type="submit" class="pt-btn pt-btn-primary">Save Assignment</button>
        </div>
    </form>
</div>
</div>

<!-- =====================================================
     COPY TO QUARTER MODAL
====================================================== -->
<?php if ($canEdit): ?>
<div id="copyModal" class="pt-modal">
<div class="pt-modal-content wide">
    <button type="button" class="pt-modal-close" onclick="closeModal('copyModal')">&times;</button>
    <h2 class="pt-modal-title">Copy Assignments to Another Quarter</h2>
    <p class="pt-modal-subtitle">
        Copies the ticked lines from <strong>Q<?= (int) $selectedQuarter ?> <?= (int) $selectedYear ?></strong>
        into the cycle chosen below. Each copy starts clean &mdash; no CR, status back to
        <em>Assigned</em>, no reminder sent &mdash; and its server list is re-read from
        <strong>Inventory</strong> rather than copied, so hosts added to Inventory since the
        source quarter was set up are included automatically.
        Lines already scheduled in the target cycle are skipped and named.
    </p>

    <form method="POST" action="patching.php" id="copyForm">
        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
        <input type="hidden" name="form_action" value="copy_to_quarter">
        <input type="hidden" name="year" value="<?= $selectedYear ?>">
        <input type="hidden" name="quarter" value="<?= $selectedQuarter ?>">

        <div class="pt-form-grid cols-3">
            <div class="pt-field">
                <label>Copy Into Year</label>
                <select name="target_year" id="copy_target_year">
                    <?php foreach ($yearSelectOptions as $year): ?>
                        <option value="<?= $year ?>" <?= $year === $copyDefaultYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-field">
                <label>Copy Into Quarter</label>
                <select name="target_quarter" id="copy_target_quarter">
                    <?php foreach ($quarterLabels as $qNum => [$qLabel, $qRange]): ?>
                        <option value="<?= $qNum ?>" <?= $qNum === $copyDefaultQuarter ? 'selected' : '' ?>><?= $qLabel ?> (<?= $qRange ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="pt-field">
                <label>New Scheduled Date</label>
                <input type="date" name="target_scheduled_date" id="copy_target_date">
                <small>Applied to every copied line. Leave blank to schedule the dates later.</small>
            </div>
        </div>

        <div class="pt-form-grid">
            <div class="pt-field">
                <label>Assignee</label>
                <select name="target_assigned_to" id="copy_target_assignee">
                    <option value="">Keep the same assignee as the source line</option>
                    <option value="0">-- Unassigned --</option>
                    <?php foreach ($portalUsers as $user): ?>
                        <option value="<?= (int) $user['id'] ?>"><?= h(trim($user['first_name'] . ' ' . $user['last_name'])) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>Choosing a user reassigns every copied line to that user instead.</small>
            </div>

            <div class="pt-field">
                <label>Filter the list below</label>
                <input type="text" id="copyFilter" placeholder="Type an application, project or support level..." oninput="ptFilterCopyRows()">
                <small>Filtering does not untick anything &mdash; "Select all" applies to the rows on show.</small>
            </div>
        </div>

        <div class="pt-field full">
            <label style="display:flex;justify-content:space-between;align-items:center;gap:12px;">
                <span>Assignments in Q<?= (int) $selectedQuarter ?> <?= (int) $selectedYear ?></span>
                <span style="font-weight:600;color:#64748B;" id="copySelectedCount">0 selected</span>
            </label>

            <?php if (!$copySourceRows): ?>
                <p class="pt-empty">There is nothing in this cycle to copy yet.</p>
            <?php else: ?>
                <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px;">
                    <button type="button" class="pt-btn pt-btn-secondary" onclick="ptCopySelectAll(true)">Select all shown</button>
                    <button type="button" class="pt-btn pt-btn-secondary" onclick="ptCopySelectAll(false)">Clear selection</button>
                </div>

                <div id="copyRowList" style="max-height:44vh;overflow-y:auto;border:1px solid #E5E7EB;border-radius:10px;">
                    <?php foreach ($copySourceRows as $copyRow): ?>
                        <?php
                        $copyAssignee = trim((string) ($copyRow['assigned_to_name'] ?? ''));
                        if ($copyAssignee === '') {
                            $copyAssignee = trim(($copyRow['first_name'] ?? '') . ' ' . ($copyRow['last_name'] ?? ''));
                        }
                        $copySearchText = strtolower(
                            $copyRow['project'] . ' ' . $copyRow['application'] . ' '
                            . $copyRow['support_level'] . ' ' . $copyAssignee
                        );
                        ?>
                        <label class="pt-copy-row" data-search="<?= h($copySearchText) ?>">
                            <input type="checkbox" class="pt-copy-check" name="copy_ids[]" value="<?= (int) $copyRow['id'] ?>" onchange="ptUpdateCopyCount()">
                            <span class="pt-copy-app"><?= h($copyRow['application'] !== '' ? $copyRow['application'] : 'All applications') ?></span>
                            <span class="pt-project-tag"><?= h($copyRow['project']) ?></span>
                            <span class="pt-copy-meta"><?= h($copyRow['support_level'] ?: '-') ?></span>
                            <span class="pt-copy-meta"><?= h($copyAssignee !== '' ? $copyAssignee : 'Unassigned') ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="pt-modal-footer-row">
            <button type="button" class="pt-btn pt-btn-secondary" onclick="closeModal('copyModal')">Cancel</button>
            <button type="submit" class="pt-btn pt-btn-primary" <?= $copySourceRows ? '' : 'disabled' ?>>Copy Assignments</button>
        </div>
    </form>
</div>
</div>
<?php endif; ?>

<!-- =====================================================
     UNASSIGNED SERVERS MODAL

     Body is fetched from ?action=unassigned_servers -- see the note on
     that handler for why it is not rendered with the page.
====================================================== -->
<div id="unassignedModal" class="pt-modal">
<div class="pt-modal-content wide">
    <button type="button" class="pt-modal-close" onclick="closeModal('unassignedModal')">&times;</button>
    <h2 class="pt-modal-title">Unassigned Servers &mdash; Q<?= (int) $selectedQuarter ?> <?= (int) $selectedYear ?></h2>
    <p class="pt-modal-subtitle">
        Inventory servers that are <strong>Managed by HCL</strong>, <strong>Live</strong>,
        <strong>not EOL</strong> and <strong>Powered on</strong>, but hold no place in this
        cycle. Tick the ones to schedule, pick an assignee and a date, and save: a host whose
        project + application + support level already has an assignment is added to it as an
        extra hostname, and one whose group has none gets a new line.
    </p>
    <div id="unassignedModalBody">
        <p class="pt-empty">Loading&hellip;</p>
    </div>
</div>
</div>

<!-- =====================================================
     SERVER MODAL
====================================================== -->
<div id="serverModal" class="pt-modal">
<div class="pt-modal-content wide">
    <button type="button" class="pt-modal-close" onclick="closeModal('serverModal')">&times;</button>
    <h2 class="pt-modal-title" id="serverModalTitle">Servers</h2>
    <p class="pt-modal-subtitle" id="serverModalSubtitle"></p>
    <div id="serverModalBody">
        <p class="pt-server-empty">Loading…</p>
    </div>
</div>
</div>

<!-- =====================================================
     HISTORY MODAL (global + per-schedule, same modal)
====================================================== -->
<?php if ($canAudit): ?>
<div id="historyModal" class="pt-modal">
<div class="pt-modal-content wide">
    <button type="button" class="pt-modal-close" onclick="closeModal('historyModal')">&times;</button>
    <h2 class="pt-modal-title" id="historyModalTitle">Audit History</h2>
    <div id="historyModalBody" style="max-height:60vh;overflow-y:auto;">
        <p class="pt-empty">Loading…</p>
    </div>
</div>
</div>
<?php endif; ?>

<!-- =====================================================
     BULK UPLOAD MODAL
====================================================== -->
<?php if ($canImport): ?>
<div id="uploadModal" class="pt-modal">
<div class="pt-modal-content">
    <button type="button" class="pt-modal-close" onclick="closeModal('uploadModal')">&times;</button>
    <h2 class="pt-modal-title">Bulk Update Server Patching (CSV)</h2>
    <p class="pt-modal-subtitle">
        Export the quarter first, edit that file, and upload it back &mdash; the header row must
        include <strong>Hostname</strong>. Each row is matched by hostname within the cycle
        selected below and updated in place; hostnames not already scheduled in that cycle are
        skipped and reported.
    </p>
    <p class="pt-modal-subtitle">
        Updatable columns: <strong>Applied Patch</strong>, <strong>Applied Patch Release Date</strong>,
        <strong>Patch Level</strong>, <strong>Latest Available Patch Details</strong>,
        <strong>Applied Kernel Patch</strong>, <strong>New OS Version</strong>,
        <strong>Kernel Patch N Level</strong>, <strong>Q<?= (int) $selectedQuarter ?> Status</strong>,
        <strong>Q<?= (int) $selectedQuarter ?> Change Number</strong>,
        <strong>Downtime Required</strong>, <strong>Note</strong>
        and <strong>Assignee</strong>.
        <strong>Patch Planned Time</strong> and <strong>Assignee</strong> belong to the assignment
        rather than the host, so they update the whole project / support level group.
        A host that is not scheduled yet is added automatically, creating its assignment if
        needed; hosts Inventory does not know are skipped and named.
        Dates are safest as <code>YYYY-MM-DD</code>; a day-first
        date such as <code>15/08/2026</code> is also read correctly, but one where both parts
        could be a month (<code>03/04/2026</code>) is ambiguous &mdash; it is reported and the
        stored date is left alone rather than guessed at.
    </p>
    <p class="pt-modal-subtitle">
        Hostname, IP, Project, Criticality, Support Group, Environment, the owner and OS columns
        come from Inventory, <strong>Product Release Premier Support End Date</strong> comes from
        License &amp; Warranty, and <strong>Last Kernel Patch</strong> is a fixed snapshot &mdash;
        editing those in the file has no effect.
    </p>

    <form method="POST" action="patching.php" enctype="multipart/form-data">
        <input type="hidden" name="csrf_token" value="<?= h($csrfToken) ?>">
        <input type="hidden" name="form_action" value="upload_csv">

        <div class="pt-form-grid cols-3">
            <div class="pt-field">
                <label>Default Year</label>
                <select name="year">
                    <?php foreach ($yearSelectOptions as $year): ?>
                        <option value="<?= $year ?>" <?= $year === $selectedYear ? 'selected' : '' ?>><?= $year ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="pt-field">
                <label>Default Quarter</label>
                <select name="quarter">
                    <?php foreach ($quarterLabels as $qNum => [$qLabel, $qRange]): ?>
                        <option value="<?= $qNum ?>" <?= $qNum === $selectedQuarter ? 'selected' : '' ?>><?= $qLabel ?> (<?= $qRange ?>)</option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div class="pt-field full">
            <label>CSV File</label>
            <input type="file" name="csv_file" accept=".csv,text/csv" required>
        </div>

        <div class="pt-modal-footer-row">
            <button type="button" class="pt-btn pt-btn-secondary" onclick="closeModal('uploadModal')">Cancel</button>
            <button type="submit" class="pt-btn pt-btn-primary">Upload &amp; Import</button>
        </div>
    </form>
</div>
</div>
<?php endif; ?>

<script>
const inventoryCombos = <?= json_encode($inventoryCombos, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP) ?>;

function closeModal(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.classList.remove('show');
    }
}

function onProjectChange(preselectApplication, preselectSupportLevel) {
    const project = document.getElementById('sch_project').value;
    const appSelect = document.getElementById('sch_application');

    const apps = [...new Set(
        inventoryCombos
            .filter(c => c.project === project)
            .map(c => c.application)
            .filter(app => app !== '')
    )];

    appSelect.innerHTML = '<option value="">-- All Applications --</option>';

    apps.forEach(function (app) {
        const option = document.createElement('option');
        option.value = app;
        option.textContent = app;
        appSelect.appendChild(option);
    });

    if (preselectApplication && apps.includes(preselectApplication)) {
        appSelect.value = preselectApplication;
    }

    onApplicationChange(preselectSupportLevel);
}

function onApplicationChange(preselectSupportLevel) {
    const project = document.getElementById('sch_project').value;
    const application = document.getElementById('sch_application').value;
    const levelSelect = document.getElementById('sch_support_level');

    const levels = [...new Set(
        inventoryCombos
            .filter(c => c.project === project && (application === '' || c.application === application))
            .map(c => c.support_level || '')
    )];

    levelSelect.innerHTML = '<option value="">-- Select Support Level --</option>';

    levels.filter(level => level !== '').forEach(function (level) {
        const option = document.createElement('option');
        option.value = level;
        option.textContent = level;
        levelSelect.appendChild(option);
    });

    if (preselectSupportLevel !== undefined && levels.includes(preselectSupportLevel)) {
        levelSelect.value = preselectSupportLevel;
    }
}

function openScheduleModal(data) {
    const modal = document.getElementById('scheduleModal');

    if (data) {
        document.getElementById('scheduleModalTitle').innerText = 'Edit Assignment';
        document.getElementById('sch_id').value = data.id;
        document.getElementById('sch_year').value = data.year;
        document.getElementById('sch_quarter').value = data.quarter;
        document.getElementById('sch_status').value = data.status;
        document.getElementById('sch_project').value = data.project;

        onProjectChange(data.application, data.support_level || '');

        document.getElementById('sch_assigned_to').value = data.assigned_to || '0';
        document.getElementById('sch_cr').value = data.cr || '';
        document.getElementById('sch_date').value = data.scheduled_date || '';
        document.getElementById('sch_notes').value = data.notes || '';
    } else {
        document.getElementById('scheduleModalTitle').innerText = 'New Assignment';
        document.getElementById('sch_id').value = '0';
        document.getElementById('sch_year').value = <?= $selectedYear ?>;
        document.getElementById('sch_quarter').value = <?= $selectedQuarter ?>;
        document.getElementById('sch_status').value = 'Assigned';
        document.getElementById('sch_project').value = '';
        document.getElementById('sch_application').innerHTML = '<option value="">-- All Applications --</option>';
        document.getElementById('sch_support_level').innerHTML = '<option value="">-- Select Support Level --</option>';
        document.getElementById('sch_assigned_to').value = '0';
        document.getElementById('sch_cr').value = '';
        document.getElementById('sch_date').value = '';
        document.getElementById('sch_notes').value = '';
    }

    modal.classList.add('show');
}

function openServerModal(scheduleId, editable) {
    const modal = document.getElementById('serverModal');
    const body = document.getElementById('serverModalBody');

    body.innerHTML = '<p class="pt-server-empty">Loading…</p>';
    modal.classList.add('show');

    fetch('patch_servers.php?schedule_id=' + encodeURIComponent(scheduleId) + '&edit=' + (editable ? '1' : '0'))
        .then(function (res) {
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.text();
        })
        .then(function (html) {
            body.innerHTML = html;
        })
        .catch(function () {
            body.innerHTML = '<p class="pt-server-empty">Failed to load servers.</p>';
        });
}

/*
Server grid view filters.

These live here rather than in the patch_servers.php fragment because the
fragment is injected with innerHTML, which does not execute inline
scripts. State is held here too, so a filter survives the re-render that
follows a save.

The filters hide rows, they do not remove them from the form -- a hidden
row still submits its inputs and is still validated, so filtering can
never silently drop someone's edits.
*/
/*
Assignee filter panel on the schedules toolbar.

The filtering itself is done in SQL -- this only collects the ticked user
ids into the form's hidden f_assignee field and reloads the page. Doing it
in the browser instead would only filter the rows of the current page,
which is wrong as soon as the list is paginated.
*/
const PT_CURRENT_USER_ID = <?= (int) $currentUserId ?>;

function ptToggleAssigneePanel(event) {
    if (event) {
        event.stopPropagation();
    }

    const panel = document.getElementById('ptAssigneePanel');
    if (panel) {
        panel.hidden = !panel.hidden;
    }
}

/* Collect the ticked ids into the hidden field the server reads. */
function ptCollectAssignees() {
    const panel = document.getElementById('ptAssigneePanel');
    const field = document.getElementById('ptAssigneeValue');

    if (!panel || !field) {
        return;
    }

    const picked = [];

    panel.querySelectorAll('.pt-assignee-option:checked').forEach(function (box) {
        picked.push(box.value);
    });

    field.value = picked.join(',');
}

function ptAssigneeQuick(mode) {
    const panel = document.getElementById('ptAssigneePanel');

    if (!panel) {
        return;
    }

    panel.querySelectorAll('.pt-assignee-option').forEach(function (box) {
        box.checked = (mode === 'me') && parseInt(box.value, 10) === PT_CURRENT_USER_ID;
    });

    ptCollectAssignees();
    panel.submit();
}

/*
Covers the Apply button. form.submit() does not fire this event, which is
why ptAssigneeQuick() collects the values itself before calling it.
*/
document.addEventListener('submit', function (event) {
    if (event.target && event.target.id === 'ptAssigneePanel') {
        ptCollectAssignees();
    }
});

/* Click anywhere else closes the assignee panel. */
document.addEventListener('click', function (event) {
    const panel = document.getElementById('ptAssigneePanel');

    if (!panel || panel.hidden) {
        return;
    }

    if (!panel.contains(event.target) && !event.target.closest('#ptAssigneeBtn')) {
        panel.hidden = true;
    }
});

/*
Call with no argument for the full module log (toolbar button).
Call with a schedule id to scope history to just that one assignment
(per-row "History" button). Both share the same modal, both gated
server-side on can_audit.
*/
function openHistoryModal(scheduleId) {
    const modal = document.getElementById('historyModal');
    if (!modal) return;

    document.getElementById('historyModalTitle').innerText = scheduleId
        ? 'Assignment Audit History (#' + scheduleId + ')'
        : 'Patching Module Audit History';

    const body = document.getElementById('historyModalBody');
    body.innerHTML = '<p class="pt-empty">Loading…</p>';

    modal.classList.add('show');

    const url = scheduleId
        ? 'patching.php?action=get_history&schedule_id=' + encodeURIComponent(scheduleId)
        : 'patching.php?action=get_history';

    fetch(url)
        .then(function (res) { return res.text(); })
        .then(function (html) { body.innerHTML = html; })
        .catch(function () { body.innerHTML = '<p class="pt-empty">Failed to load audit history.</p>'; });
}

function openUploadModal() {
    const modal = document.getElementById('uploadModal');
    if (modal) {
        modal.classList.add('show');
    }
}

/* =====================================================================
   UNASSIGNED SERVERS

   The body arrives as HTML from ?action=unassigned_servers, so these
   handlers live here: scripts inside a fragment set with innerHTML are
   not executed by the browser. Same arrangement as the server modal.
   ===================================================================== */

function openUnassignedModal() {
    const modal = document.getElementById('unassignedModal');
    if (!modal) return;

    const body = document.getElementById('unassignedModalBody');
    body.innerHTML = '<p class="pt-empty">Loading…</p>';
    modal.classList.add('show');

    fetch('patching.php?action=unassigned_servers&year=<?= (int) $selectedYear ?>&quarter=<?= (int) $selectedQuarter ?>')
        .then(function (res) {
            if (!res.ok) {
                throw new Error('HTTP ' + res.status);
            }
            return res.text();
        })
        .then(function (html) {
            body.innerHTML = html;
            ptUpdateUnassignedCount();
        })
        .catch(function () {
            body.innerHTML = '<p class="pt-empty">Failed to load the unassigned server list.</p>';
        });
}

/* Filters the rows on show; ticks are left alone so a selection survives
   retyping the filter to reach a second project. */
function ptFilterUnassignedRows() {
    const input = document.getElementById('unassignedFilter');
    const term = input ? input.value.trim().toLowerCase() : '';

    document.querySelectorAll('#unassignedRows tr').forEach(function (row) {
        const hay = row.getAttribute('data-search') || '';
        row.hidden = term !== '' && hay.indexOf(term) === -1;
    });
}

function ptUnassignedSelectAll(checked) {
    document.querySelectorAll('#unassignedRows tr').forEach(function (row) {
        if (row.hidden) return;
        const box = row.querySelector('.pt-unassigned-check');
        if (box) box.checked = checked;
    });

    ptUpdateUnassignedCount();
}

/* Sets the assignee on the ticked rows only -- the per-row select is what
   actually posts, this just fills a lot of them at once. */
function ptApplyUnassignedBulk() {
    const picker = document.getElementById('unassignedBulkUser');

    if (!picker || picker.value === '') {
        alert('Pick a user in the "Assign ticked servers to" list first.');
        return;
    }

    let changed = 0;

    document.querySelectorAll('#unassignedRows .pt-unassigned-check:checked').forEach(function (box) {
        const row = box.closest('tr');
        if (!row) return;

        const select = row.querySelector('.pt-unassigned-user');
        if (select) {
            select.value = picker.value;
            changed++;
        }
    });

    if (changed === 0) {
        alert('Tick at least one server first.');
    }
}

function ptUpdateUnassignedCount() {
    const label = document.getElementById('unassignedCount');
    if (!label) return;

    const count = document.querySelectorAll('#unassignedRows .pt-unassigned-check:checked').length;
    label.textContent = count + ' selected';
}

document.addEventListener('submit', function (event) {
    if (!event.target || event.target.id !== 'unassignedForm') {
        return;
    }

    const count = document.querySelectorAll('#unassignedRows .pt-unassigned-check:checked').length;

    if (count === 0) {
        event.preventDefault();
        alert('Tick at least one server to assign.');
    }
});

/* =====================================================================
   COPY TO QUARTER

   Call with no argument from the toolbar (nothing pre-ticked, pick what
   to roll forward), or with a schedule id from a row's copy button, which
   opens the same modal with just that line ticked.
   ===================================================================== */

function openCopyModal(scheduleId) {
    const modal = document.getElementById('copyModal');
    if (!modal) return;

    const filter = document.getElementById('copyFilter');
    if (filter) {
        filter.value = '';
    }
    ptFilterCopyRows();

    document.querySelectorAll('#copyRowList .pt-copy-check').forEach(function (box) {
        box.checked = scheduleId !== undefined && parseInt(box.value, 10) === scheduleId;
    });

    ptUpdateCopyCount();
    modal.classList.add('show');
}

/* Narrows the visible rows; ticks are left alone so a selection survives
   retyping the filter to pick a second application. */
function ptFilterCopyRows() {
    const input = document.getElementById('copyFilter');
    const term = input ? input.value.trim().toLowerCase() : '';

    document.querySelectorAll('#copyRowList .pt-copy-row').forEach(function (row) {
        const hay = row.getAttribute('data-search') || '';
        row.hidden = term !== '' && hay.indexOf(term) === -1;
    });
}

/* Applies to the rows currently on show, so filtering to one application
   and hitting "Select all shown" ticks exactly that application. */
function ptCopySelectAll(checked) {
    document.querySelectorAll('#copyRowList .pt-copy-row').forEach(function (row) {
        if (row.hidden) return;
        const box = row.querySelector('.pt-copy-check');
        if (box) box.checked = checked;
    });

    ptUpdateCopyCount();
}

function ptUpdateCopyCount() {
    const label = document.getElementById('copySelectedCount');
    if (!label) return;

    const count = document.querySelectorAll('#copyRowList .pt-copy-check:checked').length;
    label.textContent = count + ' selected';
}

document.addEventListener('submit', function (event) {
    if (!event.target || event.target.id !== 'copyForm') {
        return;
    }

    const count = document.querySelectorAll('#copyRowList .pt-copy-check:checked').length;

    if (count === 0) {
        event.preventDefault();
        alert('Select at least one assignment to copy.');
        return;
    }

    const year = document.getElementById('copy_target_year');
    const quarter = document.getElementById('copy_target_quarter');
    const target = 'Q' + quarter.value + ' ' + year.value;

    if (!confirm('Copy ' + count + ' assignment' + (count === 1 ? '' : 's') + ' into ' + target + '?')) {
        event.preventDefault();
    }
});

/* =====================================================================
   SERVER MODAL JAVASCRIPT
   These functions live in patching.php because patch_servers.php is
   loaded dynamically with innerHTML; scripts returned by AJAX are not
   executed by the browser.
   ===================================================================== */

function updateServerRowHighlight() {
    document.querySelectorAll('#serverForm .server-checkbox').forEach(function (checkbox) {
        const row = checkbox.closest('tr');
        if (!row) return;
        row.classList.toggle('pt-server-selected', checkbox.checked);
        row.classList.toggle('pt-server-not-selected', !checkbox.checked);
    });
}

function toggleAllServers(checked) {
    document.querySelectorAll('#serverForm .server-checkbox').forEach(function (checkbox) {
        checkbox.checked = checked;
    });
    updateServerRowHighlight();
}

function applyBulkAssignment() {
    const userSelect = document.getElementById('bulkUserSelect');
    if (!userSelect) return;

    const userId = userSelect.value;
    if (!userId || userId === '0') {
        alert('Select a user first.');
        return;
    }

    const checkboxes = document.querySelectorAll('#serverForm .server-checkbox:checked');

    if (!checkboxes.length) {
        alert('Select at least one server.');
        return;
    }

    let changed = 0;
    checkboxes.forEach(function (checkbox) {
        const row = checkbox.closest('tr');
        if (!row) return;
        const select = row.querySelector('.server-assignee-select');
        if (select) {
            select.value = userId;
            changed++;
        }
    });

    if (changed > 0) {
        alert(changed + ' selected server' + (changed === 1 ? '' : 's') + ' assigned. Click "Save Changes" to commit.');
    }
}

/*
Bulk update: set one field's value once and apply it to every server row
in the grid, or just the ones ticked in the "Pick" column -- for when
several servers share the same patch, kernel version, or other value and
retyping it into each row is pointless. Purely client-side: it fills the
same rows[host][field] inputs submitServerForm() already reads, so a
save afterwards commits it the normal way.
*/
function ptBulkFillFieldChanged() {
    const field = document.getElementById('bulkFillField').value;
    const textInput = document.getElementById('bulkFillValueText');
    const dateInput = document.getElementById('bulkFillValueDate');
    const statusSelect = document.getElementById('bulkFillValueStatus');

    if (!textInput || !dateInput || !statusSelect) return;

    textInput.style.display = 'none';
    dateInput.style.display = 'none';
    statusSelect.style.display = 'none';

    if (field === 'status') {
        statusSelect.style.display = '';
    } else if (field === 'applied_patch_release_date' || field === 'patch_date') {
        dateInput.style.display = '';
    } else if (field) {
        textInput.style.display = '';
    }
}

function toggleAllBulkPicks(checked) {
    document.querySelectorAll('#serverForm .server-bulk-check').forEach(function (checkbox) {
        checkbox.checked = checked;
    });
}

function ptBulkFillApply(tickedOnly) {
    const fieldSelect = document.getElementById('bulkFillField');
    const field = fieldSelect ? fieldSelect.value : '';

    if (!field) {
        alert('Choose a field to update first.');
        return;
    }

    let value;
    if (field === 'status') {
        value = document.getElementById('bulkFillValueStatus').value;
    } else if (field === 'applied_patch_release_date' || field === 'patch_date') {
        value = document.getElementById('bulkFillValueDate').value;
    } else {
        value = document.getElementById('bulkFillValueText').value;
    }

    if (tickedOnly && !document.querySelectorAll('#serverForm .server-bulk-check:checked').length) {
        alert('Tick at least one server first, or use "Apply to All".');
        return;
    }

    let changed = 0;

    document.querySelectorAll('#serverForm [name$="[' + field + ']"]').forEach(function (input) {
        const row = input.closest('tr');
        if (!row) return;

        if (tickedOnly) {
            const pick = row.querySelector('.server-bulk-check');
            if (!pick || !pick.checked) return;
        }

        input.value = value;
        input.dispatchEvent(new Event('change', { bubbles: true }));
        changed++;
    });

    if (changed > 0) {
        alert('Updated ' + changed + ' server' + (changed === 1 ? '' : 's') + '. Click "Save Changes" to commit.');
    } else {
        alert('No matching rows to update.');
    }
}

function submitServerForm(scheduleId) {
    const form = document.getElementById('serverForm');

    if (!form) {
        alert('Server form was not found.');
        return;
    }

    /*
    The grid posts about a dozen fields per host. An assignment with a few
    hundred servers therefore blew past PHP's max_input_vars (default
    1000), and PHP does not fail that -- it SILENTLY TRUNCATES the request.
    The save looked like it worked while every row past the cut-off was
    never written.

    So the rows travel as one JSON variable instead of thousands of
    form fields: one variable regardless of how many servers there are,
    which also keeps the multipart body under max_multipart_body_parts.
    The server accepts either shape.
    */
    const rows = {};

    form.querySelectorAll('[name^="rows["]').forEach(function (field) {

        const parsed = field.name.match(/^rows\[(.+?)\]\[(.+?)\]$/);

        if (!parsed) {
            return;
        }

        const host = parsed[1];
        const key = parsed[2];

        if (!rows[host]) {
            rows[host] = {};
        }

        // An unticked checkbox posts nothing, which is how "not selected" is read.
        if (field.type === 'checkbox') {
            if (field.checked) {
                rows[host][key] = '1';
            }
            return;
        }

        rows[host][key] = field.value;
    });

    const formData = new FormData();
    formData.set('schedule_id', String(scheduleId));
    formData.set('edit_mode', '1');
    formData.set('rows_json', JSON.stringify(rows));

    const csrfInput = form.querySelector('input[name="csrf_token"]');
    if (csrfInput) {
        formData.set('csrf_token', csrfInput.value);
    }

    const saveButton = document.querySelector('#serverModal .pt-save-server-button');

    if (saveButton) {
        saveButton.disabled = true;
        saveButton.dataset.originalText = saveButton.innerText;
        saveButton.innerText = 'Saving...';
    }

    fetch('patch_servers.php', {
        method: 'POST',
        body: formData,
        credentials: 'same-origin',
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
    })
    .then(function (response) {
        return response.text().then(function (text) {
            if (!response.ok) {
                throw new Error(text || ('HTTP ' + response.status));
            }
            return text;
        });
    })
    .then(function (html) {
        const body = document.getElementById('serverModalBody');
        if (!body) {
            throw new Error('Server modal body was not found.');
        }
        body.innerHTML = html;
        updateServerRowHighlight();
    })
    .catch(function (error) {
        console.error('Patch server save error:', error);
        alert('Failed to save server changes.\n\n' + error.message);
    })
    .finally(function () {
        const currentButton = document.querySelector('#serverModal .pt-save-server-button');
        if (currentButton) {
            currentButton.disabled = false;
            currentButton.innerText = currentButton.dataset.originalText || 'Save Changes';
        }
    });
}

document.addEventListener('change', function (event) {
    if (event.target.matches('#serverForm .server-checkbox')) {
        updateServerRowHighlight();
    }
});

function toggleAdvancedSearch() {
    const panel = document.getElementById('advancedSearchPanel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
    } else {
        panel.style.display = 'none';
    }
}

window.addEventListener('click', function (event) {
    ['scheduleModal', 'serverModal', 'historyModal', 'uploadModal'].forEach(function (id) {
        const modal = document.getElementById(id);
        if (modal && event.target === modal) {
            modal.classList.remove('show');
        }
    });
});
</script>

<?php
require_once __DIR__ . '/includes/footer.php';