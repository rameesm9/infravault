<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('ip', 'can_view');
requirePermission('ip', 'can_import');



$role=$_SESSION['role'] ?? 'User';

$username=$_SESSION['name'] ?? 'Unknown';



if(
    $role!="Admin" &&
    $role!="Edit"
){

    die("Permission denied");

}




$message="";

$errors=[];

$imported=0;

$skipped=0;





/*
==================================================
CIDR CALCULATOR
==================================================
*/


function calculateNetwork($cidr){


    if(!str_contains($cidr,"/")){

        return [];

    }


    list($ip,$prefix)=explode("/",$cidr);


    $prefix=intval($prefix);



    if(!filter_var($ip,FILTER_VALIDATE_IP)){

        return [];

    }



    $ipLong=ip2long($ip);


    if($ipLong===false){

        return [];

    }



    $mask=-1 << (32-$prefix);


    $network=$ipLong & $mask;


    $broadcast=$network | (~$mask);



    $total=pow(2,32-$prefix);



    if($prefix < 31){


        $usableRange=

        long2ip($network+1)
        ." - ".
        long2ip($broadcast-1);



        $usable=$total-2;


    }
    else{


        $usableRange=

        long2ip($network)
        ." - ".
        long2ip($broadcast);



        $usable=$total;


    }



    return [

        "subnet"=>long2ip($mask),

        "broadcast"=>long2ip($broadcast),

        "total_hosts"=>$total,

        "usable_hosts"=>$usable,

        "usable_range"=>$usableRange,

        "cidr"=>$prefix

    ];

}




/*
==================================================
UPLOAD
==================================================
*/


if($_SERVER['REQUEST_METHOD']=="POST"){



if(!isset($_FILES['csv'])){


$message="CSV file required";


}
else{



$file=$_FILES['csv']['tmp_name'];




if(($handle=fopen($file,"r"))!==false){



$header=fgetcsv($handle);



while(($row=fgetcsv($handle))!==false){



$data=array_combine(
$header,
$row
);




$ip=trim($data['ip_range'] ?? '');



if(!$ip){


$skipped++;

continue;


}





/*
Duplicate check -- an existing range is replaced with the new data
rather than skipped.
*/


$stmt=$pdo->prepare("

SELECT id

FROM ip_ranges

WHERE ip_range=?

");


$stmt->execute([$ip]);


$existing_id=$stmt->fetchColumn();




/*
CIDR calculation
*/


$calc=calculateNetwork($ip);


$range_values=[

$data['vlan'] ?? '',

$calc['subnet'] ?? '',

$data['gateway'] ?? '',

$data['environment'] ?? '',

$data['project'] ?? '',

$data['portgroup'] ?? '',

$calc['cidr'] ?? '',

$calc['usable_range'] ?? '',

$calc['broadcast'] ?? '',

$calc['total_hosts'] ?? 0,

$calc['usable_hosts'] ?? 0,

$data['comments'] ?? '',

];


if($existing_id){


$stmt=$pdo->prepare("

UPDATE ip_ranges SET
vlan=?, subnet=?, gateway=?, environment=?, project=?, portgroup=?,
cidr=?, usable_range=?, broadcast=?, total_hosts=?, usable_hosts=?,
comments=?, updated_by=?, updated_at=CURRENT_TIMESTAMP
WHERE id=?

");


$stmt->execute(array_merge($range_values,[$username,$existing_id]));


$id=$existing_id;

$history_action="IMPORT";

$history_details="Replaced from CSV";


}
else{


$stmt=$pdo->prepare("

INSERT INTO ip_ranges

(
ip_range,
vlan,
subnet,
gateway,
environment,
project,
portgroup,
cidr,
usable_range,
broadcast,
total_hosts,
usable_hosts,
comments,
created_by

)

VALUES

(?,?,?,?,?,?,?,?,?,?,?,?,?,?)

");




$stmt->execute(array_merge([$ip],$range_values,[$username]));




$id=$pdo->lastInsertId();

$history_action="IMPORT";

$history_details="Imported from CSV";


}




/*
History
*/


$stmt=$pdo->prepare("

INSERT INTO ip_ranges_history

(
ip_range_id,
action_type,
performed_by,
details

)

VALUES
(?,?,?,?)

");



$stmt->execute([

$id,

$history_action,

$username,

$history_details

]);





$imported++;





}




fclose($handle);




$message=

"Import completed. Imported: "
.$imported.
" | Skipped: "
.$skipped;



}


}



}




?>



<link rel="stylesheet" href="assets/css/ip.css">


<div class="content">


<div class="ip-page">


<div class="page-header">


<div>

<h1>
Bulk IP Import
</h1>

<p>
Upload CSV file to import IP ranges
</p>

</div>


<a href="ip.php"
class="secondary-btn">

Back

</a>


</div>





<?php if($message): ?>

<div class="alert-success">

<?=$message?>

</div>

<?php endif; ?>






<div class="ip-card"
style="padding:30px">


<form method="POST"
enctype="multipart/form-data">



<label>

CSV File

</label>


<br>


<input

type="file"

name="csv"

accept=".csv"

required

>



<br><br>



<button class="primary-btn">

Import CSV

</button>


</form>




<br>


<p>

CSV format:

</p>


<pre>

ip_range,vlan,environment,project,gateway,portgroup,comments

192.168.10.0/24,100,Production,ERP,192.168.10.1,PG-ERP,Main network

</pre>



</div>


</div>


</div>
