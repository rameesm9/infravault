<?php
/**
 * Application Layout -- a tiered swimlane board.
 *
 * Structure: layout -> ordered tiers -> components -> servers.
 *
 * Stored relationally rather than as a saved picture. That is the whole
 * point of building this instead of pointing people at diagram_designer:
 * the same content can be listed, filtered and exported, and a server
 * named here joins back to `inventory` instead of being a caption that
 * silently goes stale when the estate changes.
 *
 * The board is edited in place -- tiers, components and servers are all
 * manipulated client-side and submitted as one JSON document, so a
 * layout is saved atomically rather than one row at a time.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/app-layout-helpers.php';
require_once __DIR__ . '/includes/csv-helpers.php';

requireLogin();
requirePermission('major_layouts', 'can_view');

$canEdit   = can('major_layouts', 'can_edit');
$canDelete = can('major_layouts', 'can_delete');
$canExport = can('major_layouts', 'can_export');
$canAudit  = can('major_layouts', 'can_audit');

/* DR mappings are a separate module (dr_mapping.php) keyed on application
   name. The board view joins to it read-only -- shown only if the viewer
   can also see that module, and only for applications that actually have
   a mapping, so the section is genuinely optional rather than an empty
   panel on every layout. */
$canViewDr = can('dr_mapping', 'can_view');

/* project_overview.php shows every application in a project side by side --
   linked to from here (list rows, board header) only when the viewer can
   actually see that page, same gating as the DR panel above. */
$canViewProjectOverview = can('project_overview', 'can_view');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const AL_MODULE = 'app_layout';

$statuses     = ['Active', 'Draft', 'Retired'];

/* Suggested tiers. Free text, so an unusual stack is not blocked. */
$tierPresets = ['Load Balancer', 'Web', 'Application', 'Middleware', 'Cache', 'Database', 'Storage', 'Integration', 'Batch'];
$compTypes   = ['Web Server', 'App Server', 'Database', 'Cache', 'Queue', 'Load Balancer', 'API Gateway', 'Batch Job', 'Storage', 'Other'];
$deployTypes = ['In Cluster', 'Standalone'];

/* alLoadBoard()/alTierTone()/alTierIcon()/alCompIcon()/alAppCard() live in
   includes/app-layout-helpers.php, shared with project_overview.php. */


/* ---------------- AJAX ---------------- */

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('major_layouts', 'can_audit');
    echo platformHistoryHtml($pdo, AL_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}

if (($_GET['action'] ?? '') === 'board_json') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(alLoadBoard($pdo, (int) ($_GET['id'] ?? 0)));
    exit;
}

/* Live environment lookup for one hostname (or, for a VIP row, one of a
   host's additional IPs -- see alInventoryIndex()) as it's typed into the
   editor. Same resolution alLoadBoard() already tags every saved server
   with via alAttachEnvInfo(), so a still-unsaved row previews exactly
   what it will look like once saved. */
if (($_GET['action'] ?? '') === 'lookup_env') {
    header('Content-Type: application/json; charset=utf-8');

    $entered = trim((string) ($_GET['hostname'] ?? ''));
    $match   = $entered !== '' ? (alInventoryIndex($pdo)[strtolower($entered)] ?? null) : null;
    $level   = $match['support_level'] ?? null;

    echo json_encode([
        'support_level' => $level,
        'bucket'        => alEnvBucket($level),
        'label'         => alEnvLabel($level),
        'ip_address'    => $match['ip_address'] ?? null,
        'owner'         => alOwnerCaption(['hostname' => $entered, 'matched_host' => $match['hostname'] ?? null]),
    ]);
    exit;
}

/* Layout header fields, so the editor can populate without the board. */
if (($_GET['action'] ?? '') === 'meta_json') {
    header('Content-Type: application/json; charset=utf-8');

    $s = $pdo->prepare("
        SELECT id, app_name, project, description, technical_owner, status,
               deployment_type, deployment_detail, location
        FROM app_layouts WHERE id = ?
    ");
    $s->execute([(int) ($_GET['id'] ?? 0)]);

    echo json_encode($s->fetch(PDO::FETCH_ASSOC) ?: null);
    exit;
}

/* Flat CSV: one row per server, which is what people actually want to
   paste into a change record or a spreadsheet. */
if (($_GET['action'] ?? '') === 'export') {
    requirePermission('major_layouts', 'can_export');

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=application_layout_' . date('Y-m-d') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Application', 'Project', 'Tier', 'Component', 'Component Type', 'Technology', 'Port', 'Hostname', 'Server IP', 'Server Environment', 'Server Role']);

    /* Server IP and Server Environment are read live from inventory, same as
       the board's display -- not values typed into this module, so the
       export can never disagree with what the board shows. Resolved in PHP
       via alInventoryIndex() rather than a SQL join on hostname alone,
       because a VIP row's "Hostname" cell can itself be an additional IP
       (see alAttachEnvInfo()) -- a plain hostname join would miss it. */
    $sql = "
        SELECT l.app_name, l.project,
               t.tier_name, c.component_name, c.component_type, c.technology, c.port,
               s.hostname, s.server_role
        FROM app_layouts l
        LEFT JOIN app_layout_tiers t      ON t.layout_id = l.id
        LEFT JOIN app_layout_components c ON c.tier_id = t.id
        LEFT JOIN app_layout_servers s    ON s.component_id = c.id
        ORDER BY l.app_name, t.tier_order, c.component_order, s.hostname
    ";

    $invIndex = alInventoryIndex($pdo);

    foreach ($pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC) as $row) {
        $host  = (string) ($row['hostname'] ?? '');
        $match = $host !== '' ? ($invIndex[strtolower(trim($host))] ?? null) : null;

        fputcsv($out, [
            $row['app_name'], $row['project'], $row['tier_name'], $row['component_name'],
            $row['component_type'], $row['technology'], $row['port'], $row['hostname'],
            $match['ip_address'] ?? null, $match['support_level'] ?? null, $row['server_role'],
        ]);
    }

    fclose($out);
    exit;
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('major_layouts', 'can_edit');

        $id      = (int) ($_POST['id'] ?? 0);
        $appName = trim((string) ($_POST['app_name'] ?? ''));
        $meta    = [
            'app_name'          => $appName,
            'project'           => trim((string) ($_POST['project'] ?? '')),
            'description'       => trim((string) ($_POST['description'] ?? '')),
            'technical_owner'   => trim((string) ($_POST['technical_owner'] ?? '')),
            'status'            => trim((string) ($_POST['status'] ?? 'Active')),
            'deployment_type'   => trim((string) ($_POST['deployment_type'] ?? '')),
            'deployment_detail' => trim((string) ($_POST['deployment_detail'] ?? '')),
            'location'          => trim((string) ($_POST['location'] ?? '')),
        ];

        $board = json_decode((string) ($_POST['board'] ?? '[]'), true);
        if (!is_array($board)) { $board = []; }

        if ($appName === '') {
            $err = 'Application name is required.';
        } else {
            try {
                $pdo->beginTransaction();

                if ($id > 0) {
                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($meta)));
                    $pdo->prepare("UPDATE app_layouts SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($meta), $username, $id]);
                    $action = 'UPDATED';
                } else {
                    $cols = implode(', ', array_keys($meta));
                    $ph   = implode(', ', array_fill(0, count($meta), '?'));
                    $pdo->prepare("INSERT INTO app_layouts ($cols, created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($meta), $username]);
                    $id = (int) $pdo->lastInsertId();
                    $action = 'CREATED';
                }

                /*
                 * The board is replaced rather than diffed. Tiers and
                 * components have no stable identity from the client's
                 * point of view -- they can be renamed, reordered and
                 * removed in one editing session -- so reconciling them
                 * would be considerably more code for no visible gain.
                 * ON DELETE CASCADE clears components and servers.
                 */
                $pdo->prepare("DELETE FROM app_layout_tiers WHERE layout_id = ?")->execute([$id]);

                $insTier = $pdo->prepare("INSERT INTO app_layout_tiers (layout_id, tier_name, tier_type, tier_order) VALUES (?, ?, ?, ?)");
                $insComp = $pdo->prepare("INSERT INTO app_layout_components (tier_id, component_name, component_type, technology, port, notes, component_order) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $insSrv  = $pdo->prepare("INSERT OR IGNORE INTO app_layout_servers (component_id, hostname, server_role) VALUES (?, ?, ?)");

                $tierCount = $compCount = $srvCount = 0;

                foreach (array_values($board) as $ti => $tier) {
                    $tierName = trim((string) ($tier['tier_name'] ?? ''));
                    if ($tierName === '') { continue; }

                    $insTier->execute([$id, $tierName, trim((string) ($tier['tier_type'] ?? '')), $ti]);
                    $tierId = (int) $pdo->lastInsertId();
                    $tierCount++;

                    foreach (array_values($tier['components'] ?? []) as $ci => $comp) {
                        $compName = trim((string) ($comp['component_name'] ?? ''));
                        if ($compName === '') { continue; }

                        $insComp->execute([
                            $tierId, $compName,
                            trim((string) ($comp['component_type'] ?? '')),
                            trim((string) ($comp['technology'] ?? '')),
                            trim((string) ($comp['port'] ?? '')),
                            trim((string) ($comp['notes'] ?? '')),
                            $ci,
                        ]);
                        $compId = (int) $pdo->lastInsertId();
                        $compCount++;

                        foreach (($comp['servers'] ?? []) as $srv) {
                            $host = trim((string) ($srv['hostname'] ?? ''));
                            if ($host === '') { continue; }
                            $insSrv->execute([$compId, $host, trim((string) ($srv['server_role'] ?? ''))]);
                            $srvCount++;
                        }
                    }
                }

                $pdo->commit();

                platformLog($pdo, AL_MODULE, $id, $action, $username,
                    ($action === 'CREATED' ? 'Created' : 'Updated') . " layout: {$appName}\n"
                    . "{$tierCount} tier(s), {$compCount} component(s), {$srvCount} server assignment(s)");

                $msg = 'Layout saved.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save layout: ' . $e->getMessage();
            }
        }
    }

    /*
     * Bulk CSV import, in the same flat shape as the CSV export (one row
     * per server). Layouts, tiers and components are matched by name
     * (case/whitespace-insensitive) and merged -- an existing board is
     * added to, never replaced or deleted, so a partial or repeated
     * upload can never destroy work done in the editor. A brand-new
     * application name creates a brand-new layout.
     */
    if ($formAction === 'import') {
        requirePermission('major_layouts', 'can_edit');

        $file = $_FILES['import_file'] ?? null;
        if (!$file || $file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            $err = 'Please choose a CSV file to import.';
        } else {
            $handle = fopen($file['tmp_name'], 'r');
            if (!$handle) {
                $err = 'Unable to read the uploaded file.';
            } else {
                $headerRow = fgetcsv($handle);
                if (!$headerRow) {
                    $err = 'The file appears to be empty.';
                    fclose($handle);
                } else {
                    $columnMap = [
                        'application'    => 'Application',
                        'project'        => 'Project',
                        'tier'           => 'Tier',
                        'component'      => 'Component',
                        'component_type' => 'Component Type',
                        'technology'     => 'Technology',
                        'port'           => 'Port',
                        'hostname'       => 'Hostname',
                        'server_role'    => 'Server Role',
                        // 'Server IP' and 'Server Environment' are exported
                        // for reference only -- both come live from
                        // inventory and are never written from here, so
                        // they are deliberately not mapped to a column: an
                        // unrecognised header is just ignored in the loop.
                    ];
                    $keys = csvNormaliseHeader($headerRow, $columnMap);

                    $layoutIds     = [];   // app_name (lower) => id
                    $layoutCreated = [];   // app_name (lower) => bool
                    $tierIds       = [];   // "layoutId|tier name (lower)" => id
                    $tierOrder     = [];   // layoutId => next tier_order
                    $compIds       = [];   // "tierId|component name (lower)" => id
                    $compOrder     = [];   // tierId => next component_order

                    $newLayouts = $touchedLayouts = $newTiers = $newComps = $newServers = $dupServers = $skippedRows = 0;

                    try {
                        $pdo->beginTransaction();

                        $findLayout  = $pdo->prepare("SELECT id FROM app_layouts WHERE LOWER(TRIM(app_name)) = LOWER(TRIM(?))");
                        $insLayout   = $pdo->prepare("INSERT INTO app_layouts (app_name, project, status, created_by) VALUES (?, ?, 'Active', ?)");
                        $findTier    = $pdo->prepare("SELECT id FROM app_layout_tiers WHERE layout_id = ? AND LOWER(TRIM(tier_name)) = LOWER(TRIM(?))");
                        $insTier     = $pdo->prepare("INSERT INTO app_layout_tiers (layout_id, tier_name, tier_order) VALUES (?, ?, ?)");
                        $findComp    = $pdo->prepare("SELECT id FROM app_layout_components WHERE tier_id = ? AND LOWER(TRIM(component_name)) = LOWER(TRIM(?))");
                        $insComp     = $pdo->prepare("INSERT INTO app_layout_components (tier_id, component_name, component_type, technology, port, component_order) VALUES (?, ?, ?, ?, ?, ?)");
                        $insSrv      = $pdo->prepare("INSERT OR IGNORE INTO app_layout_servers (component_id, hostname, server_role) VALUES (?, ?, ?)");
                        $maxTierOrd  = $pdo->prepare("SELECT COALESCE(MAX(tier_order), -1) FROM app_layout_tiers WHERE layout_id = ?");
                        $maxCompOrd  = $pdo->prepare("SELECT COALESCE(MAX(component_order), -1) FROM app_layout_components WHERE tier_id = ?");

                        while (($cells = fgetcsv($handle)) !== false) {
                            if (count($cells) === 1 && trim((string) $cells[0]) === '') { continue; }

                            $row = array_combine(
                                array_slice($keys, 0, count($cells)),
                                array_slice($cells, 0, count($keys))
                            ) ?: [];

                            $appName = trim((string) ($row['application'] ?? ''));
                            $tierName = trim((string) ($row['tier'] ?? ''));

                            if ($appName === '' || $tierName === '') { $skippedRows++; continue; }

                            $appKey = strtolower($appName);
                            if (!isset($layoutIds[$appKey])) {
                                $findLayout->execute([$appName]);
                                $existingId = $findLayout->fetchColumn();

                                if ($existingId) {
                                    $layoutIds[$appKey] = (int) $existingId;
                                    $layoutCreated[$appKey] = false;
                                } else {
                                    $insLayout->execute([
                                        $appName,
                                        trim((string) ($row['project'] ?? '')),
                                        $username,
                                    ]);
                                    $layoutIds[$appKey] = (int) $pdo->lastInsertId();
                                    $layoutCreated[$appKey] = true;
                                    $newLayouts++;
                                }
                                $touchedLayouts++;
                            }
                            $layoutId = $layoutIds[$appKey];

                            $tierKey = $layoutId . '|' . strtolower($tierName);
                            if (!isset($tierIds[$tierKey])) {
                                $findTier->execute([$layoutId, $tierName]);
                                $existingId = $findTier->fetchColumn();

                                if ($existingId) {
                                    $tierIds[$tierKey] = (int) $existingId;
                                } else {
                                    if (!isset($tierOrder[$layoutId])) {
                                        $maxTierOrd->execute([$layoutId]);
                                        $tierOrder[$layoutId] = ((int) $maxTierOrd->fetchColumn()) + 1;
                                    }
                                    $insTier->execute([$layoutId, $tierName, $tierOrder[$layoutId]++]);
                                    $tierIds[$tierKey] = (int) $pdo->lastInsertId();
                                    $newTiers++;
                                }
                            }
                            $tierId = $tierIds[$tierKey];

                            $compName = trim((string) ($row['component'] ?? ''));
                            if ($compName === '') { continue; }   // tier recorded, nothing else on this row

                            $compKey = $tierId . '|' . strtolower($compName);
                            if (!isset($compIds[$compKey])) {
                                $findComp->execute([$tierId, $compName]);
                                $existingId = $findComp->fetchColumn();

                                if ($existingId) {
                                    $compIds[$compKey] = (int) $existingId;
                                } else {
                                    if (!isset($compOrder[$tierId])) {
                                        $maxCompOrd->execute([$tierId]);
                                        $compOrder[$tierId] = ((int) $maxCompOrd->fetchColumn()) + 1;
                                    }
                                    $insComp->execute([
                                        $tierId, $compName,
                                        trim((string) ($row['component_type'] ?? '')),
                                        trim((string) ($row['technology'] ?? '')),
                                        trim((string) ($row['port'] ?? '')),
                                        $compOrder[$tierId]++,
                                    ]);
                                    $compIds[$compKey] = (int) $pdo->lastInsertId();
                                    $newComps++;
                                }
                            }
                            $compId = $compIds[$compKey];

                            $host = trim((string) ($row['hostname'] ?? ''));
                            if ($host === '') { continue; }

                            $insSrv->execute([$compId, $host, trim((string) ($row['server_role'] ?? ''))]);
                            if ($insSrv->rowCount() > 0) { $newServers++; } else { $dupServers++; }
                        }

                        $pdo->commit();
                        fclose($handle);

                        platformLog($pdo, AL_MODULE, null, 'IMPORTED', $username, sprintf(
                            "Bulk CSV import: %d application(s) touched (%d new), %d tier(s) added, %d component(s) added, %d server assignment(s) added%s.%s",
                            $touchedLayouts, $newLayouts, $newTiers, $newComps, $newServers,
                            $dupServers ? ", {$dupServers} already present" : '',
                            $skippedRows ? " {$skippedRows} row(s) skipped (missing Application/Tier)." : ''
                        ));

                        $msg = sprintf(
                            'Import complete: %d application(s) (%d new), %d new tier(s), %d new component(s), %d server assignment(s) added%s.%s',
                            $touchedLayouts, $newLayouts, $newTiers, $newComps, $newServers,
                            $dupServers ? " ({$dupServers} already present, skipped)" : '',
                            $skippedRows ? " {$skippedRows} row(s) skipped for missing Application/Tier." : ''
                        );

                    } catch (Throwable $e) {
                        if ($pdo->inTransaction()) { $pdo->rollBack(); }
                        if (is_resource($handle)) { fclose($handle); }
                        $err = 'Import failed: ' . $e->getMessage();
                    }
                }
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('major_layouts', 'can_delete');
        $id = (int) ($_POST['id'] ?? 0);

        $n = $pdo->prepare("SELECT app_name FROM app_layouts WHERE id = ?");
        $n->execute([$id]);
        $name = (string) ($n->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM app_layouts WHERE id = ?")->execute([$id]);
        platformLog($pdo, AL_MODULE, $id, 'DELETED', $username, "Deleted layout: {$name}");
        $msg = 'Layout deleted.';
    }
}


/* ---------------- DATA ---------------- */

$q = trim((string) ($_GET['q'] ?? ''));

$where = ['1=1'];
$params = [];
if ($q !== '') {
    $where[] = '(app_name LIKE ? OR project LIKE ? OR technical_owner LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%");
}
$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("SELECT * FROM app_layouts WHERE $whereSql ORDER BY app_name");
$stmt->execute($params);
$layouts = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Counts for the list, in three queries rather than three per row. */
$tierCounts = $compCounts = $srvCounts = [];

foreach ($pdo->query("SELECT layout_id, COUNT(*) c FROM app_layout_tiers GROUP BY layout_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $tierCounts[(int) $r['layout_id']] = (int) $r['c'];
}
foreach ($pdo->query("
    SELECT t.layout_id, COUNT(c.id) c
    FROM app_layout_tiers t LEFT JOIN app_layout_components c ON c.tier_id = t.id
    GROUP BY t.layout_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $compCounts[(int) $r['layout_id']] = (int) $r['c'];
}
foreach ($pdo->query("
    SELECT t.layout_id, COUNT(s.id) c
    FROM app_layout_tiers t
    LEFT JOIN app_layout_components c ON c.tier_id = t.id
    LEFT JOIN app_layout_servers s ON s.component_id = c.id
    GROUP BY t.layout_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $srvCounts[(int) $r['layout_id']] = (int) $r['c'];
}

/* The board currently being viewed, if any. */
$viewId = (int) ($_GET['view'] ?? 0);
$viewLayout = null;
$viewBoard = [];
$viewDrRows = [];

if ($viewId > 0) {
    $s = $pdo->prepare("SELECT * FROM app_layouts WHERE id = ?");
    $s->execute([$viewId]);
    $viewLayout = $s->fetch(PDO::FETCH_ASSOC) ?: null;
    if ($viewLayout) {
        $viewBoard = alLoadBoard($pdo, $viewId);

        /* Optional DR section: a read-only join to dr_mapping.php's own
           data, shown only when that module has something recorded for
           this application. Matched the same case/whitespace-insensitive
           way asset.php joins to inventory. */
        if ($canViewDr) {
            $d = $pdo->prepare("
                SELECT * FROM dr_mappings
                WHERE LOWER(TRIM(application)) = LOWER(TRIM(?))
                ORDER BY component_type, id
            ");
            $d->execute([$viewLayout['app_name']]);
            $viewDrRows = $d->fetchAll(PDO::FETCH_ASSOC);
        }
    }
}

$hostnames    = platformHostnames($pdo);
$additionalIps = alAdditionalIpList($pdo);

$page_title = 'Application Layout | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">
<link rel="stylesheet" href="assets/css/app-layout.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">▦</div>
            <div>
                <h1>Application Layout</h1>
                <p>Applications as tiers, components and the servers behind them — structured, not just drawn.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="alNew()">+ New Layout</button>
                <button type="button" class="plat-btn" onclick="platOpen('alImportModal')">⇪ Bulk Import</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="alHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <?php if ($viewLayout): ?>
        <!-- ============ BOARD VIEW ============ -->
        <div class="plat-panel">
            <div class="plat-panel-head">
                <div>
                    <h3><?= plat_h($viewLayout['app_name']) ?></h3>
                    <span style="font-size:12.5px;color:var(--text-muted);">
                        <?php if ($viewLayout['project'] && $canViewProjectOverview): ?>
                            <a href="project_overview.php?project=<?= urlencode($viewLayout['project']) ?>"><?= plat_h($viewLayout['project']) ?></a>
                        <?php else: ?>
                            <?= plat_h($viewLayout['project'] ?: 'No project') ?>
                        <?php endif; ?>
                        <?= $viewLayout['technical_owner'] ? ' · ' . plat_h($viewLayout['technical_owner']) : '' ?>
                        · <span class="plat-pill <?= platformStatusClass((string) $viewLayout['status']) ?>"><?= plat_h($viewLayout['status']) ?></span>
                        <?php if ($viewDrRows): ?> · <span class="plat-pill ok">⇄ DR mapped</span><?php endif; ?>
                    </span>
                </div>
                <div class="plat-actions">
                    <?php if ($canEdit): ?>
                        <button type="button" class="plat-btn plat-btn-accent plat-btn-sm" onclick="alEdit(<?= (int) $viewLayout['id'] ?>)">Edit Board</button>
                    <?php endif; ?>
                    <?php if ($canAudit): ?>
                        <button type="button" class="plat-btn plat-btn-sm" onclick="alHistory(<?= (int) $viewLayout['id'] ?>)">History</button>
                    <?php endif; ?>
                    <a class="plat-btn plat-btn-light plat-btn-sm" href="app_layout.php">Close</a>
                </div>
            </div>

            <div class="plat-panel-body">
                <?php if ($viewLayout['description']): ?>
                    <p style="color:var(--text-secondary);margin-top:0;"><?= plat_h($viewLayout['description']) ?></p>
                <?php endif; ?>

                <?php if (!$viewBoard): ?>
                    <p class="plat-empty">This layout has no tiers yet. Use <strong>Edit Board</strong> to add some.</p>
                <?php endif; ?>

                <!-- Single self-contained card: flow diagram, deployment/location
                     facts, and (only if dr_mapping.php has data for this
                     application) a DR panel inside the same card. -->
                <?php echo alAppCard($viewLayout, $viewBoard, $viewDrRows); ?>

                <?php if ($viewDrRows): ?>
                    <p style="margin-top:8px;"><a class="plat-btn plat-btn-light plat-btn-sm" href="dr_mapping.php?q=<?= urlencode($viewLayout['app_name']) ?>">Manage DR mapping →</a></p>
                <?php endif; ?>
            </div>
        </div>
    <?php endif; ?>

    <!-- ============ LIST ============ -->
    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Layouts</h3>
            <form method="GET" class="plat-filters" style="margin:0;">
                <div class="plat-field">
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Search application, project, owner…">
                </div>
                <button type="submit" class="plat-btn plat-btn-accent plat-btn-sm">Search</button>
                <?php if ($q !== ''): ?><a href="app_layout.php" class="plat-btn plat-btn-light plat-btn-sm">Clear</a><?php endif; ?>
            </form>
        </div>

        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Application</th><th>Project</th><th>Deployment</th>
                        <th>Tiers</th><th>Components</th><th>Servers</th><th>Owner</th><th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$layouts): ?>
                    <tr><td colspan="9"><p class="plat-empty">No application layouts yet. Create one to map an application's tiers and servers.</p></td></tr>
                <?php else: foreach ($layouts as $l): ?>
                    <?php $lid = (int) $l['id']; ?>
                    <tr>
                        <td>
                            <a href="?view=<?= $lid ?>" class="plat-primary" style="text-decoration:none;"><?= plat_h($l['app_name']) ?></a>
                            <?php if ($l['description']): ?><span class="plat-sub"><?= plat_h(mb_strimwidth($l['description'], 0, 60, '…')) ?></span><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($l['project'] && $canViewProjectOverview): ?>
                                <a href="project_overview.php?project=<?= urlencode($l['project']) ?>" title="View all applications in this project"><?= plat_h($l['project']) ?></a>
                            <?php else: ?>
                                <?= plat_h($l['project'] ?: '—') ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($l['deployment_type']): ?>
                                <span class="plat-pill <?= alDeploymentTone($l['deployment_type']) ?>"><?= plat_h($l['deployment_type']) ?></span>
                            <?php else: ?>
                                <span class="plat-sub">—</span>
                            <?php endif; ?>
                        </td>
                        <td><?= (int) ($tierCounts[$lid] ?? 0) ?></td>
                        <td><?= (int) ($compCounts[$lid] ?? 0) ?></td>
                        <td><?= (int) ($srvCounts[$lid] ?? 0) ?></td>
                        <td><?= plat_h($l['technical_owner'] ?: '—') ?></td>
                        <td><span class="plat-pill <?= platformStatusClass((string) $l['status']) ?>"><?= plat_h($l['status']) ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <a class="plat-icon-btn plat-icon-view" title="Open board" href="?view=<?= $lid ?>">▦</a>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit" onclick="alEdit(<?= $lid ?>)">✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History" onclick="alHistory(<?= $lid ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="alDelete(<?= $lid ?>, '<?= plat_h(addslashes($l['app_name'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- ============ EDITOR ============ -->
<div class="plat-modal" id="alModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="alTitle">New Layout</h2>
            <button type="button" class="plat-close" onclick="platClose('alModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Add tiers top to bottom, components within each tier, and servers within each component.</p>

        <form method="POST" id="alForm">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="al_id">
            <input type="hidden" name="board" id="al_board">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Application Name *</label><input type="text" name="app_name" id="al_app_name" required></div>
                <div class="plat-field"><label>Project</label><input type="text" name="project" id="al_project"></div>
                <div class="plat-field"><label>Technical Owner</label><input type="text" name="technical_owner" id="al_technical_owner"></div>
                <div class="plat-field"><label>Status</label>
                    <select name="status" id="al_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Deployment Type</label>
                    <select name="deployment_type" id="al_deployment_type">
                        <option value="">—</option>
                        <?php foreach ($deployTypes as $d): ?><option value="<?= plat_h($d) ?>"><?= plat_h($d) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Deployment Detail</label><input type="text" name="deployment_detail" id="al_deployment_detail" placeholder="e.g. 3 nodes, RHEL 9"></div>
                <div class="plat-field"><label>Location</label><input type="text" name="location" id="al_location" placeholder="e.g. Riyadh"></div>
                <div class="plat-field"><label>Description</label><input type="text" name="description" id="al_description"></div>
            </div>

            <div class="al-editor-bar">
                <strong>Tiers</strong>
                <div class="al-preset-row">
                    <?php foreach ($tierPresets as $t): ?>
                        <button type="button" class="al-preset" onclick="alAddTier('<?= plat_h($t) ?>')">+ <?= plat_h($t) ?></button>
                    <?php endforeach; ?>
                    <button type="button" class="al-preset al-preset-custom" onclick="alAddTier('')">+ Custom</button>
                </div>
            </div>

            <div id="alTiers" class="al-editor"></div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('alModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Layout</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="alImportModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2>Bulk Import</h2>
            <button type="button" class="plat-close" onclick="platClose('alImportModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">
            Same column shape as <strong>Export CSV</strong> — one row per server.
            Applications, tiers and components are matched by name and merged into
            what already exists; nothing is deleted. A name not seen before creates
            a new layout, tier or component.
        </p>
        <p class="plat-modal-sub" style="margin-top:-6px;">
            Columns: Application, Project, Tier, Component, Component Type,
            Technology, Port, Hostname, Server Role. Project only applies
            when an Application is first created. Environment is not typed in
            anywhere — a server's Production/DR/Test status is read live from
            its Inventory record.
            <?php if ($canExport): ?><a href="?action=export">Download a template / current data →</a><?php endif; ?>
        </p>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="import">
            <div class="plat-field">
                <label>CSV File *</label>
                <input type="file" name="import_file" accept=".csv,text/csv" required>
            </div>
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('alImportModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Import</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="alHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="alHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('alHistModal')">&times;</button></div>
        <div id="alHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="alDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete layout</h2>
            <button type="button" class="plat-close" onclick="platClose('alDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete <strong id="alDelName"></strong> and all of its tiers, components and server assignments?</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="alDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('alDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<!-- Picked when a server row's role is VIP -- inventory.additional_ips,
     one option per IP, flattened across every host. See alWatchHostEnv()
     in app-layout.js for the swap. -->
<datalist id="platAdditionalIps">
    <?php foreach ($additionalIps as $ip => $host): ?><option value="<?= plat_h($ip) ?>"><?= plat_h($host) ?> VIP</option><?php endforeach; ?>
</datalist>

<script>
/* Declared before the module script so it can read them at load time. */
const AL_COMP_TYPES = <?= json_encode($compTypes) ?>;
</script>
<script src="assets/js/app-layout.js"></script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
