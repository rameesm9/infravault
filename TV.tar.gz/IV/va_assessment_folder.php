<?php
/**
 * VA Assessment -- folder detail: upload CSVs into it, see what's in it,
 * download the combined + tagged dataset.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/va-assessment-helpers.php';

requireLogin();
requirePermission('va_assessment', 'can_view');

$canEdit   = can('va_assessment', 'can_edit');
$canDelete = can('va_assessment', 'can_delete');
$canImport = can('va_assessment', 'can_import');
$canExport = can('va_assessment', 'can_export');

$folderId = (int) ($_GET['id'] ?? 0);

$folderStmt = $pdo->prepare("SELECT * FROM va_folders WHERE id = ?");
$folderStmt->execute([$folderId]);
$folder = $folderStmt->fetch(PDO::FETCH_ASSOC);

if (!$folder) {
    header('Location: va_assessment.php');
    exit;
}

$page_title = 'VA Assessment - ' . $folder['name'] . ' | InfraVault';

$message = '';
$error = '';
$uploadDir = __DIR__ . '/uploads/va_assessment/';

if (!is_dir($uploadDir)) {
    @mkdir($uploadDir, 0755, true);
}


/*
|--------------------------------------------------------------------------
| UPLOAD CSV(S)
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_files'])) {

    csrfVerifyOrDie();

    if (!$canImport) {
        http_response_code(403);
        exit('You do not have permission to upload files here.');
    }

    $fieldAliases = vaAssessFieldAliases();
    $fieldLabels  = vaAssessFieldLabels();

    $uploadedNames = $_FILES['csv_files']['name'] ?? [];
    $fileCount = count($uploadedNames);

    if ($fileCount === 0 || $uploadedNames[0] === '') {
        $error = 'Please select at least one file.';
    } else {

        $importedFiles = 0;
        $importedRows = 0;
        $skipped = [];

        for ($i = 0; $i < $fileCount; $i++) {

            if (($_FILES['csv_files']['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                if (($_FILES['csv_files']['error'][$i] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
                    $skipped[] = ($uploadedNames[$i] ?? 'file ' . ($i + 1)) . ' (upload failed)';
                }
                continue;
            }

            $originalName = $uploadedNames[$i];
            $tmpName = $_FILES['csv_files']['tmp_name'][$i];

            $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

            if ($extension === 'xls') {
                $skipped[] = $originalName . ' (old .xls format is not supported -- please save as .xlsx or .csv and re-upload)';
                continue;
            }

            if (!in_array($extension, ['csv', 'xlsx'], true)) {
                $skipped[] = $originalName . ' (only .csv and .xlsx files are supported)';
                continue;
            }

            if (!is_uploaded_file($tmpName)) {
                $skipped[] = $originalName . ' (upload could not be verified)';
                continue;
            }

            $handle = null;
            $temporaryFile = null;
            $storedPath = null;

            try {

                /*
                 * Both formats are read fully into the same in-memory
                 * shape here -- an array of rows, each an array of cell
                 * strings -- so everything below (header resolution, row
                 * validation, DB insert) is shared regardless of which
                 * format was uploaded.
                 */
                if ($extension === 'xlsx') {
                    $allRows = vaAssessReadXlsxAsRows($tmpName);
                } else {
                    $temporaryFile = vaAssessPrepareCsvFile($tmpName);
                    $handle = fopen($temporaryFile, 'rb');

                    if ($handle === false) {
                        throw new RuntimeException('Unable to open the CSV file.');
                    }

                    $firstLine = fgets($handle);

                    if ($firstLine === false) {
                        throw new RuntimeException('The CSV file is empty.');
                    }

                    $commaCount = substr_count($firstLine, ',');
                    $semicolonCount = substr_count($firstLine, ';');
                    $tabCount = substr_count($firstLine, "\t");

                    if ($semicolonCount > $commaCount && $semicolonCount >= $tabCount) {
                        $delimiter = ';';
                    } elseif ($tabCount > $commaCount) {
                        $delimiter = "\t";
                    } else {
                        $delimiter = ',';
                    }

                    rewind($handle);

                    $allRows = [];
                    while (($csvRow = fgetcsv($handle, 0, $delimiter)) !== false) {
                        $allRows[] = $csvRow;
                    }
                    fclose($handle);
                }

                $headerRow = $allRows[0] ?? null;

                if ($headerRow === null || count($headerRow) < 2) {
                    throw new RuntimeException('No valid header row found.');
                }

                $headerMap = [];
                foreach ($headerRow as $index => $header) {
                    $normalized = vaAssessNormalizeHeader((string) $header);
                    if ($normalized !== '' && !isset($headerMap[$normalized])) {
                        $headerMap[$normalized] = $index;
                    }
                }

                $resolvedColumns = [];
                foreach ($fieldAliases as $field => $aliases) {
                    $resolvedColumns[$field] = vaAssessResolveFieldIndex($headerMap, $aliases);
                }

                if ($resolvedColumns['ip_address'] === null) {
                    throw new RuntimeException(
                        'No IP Address column found -- this file cannot be matched to a project.'
                    );
                }

                $hasContent = $resolvedColumns['plugin_name'] !== null
                    || $resolvedColumns['family'] !== null
                    || $resolvedColumns['synopsis'] !== null;

                if (!$hasContent) {
                    throw new RuntimeException(
                        'This does not look like a vulnerability scan export (no Plugin Name, Family, or Synopsis column found).'
                    );
                }

                $storedFilename = date('Ymd_His') . '_' . bin2hex(random_bytes(5)) . '.' . $extension;
                $storedPath = $uploadDir . $storedFilename;

                if (!copy($tmpName, $storedPath)) {
                    throw new RuntimeException('Unable to save the uploaded file.');
                }

                $pdo->beginTransaction();

                $fileStmt = $pdo->prepare("
                    INSERT INTO va_folder_files (folder_id, original_filename, stored_filename, file_path, uploaded_by, record_count)
                    VALUES (?, ?, ?, ?, ?, 0)
                ");
                $fileStmt->execute([
                    $folderId,
                    $originalName,
                    $storedFilename,
                    $storedPath,
                    (int) ($_SESSION['user_id'] ?? 0),
                ]);
                $fileId = (int) $pdo->lastInsertId();

                $rowStmt = $pdo->prepare("
                    INSERT INTO va_folder_rows
                    (
                        folder_id, file_id, plugin, plugin_name, family, severity, ip_address,
                        port, exploit, repository, mac_address, dns_name, netbios_name,
                        plugin_output, steps_to_remediate, cve, first_discovered, last_observed, synopsis
                    )
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ");

                $rowCount = 0;

                for ($rowIndex = 1, $totalRows = count($allRows); $rowIndex < $totalRows; $rowIndex++) {

                    $row = $allRows[$rowIndex];

                    $hasData = false;
                    foreach ($row as $cell) {
                        if (trim((string) $cell) !== '') {
                            $hasData = true;
                            break;
                        }
                    }
                    if (!$hasData) {
                        continue;
                    }

                    if (count($row) < count($headerRow)) {
                        $row = array_pad($row, count($headerRow), '');
                    }

                    $field = static function (string $name) use ($row, $resolvedColumns): string {
                        $index = $resolvedColumns[$name];
                        return $index === null ? '' : trim((string) ($row[$index] ?? ''));
                    };

                    $rowStmt->execute([
                        $folderId,
                        $fileId,
                        $field('plugin'),
                        $field('plugin_name'),
                        $field('family'),
                        $field('severity'),
                        $field('ip_address'),
                        $field('port'),
                        $field('exploit'),
                        $field('repository'),
                        $field('mac_address'),
                        $field('dns_name'),
                        $field('netbios_name'),
                        $field('plugin_output'),
                        $field('steps_to_remediate'),
                        $field('cve'),
                        $field('first_discovered'),
                        $field('last_observed'),
                        $field('synopsis'),
                    ]);

                    $rowCount++;
                }

                if ($rowCount === 0) {
                    throw new RuntimeException('The file contains no data rows.');
                }

                $pdo->prepare("UPDATE va_folder_files SET record_count = ? WHERE id = ?")
                    ->execute([$rowCount, $fileId]);

                $pdo->commit();

                $importedFiles++;
                $importedRows += $rowCount;

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }
                if ($storedPath !== null && is_file($storedPath)) {
                    @unlink($storedPath);
                }

                $skipped[] = $originalName . ' (' . $e->getMessage() . ')';

            } finally {

                if (is_resource($handle)) {
                    fclose($handle);
                }
                if ($temporaryFile !== null && is_file($temporaryFile)) {
                    @unlink($temporaryFile);
                }
            }
        }

        if ($importedFiles > 0) {
            $message = $importedFiles . ' file' . ($importedFiles === 1 ? '' : 's') . ' imported, '
                . $importedRows . ' finding' . ($importedRows === 1 ? '' : 's') . ' added.';
        }

        if (!empty($skipped)) {
            $error = 'Skipped: ' . implode('; ', $skipped);
        }
    }
}


/*
|--------------------------------------------------------------------------
| DELETE FILE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_file'])) {

    csrfVerifyOrDie();

    if (!$canDelete) {
        http_response_code(403);
        exit('You do not have permission to delete this file.');
    }

    $fileId = (int) ($_POST['file_id'] ?? 0);

    $stmt = $pdo->prepare("SELECT file_path FROM va_folder_files WHERE id = ? AND folder_id = ?");
    $stmt->execute([$fileId, $folderId]);
    $path = $stmt->fetchColumn();

    if ($path !== false) {
        // Explicit child delete -- see the note in va_assessment.php's
        // delete_folder handler: ON DELETE CASCADE is a no-op on this
        // connection, so this must be done by hand or rows are orphaned.
        $pdo->prepare("DELETE FROM va_folder_rows WHERE file_id = ?")->execute([$fileId]);
        $pdo->prepare("DELETE FROM va_folder_files WHERE id = ?")->execute([$fileId]);
        if (!empty($path) && is_file($path)) {
            @unlink($path);
        }
    }

    header('Location: va_assessment_folder.php?id=' . $folderId . '&file_deleted=1');
    exit;
}

if (isset($_GET['file_deleted'])) {
    $message = 'File removed from folder.';
}


require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

$files = $pdo->prepare("
    SELECT ff.*, u.first_name, u.last_name
    FROM va_folder_files ff
    LEFT JOIN users u ON u.id = ff.uploaded_by
    WHERE ff.folder_id = ?
    ORDER BY ff.uploaded_at ASC
");
$files->execute([$folderId]);
$files = $files->fetchAll(PDO::FETCH_ASSOC);

$totalRows = 0;
foreach ($files as $f) {
    $totalRows += (int) $f['record_count'];
}

?>

<link rel="stylesheet" href="assets/css/vulnerabilities.css">
<link rel="stylesheet" href="assets/css/va-assessment.css">

<div class="content va-page">

    <div class="va-page-header">

        <div>
            <div class="va-breadcrumb">
                <a href="vulnerabilities.php">DMZ Assessment</a> /
                <a href="va_assessment.php">VA Assessment</a> /
                <?= htmlspecialchars($folder['name'], ENT_QUOTES, 'UTF-8'); ?>
            </div>
            <h1><?= htmlspecialchars($folder['name'], ENT_QUOTES, 'UTF-8'); ?></h1>
            <p><?= count($files); ?> file(s), <?= $totalRows; ?> finding(s) total.</p>
        </div>

        <div class="va-header-actions">
            <a href="va_assessment.php" class="va-btn va-btn-secondary">&larr; Back to Folders</a>
            <?php if ($canExport && $totalRows > 0): ?>
                <a href="va_assessment_download.php?folder_id=<?= $folderId; ?>" class="va-btn va-btn-primary">
                    &#11015; Download Combined Report
                </a>
            <?php endif; ?>
        </div>

    </div>

    <?php if ($message !== ''): ?>
        <div class="va-alert va-alert-success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="va-alert va-alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <?php if ($canImport): ?>

    <div class="va-upload-card">
        <form method="POST" enctype="multipart/form-data">
            <?= csrfField(); ?>
            <div class="va-upload-box">
                <div class="va-upload-icon">CSV</div>
                <h2>Upload Scanner File(s)</h2>
                <p>Select one or more CSV or .xlsx exports -- typically one per project/application. Column order and naming can vary between files. Old .xls files aren't supported; save as .xlsx or .csv first.</p>
                <label class="va-file-label">
                    Select File(s)
                    <input type="file" name="csv_files[]" accept=".csv,text/csv,.xlsx,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" multiple required>
                </label>
                <button type="submit" name="upload_files" value="1" class="va-btn va-btn-primary">Upload &amp; Import</button>
            </div>
        </form>
    </div>

    <?php endif; ?>

    <?php if (!$files): ?>

        <div class="va-empty">
            <div class="va-empty-icon">&#128196;</div>
            <h2>No Files Uploaded Yet</h2>
            <p>Upload the scanner CSV exports for this folder above.</p>
        </div>

    <?php else: ?>

        <div class="va-table-wrapper">
            <table class="va-table vaf-file-table">
                <thead>
                    <tr>
                        <th>File</th>
                        <th>Findings</th>
                        <th>Uploaded</th>
                        <th>By</th>
                        <?php if ($canDelete): ?><th>Actions</th><?php endif; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($files as $f): ?>
                        <?php
                            $uploadedBy = trim((string) ($f['uploaded_by_name'] ?? ''));
                            if ($uploadedBy === '') {
                                $uploadedBy = trim(($f['first_name'] ?? '') . ' ' . ($f['last_name'] ?? ''));
                            }
                        ?>
                        <tr>
                            <td><?= htmlspecialchars($f['original_filename'], ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= (int) $f['record_count']; ?></td>
                            <td><?= htmlspecialchars($f['uploaded_at'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?= htmlspecialchars($uploadedBy, ENT_QUOTES, 'UTF-8'); ?></td>
                            <?php if ($canDelete): ?>
                            <td>
                                <form method="POST" style="display:inline;" onsubmit="return confirm('Remove this file and its findings from the folder?');">
                                    <?= csrfField(); ?>
                                    <input type="hidden" name="file_id" value="<?= (int) $f['id']; ?>">
                                    <button type="submit" name="delete_file" value="1" class="va-btn va-btn-danger" style="min-height:30px; padding:5px 10px;">Remove</button>
                                </form>
                            </td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
