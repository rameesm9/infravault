<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/bookmarks-helpers.php';

header('Content-Type: application/json');

if (!authzIsLoggedIn()) {
    http_response_code(401);
    echo json_encode(['success' => false, 'error' => 'Not logged in.']);
    exit;
}

csrfVerifyOrDie();

$pageKey = trim((string) ($_POST['page_key'] ?? ''));

$registry = bookmarks_registry();
$page = null;

foreach ($registry as $p) {
    if ($p['key'] === $pageKey) {
        $page = $p;
        break;
    }
}

if ($page === null) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Unknown page.']);
    exit;
}

$role = (string) ($_SESSION['role'] ?? '');
$visible = bookmarks_filter_visible($pdo, $role, [$pageKey]);

if (!in_array($pageKey, $visible, true)) {
    http_response_code(403);
    echo json_encode(['success' => false, 'error' => 'You do not have access to this page.']);
    exit;
}

$bookmarked = bookmarks_toggle($pdo, (int) $_SESSION['user_id'], $pageKey);

echo json_encode(['success' => true, 'bookmarked' => $bookmarked]);
