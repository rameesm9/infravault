<?php
// knowledge-export.php
//
// Exports a single KB article as a Word-compatible document. Word (and most
// office suites) will happily open an .doc file that is really HTML, which
// avoids needing a PHPWord/COM dependency on the server.
//
// The document is laid out as a controlled reference document, one concern
// per page: a title page, then Document Control, then Contents, then the
// numbered sections, then the appendices (Attachments, then Revision
// History on its own page). A running header/footer repeats on every page.
// This mirrors sop-export.php so the two modules produce documents that look
// like they came from the same company.

require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/branding-helpers.php';

$appName = getAppName($pdo);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('knowledge', 'can_view');
requirePermission('knowledge', 'can_export');

$current_user_id = (int) $_SESSION['user_id'];
$role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

// Get user's team
$userStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';

// Check export permission
if (!$is_admin && !hasRolePermission($pdo, $role, 'knowledge_base', 'can_export')) {
    http_response_code(403);
    exit('You do not have permission to export KB articles.');
}

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function kb_export_date($value, string $format = 'd M Y'): string
{
    if (empty($value)) {
        return '—';
    }

    $timestamp = strtotime((string) $value);

    return $timestamp ? date($format, $timestamp) : '—';
}

function kb_export_filesize($bytes): string
{
    $bytes = (float) $bytes;

    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' MB';
    }

    return number_format($bytes / 1024, 1) . ' KB';
}

/*
|--------------------------------------------------------------------------
| Content pasted into the KB editor from an external dark-themed source
| can bring inline background-color/color styling along with it -- the
| editor's own toolbar never sets an inline style, it only uses tags, so
| nothing legitimate is lost by stripping it. Left in place, it is what
| turns an exported Word page dark.
|--------------------------------------------------------------------------
*/
function kb_export_strip_inline_style(string $html): string
{
    $html = preg_replace('/\sstyle\s*=\s*("[^"]*"|\'[^\']*\')/i', '', $html);
    $html = preg_replace('/\s(?:bgcolor|background)\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);

    return $html;
}

/*
|--------------------------------------------------------------------------
| Rewrite relative attachment/image URLs to absolute ones so Word can
| actually fetch them when it renders the exported document.
|--------------------------------------------------------------------------
*/
function kb_export_absolute_urls(string $html, string $base_url): string
{
    return preg_replace_callback(
        '/\ssrc\s*=\s*(["\'])(?!https?:\/\/|data:)([^"\']*)\1/i',
        function ($match) use ($base_url) {
            $quote = $match[1];
            $path = ltrim($match[2], '/');
            return ' src=' . $quote . $base_url . $path . $quote;
        },
        $html
    );
}

/*
|--------------------------------------------------------------------------
| Embedding images in the document.
|
| A linked image does not survive the trip: Word fetches <img src> itself
| when the file is opened, with no session cookie, over a URL the reader's
| machine may not resolve at all -- and Word blocks remote content in
| downloaded documents anyway. The result is a red-X placeholder where the
| screenshot should be.
|
| So the document is packaged as MHTML (multipart/related), the same
| single-file format Word itself writes: the HTML in one part, every image
| base64-encoded in its own part, referenced by Content-Location. Nothing
| is fetched, and the images travel with the file when the article is
| emailed. Mirrors sop-export.php's identical approach.
|--------------------------------------------------------------------------
*/

/**
 * Resolves an image URL from the document back to a file on this server,
 * or null when it is not ours to embed.
 */
function kb_export_local_asset(string $url, string $base_url, PDO $pdo): ?array
{
    $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');

    // Our own absolute URLs come back to relative paths.
    if (stripos($url, $base_url) === 0) {
        $url = substr($url, strlen($base_url));
    }

    if (preg_match('#^https?://#i', $url) || stripos($url, 'data:') === 0) {
        return null;
    }

    $path = null;

    // Body images are served through the authenticated file endpoint;
    // resolve those back to the stored attachment.
    if (preg_match('#(?:^|/)knowledge\.php\?action=file&(?:amp;)?id=(\d+)#i', $url, $match)) {
        $stmt = $pdo->prepare("SELECT file_path FROM knowledge_base_attachments WHERE id = ? LIMIT 1");
        $stmt->execute([(int) $match[1]]);
        $stored = $stmt->fetchColumn();

        if ($stored) {
            $path = __DIR__ . '/' . ltrim((string) $stored, '/');
        }
    } else {
        $path = __DIR__ . '/' . ltrim(parse_url($url, PHP_URL_PATH) ?? '', '/');
    }

    if ($path === null) {
        return null;
    }

    $real = realpath($path);
    $root = realpath(__DIR__);

    // Never read outside the application directory, whatever the stored
    // path claims.
    if ($real === false || $root === false || strpos($real, $root . DIRECTORY_SEPARATOR) !== 0) {
        return null;
    }

    $size = @getimagesize($real);

    if (!$size || empty($size['mime'])) {
        return null;
    }

    return ['path' => $real, 'mime' => $size['mime']];
}

/**
 * Swaps every embeddable <img src> for a Content-Location, and returns the
 * rewritten HTML together with the assets to attach.
 */
function kb_export_collect_assets(string $html, string $base_url, PDO $pdo, string $asset_base): array
{
    $assets = [];

    $html = preg_replace_callback(
        '/(<img\b[^>]*?\ssrc\s*=\s*)(["\'])(.*?)\2/i',
        function ($match) use (&$assets, $base_url, $pdo, $asset_base) {
            $asset = kb_export_local_asset($match[3], $base_url, $pdo);

            // Not resolvable locally: leave the URL alone so Word can at
            // least try to fetch it.
            if ($asset === null) {
                return $match[0];
            }

            $key = $asset['path'];

            if (!isset($assets[$key])) {
                $extension = pathinfo($asset['path'], PATHINFO_EXTENSION) ?: 'img';
                $assets[$key] = [
                    'location' => $asset_base . 'image' . (count($assets) + 1) . '.' . $extension,
                    'mime'     => $asset['mime'],
                    'path'     => $asset['path'],
                ];
            }

            return $match[1] . $match[2] . $assets[$key]['location'] . $match[2];
        },
        $html
    );

    return [$html, $assets];
}

/**
 * Wraps the document and its images into one MHTML file.
 */
function kb_export_mhtml(string $html, array $assets, string $document_location): string
{
    $boundary = '----=_NextPart_InfraVault_KB';
    $eol = "\r\n";

    $out = 'MIME-Version: 1.0' . $eol
        . 'Content-Type: multipart/related; boundary="' . $boundary . '"; type="text/html"' . $eol
        . $eol
        . 'This document is a single-file web page (MHTML). Open it with Microsoft Word.' . $eol
        . $eol;

    $out .= '--' . $boundary . $eol
        . 'Content-Location: ' . $document_location . $eol
        . 'Content-Transfer-Encoding: quoted-printable' . $eol
        . 'Content-Type: text/html; charset="utf-8"' . $eol
        . $eol
        . quoted_printable_encode($html) . $eol
        . $eol;

    foreach ($assets as $asset) {
        $data = @file_get_contents($asset['path']);

        if ($data === false) {
            continue;
        }

        $out .= '--' . $boundary . $eol
            . 'Content-Location: ' . $asset['location'] . $eol
            . 'Content-Transfer-Encoding: base64' . $eol
            . 'Content-Type: ' . $asset['mime'] . $eol
            . $eol
            . chunk_split(base64_encode($data), 76, $eol)
            . $eol;
    }

    return $out . '--' . $boundary . '--' . $eol;
}

$kb_id = (int) ($_GET['id'] ?? 0);

if ($kb_id <= 0) {
    http_response_code(400);
    exit('Invalid KB article.');
}

$stmt = $pdo->prepare("
    SELECT
        k.*,
        owner.first_name AS owner_first,
        owner.last_name  AS owner_last,
        editor.first_name AS editor_first,
        editor.last_name  AS editor_last
    FROM knowledge_base k
    LEFT JOIN users owner  ON owner.id = k.created_by
    LEFT JOIN users editor ON editor.id = k.updated_by
    WHERE k.id = ?
    LIMIT 1
");
$stmt->execute([$kb_id]);
$kb = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$kb) {
    http_response_code(404);
    exit('Knowledge note not found.');
}

// Check visibility permissions
if (!$is_admin) {
    $sharedTeams = getSharedTeams($pdo, 'knowledge_base', $kb_id);
    $accessLevel = getItemAccessLevel(
        $pdo,
        $current_user_id,
        $role,
        $user_team,
        (int) $kb['created_by'],
        $kb['visibility'] ?? 'public',
        $kb['owner_team'] ?? '',
        $sharedTeams,
        'knowledge_base'
    );

    if ($accessLevel === 'none') {
        http_response_code(403);
        exit('You do not have permission to export this article.');
    }
}

$owner_name = trim(($kb['owner_first'] ?? '') . ' ' . ($kb['owner_last'] ?? ''));
$editor_name = trim(($kb['editor_first'] ?? '') . ' ' . ($kb['editor_last'] ?? ''));

$base_url = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/')
    . '/';

/*
|--------------------------------------------------------------------------
| Appendix data: attachments and revision history.
|--------------------------------------------------------------------------
*/

$attachStmt = $pdo->prepare("
    SELECT original_name, file_path, file_size, created_at
    FROM knowledge_base_attachments
    WHERE kb_id = ?
    ORDER BY id
");
$attachStmt->execute([$kb_id]);
$attachments = $attachStmt->fetchAll(PDO::FETCH_ASSOC);

$revisionStmt = $pdo->prepare("
    SELECT r.version, r.change_summary, r.created_at,
           u.first_name, u.last_name
    FROM knowledge_base_revisions r
    LEFT JOIN users u ON u.id = r.changed_by
    WHERE r.kb_id = ?
    ORDER BY r.id DESC
");
$revisionStmt->execute([$kb_id]);
$revisions = $revisionStmt->fetchAll(PDO::FETCH_ASSOC);

$visibility_label = [
    'public' => 'Public — All Teams',
    'team'   => 'My Team Only',
    'teams'  => 'Specific Teams',
][$kb['visibility'] ?? 'public'] ?? 'Public';

/*
|--------------------------------------------------------------------------
| Body sections. Built as a list so the contents page, the numbering and
| the sections themselves can never drift apart.
|--------------------------------------------------------------------------
*/

$sections = [];

if (trim((string) $kb['description']) !== '') {
    $sections[] = [
        'title' => 'Description',
        'html'  => '<p>' . nl2br(h($kb['description'])) . '</p>',
    ];
}

$content_html = trim((string) ($kb['content_html'] ?? ''));

$sections[] = [
    'title' => 'Knowledge Content',
    'html'  => $content_html !== ''
        ? kb_export_absolute_urls(kb_export_strip_inline_style($content_html), $base_url)
        : '<p class="doc-empty">No content has been added to this article.</p>',
];

// Appendices are numbered after the body sections.
$appendices = [];
$appendices[] = 'Attachments';
$appendices[] = 'Revision History';

$filename = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $kb['kb_number'] . '_' . $kb['title']);
$filename = trim($filename, '_') . '.doc';

// Buffered, because the images can only be collected once the whole
// document exists, and the response headers depend on what came back.
ob_start();
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title><?= h($kb['kb_number']) ?> — <?= h($kb['title']) ?> | <?= h($appName) ?></title>
<!--[if gte mso 9]>
<xml>
<o:DocumentProperties>
    <o:Title><?= h($kb['kb_number']) ?> <?= h($kb['title']) ?></o:Title>
    <o:Subject><?= h($kb['category']) ?> — Knowledge Base Article</o:Subject>
    <o:Author><?= h($owner_name ?: $appName) ?></o:Author>
    <o:Category>Knowledge Base</o:Category>
    <o:Version><?= h($kb['version']) ?></o:Version>
</o:DocumentProperties>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>100</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
    /* --------------------------------------------------------------
       Page setup. mso-header / mso-footer point at the two
       `mso-element` divs at the end of <body>, which is what makes the
       banner repeat on every page instead of printing once inline.
       -------------------------------------------------------------- */
    @page WordSection1 {
        size: 21.0cm 29.7cm;
        margin: 2.4cm 2.0cm 2.2cm 2.0cm;
        mso-header-margin: 1.1cm;
        mso-footer-margin: 1.1cm;
        mso-header: h1;
        mso-footer: f1;
        mso-paper-source: 0;
    }
    div.WordSection1 { page: WordSection1; }

    body {
        font-family: Calibri, Arial, sans-serif;
        font-size: 11pt;
        line-height: 1.45;
        color: #1F2937;
    }

    p { margin: 0 0 8pt; }

    p.MsoHeader, p.MsoFooter {
        margin: 0;
        font-family: Calibri, Arial, sans-serif;
        font-size: 8.5pt;
        color: #64748B;
        letter-spacing: .2pt;
    }
    p.MsoHeader {
        border-bottom: .75pt solid #C7D2DE;
        padding-bottom: 3pt;
    }
    p.MsoFooter {
        border-top: .75pt solid #C7D2DE;
        padding-top: 3pt;
    }

    /* ---------------------------- Cover ---------------------------- */
    .cover-rule {
        border-top: 3pt solid #0F2A44;
        margin-bottom: 14pt;
    }
    .cover-eyebrow {
        font-size: 9pt;
        letter-spacing: 1.4pt;
        text-transform: uppercase;
        color: #64748B;
        margin-bottom: 26pt;
    }
    .cover-number {
        font-size: 13pt;
        font-weight: bold;
        letter-spacing: 2pt;
        color: #1D4ED8;
        margin-bottom: 6pt;
    }
    .cover-title {
        font-size: 27pt;
        font-weight: bold;
        line-height: 1.15;
        color: #0F2A44;
        margin: 0 0 10pt;
    }
    .cover-summary {
        font-size: 11.5pt;
        color: #475569;
        margin-bottom: 26pt;
    }
    .cover-classification {
        font-size: 8.5pt;
        letter-spacing: 1.2pt;
        text-transform: uppercase;
        color: #92400E;
        background: #FEF3C7;
        padding: 4pt 8pt;
        margin-bottom: 20pt;
    }

    /* ------------------------- Control table ----------------------- */
    .block-title {
        font-size: 9pt;
        font-weight: bold;
        letter-spacing: 1.2pt;
        text-transform: uppercase;
        color: #0F2A44;
        border-bottom: 1pt solid #0F2A44;
        padding-bottom: 3pt;
        margin: 0 0 8pt;
    }

    table.doc-table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 20pt;
        font-size: 10pt;
    }
    table.doc-table td, table.doc-table th {
        border: .75pt solid #D8E0EA;
        padding: 5pt 8pt;
        vertical-align: top;
    }
    table.doc-table th {
        background: #0F2A44;
        color: #FFFFFF;
        text-align: left;
        font-size: 9pt;
        letter-spacing: .6pt;
        text-transform: uppercase;
    }
    td.doc-label {
        background: #F4F7FB;
        font-weight: bold;
        color: #475569;
        width: 22%;
        white-space: nowrap;
    }
    tr.doc-alt td { background: #F8FAFC; }

    /* ---------------------------- Contents ------------------------- */
    table.toc {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 20pt;
        font-size: 10.5pt;
    }
    table.toc td {
        border-bottom: .5pt dotted #CBD5E1;
        padding: 5pt 4pt;
    }
    td.toc-num {
        width: 34pt;
        color: #1D4ED8;
        font-weight: bold;
    }

    /* ---------------------------- Sections ------------------------- */
    h1.doc-h1 {
        font-size: 14pt;
        color: #0F2A44;
        border-bottom: 1.5pt solid #1D4ED8;
        padding-bottom: 4pt;
        margin: 22pt 0 10pt;
        page-break-after: avoid;
    }
    .doc-section h1 {
        font-size: 13pt;
        color: #0F2A44;
        margin: 14pt 0 6pt;
        page-break-after: avoid;
    }
    .doc-section h2 {
        font-size: 12pt;
        color: #0F2A44;
        margin: 14pt 0 6pt;
        page-break-after: avoid;
    }
    .doc-section h3 {
        font-size: 11pt;
        color: #334155;
        margin: 12pt 0 5pt;
        page-break-after: avoid;
    }
    .doc-section h4 {
        font-size: 10.5pt;
        color: #334155;
        margin: 10pt 0 4pt;
        page-break-after: avoid;
    }
    .doc-section ul, .doc-section ol { margin: 0 0 8pt 18pt; }
    .doc-section li { margin-bottom: 3pt; }
    .doc-section table {
        border-collapse: collapse;
        margin: 8pt 0;
        font-size: 10pt;
        width: 100%;
    }
    .doc-section table td, .doc-section table th {
        border: .75pt solid #D8E0EA;
        padding: 4pt 8pt;
    }
    .doc-section table th { background: #F4F7FB; text-align: left; }
    .doc-section img { max-width: 16.5cm; }
    .doc-section blockquote {
        margin: 8pt 0 8pt 12pt;
        padding-left: 10pt;
        border-left: 2.5pt solid #CBD5E1;
        color: #475569;
    }
    .doc-section pre, .doc-section code {
        background: #0F172A;
        color: #E2E8F0;
        padding: 8pt 10pt;
        font-family: Consolas, "Courier New", monospace;
        font-size: 9.5pt;
        white-space: pre-wrap;
    }
    .doc-section code {
        padding: 1pt 4pt;
        display: inline;
    }
    .doc-section hr {
        border: none;
        border-top: .75pt solid #D8E0EA;
        margin: 14pt 0;
    }
    p.doc-empty { color: #94A3B8; font-style: italic; }

    .doc-end {
        margin-top: 24pt;
        padding-top: 8pt;
        border-top: .75pt solid #D8E0EA;
        font-size: 8.5pt;
        color: #94A3B8;
        text-align: center;
        letter-spacing: 1pt;
        text-transform: uppercase;
    }
</style>
</head>
<body lang="EN-GB">

<div class="WordSection1">

    <!-- =====================  COVER PAGE  ===================== -->

    <div class="cover-rule"></div>

    <p class="cover-eyebrow">Knowledge Base Article &nbsp;&bull;&nbsp; <?= h($kb['category']) ?></p>

    <p class="cover-number"><?= h($kb['kb_number']) ?></p>
    <p class="cover-title"><?= h($kb['title']) ?></p>

    <?php if (trim((string) $kb['description']) !== ''): ?>
        <p class="cover-summary"><?= nl2br(h($kb['description'])) ?></p>
    <?php else: ?>
        <p class="cover-summary">&nbsp;</p>
    <?php endif; ?>

    <p class="cover-classification"><?= h($visibility_label) ?></p>

    <!-- Page break: the title page is the cover alone. Document Control
         moves to its own page. -->
    <br clear="all" style="mso-special-character:line-break;page-break-before:always">

    <p class="block-title">Document Control</p>

    <table class="doc-table">
        <tr>
            <td class="doc-label">Document No.</td>
            <td><?= h($kb['kb_number']) ?></td>
            <td class="doc-label">Version</td>
            <td><?= h($kb['version']) ?></td>
        </tr>
        <tr class="doc-alt">
            <td class="doc-label">Category</td>
            <td><?= h($kb['category']) ?></td>
            <td class="doc-label">Visibility</td>
            <td><?= h($visibility_label) ?></td>
        </tr>
        <tr>
            <td class="doc-label">Owner</td>
            <td><?= h($owner_name ?: '—') ?></td>
            <td class="doc-label">Last Edited By</td>
            <td><?= h($editor_name ?: '—') ?></td>
        </tr>
        <tr class="doc-alt">
            <td class="doc-label">Created</td>
            <td><?= h(kb_export_date($kb['created_at'])) ?></td>
            <td class="doc-label">Last Updated</td>
            <td><?= h(kb_export_date($kb['updated_at'], 'd M Y H:i')) ?></td>
        </tr>
        <tr>
            <td class="doc-label">Exported</td>
            <td colspan="3"><?= h(date('d M Y H:i')) ?> by <?= h(trim(($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '')) ?: ($_SESSION['ncgr_id'] ?? 'Unknown user')) ?></td>
        </tr>
    </table>

    <!-- Page break: Contents gets its own page after Document Control. -->
    <br clear="all" style="mso-special-character:line-break;page-break-before:always">

    <!-- =====================  CONTENTS  ===================== -->

    <p class="block-title">Contents</p>

    <table class="toc">
        <?php $toc_index = 0; ?>
        <?php foreach ($sections as $section): $toc_index++; ?>
            <tr>
                <td class="toc-num"><?= $toc_index ?>.</td>
                <td><?= h($section['title']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php foreach ($appendices as $appendix): $toc_index++; ?>
            <tr>
                <td class="toc-num"><?= $toc_index ?>.</td>
                <td><?= h($appendix) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- =====================  BODY  ===================== -->

    <?php $index = 0; ?>
    <?php foreach ($sections as $section): $index++; ?>
        <h1 class="doc-h1"><?= $index ?>. <?= h($section['title']) ?></h1>
        <div class="doc-section"><?= $section['html'] ?></div>
    <?php endforeach; ?>

    <!-- =====================  APPENDICES  ===================== -->

    <?php $index++; ?>
    <h1 class="doc-h1"><?= $index ?>. Attachments</h1>

    <?php if ($attachments): ?>
        <table class="doc-table">
            <tr>
                <th style="width:52%">File</th>
                <th style="width:16%">Size</th>
                <th style="width:32%">Added</th>
            </tr>
            <?php foreach ($attachments as $i => $attachment): ?>
                <tr<?= $i % 2 ? ' class="doc-alt"' : '' ?>>
                    <td><a href="<?= h($base_url . ltrim((string) $attachment['file_path'], '/')) ?>"><?= h($attachment['original_name']) ?></a></td>
                    <td><?= h(kb_export_filesize($attachment['file_size'])) ?></td>
                    <td><?= h(kb_export_date($attachment['created_at'], 'd M Y H:i')) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p class="doc-empty">No attachments are associated with this article.</p>
    <?php endif; ?>

    <?php $index++; ?>
    <!-- Page break: Revision History always starts on its own page. -->
    <br clear="all" style="mso-special-character:line-break;page-break-before:always">
    <h1 class="doc-h1"><?= $index ?>. Revision History</h1>

    <?php if ($revisions): ?>
        <table class="doc-table">
            <tr>
                <th style="width:12%">Version</th>
                <th style="width:22%">Date</th>
                <th style="width:24%">Changed By</th>
                <th style="width:42%">Summary</th>
            </tr>
            <?php foreach ($revisions as $i => $revision): ?>
                <?php $changed_by = trim(($revision['first_name'] ?? '') . ' ' . ($revision['last_name'] ?? '')); ?>
                <tr<?= $i % 2 ? ' class="doc-alt"' : '' ?>>
                    <td><?= h($revision['version']) ?></td>
                    <td><?= h(kb_export_date($revision['created_at'], 'd M Y H:i')) ?></td>
                    <td><?= h($changed_by ?: '—') ?></td>
                    <td><?= h($revision['change_summary'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p class="doc-empty">No revisions recorded.</p>
    <?php endif; ?>

    <p class="doc-end">End of document &nbsp;&bull;&nbsp; <?= h($kb['kb_number']) ?> v<?= h($kb['version']) ?></p>

<!-- =====================  PAGE HEADER / FOOTER  =====================
     Referenced by "mso-header: h1" / "mso-footer: f1" in @page above.

     These live INSIDE the WordSection div on purpose. Placed after it,
     Word bound them as the real header and footer but also laid them out
     as ordinary body content, so the title and page number appeared a
     second time at the end of the document.

     Left / centre / right sit on Word's own tab stops: a centre tab at the
     middle of the 17cm text column and a right tab at its edge. That is how
     Word lays out a three-part header natively, so the alignment survives
     the document being edited afterwards.
-->

<div style='mso-element:header' id="h1">
    <p class="MsoHeader" style="tab-stops:center 8.5cm right 17.0cm"><?= h($kb['kb_number']) ?> — <?= h($kb['title']) ?><span style="mso-tab-count:1"></span><span style="mso-tab-count:1"></span>Version <?= h($kb['version']) ?></p>
</div>

<div style='mso-element:footer' id="f1">
    <p class="MsoFooter" style="tab-stops:center 8.5cm right 17.0cm">Internal Use Only — uncontrolled when printed<span style="mso-tab-count:1"></span><span style="mso-tab-count:1"></span>Page <span style='mso-field-code:PAGE'></span> of <span style='mso-field-code:NUMPAGES'></span></p>
</div>

</div>

</body>
</html>
<?php

$html = ob_get_clean();

/*
| Word resolves Content-Location against a document location, so both use
| the same made-up absolute base. The names never touch this server's
| filesystem -- they are only labels tying an <img> to its MIME part.
*/
$asset_base = 'file:///C:/infravault/knowledge/';

list($html, $assets) = kb_export_collect_assets($html, $base_url, $pdo, $asset_base);

if ($assets) {
    $document = kb_export_mhtml($html, $assets, $asset_base . 'document.htm');
} else {
    // Nothing to embed: plain HTML opens in Word just as well.
    $document = $html;
}

header('Content-Type: application/msword; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($document));
header('Cache-Control: max-age=0');

echo $document;
