<?php

session_start();

require_once __DIR__ . '/config/db.php';


if (!isset($_SESSION['user_id'])) {

    header("Location: index.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('myprofile', 'can_view');




$user_id = $_SESSION['user_id'];

$success_msg = "";
$error_msg = "";


// ===============================
// UPDATE SETTINGS
// ===============================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');
    $phone      = trim($_POST['phone'] ?? '');
    $avatar     = trim($_POST['avatar'] ?? '');

    // Validate avatar field
    if (empty($avatar)) {
        $avatar = 'initials';
    }


    $current_password = $_POST['current_password'] ?? '';
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';



    $stmt = $pdo->prepare(
        "SELECT * FROM users WHERE id=?"
    );

    $stmt->execute([$user_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);



    if (!$user) {

        $error_msg = "User account not found.";

    }

    else {


        // Email duplicate check

        $check = $pdo->prepare(
            "SELECT id FROM users 
             WHERE email=? 
             AND id != ?"
        );


        $check->execute([
            $email,
            $user_id
        ]);



        if ($check->fetch()) {


            $error_msg =
            "Email address already exists.";


        }

        else {



            // Password change

            if (!empty($new_password)) {



                if (
                    empty($current_password)
                ) {


                    $error_msg =
                    "Current password is required.";


                }


                elseif (
                    !password_verify(
                        $current_password,
                        $user['password']
                    )
                ) {


                    $error_msg =
                    "Current password is incorrect.";


                }


                elseif (
                    $new_password !== $confirm_password
                ) {


                    $error_msg =
                    "New passwords do not match.";


                }


                elseif (
                    ($policyErrors = validatePasswordPolicy($pdo, $new_password)) !== []
                ) {


                    // Password policy from Settings -> Security.
                    $error_msg = implode(' ', $policyErrors);


                }


                else {


                    $hash =
                    password_hash(
                        $new_password,
                        PASSWORD_DEFAULT
                    );



                    $update =
                    $pdo->prepare(
                    "UPDATE users SET
                    first_name=?,
                    last_name=?,
                    email=?,
                    phone=?,
                    avatar=?,
                    password=?
                    WHERE id=?"
                    );


                    $update->execute([

                        $first_name,
                        $last_name,
                        $email,
                        $phone,
                        $avatar,
                        $hash,
                        $user_id

                    ]);



                    $_SESSION['first_name']
                    =
                    $first_name;

                    $_SESSION['avatar']
                    =
                    $avatar;


                    $success_msg =
                    "Profile and password updated successfully.";

                }



            }



            else {



                $update =
                $pdo->prepare(
                "UPDATE users SET
                first_name=?,
                last_name=?,
                email=?,
                phone=?,
                avatar=?
                WHERE id=?"
                );


                $update->execute([

                    $first_name,
                    $last_name,
                    $email,
                    $phone,
                    $avatar,
                    $user_id

                ]);



                $_SESSION['first_name']
                =
                $first_name;

                $_SESSION['avatar']
                =
                $avatar;


                $success_msg =
                "Profile updated successfully.";

            }


        }


    }


}



// Fetch user

$stmt =
$pdo->prepare(
"SELECT * FROM users WHERE id=?"
);


$stmt->execute([
    $user_id
]);


$current_user =
$stmt->fetch(PDO::FETCH_ASSOC);

$page_title = 'My Profile | InfraVault';

require_once __DIR__ . '/includes/sidebar.php';
require_once __DIR__ . '/includes/header.php';
?>
<div class="content">
<!DOCTYPE html>

<html lang="en">


<head>


<meta charset="UTF-8">


<title>
My Profile | <?= htmlspecialchars($appName) ?>
</title>


<link rel="stylesheet"
href="assets/css/style.css">


<link rel="stylesheet"
href="assets/css/dashboard.css">



<style>


.settings-wrapper{


max-width:900px;

margin:auto;


}



.settings-grid{


display:grid;

grid-template-columns:

1fr 1fr;


gap:25px;


}



.settings-card{


background:var(--bg-content);

border:1px solid var(--border-color);

border-radius:18px;

padding:28px;


box-shadow:

0 5px 20px rgba(15,23,42,.05);


}



.settings-card h2{


font-size:20px;

margin-bottom:8px;

color:var(--text-primary);


}



.settings-card p{


color:var(--text-secondary);

font-size:14px;

margin-bottom:25px;


}



.form-group{


margin-bottom:18px;


}



.form-group label{


display:block;

font-size:13px;

font-weight:600;

margin-bottom:6px;

color:var(--text-secondary);


}



.form-control{


width:100%;

height:40px;

border-radius:8px;

border:1px solid var(--border-color);

padding:0 12px;

font-size:14px;


}



.form-control:focus{


outline:none;

border-color:#2563EB;


}



.locked{


background:var(--hover-bg);

color:var(--text-secondary);

cursor:not-allowed;


}



.save-btn{


background:#2563EB;

color:white;

border:none;

padding:11px 22px;

border-radius:9px;

font-weight:600;

cursor:pointer;


}



.save-btn:hover{


background:#1D4ED8;


}



.password-title{


margin-top:20px;

padding-top:20px;

border-top:1px solid var(--border-color);


}



.alert{


padding:14px;

border-radius:10px;

margin-bottom:20px;

font-size:14px;


}



.alert-success{


background:#ECFDF5;

color:#047857;


}



.alert-error{


background:#FEF2F2;

color:#B91C1C;


}



@media(max-width:900px){


.settings-grid{


grid-template-columns:1fr;


}


}



</style>


</head>



<body>










<main>


<div class="settings-wrapper">



<?php if($success_msg): ?>

<div class="alert alert-success">

<?= htmlspecialchars($success_msg) ?>

</div>

<?php endif; ?>



<?php if($error_msg): ?>

<div class="alert alert-error">

<?= htmlspecialchars($error_msg) ?>

</div>

<?php endif; ?>





<form method="POST">



<div class="settings-grid">



<!-- PROFILE -->


<div class="settings-card">


<h2>
Profile Information
</h2>


<p>
Update your personal account details.
</p>




<div class="form-group">

<label>
NCGR ID
</label>


<input
class="form-control locked"
value="<?= htmlspecialchars($current_user['ncgr_id']) ?>"
disabled>


<small style="color:var(--text-secondary);font-size:12px;">
NCGR ID cannot be modified.
</small>


</div>




<div class="form-group">


<label>
First Name
</label>


<input
type="text"
name="first_name"
class="form-control"
value="<?= htmlspecialchars($current_user['first_name']) ?>"
required>


</div>





<div class="form-group">


<label>
Last Name
</label>


<input
type="text"
name="last_name"
class="form-control"
value="<?= htmlspecialchars($current_user['last_name']) ?>"
required>


</div>





<div class="form-group">


<label>Avatar Style</label>

<?php
/*
| Options come from includes/avatars.php so this picker and the avatar
| shown in the header can never drift apart -- they used to be two
| separate hand-maintained lists.
|
| avatarResolveKey() maps values saved under the previous emoji set onto
| the current one, so an existing profile stays selected instead of
| silently falling back to initials.
*/
require_once __DIR__ . '/includes/avatars.php';

$colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];
$color = $colors[$current_user['id'] % count($colors)];
$user_initial = strtoupper(substr($current_user['first_name'], 0, 1));

$current_avatar = avatarResolveKey($current_user['avatar'] ?? '');
?>

<?php
/*
| One continuous grid, no group headings and no captions -- the pictures
| identify themselves.
|
| The names still exist for anyone who cannot see the picture: each
| option carries a title (hover tooltip) and the radio an aria-label, so
| removing the visible captions costs nothing in accessibility. A radio
| inside a label with no text would otherwise have no accessible name at
| all.
*/
?>

<div class="avatar-picker">

    <div class="avatar-grid">

        <label class="avatar-option <?= $current_avatar === 'initials' ? 'is-selected' : '' ?>" title="Initials">
            <input type="radio" name="avatar" value="initials" aria-label="Initials"
                <?= $current_avatar === 'initials' ? 'checked' : '' ?>>
            <span class="avatar-art"><?= renderAvatar('initials', 54, $user_initial, $color) ?></span>
        </label>

        <?php foreach (avatarGroups() as $groupName => $groupAvatars): ?>
            <?php foreach ($groupAvatars as $key => $meta): ?>
                <?php $name = $meta['label'] . ' (' . $groupName . ')'; ?>
                <label class="avatar-option <?= $current_avatar === $key ? 'is-selected' : '' ?>"
                    title="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>">
                    <input type="radio" name="avatar" value="<?= htmlspecialchars($key, ENT_QUOTES, 'UTF-8') ?>"
                        aria-label="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>"
                        <?= $current_avatar === $key ? 'checked' : '' ?>>
                    <span class="avatar-art"><?= renderAvatar($key, 54) ?></span>
                </label>
            <?php endforeach; ?>
        <?php endforeach; ?>

    </div>

</div>

<style>
.avatar-picker{
    margin-top:10px;
}

/* Tighter than when each tile carried a caption: with no text the tiles
   can sit closer without the grid reading as crowded. */
.avatar-grid{
    display:grid;
    grid-template-columns:repeat(auto-fill,minmax(66px,1fr));
    gap:10px;
}

.avatar-option{
    display:flex;
    align-items:center;
    justify-content:center;
    padding:5px;
    border-radius:50%;
    border:2px solid transparent;
    cursor:pointer;
    transition:.15s;
}

.avatar-option:hover{
    background:var(--hover-bg,#F1F5F9);
}

.avatar-option.is-selected{
    border-color:var(--accent,#3B82F6);
    background:var(--hover-bg,#F1F5F9);
}

/* The radio is the accessible control but adds nothing visually once the
   selected tile is outlined; kept reachable rather than display:none so
   it stays keyboard- and screen-reader-operable. */
.avatar-option input[type="radio"]{
    position:absolute;
    opacity:0;
    width:0;
    height:0;
}

.avatar-option:focus-within{
    border-color:var(--accent,#3B82F6);
    outline:2px solid var(--focus-ring,rgba(59,130,246,.4));
    outline-offset:2px;
}

.avatar-art{
    display:block;
    line-height:0;
}

.avatar-art svg{
    display:block;
    border-radius:50%;
}
</style>

</div>


<div class="form-group">


<label>
Email Address
</label>


<input
type="email"
name="email"
class="form-control"
value="<?= htmlspecialchars($current_user['email']) ?>"
required>


<label>
Phone Number
</label>


<input
type="tel"
name="phone"
class="form-control"
placeholder="Mobile number reachable for on-call"
value="<?= htmlspecialchars($current_user['phone'] ?? '') ?>">


</div>


</div>







<!-- SECURITY -->


<div class="settings-card">


<h2>
Security
</h2>


<p>
Change your account password.
</p>




<div class="form-group">


<label>
Current Password
</label>


<input
type="password"
name="current_password"
class="form-control">


</div>





<div class="form-group">


<label>
New Password
</label>


<input
type="password"
name="new_password"
class="form-control">


</div>





<div class="form-group">


<label>
Confirm Password
</label>


<input
type="password"
name="confirm_password"
class="form-control">


</div>





<button
type="submit"
class="save-btn">


Save Changes


</button>



</div>



</div>


</form>



</div>



</main>


</div>




<?php

require_once __DIR__ .
'/includes/footer.php';

?>




<script src="assets/js/sidebar.js"></script>



</body>


</html>
