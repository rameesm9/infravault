<?php
// tasks.php - unified endpoint for viewing and saving a decommission checklist.
// Replaces the old get_tasks.php + save_tasks.php pair: GET renders the
// checklist, POST saves progress and then renders the fresh state back in
// the same response so the modal only needs a single round trip.

session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo '<p class="task-error">You must be signed in to view this checklist.</p>';
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('dashboard', 'can_view');


$role = trim($_SESSION['role'] ?? '');
$can_edit_role = authzCan($pdo, $role, 'decommission', 'can_edit');
$username = ($_SESSION['first_name'] ?? 'User') . ' (' . ($_SESSION['ncgr_id'] ?? '') . ')';

$decommission_id = $_GET['decommission_id'] ?? ($_POST['decommission_id'] ?? null);

if (!$decommission_id) {
    echo '<p class="task-error">Invalid decommission record.</p>';
    exit;
}

$editable = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$can_edit_role) {
        http_response_code(403);
        echo '<p class="task-error">You do not have permission to update this checklist.</p>';
        exit;
    }

    $task_status = $_POST['task_status'] ?? [];
    $task_req = $_POST['task_req'] ?? [];

    $id_stmt = $pdo->prepare("SELECT id FROM decommission_tasks WHERE decommission_id = ? ORDER BY id ASC");
    $id_stmt->execute([$decommission_id]);
    $existing_tasks = $id_stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($existing_tasks as $t) {
        $tid = $t['id'];
        $status = isset($task_status[$tid]) ? 'Completed' : 'Pending';
        $req_no = trim($task_req[$tid] ?? '');
        $up_stmt = $pdo->prepare("UPDATE decommission_tasks SET status = ?, req_no = ? WHERE id = ? AND decommission_id = ?");
        $up_stmt->execute([$status, $req_no, $tid, $decommission_id]);
    }

    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
    $h_stmt->execute([$decommission_id, $username, "Updated checklist tasks progress"]);

    // Re-render in the same mode the form was submitted in.
    $editable = isset($_POST['edit_mode']) && $_POST['edit_mode'] == '1' && $can_edit_role;
} else {
    $editable = isset($_GET['edit']) && $_GET['edit'] == '1' && $can_edit_role;
}

$stmt = $pdo->prepare("SELECT * FROM decommission_tasks WHERE decommission_id = ? ORDER BY id ASC");
$stmt->execute([$decommission_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = count($tasks);
$done = 0;
foreach ($tasks as $t) {
    if ($t['status'] === 'Completed') {
        $done++;
    }
}
$pct = $total > 0 ? (int) round(($done / $total) * 100) : 0;
?>
<div class="task-progress">
    <div class="task-progress-top">
        <span><?php echo $done; ?> of <?php echo $total; ?> tasks completed</span>
        <span class="task-progress-pct"><?php echo $pct; ?>%</span>
    </div>
    <div class="task-progress-bar"><div style="width: <?php echo $pct; ?>%;"></div></div>
</div>

<form id="inlineTaskForm" onsubmit="submitTaskForm(event, <?php echo (int) $decommission_id; ?>)">
    <input type="hidden" name="decommission_id" value="<?php echo (int) $decommission_id; ?>">
    <input type="hidden" name="edit_mode" value="<?php echo $editable ? '1' : '0'; ?>">

    <div class="task-table-wrap">
        <table class="task-table">
            <thead>
                <tr>
                    <th class="task-col-check">Done</th>
                    <th>Task Description</th>
                    <th class="task-col-req">REQ No / Reference</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($total > 0): ?>
                    <?php foreach ($tasks as $t):
                        $tid = $t['id'];
                        $is_completed = $t['status'] === 'Completed';
                        $req_val = htmlspecialchars($t['req_no'] ?? '');
                    ?>
                    <tr class="<?php echo $is_completed ? 'task-row-done' : ''; ?>">
                        <td class="task-col-check">
                            <?php if ($editable): ?>
                                <input type="checkbox" name="task_status[<?php echo $tid; ?>]" value="Completed" <?php echo $is_completed ? 'checked' : ''; ?> class="task-checkbox">
                            <?php else: ?>
                                <span class="task-status-badge <?php echo $is_completed ? 'is-done' : 'is-pending'; ?>"><?php echo $is_completed ? '✓' : '—'; ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="task-desc"><?php echo htmlspecialchars($t['task_name']); ?></td>
                        <td class="task-col-req">
                            <?php if ($editable): ?>
                                <input type="text" name="task_req[<?php echo $tid; ?>]" value="<?php echo $req_val; ?>" class="task-req-input" placeholder="Enter REQ NO...">
                            <?php else: ?>
                                <span class="task-req-readonly"><?php echo $req_val !== '' ? $req_val : '—'; ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="task-empty">No checklist tasks defined for this record.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="task-modal-footer-row">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Close</button>
        <?php if ($editable): ?>
            <button type="submit" class="btn btn-success"><i class="fa-solid fa-check"></i> Save Checklist Progress</button>
        <?php endif; ?>
    </div>
</form>
