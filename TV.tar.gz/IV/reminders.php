<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/audit_helpers.php';
require_once __DIR__ . '/includes/reminder-mail.php';
require_once __DIR__ . '/includes/pagination-helpers.php';

/*
| No session_start() here -- config/db.php's securityBootstrap() already
| started it with the hardened cookie parameters (see change-password.php
| for the same pattern). Calling it again after requiring db.php made PHP
| emit "Ignoring session_start() because a session is already active",
| and with display_errors on that warning text landed in front of the
| save_note JSON response, which broke response.json() in the browser --
| the note saved to the database fine, but the page never got the success
| reply telling it to reload, so the new/edited note only showed up after
| a manual refresh.
*/


/*
=========================================
FLASH MESSAGE
=========================================
*/

$success_msg = $_SESSION['success_msg'] ?? '';
$error_msg   = $_SESSION['error_msg'] ?? '';

unset($_SESSION['success_msg']);
unset($_SESSION['error_msg']);



/*
=========================================
AUTHENTICATION
=========================================
*/

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('reminders', 'can_view');




$current_user_id = (int)$_SESSION['user_id'];

$current_name = $_SESSION['first_name'] ?? $_SESSION['name'] ?? '';

$role = strtolower(trim($_SESSION['role'] ?? ''));

$current_user_team = $_SESSION['team'] ?? '';




/*
=========================================
HELPERS
=========================================
*/

function isAdmin($role)
{
    return strtolower($role) === 'admin';
}



function canManage($owner_id,$current_id,$role)
{
    return (
        (int)$owner_id === (int)$current_id
        ||
        isAdmin($role)
    );
}



function canViewReminder($reminder, $current_user_id, $current_user_team, $role, $pdo)
{
    if(isAdmin($role)) return true;
    if((int)$reminder['user_id'] === (int)$current_user_id) return true;

    if($reminder['visibility'] === 'public') return true;

    if($reminder['visibility'] === 'private') return false;

    if($reminder['visibility'] === 'team' && !empty($current_user_team)) {
        $stmt = $pdo->prepare("SELECT 1 FROM reminder_teams WHERE reminder_id=? AND team_name=? LIMIT 1");
        $stmt->execute([$reminder['id'], $current_user_team]);
        if($stmt->fetch()) return true;
    }

    if($reminder['visibility'] === 'user') {
        $stmt = $pdo->prepare("SELECT 1 FROM reminder_users WHERE reminder_id=? AND user_id=? LIMIT 1");
        $stmt->execute([$reminder['id'], $current_user_id]);
        if($stmt->fetch()) return true;
    }

    return false;
}



function canViewNote($note, $current_user_id, $current_user_team, $role, $pdo)
{
    if(isAdmin($role)) return true;
    if((int)$note['user_id'] === (int)$current_user_id) return true;

    if($note['visibility'] === 'public') return true;

    if($note['visibility'] === 'private') return false;

    if($note['visibility'] === 'team' && !empty($current_user_team)) {
        $stmt = $pdo->prepare("SELECT 1 FROM sticky_note_teams WHERE sticky_note_id=? AND team_name=? LIMIT 1");
        $stmt->execute([$note['id'], $current_user_team]);
        if($stmt->fetch()) return true;
    }

    if($note['visibility'] === 'user') {
        $stmt = $pdo->prepare("SELECT 1 FROM sticky_note_users WHERE sticky_note_id=? AND user_id=? LIMIT 1");
        $stmt->execute([$note['id'], $current_user_id]);
        if($stmt->fetch()) return true;
    }

    return false;
}



function getUniqueTeams($pdo)
{
    $stmt = $pdo->query("SELECT DISTINCT team FROM users WHERE team IS NOT NULL AND team != '' ORDER BY team ASC");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}



function getAllUsers($pdo)
{
    $stmt = $pdo->query("SELECT id, first_name, last_name, email FROM users ORDER BY first_name, last_name ASC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}



/*
| Used to pre-check the team/user checkboxes when an existing note is
| opened for editing. Without this, re-saving a "team" or "user" note
| with the checkboxes left blank looked harmless but silently wiped its
| sharing -- save_note always deletes and re-inserts the associations,
| so an empty selection turns the note effectively private again while
| the visibility label still says "Team"/"Users".
*/
function getNoteTeams($pdo, $note_id)
{
    $stmt = $pdo->prepare("SELECT team_name FROM sticky_note_teams WHERE sticky_note_id=?");
    $stmt->execute([$note_id]);
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function getNoteUserIds($pdo, $note_id)
{
    $stmt = $pdo->prepare("SELECT user_id FROM sticky_note_users WHERE sticky_note_id=?");
    $stmt->execute([$note_id]);
    return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
}



function getVisibilityDisplay($visibility, $id, $type, $pdo)
{
    $visibility = strtolower($visibility);

    if($visibility === 'public') {
        return '<span class="status-all">Everyone</span>';
    }

    if($visibility === 'private') {
        return '<span class="status-private">Private</span>';
    }

    if($visibility === 'team') {
        $table = $type === 'reminder' ? 'reminder_teams' : ($type === 'note' ? 'sticky_note_teams' : 'mydata_teams');
        $id_col = $type === 'reminder' ? 'reminder_id' : ($type === 'note' ? 'sticky_note_id' : 'mydata_id');
        $stmt = $pdo->prepare("SELECT GROUP_CONCAT(team_name, ', ') as teams FROM $table WHERE $id_col = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $teams = $result['teams'] ?? '';
        return '<span class="status-team" title="' . htmlspecialchars($teams) . '">Team (' . count(explode(',', $teams)) . ')</span>';
    }

    if($visibility === 'user') {
        $table = $type === 'reminder' ? 'reminder_users' : ($type === 'note' ? 'sticky_note_users' : 'mydata_users');
        $id_col = $type === 'reminder' ? 'reminder_id' : ($type === 'note' ? 'sticky_note_id' : 'mydata_id');
        $stmt = $pdo->prepare("SELECT COUNT(*) as count FROM $table WHERE $id_col = ?");
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $count = $result['count'] ?? 0;
        return '<span class="status-user">Users (' . $count . ')</span>';
    }

    return '<span class="status-private">Unknown</span>';
}





/*
=========================================
POST ACTIONS
=========================================
*/

if($_SERVER['REQUEST_METHOD']==='POST'){


    $action = $_POST['action'] ?? '';



    /*
    =========================================
    CREATE REMINDER
    =========================================
    */


    if($action === 'save_reminder'){


        $title = trim($_POST['title'] ?? '');

        $message = trim($_POST['message'] ?? '');

        $visibility = $_POST['visibility'] ?? 'private';

        $emails = trim($_POST['additional_emails'] ?? '');

        $selected_teams = $_POST['reminder_teams'] ?? [];
        $selected_users = $_POST['reminder_users'] ?? [];

        if(!is_array($selected_teams)) $selected_teams = [];
        if(!is_array($selected_users)) $selected_users = [];

        /*
        FIX DATE HANDLING
        */

        $date = trim($_POST['full_reminder_date'] ?? '');

        if(
            empty($date)
            &&
            !empty($_POST['reminder_date'])
            &&
            !empty($_POST['reminder_time'])
        ){

            $date =
            $_POST['reminder_date']
            .' '
            .$_POST['reminder_time']
            .':00';

        }



        if(
            empty($title)
            ||
            empty($message)
            ||
            empty($date)
        ){

            $_SESSION['error_msg'] =
            "Please fill all reminder fields.";

            header("Location: reminders.php");
            exit;

        }




        try{


            $pdo->beginTransaction();



            $stmt=$pdo->prepare(

            "INSERT INTO reminders
            (
                user_id,
                title,
                message,
                reminder_date,
                visibility,
                additional_emails,
                created_at
            )

            VALUES(?,?,?,?,?,?,?)"

            );



            $stmt->execute([

                $current_user_id,
                $title,
                $message,
                $date,
                $visibility,
                $emails,
                date('Y-m-d H:i:s')

            ]);

            $reminder_id = $pdo->lastInsertId();

            // Save team associations
            if($visibility === 'team' && !empty($selected_teams)) {
                $team_stmt = $pdo->prepare("INSERT INTO reminder_teams (reminder_id, team_name) VALUES (?, ?)");
                foreach($selected_teams as $team) {
                    $team = trim($team);
                    if(!empty($team)) {
                        $team_stmt->execute([$reminder_id, $team]);
                    }
                }
            }

            // Save user associations
            if($visibility === 'user' && !empty($selected_users)) {
                $user_stmt = $pdo->prepare("INSERT INTO reminder_users (reminder_id, user_id) VALUES (?, ?)");
                foreach($selected_users as $user_id) {
                    $user_id = (int)$user_id;
                    if($user_id > 0) {
                        $user_stmt->execute([$reminder_id, $user_id]);
                    }
                }
            }

            $pdo->commit();

            // Log audit entry
            logReminderAudit($pdo, $reminder_id, 'CREATED', $current_user_id, $current_name, "Title: {$title}");

            $_SESSION['success_msg'] =
            "Reminder created successfully.";



            /*
            PRG PATTERN
            Prevent duplicate submission
            */

            header("Location: reminders.php");
            exit;



        }
        catch(Exception $e){


            if($pdo->inTransaction()){
                $pdo->rollBack();
            }


            $_SESSION['error_msg'] =
            "Unable to save reminder: ".$e->getMessage();


            header("Location: reminders.php");
            exit;

        }



    }






    /*
    =========================================
    EDIT REMINDER
    =========================================
    */


    if($action==='edit_reminder'){


        $id=(int)$_POST['reminder_id'];

        $visibility = $_POST['visibility'] ?? 'private';

        $selected_teams = $_POST['reminder_teams'] ?? [];
        $selected_users = $_POST['reminder_users'] ?? [];

        if(!is_array($selected_teams)) $selected_teams = [];
        if(!is_array($selected_users)) $selected_users = [];

        try{

            // Check if reminder exists and user has permission to edit
            $check_stmt = $pdo->prepare("SELECT user_id FROM reminders WHERE id = ?");
            $check_stmt->execute([$id]);
            $reminder = $check_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reminder) {
                $_SESSION['error_msg'] = "Reminder not found.";
                header("Location: reminders.php");
                exit;
            }

            // Check permission: user must have can_edit permission OR be the author
            if (!canEdit($pdo, $current_user_id, $role, 'reminders', $reminder['user_id'])) {
                $_SESSION['error_msg'] = "Permission denied. You cannot edit this reminder.";
                header("Location: reminders.php");
                exit;
            }

            $pdo->beginTransaction();

            $stmt=$pdo->prepare(

            "UPDATE reminders SET

            title=?,
            message=?,
            reminder_date=?,
            visibility=?,
            additional_emails=?

            WHERE id=?

            "

            );



            $stmt->execute([

                $_POST['title'],

                $_POST['message'],

                $_POST['full_reminder_date'],

                $visibility,

                $_POST['additional_emails'],

                $id

            ]);

            // Clear existing team/user associations
            $pdo->prepare("DELETE FROM reminder_teams WHERE reminder_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM reminder_users WHERE reminder_id=?")->execute([$id]);

            // Save team associations
            if($visibility === 'team' && !empty($selected_teams)) {
                $team_stmt = $pdo->prepare("INSERT INTO reminder_teams (reminder_id, team_name) VALUES (?, ?)");
                foreach($selected_teams as $team) {
                    $team = trim($team);
                    if(!empty($team)) {
                        $team_stmt->execute([$id, $team]);
                    }
                }
            }

            // Save user associations
            if($visibility === 'user' && !empty($selected_users)) {
                $user_stmt = $pdo->prepare("INSERT INTO reminder_users (reminder_id, user_id) VALUES (?, ?)");
                foreach($selected_users as $user_id) {
                    $user_id = (int)$user_id;
                    if($user_id > 0) {
                        $user_stmt->execute([$id, $user_id]);
                    }
                }
            }

            $pdo->commit();

            // Log audit entry
            logReminderAudit($pdo, $id, 'UPDATED', $current_user_id, $current_name, "Title: {$_POST['title']}");

            $_SESSION['success_msg']="Reminder updated successfully.";

            header("Location: reminders.php");
            exit;

        }
        catch(Exception $e){

            if($pdo->inTransaction()){
                $pdo->rollBack();
            }

            $_SESSION['error_msg']="Unable to update reminder: ".$e->getMessage();

            header("Location: reminders.php");
            exit;

        }

    }







    /*
    =========================================
    DELETE REMINDER
    =========================================
    */


    if($action==='delete_reminder'){


        $id=(int)$_POST['reminder_id'];

        try{

            // Check if reminder exists and user has permission to delete
            $check_stmt = $pdo->prepare("SELECT user_id FROM reminders WHERE id = ?");
            $check_stmt->execute([$id]);
            $reminder = $check_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$reminder) {
                $_SESSION['error_msg'] = "Reminder not found.";
                header("Location: reminders.php");
                exit;
            }

            // Check permission: user must have can_delete permission OR be the author
            if (!canDelete($pdo, $current_user_id, $role, 'reminders', $reminder['user_id'])) {
                $_SESSION['error_msg'] = "Permission denied. You cannot delete this reminder.";
                header("Location: reminders.php");
                exit;
            }

            $pdo->beginTransaction();

            $stmt=$pdo->prepare(

            "DELETE FROM reminders

            WHERE id=?"

            );



            $stmt->execute([

                $id

            ]);

            // Delete associated team/user entries (if FOREIGN KEY cascade doesn't work)
            $pdo->prepare("DELETE FROM reminder_teams WHERE reminder_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM reminder_users WHERE reminder_id=?")->execute([$id]);

            $pdo->commit();

            // Log audit entry before redirect
            logReminderAudit($pdo, $id, 'DELETED', $current_user_id, $current_name, "Reminder ID: {$id}");

            $_SESSION['success_msg']="Reminder deleted successfully.";

            header("Location: reminders.php");
            exit;

        }
        catch(Exception $e){

            if($pdo->inTransaction()){
                $pdo->rollBack();
            }

            $_SESSION['error_msg']="Unable to delete reminder: ".$e->getMessage();

            header("Location: reminders.php");
            exit;

        }

    }

    /*
    =========================================
    SEND REMINDER NOW (manual trigger)
    =========================================
    | Same recipient logic as reminder_notification_cron.php: reminder
    | owner + "Additional Emails", plus whoever its visibility scopes it
    | to (specific users, a team's mailbox, or every team for "public").
    | Does not touch reminder_sent_at, so the scheduled cron notification
    | still fires normally at/after the reminder's date/time -- this is
    | just an on-demand extra send.
    */

    if($action === 'send_reminder_now'){

        $id = (int)($_POST['reminder_id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT r.*, u.first_name AS owner_first_name, u.last_name AS owner_last_name, u.email AS owner_email
            FROM reminders r
            LEFT JOIN users u ON u.id = r.user_id
            WHERE r.id = ?
        ");
        $stmt->execute([$id]);
        $reminder = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$reminder) {
            $_SESSION['error_msg'] = "Reminder not found.";
            header("Location: reminders.php");
            exit;
        }

        if (!canManage($reminder['user_id'], $current_user_id, $role)) {
            $_SESSION['error_msg'] = "Permission denied. You cannot send this reminder.";
            header("Location: reminders.php");
            exit;
        }

        $recipients = buildReminderRecipients($reminder, $pdo);

        if (empty($recipients)) {
            $_SESSION['error_msg'] = "No valid recipient email addresses on this reminder.";
            header("Location: reminders.php");
            exit;
        }

        $subject = "Reminder: {$reminder['title']}";
        $html = '<p>' . nl2br(htmlspecialchars((string) $reminder['message'], ENT_QUOTES, 'UTF-8')) . '</p>'
            . '<p><strong>Scheduled for:</strong> ' . htmlspecialchars((string) $reminder['reminder_date'], ENT_QUOTES, 'UTF-8') . '</p>'
            . '<p style="color:var(--text-secondary);font-size:12px;">Sent by ' . htmlspecialchars(getAppName($pdo), ENT_QUOTES, 'UTF-8') . ' Reminders &amp; Notes.</p>';

        $sentCount = 0;
        $failMessages = [];

        foreach ($recipients as $email => $name) {
            $result = sendAppMail($pdo, 'reminder_notifications', $email, $name, $subject, $html);
            if ($result['success']) {
                $sentCount++;
            } else {
                $failMessages[] = "{$email}: {$result['message']}";
            }
        }

        logReminderAudit(
            $pdo, $id, 'EMAIL_SENT', $current_user_id, $current_name,
            "Manually sent to " . $sentCount . " of " . count($recipients) . " recipient(s)"
        );

        if ($sentCount > 0 && empty($failMessages)) {
            $_SESSION['success_msg'] = "Reminder email sent to {$sentCount} recipient(s).";
        } elseif ($sentCount > 0) {
            $_SESSION['success_msg'] = "Reminder email sent to {$sentCount} recipient(s), but failed for: " . implode('; ', $failMessages);
        } else {
            $_SESSION['error_msg'] = "Could not send reminder: " . implode('; ', $failMessages);
        }

        header("Location: reminders.php");
        exit;
    }

        /*
    =========================================
    SAVE STICKY NOTE
    =========================================
    */

    if($action === 'save_note'){


        $content = trim($_POST['content'] ?? '');

        $visibility = $_POST['visibility'] ?? 'private';

        $id = (int)($_POST['note_id'] ?? 0);

        $selected_teams = $_POST['note_teams'] ?? [];
        $selected_users = $_POST['note_users'] ?? [];

        if(!is_array($selected_teams)) $selected_teams = [];
        if(!is_array($selected_users)) $selected_users = [];


        header('Content-Type: application/json');


        if(empty($content)){

            echo json_encode([
                "status"=>"error",
                "message"=>"Empty note"
            ]);

            exit;

        }



        try{

            $pdo->beginTransaction();

            if($id > 0){

                // Check if note exists and user has permission to edit
                $check_stmt = $pdo->prepare("SELECT user_id FROM sticky_notes WHERE id = ?");
                $check_stmt->execute([$id]);
                $note = $check_stmt->fetch(PDO::FETCH_ASSOC);

                if (!$note) {
                    echo json_encode([
                        "status"=>"error",
                        "message"=>"Note not found"
                    ]);
                    exit;
                }

                // Check permission: user must have can_edit permission OR be the author
                if (!canEdit($pdo, $current_user_id, $role, 'reminders', $note['user_id'])) {
                    echo json_encode([
                        "status"=>"error",
                        "message"=>"Permission denied. You cannot edit this note."
                    ]);
                    exit;
                }

                $stmt=$pdo->prepare("

                UPDATE sticky_notes SET

                content=?,

                visibility=?,

                updated_at=?

                WHERE id=?

                ");



                $stmt->execute([

                    $content,

                    $visibility,

                    date('Y-m-d H:i:s'),

                    $id

                ]);

                // Clear existing team/user associations
                $pdo->prepare("DELETE FROM sticky_note_teams WHERE sticky_note_id=?")->execute([$id]);
                $pdo->prepare("DELETE FROM sticky_note_users WHERE sticky_note_id=?")->execute([$id]);

                $action = 'UPDATED';

            }
            else{


                $stmt=$pdo->prepare("

                INSERT INTO sticky_notes

                (
                    user_id,
                    content,
                    visibility,
                    updated_at
                )

                VALUES(?,?,?,?)

                ");



                $stmt->execute([

                    $current_user_id,

                    $content,

                    $visibility,

                    date('Y-m-d H:i:s')

                ]);

                $id = $pdo->lastInsertId();
                $action = 'CREATED';

            }

            // Save team associations
            if($visibility === 'team' && !empty($selected_teams)) {
                $team_stmt = $pdo->prepare("INSERT INTO sticky_note_teams (sticky_note_id, team_name) VALUES (?, ?)");
                foreach($selected_teams as $team) {
                    $team = trim($team);
                    if(!empty($team)) {
                        $team_stmt->execute([$id, $team]);
                    }
                }
            }

            // Save user associations
            if($visibility === 'user' && !empty($selected_users)) {
                $user_stmt = $pdo->prepare("INSERT INTO sticky_note_users (sticky_note_id, user_id) VALUES (?, ?)");
                foreach($selected_users as $user_id) {
                    $user_id = (int)$user_id;
                    if($user_id > 0) {
                        $user_stmt->execute([$id, $user_id]);
                    }
                }
            }

            $pdo->commit();

            // Log audit entry
            logStickyNoteAudit($pdo, $id, $action, $current_user_id, $current_name, null);

            echo json_encode([
                "status"=>"success"
            ]);


        }
        catch(Exception $e){

            if($pdo->inTransaction()){
                $pdo->rollBack();
            }

            echo json_encode([

                "status"=>"error",

                "message"=>$e->getMessage()

            ]);


        }


        exit;

    }






    /*
    =========================================
    DELETE STICKY NOTE
    =========================================
    */


    if($action === 'delete_note'){


        $id=(int)($_POST['note_id'] ?? 0);

        try{

            // Check if note exists and user has permission to delete
            $check_stmt = $pdo->prepare("SELECT user_id FROM sticky_notes WHERE id = ?");
            $check_stmt->execute([$id]);
            $note = $check_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$note) {
                header('Content-Type: application/json');
                echo json_encode([
                    "status"=>"error",
                    "message"=>"Note not found"
                ]);
                exit;
            }

            // Check permission: user must have can_delete permission OR be the author
            if (!canDelete($pdo, $current_user_id, $role, 'reminders', $note['user_id'])) {
                header('Content-Type: application/json');
                echo json_encode([
                    "status"=>"error",
                    "message"=>"Permission denied. You cannot delete this note."
                ]);
                exit;
            }

            $pdo->beginTransaction();

            $stmt=$pdo->prepare("

            DELETE FROM sticky_notes

            WHERE id=?

            ");



            $stmt->execute([

                $id

            ]);

            // Delete associated team/user entries
            $pdo->prepare("DELETE FROM sticky_note_teams WHERE sticky_note_id=?")->execute([$id]);
            $pdo->prepare("DELETE FROM sticky_note_users WHERE sticky_note_id=?")->execute([$id]);

            $pdo->commit();

            // Log audit entry
            logStickyNoteAudit($pdo, $id, 'DELETED', $current_user_id, $current_name, null);

            header('Content-Type: application/json');


            echo json_encode([

                "status"=>"success"

            ]);

        }
        catch(Exception $e){

            if($pdo->inTransaction()){
                $pdo->rollBack();
            }

            header('Content-Type: application/json');

            echo json_encode([
                "status"=>"error",
                "message"=>$e->getMessage()
            ]);

        }

        exit;


    }

}


/*
=========================================
FETCH AUDIT HISTORY (AJAX)
=========================================
*/

if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'get_audit_history'){

    header('Content-Type: application/json');

    $type = $_POST['type'] ?? '';
    $id = (int)($_POST['id'] ?? 0);

    if(empty($type)) {
        echo json_encode(['error' => 'Invalid request']);
        exit;
    }

    // Check permission
    if(!canAudit($pdo, $current_user_id, $role, $type)) {
        echo json_encode(['error' => 'No audit permission']);
        exit;
    }

    $history = [];

    // If ID is provided, get history for that specific record
    if($id > 0) {
        switch($type) {
            case 'reminder':
                $history = getReminderAuditHistory($pdo, $id);
                break;
            case 'sticky_note':
                $history = getStickyNoteAuditHistory($pdo, $id);
                break;
            case 'communication':
                $history = getCommunicationAuditHistory($pdo, $id);
                break;
            case 'mydata':
                $history = getMydataAuditHistory($pdo, $id);
                break;
        }
    } else {
        // Get all history for the module type
        $history = getAllAuditHistory($pdo, $type);
    }

    echo json_encode($history);
    exit;
}




/*
=========================================
FETCH STICKY NOTES
=========================================
*/


$stmt=$pdo->query("

SELECT
    sn.*,
    u.first_name,
    u.email

FROM sticky_notes sn
LEFT JOIN users u ON sn.user_id = u.id

ORDER BY sn.updated_at DESC

");



$all_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter notes based on visibility
$sticky_notes = array_filter($all_notes, function($note) use ($current_user_id, $current_user_team, $role, $pdo) {
    return canViewNote($note, $current_user_id, $current_user_team, $role, $pdo);
});







/*
=========================================
FETCH REMINDERS
=========================================
*/


$stmt = $pdo->query("
SELECT
    r.*,
    u.first_name,
    u.last_name
FROM reminders r
LEFT JOIN users u
    ON r.user_id = u.id
ORDER BY r.reminder_date ASC
");

$all_reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter reminders based on visibility
$reminders = array_filter($all_reminders, function($reminder) use ($current_user_id, $current_user_team, $role, $pdo) {
    return canViewReminder($reminder, $current_user_id, $current_user_team, $role, $pdo);
});


/*
=========================================
REMINDERS LIST: SEARCH, SORT, PAGINATION
(operates on the already visibility-filtered
$reminders array -- $reminders itself is left
untouched above for any other/future use)
=========================================
*/

$reminder_keyword = trim($_GET['keyword'] ?? '');

$reminder_sort_columns = ['reminder_date', 'title', 'created_at'];
$reminder_sort_by = $_GET['sort_by'] ?? 'reminder_date';
if (!in_array($reminder_sort_by, $reminder_sort_columns, true)) {
    $reminder_sort_by = 'reminder_date';
}
$reminder_sort_order = (strtoupper($_GET['sort_order'] ?? 'ASC') === 'DESC') ? 'DESC' : 'ASC';

$searched_reminders = array_values($reminders);

if ($reminder_keyword !== '') {
    $searched_reminders = array_values(array_filter($searched_reminders, function ($r) use ($reminder_keyword) {
        return stripos($r['title'] ?? '', $reminder_keyword) !== false
            || stripos($r['message'] ?? '', $reminder_keyword) !== false;
    }));
}

if ($_GET['sort_by'] ?? '') {
    usort($searched_reminders, function ($a, $b) use ($reminder_sort_by, $reminder_sort_order) {
        $cmp = strnatcasecmp($a[$reminder_sort_by] ?? '', $b[$reminder_sort_by] ?? '');
        return $reminder_sort_order === 'DESC' ? -$cmp : $cmp;
    });
}

$filtered_total = count($searched_reminders);
$page_size = resolveUserPageSize($pdo, $current_user_id);
$current_page = max(1, (int) ($_GET['page'] ?? 1));
$total_pages = max(1, (int) ceil($filtered_total / $page_size));
if ($current_page > $total_pages) {
    $current_page = $total_pages;
}
$offset = ($current_page - 1) * $page_size;
$paginated_reminders = array_slice($searched_reminders, $offset, $page_size);

$reminder_query_params = array_filter([
    'keyword' => $reminder_keyword,
    'sort_by' => $_GET['sort_by'] ?? '',
    'sort_order' => $_GET['sort_order'] ?? '',
], static fn($v) => $v !== '');

$reminder_hidden_fields = '';
foreach ($reminder_query_params as $fk => $fv) {
    $reminder_hidden_fields .= '<input type="hidden" name="' . htmlspecialchars((string) $fk) . '" value="' . htmlspecialchars((string) $fv) . '">';
}



/*
=========================================
EDIT LOAD
=========================================
*/


$edit_reminder=null;
$edit_reminder_teams = [];
$edit_reminder_users = [];


if(isset($_GET['edit_reminder'])){


$stmt=$pdo->prepare(

"SELECT *

FROM reminders

WHERE id=?"

);


$stmt->execute([

$_GET['edit_reminder']

]);


$edit_reminder=$stmt->fetch(PDO::FETCH_ASSOC);

if($edit_reminder) {
    // Load associated teams
    $team_stmt = $pdo->prepare("SELECT team_name FROM reminder_teams WHERE reminder_id=?");
    $team_stmt->execute([$edit_reminder['id']]);
    $edit_reminder_teams = $team_stmt->fetchAll(PDO::FETCH_COLUMN);

    // Load associated users
    $user_stmt = $pdo->prepare("SELECT user_id FROM reminder_users WHERE reminder_id=?");
    $user_stmt->execute([$edit_reminder['id']]);
    $edit_reminder_users = $user_stmt->fetchAll(PDO::FETCH_COLUMN);
}

}

$page_title = 'Alerts & Reminders | InfraVault';

require_once __DIR__ . '/includes/sidebar.php';
require_once __DIR__ . '/includes/header.php';

?>
<main class="content">
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>
Alerts & Reminders | <?= htmlspecialchars($appName) ?>
</title>


<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/dashboard.css">

<link rel="stylesheet" href="assets/css/reminders-enterprise.css">


</head>


<body>





<!-- =================================
MAIN AREA
================================= -->


<div class="main-wrapper">






<!-- =================================
STICKY NOTES FEED
================================= -->

<?php if(canAudit($pdo, $current_user_id, $role, 'sticky_note')): ?>
<div style="margin-bottom: 15px;">
    <button
        class="enterprise-btn btn-info"
        onclick="showAllAuditHistory('sticky_note'); return false;">
        ⏱ Sticky Notes History
    </button>
</div>
<?php endif; ?>

<section class="enterprise-card">


<h2 class="enterprise-title">

📝 Sticky Notes Feed

</h2>



<div class="notes-container">



<?php if(empty($sticky_notes)): ?>


<p>

No sticky notes available.

</p>


<?php endif; ?>





<?php foreach($sticky_notes as $note): ?>


<div class="enterprise-note">



<div class="note-text">

<?=nl2br(
htmlspecialchars(
$note['content']
)
)?>

</div>




<div class="note-footer">

<div style="margin-bottom: 8px;">
<strong>Created By:</strong> <?php
$author = $note['first_name'] ? $note['first_name'] : ($note['email'] ?? 'Unknown');
echo htmlspecialchars($author);
?>
</div>

<div style="margin-bottom: 8px;">
Visibility: <?=getVisibilityDisplay($note['visibility'], $note['id'], 'note', $pdo)?>
</div>

<div>
Updated: <?=$note['updated_at']?>
</div>

</div>







<?php if(canManage(
$note['user_id'],
$current_user_id,
$role
)): ?>



<div class="note-actions">



<button

class="enterprise-btn btn-edit"


onclick="editNote(

<?=$note['id']?>,

`<?=htmlspecialchars(
addslashes(
$note['content']
)
)?>`,

'<?=$note['visibility']?>',

<?=htmlspecialchars(json_encode($note['visibility'] === 'team' ? getNoteTeams($pdo, $note['id']) : []))?>,

<?=htmlspecialchars(json_encode($note['visibility'] === 'user' ? getNoteUserIds($pdo, $note['id']) : []))?>

)">


✏ Edit

</button>





<button

class="enterprise-btn btn-delete"


onclick="deleteNote(
<?=$note['id']?>
)">


🗑 Delete


</button>


</div>



<?php endif; ?>





</div>



<?php endforeach; ?>



</div>


</section>









<!-- =================================
REMINDER TABLE
================================= -->

<?php if(canAudit($pdo, $current_user_id, $role, 'reminder')): ?>
<div style="margin-bottom: 15px;">
    <button
        class="enterprise-btn btn-info"
        onclick="showAllAuditHistory('reminder'); return false;">
        ⏱ Reminders History
    </button>
</div>
<?php endif; ?>

<section class="enterprise-card">


<h2 class="enterprise-title">

🔔 Scheduled Reminders

</h2>


<div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;margin-bottom:12px;">

    <form method="GET" action="reminders.php" style="display:flex;gap:8px;">
        <input type="hidden" name="sort_by" value="<?= htmlspecialchars($reminder_sort_by) ?>">
        <input type="hidden" name="sort_order" value="<?= htmlspecialchars($reminder_sort_order) ?>">
        <input
            type="text"
            name="keyword"
            placeholder="Search title or message..."
            value="<?= htmlspecialchars($reminder_keyword) ?>"
        >
        <button type="submit" class="enterprise-btn btn-info">Search</button>
    </form>

    <?php if ($reminder_keyword !== ''): ?>
        <a href="reminders.php" class="enterprise-btn btn-info">Clear</a>
    <?php endif; ?>

    <?= pageSizeSelectorHtml($page_size, $reminder_hidden_fields) ?>

</div>



<div class="table-wrapper">


<table class="enterprise-table">


<thead>


<tr>

<th>
Title
</th>


<th>
Date
</th>


<th>
Owner
</th>


<th>
Visibility
</th>


<th>
Action
</th>


</tr>


</thead>



<tbody>


<?php if (empty($paginated_reminders)): ?>
<tr>
<td colspan="5" style="text-align:center;padding:25px;">
<?= $reminder_keyword !== '' ? 'No reminders match your search.' : 'No reminders found.' ?>
</td>
</tr>
<?php endif; ?>


<?php foreach($paginated_reminders as $rem): ?>


<tr>


<td>

<strong>

<?=htmlspecialchars(
$rem['title']
)?>

</strong>

</td>




<td>

<?=htmlspecialchars(
$rem['reminder_date']
)?>

</td>



<td>

<?= htmlspecialchars(trim(($rem['first_name'] ?? '') . ' ' . ($rem['last_name'] ?? ''))) ?>
</td>




<td>

<?=getVisibilityDisplay($rem['visibility'], $rem['id'], 'reminder', $pdo)?>

</td>




<td>


<?php if(canManage(
$rem['user_id'],
$current_user_id,
$role
)): ?>



<a

href="reminders.php?edit_reminder=<?=$rem['id']?>"

class="enterprise-btn btn-edit">


✏ Edit


</a>



<form method="POST"
style="display:inline">


<input type="hidden"
name="action"
value="send_reminder_now">


<input type="hidden"
name="reminder_id"
value="<?=$rem['id']?>">


<button
class="enterprise-btn btn-send"
onclick="return confirm('Send this reminder by email now?')">

📧 Send Now

</button>


</form>




<form method="POST"
style="display:inline">


<input type="hidden"
name="action"
value="delete_reminder">



<input type="hidden"
name="reminder_id"
value="<?=$rem['id']?>">





<button

class="enterprise-btn btn-delete"

onclick="return confirm('Delete reminder?')">


🗑 Delete


</button>



</form>

<?php endif; ?>


<?php if(!canManage($rem['user_id'], $current_user_id, $role) && !canAudit($pdo, $current_user_id, $role, 'reminder')): ?>

<span style="color:#94a3b8">

View Only

</span>

<?php endif; ?>



</td>


</tr>



<?php endforeach; ?>



</tbody>


</table>


</div>


<?php if ($total_pages > 1): ?>
    <div class="pagination" style="display:flex;justify-content:center;gap:6px;margin-top:20px;flex-wrap:wrap;">
        <?php for ($p = 1; $p <= $total_pages; $p++): ?>
            <a
                href="reminders.php?<?= htmlspecialchars(http_build_query(array_merge($reminder_query_params, ['page' => $p]))) ?>"
                class="enterprise-btn btn-info"
                style="<?= $p === $current_page ? 'background:#2563eb;color:#fff;border-color:#2563eb;' : '' ?>"
            >
                <?= $p ?>
            </a>
        <?php endfor; ?>
    </div>
<?php endif; ?>

<div style="text-align:center;color:var(--text-muted);font-size:12.5px;margin-top:10px;">
    Showing <?= count($paginated_reminders) ?> of <?= $filtered_total ?> reminder<?= $filtered_total === 1 ? '' : 's' ?>
</div>


</section>









<!-- =================================
CREATE / EDIT AREA
================================= -->


<div class="reminder-grid">



<section class="enterprise-card">


<h2 class="enterprise-title">


<?=

$edit_reminder

?

"✏ Edit Reminder"

:

"⏰ Create Reminder"

?>


</h2>





<form method="POST">


<input type="hidden"
name="action"
value="<?=

$edit_reminder

?

'edit_reminder'

:

'save_reminder'

?>">



<?php if($edit_reminder): ?>


<input type="hidden"
name="reminder_id"
value="<?=$edit_reminder['id']?>">


<?php endif; ?>





<div class="form-group">


<label>

Title

</label>


<input

class="form-control"

name="title"

required

value="<?=htmlspecialchars(
$edit_reminder['title'] ?? ''
)?>">


</div>







<div class="form-group">


<label>

Message

</label>


<textarea

class="form-control"

name="message"

required><?=htmlspecialchars(
$edit_reminder['message'] ?? ''
)?></textarea>


</div>





<div class="datetime-grid">


<div>


<label>
Date
</label>


<input

type="date"

name="reminder_date"
id="reminder_date"

class="form-control"

required>


</div>





<div>


<label>
Time
</label>


<input

type="time"
name="reminder_date"

id="reminder_time"

class="form-control"

step="60"

required>


</div>


</div>





<input

type="hidden"

name="full_reminder_date"

id="full_reminder_date">






<div class="form-group">


<label>

Additional Emails

</label>


<input

class="form-control"

name="additional_emails"

value="<?=htmlspecialchars(
$edit_reminder['additional_emails'] ?? ''
)?>">


</div>





<div class="form-group">

<label>Visibility</label>

<div style="margin-top: 10px;">
    <div style="margin-bottom: 8px;">
        <label style="display: inline-block; margin-right: 15px;">
            <input type="radio" name="visibility" value="private"
                <?=(!$edit_reminder || ($edit_reminder['visibility'] ?? 'private') === 'private') ? 'checked' : ''?>>
            Private (only me)
        </label>
    </div>
    <div style="margin-bottom: 8px;">
        <label style="display: inline-block; margin-right: 15px;">
            <input type="radio" name="visibility" value="public"
                <?=($edit_reminder && ($edit_reminder['visibility'] ?? '') === 'public') ? 'checked' : ''?>>
            Public (everyone)
        </label>
    </div>
    <div style="margin-bottom: 8px;">
        <label style="display: inline-block; margin-right: 15px;">
            <input type="radio" name="visibility" value="team"
                <?=($edit_reminder && ($edit_reminder['visibility'] ?? '') === 'team') ? 'checked' : ''?>>
            Team
        </label>
    </div>
    <div style="margin-bottom: 8px;">
        <label style="display: inline-block; margin-right: 15px;">
            <input type="radio" name="visibility" value="user"
                <?=($edit_reminder && ($edit_reminder['visibility'] ?? '') === 'user') ? 'checked' : ''?>>
            Specific Users
        </label>
    </div>
</div>

</div>

<?php
$teams = getUniqueTeams($pdo);
$users = getAllUsers($pdo);
?>

<div class="form-group" id="team-selector" style="display: none;">
    <label>Select Teams</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; border-radius: 4px;">
        <?php foreach($teams as $team): ?>
        <div style="margin-bottom: 8px;">
            <label style="display: block;">
                <input type="checkbox" name="reminder_teams[]" value="<?=htmlspecialchars($team)?>"
                    <?=in_array($team, $edit_reminder_teams) ? 'checked' : ''?>>
                <?=htmlspecialchars($team)?>
            </label>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="form-group" id="user-selector" style="display: none;">
    <label>Select Users</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; border-radius: 4px;">
        <?php foreach($users as $user): ?>
        <div style="margin-bottom: 8px;">
            <label style="display: block;">
                <input type="checkbox" name="reminder_users[]" value="<?=(int)$user['id']?>"
                    <?=in_array($user['id'], $edit_reminder_users) ? 'checked' : ''?>>
                <?=htmlspecialchars($user['first_name'] . ' ' . $user['last_name'] . ' (' . $user['email'] . ')')?>
            </label>
        </div>
        <?php endforeach; ?>
    </div>
</div>




<button type="submit" class="enterprise-btn btn-save">
💾 Save Reminder
</button>


</form>



</section>





<section class="enterprise-card">


<h2 class="enterprise-title">

📝 Sticky Note Editor

</h2>



<input type="hidden"
id="active-note-id">





<textarea

id="sticky-content"

class="form-control"

placeholder="Write note..."></textarea>





<br>

<div style="margin: 15px 0;">
    <label>Visibility</label>
    <div style="margin-top: 10px;">
        <div style="margin-bottom: 8px;">
            <label style="display: inline-block; margin-right: 15px;">
                <input type="radio" name="note_visibility" value="private" class="note-visibility-radio" checked>
                Private (only me)
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label style="display: inline-block; margin-right: 15px;">
                <input type="radio" name="note_visibility" value="public" class="note-visibility-radio">
                Public (everyone)
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label style="display: inline-block; margin-right: 15px;">
                <input type="radio" name="note_visibility" value="team" class="note-visibility-radio">
                Team
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label style="display: inline-block; margin-right: 15px;">
                <input type="radio" name="note_visibility" value="user" class="note-visibility-radio">
                Specific Users
            </label>
        </div>
    </div>
</div>

<div id="note-team-selector" style="display: none; margin-bottom: 15px;">
    <label>Select Teams</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; border-radius: 4px;">
        <?php foreach($teams as $team): ?>
        <div style="margin-bottom: 8px;">
            <label style="display: block;">
                <input type="checkbox" name="note_teams[]" value="<?=htmlspecialchars($team)?>">
                <?=htmlspecialchars($team)?>
            </label>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<div id="note-user-selector" style="display: none; margin-bottom: 15px;">
    <label>Select Users</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px; border-radius: 4px;">
        <?php foreach($users as $user): ?>
        <div style="margin-bottom: 8px;">
            <label style="display: block;">
                <input type="checkbox" name="note_users[]" value="<?=(int)$user['id']?>">
                <?=htmlspecialchars($user['first_name'] . ' ' . $user['last_name'] . ' (' . $user['email'] . ')')?>
            </label>
        </div>
        <?php endforeach; ?>
    </div>
</div>

<br>



<button

class="enterprise-btn btn-save"

onclick="saveNote()">



💾 Save Note


</button>




<button

class="enterprise-btn btn-delete"

onclick="deleteNote()">



🗑 Delete


</button>




</section>




</div>






</main>






</div>

<!-- AUDIT HISTORY MODAL -->
<style>
#auditModal { animation: modalOverlayFadeIn .18s ease-out; }
#auditModal > div { animation: auditModalPopIn .22s cubic-bezier(.16, 1, .3, 1); }
@keyframes modalOverlayFadeIn { from { opacity: 0; } to { opacity: 1; } }
@keyframes auditModalPopIn { from { opacity: 0; transform: translate(-50%, -50%) scale(.96); } to { opacity: 1; transform: translate(-50%, -50%) scale(1); } }
@media (prefers-reduced-motion: reduce) { #auditModal, #auditModal > div { animation: none; } }
</style>
<div id="auditModal" style="display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 9999;">
    <div style="position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); background: var(--bg-content); border-radius: 8px; padding: 30px; max-width: 600px; width: 90%; max-height: 80vh; overflow-y: auto;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px;">
            <h2 id="auditTitle" style="margin: 0;">Audit History</h2>
            <button onclick="closeAuditHistory()" style="background: none; border: none; font-size: 24px; cursor: pointer;">✕</button>
        </div>
        <div id="auditContent" style="max-height: 500px; overflow-y: auto;">
            <!-- Audit entries will be loaded here -->
        </div>
    </div>
</div>

<script>


/*







=========================================
DATE + TIME PICKER FIX

Chrome supports input type=time
Firefox sometimes does not show picker properly.

This creates the final datetime value
correctly.
=========================================
*/


function updateReminderDateTime(){


let date =
document.getElementById(
"reminder_date"
).value;



let time =
document.getElementById(
"reminder_time"
).value;



if(date && time){


document.getElementById(
"full_reminder_date"
).value =
date+" "+time+":00";


}


}



document
.getElementById("reminder_date")
.addEventListener(
"change",
updateReminderDateTime
);



document
.getElementById("reminder_time")
.addEventListener(
"change",
updateReminderDateTime
);









/*
=========================================
LOAD REMINDER EDIT DATE/TIME
=========================================
*/


<?php if($edit_reminder): ?>


let existingDate =
"<?=$edit_reminder['reminder_date']?>";


if(existingDate){


let parts =
existingDate.split(" ");



document.getElementById(
"reminder_date"
).value =
parts[0];



document.getElementById(
"reminder_time"
).value =
parts[1].substring(0,5);



document.getElementById(
"full_reminder_date"
).value =
existingDate;


}


<?php endif; ?>











/*
=========================================
VISIBILITY RADIO BUTTON HANDLERS
=========================================
*/

// Reminder visibility radio buttons
document.querySelectorAll('input[name="visibility"]').forEach(radio => {
    radio.addEventListener('change', function() {
        let isTeam = this.value === 'team';
        let isUser = this.value === 'user';
        document.getElementById('team-selector').style.display = isTeam ? 'block' : 'none';
        document.getElementById('user-selector').style.display = isUser ? 'block' : 'none';
    });
});

// Initialize team/user selector visibility for edit form
if(document.querySelector('input[name="visibility"]:checked')) {
    let selected = document.querySelector('input[name="visibility"]:checked').value;
    document.getElementById('team-selector').style.display = selected === 'team' ? 'block' : 'none';
    document.getElementById('user-selector').style.display = selected === 'user' ? 'block' : 'none';
}

// Sticky note visibility radio buttons
document.querySelectorAll('input.note-visibility-radio').forEach(radio => {
    radio.addEventListener('change', function() {
        let isTeam = this.value === 'team';
        let isUser = this.value === 'user';
        document.getElementById('note-team-selector').style.display = isTeam ? 'block' : 'none';
        document.getElementById('note-user-selector').style.display = isUser ? 'block' : 'none';
    });
});

/*
=========================================
STICKY NOTE SAVE
=========================================
*/


function saveNote(){



let content =
document.getElementById(
"sticky-content"
).value;



let visibility =
document.querySelector('input[name="note_visibility"]:checked').value;



let id =
document.getElementById(
"active-note-id"
).value;





if(content.trim()===""){


alert(
"Please enter note content"
);


return;


}




let data =
new FormData();



data.append(
"action",
"save_note"
);



data.append(
"content",
content
);



data.append(
"visibility",
visibility
);

// Add selected teams
document.querySelectorAll('input[name="note_teams[]"]:checked').forEach(checkbox => {
    data.append("note_teams[]", checkbox.value);
});

// Add selected users
document.querySelectorAll('input[name="note_users[]"]:checked').forEach(checkbox => {
    data.append("note_users[]", checkbox.value);
});

if(id){


data.append(
"note_id",
id
);


}




fetch(
"reminders.php",
{

method:"POST",

body:data

}

)


.then(
response=>response.json()
)


.then(
result=>{


if(result.status==="success"){


location.reload();


}

else{


alert(
result.message
);


}


}

);


}










/*
=========================================
LOAD NOTE INTO EDITOR
=========================================
*/


function editNote(
id,
content,
visibility,
teams,
users
){



document.getElementById(
"active-note-id"
).value=id;



document.getElementById(
"sticky-content"
).value=content;



// Set the radio button value and trigger change
document.querySelector(`input[name="note_visibility"][value="${visibility}"]`).checked = true;
document.querySelector(`input[name="note_visibility"][value="${visibility}"]`).dispatchEvent(new Event('change'));

// Pre-check the team/user boxes this note is already shared with --
// otherwise re-saving with none re-checked silently drops the sharing
// (save_note always deletes and re-inserts from whatever is checked).
teams = teams || [];
users = users || [];

document.querySelectorAll('input[name="note_teams[]"]').forEach(checkbox => {
    checkbox.checked = teams.includes(checkbox.value);
});

document.querySelectorAll('input[name="note_users[]"]').forEach(checkbox => {
    checkbox.checked = users.includes(parseInt(checkbox.value, 10));
});



window.scrollTo({

top:

document.getElementById(
"sticky-content"
).offsetTop-200,

behavior:"smooth"

});


}









/*
=========================================
DELETE NOTE
=========================================
*/


function deleteNote(id){



if(!id){


id=document.getElementById(
"active-note-id"
).value;


}




if(!id){


alert(
"Select a note first"
);


return;


}




if(
!confirm(
"Delete this sticky note?"
)

){

return;


}





let data =
new FormData();



data.append(
"action",
"delete_note"
);



data.append(
"note_id",
id
);




fetch(
"reminders.php",
{

method:"POST",

body:data

}

)


.then(
response=>response.json()
)


.then(
()=>{


location.reload();


}

);


}





/*
=========================================
AUDIT HISTORY MODAL
=========================================
*/

function showAuditHistory(type, id, title) {
    const modal = document.getElementById('auditModal');
    const auditTitle = document.getElementById('auditTitle');
    const auditContent = document.getElementById('auditContent');

    auditTitle.textContent = 'Audit History - ' + title;
    auditContent.innerHTML = '<p>Loading...</p>';

    const formData = new FormData();
    formData.append('action', 'get_audit_history');
    formData.append('type', type);
    formData.append('id', id);

    fetch('reminders.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            auditContent.innerHTML = '<p style="color: red;">Error: ' + data.error + '</p>';
            return;
        }

        if (data.length === 0) {
            auditContent.innerHTML = '<p>No audit history found.</p>';
            modal.style.display = 'block';
            return;
        }

        let html = '<table style="width: 100%; border-collapse: collapse;">';
        html += '<tr style="background: #f5f5f5; border-bottom: 1px solid #ddd;">';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Action</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Performed By</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Date/Time</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Details</th>';
        html += '</tr>';

        data.forEach(entry => {
            const actionDate = new Date(entry.action_date);
            const formattedDate = actionDate.toLocaleDateString();
            const formattedTime = actionDate.toLocaleTimeString();
            const details = entry.details ? entry.details : '-';

            html += '<tr style="border-bottom: 1px solid #eee;">';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.action) + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.user_name) + '</td>';
            html += '<td style="padding: 10px;">' + formattedDate + ' ' + formattedTime + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(details) + '</td>';
            html += '</tr>';
        });

        html += '</table>';
        auditContent.innerHTML = html;
        modal.style.display = 'block';
    })
    .catch(error => {
        auditContent.innerHTML = '<p style="color: red;">Error loading audit history: ' + error + '</p>';
        modal.style.display = 'block';
    });
}

function showAllAuditHistory(type) {
    const modal = document.getElementById('auditModal');
    const auditTitle = document.getElementById('auditTitle');
    const auditContent = document.getElementById('auditContent');

    // Set title based on type
    const titleMap = {
        'reminder': 'Reminders',
        'sticky_note': 'Sticky Notes',
        'communication': 'Communications',
        'mydata': 'My Data'
    };

    auditTitle.textContent = 'Audit History - ' + (titleMap[type] || type);
    auditContent.innerHTML = '<p>Loading...</p>';

    const formData = new FormData();
    formData.append('action', 'get_audit_history');
    formData.append('type', type);
    // Note: no 'id' parameter, so it will return all history for this module type

    fetch('reminders.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.error) {
            auditContent.innerHTML = '<p style="color: red;">Error: ' + data.error + '</p>';
            return;
        }

        if (data.length === 0) {
            auditContent.innerHTML = '<p>No audit history found.</p>';
            modal.style.display = 'block';
            return;
        }

        let html = '<table style="width: 100%; border-collapse: collapse;">';
        html += '<tr style="background: #f5f5f5; border-bottom: 1px solid #ddd;">';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Action</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Performed By</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Date/Time</th>';
        html += '<th style="padding: 10px; text-align: left; font-weight: bold;">Details</th>';
        html += '</tr>';

        data.forEach(entry => {
            const actionDate = new Date(entry.action_date);
            const formattedDate = actionDate.toLocaleDateString();
            const formattedTime = actionDate.toLocaleTimeString();
            const details = entry.details ? entry.details : '-';

            html += '<tr style="border-bottom: 1px solid #eee;">';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.action) + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(entry.user_name) + '</td>';
            html += '<td style="padding: 10px;">' + formattedDate + ' ' + formattedTime + '</td>';
            html += '<td style="padding: 10px;">' + escapeHtml(details) + '</td>';
            html += '</tr>';
        });

        html += '</table>';
        auditContent.innerHTML = html;
        modal.style.display = 'block';
    })
    .catch(error => {
        auditContent.innerHTML = '<p style="color: red;">Error loading audit history: ' + error + '</p>';
        modal.style.display = 'block';
    });
}

function closeAuditHistory() {
    document.getElementById('auditModal').style.display = 'none';
}

// Close modal when clicking outside
document.addEventListener('DOMContentLoaded', function() {
    const modal = document.getElementById('auditModal');
    if (modal) {
        window.addEventListener('click', function(event) {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    }
});

function escapeHtml(unsafe) {
    if (!unsafe) return '';
    return unsafe
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}

</script>




</main>



<?php

include "includes/footer.php";

?>




<script src="assets/js/sidebar.js"></script>
