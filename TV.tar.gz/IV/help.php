<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('help', 'can_view');


$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');

$search = trim($_GET['search'] ?? '');

$params = [];

$sql = "
    SELECT *
    FROM help_articles
    WHERE is_active = 1
";

if ($search != '') {

    $sql .= "
        AND (
            menu_name LIKE :search
            OR title LIKE :search
            OR content LIKE :search
        )
    ";

    $params[':search'] = "%".$search."%";
}

$sql .= "
    ORDER BY menu_name,title
";


$stmt = $pdo->prepare($sql);
$stmt->execute($params);


$help_articles = [];

while($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $menu = $row['menu_name'];

    if(!isset($help_articles[$menu])) {

        $help_articles[$menu] = [];

    }

    $help_articles[$menu][] = $row;

}


$page_title = "Help Center | InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';

?>


<style>

/* HELP CENTER PHASE 2 */

.help-layout {

    display:grid;
    grid-template-columns:260px 1fr;
    gap:25px;

}


.help-menu {

    background:var(--bg-content);
    border-radius:12px;
    border:1px solid var(--border-color);
    padding:20px;
    height:max-content;

}


.help-menu h3 {

    font-size:16px;
    margin-bottom:15px;

}


.help-menu a {

    display:block;
    padding:10px 12px;
    margin-bottom:6px;
    border-radius:8px;
    text-decoration:none;
    color:var(--text-secondary);
    font-size:14px;

}


.help-menu a:hover {

    background:#eff6ff;
    color:#2563eb;

}


[data-theme="dark"] .help-menu a:hover {

    background:rgba(37,99,235,.15);
    color:#93c5fd;

}



.help-content {

    min-width:0;

}


.help-search {

    display:flex;
    gap:12px;
    margin-bottom:25px;

}


.help-search input {

    flex:1;
    padding:12px;
    border-radius:8px;
    border:1px solid #d1d5db;

}


[data-theme="dark"] .help-search input {

    background:var(--input-bg);
    color:var(--text-primary);
    border-color:var(--input-border);

}


.help-search button {

    background:#2563eb;
    color:white;
    border:none;
    padding:0 25px;
    border-radius:8px;
    cursor:pointer;

}


.help-group {

    margin-bottom:30px;

}


.help-item {

    border:1px solid var(--border-color);
    border-radius:10px;
    margin-bottom:12px;
    background:var(--bg-content);

}


.help-title {

    padding:16px;
    cursor:pointer;
    font-weight:600;
    color:var(--text-primary);

}


.help-body {

    display:none;
    padding:0 16px 16px;
    color:var(--text-secondary);
    line-height:1.7;

}


.help-date {

    margin-top:15px;
    font-size:12px;
    color:var(--text-muted);

}



@media(max-width:900px){

.help-layout{

grid-template-columns:1fr;

}

}


</style>


<div class="content">


<div class="dashboard-header">

<div>

<h1>Help Center</h1>

<p><?= htmlspecialchars($appName) ?> Documentation and User Assistance</p>

</div>

</div>


<div class="help-layout">

<!-- LEFT MODULE MENU -->

<div class="help-menu">

<h3>Help Modules</h3>


<?php if(empty($help_articles)): ?>

<p style="color:var(--text-muted);font-size:14px;">
No modules found.
</p>

<?php else: ?>


<?php foreach($help_articles as $menu => $articles): ?>

<a href="#<?= md5($menu) ?>">
    
<?= htmlspecialchars($menu) ?>

</a>

<?php endforeach; ?>


<?php endif; ?>


</div>



<!-- HELP CONTENT -->

<div class="help-content">


<div class="dashboard-panel">


<div class="panel-header">

<h3>Documentation</h3>

</div>



<form method="GET">


<div class="help-search">


<input

type="text"

name="search"

placeholder="Search help articles..."

value="<?= htmlspecialchars($search) ?>"



>


<button type="submit">

Search

</button>


</div>


</form>




<?php if(empty($help_articles)): ?>


<div class="help-item">

<div class="help-body" style="display:block;">

No help articles available.

</div>

</div>



<?php else: ?>



<?php foreach($help_articles as $menu => $articles): ?>


<div class="help-group" id="<?= md5($menu) ?>">



<div class="panel-header">

<h3>

<?= htmlspecialchars($menu) ?>

</h3>

</div>




<?php foreach($articles as $article): ?>



<div class="help-item">



<div class="help-title"

onclick="toggleHelp(this)">


<?= htmlspecialchars($article['title']) ?>


<span style="float:right;color:#2563eb;">

+

</span>


</div>



<div class="help-body">


<p>

<?= nl2br(htmlspecialchars($article['content'])) ?>

</p>



<div class="help-date">


Last Updated:

<?= htmlspecialchars($article['last_updated']) ?>


</div>



<?php if(!empty($article['suggestions'])): ?>


<hr>


<strong>
Suggestions:
</strong>


<p>

<?= nl2br(htmlspecialchars($article['suggestions'])) ?>

</p>


<?php endif; ?>



<?php if(!empty($article['comments'])): ?>


<hr>


<strong>
Comments:
</strong>


<p>

<?= nl2br(htmlspecialchars($article['comments'])) ?>

</p>


<?php endif; ?>



</div>


</div>



<?php endforeach; ?>


</div>



<?php endforeach; ?>


<?php endif; ?>



</div>


</div>

<!-- SUGGESTIONS AND SUPPORT PANEL -->

<div class="dashboard-panel" style="margin-top:25px;">


<div class="panel-header">

<h3>Suggestions & Support</h3>

</div>


<p>

We welcome suggestions to improve the <?= htmlspecialchars($appName) ?> documentation and user experience.

</p>


<ul style="line-height:2;">

<li>Report incorrect or outdated information.</li>

<li>Suggest new Help Center topics.</li>

<li>Request documentation for new features.</li>

<li>Provide usability improvement suggestions.</li>

</ul>



<div class="bd-alert success" style="margin-top:20px;">


<strong>Need Assistance?</strong>


<br><br>


For application issues, access problems, missing data,
or technical questions, please contact the
<strong>LinuxAdmin Team</strong>.


</div>



</div>



</div>

</div>


<script>


function toggleHelp(element)

{


    let body = element.nextElementSibling;


    let icon = element.querySelector("span");



    if(body.style.display === "block")

    {


        body.style.display = "none";

        if(icon)

            icon.innerHTML = "+";


    }

    else

    {


        body.style.display = "block";

        if(icon)

            icon.innerHTML = "−";


    }


}



</script>



<?php include 'includes/footer.php'; ?>

