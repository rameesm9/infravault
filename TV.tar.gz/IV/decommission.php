<?php
// decommission.php
session_start();
require 'config/db.php';
require_once 'includes/pagination-helpers.php';
require_once 'includes/decommission-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
|
| Permissions table:
|
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
| This page's key is 'decommission' (registered in permission.php as
| "Asset Decommission").
|
*/

function decommissionHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'decommission', $permission);
}


$canView   = decommissionHasPermission($pdo, $role, 'can_view');
$canEdit   = decommissionHasPermission($pdo, $role, 'can_edit');
$canDelete = decommissionHasPermission($pdo, $role, 'can_delete');
$canExport = decommissionHasPermission($pdo, $role, 'can_export');
$canImport = decommissionHasPermission($pdo, $role, 'can_import');
$canAudit  = decommissionHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
|
| Must happen before any header/sidebar output or AJAX handler below.
| Previously this page had NO view check at all -- any logged-in user
| could load it regardless of their role's can_view setting.
|
*/

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}


$msg = "";
$error = "";

$upload_dir = __DIR__ . '/uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Export CSV
if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export decommission records.');
    }

    // Build WHERE clause with same filters as main page
    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_unique_id = trim($_GET['s_unique_id'] ?? '');
    $s_hostname = trim($_GET['s_hostname'] ?? '');
    $s_project = trim($_GET['s_project'] ?? '');
    $s_support = trim($_GET['s_support'] ?? '');
    $s_application = trim($_GET['s_application'] ?? '');
    $s_reqno = trim($_GET['s_reqno'] ?? '');
    $s_assignee = trim($_GET['s_assignee'] ?? '');
    $s_tag = trim($_GET['s_tag'] ?? '');

    if (!empty($keyword)) {
        $export_where_clauses[] = "(d.unique_id LIKE ? OR d.req_no LIKE ? OR EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.hostname LIKE ?))";
        array_push($export_params, "%$keyword%", "%$keyword%", "%$keyword%");
    }
    if (!empty($s_unique_id)) {
        $export_where_clauses[] = "d.unique_id LIKE ?";
        $export_params[] = "%$s_unique_id%";
    }
    if (!empty($s_hostname)) {
        $export_where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.hostname LIKE ?)";
        $export_params[] = "%$s_hostname%";
    }
    if (!empty($s_project)) {
        $export_where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.project LIKE ?)";
        $export_params[] = "%$s_project%";
    }
    if (!empty($s_support)) {
        $export_where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.support_level = ?)";
        $export_params[] = "$s_support";
    }
    if (!empty($s_application)) {
        $export_where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.application_name LIKE ?)";
        $export_params[] = "%$s_application%";
    }
    if (!empty($s_reqno)) {
        $export_where_clauses[] = "d.req_no LIKE ?";
        $export_params[] = "%$s_reqno%";
    }
    if (!empty($s_assignee)) {
        $export_where_clauses[] = "d.assignee_id = ?";
        $export_params[] = (int) $s_assignee;
    }
    if (!empty($s_tag)) {
        $export_where_clauses[] = "d.server_state LIKE ?";
        $export_params[] = "%$s_tag%";
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=decommission_export_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Unique ID', 'REQ Number', 'Assignee', 'Server State', 'Start Date', 'End Date', 'Hosts', 'Attachment', 'Created By', 'Created At']);

    $stmt = $pdo->prepare("
        SELECT d.*,
               u.first_name AS assignee_first_name, u.last_name AS assignee_last_name, u.ncgr_id AS assignee_ncgr_id,
               (SELECT GROUP_CONCAT(dh.hostname, '; ') FROM decommission_hosts dh WHERE dh.decommission_id = d.id) AS hosts_list
        FROM decommission d
        LEFT JOIN users u ON u.id = d.assignee_id
        WHERE $export_where_sql
        ORDER BY d.unique_id ASC
    ");
    $stmt->execute($export_params);

    while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
        fputcsv($output, [
            $row['unique_id'], $row['req_no'], decomAssigneeLabel($row['assignee_name']),
            $row['server_state'], $row['decommission_start_date'], $row['decommission_end_date'],
            $row['hosts_list'] ?? '', $row['attachment'] ?? '',
            $row['created_by'], $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

// AJAX: single-hostname inventory snapshot, used to populate the live
// preview panel in the Add Record modal as hosts are ticked.
if (isset($_GET['action']) && $_GET['action'] === 'get_inventory_details') {

    if (!$canEdit) {
        http_response_code(403);
        echo json_encode(['success' => false]);
        exit;
    }

    $hname = trim($_GET['hostname'] ?? '');
    $snap = $hname !== '' ? decomInventorySnapshot($pdo, $hname) : null;

    if ($snap) {
        echo json_encode(['success' => true] + $snap);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// AJAX: "View Hosts" -- every host attached to one decommission entry.
if (isset($_GET['action']) && $_GET['action'] === 'get_hosts') {

    $decommission_id = isset($_GET['decommission_id']) ? (int) $_GET['decommission_id'] : 0;

    $stmt = $pdo->prepare("SELECT * FROM decommission_hosts WHERE decommission_id = ? ORDER BY hostname ASC");
    $stmt->execute([$decommission_id]);
    $hosts = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($hosts) > 0) {
        echo '<div class="table-wrap"><table class="data-table">';
        echo '<thead><tr><th>Hostname</th><th>Project Name</th><th>Support Level</th><th>IP Address</th><th>Additional IPs</th><th>Technical Owner</th><th>Application</th></tr></thead><tbody>';
        foreach ($hosts as $h) {
            echo '<tr>';
            echo '<td class="cell-primary">' . htmlspecialchars($h['hostname']) . '</td>';
            echo '<td>' . htmlspecialchars($h['project'] ?: '—') . '</td>';
            echo '<td><span class="badge-support ' . decom_support_class($h['support_level']) . '">' . htmlspecialchars($h['support_level'] ?: 'N/A') . '</span></td>';
            echo '<td>' . htmlspecialchars($h['ip_address'] ?: '—') . '</td>';
            echo '<td>' . htmlspecialchars($h['additional_ips'] ?: '—') . '</td>';
            echo '<td>' . htmlspecialchars($h['technical_owner'] ?: '—') . '</td>';
            echo '<td>' . htmlspecialchars($h['application_name'] ?: '—') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    } else {
        echo '<p class="empty-state">No hosts are attached to this decommission entry.</p>';
    }
    exit;
}

// Global History AJAX
if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
        exit;
    }

    $record_id = isset($_GET['record_id']) ? (int)$_GET['record_id'] : null;

    if ($record_id) {
        $stmt = $pdo->prepare("SELECT * FROM decommission_history WHERE decommission_id = ? ORDER BY timestamp DESC");
        $stmt->execute([$record_id]);
    } else {
        $stmt = $pdo->query("SELECT * FROM decommission_history ORDER BY timestamp DESC");
    }

    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<div class="table-wrap"><table class="data-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $action_class = 'action-updated';
            if ($log['action_type'] === 'CREATED') $action_class = 'action-created';
            if ($log['action_type'] === 'DELETED') $action_class = 'action-deleted';

            echo '<tr>';
            echo '<td><span class="action-badge ' . $action_class . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td>' . htmlspecialchars($log['details']) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    } else {
        echo '<p class="empty-state">No audit history records found.</p>';
    }
    exit;
}

// Handle Form Submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    if ($action_type === 'save') {

        if (!$canEdit) {
            http_response_code(403);
            $error = "You do not have permission to create or edit decommission records.";
        } else {

            $id = trim($_POST['id'] ?? '');
            $unique_id = trim($_POST['unique_id'] ?? '');
            $req_no = trim($_POST['req_no'] ?? '');
            $assignee_id = !empty($_POST['assignee_id']) ? (int) $_POST['assignee_id'] : null;
            $assignee_name = decomResolveAssigneeName($pdo, $assignee_id);
            $server_state = trim($_POST['server_state'] ?? '');
            $decommission_start_date = $_POST['decommission_start_date'] ?? '';
            $decommission_end_date = !empty($_POST['decommission_end_date']) ? $_POST['decommission_end_date'] : null;
            $hostnames = array_values(array_unique(array_filter(array_map('trim', $_POST['hostnames'] ?? []))));

            // Handle existing attachments list if editing
            $existing_attachments = [];
            if (!empty($_POST['existing_attachment'])) {
                $existing_attachments = array_filter(explode(',', $_POST['existing_attachment']));
            }

            // Handle multiple file uploads
            $uploaded_files = $existing_attachments;
            if (isset($_FILES['attachment_files']) && !empty($_FILES['attachment_files']['name'][0])) {
                $file_count = count($_FILES['attachment_files']['name']);

                // Comprehensive Office formats + CSV, PDFs, Archives, and standard documents
                $allowed_exts = [
                    'pdf', 'doc', 'docx', 'dot', 'dotx', 'docm', 'dotm',
                    'xls', 'xlsx', 'xlt', 'xltx', 'xlsm', 'xltm', 'xlsb', 'xla', 'xlam',
                    'ppt', 'pptx', 'pot', 'potx', 'pptm', 'potm', 'pps', 'ppsx', 'ppsm',
                    'msg', 'eml', 'pst', 'ost',
                    'vsd', 'vsdx', 'vss', 'vst', 'vstm', 'vstx',
                    'accdb', 'mdb', 'csv',
                    'png', 'jpg', 'jpeg', 'gif', 'txt', 'zip', 'rar', '7z', 'tar', 'gz'
                ];

                for ($i = 0; $i < $file_count; $i++) {
                    if ($_FILES['attachment_files']['error'][$i] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['attachment_files']['tmp_name'][$i];
                        $file_orig = basename($_FILES['attachment_files']['name'][$i]);
                        $file_ext = strtolower(pathinfo($file_orig, PATHINFO_EXTENSION));

                        if (in_array($file_ext, $allowed_exts)) {
                            $new_filename = time() . '_' . $i . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $file_orig);
                            if (move_uploaded_file($file_tmp, $upload_dir . $new_filename)) {
                                $uploaded_files[] = $new_filename;
                            }
                        } else {
                            $error = "One or more files have an unsupported extension.";
                        }
                    }
                }
            }

            $attachment_name_string = !empty($uploaded_files) ? implode(',', array_unique($uploaded_files)) : '';

            if (empty($error)) {
                if (empty($unique_id)) {
                    $error = "Unique ID is a required field.";
                } elseif (empty($id) && empty($hostnames)) {
                    $error = "Select at least one hostname from Inventory.";
                } else {
                    $dup_stmt = $pdo->prepare("SELECT COUNT(*) FROM decommission WHERE unique_id = ? AND id != ?");
                    $dup_stmt->execute([$unique_id, $id !== '' ? $id : 0]);
                    if ($dup_stmt->fetchColumn() > 0) {
                        $error = "Unique ID \"$unique_id\" is already used by another decommission entry.";
                    }
                }
            }

            if (empty($error)) {

                if (empty($id)) {
                    // CREATE
                    $stmt = $pdo->prepare("
                        INSERT INTO decommission
                        (hostname, unique_id, req_no, assignee_id, assignee_name, server_state, decommission_start_date, decommission_end_date, attachment, created_by)
                        VALUES ('', ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    $stmt->execute([$unique_id, $req_no, $assignee_id, $assignee_name, $server_state, $decommission_start_date ?: null, $decommission_end_date, $attachment_name_string, $username]);
                    $new_id = (int) $pdo->lastInsertId();

                    foreach ($hostnames as $hn) {
                        decomAttachHost($pdo, $new_id, $hn);

                        if ($server_state !== '') {
                            $pdo->prepare("UPDATE inventory SET server_state = ? WHERE hostname = ?")->execute([$server_state, $hn]);
                        }
                    }

                    decomCreateDefaultTasks($pdo, $new_id);

                    $create_details = "Created decommission entry $unique_id covering " . count($hostnames) . " host(s): " . implode(', ', $hostnames);
                    if ($assignee_name) {
                        $create_details .= ". Assignee: $assignee_name";
                    }
                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                    $h_stmt->execute([$new_id, $username, $create_details]);
                    $msg = "Decommission entry created successfully.";
                } else {
                    // UPDATE -- hostnames are fixed once an entry is created;
                    // only entry-level fields can change here.
                    $prev_stmt = $pdo->prepare("SELECT assignee_name FROM decommission WHERE id = ?");
                    $prev_stmt->execute([$id]);
                    $prev_assignee_name = $prev_stmt->fetchColumn();

                    $stmt = $pdo->prepare("
                        UPDATE decommission
                        SET unique_id=?, req_no=?, assignee_id=?, assignee_name=?, server_state=?, decommission_start_date=?, decommission_end_date=?, attachment=?, updated_by=?, updated_at=CURRENT_TIMESTAMP
                        WHERE id=?
                    ");
                    $stmt->execute([$unique_id, $req_no, $assignee_id, $assignee_name, $server_state, $decommission_start_date ?: null, $decommission_end_date, $attachment_name_string, $username, $id]);

                    // Server State on the entry always reflects onto every
                    // host it covers, so Inventory can't drift from what
                    // this decommission entry says the servers' state is.
                    if ($server_state !== '') {
                        $hosts_stmt = $pdo->prepare("SELECT hostname FROM decommission_hosts WHERE decommission_id = ?");
                        $hosts_stmt->execute([$id]);
                        $inv_up = $pdo->prepare("UPDATE inventory SET server_state = ? WHERE hostname = ?");
                        foreach ($hosts_stmt->fetchAll(PDO::FETCH_COLUMN) as $hn) {
                            $inv_up->execute([$server_state, $hn]);
                        }
                    }

                    $update_details = "Updated decommission entry: $unique_id";
                    if (trim((string) $prev_assignee_name) !== trim((string) $assignee_name)) {
                        $from_label = decomAssigneeLabel($prev_assignee_name);
                        $to_label = decomAssigneeLabel($assignee_name);
                        $update_details .= ". Assignee changed from \"$from_label\" to \"$to_label\"";
                    }
                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                    $h_stmt->execute([$id, $username, $update_details]);
                    $msg = "Decommission entry updated successfully.";
                }
            }
        }
    }

    if ($action_type === 'delete') {

        if (!$canDelete) {
            http_response_code(403);
            $error = "You do not have permission to delete decommission records.";
        } else {
            $id = $_POST['id'];
            $p_stmt = $pdo->prepare("SELECT unique_id FROM decommission WHERE id = ?");
            $p_stmt->execute([$id]);
            $row = $p_stmt->fetch(PDO::FETCH_ASSOC);
            $uid_label = $row ? $row['unique_id'] : 'Unknown';

            $stmt = $pdo->prepare("DELETE FROM decommission WHERE id = ?");
            $stmt->execute([$id]);

            $t_stmt = $pdo->prepare("DELETE FROM decommission_tasks WHERE decommission_id = ?");
            $t_stmt->execute([$id]);

            $dh_stmt = $pdo->prepare("DELETE FROM decommission_hosts WHERE decommission_id = ?");
            $dh_stmt->execute([$id]);

            $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
            $h_stmt->execute([$id, $username, "Deleted decommission entry: $uid_label"]);
            $msg = "Decommission entry deleted successfully.";
        }
    }
}

// Pagination & Search
$limit = resolveUserPageSize($pdo, (int) $_SESSION['user_id']);

$page = isset($_GET['page'])
    ? max(1, (int)$_GET['page'])
    : 1;

$start = ($page - 1) * $limit;

$keyword = trim($_GET['keyword'] ?? '');
$s_unique_id = trim($_GET['s_unique_id'] ?? '');
$s_hostname = trim($_GET['s_hostname'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_support = trim($_GET['s_support'] ?? '');
$s_application = trim($_GET['s_application'] ?? '');
$s_reqno = trim($_GET['s_reqno'] ?? '');
$s_assignee = trim($_GET['s_assignee'] ?? '');
$s_tag = trim($_GET['s_tag'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(d.unique_id LIKE ? OR d.req_no LIKE ? OR EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.hostname LIKE ?))";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_unique_id)) {
    $where_clauses[] = "d.unique_id LIKE ?";
    $params[] = "%$s_unique_id%";
}
if (!empty($s_hostname)) {
    $where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.hostname LIKE ?)";
    $params[] = "%$s_hostname%";
}
if (!empty($s_project)) {
    $where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.project LIKE ?)";
    $params[] = "%$s_project%";
}
if (!empty($s_support)) {
    $where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.support_level = ?)";
    $params[] = "$s_support";
}
if (!empty($s_application)) {
    $where_clauses[] = "EXISTS (SELECT 1 FROM decommission_hosts dh WHERE dh.decommission_id = d.id AND dh.application_name LIKE ?)";
    $params[] = "%$s_application%";
}
if (!empty($s_reqno)) {
    $where_clauses[] = "d.req_no LIKE ?";
    $params[] = "%$s_reqno%";
}
if (!empty($s_assignee)) {
    $where_clauses[] = "d.assignee_id = ?";
    $params[] = (int) $s_assignee;
}
if (!empty($s_tag)) {
    $where_clauses[] = "d.server_state LIKE ?";
    $params[] = "%$s_tag%";
}

$where_sql = implode(" AND ", $where_clauses);

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM decommission d WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_records / $limit));

// Correct page if out of range
if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

// Sorting - validate and apply. Assignee/Hosts aren't plain columns on
// `decommission`, so they need their own SQL expression rather than a
// bare column name.
$sort_column_map = [
    'id'                       => 'd.id',
    'unique_id'                => 'd.unique_id',
    'req_no'                   => 'd.req_no',
    'assignee'                 => 'd.assignee_name',
    'server_state'             => 'd.server_state',
    'host_count'               => 'host_count',
    'decommission_start_date'  => 'd.decommission_start_date',
    'decommission_end_date'    => 'd.decommission_end_date',
    'created_at'               => 'd.created_at',
];

$sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

if (!array_key_exists($sort_by, $sort_column_map)) {
    $sort_by = 'id';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'DESC';
}
$order_expr = $sort_column_map[$sort_by];

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

$data_stmt = $pdo->prepare("
    SELECT d.*,
           u.first_name AS assignee_first_name, u.last_name AS assignee_last_name, u.ncgr_id AS assignee_ncgr_id,
           (SELECT COUNT(*) FROM decommission_hosts dh WHERE dh.decommission_id = d.id) AS host_count
    FROM decommission d
    LEFT JOIN users u ON u.id = d.assignee_id
    WHERE $where_sql
    ORDER BY $order_expr $sort_dir
    LIMIT $limit OFFSET $start
");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hidden fields so the page-size selector preserves the current
// search/filter/sort state instead of resetting it.
$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_unique_id' => $s_unique_id,
    's_hostname' => $s_hostname,
    's_project' => $s_project,
    's_support' => $s_support,
    's_application' => $s_application,
    's_reqno' => $s_reqno,
    's_assignee' => $s_assignee,
    's_tag' => $s_tag,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
] as $fk => $fv) {
    if ($fv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
    }
}

$inventory_list = [];
try {
    $inv_stmt = $pdo->query("SELECT DISTINCT hostname FROM inventory ORDER BY hostname ASC");
    $inventory_list = $inv_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {}

$support_levels = ['Production', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox', 'DR', 'POC'];

$assignee_options = [];
try {
    $assignee_options = $pdo->query("SELECT id, first_name, last_name, ncgr_id FROM users WHERE is_approved = 1 ORDER BY first_name ASC, last_name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {}

// Used by includes/header.php for the <title> tag
$page_title = "Decommission Registry | InfraVault";

require 'includes/header.php';
?>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/decommission.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Server Decommission Management</h1>
            <p>Track servers going through the decommission process, from CR approval to final cleanup.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="btn btn-success" onclick="openCreateModal()">+ Add Record</button>
            <?php endif; ?>
            <?php if ($canImport): ?>
                <button type="button" class="btn btn-info" onclick="openImportModal()">Import CSV</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_unique_id !== '') $export_params['s_unique_id'] = $s_unique_id;
                if ($s_hostname !== '') $export_params['s_hostname'] = $s_hostname;
                if ($s_project !== '') $export_params['s_project'] = $s_project;
                if ($s_support !== '') $export_params['s_support'] = $s_support;
                if ($s_application !== '') $export_params['s_application'] = $s_application;
                if ($s_reqno !== '') $export_params['s_reqno'] = $s_reqno;
                if ($s_assignee !== '') $export_params['s_assignee'] = $s_assignee;
                if ($s_tag !== '') $export_params['s_tag'] = $s_tag;
                $export_url = 'decommission.php?' . http_build_query($export_params);
                ?>
                <a href="<?= htmlspecialchars($export_url) ?>" class="btn btn-info">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="btn btn-warning" onclick="openGlobalHistoryModal()">⏱ History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="alert alert-warning mb-4">
        <strong>🔔 Important:</strong> Server decommissioning must always be performed through an approved Change Request (CR). Make sure all stakeholders are approved and alert removed.
    </div>

    <!-- Search Panel -->
    <div class="panel">
        <div
            class="panel-header"
            style="margin-bottom:14px;"
        >
            <h3
                class="panel-title"
                style="margin:0;"
            >
                Search &amp; Filters
            </h3>
            <span
                style="
                    cursor:pointer;
                    color:#2563EB;
                    font-size:13px;
                    font-weight:600;
                "
                onclick="toggleAdvancedSearch()"
            >
                Search Multiple Values &#9662;
            </span>
        </div>

        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">
        <form
            method="GET"
            action="decommission.php"
            style="
                display:flex;
                gap:10px;
                flex-wrap:wrap;
            "
        >
            <input
                type="text"
                name="keyword"
                class="form-control"
                style="max-width:320px;"
                placeholder="Search unique ID, REQ number, hostname..."
                data-live-search="500"
                value="<?php
                echo htmlspecialchars(
                    $keyword,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>"
            >
            <button
                type="submit"
                class="btn btn-primary"
            >
                Search
            </button>
            <button
                type="button"
                class="btn"
                data-live-search-toggle
                onclick="toggleLiveSearch()"
                title="Toggle searching automatically as you type"
            ></button>
            <?php if (
                $keyword !== '' ||
                $s_unique_id !== '' ||
                $s_hostname !== '' ||
                $s_project !== '' ||
                $s_support !== '' ||
                $s_application !== '' ||
                $s_reqno !== '' ||
                $s_assignee !== '' ||
                $s_tag !== ''
            ): ?>
                <a
                    href="decommission.php"
                    class="btn"
                >
                    Clear
                </a>
            <?php endif; ?>
        </form>

        <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
        </div>

        <div
            id="advancedSearchPanel"
            style="
                display:<?php
                echo (
                    $s_unique_id !== '' ||
                    $s_hostname !== '' ||
                    $s_project !== '' ||
                    $s_support !== '' ||
                    $s_application !== '' ||
                    $s_reqno !== '' ||
                    $s_assignee !== '' ||
                    $s_tag !== ''
                )
                    ? 'block'
                    : 'none';
                ?>;
                margin-top:18px;
                padding:20px;
                background:var(--hover-bg);
                border-radius:10px;
                border:1px solid #E5E7EB;
            "
        >
            <form
                method="GET"
                action="decommission.php"
                style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;"
            >
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Unique ID</label>
                    <input type="text" name="s_unique_id" class="form-control" placeholder="Unique ID..." value="<?= htmlspecialchars($s_unique_id, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Hostname</label>
                    <input type="text" name="s_hostname" class="form-control" placeholder="Hostname..." value="<?= htmlspecialchars($s_hostname, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Project</label>
                    <input type="text" name="s_project" class="form-control" placeholder="Project..." value="<?= htmlspecialchars($s_project, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Support Level</label>
                    <select name="s_support" class="form-control">
                        <option value="">All Levels</option>
                        <?php foreach ($support_levels as $level): ?>
                            <option value="<?= htmlspecialchars($level, ENT_QUOTES, 'UTF-8') ?>" <?= $s_support === $level ? 'selected' : '' ?>><?= htmlspecialchars($level, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Application</label>
                    <input type="text" name="s_application" class="form-control" placeholder="Application..." value="<?= htmlspecialchars($s_application, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">REQ Number</label>
                    <input type="text" name="s_reqno" class="form-control" placeholder="REQ number..." value="<?= htmlspecialchars($s_reqno, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Assignee</label>
                    <select name="s_assignee" class="form-control">
                        <option value="">All Assignees</option>
                        <?php foreach ($assignee_options as $opt): ?>
                            <option value="<?= (int) $opt['id'] ?>" <?= ((string) $s_assignee === (string) $opt['id']) ? 'selected' : '' ?>><?= htmlspecialchars(trim($opt['first_name'] . ' ' . $opt['last_name'])) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Server State</label>
                    <input type="text" name="s_tag" class="form-control" placeholder="State..." value="<?= htmlspecialchars($s_tag, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- BUTTONS -->
                <div style="grid-column: 1/-1; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; min-width: 120px;">
                        🔍 Apply Filters
                    </button>
                    <a href="decommission.php" class="btn" style="flex: 1; min-width: 120px; text-align: center;">
                        ↺ Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <span class="panel-title" style="margin-bottom:0;">Decommission Records</span>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <?php
                        $decom_sort_headers = [
                            'unique_id' => 'Unique ID',
                            'req_no' => 'REQ Number',
                            'assignee' => 'Assignee',
                            'server_state' => 'Server State',
                            'decommission_start_date' => 'Start Date',
                            'decommission_end_date' => 'End Date',
                            'host_count' => 'Hosts',
                        ];
                        foreach ($decom_sort_headers as $col_key => $col_label): ?>
                        <th>
                            <a href="decommission.php?sort_by=<?php echo $col_key; ?>&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                <?php echo $col_label; ?>
                                <?php if ($sort_by === $col_key): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <?php endforeach; ?>
                        <th>Attachments</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                        <tr>
                            <td class="cell-primary"><?php echo htmlspecialchars($r['unique_id']); ?></td>
                            <td><?php echo htmlspecialchars($r['req_no'] !== '' && $r['req_no'] !== null ? $r['req_no'] : '—'); ?></td>
                            <td><?php echo htmlspecialchars(decomAssigneeLabel($r['assignee_name'])); ?></td>
                            <td><span class="badge-state <?php echo decom_state_class($r['server_state']); ?>"><?php echo htmlspecialchars($r['server_state'] ?: 'N/A'); ?></span></td>
                            <td><?php echo htmlspecialchars($r['decommission_start_date'] ?: '—'); ?></td>
                            <td><?php echo htmlspecialchars($r['decommission_end_date'] ?: '—'); ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-outline-info" onclick="openHostsModal(<?php echo (int) $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['unique_id'])); ?>')">
                                    👥 <?php echo (int) $r['host_count']; ?> host<?php echo ((int) $r['host_count'] === 1) ? '' : 's'; ?>
                                </button>
                            </td>
                            <td>
                                <?php if (!empty($r['attachment'])): ?>
                                    <?php
                                        $files = explode(',', $r['attachment']);
                                        foreach ($files as $idx => $file):
                                            $file = trim($file);
                                            if(empty($file)) continue;
                                    ?>
                                        <a href="uploads/<?php echo htmlspecialchars($file); ?>" target="_blank" class="btn btn-sm btn-outline-info mb-1">📎 File <?php echo ($idx + 1); ?></a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <span class="text-muted small">None</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; white-space: nowrap;">
                                <div class="row-actions">
                                    <button type="button" class="btn btn-sm btn-secondary btn-icon" title="View Tasks" aria-label="View Tasks" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['unique_id'])); ?>', false)">👁</button>
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="btn btn-sm btn-info btn-icon" title="Edit Tasks" aria-label="Edit Tasks" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['unique_id'])); ?>', true)">✏️</button>
                                        <button type="button" class="btn btn-sm btn-primary btn-icon" title="Edit" aria-label="Edit" onclick='openEditModal(<?php echo json_encode($r); ?>)'>✎</button>
                                    <?php endif; ?>
                                    <?php if ($canDelete): ?>
                                        <button type="button" class="btn btn-sm btn-danger btn-icon" title="Delete" aria-label="Delete" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['unique_id'])); ?>')">🗑</button>
                                    <?php endif; ?>
                                    <?php if ($canAudit): ?>
                                        <button type="button" class="btn btn-sm btn-warning btn-icon" title="Audit History" aria-label="Audit History" onclick="openRowHistoryModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['unique_id'])); ?>')">⏱</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9"><p class="empty-state">No decommission records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= ivPager($page, $total_pages, [
            'keyword'       => $keyword,
            's_unique_id'   => $s_unique_id,
            's_hostname'    => $s_hostname,
            's_project'     => $s_project,
            's_support'     => $s_support,
            's_application' => $s_application,
            's_reqno'       => $s_reqno,
            's_assignee'    => $s_assignee,
            's_tag'         => $s_tag,
            'sort_by'       => $sort_by,
            'sort_dir'      => $sort_dir,
        ], ['base' => 'decommission.php', 'total_records' => $total_records ?? null, 'per_page' => $limit ?? null]) ?>
    </div>

</div>

<!-- Modals -->
<div class="modal fade" id="recordModal" tabindex="-1" aria-hidden="true" data-bs-backdrop="static" data-bs-keyboard="false">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Decommission Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="decommission.php" enctype="multipart/form-data" id="recordForm">
                <div class="modal-body">
                    <input type="hidden" name="form_action" value="save">
                    <input type="hidden" name="id" id="rec_id">
                    <input type="hidden" name="existing_attachment" id="rec_existing_attachment">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Unique ID *</label>
                            <input type="text" name="unique_id" id="rec_unique_id" class="form-control" placeholder="e.g. DECOM-2026-014" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">REQ Number</label>
                            <input type="text" name="req_no" id="rec_req_no" class="form-control" placeholder="e.g. REQ0012345">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Assignee</label>
                            <select name="assignee_id" id="rec_assignee_id" class="form-select">
                                <option value="">-- Unassigned --</option>
                                <?php foreach ($assignee_options as $opt): ?>
                                    <option value="<?= (int) $opt['id'] ?>"><?= htmlspecialchars(trim($opt['first_name'] . ' ' . $opt['last_name']) . ' (' . $opt['ncgr_id'] . ')') ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Server State</label>
                            <select class="form-select" name="server_state" id="server_state" required>
                                <option value="">Select Server State...</option>
                                <option value="powered on">Powered On / Active</option>
                                <option value="powered off">Powered Off</option>
                                <option value="to be decomm">To Be Decommissioned</option>
                                <option value="decommissioned">Decommissioned</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Decommission Start Date *</label>
                            <input type="date" name="decommission_start_date" id="rec_start_date" class="form-control" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Decommission End Date</label>
                            <input type="date" name="decommission_end_date" id="rec_end_date" class="form-control">
                        </div>

                        <div class="col-md-12" id="hostPickerContainer">
                            <label class="form-label">Search &amp; Select Hostname(s) from Inventory *</label>
                            <div class="decom-host-picker">
                                <div class="decom-host-picker-toolbar">
                                    <input type="text" id="hostPickerSearch" class="form-control" placeholder="Search hostnames..." oninput="filterHostPicker()">
                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="hostPickerSelectAllFiltered()">Select filtered</button>
                                    <button type="button" class="btn btn-sm btn-outline-secondary" onclick="hostPickerClearAll()">Clear</button>
                                    <span class="decom-host-picker-count" id="hostPickerCount">0 selected</span>
                                </div>
                                <div class="decom-host-picker-list" id="hostPickerList">
                                    <?php foreach ($inventory_list as $inv_host): ?>
                                        <label class="decom-host-picker-item" data-host="<?php echo htmlspecialchars(strtolower($inv_host)); ?>">
                                            <input type="checkbox" name="hostnames[]" value="<?php echo htmlspecialchars($inv_host); ?>" onchange="hostPickerToggle(this)">
                                            <span><?php echo htmlspecialchars($inv_host); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="form-text">Tick every host this decommission entry covers. Project, support level, IPs, technical owner and application are captured automatically from Inventory.</div>

                            <div class="decom-host-preview" id="hostPreviewWrap" hidden>
                                <div class="table-wrap">
                                    <table class="data-table" id="hostPreviewTable">
                                        <thead><tr><th>Hostname</th><th>Project</th><th>Support Level</th><th>IP Address</th></tr></thead>
                                        <tbody></tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <div class="col-md-12" id="hostSummaryContainer" style="display:none;">
                            <label class="form-label">Hosts on this entry</label>
                            <div class="alert alert-info" style="margin:0;">
                                <span id="hostSummaryText">This entry covers 0 host(s).</span>
                                <button type="button" class="btn btn-sm btn-outline-info" onclick="openHostsModalFromEdit()">View Hosts</button>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <label class="form-label">Attachment Documents (Microsoft Office files, CSV, PDFs, Images, Archives allowed)</label>
                            <input type="file" name="attachment_files[]" class="form-control" multiple>
                            <div id="fileHelpBlock" class="form-text"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- View Hosts Modal -->
<div class="modal fade" id="hostsModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Hosts on <span id="hostsModalUniqueId" class="text-primary"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="hostsModalBody" style="max-height: 65vh; overflow-y: auto;">
                <p class="task-loading">Loading hosts...</p>
            </div>
        </div>
    </div>
</div>

<!-- Task Modal Container -->
<div class="modal fade" id="taskModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title"><span id="taskModalTitleMode">Checklist Tasks</span>: <span id="taskModalHostname" class="text-warning"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="taskModalBody">
                <p class="task-loading">Loading checklist tasks...</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content text-center">
            <div class="modal-header"><h5 class="modal-title">Confirm Deletion</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"><p>Are you sure you want to delete decommission entry: <strong id="del_hostname"></strong>? This also removes its attached hosts and checklist.</p></div>
            <div class="modal-footer justify-content-center">
                <form method="POST" action="decommission.php">
                    <input type="hidden" name="form_action" value="delete">
                    <input type="hidden" name="id" id="del_id">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="globalHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Module Audit History</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body" id="globalHistoryContent" style="max-height: 60vh; overflow-y: auto;"><p class="task-loading">Loading audit trails...</p></div>
        </div>
    </div>
</div>

<!-- Import CSV Modal -->
<div class="modal fade" id="importModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Import Decommission CSV</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="decommission-import.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="csv_file" class="form-label">CSV File</label>
                        <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv" required>
                    </div>
                    <div class="mb-3">
                        <p><strong>CSV Format</strong> (one row per host; rows sharing the same Unique ID become one entry):</p>
                        <code style="display: block; background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto;">
unique_id,req_no,assignee,server_state,hostname,decommission_start_date,decommission_end_date
                        </code>
                        <p class="form-text">Assignee is matched by NCGR ID or email. Entry-level values (REQ number, assignee, server state, dates) only need to be filled on one row per Unique ID.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
<script>
    let currentEditDecommissionId = null;
    let hostPreviewCache = {};

    function cssEscapeHost(s) { return s.replace(/[^a-zA-Z0-9_-]/g, '_'); }
    function escapeHtml(s) {
        const div = document.createElement('div');
        div.innerText = s == null ? '' : s;
        return div.innerHTML;
    }

    function updateHostPickerCount() {
        const checked = document.querySelectorAll('#hostPickerList input[type=checkbox]:checked');
        document.getElementById('hostPickerCount').innerText = checked.length + ' selected';
    }

    function filterHostPicker() {
        const q = document.getElementById('hostPickerSearch').value.trim().toLowerCase();
        document.querySelectorAll('#hostPickerList .decom-host-picker-item').forEach(item => {
            item.style.display = item.dataset.host.indexOf(q) !== -1 ? '' : 'none';
        });
    }

    function hostPickerSelectAllFiltered() {
        document.querySelectorAll('#hostPickerList .decom-host-picker-item').forEach(item => {
            if (item.style.display !== 'none') {
                const cb = item.querySelector('input[type=checkbox]');
                if (!cb.checked) {
                    cb.checked = true;
                    hostPickerToggle(cb);
                }
            }
        });
    }

    function hostPickerClearAll() {
        document.querySelectorAll('#hostPickerList input[type=checkbox]:checked').forEach(cb => {
            cb.checked = false;
            hostPickerToggle(cb);
        });
    }

    function hostPickerToggle(checkbox) {
        updateHostPickerCount();
        if (checkbox.checked) {
            loadHostPreview(checkbox.value);
        } else {
            removeHostPreview(checkbox.value);
        }
    }

    function addOrUpdateHostPreviewRow(hostname, info) {
        const tbody = document.querySelector('#hostPreviewTable tbody');
        const rowId = 'hostPreviewRow_' + cssEscapeHost(hostname);
        let row = document.getElementById(rowId);
        if (!row) {
            row = document.createElement('tr');
            row.id = rowId;
            tbody.appendChild(row);
        }
        row.innerHTML = '<td>' + escapeHtml(hostname) + '</td>' +
            '<td>' + escapeHtml(info.project || '—') + '</td>' +
            '<td>' + escapeHtml(info.support_level || '—') + '</td>' +
            '<td>' + escapeHtml(info.ip_address || '—') + '</td>';
    }

    function loadHostPreview(hostname) {
        document.getElementById('hostPreviewWrap').hidden = false;

        if (hostPreviewCache[hostname]) {
            addOrUpdateHostPreviewRow(hostname, hostPreviewCache[hostname]);
            return;
        }

        addOrUpdateHostPreviewRow(hostname, { project: 'Loading...', support_level: '', ip_address: '' });

        fetch('decommission.php?action=get_inventory_details&hostname=' + encodeURIComponent(hostname))
            .then(res => res.json())
            .then(data => {
                const info = data.success ? data : { project: '—', support_level: '—', ip_address: '—' };
                hostPreviewCache[hostname] = info;
                addOrUpdateHostPreviewRow(hostname, info);
            })
            .catch(() => addOrUpdateHostPreviewRow(hostname, { project: '—', support_level: '—', ip_address: '—' }));
    }

    function removeHostPreview(hostname) {
        const row = document.getElementById('hostPreviewRow_' + cssEscapeHost(hostname));
        if (row) row.remove();
        const tbody = document.querySelector('#hostPreviewTable tbody');
        if (tbody && tbody.children.length === 0) {
            document.getElementById('hostPreviewWrap').hidden = true;
        }
    }

    function resetHostPicker() {
        document.querySelectorAll('#hostPickerList input[type=checkbox]').forEach(cb => cb.checked = false);
        document.getElementById('hostPickerSearch').value = '';
        filterHostPicker();
        updateHostPickerCount();
        document.querySelector('#hostPreviewTable tbody').innerHTML = '';
        document.getElementById('hostPreviewWrap').hidden = true;
        hostPreviewCache = {};
    }

    function openHostsModal(decommissionId, uniqueId) {
        document.getElementById('hostsModalUniqueId').innerText = uniqueId;
        document.getElementById('hostsModalBody').innerHTML = '<p class="task-loading">Loading hosts...</p>';
        new bootstrap.Modal(document.getElementById('hostsModal')).show();
        fetch('decommission.php?action=get_hosts&decommission_id=' + decommissionId)
            .then(res => res.text())
            .then(html => { document.getElementById('hostsModalBody').innerHTML = html; })
            .catch(() => { document.getElementById('hostsModalBody').innerHTML = '<p class="task-error">Failed to load hosts.</p>'; });
    }

    function openHostsModalFromEdit() {
        if (!currentEditDecommissionId) return;
        openHostsModal(currentEditDecommissionId, document.getElementById('rec_unique_id').value);
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'New Decommission Entry';
        document.getElementById('rec_id').value = '';
        document.getElementById('rec_existing_attachment').value = '';
        document.getElementById('fileHelpBlock').innerHTML = '';
        document.getElementById('rec_unique_id').value = '';
        document.getElementById('rec_req_no').value = '';
        document.getElementById('rec_assignee_id').value = '';
        document.getElementById('server_state').value = '';
        document.getElementById('rec_start_date').value = '';
        document.getElementById('rec_end_date').value = '';
        document.getElementById('hostPickerContainer').style.display = 'block';
        document.getElementById('hostSummaryContainer').style.display = 'none';
        currentEditDecommissionId = null;
        resetHostPicker();
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Decommission Entry';
        document.getElementById('rec_id').value = data.id;
        document.getElementById('rec_unique_id').value = data.unique_id || '';
        document.getElementById('rec_req_no').value = data.req_no || '';
        document.getElementById('rec_assignee_id').value = data.assignee_id || '';
        document.getElementById('server_state').value = data.server_state || '';
        document.getElementById('rec_start_date').value = data.decommission_start_date || '';
        document.getElementById('rec_end_date').value = data.decommission_end_date || '';
        document.getElementById('rec_existing_attachment').value = data.attachment || '';

        document.getElementById('hostPickerContainer').style.display = 'none';
        document.getElementById('hostSummaryContainer').style.display = 'block';
        const hostCount = parseInt(data.host_count || 0, 10);
        document.getElementById('hostSummaryText').innerText = 'This entry covers ' + hostCount + ' host' + (hostCount === 1 ? '' : 's') + '.';
        currentEditDecommissionId = data.id;

        let fileListHtml = 'No files currently attached.';
        if (data.attachment) {
            let files = data.attachment.split(',');
            fileListHtml = 'Current files: ';
            files.forEach((f, idx) => {
                fileListHtml += `<br><a href="uploads/${f.trim()}" target="_blank">File ${idx + 1} (${f.trim()})</a>`;
            });
        }
        document.getElementById('fileHelpBlock').innerHTML = fileListHtml;
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openDeleteModal(id, uniqueId) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_hostname').innerText = uniqueId;
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    }

    function openTaskModal(decommissionId, uniqueId, isEditable) {
        document.getElementById('taskModalHostname').innerText = uniqueId;
        document.getElementById('taskModalTitleMode').innerText = isEditable ? 'Modify Checklist Tasks' : 'View Checklist Tasks';
        document.getElementById('taskModalBody').innerHTML = '<p class="task-loading">Loading checklist tasks...</p>';

        fetch('tasks.php?decommission_id=' + decommissionId + '&edit=' + (isEditable ? 1 : 0))
            .then(res => res.text())
            .then(html => { document.getElementById('taskModalBody').innerHTML = html; })
            .catch(() => { document.getElementById('taskModalBody').innerHTML = '<p class="task-error">Failed to load tasks.</p>'; });

        new bootstrap.Modal(document.getElementById('taskModal')).show();
    }

    function submitTaskForm(event, decommissionId) {
        event.preventDefault();
        const form = document.getElementById('inlineTaskForm');
        const formData = new FormData(form);

        fetch('tasks.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.text())
        .then(html => {
            document.getElementById('taskModalBody').innerHTML = html;
        })
        .catch(() => {
            alert('Failed to save task progress.');
        });
    }

    function openGlobalHistoryModal() {
        new bootstrap.Modal(document.getElementById('globalHistoryModal')).show();
        document.getElementById('globalHistoryContent').innerHTML = '<p class="task-loading">Loading audit history...</p>';
        fetch('decommission.php?action=get_history')
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="task-error">Failed to load audit history.</p>'; });
    }

    function openRowHistoryModal(recordId, uniqueId) {
        new bootstrap.Modal(document.getElementById('globalHistoryModal')).show();
        document.getElementById('globalHistoryContent').innerHTML = '<p class="task-loading">Loading audit history...</p>';
        fetch(`decommission.php?action=get_history&record_id=${recordId}`)
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="task-error">Failed to load audit history.</p>'; });
    }

    function openImportModal() {
        new bootstrap.Modal(document.getElementById('importModal')).show();
    }

    function closeImportModal() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('importModal'));
        if (modal) modal.hide();
    }

    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    }
</script>

<?php require 'includes/footer.php'; ?>
