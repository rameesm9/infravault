<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/mail-helpers.php';
require_once __DIR__ . '/includes/ldap-helpers.php';
require_once __DIR__ . '/includes/permission-helpers.php';
require_once __DIR__ . '/includes/branding-helpers.php';


/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
| Routed through the standard page-permission table (page_key 'settings',
| already registered in permission.php) rather than a hardcoded Admin
| check, so it behaves like every other module: the Admin role always has
| full access, and an Admin can additionally grant can_view/can_edit on
| the 'settings' page to other roles from permission.php if they choose to.
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id']) || !isset($_SESSION['role'])) {
    header("Location: index.php");
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];
$role = trim($_SESSION['role']);
$is_admin = in_array(strtolower($role), ['admin', 'administrator', 'super admin', 'superadmin'], true);

$canViewSettings = $is_admin || hasRolePermission($pdo, $role, 'settings', 'can_view');
$canEditSettings = $is_admin || hasRolePermission($pdo, $role, 'settings', 'can_edit');

if (!$canViewSettings) {
    header("Location: home.php");
    exit;
}


function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];

function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $token)) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| CURRENT USER DISPLAY NAME (for the updated_by column)
|--------------------------------------------------------------------------
*/

$updatedByName = 'Unknown User';
try {
    $stmt = $pdo->prepare("SELECT first_name, last_name, ncgr_id FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$current_user_id]);
    $u = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($u) {
        $name = trim(($u['first_name'] ?? '') . ' ' . ($u['last_name'] ?? ''));
        $updatedByName = $name !== '' ? $name : ($u['ncgr_id'] ?? $updatedByName);
    }
} catch (Throwable $e) {
    // Keep the fallback name; this is cosmetic only.
}


$successMessage = '';
$errorMessage = '';
$testResult = null;
$ldapTestResult = null;


/*
|--------------------------------------------------------------------------
| HANDLE POST
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    if (!$canEditSettings) {
        http_response_code(403);
        exit('You have view-only access to Settings and cannot make changes.');
    }

    $formAction = $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE MAIL SETTINGS (connection + module toggles together)
    |--------------------------------------------------------------------------
    */

    if ($formAction === 'save_mail_settings') {

        $envOverrides = getMailEnvOverrides();

        $isEnabled = isset($_POST['is_enabled']) ? 1 : 0;
        $smtpHost = trim($_POST['smtp_host'] ?? '');
        $smtpPort = (int) ($_POST['smtp_port'] ?? 587);
        $smtpEncryption = $_POST['smtp_encryption'] ?? 'tls';
        $smtpUsername = trim($_POST['smtp_username'] ?? '');
        $fromEmail = trim($_POST['from_email'] ?? '');
        $fromName = trim($_POST['from_name'] ?? 'InfraVault');
        $smtpTimeout = (int) ($_POST['smtp_timeout'] ?? 15);

        if (!in_array($smtpEncryption, ['', 'tls', 'ssl'], true)) {
            $smtpEncryption = 'tls';
        }

        if ($isEnabled && $smtpHost === '') {
            $errorMessage = 'SMTP Host is required to enable email notifications.';
        } elseif ($fromEmail !== '' && !filter_var($fromEmail, FILTER_VALIDATE_EMAIL)) {
            $errorMessage = 'From Email is not a valid email address.';
        } else {

            // Password: blank input means "keep the existing stored value" --
            // the real password is never echoed back into the form, so an
            // empty submit must not silently wipe it out. An explicit
            // "clear_password" checkbox is the only way to blank it.
            $newPassword = $_POST['smtp_password'] ?? '';
            $clearPassword = isset($_POST['clear_password']);

            try {
                if ($newPassword !== '') {
                    $stmt = $pdo->prepare("
                        UPDATE mail_settings SET
                            is_enabled = ?, smtp_host = ?, smtp_port = ?, smtp_encryption = ?,
                            smtp_username = ?, smtp_password = ?, from_email = ?, from_name = ?,
                            smtp_timeout = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $smtpHost, $smtpPort, $smtpEncryption,
                        $smtpUsername, $newPassword, $fromEmail, $fromName,
                        $smtpTimeout, $updatedByName,
                    ]);
                } elseif ($clearPassword) {
                    $stmt = $pdo->prepare("
                        UPDATE mail_settings SET
                            is_enabled = ?, smtp_host = ?, smtp_port = ?, smtp_encryption = ?,
                            smtp_username = ?, smtp_password = '', from_email = ?, from_name = ?,
                            smtp_timeout = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $smtpHost, $smtpPort, $smtpEncryption,
                        $smtpUsername, $fromEmail, $fromName,
                        $smtpTimeout, $updatedByName,
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE mail_settings SET
                            is_enabled = ?, smtp_host = ?, smtp_port = ?, smtp_encryption = ?,
                            smtp_username = ?, from_email = ?, from_name = ?,
                            smtp_timeout = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $smtpHost, $smtpPort, $smtpEncryption,
                        $smtpUsername, $fromEmail, $fromName,
                        $smtpTimeout, $updatedByName,
                    ]);
                }

                // Module toggles.
                $submittedModules = $_POST['modules'] ?? [];
                $allModules = getAllMailModuleToggles($pdo);
                $toggleStmt = $pdo->prepare("UPDATE mail_module_toggles SET is_enabled = ? WHERE module_key = ?");

                foreach ($allModules as $module) {
                    $key = $module['module_key'];
                    $enabled = isset($submittedModules[$key]) ? 1 : 0;
                    $toggleStmt->execute([$enabled, $key]);
                }

                $successMessage = 'Mail settings saved successfully.';

            } catch (Throwable $e) {
                $errorMessage = 'Unable to save settings: ' . $e->getMessage();
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SEND TEST EMAIL
    |--------------------------------------------------------------------------
    | Uses whatever is currently saved in the database (not the unsaved form
    | state) and intentionally bypasses the global/module enable switches --
    | this lets an admin verify SMTP credentials work before flipping mail
    | on for real.
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'send_test_email') {

        $testEmail = trim($_POST['test_email'] ?? '');

        if ($testEmail === '' || !filter_var($testEmail, FILTER_VALIDATE_EMAIL)) {
            $testResult = ['success' => false, 'message' => 'Enter a valid email address to send the test to.'];
        } else {
            try {
                $mailer = new SmtpMailer(getMailSettings($pdo));
                $testResult = $mailer->send(
                    $testEmail,
                    '',
                    getAppName($pdo) . ' SMTP Test',
                    '<p>This is a test email from ' . h(getAppName($pdo)) . ' Settings.</p>' .
                    '<p>If you received this, your SMTP configuration is working.</p>' .
                    '<p style="color:var(--text-secondary);font-size:12px;">Sent by ' . h($updatedByName) . ' at ' . date('Y-m-d H:i:s') . '</p>'
                );
            } catch (Throwable $e) {
                $testResult = ['success' => false, 'message' => $e->getMessage()];
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE SECURITY SETTINGS
    |--------------------------------------------------------------------------
    | Only the tunables are writable here. CSRF verification, the security
    | response headers, session cookie flags and the per-page authorization
    | checks are enforced unconditionally in includes/security.php and are
    | deliberately not exposed as switches -- a control that can be turned
    | off from a web form is one an attacker who reaches that form can turn
    | off too.
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'save_security_settings') {

        $securityEnvOverrides = getSecurityEnvOverrides();

        // Clamped rather than rejected: these come from number inputs, and
        // silently landing on a safe value beats bouncing the whole form.
        $idleTimeout      = max(1,  min(1440, (int) ($_POST['idle_timeout_minutes'] ?? 30)));
        $absoluteTimeout  = max(0,  min(168,  (int) ($_POST['absolute_timeout_hours'] ?? 12)));
        $lockoutEnabled   = isset($_POST['lockout_enabled']) ? 1 : 0;
        $lockoutThreshold = max(1,  min(50,   (int) ($_POST['lockout_threshold'] ?? 5)));
        $lockoutWindow    = max(1,  min(1440, (int) ($_POST['lockout_window_minutes'] ?? 15)));
        $lockoutDuration  = max(1,  min(1440, (int) ($_POST['lockout_duration_minutes'] ?? 15)));

        $passwordMinLength = max(8, min(128, (int) ($_POST['password_min_length'] ?? 12)));
        $requireUpper  = isset($_POST['password_require_upper'])  ? 1 : 0;
        $requireLower  = isset($_POST['password_require_lower'])  ? 1 : 0;
        $requireNumber = isset($_POST['password_require_number']) ? 1 : 0;
        $requireSymbol = isset($_POST['password_require_symbol']) ? 1 : 0;

        $cspMode = strtolower(trim($_POST['csp_mode'] ?? 'report-only'));
        if (!in_array($cspMode, ['off', 'report-only', 'enforce'], true)) {
            $cspMode = 'report-only';
        }

        try {
            $pdo->prepare("
                UPDATE security_settings SET
                    idle_timeout_minutes = ?, absolute_timeout_hours = ?,
                    lockout_enabled = ?, lockout_threshold = ?,
                    lockout_window_minutes = ?, lockout_duration_minutes = ?,
                    password_min_length = ?,
                    password_require_upper = ?, password_require_lower = ?,
                    password_require_number = ?, password_require_symbol = ?,
                    csp_mode = ?,
                    updated_by = ?, updated_at = CURRENT_TIMESTAMP
                WHERE id = 1
            ")->execute([
                $idleTimeout, $absoluteTimeout,
                $lockoutEnabled, $lockoutThreshold,
                $lockoutWindow, $lockoutDuration,
                $passwordMinLength,
                $requireUpper, $requireLower, $requireNumber, $requireSymbol,
                $cspMode,
                $updatedByName,
            ]);

            $successMessage = 'Security settings saved successfully.';

        } catch (Throwable $e) {
            $errorMessage = 'Unable to save security settings: ' . $e->getMessage();
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CLEAR LOCKOUTS
    |--------------------------------------------------------------------------
    | Releases everyone currently locked out, for the case where a legitimate
    | user is stuck and cannot wait out the window.
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'clear_lockouts') {

        try {
            $cleared = $pdo->exec("DELETE FROM login_attempts WHERE success = 0");
            $successMessage = 'Cleared ' . (int) $cleared . ' failed sign-in record(s). Any active lockouts are released.';
        } catch (Throwable $e) {
            $errorMessage = 'Unable to clear lockouts: ' . $e->getMessage();
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE LDAP SETTINGS
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'save_ldap_settings') {

        $ldapEnvOverrides = getLdapEnvOverrides();

        $isEnabled = isset($_POST['ldap_is_enabled']) ? 1 : 0;
        $host = trim($_POST['ldap_host'] ?? '');
        $port = (int) ($_POST['ldap_port'] ?? 636);
        $encryption = $_POST['ldap_encryption'] ?? 'ldaps';
        $baseDn = trim($_POST['ldap_base_dn'] ?? '');
        $bindDn = trim($_POST['ldap_bind_dn'] ?? '');
        $caCert = trim($_POST['ldap_ca_cert'] ?? '');
        $verifyCertificate = isset($_POST['ldap_verify_certificate']) ? 1 : 0;
        $searchFilter = trim($_POST['ldap_search_filter'] ?? '(sAMAccountName=%s)');
        $defaultRoleLdap = trim($_POST['ldap_default_role'] ?? 'Read-only');

        if (!in_array($encryption, ['ldaps', 'starttls'], true)) {
            $encryption = 'ldaps';
        }

        if ($isEnabled && $host === '') {
            $errorMessage = 'LDAP Host is required to enable LDAP authentication.';
        } elseif ($isEnabled && $baseDn === '') {
            $errorMessage = 'Base DN is required to enable LDAP authentication.';
        } else {

            $newBindPassword = $_POST['ldap_bind_password'] ?? '';
            $clearBindPassword = isset($_POST['ldap_clear_bind_password']);

            try {
                if ($newBindPassword !== '') {
                    $stmt = $pdo->prepare("
                        UPDATE ldap_settings SET
                            is_enabled = ?, host = ?, port = ?, encryption = ?, base_dn = ?,
                            bind_dn = ?, bind_password = ?, ca_cert = ?, verify_certificate = ?,
                            user_search_filter = ?, default_role = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $host, $port, $encryption, $baseDn,
                        $bindDn, $newBindPassword, $caCert, $verifyCertificate,
                        $searchFilter, $defaultRoleLdap, $updatedByName,
                    ]);
                } elseif ($clearBindPassword) {
                    $stmt = $pdo->prepare("
                        UPDATE ldap_settings SET
                            is_enabled = ?, host = ?, port = ?, encryption = ?, base_dn = ?,
                            bind_dn = ?, bind_password = '', ca_cert = ?, verify_certificate = ?,
                            user_search_filter = ?, default_role = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $host, $port, $encryption, $baseDn,
                        $bindDn, $caCert, $verifyCertificate,
                        $searchFilter, $defaultRoleLdap, $updatedByName,
                    ]);
                } else {
                    $stmt = $pdo->prepare("
                        UPDATE ldap_settings SET
                            is_enabled = ?, host = ?, port = ?, encryption = ?, base_dn = ?,
                            bind_dn = ?, ca_cert = ?, verify_certificate = ?,
                            user_search_filter = ?, default_role = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = 1
                    ");
                    $stmt->execute([
                        $isEnabled, $host, $port, $encryption, $baseDn,
                        $bindDn, $caCert, $verifyCertificate,
                        $searchFilter, $defaultRoleLdap, $updatedByName,
                    ]);
                }

                $successMessage = 'LDAP settings saved successfully.';

            } catch (Throwable $e) {
                $errorMessage = 'Unable to save LDAP settings: ' . $e->getMessage();
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | TEST LDAP CONNECTION
    |--------------------------------------------------------------------------
    | Uses whatever is currently saved (save first if you just changed
    | anything). Binds with the service account only -- optionally also
    | searches for a sample username if one was given, without needing a
    | real end-user password.
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'test_ldap_connection') {

        $testUsername = trim($_POST['ldap_test_username'] ?? '');
        $ldapTestResult = testLdapConnection($pdo, $testUsername);
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE BRANDING (application name + logo)
    |--------------------------------------------------------------------------
    */

    elseif ($formAction === 'save_branding') {

        $newAppName = trim($_POST['app_name'] ?? '');
        $resetLogo = isset($_POST['reset_logo']);

        if ($newAppName === '') {
            $errorMessage = 'Application Name cannot be empty.';
        } else {

            try {
                $brandingRow = getBrandingRow($pdo);
                $logoPath = $brandingRow['logo_path'] ?? '';

                $uploaded = brandingSaveLogoUpload($_FILES['logo'] ?? []);

                if ($uploaded !== null) {
                    brandingDeleteUploadedLogo($logoPath);
                    $logoPath = $uploaded;
                } elseif ($resetLogo) {
                    brandingDeleteUploadedLogo($logoPath);
                    $logoPath = '';
                }

                $pdo->prepare("
                    UPDATE branding_settings SET
                        app_name = ?, logo_path = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                    WHERE id = 1
                ")->execute([$newAppName, $logoPath, $updatedByName]);

                $successMessage = 'Branding saved successfully.';

            } catch (Throwable $e) {
                $errorMessage = 'Unable to save branding: ' . $e->getMessage();
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| LOAD CURRENT STATE FOR DISPLAY
|--------------------------------------------------------------------------
*/

$mailRow = getMailSettingsRow($pdo);
$envOverrides = getMailEnvOverrides();
$moduleToggles = getAllMailModuleToggles($pdo);
$hasStoredPassword = trim((string) ($pdo->query("SELECT smtp_password FROM mail_settings WHERE id = 1")->fetchColumn() ?: '')) !== '';

$ldapRow = getLdapSettingsRow($pdo);
$ldapEnvOverrides = getLdapEnvOverrides();
$hasStoredBindPassword = trim((string) ($pdo->query("SELECT bind_password FROM ldap_settings WHERE id = 1")->fetchColumn() ?: '')) !== '';
$ldapExtensionAvailable = extension_loaded('ldap');
$availableRoleNames = $pdo->query("SELECT role_name FROM roles ORDER BY role_name ASC")->fetchAll(PDO::FETCH_COLUMN);

$securityRow = getSecuritySettings($pdo);
$securityEnvOverrides = getSecurityEnvOverrides();

$brandingRow = getBrandingRow($pdo);
$currentAppName = getAppName($pdo);
$currentLogoUrl = getAppLogoUrl($pdo);

// Live status of the controls that are enforced in code rather than
// configured here, so the panel can report them instead of pretending
// they are options.
$httpsActive       = requestIsHttps();
$httpsForced       = getenv('APP_FORCE_HTTPS') === '1';
$trustedProxy      = getenv('TRUSTED_PROXY') === '1';
$sessionCookieOpts = session_get_cookie_params();

$activeLockouts = 0;
try {
    $activeLockouts = (int) $pdo->query("
        SELECT COUNT(DISTINCT identifier) FROM login_attempts WHERE success = 0
    ")->fetchColumn();
} catch (Throwable $e) {
    // Non-critical display value.
}


$page_title = "Settings | InfraVault";

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>


<div class="content">


<style>

.settings-container {
    max-width: 900px;
    margin: 0 auto;
}

.settings-header {
    margin-bottom: 24px;
}

.settings-header h1 {
    margin: 0;
    color: var(--text-primary, #0f172a);
}

.settings-header p {
    margin: 6px 0 0;
    color: var(--text-secondary);
}

.settings-message-success {
    background: #dcfce7;
    color: #166534;
    border: 1px solid #bbf7d0;
    padding: 14px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.settings-message-error {
    background: #fee2e2;
    color: #991b1b;
    border: 1px solid #fecaca;
    padding: 14px;
    border-radius: 8px;
    margin-bottom: 20px;
}

.settings-panel {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 26px;
    margin-bottom: 22px;
    box-shadow: 0 5px 20px rgba(15, 23, 42, .05);
}

.settings-panel h2 {
    margin: 0 0 4px;
    font-size: 18px;
    color: var(--text-primary);
}

.settings-panel .panel-subtitle {
    margin: 0 0 18px;
    color: var(--text-secondary);
    font-size: 13px;
}

.settings-info-box {
    background: #eff6ff;
    border: 1px solid #bfdbfe;
    color: #1e40af;
    padding: 14px 16px;
    border-radius: 8px;
    margin-bottom: 20px;
    line-height: 1.5;
    font-size: 13.5px;
}

.settings-info-box code {
    background: rgba(255,255,255,.6);
    padding: 1px 6px;
    border-radius: 4px;
}

.settings-env-notice {
    background: #fff7ed;
    border: 1px solid #fed7aa;
    color: #9a3412;
    padding: 12px 16px;
    border-radius: 8px;
    margin-bottom: 18px;
    font-size: 13.5px;
}

[data-theme="dark"] .settings-info-box {
    background: #1e2a4a;
    border-color: #29365a;
    color: #a8c8ff;
}

[data-theme="dark"] .settings-info-box code {
    background: rgba(0,0,0,.25);
}

[data-theme="dark"] .settings-env-notice {
    background: #3a2a14;
    border-color: #4a3620;
    color: #F5B054;
}

.settings-toggle-row {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 0;
    border-bottom: 1px solid var(--border-light);
}

.settings-toggle-row:last-child {
    border-bottom: none;
}

.settings-form-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
}

.settings-field {
    display: flex;
    flex-direction: column;
    gap: 6px;
    margin-bottom: 14px;
}

.settings-field.full {
    grid-column: 1 / -1;
}

.settings-field label {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
}

.settings-field input[type="text"],
.settings-field input[type="password"],
.settings-field input[type="email"],
.settings-field input[type="number"],
.settings-field select {
    border: 1px solid var(--border-color);
    border-radius: 8px;
    padding: 10px 12px;
    font-size: 14px;
    font-family: inherit;
    background: var(--bg-content);
}

.settings-field input:disabled,
.settings-field select:disabled {
    background: var(--hover-bg);
    color: var(--text-muted);
    cursor: not-allowed;
}

.settings-field small {
    color: var(--text-muted);
    font-size: 12px;
}

.settings-checkbox-label {
    display: flex;
    align-items: center;
    gap: 8px;
    font-weight: 600;
    color: var(--text-primary);
    cursor: pointer;
}

.settings-checkbox-label input {
    width: 18px;
    height: 18px;
    accent-color: #2563eb;
    cursor: pointer;
}

.settings-btn {
    border: 0;
    padding: 11px 20px;
    border-radius: 8px;
    font-weight: 600;
    cursor: pointer;
    font-size: 14px;
}

.settings-btn-primary {
    background: #2563eb;
    color: #fff;
}

.settings-btn-primary:hover {
    background: #1d4ed8;
}

.settings-btn-secondary {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    color: var(--text-primary);
}

.settings-btn-secondary:hover {
    background: var(--hover-bg);
}

.settings-test-row {
    display: flex;
    gap: 10px;
    align-items: flex-end;
    flex-wrap: wrap;
}

.settings-test-row .settings-field {
    flex: 1;
    min-width: 240px;
    margin-bottom: 0;
}

.settings-meta {
    color: var(--text-muted);
    font-size: 12px;
    margin-top: 14px;
}

@media (max-width: 700px) {
    .settings-form-grid {
        grid-template-columns: 1fr;
    }
}

</style>


<div class="settings-container">


<div class="settings-header">
    <h1>Settings</h1>
    <p>Branding, email, authentication and security configuration for <?= h($currentAppName) ?>.</p>
</div>


<?php if ($successMessage !== ''): ?>
    <div class="settings-message-success">&check; <?= h($successMessage) ?></div>
<?php endif; ?>

<?php if ($errorMessage !== ''): ?>
    <div class="settings-message-error"><strong>Error:</strong> <?= h($errorMessage) ?></div>
<?php endif; ?>

<?php if ($testResult !== null): ?>
    <?php if ($testResult['success']): ?>
        <div class="settings-message-success">&check; Test email sent successfully.</div>
    <?php else: ?>
        <div class="settings-message-error"><strong>Test email failed:</strong> <?= h($testResult['message']) ?></div>
    <?php endif; ?>
<?php endif; ?>


<!-- ==========================================================
     BRANDING
     ========================================================== -->

<form method="POST" action="settings.php" enctype="multipart/form-data">

    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
    <input type="hidden" name="form_action" value="save_branding">

    <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;">

    <div class="settings-panel">

        <h2>Branding</h2>
        <p class="panel-subtitle">
            The application name and logo shown across the header, sidebar, sign-in pages and the AI assistant.
            Changing these here renames the app everywhere at once -- no other file needs to be touched.
        </p>

        <div class="settings-form-grid">

            <div class="settings-field full">
                <label>Application Name</label>
                <input type="text" name="app_name" maxlength="60" required value="<?= h($currentAppName) ?>">
                <small>Replaces every "InfraVault" shown to users -- page titles, the sidebar, sign-in/sign-up/reset pages, emails and the chat assistant.</small>
            </div>

            <div class="settings-field full">
                <label>Logo</label>
                <div style="display:flex;align-items:center;gap:16px;flex-wrap:wrap;">
                    <img src="<?= h($currentLogoUrl) ?>" alt="Current logo" style="height:48px;width:auto;max-width:160px;object-fit:contain;background:var(--hover-bg);border-radius:8px;padding:6px;">
                    <input type="file" name="logo" accept=".svg,.png,.jpg,.jpeg,.webp" style="flex:1;min-width:220px;">
                </div>
                <small>SVG, PNG, JPG or WEBP, up to 2MB. Used as the sidebar/login logo and the browser tab icon.</small>
                <?php if ($brandingRow['logo_path'] !== ''): ?>
                    <label style="font-weight:400;display:inline-flex;align-items:center;gap:5px;cursor:pointer;margin-top:4px;">
                        <input type="checkbox" name="reset_logo" style="width:14px;height:14px;"> Remove custom logo and use the default
                    </label>
                <?php endif; ?>
            </div>

        </div>

        <?php if (!empty($brandingRow['updated_at'])): ?>
            <div class="settings-meta">Last updated <?= h($brandingRow['updated_at']) ?><?= !empty($brandingRow['updated_by']) ? ' by ' . h($brandingRow['updated_by']) : '' ?></div>
        <?php endif; ?>

    </div>

    <button type="submit" class="settings-btn settings-btn-primary">Save Branding</button>

    </fieldset>

</form>


<div class="settings-info-box" style="margin-top:22px;">
    Running in a container? Any of <code>SMTP_HOST</code>, <code>SMTP_PORT</code>, <code>SMTP_ENCRYPTION</code>,
    <code>SMTP_USERNAME</code>, <code>SMTP_PASSWORD</code>, <code>SMTP_FROM_EMAIL</code>, <code>SMTP_FROM_NAME</code>,
    <code>SMTP_TIMEOUT</code> set as environment variables (e.g. via <code>podman run --env</code> or a Podman secret)
    will override the matching field below at send time -- a more idiomatic way to inject credentials than typing
    them into this form. Fields stored here live in the application database, so as long as
    <code>config/infravault.db</code> is on a mounted volume, they persist across container restarts/recreation.
</div>


<?php if (!empty($envOverrides)): ?>
    <div class="settings-env-notice">
        <strong>&#9888; Environment overrides active:</strong>
        The following fields are currently controlled by container environment variables and are disabled below --
        <?php foreach ($envOverrides as $col => $var): ?>
            <code><?= h($var) ?></code><?= $col !== array_key_last($envOverrides) ? ', ' : '' ?>
        <?php endforeach; ?>.
        Unset them on the container to manage these from this form instead.
    </div>
<?php endif; ?>


<?php if (!$canEditSettings): ?>
    <div class="settings-env-notice">
        <strong>View-only access.</strong> Your role can view these settings but not change them.
        Ask an Admin to grant "Edit" on the Settings page in Manage Permissions if you need to make changes.
    </div>
<?php endif; ?>


<form method="POST" action="settings.php">

    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
    <input type="hidden" name="form_action" value="save_mail_settings">

    <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;">

    <div class="settings-panel">

        <h2>Email Notifications</h2>
        <p class="panel-subtitle">SMTP connection used to send outbound notification emails.</p>

        <label class="settings-checkbox-label" style="margin-bottom:18px;">
            <input type="checkbox" name="is_enabled" <?= (int) $mailRow['is_enabled'] === 1 ? 'checked' : '' ?> <?= isset($envOverrides['is_enabled']) ? 'disabled' : '' ?>>
            Enable Email Notifications
        </label>

        <div class="settings-form-grid">

            <div class="settings-field full">
                <label>SMTP Host</label>
                <input type="text" name="smtp_host" placeholder="smtp.yourcompany.local"
                    value="<?= h($mailRow['smtp_host']) ?>" <?= isset($envOverrides['smtp_host']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>SMTP Port</label>
                <input type="number" name="smtp_port" value="<?= h($mailRow['smtp_port']) ?>"
                    <?= isset($envOverrides['smtp_port']) ? 'disabled' : '' ?>>
                <small>Common: 25 (unencrypted), 587 (STARTTLS), 465 (SSL)</small>
            </div>

            <div class="settings-field">
                <label>Encryption</label>
                <select name="smtp_encryption" <?= isset($envOverrides['smtp_encryption']) ? 'disabled' : '' ?>>
                    <option value="" <?= $mailRow['smtp_encryption'] === '' ? 'selected' : '' ?>>None</option>
                    <option value="tls" <?= $mailRow['smtp_encryption'] === 'tls' ? 'selected' : '' ?>>STARTTLS (recommended)</option>
                    <option value="ssl" <?= $mailRow['smtp_encryption'] === 'ssl' ? 'selected' : '' ?>>SSL / Implicit TLS</option>
                </select>
            </div>

            <div class="settings-field">
                <label>Username <small style="font-weight:400;">(if required)</small></label>
                <input type="text" name="smtp_username" autocomplete="off" placeholder="Leave blank if not required"
                    value="<?= h($mailRow['smtp_username']) ?>" <?= isset($envOverrides['smtp_username']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>Password <small style="font-weight:400;">(if required)</small></label>
                <input type="password" name="smtp_password" autocomplete="new-password"
                    placeholder="<?= $hasStoredPassword ? '•••••••• (unchanged)' : 'Leave blank if not required' ?>"
                    <?= isset($envOverrides['smtp_password']) ? 'disabled' : '' ?>>
                <?php if ($hasStoredPassword && !isset($envOverrides['smtp_password'])): ?>
                    <small>
                        <label style="font-weight:400;display:inline-flex;align-items:center;gap:5px;cursor:pointer;">
                            <input type="checkbox" name="clear_password" style="width:14px;height:14px;"> Clear stored password
                        </label>
                    </small>
                <?php endif; ?>
            </div>

            <div class="settings-field">
                <label>From Email</label>
                <input type="email" name="from_email" placeholder="infravault@yourcompany.local"
                    value="<?= h($mailRow['from_email']) ?>" <?= isset($envOverrides['from_email']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>From Name</label>
                <input type="text" name="from_name" value="<?= h($mailRow['from_name']) ?>"
                    <?= isset($envOverrides['from_name']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>Connection Timeout (seconds)</label>
                <input type="number" name="smtp_timeout" value="<?= h($mailRow['smtp_timeout']) ?>"
                    <?= isset($envOverrides['smtp_timeout']) ? 'disabled' : '' ?>>
            </div>

        </div>

        <?php if (!empty($mailRow['updated_at'])): ?>
            <div class="settings-meta">Last updated <?= h($mailRow['updated_at']) ?><?= !empty($mailRow['updated_by']) ? ' by ' . h($mailRow['updated_by']) : '' ?></div>
        <?php endif; ?>

    </div>


    <div class="settings-panel">

        <h2>Mail Modules</h2>
        <p class="panel-subtitle">
            Turn email notifications on per module. A module only sends mail if <strong>both</strong>
            this toggle and "Enable Email Notifications" above are on.
        </p>

        <?php if (empty($moduleToggles)): ?>
            <p style="color:var(--text-muted);">No mail-enabled modules registered yet.</p>
        <?php else: ?>
            <?php foreach ($moduleToggles as $module): ?>
                <div class="settings-toggle-row">
                    <label class="settings-checkbox-label" style="flex:1;">
                        <input type="checkbox" name="modules[<?= h($module['module_key']) ?>]"
                            <?= (int) $module['is_enabled'] === 1 ? 'checked' : '' ?>>
                        <?= h($module['module_label']) ?>
                    </label>
                    <span style="color:var(--text-muted);font-size:12px;"><?= h($module['module_key']) ?></span>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>

    </div>

    <button type="submit" class="settings-btn settings-btn-primary">Save Settings</button>

    </fieldset>

</form>


<div class="settings-panel" style="margin-top:22px;">

    <h2>Send Test Email</h2>
    <p class="panel-subtitle">
        Sends using the settings currently saved above (save first if you just changed anything).
        This ignores the enable switches, so you can verify credentials before turning mail on.
    </p>

    <form method="POST" action="settings.php" class="settings-test-row">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="form_action" value="send_test_email">

        <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;display:contents;">

        <div class="settings-field">
            <label>Recipient Email</label>
            <input type="email" name="test_email" placeholder="you@yourcompany.local" required>
        </div>

        <button type="submit" class="settings-btn settings-btn-secondary">Send Test Email</button>

        </fieldset>
    </form>

</div>


<?php if ($ldapTestResult !== null): ?>
    <?php if ($ldapTestResult['success']): ?>
        <div class="settings-message-success">&check; <?= h($ldapTestResult['message']) ?></div>
    <?php else: ?>
        <div class="settings-message-error"><strong>LDAP test failed:</strong> <?= h($ldapTestResult['message']) ?></div>
    <?php endif; ?>
<?php endif; ?>

<?php if (!$ldapExtensionAvailable): ?>
    <div class="settings-env-notice">
        <strong>&#9888; PHP ldap extension not installed.</strong>
        You can fill in and save these settings, but authentication will fail until the <code>ldap</code>
        PHP extension is installed on the server (<code>docker-php-ext-install ldap</code> in the Containerfile).
    </div>
<?php endif; ?>

<?php if (!empty($ldapEnvOverrides)): ?>
    <div class="settings-env-notice">
        <strong>&#9888; Environment overrides active:</strong>
        The following fields are currently controlled by container environment variables and are disabled below --
        <?php foreach ($ldapEnvOverrides as $col => $var): ?>
            <code><?= h($var) ?></code><?= $col !== array_key_last($ldapEnvOverrides) ? ', ' : '' ?>
        <?php endforeach; ?>.
    </div>
<?php endif; ?>


<form method="POST" action="settings.php">

    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
    <input type="hidden" name="form_action" value="save_ldap_settings">

    <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;">

    <div class="settings-panel">

        <h2>LDAP / Active Directory Authentication</h2>
        <p class="panel-subtitle">
            Lets users sign in with their directory (AD) credentials. Only their username, email, and
            sAMAccountName are read from the directory -- the password is never stored, every login re-verifies
            live against LDAP. A user's first successful LDAP login creates a pending account that an Admin must
            approve in Manage Users, exactly like a local self-registration.
        </p>

        <label class="settings-checkbox-label" style="margin-bottom:18px;">
            <input type="checkbox" name="ldap_is_enabled" <?= (int) $ldapRow['is_enabled'] === 1 ? 'checked' : '' ?> <?= isset($ldapEnvOverrides['is_enabled']) ? 'disabled' : '' ?>>
            Enable LDAP Authentication
        </label>

        <div class="settings-form-grid">

            <div class="settings-field">
                <label>Host</label>
                <input type="text" name="ldap_host" placeholder="dc01.yourcompany.local"
                    value="<?= h($ldapRow['host']) ?>" <?= isset($ldapEnvOverrides['host']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>Port</label>
                <input type="number" name="ldap_port" value="<?= h($ldapRow['port']) ?>"
                    <?= isset($ldapEnvOverrides['port']) ? 'disabled' : '' ?>>
                <small>Common: 636 (LDAPS), 389 (plain / STARTTLS)</small>
            </div>

            <div class="settings-field full">
                <label>Connection Security</label>
                <select name="ldap_encryption" <?= isset($ldapEnvOverrides['encryption']) ? 'disabled' : '' ?>>
                    <option value="ldaps" <?= $ldapRow['encryption'] === 'ldaps' ? 'selected' : '' ?>>LDAPS (implicit TLS, recommended)</option>
                    <option value="starttls" <?= $ldapRow['encryption'] === 'starttls' ? 'selected' : '' ?>>STARTTLS (plain port, upgraded to TLS)</option>
                </select>
            </div>

            <div class="settings-field full">
                <label>Base DN</label>
                <input type="text" name="ldap_base_dn" placeholder="DC=yourcompany,DC=local"
                    value="<?= h($ldapRow['base_dn']) ?>" <?= isset($ldapEnvOverrides['base_dn']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>Service Account DN</label>
                <input type="text" name="ldap_bind_dn" autocomplete="off" placeholder="svc_infravault@yourcompany.local"
                    value="<?= h($ldapRow['bind_dn']) ?>" <?= isset($ldapEnvOverrides['bind_dn']) ? 'disabled' : '' ?>>
                <small>A read-only account used to search the directory. Not a Domain Admin.</small>
            </div>

            <div class="settings-field">
                <label>Service Account Password</label>
                <input type="password" name="ldap_bind_password" autocomplete="new-password"
                    placeholder="<?= $hasStoredBindPassword ? '•••••••• (unchanged)' : 'Enter password' ?>"
                    <?= isset($ldapEnvOverrides['bind_password']) ? 'disabled' : '' ?>>
                <?php if ($hasStoredBindPassword && !isset($ldapEnvOverrides['bind_password'])): ?>
                    <small>
                        <label style="font-weight:400;display:inline-flex;align-items:center;gap:5px;cursor:pointer;">
                            <input type="checkbox" name="ldap_clear_bind_password" style="width:14px;height:14px;"> Clear stored password
                        </label>
                    </small>
                <?php endif; ?>
            </div>

            <div class="settings-field full">
                <label>CA Certificate (PEM)</label>
                <textarea name="ldap_ca_cert" rows="6" placeholder="-----BEGIN CERTIFICATE-----&#10;...&#10;-----END CERTIFICATE-----"
                    style="border:1px solid var(--border-color);border-radius:8px;padding:10px 12px;font-size:12.5px;font-family:monospace;resize:vertical;"><?= h($ldapRow['ca_cert']) ?></textarea>
                <small>The certificate authority that signed the directory server's TLS certificate. Leave blank only if your directory's certificate is already trusted by the system, or if Verify Certificate below is off.</small>
            </div>

            <div class="settings-field full">
                <label class="settings-checkbox-label" style="font-weight:400;">
                    <input type="checkbox" name="ldap_verify_certificate" <?= (int) $ldapRow['verify_certificate'] === 1 ? 'checked' : '' ?>>
                    Verify Certificate <span style="font-weight:400;color:var(--text-muted);">(turn off only for testing against a self-signed directory -- insecure)</span>
                </label>
            </div>

            <div class="settings-field full">
                <label>User Search Filter</label>
                <input type="text" name="ldap_search_filter" value="<?= h($ldapRow['user_search_filter']) ?>">
                <small><code>%s</code> is replaced with the username the person types in at login.</small>
            </div>

            <div class="settings-field full">
                <label>Default Role for New LDAP Accounts</label>
                <select name="ldap_default_role">
                    <?php foreach ($availableRoleNames as $roleName): ?>
                        <option value="<?= h($roleName) ?>" <?= $ldapRow['default_role'] === $roleName ? 'selected' : '' ?>><?= h($roleName) ?></option>
                    <?php endforeach; ?>
                </select>
                <small>Assigned when a pending LDAP account is created; an Admin can change it when approving in Manage Users.</small>
            </div>

        </div>

        <?php if (!empty($ldapRow['updated_at'])): ?>
            <div class="settings-meta">Last updated <?= h($ldapRow['updated_at']) ?><?= !empty($ldapRow['updated_by']) ? ' by ' . h($ldapRow['updated_by']) : '' ?></div>
        <?php endif; ?>

    </div>

    <button type="submit" class="settings-btn settings-btn-primary">Save LDAP Settings</button>

    </fieldset>

</form>


<div class="settings-panel" style="margin-top:22px;">

    <h2>Test LDAP Connection</h2>
    <p class="panel-subtitle">
        Uses the settings currently saved above (save first if you just changed anything). Verifies the
        service account can bind; optionally also searches for a sample username, without needing that
        person's password.
    </p>

    <form method="POST" action="settings.php" class="settings-test-row">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="form_action" value="test_ldap_connection">

        <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;display:contents;">

        <div class="settings-field">
            <label>Sample Username (optional)</label>
            <input type="text" name="ldap_test_username" placeholder="e.g. jdoe">
        </div>

        <button type="submit" class="settings-btn settings-btn-secondary">Test LDAP Connection</button>

        </fieldset>
    </form>

</div>


<!-- ==========================================================
     SECURITY
     ========================================================== -->

<div class="settings-panel" style="margin-top:22px;">

    <h2>Security</h2>
    <p class="panel-subtitle">
        Session, sign-in and password policy for this installation.
    </p>

    <div class="settings-info-box">
        <strong>Always on, and not configurable here:</strong>
        CSRF verification, server-side authorization on every page, the security response headers
        (<code>X-Frame-Options</code>, <code>X-Content-Type-Options</code>, <code>Referrer-Policy</code>,
        <code>Permissions-Policy</code>), and session cookie hardening
        (<code>HttpOnly</code>, <code>SameSite=Lax</code>, <code>Secure</code> over TLS).
        These are enforced in <code>includes/security.php</code> on every request. They are intentionally not
        switches &mdash; a protection that can be turned off from this form is one that anyone who reaches
        this form can turn off.
    </div>

    <?php if (!empty($securityEnvOverrides)): ?>
        <div class="settings-env-notice">
            <strong>&#9888; Environment overrides active:</strong>
            Controlled by container environment variables and disabled below &mdash;
            <?php foreach ($securityEnvOverrides as $col => $var): ?>
                <code><?= h($var) ?></code><?= $col !== array_key_last($securityEnvOverrides) ? ', ' : '' ?>
            <?php endforeach; ?>.
        </div>
    <?php endif; ?>

    <!-- Transport status: reported, not configured. Whether TLS is available
         is a property of how the container is fronted. -->
    <div class="settings-info-box" style="margin-top:14px;">
        <strong>Transport:</strong>
        This request is <strong><?= $httpsActive ? 'HTTPS' : 'plain HTTP' ?></strong>.
        HTTPS redirect is <strong><?= $httpsForced ? 'enabled' : 'disabled' ?></strong>
        (<code>APP_FORCE_HTTPS=1</code>), proxy header trust is
        <strong><?= $trustedProxy ? 'enabled' : 'disabled' ?></strong> (<code>TRUSTED_PROXY=1</code>).
        <?php if (!$httpsActive): ?>
            <br><span style="color:#B45309;">
                Session cookies cannot be marked <code>Secure</code> and HSTS is not sent over plain HTTP.
                Terminate TLS at a reverse proxy and set both variables for production.
            </span>
        <?php endif; ?>
    </div>

    <form method="POST" action="settings.php" style="margin-top:18px;">

        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="form_action" value="save_security_settings">

        <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;">

        <h3 style="margin:22px 0 4px;font-size:15px;">Session timeout</h3>
        <p class="panel-subtitle">How long a signed-in session stays valid.</p>

        <div class="settings-form-grid">

            <div class="settings-field">
                <label>Idle timeout (minutes)</label>
                <input type="number" name="idle_timeout_minutes" min="1" max="1440"
                    value="<?= (int) $securityRow['idle_timeout_minutes'] ?>"
                    <?= isset($securityEnvOverrides['idle_timeout_minutes']) ? 'disabled' : '' ?>>
                <small>Signed out after this long with no activity.</small>
            </div>

            <div class="settings-field">
                <label>Absolute lifetime (hours)</label>
                <input type="number" name="absolute_timeout_hours" min="0" max="168"
                    value="<?= (int) $securityRow['absolute_timeout_hours'] ?>"
                    <?= isset($securityEnvOverrides['absolute_timeout_hours']) ? 'disabled' : '' ?>>
                <small>Maximum session age regardless of activity. 0 disables.</small>
            </div>

        </div>

        <h3 style="margin:26px 0 4px;font-size:15px;">Sign-in lockout</h3>
        <p class="panel-subtitle">
            Failed attempts are counted per account <em>and</em> source IP address. Counting by account alone
            would let anyone lock a colleague out on purpose; counting by IP alone is defeated by rotating
            addresses.
        </p>

        <label class="settings-checkbox-label" style="margin-bottom:14px;">
            <input type="checkbox" name="lockout_enabled"
                <?= (int) $securityRow['lockout_enabled'] === 1 ? 'checked' : '' ?>
                <?= isset($securityEnvOverrides['lockout_enabled']) ? 'disabled' : '' ?>>
            Lock accounts after repeated failed sign-ins
        </label>

        <div class="settings-form-grid">

            <div class="settings-field">
                <label>Failed attempts before lockout</label>
                <input type="number" name="lockout_threshold" min="1" max="50"
                    value="<?= (int) $securityRow['lockout_threshold'] ?>"
                    <?= isset($securityEnvOverrides['lockout_threshold']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field">
                <label>Counting window (minutes)</label>
                <input type="number" name="lockout_window_minutes" min="1" max="1440"
                    value="<?= (int) $securityRow['lockout_window_minutes'] ?>">
                <small>Only failures within this window count.</small>
            </div>

            <div class="settings-field">
                <label>Lockout duration (minutes)</label>
                <input type="number" name="lockout_duration_minutes" min="1" max="1440"
                    value="<?= (int) $securityRow['lockout_duration_minutes'] ?>">
            </div>

        </div>

        <h3 style="margin:26px 0 4px;font-size:15px;">Password policy</h3>
        <p class="panel-subtitle">
            Applies to local accounts only. Directory (LDAP) accounts are governed by your directory's own
            policy &mdash; their passwords are verified by a live bind and are never stored or evaluated here.
        </p>

        <div class="settings-form-grid">

            <div class="settings-field">
                <label>Minimum length</label>
                <input type="number" name="password_min_length" min="8" max="128"
                    value="<?= (int) $securityRow['password_min_length'] ?>"
                    <?= isset($securityEnvOverrides['password_min_length']) ? 'disabled' : '' ?>>
            </div>

            <div class="settings-field full">
                <label>Required character types</label>

                <label class="settings-checkbox-label">
                    <input type="checkbox" name="password_require_upper"
                        <?= (int) $securityRow['password_require_upper'] === 1 ? 'checked' : '' ?>>
                    Uppercase letter
                </label>

                <label class="settings-checkbox-label">
                    <input type="checkbox" name="password_require_lower"
                        <?= (int) $securityRow['password_require_lower'] === 1 ? 'checked' : '' ?>>
                    Lowercase letter
                </label>

                <label class="settings-checkbox-label">
                    <input type="checkbox" name="password_require_number"
                        <?= (int) $securityRow['password_require_number'] === 1 ? 'checked' : '' ?>>
                    Number
                </label>

                <label class="settings-checkbox-label">
                    <input type="checkbox" name="password_require_symbol"
                        <?= (int) $securityRow['password_require_symbol'] === 1 ? 'checked' : '' ?>>
                    Symbol
                </label>
            </div>

        </div>

        <h3 style="margin:26px 0 4px;font-size:15px;">Content Security Policy</h3>
        <p class="panel-subtitle">
            This application still uses inline scripts and <code>onclick</code> handlers, so the policy must
            currently allow <code>'unsafe-inline'</code> for scripts. Keep it on <strong>Report only</strong>
            and watch the browser console for violations before enforcing.
        </p>

        <div class="settings-form-grid">
            <div class="settings-field">
                <label>Mode</label>
                <select name="csp_mode" <?= isset($securityEnvOverrides['csp_mode']) ? 'disabled' : '' ?>>
                    <?php foreach ([
                        'off'         => 'Off — send no policy',
                        'report-only' => 'Report only — log violations, block nothing (recommended)',
                        'enforce'     => 'Enforce — block violations',
                    ] as $value => $label): ?>
                        <option value="<?= h($value) ?>" <?= $securityRow['csp_mode'] === $value ? 'selected' : '' ?>>
                            <?= h($label) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
        </div>

        <div style="margin-top:24px;">
            <button type="submit" class="settings-btn">Save Security Settings</button>
        </div>

        </fieldset>
    </form>

</div>


<!-- Lockout release: separate form so it cannot be submitted by accident
     along with a settings save. -->
<div class="settings-panel" style="margin-top:22px;">

    <h2>Active Lockouts</h2>
    <p class="panel-subtitle">
        <?php if ($activeLockouts > 0): ?>
            <strong><?= (int) $activeLockouts ?></strong> account<?= $activeLockouts === 1 ? '' : 's' ?>
            currently ha<?= $activeLockouts === 1 ? 's' : 've' ?> recent failed sign-in attempts on record.
            Records older than 24 hours are pruned automatically.
        <?php else: ?>
            No failed sign-in attempts on record.
        <?php endif; ?>
    </p>

    <form method="POST" action="settings.php"
        onsubmit="return confirm('Release all active lockouts and clear failed sign-in history?');">
        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="form_action" value="clear_lockouts">

        <fieldset <?= !$canEditSettings ? 'disabled' : '' ?> style="border:0;padding:0;margin:0;">
            <button type="submit" class="settings-btn settings-btn-secondary">Clear Lockouts</button>
        </fieldset>
    </form>

</div>


</div>


</div>


<?php require_once __DIR__ . '/includes/footer.php'; ?>
