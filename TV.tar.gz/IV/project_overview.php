<?php
/**
 * Project Overview -- every application under one project, side by side,
 * as the same architecture card app_layout.php shows for a single
 * application (see includes/app-layout-helpers.php::alAppCard()).
 *
 * Read-only: this page draws entirely on app_layouts/app_layout_tiers/
 * .../dr_mappings, all owned and edited by app_layout.php and
 * dr_mapping.php. Gated on its own 'project_overview' permission (a
 * viewer can see this dashboard without necessarily being able to view/
 * edit the underlying Application Layout boards themselves, or the other
 * way round) -- registered in permission.php's $pagesToRegister and
 * auto-granted to Admin in config/schema/platform.php, same as
 * oracle_db/dr_mapping.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/app-layout-helpers.php';

requireLogin();
requirePermission('project_overview', 'can_view');

$canViewDr = can('dr_mapping', 'can_view');

$projects = $pdo->query("
    SELECT project, COUNT(*) c
    FROM app_layouts
    WHERE TRIM(project) <> ''
    GROUP BY project
    ORDER BY project
")->fetchAll(PDO::FETCH_ASSOC);

$project = trim((string) ($_GET['project'] ?? ''));
$cards   = [];

if ($project !== '') {
    $cards = alLoadProjectCards($pdo, $project, $canViewDr);
}

/* Stats for the header strip. */
$totalApps  = count($cards);
$owners     = [];
$inCluster  = $standalone = $drCount = 0;

foreach ($cards as $row) {
    $owner = trim((string) ($row['layout']['technical_owner'] ?? ''));
    if ($owner !== '') { $owners[$owner] = true; }

    $deploy = strtolower(trim((string) ($row['layout']['deployment_type'] ?? '')));
    if (str_contains($deploy, 'cluster')) { $inCluster++; }
    elseif (str_contains($deploy, 'standalone')) { $standalone++; }

    if ($row['dr']) { $drCount++; }
}
$owners = array_keys($owners);

$page_title = 'Project Overview | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">
<link rel="stylesheet" href="assets/css/app-layout.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">▦</div>
            <div>
                <h1>Project Overview</h1>
                <p>Every application in a project, side by side, exactly as it's mapped in Application Layout.</p>
            </div>
        </div>
        <div class="plat-actions">
            <a class="plat-btn" href="app_layout.php">Application Layout →</a>
        </div>
    </div>

    <?php if ($project === ''): ?>

        <!-- ============ PROJECT PICKER ============ -->
        <div class="plat-panel">
            <div class="plat-panel-head"><h3>Choose a project</h3></div>
            <div class="plat-panel-body">
                <?php if (!$projects): ?>
                    <p class="plat-empty">No application layouts have a project set yet. Add one from Application Layout.</p>
                <?php else: ?>
                    <div class="al-overview-grid">
                        <?php foreach ($projects as $p): ?>
                            <a class="al-overview-stat" style="text-decoration:none;cursor:pointer;" href="?project=<?= urlencode($p['project']) ?>">
                                <span class="al-stat-icon" aria-hidden="true">▦</span>
                                <span>
                                    <b><?= plat_h($p['project']) ?></b>
                                    <span><?= (int) $p['c'] ?> application<?= (int) $p['c'] === 1 ? '' : 's' ?></span>
                                </span>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>

    <?php else: ?>

        <!-- ============ PROJECT SUMMARY ============ -->
        <div class="plat-panel-head" style="padding:0 0 12px;">
            <h3>Project: <?= plat_h($project) ?></h3>
            <a class="plat-btn plat-btn-light plat-btn-sm" href="project_overview.php">← All projects</a>
        </div>

        <?php if (!$cards): ?>
            <p class="plat-empty">No applications found for this project.</p>
        <?php else: ?>
            <div class="al-overview-stats">
                <div class="al-overview-stat">
                    <span class="al-stat-icon" aria-hidden="true">👥</span>
                    <span><b style="font-size:13px;"><?= plat_h($owners ? implode(', ', array_slice($owners, 0, 3)) . (count($owners) > 3 ? ' +' . (count($owners) - 3) : '') : '—') ?></b><span>Application Owners</span></span>
                </div>
                <div class="al-overview-stat al-tone-blue">
                    <span class="al-stat-icon" aria-hidden="true">▦</span>
                    <span><b><?= $totalApps ?></b><span>Total Applications</span></span>
                </div>
                <div class="al-overview-stat al-tone-green">
                    <span class="al-stat-icon" aria-hidden="true">◎</span>
                    <span><b><?= $inCluster ?></b><span>In Cluster</span></span>
                </div>
                <div class="al-overview-stat al-tone-slate">
                    <span class="al-stat-icon" aria-hidden="true">▭</span>
                    <span><b><?= $standalone ?></b><span>Standalone</span></span>
                </div>
                <?php if ($canViewDr): ?>
                <div class="al-overview-stat al-tone-teal">
                    <span class="al-stat-icon" aria-hidden="true">🛡</span>
                    <span><b><?= $drCount ?></b><span>DR Mapped</span></span>
                </div>
                <?php endif; ?>
            </div>

            <div class="al-overview-grid">
                <?php foreach ($cards as $i => $row): ?>
                    <div>
                        <?= alAppCard($row['layout'], $row['board'], $row['dr'], true, $i + 1) ?>
                        <p style="margin:6px 2px 0;">
                            <a class="plat-btn plat-btn-light plat-btn-sm" href="app_layout.php?view=<?= (int) $row['layout']['id'] ?>">Open full board →</a>
                        </p>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    <?php endif; ?>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
