<?php
session_start();
require 'config/db.php';
require_once 'includes/pagination-helpers.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Normalize role to trim any accidental whitespace
$role = trim($_SESSION['role'] ?? '');
$username = $_SESSION['name'] ?? 'Unknown User';


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
|
| Permissions table:
|
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
| This page's key is 'ownership' (registered in permission.php as
| "Asset Ownership").
|
*/

function ownershipHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'ownership', $permission);
}


$canView   = ownershipHasPermission($pdo, $role, 'can_view');
$canEdit   = ownershipHasPermission($pdo, $role, 'can_edit');
$canDelete = ownershipHasPermission($pdo, $role, 'can_delete');
$canExport = ownershipHasPermission($pdo, $role, 'can_export');
$canImport = ownershipHasPermission($pdo, $role, 'can_import');
$canAudit  = ownershipHasPermission($pdo, $role, 'can_audit');

/*
| The view modal's "Linked Servers" tab reads from the inventory
| module, so it is gated on that module's own view permission rather
| than on 'ownership' -- otherwise this page would leak inventory
| data to roles that are not allowed to see it.
*/
$canViewInventory = authzCan($pdo, $role, 'inventory', 'can_view');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
|
| Must happen before any header/sidebar output or AJAX handler below.
| Previously this page had NO view check at all -- any logged-in user
| could load it regardless of their role's can_view setting.
|
*/

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}


$msg = "";
$error = "";

/*
| Canonical list of support levels, used to validate/order the
| multi-select on create/edit (an ownership record can now cover
| several levels for the same project -- see support_level handling
| in the 'save' action below) and to populate every support-level
| dropdown/checkbox group on this page.
*/
$support_levels = ['Production', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox', 'DR', 'POC', 'Management'];

// Splits the comma-joined support_level column back into its
// individual level names, trimmed and with blanks dropped.
function ownershipSupportLevelList($raw) {
    $parts = explode(',', (string)$raw);
    $parts = array_map('trim', $parts);
    return array_values(array_filter($parts, function ($v) { return $v !== ''; }));
}

// 1. Handle Export CSV Action
if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export ownership records.');
    }

    // Apply search/filter filters to export only filtered rows
    $where_clauses = ["1=1"];
    $export_params = [];

    $export_keyword = trim($_GET['keyword'] ?? '');
    $export_s_project = trim($_GET['s_project'] ?? '');
    $export_s_support = trim($_GET['s_support'] ?? '');
    $export_s_owner = trim($_GET['s_owner'] ?? '');
    $export_s_manager = trim($_GET['s_manager'] ?? '');

    if (!empty($export_keyword)) {
        $where_clauses[] = "(project LIKE ? OR technical_owner LIKE ? OR ncgr_owner LIKE ? OR team_dl LIKE ?)";
        $export_params[] = "%$export_keyword%";
        $export_params[] = "%$export_keyword%";
        $export_params[] = "%$export_keyword%";
        $export_params[] = "%$export_keyword%";
    }

    if (!empty($export_s_project)) {
        $where_clauses[] = "project LIKE ?";
        $export_params[] = "%$export_s_project%";
    }
    if (!empty($export_s_support)) {
        // Contains-match: support_level may now hold a comma-joined
        // list of levels for one owner (e.g. "Production,DR").
        $where_clauses[] = "(',' || support_level || ',') LIKE ?";
        $export_params[] = '%,' . $export_s_support . ',%';
    }
    if (!empty($export_s_owner)) {
        $where_clauses[] = "technical_owner LIKE ?";
        $export_params[] = "%$export_s_owner%";
    }
    if (!empty($export_s_manager)) {
        $where_clauses[] = "technical_manager LIKE ?";
        $export_params[] = "%$export_s_manager%";
    }

    $export_where_sql = implode(" AND ", $where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=ownership_export_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['Project', 'Support Level', 'Technical Owner', 'Technical Owner Email', 'Team DL', 'Technical Manager', 'Technical Manager Email', 'SDM Name', 'SDM Email', 'NCGR Owner', 'NCGR Owner Email', 'Created By', 'Created At']);

    $export_stmt = $pdo->prepare("SELECT project, support_level, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, created_by, created_at FROM ownership WHERE $export_where_sql ORDER BY id DESC");
    $export_stmt->execute($export_params);
    $rows = $export_stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// 2. Handle Global + Per-Record History AJAX Call
if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
        exit;
    }

    /*
    | ?id=<ownership.id> scopes this to just that one record (the
    | per-row "History" button). No id = the full module log (the
    | toolbar's "Audit History" button).
    */
    $historyId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    if ($historyId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM ownership_history WHERE ownership_id = ? ORDER BY timestamp DESC");
        $stmt->execute([$historyId]);
    } else {
        $stmt = $pdo->query("SELECT * FROM ownership_history ORDER BY timestamp DESC");
    }

    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table class="audit-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $badge_color = 'background:var(--border-color);color:var(--text-primary);';
            if ($log['action_type'] === 'CREATED') $badge_color = 'background:#dcfce7;color:#166534;';
            if ($log['action_type'] === 'DELETED') $badge_color = 'background:#fee2e2;color:#991b1b;';
            if ($log['action_type'] === 'UPDATED') $badge_color = 'background:#fef9c3;color:#854d0e;';
            if ($log['action_type'] === 'BULK IMPORT') $badge_color = 'background:#dbeafe;color:#1e40af;';

            echo '<tr>';
            echo '<td><span class="audit-badge" style="' . $badge_color . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td class="audit-details">' . nl2br(htmlspecialchars($log['details'])) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">' . ($historyId > 0 ? 'No history found for this record.' : 'No audit history records found.') . '</p>';
    }
    exit;
}


/*
|--------------------------------------------------------------------------
| LINKED SERVERS AJAX CALL
|--------------------------------------------------------------------------
|
| Backs the "Linked Servers" tab of the view modal: every inventory
| host whose project AND support level match this ownership record.
| Comparison is case/whitespace-insensitive on both sides because the
| two modules are populated independently (manual entry on one side,
| CSV import on the other) and "ESB " / "esb" would otherwise miss.
|
| Returns JSON so the tab label can carry the count without a second
| round trip.
|
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_servers') {

    header('Content-Type: application/json; charset=utf-8');

    if (!$canViewInventory) {
        http_response_code(403);
        echo json_encode([
            'ok'    => false,
            'count' => 0,
            'html'  => '<p class="empty-state">You do not have permission to view inventory records.</p>',
        ]);
        exit;
    }

    $ownershipId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    $ownStmt = $pdo->prepare("SELECT project, support_level FROM ownership WHERE id = ?");
    $ownStmt->execute([$ownershipId]);
    $ownRow = $ownStmt->fetch(PDO::FETCH_ASSOC);

    if (!$ownRow) {
        http_response_code(404);
        echo json_encode([
            'ok'    => false,
            'count' => 0,
            'html'  => '<p class="empty-state">Ownership record not found.</p>',
        ]);
        exit;
    }

    // An ownership record can now list several support levels
    // (see the save-action comment above) -- a linked server just
    // needs to match ANY of them, not all.
    $ownLevels = ownershipSupportLevelList($ownRow['support_level']);
    $levelPlaceholders = implode(',', array_fill(0, max(count($ownLevels), 1), "LOWER(TRIM(?))"));

    $serverStmt = $pdo->prepare("
        SELECT hostname, ip_address, os_family, os_version, server_state,
               application, criticality, location
        FROM inventory
        WHERE LOWER(TRIM(COALESCE(project, ''))) = LOWER(TRIM(?))
          AND LOWER(TRIM(COALESCE(support_level, ''))) IN ($levelPlaceholders)
        ORDER BY hostname COLLATE NOCASE
    ");
    $serverStmt->execute(array_merge([$ownRow['project']], $ownLevels !== [] ? $ownLevels : ['']));
    $servers = $serverStmt->fetchAll(PDO::FETCH_ASSOC);

    ob_start();

    if (count($servers) > 0) {

        echo '<div class="linked-summary">';
        echo '<strong>' . count($servers) . '</strong> ' . (count($servers) === 1 ? 'server' : 'servers');
        echo ' in <span class="linked-chip">' . htmlspecialchars($ownRow['project']) . '</span>';
        echo ' &middot; ';
        foreach ($ownLevels as $lvl) {
            echo '<span class="linked-chip">' . htmlspecialchars($lvl) . '</span> ';
        }
        echo '</div>';

        echo '<div class="table-wrap linked-table-wrap">';
        echo '<table class="data-table">';
        echo '<thead><tr>';
        echo '<th>Hostname</th><th>IP Address</th><th>OS</th><th>State</th><th>Application</th><th>Criticality</th><th>Location</th>';
        echo '</tr></thead><tbody>';

        foreach ($servers as $s) {

            $osLabel = trim(($s['os_family'] ?? '') . ' ' . ($s['os_version'] ?? ''));

            $stateRaw = strtolower(trim((string)($s['server_state'] ?? '')));
            $stateClass = 'state-unknown';
            if ($stateRaw === 'powered on')        $stateClass = 'state-on';
            elseif ($stateRaw === 'powered off')   $stateClass = 'state-off';
            elseif ($stateRaw === 'decommissioned') $stateClass = 'state-decomm';
            elseif ($stateRaw === 'to be decomm')  $stateClass = 'state-pending';

            echo '<tr>';
            echo '<td><a class="linked-host" href="inventory.php?keyword=' . urlencode($s['hostname']) . '">' . htmlspecialchars($s['hostname']) . '</a></td>';
            echo '<td>' . htmlspecialchars($s['ip_address'] ?? '') . '</td>';
            echo '<td>' . htmlspecialchars($osLabel !== '' ? $osLabel : '—') . '</td>';
            echo '<td><span class="state-pill ' . $stateClass . '">' . htmlspecialchars($s['server_state'] ?? '') . '</span></td>';
            echo '<td>' . htmlspecialchars($s['application'] ?? '') . '</td>';
            echo '<td>' . htmlspecialchars($s['criticality'] ?? '') . '</td>';
            echo '<td>' . htmlspecialchars($s['location'] ?? '') . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table></div>';

    } else {
        echo '<p class="empty-state">No inventory hostnames are recorded for <strong>'
            . htmlspecialchars($ownRow['project'] ?? '') . '</strong> at support level(s) <strong>'
            . htmlspecialchars(implode(', ', $ownLevels)) . '</strong>.</p>';
    }

    echo json_encode([
        'ok'    => true,
        'count' => count($servers),
        'html'  => ob_get_clean(),
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| COLUMN DEFINITIONS
|--------------------------------------------------------------------------
|
| Single source of truth for every toggleable column -- drives the
| table header, the row cells, and the column-picker checkboxes, so a
| field can't quietly go missing from one of the three.
|
*/

$ownership_columns = [
    'project'                  => 'Project',
    'support_level'            => 'Support Level',
    'technical_owner'          => 'Technical Owner',
    'team_dl'                  => 'Team DL',
    'technical_manager'        => 'Technical Manager',
    'technical_manager_email'  => 'Technical Manager Email',
    'sdm_name'                 => 'SDM',
    'sdm_email'                => 'SDM Email',
    'ncgr_owner'               => 'NCGR Owner',
    'ncgr_owner_email'         => 'NCGR Owner Email',
    'created_by'               => 'Created By',
];

$default_visible_columns = [
    'project',
    'support_level',
    'technical_owner',
    'team_dl',
    'technical_manager',
    'sdm_name',
    'ncgr_owner',
];


/*
|--------------------------------------------------------------------------
| PER-USER COLUMN PREFERENCES (persisted server-side)
|--------------------------------------------------------------------------
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS ownership_column_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        column_key TEXT NOT NULL,
        is_visible INTEGER NOT NULL DEFAULT 1,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, column_key)
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize ownership_column_preferences: ' . $e->getMessage());
}

/*
| Same defensive migration as ip_column_preferences: if a table with
| this name already exists with a different/incompatible schema (an
| unexpected NOT NULL column with no default), rebuild it cleanly
| rather than trying to patch around an unknown legacy shape. This
| table only caches display preferences, nothing worth preserving.
*/
try {
    $ownColPrefsExisting = [];
    $ownColPrefsIncompatible = false;

    $ownColPrefsInfo = $pdo->query("PRAGMA table_info(ownership_column_preferences)")->fetchAll(PDO::FETCH_ASSOC);

    $ownColPrefsKnown = ['id', 'user_id', 'column_key', 'is_visible', 'updated_at'];

    foreach ($ownColPrefsInfo as $col) {
        $ownColPrefsExisting[] = $col['name'];

        $isUnknownColumn = !in_array($col['name'], $ownColPrefsKnown, true);
        $isNotNullNoDefault = ((int)($col['notnull'] ?? 0) === 1) && ($col['dflt_value'] === null);

        if ($isUnknownColumn && $isNotNullNoDefault) {
            $ownColPrefsIncompatible = true;
        }
    }

    if ($ownColPrefsIncompatible) {

        $pdo->exec("DROP TABLE IF EXISTS ownership_column_preferences");

        $pdo->exec("CREATE TABLE ownership_column_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            column_key TEXT NOT NULL,
            is_visible INTEGER NOT NULL DEFAULT 1,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, column_key)
        )");

    } else {

        $ownColPrefsRequired = [
            'user_id'    => "INTEGER NOT NULL DEFAULT 0",
            'column_key' => "TEXT NOT NULL DEFAULT ''",
            'is_visible' => "INTEGER NOT NULL DEFAULT 1",
            'updated_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
        ];

        foreach ($ownColPrefsRequired as $colName => $definition) {
            if (!in_array($colName, $ownColPrefsExisting, true)) {
                $pdo->exec("ALTER TABLE ownership_column_preferences ADD COLUMN {$colName} {$definition}");
            }
        }
    }
} catch (Throwable $e) {
    error_log('Unable to migrate ownership_column_preferences: ' . $e->getMessage());
}


$visible_columns = $default_visible_columns;
$user_id = (int)($_SESSION['user_id'] ?? 0);

if ($user_id > 0) {
    try {
        $prefStmt = $pdo->prepare("
            SELECT column_key
            FROM ownership_column_preferences
            WHERE user_id = ? AND is_visible = 1
            ORDER BY column_key
        ");
        $prefStmt->execute([$user_id]);
        $savedColumns = $prefStmt->fetchAll(PDO::FETCH_COLUMN);

        if (is_array($savedColumns) && count($savedColumns) > 0) {
            $visible_columns = array_values(array_intersect(
                array_keys($ownership_columns),
                array_map('strval', $savedColumns)
            ));
            if (count($visible_columns) === 0) {
                $visible_columns = $default_visible_columns;
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to load ownership_column_preferences: ' . $e->getMessage());
    }
}


/*
|--------------------------------------------------------------------------
| SAVE COLUMN PREFERENCES (AJAX)
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['form_action'] ?? '') === 'save_columns')) {

    header('Content-Type: application/json; charset=utf-8');

    try {
        if ($user_id <= 0) {
            throw new Exception('Invalid user session.');
        }

        $requested = json_decode($_POST['visible_columns'] ?? '[]', true);
        if (!is_array($requested)) {
            $requested = [];
        }

        $requested = array_values(array_unique(array_intersect(
            array_keys($ownership_columns),
            array_map('strval', $requested)
        )));

        if (count($requested) === 0) {
            throw new Exception('Select at least one column.');
        }

        $pdo->beginTransaction();

        $pdo->prepare("DELETE FROM ownership_column_preferences WHERE user_id = ?")
            ->execute([$user_id]);

        $insertStmt = $pdo->prepare("
            INSERT INTO ownership_column_preferences (user_id, column_key, is_visible, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ");

        foreach (array_keys($ownership_columns) as $columnKey) {
            $insertStmt->execute([
                $user_id,
                $columnKey,
                in_array($columnKey, $requested, true) ? 1 : 0
            ]);
        }

        $pdo->commit();

        echo json_encode(['ok' => true, 'message' => 'Column layout saved.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Saving ownership_column_preferences failed: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Unable to save column layout: ' . $e->getMessage()]);
    }

    exit;
}


// 3. Handle Form Submissions (Create, Update, Delete, Bulk Upload)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    // Create or Update Record
    if ($action_type === 'save') {

        if (!$canEdit) {
            http_response_code(403);
            $error = "You do not have permission to create or edit ownership records.";
        } else {

            $id = $_POST['id'] ?? '';
            $project = trim($_POST['project']);

            // Multi-select: one owner can now cover several support
            // levels (e.g. Production + DR) instead of needing a
            // duplicate row per level. Stored as a comma-joined list,
            // restricted and ordered to the canonical $support_levels
            // set so it stays predictable for the contains-match
            // filters/lookups elsewhere.
            $support_level_input = $_POST['support_level'] ?? [];
            if (!is_array($support_level_input)) {
                $support_level_input = [$support_level_input];
            }
            $support_level_selected = [];
            foreach ($support_levels as $lvl) {
                if (in_array($lvl, $support_level_input, true)) {
                    $support_level_selected[] = $lvl;
                }
            }
            $support_level = implode(',', $support_level_selected);

            $technical_owner = trim($_POST['technical_owner']);
            $technical_owner_email = trim($_POST['technical_owner_email']);
            $team_dl = trim($_POST['team_dl']);
            $technical_manager = trim($_POST['technical_manager']);
            $technical_manager_email = trim($_POST['technical_manager_email']);
            $sdm_name = trim($_POST['sdm_name']);
            $sdm_email = trim($_POST['sdm_email']);
            $ncgr_owner = trim($_POST['ncgr_owner']);
            $ncgr_owner_email = trim($_POST['ncgr_owner_email']);

            if (empty($project) || empty($support_level)) {
                $error = "Project and at least one Support Level are required.";
            } else {

                // A given support level can only belong to ONE
                // ownership record per project -- otherwise
                // inventory's lookupOwnershipDetails() (matched on
                // project + support_level) would have two candidate
                // owners to choose between. Checked against every
                // OTHER row for this project (excluding the row being
                // updated, if any).
                $conflictStmt = $pdo->prepare(
                    "SELECT support_level FROM ownership WHERE project = ?" . (!empty($id) ? " AND id != ?" : "")
                );
                $conflictParams = [$project];
                if (!empty($id)) $conflictParams[] = $id;
                $conflictStmt->execute($conflictParams);

                $conflictingLevels = [];
                foreach ($conflictStmt->fetchAll(PDO::FETCH_COLUMN) as $existingLevelsRaw) {
                    $conflictingLevels = array_merge(
                        $conflictingLevels,
                        array_intersect($support_level_selected, ownershipSupportLevelList($existingLevelsRaw))
                    );
                }
                $conflictingLevels = array_unique($conflictingLevels);

                if (!empty($conflictingLevels)) {
                    $error = "\"" . $project . "\" already has an ownership record covering: "
                        . implode(', ', $conflictingLevels)
                        . ". Edit that record instead, or remove the overlapping level(s) here.";
                } elseif (empty($id)) {
                    // Insert
                    $stmt = $pdo->prepare("INSERT INTO ownership (project, support_level, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$project, $support_level, $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, $username]);
                    $new_id = $pdo->lastInsertId();

                    // Audit History
                    $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                    $h_stmt->execute([$new_id, $username, "Created project: $project"]);
                    $msg = "Ownership entry created successfully.";
                } else {

                    // Capture the pre-update row so the audit log can show
                    // exactly which fields changed and their old -> new values.
                    $oldStmt = $pdo->prepare("SELECT * FROM ownership WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $oldRecord = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    // Update
                    $stmt = $pdo->prepare("UPDATE ownership SET project=?, support_level=?, technical_owner=?, technical_owner_email=?, team_dl=?, technical_manager=?, technical_manager_email=?, sdm_name=?, sdm_email=?, ncgr_owner=?, ncgr_owner_email=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                    $stmt->execute([$project, $support_level, $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, $username, $id]);

                    // Field-level diff so the per-row history shows what
                    // actually changed, not just "record updated".
                    $newValuesByColumn = [
                        'project'                 => $project,
                        'support_level'           => $support_level,
                        'technical_owner'         => $technical_owner,
                        'technical_owner_email'   => $technical_owner_email,
                        'team_dl'                 => $team_dl,
                        'technical_manager'       => $technical_manager,
                        'technical_manager_email' => $technical_manager_email,
                        'sdm_name'                => $sdm_name,
                        'sdm_email'               => $sdm_email,
                        'ncgr_owner'              => $ncgr_owner,
                        'ncgr_owner_email'        => $ncgr_owner_email,
                    ];

                    $ownershipFieldLabels = [
                        'project'                 => 'Project',
                        'support_level'           => 'Support Level',
                        'technical_owner'         => 'Technical Owner',
                        'technical_owner_email'   => 'Technical Owner Email',
                        'team_dl'                 => 'Team DL',
                        'technical_manager'       => 'Technical Manager',
                        'technical_manager_email' => 'Technical Manager Email',
                        'sdm_name'                => 'SDM Name',
                        'sdm_email'               => 'SDM Email',
                        'ncgr_owner'              => 'NCGR Owner',
                        'ncgr_owner_email'        => 'NCGR Owner Email',
                    ];

                    $changedFields = [];
                    foreach ($newValuesByColumn as $columnKey => $newVal) {
                        $oldValStr = trim((string)($oldRecord[$columnKey] ?? ''));
                        $newValStr = trim((string)$newVal);
                        if ($oldValStr !== $newValStr) {
                            $fieldLabel = $ownershipFieldLabels[$columnKey] ?? $columnKey;
                            $oldDisplay = $oldValStr === '' ? '(empty)' : $oldValStr;
                            $newDisplay = $newValStr === '' ? '(empty)' : $newValStr;
                            $changedFields[] = "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                        }
                    }

                    $detail_msg = "Updated project: $project\n";
                    $detail_msg .= (count($changedFields) > 0)
                        ? implode("\n", $changedFields)
                        : "No field value changes detected.";

                    // Audit History
                    $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                    $h_stmt->execute([$id, $username, $detail_msg]);
                    $msg = "Ownership entry updated successfully.";
                }
            }
        }
    }

    // Delete Record
    if ($action_type === 'delete') {

        if (!$canDelete) {
            http_response_code(403);
            $error = "You do not have permission to delete ownership records.";
        } else {
            $id = $_POST['id'];

            // Fetch project name for audit logs before deleting
            $p_stmt = $pdo->prepare("SELECT project FROM ownership WHERE id = ?");
            $p_stmt->execute([$id]);
            $proj_row = $p_stmt->fetch(PDO::FETCH_ASSOC);
            $proj_name = $proj_row ? $proj_row['project'] : 'Unknown';

            $stmt = $pdo->prepare("DELETE FROM ownership WHERE id = ?");
            $stmt->execute([$id]);

            $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
            $h_stmt->execute([$id, $username, "Deleted project: $proj_name"]);
            $msg = "Ownership entry deleted successfully.";
        }
    }

    // Excel CSV Bulk Upload
    if ($action_type === 'upload_csv') {

        if (!$canImport) {
            http_response_code(403);
            $error = "You do not have permission to import ownership records.";
        } else {
            if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
                $file_tmp = $_FILES['csv_file']['tmp_name'];
                if (($handle = fopen($file_tmp, 'r')) !== FALSE) {
                    fgetcsv($handle); // Skip header
                    $count = 0;
                    while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                        if (count($data) >= 12) {
                            $csv_project = trim($data[1] ?? '');
                            if ($csv_project === '') {
                                continue;
                            }

                            /*
                            | REPLACE EXISTING OWNERSHIP ENTRY (MATCHED BY PROJECT)
                            |
                            | Project is already this page's identity for an ownership
                            | record -- it's what searches, edit, and delete key off of --
                            | so a re-upload of the same project overwrites it instead of
                            | creating a duplicate row.
                            */
                            $existing_stmt = $pdo->prepare("SELECT id FROM ownership WHERE project = ?");
                            $existing_stmt->execute([$csv_project]);
                            $existing_id = $existing_stmt->fetchColumn();

                            $ownership_values = [$csv_project, $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8], $data[9], $data[10], $data[11] ?? ''];

                            if ($existing_id) {
                                $stmt = $pdo->prepare("
                                    UPDATE ownership SET
                                        project = ?, support_level = ?, technical_owner = ?, technical_owner_email = ?,
                                        team_dl = ?, technical_manager = ?, technical_manager_email = ?,
                                        sdm_name = ?, sdm_email = ?, ncgr_owner = ?, ncgr_owner_email = ?,
                                        updated_by = ?, updated_at = CURRENT_TIMESTAMP
                                    WHERE id = ?
                                ");
                                $stmt->execute(array_merge($ownership_values, [$username, $existing_id]));

                                $new_id = $existing_id;
                                $history_details = "Replaced via CSV bulk upload";
                            } else {
                                $stmt = $pdo->prepare("INSERT INTO ownership (project, support_level, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                                $stmt->execute(array_merge($ownership_values, [$username]));

                                $new_id = $pdo->lastInsertId();
                                $history_details = "Imported via CSV bulk upload";
                            }

                            $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'BULK IMPORT', ?, ?)");
                            $h_stmt->execute([$new_id, $username, $history_details]);
                            $count++;
                        }
                    }
                    fclose($handle);
                    $msg = "Successfully imported $count records from CSV.";
                } else {
                    $error = "Failed to read uploaded CSV file.";
                }
            } else {
                $error = "Please upload a valid CSV file.";
            }
        }
    }
}

// 4. Pagination & Advanced Search Filtering setup
$limit = resolveUserPageSize($pdo, $user_id);
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $limit) - $limit : 0;

$keyword = trim($_GET['keyword'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_support = trim($_GET['s_support'] ?? '');
$s_owner = trim($_GET['s_owner'] ?? '');
$s_manager = trim($_GET['s_manager'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(project LIKE ? OR technical_owner LIKE ? OR ncgr_owner LIKE ? OR team_dl LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if (!empty($s_project)) {
    $where_clauses[] = "project LIKE ?";
    $params[] = "%$s_project%";
}
if (!empty($s_support)) {
    // Contains-match: support_level may now hold a comma-joined
    // list of levels for one owner (e.g. "Production,DR").
    $where_clauses[] = "(',' || support_level || ',') LIKE ?";
    $params[] = '%,' . $s_support . ',%';
}
if (!empty($s_owner)) {
    $where_clauses[] = "technical_owner LIKE ?";
    $params[] = "%$s_owner%";
}
if (!empty($s_manager)) {
    $where_clauses[] = "technical_manager LIKE ?";
    $params[] = "%$s_manager%";
}

$where_sql = implode(" AND ", $where_clauses);

// Count total records for pagination
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM ownership WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Fetch paginated data
$data_stmt = $pdo->prepare("SELECT * FROM ownership WHERE $where_sql ORDER BY id DESC LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hidden fields so the page-size selector preserves the current
// search/filter state instead of resetting it.
$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_project' => $s_project,
    's_support' => $s_support,
    's_owner' => $s_owner,
    's_manager' => $s_manager,
] as $fk => $fv) {
    if ($fv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
    }
}

// Helper: initials for the owner avatar
function ownerInitials($name) {
    $name = trim($name);
    if ($name === '') return '?';
    $parts = preg_split('/\s+/', $name);
    $initials = strtoupper(substr($parts[0], 0, 1));
    if (count($parts) > 1) {
        $initials .= strtoupper(substr(end($parts), 0, 1));
    }
    return $initials;
}

// Used by includes/header.php for the <title> tag
$page_title = "Ownership Registry | InfraVault";

require 'includes/header.php';
?>
<link rel="stylesheet" href="assets/css/ownership.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Ownership Registry</h1>
            <p>Technical, managerial and NCGR ownership contacts for every ITAM project.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="btn btn-primary" onclick="openCreateModal()">+ Add New Ownership</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a href="ownership.php?action=export&keyword=<?php echo urlencode($keyword); ?>&s_project=<?php echo urlencode($s_project); ?>&s_support=<?php echo urlencode($s_support); ?>&s_owner=<?php echo urlencode($s_owner); ?>&s_manager=<?php echo urlencode($s_manager); ?>" class="btn btn-secondary">Export</a>
            <?php endif; ?>
            <?php if ($canImport): ?>
                <button type="button" class="btn btn-secondary" onclick="openUploadModal()">Import CSV</button>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="btn btn-secondary" onclick="openHistoryModal()">History</button>
            <?php endif; ?>
            <button type="button" class="btn btn-secondary" onclick="openColumnsModal()">Columns</button>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header" style="margin-bottom:14px;">
            <h3 class="panel-title" style="margin:0;">Search &amp; Filters</h3>
            <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">Advanced &#9662;</span>
        </div>

        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">
            <form method="GET" action="ownership.php" style="display:flex;gap:10px;flex-wrap:wrap;">
                <input type="text" name="keyword" class="form-control" style="max-width:320px;" placeholder="Search project, owner, team DL..." value="<?php echo htmlspecialchars($keyword); ?>" data-live-search="500">
                <button type="submit" class="btn btn-primary">Search</button>
                <button type="button" class="btn" data-live-search-toggle onclick="toggleLiveSearch()" title="Toggle searching automatically as you type"></button>
                <?php if (!empty($keyword) || !empty($s_project) || !empty($s_support) || !empty($s_owner) || !empty($s_manager)): ?>
                    <a href="ownership.php" class="btn">Clear</a>
                <?php endif; ?>
            </form>

            <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
        </div>

        <div id="advancedSearchPanel" style="display:<?php echo (!empty($s_project) || !empty($s_support) || !empty($s_owner) || !empty($s_manager)) ? 'block' : 'none'; ?>; margin-top:18px; padding-top:18px; border-top:1px solid #F1F5F9;">
            <form method="GET" action="ownership.php" class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
                <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" name="s_project" class="form-control" value="<?php echo htmlspecialchars($s_project); ?>">
                </div>
                <div class="form-group">
                    <label>Support Level</label>
                    <select name="s_support" class="form-control">
                        <option value="">All Levels</option>
                        <?php foreach ($support_levels as $lvl): ?>
                            <option value="<?php echo $lvl; ?>" <?php if ($s_support == $lvl) echo 'selected'; ?>><?php echo $lvl; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Technical Owner</label>
                    <input type="text" name="s_owner" class="form-control" value="<?php echo htmlspecialchars($s_owner); ?>">
                </div>
                <div class="form-group">
                    <label>Technical Manager</label>
                    <input type="text" name="s_manager" class="form-control" value="<?php echo htmlspecialchars($s_manager); ?>">
                </div>
                <div style="grid-column:1/-1; display:flex; gap:10px;">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="ownership.php" class="btn">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <h3 class="panel-title" style="margin:0;">Ownership Records</h3>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <?php foreach ($ownership_columns as $col_key => $col_label): ?>
                            <th class="col-th-<?php echo htmlspecialchars($col_key); ?> <?php echo in_array($col_key, $visible_columns, true) ? '' : 'hidden-col'; ?>"><?php echo htmlspecialchars($col_label); ?></th>
                        <?php endforeach; ?>
                        <th class="col-actions">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                            <tr>
                                <?php foreach ($ownership_columns as $col_key => $col_label): ?>
                                    <td class="col-td-<?php echo htmlspecialchars($col_key); ?> <?php echo in_array($col_key, $visible_columns, true) ? '' : 'hidden-col'; ?>">
                                        <?php if ($col_key === 'project'): ?>
                                            <span class="cell-primary"><?php echo htmlspecialchars($r['project']); ?></span>
                                        <?php elseif ($col_key === 'support_level'): ?>
                                            <div class="badge-group">
                                            <?php foreach (ownershipSupportLevelList($r['support_level']) as $lvl): ?>
                                                <?php $badgeClass = 'badge-' . str_replace(' ', '-', $lvl); ?>
                                                <span class="badge <?php echo htmlspecialchars($badgeClass); ?>"><span class="badge-dot"></span><?php echo htmlspecialchars($lvl); ?></span>
                                            <?php endforeach; ?>
                                            </div>
                                        <?php elseif ($col_key === 'technical_owner'): ?>
                                            <div class="owner-cell">
                                                <div class="owner-avatar"><?php echo ownerInitials($r['technical_owner']); ?></div>
                                                <div>
                                                    <?php echo htmlspecialchars($r['technical_owner']); ?>
                                                    <span class="cell-sub"><?php echo htmlspecialchars($r['technical_owner_email']); ?></span>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <?php echo htmlspecialchars($r[$col_key] ?? ''); ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                                <td style="text-align: center;">
                                    <div class="row-actions">
                                        <button type="button" class="action-icon action-view" title="View" onclick='viewOwnership(<?php echo htmlspecialchars(json_encode($r), ENT_QUOTES, 'UTF-8'); ?>)'>👁</button>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="action-icon action-edit" title="Edit" onclick='openEditModal(<?php echo json_encode($r); ?>)'>✎</button>
                                            <button type="button" class="action-icon action-clone" title="Clone into a new entry" onclick='cloneOwnership(<?php echo json_encode($r); ?>)'>⧉</button>
                                        <?php endif; ?>
                                        <?php if ($canAudit): ?>
                                            <button type="button" class="action-icon action-history" title="History" onclick="openHistoryModal(<?php echo (int)$r['id']; ?>)">⏱</button>
                                        <?php endif; ?>
                                        <?php if ($canDelete): ?>
                                            <button type="button" class="action-icon action-delete" title="Delete" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['project'])); ?>')">🗑</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="<?php echo count($ownership_columns) + 1; ?>"><p class="empty-state">No ownership records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= ivPager($page, $total_pages, [
            'keyword'   => $keyword,
            's_project' => $s_project,
            's_support' => $s_support,
        ], ['base' => 'ownership.php', 'total_records' => $total_records ?? null, 'per_page' => $limit ?? null]) ?>
    </div>

</div>

<!-- CREATE / UPDATE MODAL -->
<div id="recordModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add Ownership Entry</h3>
            <button type="button" class="close-modal" onclick="closeModal('recordModal')">&times;</button>
        </div>
        <form method="POST" action="ownership.php" id="recordForm">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="rec_id">

            <div class="form-grid">
                <div class="form-group">
                    <label>Project Name *</label>
                    <input type="text" name="project" id="rec_project" class="form-control" required>
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label>Support Level(s) *</label>
                    <div class="support-level-checks" id="rec_support_level_group">
                        <?php foreach ($support_levels as $lvl): ?>
                            <label class="support-level-check">
                                <input type="checkbox" name="support_level[]" value="<?php echo htmlspecialchars($lvl); ?>">
                                <span><?php echo htmlspecialchars($lvl); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <span class="support-level-hint" id="supportLevelError" style="display:none;">Select at least one support level.</span>
                </div>
                <div class="form-group">
                    <label>Technical Owner</label>
                    <input type="text" name="technical_owner" id="rec_technical_owner" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Owner Email</label>
                    <input type="email" name="technical_owner_email" id="rec_technical_owner_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>Team DL</label>
                    <input type="text" name="team_dl" id="rec_team_dl" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Manager</label>
                    <input type="text" name="technical_manager" id="rec_technical_manager" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Manager Email</label>
                    <input type="email" name="technical_manager_email" id="rec_technical_manager_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>SDM Name</label>
                    <input type="text" name="sdm_name" id="rec_sdm_name" class="form-control">
                </div>
                <div class="form-group">
                    <label>SDM Email</label>
                    <input type="email" name="sdm_email" id="rec_sdm_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>NCGR Owner</label>
                    <input type="text" name="ncgr_owner" id="rec_ncgr_owner" class="form-control">
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label>NCGR Owner Email</label>
                    <input type="email" name="ncgr_owner_email" id="rec_ncgr_owner_email" class="form-control">
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('recordModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Record</button>
            </div>
        </form>
    </div>
</div>

<!-- VIEW MODAL -->
<div id="viewModal" class="modal-overlay">
    <div class="modal-content view-modal">
        <div class="modal-header">
            <div class="modal-heading">
                <h3>Ownership Details</h3>
                <p class="modal-subtitle" id="viewSubtitle"></p>
            </div>
            <button type="button" class="close-modal" onclick="closeModal('viewModal')">&times;</button>
        </div>

        <div class="modal-tabs" role="tablist">
            <button type="button" class="modal-tab is-active" id="viewTabBtn-details" role="tab" onclick="switchViewTab('details')">Details</button>
            <?php if ($canViewInventory): ?>
                <button type="button" class="modal-tab" id="viewTabBtn-servers" role="tab" onclick="switchViewTab('servers')">
                    Linked Servers <span class="tab-count" id="serverCount">0</span>
                </button>
            <?php endif; ?>
        </div>

        <div class="modal-tab-panel is-active" id="viewTabPanel-details">
            <div id="viewContent" class="details-grid"></div>
            <div class="detail-meta" id="viewMeta"></div>
        </div>

        <?php if ($canViewInventory): ?>
            <div class="modal-tab-panel" id="viewTabPanel-servers">
                <div id="serversContent"><p class="empty-state">Loading linked servers...</p></div>
            </div>
        <?php endif; ?>

        <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="closeModal('viewModal')">Close</button>
        </div>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content" style="max-width:400px; text-align:center;">
        <div class="modal-header">
            <h3>Confirm Deletion</h3>
            <button type="button" class="close-modal" onclick="closeModal('deleteModal')">&times;</button>
        </div>
        <p style="margin:1rem 0; color:#64748B;">Are you sure you want to delete project: <strong id="del_project_name"></strong>?</p>
        <form method="POST" action="ownership.php">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="del_id">
            <div class="modal-footer" style="justify-content:center;">
                <button type="button" class="btn" onclick="closeModal('deleteModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- HISTORY MODAL (global + per-record, same modal) -->
<div id="globalHistoryModal" class="modal-overlay">
    <div class="modal-content" style="max-width:800px;">
        <div class="modal-header">
            <h3 id="historyModalTitle">Module Audit History (Created, Updated, Deleted)</h3>
            <button type="button" class="close-modal" onclick="closeModal('globalHistoryModal')">&times;</button>
        </div>
        <div id="globalHistoryContent" style="margin-top:1rem; max-height:60vh; overflow-y:auto;">
            <p class="empty-state">Loading audit trails...</p>
        </div>
    </div>
</div>

<!-- UPLOAD CSV MODAL -->
<div id="uploadModal" class="modal-overlay">
    <div class="modal-content" style="max-width:450px;">
        <div class="modal-header">
            <h3>Bulk Upload via CSV</h3>
            <button type="button" class="close-modal" onclick="closeModal('uploadModal')">&times;</button>
        </div>
        <form method="POST" action="ownership.php" enctype="multipart/form-data">
            <input type="hidden" name="form_action" value="upload_csv">
            <p style="font-size:0.85rem; color:#64748B; margin-bottom:1rem;">Upload a CSV file formatted to match the exported column structure.</p>
            <div class="form-group">
                <input type="file" name="csv_file" accept=".csv" class="form-control" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('uploadModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload &amp; Import</button>
            </div>
        </form>
    </div>
</div>

<!-- CUSTOMIZE COLUMNS MODAL -->
<div id="columnsModal" class="modal-overlay">
    <div class="modal-content" style="max-width:550px;">
        <div class="modal-header">
            <div>
                <h3>Customize Visible Columns</h3>
            </div>
            <button type="button" class="close-modal" onclick="closeModal('columnsModal')">&times;</button>
        </div>
        <div class="column-preferences-grid">
            <?php foreach ($ownership_columns as $col_key => $col_label): ?>
                <?php $is_checked = in_array($col_key, $visible_columns, true); ?>
                <label class="column-preference-item">
                    <input type="checkbox" data-column="<?php echo htmlspecialchars($col_key); ?>" <?php echo $is_checked ? 'checked' : ''; ?> onchange="toggleCol('<?php echo htmlspecialchars($col_key); ?>', this.checked)">
                    <span><?php echo htmlspecialchars($col_label); ?></span>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="modal-footer">
            <span id="columnSaveStatus" class="save-status"></span>
            <button type="button" class="btn" onclick="closeModal('columnsModal')">Cancel</button>
            <button type="button" class="btn btn-primary" onclick="saveColumnPreferences()">Save Preferences</button>
        </div>
    </div>
</div>

<!-- JavaScript Interactions -->
<script>
    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function setSupportLevelChecks(levelsStr) {
        const selected = String(levelsStr || '').split(',').map(s => s.trim()).filter(Boolean);
        document.querySelectorAll('#rec_support_level_group input[type="checkbox"]').forEach(cb => {
            cb.checked = selected.indexOf(cb.value) !== -1;
        });
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'Add Ownership Entry';
        document.getElementById('rec_id').value = '';
        document.querySelectorAll('#recordModal input[type="text"], #recordModal input[type="email"]').forEach(i => i.value = '');
        setSupportLevelChecks('');
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Ownership Entry';
        document.getElementById('rec_id').value = data.id;
        document.getElementById('rec_project').value = data.project;
        setSupportLevelChecks(data.support_level);
        document.getElementById('rec_technical_owner').value = data.technical_owner;
        document.getElementById('rec_technical_owner_email').value = data.technical_owner_email;
        document.getElementById('rec_team_dl').value = data.team_dl;
        document.getElementById('rec_technical_manager').value = data.technical_manager;
        document.getElementById('rec_technical_manager_email').value = data.technical_manager_email;
        document.getElementById('rec_sdm_name').value = data.sdm_name;
        document.getElementById('rec_sdm_email').value = data.sdm_email;
        document.getElementById('rec_ncgr_owner').value = data.ncgr_owner;
        document.getElementById('rec_ncgr_owner_email').value = data.ncgr_owner_email;
        document.getElementById('recordModal').style.display = 'flex';
    }

    // Prefills the create form from an existing record so a similar
    // owner doesn't have to be retyped -- but leaves rec_id blank so
    // the submit inserts a new row instead of overwriting the
    // original. Project + Support Level are copied as-is too, so
    // saving without changing at least one of them will correctly
    // hit the same-project/same-level duplicate check below.
    function cloneOwnership(data) {
        openEditModal(data);
        document.getElementById('rec_id').value = '';
        document.getElementById('modalTitle').innerText = 'Clone Ownership Entry';
    }

    // Checkboxes can't use the native "required" attribute for
    // "at least one selected", so this is enforced on submit.
    document.getElementById('recordForm').addEventListener('submit', function (e) {
        const anyChecked = document.querySelectorAll('#rec_support_level_group input[type="checkbox"]:checked').length > 0;
        const errEl = document.getElementById('supportLevelError');
        if (!anyChecked) {
            e.preventDefault();
            if (errEl) errEl.style.display = 'block';
        } else if (errEl) {
            errEl.style.display = 'none';
        }
    });

    function escapeHtml(value) {
        return String(value ?? '-')
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    /*
    | Explicit label map rather than derived-from-key titlecasing, which
    | rendered "sdm_name" as "Sdm Name" and "ncgr_owner" as "Ncgr Owner".
    | Order here is the order shown in the modal.
    */
    const OWNERSHIP_DETAIL_FIELDS = [
        ['project', 'Project'],
        ['support_level', 'Support Level'],
        ['technical_owner', 'Technical Owner'],
        ['technical_owner_email', 'Technical Owner Email'],
        ['team_dl', 'Team DL'],
        ['technical_manager', 'Technical Manager'],
        ['technical_manager_email', 'Technical Manager Email'],
        ['sdm_name', 'SDM Name'],
        ['sdm_email', 'SDM Email'],
        ['ncgr_owner', 'NCGR Owner'],
        ['ncgr_owner_email', 'NCGR Owner Email'],
        ['notes', 'Notes'],
    ];

    const EMAIL_DETAIL_FIELDS = [
        'technical_owner_email',
        'technical_manager_email',
        'sdm_email',
        'ncgr_owner_email',
    ];

    function detailValueHtml(key, rawValue) {
        const value = String(rawValue ?? '').trim();

        if (value === '' || value === '-') {
            return '<strong class="is-empty">Not set</strong>';
        }

        if (EMAIL_DETAIL_FIELDS.indexOf(key) !== -1 && value.indexOf('@') !== -1) {
            return '<strong><a href="mailto:' + escapeHtml(value) + '">' + escapeHtml(value) + '</a></strong>';
        }

        if (key === 'support_level') {
            const levels = value.split(',').map(v => v.trim()).filter(Boolean);
            if (levels.length === 0) return '<strong class="is-empty">Not set</strong>';
            const badges = levels.map(function (lvl) {
                const badgeClass = 'badge-' + lvl.replace(/\s+/g, '-');
                return '<span class="badge ' + escapeHtml(badgeClass) + '"><span class="badge-dot"></span>' +
                    escapeHtml(lvl) + '</span>';
            }).join('');
            return '<strong><span class="badge-group">' + badges + '</span></strong>';
        }

        return '<strong>' + escapeHtml(value) + '</strong>';
    }

    // Shows every field on the record, regardless of which columns
    // are currently toggled visible in the table.
    function viewOwnership(data) {
        let html = '';

        OWNERSHIP_DETAIL_FIELDS.forEach(function (field) {
            const key = field[0];
            const label = field[1];

            // 'notes' only exists on some deployments -- skip silently.
            if (!(key in data)) return;

            const wide = (key === 'notes') ? ' detail-item-wide' : '';

            html += '<div class="detail-item' + wide + '">' +
                '<label>' + escapeHtml(label) + '</label>' +
                detailValueHtml(key, data[key]) +
                '</div>';
        });

        document.getElementById('viewContent').innerHTML = html;

        document.getElementById('viewSubtitle').innerHTML =
            escapeHtml(String(data.project ?? '').trim() || 'Untitled project') +
            ' <span class="subtitle-sep">&middot;</span> Record #' + escapeHtml(data.id);

        // Created/updated provenance sits below the grid rather than
        // as four more identical-looking cells inside it.
        let metaHtml = '<span>Created by <strong>' + escapeHtml(data.created_by) +
            '</strong> on ' + escapeHtml(data.created_at) + '</span>';

        if (String(data.updated_at ?? '').trim() !== '') {
            metaHtml += '<span>Last updated by <strong>' + escapeHtml(data.updated_by) +
                '</strong> on ' + escapeHtml(data.updated_at) + '</span>';
        }

        document.getElementById('viewMeta').innerHTML = metaHtml;

        switchViewTab('details');
        loadLinkedServers(data.id);

        document.getElementById('viewModal').style.display = 'flex';
    }

    /* ============================
    VIEW MODAL TABS + LINKED SERVERS
    ============================ */

    function switchViewTab(tabKey) {
        ['details', 'servers'].forEach(function (key) {
            const btn = document.getElementById('viewTabBtn-' + key);
            const panel = document.getElementById('viewTabPanel-' + key);
            if (btn) btn.classList.toggle('is-active', key === tabKey);
            if (panel) panel.classList.toggle('is-active', key === tabKey);
        });
    }

    // Loaded eagerly when the modal opens so the tab label can show an
    // accurate count before the user clicks it.
    function loadLinkedServers(ownershipId) {
        const container = document.getElementById('serversContent');
        const countBadge = document.getElementById('serverCount');

        // Tab is not rendered for roles without inventory view rights.
        if (!container) return;

        container.innerHTML = '<p class="empty-state">Loading linked servers...</p>';
        if (countBadge) countBadge.innerText = '…';

        fetch('ownership.php?action=get_servers&id=' + encodeURIComponent(ownershipId))
            .then(res => res.json())
            .then(data => {
                container.innerHTML = data.html || '<p class="empty-state">No linked servers found.</p>';
                if (countBadge) countBadge.innerText = data.count ?? 0;
            })
            .catch(() => {
                container.innerHTML = '<p class="empty-state" style="color:#EF4444;">Failed to load linked servers.</p>';
                if (countBadge) countBadge.innerText = '0';
            });
    }

    function openDeleteModal(id, projectName) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_project_name').innerText = projectName;
        document.getElementById('deleteModal').style.display = 'flex';
    }

    function openUploadModal() {
        document.getElementById('uploadModal').style.display = 'flex';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    // Call with no argument for the full module log (toolbar button).
    // Call with an ownership record id to scope history to just that
    // one row (per-row "History" button). Both share the same modal.
    function openHistoryModal(ownershipId) {
        document.getElementById('globalHistoryModal').style.display = 'flex';
        document.getElementById('historyModalTitle').innerText = ownershipId
            ? 'Record Audit History (#' + ownershipId + ')'
            : 'Module Audit History (Created, Updated, Deleted)';
        document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state">Loading audit history...</p>';

        const url = ownershipId
            ? 'ownership.php?action=get_history&id=' + encodeURIComponent(ownershipId)
            : 'ownership.php?action=get_history';

        fetch(url)
            .then(res => res.text())
            .then(html => {
                document.getElementById('globalHistoryContent').innerHTML = html;
            })
            .catch(() => {
                document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state" style="color:#EF4444;">Failed to load audit history logs.</p>';
            });
    }

    /* ============================
    COLUMN CUSTOMIZATION (persisted server-side per user)
    ============================ */

    function openColumnsModal() {
        document.getElementById('columnsModal').style.display = 'flex';
        document.getElementById('columnSaveStatus').innerText = '';
    }

    function toggleCol(colKey, show) {
        document.querySelectorAll('.col-th-' + colKey + ', .col-td-' + colKey).forEach(function (el) {
            el.classList.toggle('hidden-col', !show);
        });
    }

    function saveColumnPreferences() {
        const selected = Array.from(document.querySelectorAll('#columnsModal input[type="checkbox"][data-column]:checked'))
            .map(cb => cb.dataset.column);

        if (selected.length === 0) {
            document.getElementById('columnSaveStatus').innerText = 'Select at least one column.';
            return;
        }

        const formData = new FormData();
        formData.append('form_action', 'save_columns');
        formData.append('visible_columns', JSON.stringify(selected));

        const status = document.getElementById('columnSaveStatus');
        status.innerText = 'Saving...';

        fetch('ownership.php', { method: 'POST', body: formData })
            .then(r => r.json())
            .then(data => {
                status.innerText = (data && data.message) || (data && data.ok ? 'Saved.' : 'Unable to save.');
                if (data && data.ok) setTimeout(() => closeModal('columnsModal'), 700);
            })
            .catch(() => { status.innerText = 'Unable to save column layout.'; });
    }
</script>

<?php require 'includes/footer.php'; ?>