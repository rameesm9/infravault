<?php
require_once 'config/db.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

function handoverHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'handover', $permission);
}


require_once 'includes/permission-helpers.php';

/*
|--------------------------------------------------------------------------
| VISIBILITY
|--------------------------------------------------------------------------
|
| A handover names both owners and carries open issues, risks and pending
| actions, so it is publishable at three scopes rather than being visible
| to everyone who can open the page:
|
|   team    -> the author's team
|   teams   -> a chosen set of teams (handover_teams)
|   public  -> anyone whose role grants handover.can_view
|
| Rows created before this existed default to 'public', which is how they
| already behaved -- a migration must not hide data retroactively.
*/

const HANDOVER_VISIBILITIES = [
    'team'   => 'My team',
    'teams'  => 'Multiple teams',
    'public' => 'Public',
];

$is_handover_admin = in_array(strtolower($role), ['admin', 'administrator', 'super admin', 'superadmin'], true);

/* The session carries the role but not the team, which visibility needs. */
$user_team = '';
try {
    $ut = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
    $ut->execute([$current_user_id]);
    $user_team = (string) ($ut->fetchColumn() ?: '');
} catch (Throwable $e) {
    $user_team = '';
}

$handover_teams_list = [];
try {
    $handover_teams_list = $pdo->query("SELECT team_name FROM teams ORDER BY team_name")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    $handover_teams_list = [];
}

/**
 * WHERE fragment limiting the list to what this user may see.
 *
 * The owner_team comparison guards against empty strings on both sides:
 * a user with no team assigned would otherwise match every record whose
 * owner_team was never set.
 *
 * @return array{0:string,1:array<int,mixed>}
 */
function handoverVisibilityWhere(bool $isAdmin, int $userId, string $userTeam, string $alias = 'handovers'): array
{
    if ($isAdmin) {
        return ['1=1', []];
    }

    /*
     * $alias exists because this fragment is used against both
     * "FROM handovers" (the count) and "FROM handovers h" (the list). Once
     * a table is aliased its original name no longer resolves, so the
     * correlated EXISTS below has to be told which name to use.
     */
    $a = preg_match('/^[a-z_][a-z0-9_]*$/i', $alias) ? $alias : 'handovers';

    $sql = "(
        COALESCE(visibility,'public') = 'public'
        OR user_id = ?
        OR (visibility = 'team'  AND COALESCE(owner_team,'') <> '' AND owner_team = ?)
        OR (visibility = 'teams' AND EXISTS (
                SELECT 1 FROM handover_teams ht
                WHERE ht.handover_id = $a.id AND ht.team_name = ?
        ))
    )";

    return [$sql, [$userId, $userTeam, $userTeam]];
}

/**
 * Replaces a handover's team shares.
 *
 * Rewritten wholesale rather than diffed: the editor lets teams be ticked
 * and unticked freely, so "what is checked now" is the whole truth. Rows
 * are cleared for every scope, not just 'teams', so switching a record
 * from multi-team to public does not leave stale shares behind that would
 * reappear if it were switched back.
 */
function handoverSaveTeams(PDO $pdo, int $handoverId, string $visibility, array $teams): void
{
    try {
        $pdo->prepare("DELETE FROM handover_teams WHERE handover_id = ?")->execute([$handoverId]);

        if ($visibility !== 'teams' || !$teams) {
            return;
        }

        $ins = $pdo->prepare("INSERT OR IGNORE INTO handover_teams (handover_id, team_name) VALUES (?, ?)");
        foreach ($teams as $team) {
            $team = trim((string) $team);
            if ($team !== '') {
                $ins->execute([$handoverId, $team]);
            }
        }
    } catch (Throwable $e) {
        error_log("handoverSaveTeams failed for #$handoverId: " . $e->getMessage());
    }
}

/**
 * Loads one handover only if this user may see it, else null.
 *
 * Every write path goes through this rather than a bare SELECT by id --
 * otherwise the record id is the only thing an attacker needs to edit or
 * delete a handover belonging to a team they are not in.
 */
function handoverLoadVisible(PDO $pdo, int $id, bool $isAdmin, int $userId, string $userTeam): ?array
{
    [$sql, $bind] = handoverVisibilityWhere($isAdmin, $userId, $userTeam);

    $stmt = $pdo->prepare("SELECT * FROM handovers WHERE id = ? AND $sql");
    $stmt->execute([$id, ...$bind]);

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}


$canView   = handoverHasPermission($pdo, $role, 'can_view');
$canEdit   = handoverHasPermission($pdo, $role, 'can_edit');
$canDelete = handoverHasPermission($pdo, $role, 'can_delete');
$canExport = handoverHasPermission($pdo, $role, 'can_export');
$canImport = handoverHasPermission($pdo, $role, 'can_import');
$canAudit  = handoverHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
*/

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}


/*
|--------------------------------------------------------------------------
| RESOLVE CURRENT USERNAME
|--------------------------------------------------------------------------
*/

$username = 'Unknown User';

if ($current_user_id > 0) {
    $userStmt = $pdo->prepare("
        SELECT first_name, last_name, ncgr_id
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $userStmt->execute([$current_user_id]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if ($currentUser) {
        $firstName = trim($currentUser['first_name'] ?? '');
        $lastName  = trim($currentUser['last_name'] ?? '');
        $ncgrId    = trim($currentUser['ncgr_id'] ?? '');
        $fullName  = trim($firstName . ' ' . $lastName);

        if ($fullName !== '' && $ncgrId !== '') {
            $username = $fullName . ' (' . $ncgrId . ')';
        } elseif ($fullName !== '') {
            $username = $fullName;
        } elseif ($ncgrId !== '') {
            $username = $ncgrId;
        }
    }
}


/*
|--------------------------------------------------------------------------
| AUDIT HISTORY TABLE
|--------------------------------------------------------------------------
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS handover_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        handover_id INTEGER,
        action_type TEXT NOT NULL,
        performed_by TEXT,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize handover_history: ' . $e->getMessage());
}


$success_msg = '';
$error_msg = '';


/*
|--------------------------------------------------------------------------
| FIELDS / LABELS
|--------------------------------------------------------------------------
*/

function ho_initials(string $name): string
{
    $name = trim($name);

    if ($name === '') {
        return '?';
    }

    $parts = preg_split('/\s+/', $name);
    $initials = strtoupper(substr($parts[0], 0, 1));

    if (count($parts) > 1) {
        $initials .= strtoupper(substr(end($parts), 0, 1));
    } elseif (strlen($parts[0]) > 1) {
        $initials .= strtoupper(substr($parts[0], 1, 1));
    }

    return $initials;
}


$handover_field_labels = [
    'project_name'          => 'Project Name',
    'project_id'            => 'Project ID',
    'current_owner'         => 'Current Owner',
    'new_owner'             => 'New Owner',
    'handover_date'         => 'Handover Date',
    'handover_status'       => 'Handover Status',
    'reason_for_handover'   => 'Reason for Handover',
    'project_phase'         => 'Project Phase',
    'documentation_status'  => 'Documentation Status',
    'open_issues'           => 'Open Issues',
    'pending_actions'       => 'Pending Actions',
    'risks'                 => 'Risks',
    'dependencies'          => 'Dependencies',
    'kt_completed'          => 'Knowledge Transfer Completed',
    'training_completed'    => 'Training Completed',
    'access_transferred'    => 'Access Transferred',
    'stakeholder_signoff'   => 'Stakeholder Sign-off',
    'client_notified'       => 'Customer/Client Notified',
    'warranty_period'       => 'Warranty/Support Period',
    'notes'                 => 'Notes',
];


/*
|--------------------------------------------------------------------------
| FETCH TECHNICAL OWNERS
|--------------------------------------------------------------------------
*/

$owners_stmt = $pdo->query("
    SELECT DISTINCT technical_owner
    FROM ownership
    WHERE technical_owner IS NOT NULL
      AND technical_owner != ''
    ORDER BY technical_owner ASC
");

$tech_owners = $owners_stmt->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| STATUS OVERVIEW (KPI CARDS)
|--------------------------------------------------------------------------
*/

$status_counts = [
    'Planned'     => 0,
    'In Progress' => 0,
    'Completed'   => 0,
    'Delayed'     => 0,
];

$status_count_stmt = $pdo->query("
    SELECT handover_status, COUNT(*) AS cnt
    FROM handovers
    GROUP BY handover_status
");

foreach ($status_count_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    if (isset($status_counts[$row['handover_status']])) {
        $status_counts[$row['handover_status']] = (int)$row['cnt'];
    }
}

$total_handovers = array_sum($status_counts);


/*
|--------------------------------------------------------------------------
| EXPORT CSV
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export handover records.');
    }

    // Build WHERE clause with same filters as main page
    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_project_name = trim($_GET['s_project_name'] ?? '');
    $s_current_owner = trim($_GET['s_current_owner'] ?? '');
    $s_new_owner = trim($_GET['s_new_owner'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');

    if (!empty($keyword)) {
        $export_where_clauses[] = "(project_name LIKE ? OR project_id LIKE ? OR current_owner LIKE ? OR new_owner LIKE ?)";
        array_push($export_params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
    }
    if (!empty($s_project_name)) {
        $export_where_clauses[] = "project_name LIKE ?";
        $export_params[] = "%$s_project_name%";
    }
    if (!empty($s_current_owner)) {
        $export_where_clauses[] = "current_owner LIKE ?";
        $export_params[] = "%$s_current_owner%";
    }
    if (!empty($s_new_owner)) {
        $export_where_clauses[] = "new_owner LIKE ?";
        $export_params[] = "%$s_new_owner%";
    }
    if (!empty($s_status)) {
        $export_where_clauses[] = "handover_status = ?";
        $export_params[] = "$s_status";
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=handover_export_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    fputcsv(
        $output,
        array_merge(
            array_values($handover_field_labels),
            ['Last Updated']
        )
    );

    $cols = array_keys($handover_field_labels);

    $export_stmt = $pdo->prepare("
        SELECT *
        FROM handovers
        WHERE $export_where_sql
        ORDER BY id DESC
    ");

    $export_stmt->execute($export_params);

    while ($row = $export_stmt->fetch(PDO::FETCH_ASSOC)) {

        $line = [];

        foreach ($cols as $c) {
            $line[] = $row[$c] ?? '';
        }

        $line[] = $row['last_updated'] ?? '';

        fputcsv($output, $line);
    }

    fclose($output);
    exit;
}


/*
|--------------------------------------------------------------------------
| GLOBAL + PER-RECORD HISTORY AJAX
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="ho-empty">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    if ($historyId > 0) {

        $h_stmt = $pdo->prepare("
            SELECT *
            FROM handover_history
            WHERE handover_id = ?
            ORDER BY timestamp DESC, id DESC
        ");

        $h_stmt->execute([$historyId]);

    } else {

        $h_stmt = $pdo->query("
            SELECT *
            FROM handover_history
            ORDER BY timestamp DESC, id DESC
        ");
    }

    $logs = $h_stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {

        echo '<table class="audit-table">';
        echo '<thead>';
        echo '<tr>';
        echo '<th>Action</th>';
        echo '<th>Performed By</th>';
        echo '<th>Details</th>';
        echo '<th>Timestamp</th>';
        echo '</tr>';
        echo '</thead>';
        echo '<tbody>';

        foreach ($logs as $log) {

            $badge_class = '';

            if ($log['action_type'] === 'CREATED') {
                $badge_class = 'action-created';
            } elseif ($log['action_type'] === 'DELETED') {
                $badge_class = 'action-deleted';
            } elseif ($log['action_type'] === 'UPDATED') {
                $badge_class = 'action-updated';
            }

            echo '<tr>';

            echo '<td>';
            echo '<span class="audit-badge ' . $badge_class . '">';
            echo htmlspecialchars($log['action_type']);
            echo '</span>';
            echo '</td>';

            echo '<td>';
            echo htmlspecialchars($log['performed_by'] ?? '');
            echo '</td>';

            echo '<td class="audit-details">';
            echo nl2br(htmlspecialchars($log['details'] ?? ''));
            echo '</td>';

            echo '<td>';
            echo htmlspecialchars($log['timestamp'] ?? '');
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody>';
        echo '</table>';

    } else {

        echo '<p class="ho-empty">' .
            ($historyId > 0
                ? 'No history found for this record.'
                : 'No audit history records found.') .
            '</p>';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| HANDLE FORM SUBMISSIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | CREATE HANDOVER
    |--------------------------------------------------------------------------
    */

    if ($action === 'create_handover') {

        if (!$canEdit) {

            $error_msg = "You do not have permission to create handover records.";

        } else {

            $project_name = trim($_POST['project_name'] ?? '');
            $project_id = trim($_POST['project_id'] ?? '');
            $current_owner = trim($_POST['current_owner'] ?? '');
            $new_owner = trim($_POST['new_owner'] ?? '');
            $handover_date = trim($_POST['handover_date'] ?? '');
            $handover_status = trim($_POST['handover_status'] ?? '');
            $reason_for_handover = trim($_POST['reason_for_handover'] ?? '');
            $project_phase = trim($_POST['project_phase'] ?? '');
            $documentation_status = trim($_POST['documentation_status'] ?? '');
            $open_issues = trim($_POST['open_issues'] ?? '');
            $pending_actions = trim($_POST['pending_actions'] ?? '');
            $risks = trim($_POST['risks'] ?? '');
            $dependencies = trim($_POST['dependencies'] ?? '');
            $kt_completed = trim($_POST['kt_completed'] ?? 'No');
            $training_completed = trim($_POST['training_completed'] ?? 'No');
            $access_transferred = trim($_POST['access_transferred'] ?? 'No');
            $stakeholder_signoff = trim($_POST['stakeholder_signoff'] ?? '');
            $client_notified = trim($_POST['client_notified'] ?? 'No');
            $warranty_period = trim($_POST['warranty_period'] ?? '');
            $notes = trim($_POST['notes'] ?? '');

            /* Publication scope. An unrecognised value falls back to the
               narrowest sensible default rather than to public. */
            $visibility = (string) ($_POST['visibility'] ?? 'public');
            if (!isset(HANDOVER_VISIBILITIES[$visibility])) {
                $visibility = 'public';
            }

            // Only real teams are stored, so a hand-crafted POST cannot
            // create a share against a team that does not exist.
            $shared_teams = array_values(array_intersect(
                array_filter(array_map('trim', (array) ($_POST['shared_teams'] ?? []))),
                $handover_teams_list
            ));

            // 'team' means the author's own team, recorded explicitly so
            // the row still reads correctly if they later change team.
            $owner_team = $visibility === 'team' ? $user_team : '';

            if (
                empty($project_name) ||
                empty($current_owner) ||
                empty($new_owner)
            ) {

                $error_msg =
                    "Please fill in all required fields (Project Name, Current Owner, New Owner).";

            } else {

                $stmt = $pdo->prepare("
                    INSERT INTO handovers (
                        project_name,
                        project_id,
                        current_owner,
                        new_owner,
                        handover_date,
                        handover_status,
                        reason_for_handover,
                        project_phase,
                        documentation_status,
                        open_issues,
                        pending_actions,
                        risks,
                        dependencies,
                        kt_completed,
                        training_completed,
                        access_transferred,
                        stakeholder_signoff,
                        client_notified,
                        warranty_period,
                        notes,
                        user_id,
                        visibility,
                        owner_team,
                        last_updated
                    )
                    VALUES (
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                        ?, ?,
                        CURRENT_TIMESTAMP
                    )
                ");

                $stmt->execute([
                    $project_name,
                    $project_id,
                    $current_owner,
                    $new_owner,
                    $handover_date,
                    $handover_status,
                    $reason_for_handover,
                    $project_phase,
                    $documentation_status,
                    $open_issues,
                    $pending_actions,
                    $risks,
                    $dependencies,
                    $kt_completed,
                    $training_completed,
                    $access_transferred,
                    $stakeholder_signoff,
                    $client_notified,
                    $warranty_period,
                    $notes,
                    $current_user_id,
                    $visibility,
                    $owner_team
                ]);

                $handover_id = $pdo->lastInsertId();

                // Team shares live in their own table; rewritten wholesale
                // so removing a team on edit actually removes the share.
                handoverSaveTeams($pdo, (int) $handover_id, $visibility, $shared_teams);


                /*
                |--------------------------------------------------------------------------
                | FILE ATTACHMENTS
                |--------------------------------------------------------------------------
                */

                if (
                    isset($_FILES['attachments']['name']) &&
                    is_array($_FILES['attachments']['name']) &&
                    !empty($_FILES['attachments']['name'][0])
                ) {

                    $upload_dir = 'uploads/handovers/';

                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }

                    foreach ($_FILES['attachments']['name'] as $key => $filename) {

                        if (
                            !isset($_FILES['attachments']['error'][$key]) ||
                            $_FILES['attachments']['error'][$key] !== UPLOAD_ERR_OK
                        ) {
                            continue;
                        }

                        $tmp_name =
                            $_FILES['attachments']['tmp_name'][$key];

                        $safe_filename =
                            time() . '_' .
                            preg_replace(
                                "/[^a-zA-Z0-9\._-]/",
                                "_",
                                basename($filename)
                            );

                        $destination =
                            $upload_dir . $safe_filename;

                        if (move_uploaded_file(
                            $tmp_name,
                            $destination
                        )) {

                            $att_stmt = $pdo->prepare("
                                INSERT INTO handover_attachments
                                (handover_id, filename, filepath)
                                VALUES (?, ?, ?)
                            ");

                            $att_stmt->execute([
                                $handover_id,
                                $filename,
                                $destination
                            ]);
                        }
                    }
                }


                /*
                |--------------------------------------------------------------------------
                | AUDIT
                |--------------------------------------------------------------------------
                */

                $h_stmt = $pdo->prepare("
                    INSERT INTO handover_history
                    (handover_id, action_type, performed_by, details)
                    VALUES (?, 'CREATED', ?, ?)
                ");

                $h_stmt->execute([
                    $handover_id,
                    $username,
                    "Created handover: $project_name (current owner: $current_owner -> new owner: $new_owner)"
                ]);

                $success_msg =
                    "New project handover record successfully created!";
            }
        }


    /*
    |--------------------------------------------------------------------------
    | UPDATE HANDOVER
    |--------------------------------------------------------------------------
    */

    } elseif ($action === 'update_handover') {

        $handover_id = (int)($_POST['handover_id'] ?? 0);

        if ($handover_id <= 0) {

            $error_msg = "Invalid handover record.";

        } elseif (!$canEdit) {

            $error_msg =
                "You do not have permission to modify handover records.";

        } else {

            /*
            | Loaded through the visibility filter, not by id alone. A bare
            | "SELECT ... WHERE id = ?" would let anyone with can_edit
            | modify a handover scoped to a team they are not in, simply by
            | supplying its id -- the record id is the only thing the form
            | sends.
            |
            | The same message covers "missing" and "not yours", so the
            | response cannot be used to discover which ids exist.
            */
            $oldRecord = handoverLoadVisible(
                $pdo,
                $handover_id,
                $is_handover_admin,
                (int) $current_user_id,
                $user_team
            );

            if (!$oldRecord) {

                $error_msg = "Handover record not found.";

            } else {

                $project_name = trim($_POST['project_name'] ?? '');
                $project_id = trim($_POST['project_id'] ?? '');
                $current_owner = trim($_POST['current_owner'] ?? '');
                $new_owner = trim($_POST['new_owner'] ?? '');
                $handover_date = trim($_POST['handover_date'] ?? '');
                $handover_status = trim($_POST['handover_status'] ?? '');
                $reason_for_handover = trim($_POST['reason_for_handover'] ?? '');
                $project_phase = trim($_POST['project_phase'] ?? '');
                $documentation_status = trim($_POST['documentation_status'] ?? '');
                $open_issues = trim($_POST['open_issues'] ?? '');
                $pending_actions = trim($_POST['pending_actions'] ?? '');
                $risks = trim($_POST['risks'] ?? '');
                $dependencies = trim($_POST['dependencies'] ?? '');
                $kt_completed = trim($_POST['kt_completed'] ?? 'No');
                $training_completed = trim($_POST['training_completed'] ?? 'No');
                $access_transferred = trim($_POST['access_transferred'] ?? 'No');
                $stakeholder_signoff = trim($_POST['stakeholder_signoff'] ?? '');
                $client_notified = trim($_POST['client_notified'] ?? 'No');
                $warranty_period = trim($_POST['warranty_period'] ?? '');
                $notes = trim($_POST['notes'] ?? '');

                $visibility = (string) ($_POST['visibility'] ?? ($oldRecord['visibility'] ?? 'public'));
                if (!isset(HANDOVER_VISIBILITIES[$visibility])) {
                    $visibility = 'public';
                }

                $shared_teams = array_values(array_intersect(
                    array_filter(array_map('trim', (array) ($_POST['shared_teams'] ?? []))),
                    $handover_teams_list
                ));

                // Keep the existing owner_team when the record already had
                // one, so re-saving as 'team' does not silently move it to
                // whoever happens to be editing.
                $owner_team = $visibility === 'team'
                    ? (trim((string) ($oldRecord['owner_team'] ?? '')) ?: $user_team)
                    : '';


                if (
                    $project_name === '' ||
                    $current_owner === '' ||
                    $new_owner === ''
                ) {

                    $error_msg =
                        "Please fill in all required fields.";

                } else {

                    $update_stmt = $pdo->prepare("
                        UPDATE handovers SET
                            project_name = ?,
                            project_id = ?,
                            current_owner = ?,
                            new_owner = ?,
                            handover_date = ?,
                            handover_status = ?,
                            reason_for_handover = ?,
                            project_phase = ?,
                            documentation_status = ?,
                            open_issues = ?,
                            pending_actions = ?,
                            risks = ?,
                            dependencies = ?,
                            kt_completed = ?,
                            training_completed = ?,
                            access_transferred = ?,
                            stakeholder_signoff = ?,
                            client_notified = ?,
                            warranty_period = ?,
                            notes = ?,
                            visibility = ?,
                            owner_team = ?,
                            last_updated = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ");

                    $update_stmt->execute([
                        $project_name,
                        $project_id,
                        $current_owner,
                        $new_owner,
                        $handover_date,
                        $handover_status,
                        $reason_for_handover,
                        $project_phase,
                        $documentation_status,
                        $open_issues,
                        $pending_actions,
                        $risks,
                        $dependencies,
                        $kt_completed,
                        $training_completed,
                        $access_transferred,
                        $stakeholder_signoff,
                        $client_notified,
                        $warranty_period,
                        $notes,
                        $visibility,
                        $owner_team,
                        $handover_id
                    ]);

                    handoverSaveTeams($pdo, $handover_id, $visibility, $shared_teams);


                    /*
                    |--------------------------------------------------------------------------
                    | FILE ATTACHMENTS
                    |--------------------------------------------------------------------------
                    */

                    if (
                        isset($_FILES['attachments']['name']) &&
                        is_array($_FILES['attachments']['name']) &&
                        !empty($_FILES['attachments']['name'][0])
                    ) {

                        $upload_dir = 'uploads/handovers/';

                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }

                        foreach ($_FILES['attachments']['name'] as $key => $filename) {

                            if (
                                !isset($_FILES['attachments']['error'][$key]) ||
                                $_FILES['attachments']['error'][$key] !== UPLOAD_ERR_OK
                            ) {
                                continue;
                            }

                            $tmp_name =
                                $_FILES['attachments']['tmp_name'][$key];

                            $safe_filename =
                                time() . '_' .
                                preg_replace(
                                    "/[^a-zA-Z0-9\._-]/",
                                    "_",
                                    basename($filename)
                                );

                            $destination =
                                $upload_dir . $safe_filename;

                            if (move_uploaded_file(
                                $tmp_name,
                                $destination
                            )) {

                                $att_stmt = $pdo->prepare("
                                    INSERT INTO handover_attachments
                                    (handover_id, filename, filepath)
                                    VALUES (?, ?, ?)
                                ");

                                $att_stmt->execute([
                                    $handover_id,
                                    $filename,
                                    $destination
                                ]);
                            }
                        }
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | FIELD-LEVEL AUDIT DIFF
                    |--------------------------------------------------------------------------
                    */

                    $newValuesByColumn = [

                        'project_name' =>
                            $project_name,

                        'project_id' =>
                            $project_id,

                        'current_owner' =>
                            $current_owner,

                        'new_owner' =>
                            $new_owner,

                        'handover_date' =>
                            $handover_date,

                        'handover_status' =>
                            $handover_status,

                        'reason_for_handover' =>
                            $reason_for_handover,

                        'project_phase' =>
                            $project_phase,

                        'documentation_status' =>
                            $documentation_status,

                        'open_issues' =>
                            $open_issues,

                        'pending_actions' =>
                            $pending_actions,

                        'risks' =>
                            $risks,

                        'dependencies' =>
                            $dependencies,

                        'kt_completed' =>
                            $kt_completed,

                        'training_completed' =>
                            $training_completed,

                        'access_transferred' =>
                            $access_transferred,

                        'stakeholder_signoff' =>
                            $stakeholder_signoff,

                        'client_notified' =>
                            $client_notified,

                        'warranty_period' =>
                            $warranty_period,

                        'notes' =>
                            $notes
                    ];


                    $changedFields = [];

                    foreach (
                        $newValuesByColumn
                        as $columnKey => $newVal
                    ) {

                        $oldValStr =
                            trim(
                                (string)(
                                    $oldRecord[$columnKey] ?? ''
                                )
                            );

                        $newValStr =
                            trim((string)$newVal);

                        if ($oldValStr !== $newValStr) {

                            $fieldLabel =
                                $handover_field_labels[$columnKey]
                                ?? $columnKey;

                            $oldDisplay =
                                $oldValStr === ''
                                ? '(empty)'
                                : $oldValStr;

                            $newDisplay =
                                $newValStr === ''
                                ? '(empty)'
                                : $newValStr;

                            $changedFields[] =
                                "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                        }
                    }


                    $detail_msg =
                        "Updated handover: $project_name\n";

                    $detail_msg .=
                        count($changedFields) > 0
                        ? implode("\n", $changedFields)
                        : "No field value changes detected.";


                    $h_stmt = $pdo->prepare("
                        INSERT INTO handover_history
                        (handover_id, action_type, performed_by, details)
                        VALUES (?, 'UPDATED', ?, ?)
                    ");

                    $h_stmt->execute([
                        $handover_id,
                        $username,
                        $detail_msg
                    ]);


                    $success_msg =
                        "Handover record successfully updated!";
                }
            }
        }


    /*
    |--------------------------------------------------------------------------
    | DELETE HANDOVER
    |--------------------------------------------------------------------------
    */

    } elseif ($action === 'delete_handover') {

        $handover_id = (int)($_POST['handover_id'] ?? 0);

        // Visibility-scoped, for the same reason as the update path: the id
        // is the only thing the form supplies, so loading by id alone would
        // let a record be deleted by someone who cannot even see it.
        $handover_owner = handoverLoadVisible(
            $pdo,
            $handover_id,
            $is_handover_admin,
            (int) $current_user_id,
            $user_team
        );

        if (!$handover_owner) {

            $error_msg =
                "Handover record not found.";

        } elseif (!$canDelete) {

            $error_msg =
                "You do not have permission to delete handover records.";

        } else {

            $att_query = $pdo->prepare("
                SELECT filepath
                FROM handover_attachments
                WHERE handover_id = ?
            ");

            $att_query->execute([$handover_id]);

            $attachments =
                $att_query->fetchAll(PDO::FETCH_ASSOC);

            foreach ($attachments as $att) {

                if (
                    !empty($att['filepath']) &&
                    file_exists($att['filepath'])
                ) {
                    unlink($att['filepath']);
                }
            }

            // Team shares first: foreign keys are off app-wide, so nothing
            // removes them automatically and they would be orphaned.
            $pdo->prepare("DELETE FROM handover_teams WHERE handover_id = ?")->execute([$handover_id]);

            $del_stmt = $pdo->prepare("
                DELETE FROM handovers
                WHERE id = ?
            ");

            $del_stmt->execute([$handover_id]);


            $h_stmt = $pdo->prepare("
                INSERT INTO handover_history
                (handover_id, action_type, performed_by, details)
                VALUES (?, 'DELETED', ?, ?)
            ");

            $h_stmt->execute([
                $handover_id,
                $username,
                "Deleted handover: " .
                ($handover_owner['project_name'] ?? 'Unknown')
            ]);

            $success_msg =
                "Handover record successfully deleted.";
        }
    }
}


/*
|--------------------------------------------------------------------------
| PAGINATION & SEARCH
|--------------------------------------------------------------------------
*/

$page_size = resolveUserPageSize($pdo, $current_user_id);

$page = isset($_GET['page'])
    ? max(1, (int)$_GET['page'])
    : 1;

$start = ($page - 1) * $page_size;

$keyword = trim($_GET['keyword'] ?? '');
$s_project_name = trim($_GET['s_project_name'] ?? '');
$s_current_owner = trim($_GET['s_current_owner'] ?? '');
$s_new_owner = trim($_GET['s_new_owner'] ?? '');
$s_status = trim($_GET['s_status'] ?? '');

$where_clauses = ["1=1"];
$params = [];

/*
| Visibility scoping, applied in SQL rather than by discarding rows in the
| template: a record the viewer has no right to must never reach their
| browser at all.
|
| Admins see everything. Everyone else sees public records, their own, the
| ones scoped to their team, and the ones explicitly shared with a team
| they belong to.
*/
// Alias 'h' -- both the count and the list query below use "FROM handovers h".
[$ho_vis_sql, $ho_vis_params] = handoverVisibilityWhere($is_handover_admin, (int) $current_user_id, $user_team, 'h');
$where_clauses[] = $ho_vis_sql;
$params = array_merge($params, $ho_vis_params);

if (!empty($keyword)) {
    $where_clauses[] = "(project_name LIKE ? OR project_id LIKE ? OR current_owner LIKE ? OR new_owner LIKE ?)";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_project_name)) {
    $where_clauses[] = "project_name LIKE ?";
    $params[] = "%$s_project_name%";
}
if (!empty($s_current_owner)) {
    $where_clauses[] = "current_owner LIKE ?";
    $params[] = "%$s_current_owner%";
}
if (!empty($s_new_owner)) {
    $where_clauses[] = "new_owner LIKE ?";
    $params[] = "%$s_new_owner%";
}
if (!empty($s_status)) {
    $where_clauses[] = "handover_status = ?";
    $params[] = "$s_status";
}

$where_sql = implode(" AND ", $where_clauses);

// Aliased to match the list query, so the shared visibility fragment
// resolves the same way in both.
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM handovers h WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_records / $page_size));

// Correct page if out of range
if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $page_size;
}

// Sorting - validate and apply
$sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

$valid_sort_columns = ['id', 'project_name', 'project_id', 'current_owner', 'new_owner', 'handover_date', 'handover_status', 'project_phase', 'kt_completed', 'access_transferred', 'last_updated'];
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'id';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'DESC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

/*
|--------------------------------------------------------------------------
| FETCH PAGINATED HANDOVERS
|--------------------------------------------------------------------------
*/

$data_stmt = $pdo->prepare("
    SELECT
        h.*,
        u.first_name AS creator_first,
        u.last_name AS creator_last
    FROM handovers h
    LEFT JOIN users u
        ON h.user_id = u.id
    WHERE $where_sql
    ORDER BY `$sort_by` $sort_dir
    LIMIT $page_size OFFSET $start
");

$data_stmt->execute($params);
$handovers = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

/*
| Team shares for the rows on this page, in one query rather than one per
| row. Attached to each record so the edit modal can pre-tick the right
| boxes without a second round trip.
*/
if ($handovers) {
    $ho_ids = array_column($handovers, 'id');
    $ho_shared = [];

    try {
        $in = implode(',', array_fill(0, count($ho_ids), '?'));
        $ts = $pdo->prepare("SELECT handover_id, team_name FROM handover_teams WHERE handover_id IN ($in) ORDER BY team_name");
        $ts->execute($ho_ids);
        foreach ($ts as $r) {
            $ho_shared[(int) $r['handover_id']][] = $r['team_name'];
        }
    } catch (Throwable $e) {
        $ho_shared = [];
    }

    foreach ($handovers as &$ho_row) {
        $ho_row['visibility']   = $ho_row['visibility'] ?? 'public';
        $ho_row['shared_teams'] = $ho_shared[(int) $ho_row['id']] ?? [];
    }
    unset($ho_row);
}

// Hidden fields so the page-size selector preserves the current
// search/filter/sort state instead of resetting it.
$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_project_name' => $s_project_name,
    's_current_owner' => $s_current_owner,
    's_new_owner' => $s_new_owner,
    's_status' => $s_status,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
] as $fk => $fv) {
    if ($fv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
    }
}


$page_title = "Project Handovers | InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/handover.css">

<style>
/* Visibility picker. Namespaced ho-vis-* so it cannot collide with the
   Bootstrap classes this page already loads. */
.ho-vis-row { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 6px; }
.ho-vis-opt {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 8px 14px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    cursor: pointer;
    font-size: 13px;
    background: var(--bg-content);
    transition: border-color .12s, background .12s;
}
.ho-vis-opt:hover { border-color: var(--text-muted); }
.ho-vis-opt:has(input:checked) {
    border-color: #2563EB;
    background: #EFF6FF;
    font-weight: 600;
}
.ho-vis-hint { font-size: 11.5px; color: var(--text-secondary); margin: 4px 0 10px; min-height: 1em; }

.ho-team-picker { margin-top: 4px; }
.ho-team-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(165px, 1fr));
    gap: 6px;
    margin-top: 6px;
    max-height: 170px;
    overflow-y: auto;
    padding: 9px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
}
.ho-team { display: flex; align-items: center; gap: 7px; font-size: 13px; cursor: pointer; }

/* Scope badge in the list. */
.ho-vis-badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 10.5px;
    font-weight: 700;
    color: #fff;
    letter-spacing: .02em;
}
.ho-vis-badge.vis-team   { background: #0369A1; }
.ho-vis-badge.vis-teams  { background: #6D28D9; }
.ho-vis-badge.vis-public { background: #0D9488; }

[data-theme="dark"] .ho-vis-opt { background: rgba(255,255,255,.04); border-color: var(--border-color); }
[data-theme="dark"] .ho-vis-opt:has(input:checked) { background: rgba(37,99,235,.18); }
[data-theme="dark"] .ho-team-list { border-color: var(--border-color); }
</style>


<div class="content">

    <div class="ho-hero">

        <div class="ho-hero-main">
            <div class="ho-hero-icon">🔄</div>
            <div>
                <h1>Project Handovers</h1>
                <p>
                    Track ownership transitions, knowledge transfer status,
                    and sign-off across all projects.
                </p>
            </div>
        </div>

        <div class="dashboard-actions">

            <?php if ($canEdit): ?>

                <button
                    type="button"
                    class="ho-btn ho-btn-primary"
                    onclick="openCreateModal()">
                    + Add Record
                </button>

            <?php endif; ?>


            <?php if ($canImport): ?>

                <button
                    type="button"
                    class="ho-btn ho-btn-indigo"
                    onclick="openImportModal()">
                    Import CSV
                </button>

            <?php endif; ?>


            <?php if ($canExport): ?>

                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_project_name !== '') $export_params['s_project_name'] = $s_project_name;
                if ($s_current_owner !== '') $export_params['s_current_owner'] = $s_current_owner;
                if ($s_new_owner !== '') $export_params['s_new_owner'] = $s_new_owner;
                if ($s_status !== '') $export_params['s_status'] = $s_status;
                $export_url = 'handover.php?' . http_build_query($export_params);
                ?>

                <a
                    href="<?= htmlspecialchars($export_url) ?>"
                    class="ho-btn ho-btn-indigo">
                    Export CSV
                </a>

            <?php endif; ?>


            <?php if ($canAudit): ?>

                <button
                    type="button"
                    class="ho-btn ho-btn-orange"
                    onclick="openGlobalHistoryModal()">
                    ⏱ History
                </button>

            <?php endif; ?>

        </div>

    </div>


    <div class="ho-stats-grid">

        <div class="ho-stat-card st-total">
            <div class="ho-stat-icon">📦</div>
            <div>
                <div class="ho-stat-value"><?= (int)$total_handovers ?></div>
                <div class="ho-stat-label">Total Records</div>
            </div>
        </div>

        <div class="ho-stat-card st-planned">
            <div class="ho-stat-icon">🗓</div>
            <div>
                <div class="ho-stat-value"><?= (int)$status_counts['Planned'] ?></div>
                <div class="ho-stat-label">Planned</div>
            </div>
        </div>

        <div class="ho-stat-card st-inprogress">
            <div class="ho-stat-icon">⏳</div>
            <div>
                <div class="ho-stat-value"><?= (int)$status_counts['In Progress'] ?></div>
                <div class="ho-stat-label">In Progress</div>
            </div>
        </div>

        <div class="ho-stat-card st-completed">
            <div class="ho-stat-icon">✅</div>
            <div>
                <div class="ho-stat-value"><?= (int)$status_counts['Completed'] ?></div>
                <div class="ho-stat-label">Completed</div>
            </div>
        </div>

        <div class="ho-stat-card st-delayed">
            <div class="ho-stat-icon">⚠️</div>
            <div>
                <div class="ho-stat-value"><?= (int)$status_counts['Delayed'] ?></div>
                <div class="ho-stat-label">Delayed</div>
            </div>
        </div>

    </div>


    <?php if ($success_msg): ?>

        <div class="ho-alert success">
            <?= htmlspecialchars($success_msg) ?>
        </div>

    <?php endif; ?>


    <?php if ($error_msg): ?>

        <div class="ho-alert error">
            <?= htmlspecialchars($error_msg) ?>
        </div>

    <?php endif; ?>


    <!-- Search Panel -->
    <div class="panel">
        <div style="padding:20px 22px;">
            <div class="ho-toolbar-head">
                <h3 class="panel-title">Search &amp; Filters</h3>
                <button
                    type="button"
                    class="ho-toolbar-link"
                    onclick="toggleAdvancedSearch()"
                >
                    Search Multiple Values &#9662;
                </button>
            </div>

            <div class="ho-toolbar-row">
            <form
                method="GET"
                action="handover.php"
                class="ho-search-row"
            >
                <div class="ho-search-input-wrap">
                    <span class="ho-search-icon">🔍</span>
                    <input
                        type="text"
                        name="keyword"
                        class="form-control"
                        placeholder="Search project, owner, ID..."
                        value="<?php
                        echo htmlspecialchars(
                            $keyword,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>"
                    >
                </div>

                <div class="ho-status-chips">
                    <?php
                    $chip_statuses = ['' => 'All', 'Planned' => 'Planned', 'In Progress' => 'In Progress', 'Completed' => 'Completed', 'Delayed' => 'Delayed'];
                    foreach ($chip_statuses as $chip_value => $chip_label):
                        $chip_params = ['s_status' => $chip_value];
                        if ($keyword !== '') $chip_params['keyword'] = $keyword;
                        $chip_url = 'handover.php?' . http_build_query($chip_params);
                    ?>
                        <a
                            href="<?= htmlspecialchars($chip_url) ?>"
                            class="ho-chip <?= $s_status === $chip_value ? 'active' : '' ?>"
                        >
                            <?= htmlspecialchars($chip_label) ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Search
                </button>
                <?php if (
                    $keyword !== '' ||
                    $s_project_name !== '' ||
                    $s_current_owner !== '' ||
                    $s_new_owner !== '' ||
                    $s_status !== ''
                ): ?>
                    <a
                        href="handover.php"
                        class="btn"
                    >
                        Clear
                    </a>
                <?php endif; ?>
            </form>

            <?= pageSizeSelectorHtml($page_size, $hidden_filter_fields) ?>
            </div>

            <div
                id="advancedSearchPanel"
                class="ho-advanced-panel"
                style="display:<?php
                    echo (
                        $s_project_name !== '' ||
                        $s_current_owner !== '' ||
                        $s_new_owner !== ''
                    )
                        ? 'block'
                        : 'none';
                ?>;"
            >
                <form
                    method="GET"
                    action="handover.php"
                    class="ho-advanced-grid"
                >
                    <div class="form-group">
                        <label>Project Name</label>
                        <input type="text" name="s_project_name" class="form-control" placeholder="Project..." value="<?= htmlspecialchars($s_project_name, ENT_QUOTES, 'UTF-8') ?>">
                    </div>

                    <div class="form-group">
                        <label>Current Owner</label>
                        <input type="text" name="s_current_owner" class="form-control" placeholder="Owner..." value="<?= htmlspecialchars($s_current_owner, ENT_QUOTES, 'UTF-8') ?>">
                    </div>

                    <div class="form-group">
                        <label>New Owner</label>
                        <input type="text" name="s_new_owner" class="form-control" placeholder="New Owner..." value="<?= htmlspecialchars($s_new_owner, ENT_QUOTES, 'UTF-8') ?>">
                    </div>

                    <div class="form-group">
                        <label>Status</label>
                        <select name="s_status" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="Planned" <?= $s_status === 'Planned' ? 'selected' : '' ?>>Planned</option>
                            <option value="In Progress" <?= $s_status === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                            <option value="Completed" <?= $s_status === 'Completed' ? 'selected' : '' ?>>Completed</option>
                            <option value="Delayed" <?= $s_status === 'Delayed' ? 'selected' : '' ?>>Delayed</option>
                        </select>
                    </div>

                    <div class="ho-advanced-actions">
                        <button type="submit" class="btn btn-primary" style="flex: 1; min-width: 120px;">
                            🔍 Apply Filters
                        </button>
                        <a href="handover.php" class="btn" style="flex: 1; min-width: 120px; text-align: center;">
                            ↺ Reset
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Existing Handovers -->

    <div
        class="panel"
        style="padding:0;">

        <div class="panel-header">
            <span class="panel-title">Project Handovers</span>
            <span style="color:var(--text-muted);font-size:13px;"><?php echo (int)$total_records; ?> total</span>
        </div>

        <div class="ho-table-wrap">

            <table class="ho-table">

                <thead>

                    <tr>
                        <th>
                            <a href="handover.php?sort_by=project_name&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Project Name
                                <?php if ($sort_by === 'project_name'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="handover.php?sort_by=current_owner&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Current Owner
                                <?php if ($sort_by === 'current_owner'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="handover.php?sort_by=new_owner&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                New Owner
                                <?php if ($sort_by === 'new_owner'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="handover.php?sort_by=handover_date&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Date
                                <?php if ($sort_by === 'handover_date'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="handover.php?sort_by=handover_status&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Status
                                <?php if ($sort_by === 'handover_status'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>KT</th>
                        <th>Access</th>
                        <th>
                            <a href="handover.php?sort_by=last_updated&sort_dir=<?php echo $next_sort_dir; ?>&page=1&keyword=<?php echo urlencode($keyword); ?>&s_project_name=<?php echo urlencode($s_project_name); ?>&s_current_owner=<?php echo urlencode($s_current_owner); ?>&s_new_owner=<?php echo urlencode($s_new_owner); ?>&s_status=<?php echo urlencode($s_status); ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Last Updated
                                <?php if ($sort_by === 'last_updated'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th style="text-align: center;">Actions</th>
                    </tr>

                </thead>


                <tbody>

                    <?php if (empty($handovers)): ?>

                        <tr>
                            <td colspan="9">
                                <div class="ho-empty-state">
                                    <div class="ho-empty-icon">🔄</div>
                                    <div class="ho-empty-title">No handover records found</div>
                                    <div class="ho-empty-sub">
                                        <?= ($keyword !== '' || $s_project_name !== '' || $s_current_owner !== '' || $s_new_owner !== '' || $s_status !== '')
                                            ? 'No records match your current search or filters. Try clearing them.'
                                            : 'Get started by creating your first project handover record.' ?>
                                    </div>
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="ho-btn ho-btn-primary" onclick="openCreateModal()">+ Add Record</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>

                    <?php else: ?>


                        <?php foreach ($handovers as $h):

                            $att_query = $pdo->prepare("
                                SELECT *
                                FROM handover_attachments
                                WHERE handover_id = ?
                            ");

                            $att_query->execute([$h['id']]);

                            $attachments =
                                $att_query->fetchAll(PDO::FETCH_ASSOC);


                            /*
                             * Permissions are now controlled only
                             * by can_edit / can_delete.
                             */

                            $can_modify_row = $canEdit;
                            $can_delete_row = $canDelete;


                            $status_class = 'st-planned';

                            switch ($h['handover_status']) {

                                case 'In Progress':
                                    $status_class = 'st-inprogress';
                                    break;

                                case 'Completed':
                                    $status_class = 'st-completed';
                                    break;

                                case 'Delayed':
                                    $status_class = 'st-delayed';
                                    break;
                            }

                        ?>

                            <tr>

                                <td>
                                    <div class="ho-cell-primary"><?= htmlspecialchars($h['project_name']) ?></div>
                                    <?php if (!empty($h['project_id'])): ?>
                                        <div class="ho-cell-sub"><?= htmlspecialchars($h['project_id']) ?></div>
                                    <?php endif; ?>
                                </td>

                                <td>
                                    <div class="ho-owner">
                                        <span class="ho-owner-avatar"><?= htmlspecialchars(ho_initials($h['current_owner'])) ?></span>
                                        <span class="ho-owner-name"><?= htmlspecialchars($h['current_owner']) ?></span>
                                    </div>
                                </td>

                                <td>
                                    <div class="ho-owner">
                                        <span class="ho-transfer-arrow">→</span>
                                        <span class="ho-owner-avatar"><?= htmlspecialchars(ho_initials($h['new_owner'])) ?></span>
                                        <span class="ho-owner-name"><?= htmlspecialchars($h['new_owner']) ?></span>
                                    </div>
                                </td>

                                <td>

                                    <span
                                        class="ho-badge <?= $status_class ?>">
                                        <?= htmlspecialchars(
                                            $h['handover_status']
                                        ) ?>
                                    </span>

                                    <?php
                                    /* Publication scope, so it is obvious at a
                                       glance who a record is visible to. */
                                    $ho_vis = $h['visibility'] ?? 'public';
                                    $ho_shared_names = $h['shared_teams'] ?? [];
                                    $ho_vis_title = $ho_vis === 'teams'
                                        ? 'Shared with: ' . implode(', ', $ho_shared_names)
                                        : ($ho_vis === 'team'
                                            ? 'Team: ' . ($h['owner_team'] ?: '(unset)')
                                            : 'Visible to everyone with access to this page');
                                    ?>
                                    <span class="ho-vis-badge vis-<?= htmlspecialchars($ho_vis) ?>"
                                          title="<?= htmlspecialchars($ho_vis_title) ?>">
                                        <?= htmlspecialchars(HANDOVER_VISIBILITIES[$ho_vis] ?? $ho_vis) ?><?php
                                        if ($ho_vis === 'teams' && $ho_shared_names) {
                                            echo ' (' . count($ho_shared_names) . ')';
                                        } ?>
                                    </span>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $h['project_phase'] ?: '-'
                                    ) ?>
                                </td>

                                <td>

                                    <span
                                        class="ho-pill <?= $h['kt_completed'] === 'Yes'
                                            ? 'yes'
                                            : 'no' ?>">
                                        <?= $h['kt_completed'] === 'Yes' ? '✓' : '–' ?>
                                        <?= htmlspecialchars(
                                            $h['kt_completed']
                                        ) ?>
                                    </span>

                                </td>

                                <td>

                                    <span
                                        class="ho-pill <?= $h['access_transferred'] === 'Yes'
                                            ? 'yes'
                                            : 'no' ?>">
                                        <?= $h['access_transferred'] === 'Yes' ? '✓' : '–' ?>
                                        <?= htmlspecialchars(
                                            $h['access_transferred']
                                        ) ?>
                                    </span>

                                </td>

                                <td>
                                    <?= htmlspecialchars(
                                        $h['last_updated']
                                    ) ?>
                                </td>

                                <td style="text-align: center; white-space: nowrap;">
                                    <div class="row-actions">
                                        <button type="button" class="btn btn-sm btn-secondary btn-icon" title="View" aria-label="View" onclick='openViewModal(<?= json_encode($h) ?>, <?= json_encode($attachments) ?>)'>👁</button>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-primary btn-icon" title="Edit" aria-label="Edit" onclick='openEditModal(<?= json_encode($h) ?>)'>✎</button>
                                        <?php endif; ?>
                                        <?php if ($canDelete): ?>
                                            <button type="button" class="btn btn-sm btn-danger btn-icon" title="Delete" aria-label="Delete" onclick="openDeleteModal(<?= $h['id'] ?>, '<?= htmlspecialchars(addslashes($h['project_name'])) ?>')">🗑</button>
                                        <?php endif; ?>
                                        <?php if ($canAudit): ?>
                                            <button type="button" class="btn btn-sm btn-warning btn-icon" title="Audit History" aria-label="Audit History" onclick="openRowHistoryModal(<?= $h['id'] ?>, '<?= htmlspecialchars($h['project_name']) ?>')">⏱</button>
                                        <?php endif; ?>
                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <?php if ($total_pages > 1): ?>
            <?php
            $page_link = function ($p) use ($keyword, $s_project_name, $s_current_owner, $s_new_owner, $s_status, $sort_by, $sort_dir) {
                return 'handover.php?page=' . $p . '&keyword=' . urlencode($keyword) . '&s_project_name=' . urlencode($s_project_name) . '&s_current_owner=' . urlencode($s_current_owner) . '&s_new_owner=' . urlencode($s_new_owner) . '&s_status=' . urlencode($s_status) . '&sort_by=' . urlencode($sort_by) . '&sort_dir=' . urlencode($sort_dir);
            };
            ?>
            <?= ivPager($page, $total_pages, [], [
                'base'          => 'handover.php',
                'link'          => $page_link,
                'total_records' => $total_records ?? null,
                'per_page'      => $limit ?? null,
            ]) ?>
        <?php endif; ?>
    </div>

</div>


<!-- =========================================================
     DELETE CONFIRMATION MODAL
========================================================= -->

<div id="deleteModal" class="ho-modal">

    <div class="ho-modal-content">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2 class="ho-modal-title">🗑 Confirm Deletion</h2>
                <div class="ho-modal-head-sub">This action cannot be undone.</div>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeDeleteModal()">
                &times;
            </button>
        </div>

        <form method="POST" id="deleteForm">

            <div class="ho-modal-body">
                <p>
                    Are you sure you want to delete this handover record for
                    <strong id="del_project_name"></strong>?
                </p>
            </div>

            <div class="ho-modal-footer">

                <input
                    type="hidden"
                    name="action"
                    value="delete_handover">

                <input
                    type="hidden"
                    name="handover_id"
                    id="del_handover_id">

                <button
                    type="button"
                    class="ho-btn ho-btn-ghost"
                    onclick="closeDeleteModal()">
                    Cancel
                </button>

                <button
                    type="submit"
                    class="ho-btn ho-btn-danger">
                    Delete
                </button>

            </div>

        </form>

    </div>

</div>


<!-- =========================================================
     IMPORT CSV MODAL
========================================================= -->

<div id="importModal" class="ho-modal">

    <div class="ho-modal-content">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2 class="ho-modal-title">⬆ Import Handover CSV</h2>
                <div class="ho-modal-head-sub">Bulk-create handover records from a spreadsheet export.</div>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeImportModal()">
                &times;
            </button>
        </div>

        <form
            action="handover-import.php"
            method="POST"
            enctype="multipart/form-data">

            <div class="ho-modal-body">
                <div class="form-group">
                    <label class="form-label">CSV File</label>
                    <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv" required>
                </div>

                <div class="form-group">
                    <label class="form-label">Expected Columns</label>
                    <code style="display: block; background: var(--table-header-bg); color: var(--text-secondary); padding: 12px; border-radius: 8px; overflow-x: auto; font-size: 12px; border: 1px solid var(--border-light);">
project_name,project_id,current_owner,new_owner,handover_date,handover_status,reason_for_handover,project_phase,documentation_status
                    </code>
                </div>
            </div>

            <div class="ho-modal-footer">
                <button type="button" class="ho-btn ho-btn-ghost" onclick="closeImportModal()">Cancel</button>
                <button type="submit" class="ho-btn ho-btn-primary">Upload</button>
            </div>

        </form>

    </div>

</div>


<!-- =========================================================
     CREATE HANDOVER MODAL
========================================================= -->

<?php if ($canEdit): ?>

<div id="createModal" class="ho-modal">

    <div class="ho-modal-content ho-modal-wide">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2 class="ho-modal-title">Create New Project Handover</h2>
                <div class="ho-modal-head-sub">Document an ownership transition end-to-end.</div>
            </div>
            <button
                type="button"
                class="ho-modal-close"
                onclick="closeCreateModal()">
                &times;
            </button>
        </div>


        <form
            method="POST"
            enctype="multipart/form-data">

            <input
                type="hidden"
                name="action"
                value="create_handover">

            <div class="ho-modal-body">

            <div class="ho-modal-section">
            <div class="ho-modal-section-title">👁 Visible To</div>
            <div class="ho-vis-row">
                <?php foreach (HANDOVER_VISIBILITIES as $vKey => $vLabel): ?>
                    <label class="ho-vis-opt">
                        <input type="radio" name="visibility" value="<?= htmlspecialchars($vKey) ?>"
                               <?= $vKey === 'public' ? 'checked' : '' ?>
                               onchange="hoVisChanged(this.form)">
                        <span><?= htmlspecialchars($vLabel) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <p class="ho-vis-hint" data-role="hoVisHint"></p>

            <div class="ho-team-picker" data-role="hoTeamPicker" style="display:none;">
                <label style="font-size:12px;font-weight:600;">Share with teams</label>
                <div class="ho-team-list">
                    <?php foreach ($handover_teams_list as $t): ?>
                        <label class="ho-team">
                            <input type="checkbox" name="shared_teams[]" value="<?= htmlspecialchars($t) ?>">
                            <span><?= htmlspecialchars($t) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            </div>

            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📋 Project &amp; Ownership</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Project Name <span class="req">*</span>
                    </label>

                    <input
                        type="text"
                        name="project_name"
                        placeholder="Name of the project"
                        required>

                </div>


                <div class="ho-field">

                    <label>
                        Project ID
                    </label>

                    <input
                        type="text"
                        name="project_id"
                        placeholder="Unique identifier">

                </div>


                <div class="ho-field">

                    <label>
                        Current Owner <span class="req">*</span>
                    </label>

                    <select
                        name="current_owner"
                        required>

                        <option value="">
                            -- Select Tech Owner --
                        </option>

                        <?php foreach ($tech_owners as $owner): ?>

                            <option
                                value="<?= htmlspecialchars($owner) ?>">
                                <?= htmlspecialchars($owner) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">🔄 Timeline &amp; Status</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        New Owner <span class="req">*</span>
                    </label>

                    <select
                        name="new_owner"
                        required>

                        <option value="">
                            -- Select Tech Owner --
                        </option>

                        <?php foreach ($tech_owners as $owner): ?>

                            <option
                                value="<?= htmlspecialchars($owner) ?>">
                                <?= htmlspecialchars($owner) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Handover Date
                    </label>

                    <input
                        type="date"
                        name="handover_date">

                </div>


                <div class="ho-field">

                    <label>
                        Handover Status
                    </label>

                    <select name="handover_status">

                        <option value="Planned">
                            Planned
                        </option>

                        <option value="In Progress">
                            In Progress
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="Delayed">
                            Delayed
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📄 Documentation &amp; Phase</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Reason for Handover
                    </label>

                    <input
                        type="text"
                        name="reason_for_handover"
                        placeholder="Project completion, team change, etc.">

                </div>


                <div class="ho-field">

                    <label>
                        Project Phase
                    </label>

                    <select name="project_phase">

                        <option value="Planning">
                            Planning
                        </option>

                        <option value="Execution">
                            Execution
                        </option>

                        <option value="Closing">
                            Closing
                        </option>

                        <option value="Operations">
                            Operations
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Documentation Status
                    </label>

                    <select name="documentation_status">

                        <option value="Complete">
                            Complete
                        </option>

                        <option value="Partial">
                            Partial
                        </option>

                        <option value="Missing">
                            Missing
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">⚠️ Risk &amp; Continuity</div>
            <div class="ho-form-grid cols-2">

                <div class="ho-field">

                    <label>
                        Open Issues
                    </label>

                    <textarea
                        name="open_issues"
                        rows="2"
                        placeholder="Outstanding risks or issues"></textarea>

                </div>


                <div class="ho-field">

                    <label>
                        Pending Actions
                    </label>

                    <textarea
                        name="pending_actions"
                        rows="2"
                        placeholder="Tasks to be completed after handover"></textarea>

                </div>

            </div>


            <div class="ho-form-grid cols-2">

                <div class="ho-field">

                    <label>
                        Risks
                    </label>

                    <textarea
                        name="risks"
                        rows="2"
                        placeholder="Known risks that the new owner should monitor"></textarea>

                </div>


                <div class="ho-field">

                    <label>
                        Dependencies
                    </label>

                    <textarea
                        name="dependencies"
                        rows="2"
                        placeholder="External teams, systems, or vendors involved"></textarea>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">✅ Transition Checklist</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Knowledge Transfer Completed
                    </label>

                    <select name="kt_completed">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Training Completed
                    </label>

                    <select name="training_completed">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Access Transferred
                    </label>

                    <select name="access_transferred">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">🤝 Sign-off &amp; Support</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Stakeholder Sign-off
                    </label>

                    <input
                        type="text"
                        name="stakeholder_signoff"
                        placeholder="Names and dates of approvals">

                </div>


                <div class="ho-field">

                    <label>
                        Customer/Client Notified
                    </label>

                    <select name="client_notified">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Warranty/Support Period
                    </label>

                    <input
                        type="text"
                        name="warranty_period"
                        placeholder="If applicable">

                </div>

            </div>

            <div
                class="ho-field"
                style="margin-bottom:0;">

                <label>
                    Notes
                </label>

                <textarea
                    name="notes"
                    rows="2"
                    placeholder="Additional comments or special instructions"></textarea>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📎 Attachments</div>

            <div class="ho-field">

                <label>
                    Attach Docs (Multiple)
                </label>

                <div class="ho-file-drop">
                    📄
                    <input
                        type="file"
                        name="attachments[]"
                        multiple>
                </div>

            </div>
            </div>

            </div>

            <div class="ho-modal-footer">

                <button
                    type="button"
                    class="ho-btn ho-btn-ghost"
                    onclick="closeCreateModal()">
                    Cancel
                </button>

                <button
                    type="submit"
                    class="ho-btn ho-btn-primary">
                    Create Handover Record
                </button>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


<!-- =========================================================
     VIEW MODAL
========================================================= -->

<div id="viewModal" class="ho-modal">

    <div class="ho-modal-content">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2
                    id="viewModalTitle"
                    class="ho-modal-title">
                    Project Handover Details
                </h2>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeViewModal()">
                &times;
            </button>
        </div>

        <div class="ho-modal-body">

            <div id="viewModalContentContainer"></div>

            <div class="ho-subheading">
                📎 Attached Documents
            </div>

            <div id="viewAttachmentsListContainer"></div>

        </div>

    </div>

</div>


<!-- =========================================================
     EDIT MODAL
========================================================= -->

<div id="editModal" class="ho-modal">

    <div class="ho-modal-content ho-modal-wide">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2 class="ho-modal-title">Modify Project Handover</h2>
                <div class="ho-modal-head-sub">Update ownership, status, and continuity details.</div>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeEditModal()">
                &times;
            </button>
        </div>


        <form
            method="POST"
            enctype="multipart/form-data">

            <input
                type="hidden"
                name="action"
                value="update_handover">

            <input
                type="hidden"
                name="handover_id"
                id="edit_handover_id">

            <div class="ho-modal-body">

            <div class="ho-modal-section">
            <div class="ho-modal-section-title">👁 Visible To</div>
            <div class="ho-vis-row">
                <?php foreach (HANDOVER_VISIBILITIES as $vKey => $vLabel): ?>
                    <label class="ho-vis-opt">
                        <input type="radio" name="visibility" value="<?= htmlspecialchars($vKey) ?>"
                               id="edit_visibility_<?= htmlspecialchars($vKey) ?>"
                               onchange="hoVisChanged(this.form)">
                        <span><?= htmlspecialchars($vLabel) ?></span>
                    </label>
                <?php endforeach; ?>
            </div>
            <p class="ho-vis-hint" data-role="hoVisHint"></p>

            <div class="ho-team-picker" data-role="hoTeamPicker" style="display:none;">
                <label style="font-size:12px;font-weight:600;">Share with teams</label>
                <div class="ho-team-list">
                    <?php foreach ($handover_teams_list as $t): ?>
                        <label class="ho-team">
                            <input type="checkbox" name="shared_teams[]" value="<?= htmlspecialchars($t) ?>"
                                   data-edit-team="<?= htmlspecialchars($t) ?>">
                            <span><?= htmlspecialchars($t) ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
            </div>

            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📋 Project &amp; Ownership</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Project Name <span class="req">*</span>
                    </label>

                    <input
                        type="text"
                        name="project_name"
                        id="edit_project_name"
                        required>

                </div>


                <div class="ho-field">

                    <label>
                        Project ID
                    </label>

                    <input
                        type="text"
                        name="project_id"
                        id="edit_project_id">

                </div>


                <div class="ho-field">

                    <label>
                        Current Owner *
                    </label>

                    <select
                        name="current_owner"
                        id="edit_current_owner"
                        required>

                        <option value="">
                            -- Select Tech Owner --
                        </option>

                        <?php foreach ($tech_owners as $owner): ?>

                            <option
                                value="<?= htmlspecialchars($owner) ?>">
                                <?= htmlspecialchars($owner) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">🔄 Timeline &amp; Status</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        New Owner <span class="req">*</span>
                    </label>

                    <select
                        name="new_owner"
                        id="edit_new_owner"
                        required>

                        <option value="">
                            -- Select Tech Owner --
                        </option>

                        <?php foreach ($tech_owners as $owner): ?>

                            <option
                                value="<?= htmlspecialchars($owner) ?>">
                                <?= htmlspecialchars($owner) ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Handover Date
                    </label>

                    <input
                        type="date"
                        name="handover_date"
                        id="edit_handover_date">

                </div>


                <div class="ho-field">

                    <label>
                        Handover Status
                    </label>

                    <select
                        name="handover_status"
                        id="edit_handover_status">

                        <option value="Planned">
                            Planned
                        </option>

                        <option value="In Progress">
                            In Progress
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="Delayed">
                            Delayed
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📄 Documentation &amp; Phase</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Reason for Handover
                    </label>

                    <input
                        type="text"
                        name="reason_for_handover"
                        id="edit_reason_for_handover">

                </div>


                <div class="ho-field">

                    <label>
                        Project Phase
                    </label>

                    <select
                        name="project_phase"
                        id="edit_project_phase">

                        <option value="Planning">
                            Planning
                        </option>

                        <option value="Execution">
                            Execution
                        </option>

                        <option value="Closing">
                            Closing
                        </option>

                        <option value="Operations">
                            Operations
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Documentation Status
                    </label>

                    <select
                        name="documentation_status"
                        id="edit_documentation_status">

                        <option value="Complete">
                            Complete
                        </option>

                        <option value="Partial">
                            Partial
                        </option>

                        <option value="Missing">
                            Missing
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">⚠️ Risk &amp; Continuity</div>
            <div class="ho-form-grid cols-2">

                <div class="ho-field">

                    <label>
                        Open Issues
                    </label>

                    <textarea
                        name="open_issues"
                        id="edit_open_issues"
                        rows="2"></textarea>

                </div>


                <div class="ho-field">

                    <label>
                        Pending Actions
                    </label>

                    <textarea
                        name="pending_actions"
                        id="edit_pending_actions"
                        rows="2"></textarea>

                </div>

            </div>


            <div class="ho-form-grid cols-2">

                <div class="ho-field">

                    <label>
                        Risks
                    </label>

                    <textarea
                        name="risks"
                        id="edit_risks"
                        rows="2"></textarea>

                </div>


                <div class="ho-field">

                    <label>
                        Dependencies
                    </label>

                    <textarea
                        name="dependencies"
                        id="edit_dependencies"
                        rows="2"></textarea>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">✅ Transition Checklist</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Knowledge Transfer Completed
                    </label>

                    <select
                        name="kt_completed"
                        id="edit_kt_completed">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Training Completed
                    </label>

                    <select
                        name="training_completed"
                        id="edit_training_completed">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Access Transferred
                    </label>

                    <select
                        name="access_transferred"
                        id="edit_access_transferred">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">🤝 Sign-off &amp; Support</div>
            <div class="ho-form-grid">

                <div class="ho-field">

                    <label>
                        Stakeholder Sign-off
                    </label>

                    <input
                        type="text"
                        name="stakeholder_signoff"
                        id="edit_stakeholder_signoff">

                </div>


                <div class="ho-field">

                    <label>
                        Customer/Client Notified
                    </label>

                    <select
                        name="client_notified"
                        id="edit_client_notified">

                        <option value="No">
                            No
                        </option>

                        <option value="Yes">
                            Yes
                        </option>

                    </select>

                </div>


                <div class="ho-field">

                    <label>
                        Warranty/Support Period
                    </label>

                    <input
                        type="text"
                        name="warranty_period"
                        id="edit_warranty_period">

                </div>

            </div>

            <div
                class="ho-field"
                style="margin-bottom:0;">

                <label>
                    Notes
                </label>

                <textarea
                    name="notes"
                    id="edit_notes"
                    rows="2"></textarea>

            </div>
            </div>


            <div class="ho-modal-section">
            <div class="ho-modal-section-title">📎 Attachments</div>

            <div class="ho-field">

                <label>
                    Attach More Docs
                </label>

                <div class="ho-file-drop">
                    📄
                    <input
                        type="file"
                        name="attachments[]"
                        multiple>
                </div>

            </div>
            </div>

            </div>

            <div class="ho-modal-footer">
                <button
                    type="button"
                    class="ho-btn ho-btn-ghost"
                    onclick="closeEditModal()">
                    Cancel
                </button>

                <button
                    type="submit"
                    class="ho-btn ho-btn-primary">
                    Update Handover Record
                </button>
            </div>

        </form>

    </div>

</div>


<!-- =========================================================
     GLOBAL HISTORY MODAL
========================================================= -->

<div id="globalHistoryModal" class="ho-modal">

    <div class="ho-modal-content ho-modal-wide">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2 class="ho-modal-title">⏱ Audit History</h2>
                <div class="ho-modal-head-sub">Every create, update, and delete across all handover records.</div>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeGlobalHistoryModal()">
                &times;
            </button>
        </div>

        <div id="globalHistoryContent" class="ho-modal-body">
            <p class="ho-empty">
                Loading audit trails...
            </p>
        </div>

    </div>

</div>


<!-- =========================================================
     HISTORY MODAL
========================================================= -->

<div id="historyModal" class="ho-modal">

    <div class="ho-modal-content ho-modal-wide">

        <div class="ho-modal-head">
            <div class="ho-modal-head-text">
                <h2
                    id="historyModalTitle"
                    class="ho-modal-title">
                    Audit History
                </h2>
            </div>
            <button
                class="ho-modal-close"
                onclick="closeHistoryModal()">
                &times;
            </button>
        </div>

        <div id="historyModalContent" class="ho-modal-body">
            <p class="ho-empty">
                Loading audit trails...
            </p>
        </div>

    </div>

</div>


<script>

    /*
    |--------------------------------------------------------------------------
    | CREATE MODAL
    |--------------------------------------------------------------------------
    */

    function openCreateModal() {
        document.getElementById('createModal').style.display = 'block';
    }


    function closeCreateModal() {
        document.getElementById('createModal').style.display = 'none';
    }


    /*
    |--------------------------------------------------------------------------
    | VIEW MODAL
    |--------------------------------------------------------------------------
    */

    function openViewModal(h, attachments) {

        document.getElementById('viewModalTitle').innerText =
            'Handover Details: ' +
            (h.project_name || '');


        const groups = [
            {
                title: '📋 Project &amp; Ownership',
                rows: [
                    ['Project Name', h.project_name],
                    ['Project ID', h.project_id],
                    ['Current Owner', h.current_owner],
                    ['New Owner', h.new_owner],
                ]
            },
            {
                title: '🔄 Timeline &amp; Status',
                rows: [
                    ['Handover Date', h.handover_date],
                    ['Handover Status', h.handover_status],
                    ['Last Updated', h.last_updated],
                ]
            },
            {
                title: '📄 Documentation &amp; Phase',
                rows: [
                    ['Reason for Handover', h.reason_for_handover],
                    ['Project Phase', h.project_phase],
                    ['Documentation Status', h.documentation_status],
                ]
            },
            {
                title: '⚠️ Risk &amp; Continuity',
                rows: [
                    ['Open Issues', h.open_issues],
                    ['Pending Actions', h.pending_actions],
                    ['Risks', h.risks],
                    ['Dependencies', h.dependencies],
                ]
            },
            {
                title: '✅ Transition Checklist',
                rows: [
                    ['Knowledge Transfer Completed', h.kt_completed],
                    ['Training Completed', h.training_completed],
                    ['Access Transferred', h.access_transferred],
                ]
            },
            {
                title: '🤝 Sign-off &amp; Support',
                rows: [
                    ['Stakeholder Sign-off', h.stakeholder_signoff],
                    ['Customer/Client Notified', h.client_notified],
                    ['Warranty/Support Period', h.warranty_period],
                    ['Notes', h.notes],
                ]
            },
        ];


        let detailsHtml = '';

        groups.forEach(group => {

            let rowsHtml = '';

            group.rows.forEach(([label, value]) => {
                rowsHtml +=
                    `<div class="ho-detail-row">
                        <div class="ho-detail-label">
                            ${label}
                        </div>
                        <div class="ho-detail-value">
                            ${value || '-'}
                        </div>
                    </div>`;
            });

            detailsHtml +=
                `<div class="ho-modal-section">
                    <div class="ho-modal-section-title">${group.title}</div>
                    ${rowsHtml}
                </div>`;

        });


        document.getElementById(
            'viewModalContentContainer'
        ).innerHTML = detailsHtml;


        let attContainer =
            document.getElementById(
                'viewAttachmentsListContainer'
            );


        attContainer.innerHTML = '';


        if (!attachments || attachments.length === 0) {

            attContainer.innerHTML =
                '<p class="ho-file-empty">' +
                'No documents attached to this handover record.' +
                '</p>';

        } else {

            let listHtml = '';


            attachments.forEach(att => {

                listHtml +=
                    `<a
                        href="${att.filepath}"
                        class="ho-file-chip"
                        target="_blank">
                        📄 ${att.filename}
                    </a>`;

            });


            attContainer.innerHTML = listHtml;
        }


        document.getElementById(
            'viewModal'
        ).style.display = 'block';
    }


    function closeViewModal() {
        document.getElementById(
            'viewModal'
        ).style.display = 'none';
    }


    /*
    |--------------------------------------------------------------------------
    | EDIT MODAL
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | VISIBILITY PICKER
    |--------------------------------------------------------------------------
    |
    | Scoped to the form it is called with, because the create and edit
    | modals each carry their own copy of the control.
    */

    var HO_VIS_HINT = {
        team:   <?= json_encode($user_team !== ''
                    ? 'Everyone in ' . $user_team . ' can see this handover.'
                    : 'You are not assigned to a team — ask an administrator before using this.') ?>,
        teams:  'Only the teams ticked below can see this handover.',
        public: 'Anyone who can open the Handover page can see this.'
    };

    function hoVisChanged(form) {
        if (!form) { return; }

        var picked = form.querySelector('input[name="visibility"]:checked');
        var value  = picked ? picked.value : 'public';

        var picker = form.querySelector('[data-role="hoTeamPicker"]');
        if (picker) { picker.style.display = (value === 'teams') ? '' : 'none'; }

        var hint = form.querySelector('[data-role="hoVisHint"]');
        if (hint) { hint.textContent = HO_VIS_HINT[value] || ''; }
    }

    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('input[name="visibility"]:checked').forEach(function (r) {
            hoVisChanged(r.form);
        });
    });

    function openEditModal(h) {

        document.getElementById(
            'edit_handover_id'
        ).value = h.id;


        /* Visibility: select the record's scope, tick the teams it is
           shared with, then let hoVisChanged show or hide the picker.
           h.shared_teams is attached server-side alongside the row. */
        var vis = h.visibility || 'public';
        var visRadio = document.getElementById('edit_visibility_' + vis);
        if (visRadio) { visRadio.checked = true; }

        var shared = Array.isArray(h.shared_teams) ? h.shared_teams : [];
        document.querySelectorAll('[data-edit-team]').forEach(function (cb) {
            cb.checked = shared.indexOf(cb.value) !== -1;
        });

        if (visRadio && visRadio.form) { hoVisChanged(visRadio.form); }


        document.getElementById(
            'edit_project_name'
        ).value = h.project_name || '';


        document.getElementById(
            'edit_project_id'
        ).value = h.project_id || '';


        document.getElementById(
            'edit_current_owner'
        ).value = h.current_owner || '';


        document.getElementById(
            'edit_new_owner'
        ).value = h.new_owner || '';


        document.getElementById(
            'edit_handover_date'
        ).value = h.handover_date || '';


        document.getElementById(
            'edit_handover_status'
        ).value = h.handover_status || 'Planned';


        document.getElementById(
            'edit_reason_for_handover'
        ).value = h.reason_for_handover || '';


        document.getElementById(
            'edit_project_phase'
        ).value = h.project_phase || 'Planning';


        document.getElementById(
            'edit_documentation_status'
        ).value = h.documentation_status || 'Complete';


        document.getElementById(
            'edit_open_issues'
        ).value = h.open_issues || '';


        document.getElementById(
            'edit_pending_actions'
        ).value = h.pending_actions || '';


        document.getElementById(
            'edit_risks'
        ).value = h.risks || '';


        document.getElementById(
            'edit_dependencies'
        ).value = h.dependencies || '';


        document.getElementById(
            'edit_kt_completed'
        ).value = h.kt_completed || 'No';


        document.getElementById(
            'edit_training_completed'
        ).value = h.training_completed || 'No';


        document.getElementById(
            'edit_access_transferred'
        ).value = h.access_transferred || 'No';


        document.getElementById(
            'edit_stakeholder_signoff'
        ).value = h.stakeholder_signoff || '';


        document.getElementById(
            'edit_client_notified'
        ).value = h.client_notified || 'No';


        document.getElementById(
            'edit_warranty_period'
        ).value = h.warranty_period || '';


        document.getElementById(
            'edit_notes'
        ).value = h.notes || '';


        document.getElementById(
            'editModal'
        ).style.display = 'block';
    }


    function closeEditModal() {

        document.getElementById(
            'editModal'
        ).style.display = 'none';

    }


    /*
    |--------------------------------------------------------------------------
    | HISTORY MODAL
    |--------------------------------------------------------------------------
    */

    function openHistoryModal(handoverId) {

        document.getElementById(
            'historyModal'
        ).style.display = 'block';


        document.getElementById(
            'historyModalTitle'
        ).innerText = handoverId
            ? 'Record Audit History (#' + handoverId + ')'
            : 'Module Audit History';


        document.getElementById(
            'historyModalContent'
        ).innerHTML =
            '<p class="ho-empty">Loading audit history...</p>';


        const url = handoverId
            ? 'handover.php?action=get_history&id=' +
              encodeURIComponent(handoverId)
            : 'handover.php?action=get_history';


        fetch(url)

            .then(res => res.text())

            .then(html => {

                document.getElementById(
                    'historyModalContent'
                ).innerHTML = html;

            })

            .catch(() => {

                document.getElementById(
                    'historyModalContent'
                ).innerHTML =
                    '<p class="ho-empty" style="color:#DC2626;">' +
                    'Failed to load audit history.' +
                    '</p>';

            });
    }


    function closeHistoryModal() {

        document.getElementById(
            'historyModal'
        ).style.display = 'none';

    }


    /*
    |--------------------------------------------------------------------------
    | CLOSE MODALS WHEN CLICKING OUTSIDE
    |--------------------------------------------------------------------------
    */

    /*
    |--------------------------------------------------------------------------
    | DELETE MODAL
    |--------------------------------------------------------------------------
    */

    function openDeleteModal(handoverId, projectName) {
        document.getElementById('del_handover_id').value = handoverId;
        document.getElementById('del_project_name').innerText = projectName;
        document.getElementById('deleteModal').style.display = 'block';
    }

    function closeDeleteModal() {
        document.getElementById('deleteModal').style.display = 'none';
    }


    /*
    |--------------------------------------------------------------------------
    | IMPORT MODAL
    |--------------------------------------------------------------------------
    */

    function openImportModal() {
        document.getElementById('importModal').style.display = 'block';
    }

    function closeImportModal() {
        document.getElementById('importModal').style.display = 'none';
    }


    /*
    |--------------------------------------------------------------------------
    | GLOBAL HISTORY MODAL
    |--------------------------------------------------------------------------
    */

    function openGlobalHistoryModal() {
        document.getElementById('globalHistoryModal').style.display = 'block';
        document.getElementById('globalHistoryContent').innerHTML = '<p class="ho-empty">Loading audit trails...</p>';
        fetch('handover.php?action=get_history')
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="ho-empty" style="color:#DC2626;">Failed to load audit history.</p>'; });
    }

    function closeGlobalHistoryModal() {
        document.getElementById('globalHistoryModal').style.display = 'none';
    }


    /*
    |--------------------------------------------------------------------------
    | ROW HISTORY MODAL
    |--------------------------------------------------------------------------
    */

    function openRowHistoryModal(recordId, projectName) {
        document.getElementById('historyModal').style.display = 'block';
        document.getElementById('historyModalTitle').innerText = 'Record Audit History (#' + recordId + ')';
        document.getElementById('historyModalContent').innerHTML = '<p class="ho-empty">Loading audit history...</p>';
        fetch(`handover.php?action=get_history&id=${recordId}`)
            .then(res => res.text())
            .then(html => { document.getElementById('historyModalContent').innerHTML = html; })
            .catch(() => { document.getElementById('historyModalContent').innerHTML = '<p class="ho-empty" style="color:#DC2626;">Failed to load audit history.</p>'; });
    }


    /*
    |--------------------------------------------------------------------------
    | TOGGLE ADVANCED SEARCH
    |--------------------------------------------------------------------------
    */

    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CLOSE MODALS WHEN CLICKING OUTSIDE
    |--------------------------------------------------------------------------
    */

    window.addEventListener('click', function (event) {

        const createModal =
            document.getElementById('createModal');

        const editModal =
            document.getElementById('editModal');

        const viewModal =
            document.getElementById('viewModal');

        const historyModal =
            document.getElementById('historyModal');

        const deleteModal =
            document.getElementById('deleteModal');

        const importModal =
            document.getElementById('importModal');

        const globalHistoryModal =
            document.getElementById('globalHistoryModal');


        if (
            createModal &&
            event.target === createModal
        ) {
            createModal.style.display = 'none';
        }


        if (
            editModal &&
            event.target === editModal
        ) {
            editModal.style.display = 'none';
        }


        if (
            viewModal &&
            event.target === viewModal
        ) {
            viewModal.style.display = 'none';
        }


        if (
            historyModal &&
            event.target === historyModal
        ) {
            historyModal.style.display = 'none';
        }


        if (
            deleteModal &&
            event.target === deleteModal
        ) {
            deleteModal.style.display = 'none';
        }


        if (
            importModal &&
            event.target === importModal
        ) {
            importModal.style.display = 'none';
        }


        if (
            globalHistoryModal &&
            event.target === globalHistoryModal
        ) {
            globalHistoryModal.style.display = 'none';
        }

    });

</script>


<?php include 'includes/footer.php'; ?>
