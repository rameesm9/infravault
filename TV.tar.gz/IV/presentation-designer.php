<?php

require_once __DIR__ . '/config/db.php';

requireLogin();
requirePermission('presentation_designer', 'can_view');

$flags = authzFlags('presentation_designer');
$canExport = $flags['can_export'];
$canEdit   = $flags['can_edit'];
$canDelete = $flags['can_delete'];
$userId    = authzUserId();

const PD_DECK_TYPES = ['pptx', 'docx'];

/*
|--------------------------------------------------------------------------
| SAVE / LOAD API
|--------------------------------------------------------------------------
|
| The designer itself is entirely client-side; this is the one piece of
| server-side state it has -- a named, ordered deck (slides/pages, their
| field values, the header/footer config and the accent theme) saved as
| one JSON blob per (user, deck_type, name). Handled here, before any
| HTML is emitted, so a JSON response never has page markup mixed into it.
*/

if (isset($_REQUEST['pd_action'])) {
    header('Content-Type: application/json');
    $action = (string) $_REQUEST['pd_action'];

    if ($action === 'list') {
        $type = (string) ($_GET['deck_type'] ?? '');
        if (!in_array($type, PD_DECK_TYPES, true)) {
            echo json_encode(['ok' => false, 'error' => 'Unknown deck type.']);
            exit;
        }
        $stmt = $pdo->prepare("
            SELECT id, name, updated_at
            FROM presentation_designer_decks
            WHERE user_id = ? AND deck_type = ?
            ORDER BY updated_at DESC
        ");
        $stmt->execute([$userId, $type]);
        echo json_encode(['ok' => true, 'decks' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;
    }

    if ($action === 'load' || $action === 'most_recent') {
        $type = (string) ($_GET['deck_type'] ?? '');
        if (!in_array($type, PD_DECK_TYPES, true)) {
            echo json_encode(['ok' => false, 'error' => 'Unknown deck type.']);
            exit;
        }

        if ($action === 'load') {
            $id = (int) ($_GET['id'] ?? 0);
            $stmt = $pdo->prepare("SELECT id, name, data FROM presentation_designer_decks WHERE id = ? AND user_id = ? AND deck_type = ?");
            $stmt->execute([$id, $userId, $type]);
        } else {
            $stmt = $pdo->prepare("SELECT id, name, data FROM presentation_designer_decks WHERE user_id = ? AND deck_type = ? ORDER BY updated_at DESC LIMIT 1");
            $stmt->execute([$userId, $type]);
        }

        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$row) {
            echo json_encode(['ok' => true, 'deck' => null]);
            exit;
        }

        $decoded = json_decode($row['data']);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['ok' => false, 'error' => 'Saved deck is corrupted.']);
            exit;
        }

        echo json_encode(['ok' => true, 'deck' => ['id' => (int) $row['id'], 'name' => $row['name'], 'data' => $decoded]]);
        exit;
    }

    if ($action === 'save') {
        csrfVerifyOrDie();

        if (!$canEdit) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'You do not have edit permission for this page.']);
            exit;
        }

        $type = (string) ($_POST['deck_type'] ?? '');
        $name = trim((string) ($_POST['name'] ?? ''));
        $data = (string) ($_POST['data'] ?? '');

        if (!in_array($type, PD_DECK_TYPES, true) || $name === '' || $data === '') {
            echo json_encode(['ok' => false, 'error' => 'Missing name or content.']);
            exit;
        }

        if (strlen($name) > 200) {
            echo json_encode(['ok' => false, 'error' => 'Name is too long.']);
            exit;
        }

        // 12 MB ceiling: generous for a handful of embedded logos/photos,
        // but keeps one bad save from bloating the SQLite file unbounded.
        if (strlen($data) > 12 * 1024 * 1024) {
            echo json_encode(['ok' => false, 'error' => 'This deck is too large to save (images may be too big).']);
            exit;
        }

        json_decode($data);
        if (json_last_error() !== JSON_ERROR_NONE) {
            echo json_encode(['ok' => false, 'error' => 'Deck content is not valid.']);
            exit;
        }

        try {
            $existing = $pdo->prepare("SELECT id FROM presentation_designer_decks WHERE user_id = ? AND deck_type = ? AND name = ?");
            $existing->execute([$userId, $type, $name]);
            $id = $existing->fetchColumn();

            if ($id) {
                $pdo->prepare("UPDATE presentation_designer_decks SET data = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                    ->execute([$data, $id]);
            } else {
                $pdo->prepare("INSERT INTO presentation_designer_decks (user_id, deck_type, name, data) VALUES (?, ?, ?, ?)")
                    ->execute([$userId, $type, $name, $data]);
                $id = $pdo->lastInsertId();
            }
            echo json_encode(['ok' => true, 'id' => (int) $id]);
        } catch (Throwable $e) {
            error_log('presentation_designer save failed: ' . $e->getMessage());
            echo json_encode(['ok' => false, 'error' => 'Could not save right now.']);
        }
        exit;
    }

    if ($action === 'delete') {
        csrfVerifyOrDie();

        if (!$canDelete) {
            http_response_code(403);
            echo json_encode(['ok' => false, 'error' => 'You do not have delete permission for this page.']);
            exit;
        }

        $id = (int) ($_POST['id'] ?? 0);
        $pdo->prepare("DELETE FROM presentation_designer_decks WHERE id = ? AND user_id = ?")->execute([$id, $userId]);
        echo json_encode(['ok' => true]);
        exit;
    }

    echo json_encode(['ok' => false, 'error' => 'Unknown action.']);
    exit;
}

$page_title = 'Presentation & Document Designer | InfraVault';

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<link rel="stylesheet" href="assets/css/presentation-designer.css">

<?= csrfField() ?>
<input type="hidden" id="pdCsrfToken" value="<?= htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') ?>">
<input type="hidden" id="pdCanEdit" value="<?= $canEdit ? '1' : '0' ?>">
<input type="hidden" id="pdCanDelete" value="<?= $canDelete ? '1' : '0' ?>">

<div class="pd-page">

    <div class="pd-topbar">
        <div>
            <div class="pd-title">Presentation &amp; Document Designer</div>
            <div class="pd-subtitle">Enterprise slide and report templates &mdash; fully offline, exports real .pptx / .docx files</div>
        </div>

        <div class="pd-tabs">
            <button type="button" class="pd-tab" data-tab="pptx">Presentations</button>
            <button type="button" class="pd-tab" data-tab="docx">Documents</button>
        </div>

        <input type="text" class="pd-deck-name-input" id="pdDeckName" placeholder="Untitled Presentation" aria-label="Presentation or document name">

        <button type="button" class="pd-btn" id="pdNewBtn" title="Start a new, empty deck">New</button>

        <div class="pd-decks-menu">
            <button type="button" class="pd-btn" id="pdMyDecksBtn">My Saved Decks</button>
            <div class="pd-decks-dropdown" id="pdDecksDropdown" hidden></div>
        </div>

        <?php if ($canEdit): ?>
            <button type="button" class="pd-btn" id="pdSaveBtn">Save</button>
        <?php else: ?>
            <button type="button" class="pd-btn" disabled title="You do not have edit permission for this page">Save</button>
        <?php endif; ?>

        <div class="pd-topbar-spacer"></div>

        <div class="pd-theme-swatches" id="pdSwatches"></div>

        <?php if ($canExport): ?>
            <button type="button" class="pd-btn pd-btn-primary" id="pdExportBtn">Export File</button>
        <?php else: ?>
            <button type="button" class="pd-btn" disabled title="You do not have export permission for this page">Export File</button>
        <?php endif; ?>
    </div>

    <div class="pd-save-status" id="pdSaveStatus" hidden></div>

    <div class="pd-body">

        <div class="pd-gallery">
            <div class="pd-gallery-heading">Your Deck <span class="pd-count" id="pdDeckCount">0</span></div>
            <div id="pdDeckList"></div>

            <div class="pd-gallery-heading pd-gallery-heading-spaced">Add a Template</div>
            <div id="pdGalleryList"></div>
        </div>

        <div class="pd-stage" id="pdStage"></div>

        <div class="pd-form-panel">
            <div class="pd-form-tabs">
                <button type="button" class="pd-form-tab active" data-form-tab="item">Slide</button>
                <button type="button" class="pd-form-tab" data-form-tab="headerFooter">Header &amp; Footer</button>
            </div>
            <div class="pd-form" id="pdForm"></div>
        </div>

    </div>

</div>

<script src="assets/js/vendor/pptxgen.bundle.js"></script>
<script src="assets/js/vendor/docx.min.js"></script>
<script src="assets/js/presentation-designer.js"></script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
