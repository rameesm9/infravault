<?php
$current_page = basename($_SERVER['PHP_SELF']);
?>

<aside id="sidebar" class="sidebar" >

    <!-- =====================================================
         Sidebar Header
    ====================================================== -->

    <div class="sidebar-top">

        <button id="sidebarToggle" title="Toggle Sidebar">
            ☰
        </button>

        <img src="assets/images/infravault-logo.svg" alt="InfraVault">

        <span class="sidebar-title">
            InfraVault
        </span>

    </div>

    <nav>

        <!-- =====================================================
             Dashboard
        ====================================================== -->

        <a href="home.php"
           class="nav-item <?= $current_page == 'home.php' ? 'active' : ''; ?>">

            <span class="nav-icon">

                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor">

                    <path d="M3 13h8V3H3z"/>

                    <path d="M13 21h8v-8h-8z"/>

                    <path d="M13 3h8v6h-8z"/>

                    <path d="M3 17h8v4H3z"/>

                </svg>

            </span>

            <span class="nav-text">

                Dashboard

            </span>

        </a>

        <!-- =====================================================
             INVENTORY
        ====================================================== -->

        <div class="menu-group">

            <div class="menu-header"
                 onclick="toggleMenu(this)">

                <span class="nav-icon">

                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">

                        <path d="M21 16V8"/>

                        <path d="M3 8v8"/>

                        <path d="M12 3v18"/>

                        <path d="M3 8l9-5 9 5-9 5-9-5z"/>

                    </svg>

                </span>

                <span class="nav-text">

                    Inventory

                </span>

                <span class="arrow">

                    ▾

                </span>

            </div>

            <div class="submenu">

                <a href="asset.php">
                    <span class="nav-text">
                        Asset Management
                    </span>
                </a>

                <a href="inventory.php">
                    <span class="nav-text">
                        Server Inventory
                    </span>
                </a>

                <a href="#">
                    <span class="nav-text">
                        License Management
                    </span>
                </a>

                <a href="ip.php">
                    <span class="nav-text">
                        IP Address Management
                    </span>
                </a>

                <a href="ownership.php">
                    <span class="nav-text">
                        Asset Ownership
                    </span>
                </a>

                <a href="handover.php">
                    <span class="nav-text">
                        Asset Handover
                    </span>
                </a>

                <a href="decommission.php">
                    <span class="nav-text">
                        Asset Decommission
                    </span>
                </a>

                <a href="builds.php">
                    <span class="nav-text">
                        New Build
                    </span>
                </a>

                <a href="#">
                    <span class="nav-text">
                        Warranty Tracking
                    </span>
                </a>

                <a href="#">
                    <span class="nav-text">
                        Container Platform
                    </span>
                </a>

                <a href="#">
                    <span class="nav-text">
                        Major Layouts
                    </span>
                </a>

            </div>

        </div>
        <!-- =====================================================
             VULNERABILITY & CONTROLS
        ====================================================== -->

        <div class="menu-group">

            <div class="menu-header"
                 onclick="toggleMenu(this)">

                <span class="nav-icon">

                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">

                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>

                    </svg>

                </span>


                <span class="nav-text">

                    Vulnerability & Controls

                </span>


                <span class="arrow">

                    ▾

                </span>


            </div>



            <div class="submenu">


                <a href="#">

                    <span class="nav-text">
                        Quarterly Patching
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Critical Exploitable
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        GRC Schedule
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        DMZ Assessment
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Compliance
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Exception Register
                    </span>

                </a>


            </div>


        </div>








        <!-- =====================================================
             RUNBOOK
        ====================================================== -->


        <div class="menu-group">


            <div class="menu-header"
                 onclick="toggleMenu(this)">


                <span class="nav-icon">


                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">


                        <path d="M4 19h16"/>

                        <path d="M4 5h16"/>

                        <path d="M8 5v14"/>


                    </svg>


                </span>



                <span class="nav-text">

                    Runbook

                </span>



                <span class="arrow">

                    ▾

                </span>


            </div>





            <div class="submenu">


                <a href="#">

                    <span class="nav-text">
                        SOP
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Knowledge Base
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Known Issues
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        KT Documents
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Change Procedures
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Disaster Recovery
                    </span>

                </a>


                <a href="#">

                    <span class="nav-text">
                        Escalation Matrix
                    </span>

                </a>


            </div>


        </div>









        <!-- =====================================================
             MONITORING
        ====================================================== -->


        <div class="menu-group">


            <div class="menu-header"
                 onclick="toggleMenu(this)">


                <span class="nav-icon">


                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">


                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>


                    </svg>


                </span>



                <span class="nav-text">

                    Monitoring

                </span>



                <span class="arrow">

                    ▾

                </span>


            </div>




            <div class="submenu">


                <a href="#">

                    <span class="nav-text">
                        Splunk
                    </span>

                </a>



                <a href="#">

                    <span class="nav-text">
                        BMC CMDB
                    </span>

                </a>



                <a href="#">

                    <span class="nav-text">
                        Grafana
                    </span>

                </a>



            </div>


        </div>

        <!-- =====================================================
             OTHER DATA
        ====================================================== -->


        <div class="menu-group">


            <div class="menu-header"
                 onclick="toggleMenu(this)">


                <span class="nav-icon">


                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">


                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>

                        <circle cx="12" cy="7" r="4"/>


                    </svg>


                </span>



                <span class="nav-text">

                    Other Data

                </span>



                <span class="arrow">

                    ▾

                </span>


            </div>





            <div class="submenu">


                <a href="#">

                    <span class="nav-text">

                        My Data

                    </span>

                </a>


            </div>


        </div>










        <!-- =====================================================
             OPTIONS
        ====================================================== -->


        <div class="menu-group">


            <div class="menu-header"
                 onclick="toggleMenu(this)">


                <span class="nav-icon">


                    <svg viewBox="0 0 24 24"
                         fill="none"
                         stroke="currentColor">


                        <circle cx="12" cy="12" r="3"/>


                        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 0 1-4 0v-.2a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.6-1H3a2 2 0 0 1 0-4h.2a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.6V3a2 2 0 0 1 4 0v.2a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.6 1H21a2 2 0 0 1 0 4h-.2a1.7 1.7 0 0 0-1.4.8z"/>


                    </svg>


                </span>




                <span class="nav-text">

                    Options

                </span>



                <span class="arrow">

                    ▾

                </span>


            </div>






            <div class="submenu">


                <a href="#">

                    <span class="nav-text">

                        Notifications

                    </span>

                </a>




                <a href="reminders.php">

                    <span class="nav-text">

                        Reminders and Notes

                    </span>

                </a>





                <a href="myprofile.php">

                    <span class="nav-text">

                        My Profile

                    </span>

                </a>





                <a href="#">

                    <span class="nav-text">

                        Settings

                    </span>

                </a>





                <a href="users.php">

                    <span class="nav-text">

                        Manage Users

                    </span>

                </a>





                <a href="#">

                    <span class="nav-text">

                        Help Center

                    </span>

                </a>





                <a href="#">

                    <span class="nav-text">

                        About

                    </span>

                </a>



            </div>


        </div>




    </nav>


</aside>
