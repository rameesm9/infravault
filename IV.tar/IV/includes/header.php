<?php

if(session_status() === PHP_SESSION_NONE){
    session_start();
}


$page_title = $page_title ?? "InfraVault";

?>


<!DOCTYPE html>

<html lang="en">


<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
<?= htmlspecialchars($page_title); ?>
</title>



<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/header.css">

<link rel="stylesheet" href="assets/css/dashboard.css">


</head>



<body>




<header class="top-header">



<!-- LEFT BRAND -->


<div class="header-brand">







<div class="brand-subtitle">

Enterprise IT Management Platform




</div>


</div>








<!-- CENTER MENU -->


<nav class="header-navigation">


<a href="home.php"
class="active">

Dashboard

</a>


<a href="#">

Inventory

</a>


<a href="#">

Security

</a>


<a href="#">

Monitoring

</a>


<a href="#">

Reports

</a>


</nav>








<!-- RIGHT AREA -->


<div class="header-right">





<!-- SEARCH -->


<button class="header-button">


<svg viewBox="0 0 24 24">


<circle cx="11" cy="11" r="7"></circle>


<line x1="16.5" y1="16.5" x2="21" y2="21"></line>


</svg>


</button>







<!-- NOTIFICATION -->


<button class="header-button notification-btn">


<svg viewBox="0 0 24 24">


<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"></path>


<path d="M13 21h-2"></path>


</svg>


<span></span>


</button>









<!-- USER -->


<div class="header-user">



<div class="user-avatar">
<a href="myprofile.php"
>

<?= strtoupper(substr($_SESSION['name'] ?? 'A',0,1)); ?>


</div>





<div class="user-details">


<strong>

<?= htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?>

</strong>


<small>

<?= htmlspecialchars($_SESSION['role'] ?? 'Administrator'); ?>

</small>


</div>



</div>








<!-- SIGN OUT -->


<a href="logout.php" class="header-signout"
onclick="return confirm('Are you sure you want to sign out?');">
    <i class="fa-solid fa-right-from-bracket"></i>
<span>
Sign Out
</span>

</a>



</div>



</header>





<!-- PAGE START -->

<div class="main-container">
