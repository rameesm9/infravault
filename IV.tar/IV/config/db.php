<?php
// db.php
$db_file = __DIR__ . '/infravault.db';

try {
    $pdo = new PDO('sqlite:' . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create Users table
    $pdo->exec("CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ncgr_id TEXT UNIQUE NOT NULL,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        email TEXT NOT NULL,
        team TEXT NOT NULL,
        password TEXT NOT NULL,
        role TEXT DEFAULT 'Read-only',
        is_approved INTEGER DEFAULT 0
    )");

    // Safely insert default admin if not already present
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT OR IGNORE INTO users (ncgr_id, first_name, last_name, email, team, password, role, is_approved)
                         VALUES ('ADMIN001', 'System', 'Admin', 'admin@infravault.local', 'Cloud', ?, 'Admin', 1)");
    $stmt->execute([$hashed_password]);

    // Create Ownership Inventory Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS ownership (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project TEXT NOT NULL,
        support_level TEXT NOT NULL,
        technical_owner TEXT NOT NULL,
        technical_owner_email TEXT NOT NULL,
        team_dl TEXT NOT NULL,
        technical_manager TEXT NOT NULL,
        technical_manager_email TEXT NOT NULL,
        sdm_name TEXT NOT NULL,
        sdm_email TEXT NOT NULL,
        ncgr_owner TEXT NOT NULL,
        ncgr_owner_email TEXT NOT NULL,
        notes TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT,
        updated_at DATETIME
    )");
    
   $pdo->exec("CREATE TABLE IF NOT EXISTS audit_history (

        id INTEGER PRIMARY KEY AUTOINCREMENT,
       
        module TEXT NOT NULL,
       
        record_id INTEGER NOT NULL,
       
        action TEXT NOT NULL,
       
        performed_by TEXT NOT NULL,
       
        details TEXT,
       
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP

     )");

    // Create Asset Inventory Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS asset (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_name TEXT NOT NULL,
        asset_type TEXT NOT NULL,
        manufacturer TEXT,
        model TEXT,
        serial_number TEXT,
        service_tag TEXT,
        hostname TEXT,
        ip_address TEXT,
        location TEXT,
        site TEXT,
        region TEXT,
        room TEXT,
        row TEXT,
        rack TEXT,
        cpu_model TEXT,
        cpu_count TEXT,
        total_cores TEXT,
        memory_gb TEXT,
        internal_storage TEXT,
        number_of_nics TEXT,
        hba_details TEXT,
        gpu_details TEXT,
        vlan TEXT,
        purchase_date TEXT,
        vendor TEXT,
        warranty_start_date TEXT,
        warranty_expiry_date TEXT,
        support_vendor TEXT,
        status TEXT,
        end_of_life TEXT,
        remarks TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT,
        updated_at DATETIME
    )");

    // Create Asset History Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS asset_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        asset_id INTEGER,
        action_type TEXT,
        performed_by TEXT,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )");


    // Create Server Inventory Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        hostname TEXT NOT NULL,
        ip_address TEXT NOT NULL,
        additional_ips TEXT,
        os_family TEXT,
        os_version TEXT,
        kernel_version TEXT,
        cpu TEXT,
        memory TEXT,
        support_level TEXT,
        server_state TEXT,
        domain TEXT,
        joined_in TEXT,
        role TEXT,
        cluster_name TEXT,
        managed_by TEXT,
        cluster_type TEXT,
        project TEXT,
        application TEXT,
        technical_owner TEXT,
        technical_owner_email TEXT,
        team_dl TEXT,
        technical_manager TEXT,
        technical_manager_email TEXT,
        sdm_name TEXT,
        sdm_email TEXT,
        ncgr_owner TEXT,
        ncgr_owner_email TEXT,
        server_type TEXT,
        appliance TEXT,
        port_group TEXT,
        vlan TEXT,
        location TEXT,
        criticality TEXT,
        project_code TEXT,
        commissioned_date TEXT,
        host_type TEXT,
        hw_model TEXT,
        esxi_cluster TEXT,
        vendor TEXT,
        dmz TEXT,
        db_type TEXT,
        live TEXT,
        eol TEXT,
        backup TEXT,
        monitoring TEXT,
        infra TEXT,
        edit_comments TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT,
        updated_at DATETIME
    )");

    // Create Inventory History Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS inventory_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        inventory_id INTEGER,
        action_type TEXT,
        performed_by TEXT,
        details TEXT,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Reminders Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        reminder_date DATETIME NOT NULL,
        visibility TEXT DEFAULT 'all',
        additional_emails TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Sticky Notes Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS sticky_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        content TEXT NOT NULL,
        visibility TEXT DEFAULT 'all',
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Builds Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS builds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        build_no TEXT NOT NULL,
        project TEXT NOT NULL,
        status TEXT NOT NULL,
        build_by INTEGER NOT NULL,
        supported_by TEXT,
        build_from TEXT,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Build Attachments Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS build_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        build_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        filepath TEXT NOT NULL,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (build_id) REFERENCES builds(id) ON DELETE CASCADE
    )");
// Create Handovers Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS handovers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project_name TEXT NOT NULL,
        project_id TEXT,
        current_owner TEXT NOT NULL,
        new_owner TEXT NOT NULL,
        handover_date TEXT,
        handover_status TEXT,
        reason_for_handover TEXT,
        project_phase TEXT,
        documentation_status TEXT,
        open_issues TEXT,
        pending_actions TEXT,
        risks TEXT,
        dependencies TEXT,
        kt_completed TEXT,
        training_completed TEXT,
        access_transferred TEXT,
        stakeholder_signoff TEXT,
        client_notified TEXT,
        warranty_period TEXT,
        notes TEXT,
        user_id INTEGER NOT NULL,
        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Create Handover Attachments Table (SQLite Compatible)
    $pdo->exec("CREATE TABLE IF NOT EXISTS handover_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        handover_id INTEGER NOT NULL,
        filename TEXT NOT NULL,
        filepath TEXT NOT NULL,
        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (handover_id) REFERENCES handovers(id) ON DELETE CASCADE
    )");

// =====================================================
// IP ADDRESS MANAGEMENT (IPAM)
// =====================================================


$pdo->exec("
CREATE TABLE IF NOT EXISTS ip_ranges (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    ip_range TEXT NOT NULL,

    vlan TEXT,

    subnet TEXT,

    subnet_mask TEXT,

    gateway TEXT,

    network_address TEXT,

    portgroup TEXT,

    cidr TEXT,

    usable_range TEXT,

    broadcast TEXT,

    total_hosts INTEGER DEFAULT 0,

    usable_hosts INTEGER DEFAULT 0,


    environment TEXT,

    project TEXT,

    project_code TEXT,


    comments TEXT,


    created_by TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,


    updated_by TEXT,

    updated_at DATETIME

)
");



// =====================================================
// SAFE IP COLUMN UPGRADES
// =====================================================


$ip_columns = [

    "subnet_mask TEXT",

    "network_address TEXT",

    "project_code TEXT",

    "updated_by TEXT",

    "updated_at DATETIME"

];


foreach($ip_columns as $column){

    try {

        $pdo->exec(
            "ALTER TABLE ip_ranges ADD COLUMN ".$column
        );


    } catch(PDOException $e){

        // already exists

    }

}





// =====================================================
// IP RANGE HISTORY
// =====================================================


$pdo->exec("
CREATE TABLE IF NOT EXISTS ip_ranges_history (

    id INTEGER PRIMARY KEY AUTOINCREMENT,


    ip_range_id INTEGER NOT NULL,


    action_type TEXT NOT NULL,


    old_data TEXT,


    new_data TEXT,


    performed_by TEXT,


    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP

)
");
$pdo->exec("
CREATE TABLE IF NOT EXISTS ownership_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ownership_id INTEGER,
    action_type TEXT,
    performed_by TEXT,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)");

$pdo->exec("
CREATE TABLE IF NOT EXISTS ip_column_preferences (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    user_id INTEGER NOT NULL,

    columns TEXT NOT NULL,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP

)
");



// =====================================================
// IP TABLE USER COLUMN SETTINGS
// =====================================================


$pdo->exec("
CREATE TABLE IF NOT EXISTS ip_column_settings (

    id INTEGER PRIMARY KEY AUTOINCREMENT,


    username TEXT UNIQUE NOT NULL,


    columns TEXT NOT NULL,


    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP

)
");

// Create Decommission Table
$pdo->exec("CREATE TABLE IF NOT EXISTS decommission (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    hostname TEXT NOT NULL,
    server_state TEXT,
    support_level TEXT,
    project TEXT,
    application_name TEXT,
    ip_address TEXT,
    additional_ips TEXT,
    decommission_start_date TEXT,
    decommission_end_date TEXT,
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_by TEXT,
    updated_at DATETIME
)");
// 3. Decommission Tasks Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS decommission_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        decommission_id INTEGER,
        task_name TEXT NOT NULL,
        status TEXT DEFAULT 'Pending',
        remarks TEXT
    )");

// Create Decommission History Table (Audit Trail)
$pdo->exec("CREATE TABLE IF NOT EXISTS decommission_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    decommission_id INTEGER,
    action_type TEXT,
    performed_by TEXT,
    details TEXT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
)");
// Safe column additions for existing databases
    try {
        $pdo->exec("ALTER TABLE decommission_tasks ADD COLUMN status TEXT DEFAULT 'Pending';");
    } catch (PDOException $e) {}

    try {
        $pdo->exec("ALTER TABLE decommission_tasks ADD COLUMN remarks TEXT;");
    } catch (PDOException $e) {}

} catch (PDOException $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>
