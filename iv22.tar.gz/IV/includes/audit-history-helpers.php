<?php
/**
 * Thin helpers around the shared `audit_history` table
 * (module, record_id, action, performed_by, details, created_at).
 *
 * vulnerability_detail.php / vulnerability_report.php already wrote
 * per-vulnerability status-change entries into this table (module =
 * 'Vulnerability'), but nothing anywhere ever rendered it -- the trail was
 * being recorded and then never shown. Reused here for report/folder/file
 * level events (module = 'VA Report', 'VA Folder', 'VA Folder File') and,
 * for the first time, actually surfaced through auditHistoryHtml().
 */

if (!function_exists('logAuditHistory')) {
    function logAuditHistory(PDO $pdo, string $module, int $recordId, string $action, string $performedBy, string $details = ''): void
    {
        try {
            $pdo->prepare("
                INSERT INTO audit_history (module, record_id, action, performed_by, details)
                VALUES (?, ?, ?, ?, ?)
            ")->execute([$module, $recordId, $action, $performedBy, $details]);
        } catch (Throwable $e) {
            error_log("logAuditHistory failed for {$module}#{$recordId}: " . $e->getMessage());
        }
    }
}

if (!function_exists('auditHistoryRows')) {
    /**
     * @param string[] $modules
     */
    function auditHistoryRows(PDO $pdo, array $modules, ?int $recordId = null, int $limit = 200): array
    {
        if (empty($modules)) {
            return [];
        }

        $placeholders = implode(',', array_fill(0, count($modules), '?'));
        $params = $modules;

        $sql = "SELECT * FROM audit_history WHERE module IN ($placeholders)";

        if ($recordId !== null) {
            $sql .= " AND record_id = ?";
            $params[] = $recordId;
        }

        $sql .= " ORDER BY created_at DESC, id DESC LIMIT " . (int) $limit;

        try {
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) {
            error_log('auditHistoryRows failed: ' . $e->getMessage());
            return [];
        }
    }
}

if (!function_exists('auditHistoryHtml')) {
    /**
     * @param string[] $modules
     */
    function auditHistoryHtml(PDO $pdo, array $modules, ?int $recordId = null, int $limit = 200): string
    {
        $rows = auditHistoryRows($pdo, $modules, $recordId, $limit);

        if (!$rows) {
            return '<p class="va-history-empty">No history recorded yet.</p>';
        }

        $html = '<table class="va-history-table"><thead><tr>'
              . '<th>Action</th><th>Performed By</th><th>Details</th><th>When</th>'
              . '</tr></thead><tbody>';

        foreach ($rows as $r) {
            $html .= '<tr>'
                  . '<td><span class="va-history-badge">' . htmlspecialchars((string) $r['action'], ENT_QUOTES, 'UTF-8') . '</span></td>'
                  . '<td>' . htmlspecialchars((string) $r['performed_by'], ENT_QUOTES, 'UTF-8') . '</td>'
                  . '<td>' . nl2br(htmlspecialchars((string) ($r['details'] ?? ''), ENT_QUOTES, 'UTF-8')) . '</td>'
                  . '<td>' . htmlspecialchars((string) ($r['created_at'] ?? ''), ENT_QUOTES, 'UTF-8') . '</td>'
                  . '</tr>';
        }

        return $html . '</tbody></table>';
    }
}
