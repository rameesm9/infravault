<?php
/**
 * Styled Excel (SpreadsheetML) export, shared by every module's "Export"
 * button.
 *
 * Exports used to be plain CSV, which Excel opens with an unstyled grid --
 * no bold header row, no color, whatever font the user's Excel defaults to.
 * SpreadsheetML is plain XML that Excel opens natively (no COM extension,
 * no Composer dependency, nothing to install on the server), so a real
 * font, a bold/colored header row and column borders can be set once here
 * and reused by every export instead of hand-rolled per module.
 */

/**
 * Sends the response headers for a SpreadsheetML download.
 *
 * The file extension is .xls (SpreadsheetML's own convention) even though
 * the bytes are XML, not the legacy binary XLS format -- Excel recognises
 * the format from its content, not the extension.
 */
function excelExportHeaders(string $filenameBase): void
{
    header('Content-Type: application/vnd.ms-excel; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filenameBase . '.xls');
    header('Pragma: no-cache');
    header('Expires: 0');
}

/**
 * One cell's text, escaped for SpreadsheetML.
 *
 * ENT_XML1 covers the five XML entities; SpreadsheetML has no HTML-style
 * numeric-entity fallback for stray control characters, but export data is
 * always plain text/dates from our own database, never markup.
 */
function excelXmlEscape($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_XML1, 'UTF-8');
}

/**
 * Writes the XML prolog, the header/data cell styles, and opens the
 * worksheet's <Table>. Call excelWorkbookClose() to finish it off.
 *
 * $sheetName is trimmed to Excel's 31-character sheet-name limit and
 * stripped of the handful of characters it forbids there.
 */
function excelWorkbookOpen($out, string $sheetName): void
{
    $sheetName = substr(preg_replace('/[\\\\\/?*\[\]:]/', ' ', $sheetName), 0, 31);

    fwrite($out, '<?xml version="1.0" encoding="UTF-8"?>' . "\n");
    fwrite($out, '<?mso-application progid="Excel.Sheet"?>' . "\n");
    fwrite($out, '<Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:o="urn:schemas-microsoft-com:office:office"
 xmlns:x="urn:schemas-microsoft-com:office:excel"
 xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
 xmlns:html="http://www.w3.org/TR/REC-html40">
 <Styles>
  <Style ss:ID="sHeader">
   <Font ss:FontName="Calibri" ss:Size="11" ss:Color="#FFFFFF" ss:Bold="1"/>
   <Interior ss:Color="#305496" ss:Pattern="Solid"/>
   <Alignment ss:Vertical="Center" ss:WrapText="0"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#1F3864"/>
   </Borders>
  </Style>
  <Style ss:ID="sData">
   <Font ss:FontName="Calibri" ss:Size="11"/>
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E7E6E6"/>
   </Borders>
  </Style>
  <Style ss:ID="sDataAlt">
   <Font ss:FontName="Calibri" ss:Size="11"/>
   <Interior ss:Color="#F2F2F2" ss:Pattern="Solid"/>
   <Alignment ss:Vertical="Center"/>
   <Borders>
    <Border ss:Position="Bottom" ss:LineStyle="Continuous" ss:Weight="1" ss:Color="#E7E6E6"/>
   </Borders>
  </Style>
 </Styles>
 <Worksheet ss:Name="' . excelXmlEscape($sheetName) . '">
  <Table>
');
}

/**
 * The bold/colored header row.
 */
function excelHeaderRow($out, array $headers): void
{
    fwrite($out, '   <Row ss:AutoFitHeight="0">' . "\n");
    foreach ($headers as $h) {
        fwrite($out, '    <Cell ss:StyleID="sHeader"><Data ss:Type="String">' . excelXmlEscape($h) . '</Data></Cell>' . "\n");
    }
    fwrite($out, '   </Row>' . "\n");
}

/**
 * One data row. $rowNumber (1-based, header excluded) alternates the
 * light zebra-stripe shading so a wide row is easier to track across the
 * screen -- purely cosmetic, so a caller that doesn't track row numbers
 * can just pass 1 every time and get the plain style throughout.
 */
function excelDataRow($out, array $values, int $rowNumber = 1): void
{
    $styleId = ($rowNumber % 2 === 0) ? 'sDataAlt' : 'sData';

    fwrite($out, '   <Row>' . "\n");
    foreach ($values as $v) {
        fwrite($out, '    <Cell ss:StyleID="' . $styleId . '"><Data ss:Type="String">' . excelXmlEscape($v ?? '') . '</Data></Cell>' . "\n");
    }
    fwrite($out, '   </Row>' . "\n");
}

/**
 * Closes the table/worksheet/workbook, freezing the header row so it
 * stays put while scrolling a large export.
 */
function excelWorkbookClose($out): void
{
    fwrite($out, '  </Table>
  <WorksheetOptions xmlns="urn:schemas-microsoft-com:office:excel">
   <Selected/>
   <FreezePanes/>
   <FrozenNoSplit/>
   <SplitHorizontal>1</SplitHorizontal>
   <TopRowBottomPane>1</TopRowBottomPane>
   <ActivePane>2</ActivePane>
  </WorksheetOptions>
 </Worksheet>
</Workbook>
');
}
