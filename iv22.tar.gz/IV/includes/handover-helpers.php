<?php
/**
 * Shared between handover.php (which exports these fields to CSV) and
 * handover-import.php (which must read that same CSV back in) so the two
 * can never drift apart into a label/key mismatch.
 */
function handoverFieldLabels(): array
{
    return [
        'project_name'          => 'Project Name',
        'project_id'            => 'Project ID',
        'current_owner'         => 'Current Owner',
        'new_owner'             => 'New Owner',
        'handover_date'         => 'Handover Date',
        'handover_status'       => 'Handover Status',
        'reason_for_handover'   => 'Reason for Handover',
        'project_phase'         => 'Project Phase',
        'documentation_status'  => 'Documentation Status',
        'open_issues'           => 'Open Issues',
        'pending_actions'       => 'Pending Actions',
        'risks'                 => 'Risks',
        'dependencies'          => 'Dependencies',
        'kt_completed'          => 'Knowledge Transfer Completed',
        'training_completed'    => 'Training Completed',
        'access_transferred'    => 'Access Transferred',
        'stakeholder_signoff'   => 'Stakeholder Sign-off',
        'client_notified'       => 'Customer/Client Notified',
        'warranty_period'       => 'Warranty/Support Period',
        'notes'                 => 'Notes',
    ];
}
