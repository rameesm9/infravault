<?php

session_start();

require_once __DIR__ . '/config/vulnerability_db.php';
require_once __DIR__ . '/includes/audit-history-helpers.php';

/*
|--------------------------------------------------------------------------
| LOGIN CHECK
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('vulnerabilities', 'can_view');



/*
|--------------------------------------------------------------------------
| CURRENT USER ROLE
|--------------------------------------------------------------------------
|
| Delete is allowed only for Admin users.
|
*/

$role = strtolower(trim($_SESSION['role'] ?? ''));

$isAdmin = authzHasAnyRole($pdo, ['admin', 'administrator', 'super admin', 'superadmin']);

$canAudit = can('vulnerabilities', 'can_audit');

$currentUserName = trim(
    ($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '')
) ?: 'Admin';


/*
|--------------------------------------------------------------------------
| PAGE TITLE
|--------------------------------------------------------------------------
*/

$page_title = 'Vulnerability Management | InfraVault';


/*
|--------------------------------------------------------------------------
| DELETE VA REPORT
|--------------------------------------------------------------------------
|
| Only Admin users can execute this operation.
|
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['delete_report'])
) {

    /*
     * Extra server-side security check.
     *
     * Even if somebody manually creates a POST request,
     * non-admin users cannot delete reports.
     */
    if (!$isAdmin) {
        http_response_code(403);
        exit('You do not have permission to delete VA reports.');
    }


    /*
     * Get report ID.
     */
    $reportId = (int) ($_POST['report_id'] ?? 0);


    if ($reportId <= 0) {

        header('Location: vulnerabilities.php');
        exit;

    }


    try {

        /*
         * Get the report first so we know the physical
         * CSV file path before deleting the database row.
         */
        $reportStmt = $pdo->prepare("
            SELECT
                id,
                filename,
                file_path
            FROM va_reports
            WHERE id = ?
            LIMIT 1
        ");

        $reportStmt->execute([$reportId]);

        $reportToDelete = $reportStmt->fetch(PDO::FETCH_ASSOC);


        /*
         * Report does not exist.
         */
        if (!$reportToDelete) {

            header('Location: vulnerabilities.php');
            exit;

        }


        /*
         * Store the physical file path before
         * deleting the database record.
         */
        $filePath = $reportToDelete['file_path'] ?? '';
        $reportFilename = $reportToDelete['filename'] ?? 'Unknown Report';


        /*
         * Start transaction.
         */
        $pdo->beginTransaction();


        /*
         * -------------------------------------------------------
         * DELETE TRACKING RECORDS
         * -------------------------------------------------------
         *
         * va_tracking references va_vulnerabilities.
         */
        $deleteTracking = $pdo->prepare("
            DELETE FROM va_tracking
            WHERE vulnerability_id IN (
                SELECT id
                FROM va_vulnerabilities
                WHERE report_id = ?
            )
        ");

        $deleteTracking->execute([$reportId]);


        /*
         * -------------------------------------------------------
         * DELETE VULNERABILITY RECORDS
         * -------------------------------------------------------
         */
        $deleteVulnerabilities = $pdo->prepare("
            DELETE FROM va_vulnerabilities
            WHERE report_id = ?
        ");

        $deleteVulnerabilities->execute([$reportId]);


        /*
         * -------------------------------------------------------
         * DELETE REPORT
         * -------------------------------------------------------
         */
        $deleteReport = $pdo->prepare("
            DELETE FROM va_reports
            WHERE id = ?
        ");

        $deleteReport->execute([$reportId]);


        /*
         * Commit database changes.
         */
        $pdo->commit();


        /*
         * Logged after commit succeeds, into the shared audit_history
         * table -- record_id keeps pointing at the now-deleted report id,
         * which is fine since audit_history has no FK back to va_reports.
         */
        logAuditHistory(
            $pdo,
            'VA Report',
            $reportId,
            'Deleted',
            $currentUserName,
            'Deleted report "' . $reportFilename . '" and all its vulnerability records.'
        );


        /*
         * -------------------------------------------------------
         * DELETE PHYSICAL CSV FILE
         * -------------------------------------------------------
         *
         * Database deletion has already succeeded.
         * If the physical file is missing, there is nothing
         * further to remove.
         */
        if (
            !empty($filePath)
            && is_file($filePath)
        ) {
            @unlink($filePath);
        }


        /*
         * Redirect after successful deletion.
         *
         * This prevents duplicate POST requests if the
         * browser page is refreshed.
         */
        header('Location: vulnerabilities.php?deleted=1');
        exit;


    } catch (Throwable $e) {

        /*
         * Roll back database changes if anything failed.
         */
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }


        /*
         * Do not expose database details to normal users.
         * Log the actual error to PHP error log.
         */
        error_log(
            'VA report deletion failed: ' . $e->getMessage()
        );


        header('Location: vulnerabilities.php?delete_error=1');
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| SUCCESS / ERROR MESSAGE AFTER DELETE
|--------------------------------------------------------------------------
*/

$deleteMessage = '';

if (
    isset($_GET['deleted'])
    && $_GET['deleted'] === '1'
) {
    $deleteMessage = 'VA report deleted successfully.';
}


if (
    isset($_GET['delete_error'])
    && $_GET['delete_error'] === '1'
) {
    $deleteMessage = 'Unable to delete the VA report.';
}


/*
|--------------------------------------------------------------------------
| HISTORY AJAX
|--------------------------------------------------------------------------
|
| No record_id -> every report upload/delete across the module.
| With record_id -> just that one report's own history entries.
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="va-history-empty">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyRecordId = isset($_GET['record_id']) && $_GET['record_id'] !== ''
        ? (int) $_GET['record_id']
        : null;

    echo auditHistoryHtml($pdo, ['VA Report'], $historyRecordId);
    exit;
}

/*
|--------------------------------------------------------------------------
| HEADER / SIDEBAR
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/header.php';

require_once __DIR__ . '/includes/sidebar.php';

?>


<link rel="stylesheet" href="assets/css/vulnerabilities.css">


<div class="content">


    <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

    <div class="va-page-header">

        <div>

            <h1>
                Vulnerability Management
            </h1>

            <p>
                Manage uploaded VA reports and remediation status.
            </p>

        </div>


        <div class="va-header-actions">

            <?php if ($canAudit): ?>
                <button
                    type="button"
                    class="va-btn va-btn-secondary"
                    onclick="vaOpenHistory()"
                >
                    ⏱ History
                </button>
            <?php endif; ?>

            <?php if (can('va_assessment', 'can_view')): ?>
                <a
                    href="va_assessment.php"
                    class="va-btn va-btn-secondary"
                >
                    VA Assessment
                </a>
            <?php endif; ?>

            <?php if (can('vulnerability_upload', 'can_view') && can('vulnerability_upload', 'can_import')): ?>
                <a
                    href="vulnerability_upload.php"
                    class="va-btn va-btn-primary"
                >
                    + Upload CSV
                </a>
            <?php endif; ?>

        </div>

    </div>


    <?php if ($deleteMessage !== ''): ?>

        <div class="va-alert va-alert-success">

            <?= htmlspecialchars(
                $deleteMessage,
                ENT_QUOTES,
                'UTF-8'
            ); ?>

        </div>

    <?php endif; ?>


    <?php

    /* =====================================================
       GET LAST 10 UPLOADED REPORTS
    ====================================================== */

    $stmt = $pdo->query("
        SELECT
            r.*,
            u.first_name,
            u.last_name
        FROM va_reports r
        LEFT JOIN users u
            ON u.id = r.uploaded_by
        ORDER BY r.uploaded_at DESC
        LIMIT 10
    ");

    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ?>


    <?php if (!$reports): ?>


        <!-- =================================================
             EMPTY STATE
        ================================================== -->

        <div class="va-empty">

            <div class="va-empty-icon">
                📊
            </div>

            <h2>
                No VA Reports
            </h2>

            <p>
                Upload your first vulnerability assessment CSV file.
            </p>

            <br>

            <?php if (can('vulnerability_upload', 'can_view') && can('vulnerability_upload', 'can_import')): ?>
                <a
                    href="vulnerability_upload.php"
                    class="va-btn va-btn-primary"
                >
                    Upload CSV
                </a>
            <?php endif; ?>

        </div>


    <?php else: ?>


        <!-- =================================================
             REPORT GRID
        ================================================== -->

        <div class="va-report-grid">


            <?php foreach ($reports as $report): ?>


                <?php

                /* =============================================
                   GET REPORT STATISTICS
                ============================================== */

                $countStmt = $pdo->prepare("
                    SELECT

                        COUNT(*) AS total,

                        SUM(
                            CASE
                                WHEN COALESCE(t.status, 'Open') = 'Open'
                                THEN 1
                                ELSE 0
                            END
                        ) AS open_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Assigned'
                                THEN 1
                                ELSE 0
                            END
                        ) AS assigned_count,

                        SUM(
                            CASE
                                WHEN t.status = 'In Progress'
                                THEN 1
                                ELSE 0
                            END
                        ) AS progress_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Exception'
                                THEN 1
                                ELSE 0
                            END
                        ) AS exception_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Closed'
                                THEN 1
                                ELSE 0
                            END
                        ) AS closed_count

                    FROM va_vulnerabilities v

                    LEFT JOIN va_tracking t
                        ON t.vulnerability_id = v.id

                    WHERE v.report_id = ?
                ");


                $countStmt->execute([
                    $report['id']
                ]);


                $stats = $countStmt->fetch(
                    PDO::FETCH_ASSOC
                );


                /* =============================================
                   UPLOADER NAME
                ============================================== */

                $uploadedBy = trim((string) ($report['uploaded_by_name'] ?? ''));
                if ($uploadedBy === '') {
                    $uploadedBy = trim(
                        ($report['first_name'] ?? '')
                        . ' '
                        . ($report['last_name'] ?? '')
                    );
                }

                ?>


                <!-- =========================================
                     REPORT CARD
                ========================================== -->

                <div class="va-report-card">


                    <!-- REPORT HEADER -->

                    <div class="va-report-top">


                        <div class="va-file-icon">
                            CSV
                        </div>


                        <div class="va-report-info">


                            <a
                                href="vulnerability_report.php?id=<?= (int) $report['id']; ?>"
                                class="va-report-name"
                            >

                                <?= htmlspecialchars(
                                    $report['filename'] ?? 'Unknown Report',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>

                            </a>


                            <div class="va-report-meta">

                                Uploaded

                                <?= htmlspecialchars(
                                    $report['uploaded_at'] ?? '',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>


                                <?php if ($uploadedBy !== ''): ?>

                                    by

                                    <?= htmlspecialchars(
                                        $uploadedBy,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                <?php endif; ?>

                            </div>


                        </div>


                    </div>


                    <!-- =====================================
                         STATISTICS
                    ====================================== -->

                    <div class="va-report-stats">


                        <div>

                            <strong>
                                <?= (int) ($stats['total'] ?? 0); ?>
                            </strong>

                            <span>
                                Total
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['open_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Open
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['assigned_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Assigned
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['progress_count'] ?? 0); ?>
                            </strong>

                            <span>
                                In Progress
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['exception_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Exception
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['closed_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Closed
                            </span>

                        </div>


                    </div>


                    <!-- =====================================
                         CARD FOOTER
                    ====================================== -->

                    <div class="va-report-footer">


                        <span>

                            <?= (int) (
                                $report['record_count'] ?? 0
                            ); ?>

                            records

                        </span>


                        <div>


                            <a
                                href="vulnerability_report.php?id=<?= (int) $report['id']; ?>"
                                class="va-btn va-btn-secondary"
                            >
                                Open Report
                            </a>


                            <a
                                href="vulnerability_export.php?id=<?= (int) $report['id']; ?>"
                                class="va-btn va-btn-secondary"
                            >
                                Export
                            </a>


                            <?php if ($canAudit): ?>
                                <button
                                    type="button"
                                    class="va-history-btn"
                                    title="History"
                                    aria-label="Report history"
                                    onclick="vaOpenHistory(<?= (int) $report['id']; ?>)"
                                >
                                    ⏱
                                </button>
                            <?php endif; ?>


                            <?php if ($isAdmin): ?>


                                <!-- =================================
                                     ADMIN ONLY DELETE
                                ================================== -->

                                <form
                                    method="POST"
                                    action="vulnerabilities.php"
                                    style="display:inline;"
                                    onsubmit="return confirm('Are you sure you want to permanently delete this VA report and all vulnerability records?');"
                                >

                                    <input
                                        type="hidden"
                                        name="delete_report"
                                        value="1"
                                    >


                                    <input
                                        type="hidden"
                                        name="report_id"
                                        value="<?= (int) $report['id']; ?>"
                                    >


                                    <button
                                        type="submit"
                                        class="va-btn va-btn-danger"
                                    >
                                        Delete
                                    </button>

                                </form>


                            <?php endif; ?>


                        </div>


                    </div>


                </div>


            <?php endforeach; ?>


        </div>


    <?php endif; ?>


    <?php if ($canAudit): ?>

        <!-- =================================================
             HISTORY MODAL
        ================================================== -->

        <div class="va-modal-overlay" id="vaHistoryModal" onclick="if (event.target === this) vaCloseHistory();">
            <div class="va-modal-box">
                <div class="va-modal-header">
                    <h3 id="vaHistoryTitle">Report History</h3>
                    <button type="button" class="va-modal-close" aria-label="Close" onclick="vaCloseHistory();">&times;</button>
                </div>
                <div class="va-modal-body" id="vaHistoryBody">
                    <p class="va-history-empty">Loading...</p>
                </div>
            </div>
        </div>

    <?php endif; ?>


</div>


<?php if ($canAudit): ?>
<script>
function vaOpenHistory(reportId) {
    const modal = document.getElementById('vaHistoryModal');
    const title = document.getElementById('vaHistoryTitle');
    const body = document.getElementById('vaHistoryBody');

    title.textContent = reportId ? 'Report History' : 'All VA Report History';
    body.innerHTML = '<p class="va-history-empty">Loading...</p>';
    modal.classList.add('is-open');

    const url = 'vulnerabilities.php?action=get_history' + (reportId ? '&record_id=' + reportId : '');

    fetch(url)
        .then(response => response.text())
        .then(html => { body.innerHTML = html; })
        .catch(() => { body.innerHTML = '<p class="va-history-empty">Failed to load history.</p>'; });
}

function vaCloseHistory() {
    document.getElementById('vaHistoryModal').classList.remove('is-open');
}
</script>
<?php endif; ?>


<?php

require_once __DIR__ . '/includes/footer.php';

?>