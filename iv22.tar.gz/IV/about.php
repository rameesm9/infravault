 
<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('about', 'can_view');


$page_title = "About | InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';

?>

<style>

.about-grid {

    display:grid;
    grid-template-columns:repeat(3,1fr);
    gap:20px;

}


.about-card {

    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:12px;
    padding:25px;
    box-shadow:0 2px 8px rgba(0,0,0,.04);

}


.about-card h3 {

    color:var(--text-primary);
    margin-bottom:12px;

}


.about-card p {

    color:var(--text-secondary);
    line-height:1.7;

}


.about-banner {

    background:linear-gradient(
        135deg,
        #2563eb,
        #1e40af
    );

    color:white;
    border-radius:14px;
    padding:35px;
    margin-bottom:25px;

}


.about-banner h1 {

    margin:0 0 10px;
    font-size:32px;

}


.about-banner p {

    margin:0;
    opacity:.9;
    font-size:16px;

}



.team-box {

    background:var(--hover-bg);
    border-left:5px solid #2563eb;
    padding:20px;
    border-radius:10px;

}



.feature-list li {

    margin-bottom:10px;
    color:var(--text-secondary);

}



@media(max-width:900px){

.about-grid{

grid-template-columns:1fr;

}

}


</style>



<div class="content">


<div class="dashboard-header">

<div>

<h1>About <?= htmlspecialchars($appName) ?></h1>

<p>
Infrastructure Asset and Operations Management Platform
</p>

</div>

</div>




<div class="about-banner">

<h1><?= htmlspecialchars($appName) ?></h1>


<p>

A centralized platform designed to simplify infrastructure
visibility, ownership tracking, lifecycle management,
and operational collaboration.

</p>


</div>




<div class="dashboard-panel">


<div class="panel-header">

<h3>About the Platform</h3>

</div>



<p>

<?= htmlspecialchars($appName) ?> is an enterprise infrastructure management platform
developed to provide a single source of truth for infrastructure
assets, ownership details, server inventory, IP management,
build tracking, handovers, and operational documentation.

</p>


<p>

The platform helps infrastructure teams maintain accurate records,
improve operational efficiency, strengthen accountability, and
support better decision-making across technology environments.

</p>


</div>





<div class="about-grid" style="margin-top:25px;">



<div class="about-card">


<h3>
Infrastructure Management
</h3>


<p>

Manage servers, hardware assets, ownership information,
support details, lifecycle status, and operational records
from one centralized location.

</p>


</div>




<div class="about-card">


<h3>
IP Address Management
</h3>


<p>

Maintain IP ranges, VLAN information, subnet details,
network ownership, and allocation records with improved
visibility.

</p>


</div>




<div class="about-card">


<h3>
Operational Collaboration
</h3>


<p>

Support build management, project handovers,
documentation sharing, and team collaboration through
structured workflows.

</p>


</div>


</div>





<div class="dashboard-panel" style="margin-top:25px;">


<div class="panel-header">

<h3>Platform Capabilities</h3>

</div>


<ul class="feature-list">


<li>
Infrastructure Asset Inventory Management
</li>


<li>
Server and Application Ownership Tracking
</li>


<li>
IP Address Management (IPAM)
</li>


<li>
Infrastructure Build Documentation
</li>


<li>
Project Handover Management
</li>


<li>
Audit History and Operational Tracking
</li>


<li>
Help Center and Knowledge Repository
</li>


</ul>


</div>





<div class="dashboard-panel" style="margin-top:25px;">


<div class="panel-header">

<h3>Development & Ownership</h3>

</div>



<div class="team-box">


<h3>
Developed By
</h3>


<p>

<strong>
Ramees Muhammed
</strong>

</p>


<p>

<?= htmlspecialchars($appName) ?> has been designed and developed as an internal
infrastructure management solution to improve operational
visibility and collaboration.

</p>


<h3>
Team
</h3>


<p>

<strong>
Linux and Container Platform Team
</strong>

</p>


<p>

The platform is maintained and enhanced to support modern
infrastructure operations, automation practices, and reliable
service delivery.

</p>


</div>


</div>






<div class="dashboard-panel" style="margin-top:25px;">


<div class="panel-header">

<h3>Vision</h3>

</div>


<p>

<?= htmlspecialchars($appName) ?> aims to become a reliable operational knowledge
platform that connects infrastructure data, teams, and processes
while reducing manual effort and improving service reliability.

</p>


</div>




</div>


<?php include 'includes/footer.php'; ?>
