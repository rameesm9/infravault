<?php
/**
 * Container Platform inventory -- OpenShift and other Kubernetes
 * distributions, with their nodes.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('container_platform', 'can_view');

$canEdit   = can('container_platform', 'can_edit');
$canDelete = can('container_platform', 'can_delete');
$canExport = can('container_platform', 'can_export');
$canAudit  = can('container_platform', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const CP_MODULE = 'container_platform';

$platforms    = ['OpenShift', 'Vanilla Kubernetes', 'Rancher', 'Tanzu', 'EKS', 'AKS', 'GKE', 'OKD'];
$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox'];
$statuses     = ['Active', 'Building', 'Degraded', 'Decommissioned'];
$nodeRoles    = ['master', 'infra', 'worker', 'storage', 'other'];
$netPlugins   = ['OVN-Kubernetes', 'OpenShiftSDN', 'Calico', 'Cilium', 'Flannel', 'Other'];

/* Column list drives both the form and the CSV export. */
$cpFields = [
    'cluster_name'          => 'Cluster Name',
    'platform'              => 'Platform',
    'distribution_version'  => 'Platform Version',
    'kubernetes_version'    => 'Kubernetes Version',
    'environment'           => 'Environment',
    'project'               => 'Project',
    'location'              => 'Location / DC',
    'managed_by'            => 'Managed By',
    'api_endpoint'          => 'API Endpoint',
    'console_url'           => 'Console URL',
    'ingress_domain'        => 'Ingress Domain',
    'master_count'          => 'Masters',
    'infra_count'           => 'Infra Nodes',
    'worker_count'          => 'Workers',
    'storage_count'         => 'Storage Nodes',
    'other_count'           => 'Other Nodes',
    'total_cpu_cores'       => 'Total vCPU',
    'total_memory_gb'       => 'Total Memory (GB)',
    'total_storage_tb'      => 'Total Storage (TB)',
    'network_plugin'        => 'Network Plugin',
    'storage_backend'       => 'Storage Backend',
    'registry_type'         => 'Registry',
    'subscription_type'     => 'Subscription',
    'subscription_expiry'   => 'Subscription Expiry',
    'technical_owner'       => 'Technical Owner',
    'technical_owner_email' => 'Owner Email',
    'status'                => 'Status',
    'notes'                 => 'Notes',
];

/* Role -> lane metadata for the cluster topology diagram in the Nodes
   modal. A node whose stored role isn't one of these (a leftover from
   before "other" existed, or a hand-edited row) is grouped under 'other'
   rather than dropped. */
const CP_ROLE_META = [
    'master'  => ['label' => 'Masters',  'icon' => '👑'],
    'infra'   => ['label' => 'Infra',    'icon' => '🧩'],
    'worker'  => ['label' => 'Workers',  'icon' => '⚙️'],
    'storage' => ['label' => 'Storage',  'icon' => '🗄️'],
    'other'   => ['label' => 'Other',    'icon' => '▫️'],
];

/**
 * Renders the cluster's nodes and surrounding services (registry, network
 * plugin, storage backend) as a topology diagram rather than a flat table,
 * so the modal shows how the cluster is actually laid out.
 */
function platformClusterDiagramHtml(array $cluster, array $nodes, int $clusterId, bool $canExport): string
{
    $lanes = array_fill_keys(array_keys(CP_ROLE_META), []);
    foreach ($nodes as $n) {
        $role = strtolower(trim((string) $n['node_role']));
        if (!isset($lanes[$role])) { $role = 'other'; }
        $lanes[$role][] = $n;
    }

    $registry = trim((string) ($cluster['registry_type'] ?? ''));
    $isHarbor = $registry !== '' && stripos($registry, 'harbor') !== false;

    $services = [
        ['label' => 'Registry',        'value' => $registry, 'accent' => $isHarbor ? 'harbor' : ''],
        ['label' => 'Network Plugin',  'value' => trim((string) ($cluster['network_plugin'] ?? '')), 'accent' => ''],
        ['label' => 'Storage Backend', 'value' => trim((string) ($cluster['storage_backend'] ?? '')), 'accent' => ''],
        ['label' => 'Ingress / API',   'value' => trim((string) ($cluster['ingress_domain'] ?? '')) ?: trim((string) ($cluster['api_endpoint'] ?? '')), 'accent' => ''],
    ];

    $html = '<div class="cp-diagram">';

    $html .= '<div class="cp-services">';
    foreach ($services as $svc) {
        $accentClass = $svc['accent'] ? ' cp-service-' . $svc['accent'] : '';
        $html .= '<div class="cp-service-tile' . $accentClass . '">'
               . '<span class="cp-service-label">' . plat_h($svc['label']) . '</span>'
               . '<span class="cp-service-value">' . ($svc['accent'] === 'harbor' ? '⚓ ' : '') . plat_h($svc['value'] ?: '—') . '</span>'
               . '</div>';
    }
    $html .= '</div>';

    if (!$nodes) {
        $html .= '<p class="plat-empty">No nodes recorded for this cluster yet.</p>';
    } else {
        $html .= '<div class="cp-lanes">';
        foreach (CP_ROLE_META as $role => $meta) {
            if (!$lanes[$role]) { continue; }

            $html .= '<div class="cp-lane cp-lane-' . $role . '">'
                   . '<div class="cp-lane-head">'
                   . '<span class="cp-lane-icon">' . $meta['icon'] . '</span>'
                   . '<span class="cp-lane-title">' . plat_h($meta['label']) . '</span>'
                   . '<span class="cp-lane-count">' . count($lanes[$role]) . '</span>'
                   . '</div>'
                   . '<div class="cp-lane-body">';

            foreach ($lanes[$role] as $n) {
                $html .= '<div class="cp-node-card">'
                       . '<div class="cp-node-host">' . plat_h($n['hostname']) . '</div>'
                       . '<div class="cp-node-meta">' . (int) $n['cpu_cores'] . ' vCPU &middot; ' . (int) $n['memory_gb'] . ' GB</div>'
                       . '<span class="plat-pill ' . platformStatusClass((string) $n['status']) . '">' . plat_h($n['status']) . '</span>';

                if (trim((string) $n['notes']) !== '') {
                    $html .= '<div class="cp-node-notes">' . plat_h($n['notes']) . '</div>';
                }

                $html .= '</div>';
            }

            $html .= '</div></div>';
        }
        $html .= '</div>';
    }

    if ($canExport && $nodes) {
        $html .= '<div class="cp-diagram-foot">'
               . '<a class="plat-btn plat-btn-light plat-btn-sm" href="container_platform.php?action=export_nodes&amp;id=' . $clusterId . '">Export Nodes CSV</a>'
               . '</div>';
    }

    return $html . '</div>';
}


/*
|--------------------------------------------------------------------------
| AJAX: audit history
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('container_platform', 'can_audit');
    echo platformHistoryHtml($pdo, CP_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX: nodes for one cluster
|--------------------------------------------------------------------------
*/

/* Same data as the read-only view below, but as JSON for the editor. */
if (($_GET['action'] ?? '') === 'nodes_json') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');

    $stmt = $pdo->prepare("
        SELECT hostname, node_role, cpu_cores, memory_gb, status
        FROM container_nodes WHERE cluster_id = ? ORDER BY node_role, hostname
    ");
    $stmt->execute([(int) ($_GET['id'] ?? 0)]);

    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}


/*
|--------------------------------------------------------------------------
| EXPORT: nodes for one cluster
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'export_nodes') {
    requirePermission('container_platform', 'can_export');

    $clusterId = (int) ($_GET['id'] ?? 0);

    $nameStmt = $pdo->prepare("SELECT cluster_name FROM container_clusters WHERE id = ?");
    $nameStmt->execute([$clusterId]);
    $clusterName = (string) ($nameStmt->fetchColumn() ?: 'cluster');

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . preg_replace('/[^a-z0-9_-]+/i', '_', $clusterName) . '_nodes_' . date('Y-m-d') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Hostname', 'Role', 'vCPU', 'Memory (GB)', 'Status', 'Notes']);

    $stmt = $pdo->prepare("SELECT hostname, node_role, cpu_cores, memory_gb, status, notes FROM container_nodes WHERE cluster_id = ? ORDER BY node_role, hostname");
    $stmt->execute([$clusterId]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
        fputcsv($out, $row);
    }

    fclose($out);
    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX: auto-fill from Inventory when a cluster name is entered
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'cluster_lookup') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');

    $name = trim((string) ($_GET['name'] ?? ''));
    if ($name === '') { echo json_encode(['hosts' => []]); exit; }

    $stmt = $pdo->prepare("
        SELECT hostname, cpu, memory, support_level, technical_owner, technical_owner_email, managed_by, project
        FROM inventory
        WHERE cluster_name = ? COLLATE NOCASE
        ORDER BY hostname
    ");
    $stmt->execute([$name]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $out = [
        'hosts'                 => [],
        'total_cpu_cores'       => 0,
        'total_memory_gb'       => 0,
        'support_level'         => '',
        'technical_owner'       => '',
        'technical_owner_email' => '',
        'managed_by'            => '',
        'project'               => '',
    ];

    foreach ($rows as $r) {
        $cpu = preg_match('/\d+/', (string) $r['cpu'], $m) ? (int) $m[0] : 0;
        $mem = preg_match('/\d+/', (string) $r['memory'], $m) ? (int) $m[0] : 0;

        $out['hosts'][] = ['hostname' => $r['hostname'], 'cpu' => $cpu, 'memory' => $mem];
        $out['total_cpu_cores'] += $cpu;
        $out['total_memory_gb'] += $mem;

        // First non-empty value wins for the cluster-level fields -- these
        // should be consistent across a cluster's hosts, so whichever host
        // has it filled in is good enough.
        foreach (['support_level', 'technical_owner', 'technical_owner_email', 'managed_by', 'project'] as $f) {
            if ($out[$f] === '' && trim((string) $r[$f]) !== '') {
                $out[$f] = trim((string) $r[$f]);
            }
        }
    }

    echo json_encode($out);
    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX: auto-fill subscription expiry from License / Warranty
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'subscription_lookup') {
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');

    $name = trim((string) ($_GET['name'] ?? ''));
    if ($name === '') { echo json_encode(['subscription_expiry' => '']); exit; }

    $stmt = $pdo->prepare("
        SELECT support_expiry_date FROM license_warranty
        WHERE product_name = ? COLLATE NOCASE
        ORDER BY id DESC LIMIT 1
    ");
    $stmt->execute([$name]);
    $expiry = $stmt->fetchColumn();

    echo json_encode(['subscription_expiry' => $expiry ?: '']);
    exit;
}

if (($_GET['action'] ?? '') === 'nodes') {
    header('Cache-Control: no-store');

    $clusterId = (int) ($_GET['id'] ?? 0);

    $cStmt = $pdo->prepare("SELECT * FROM container_clusters WHERE id = ?");
    $cStmt->execute([$clusterId]);
    $cluster = $cStmt->fetch(PDO::FETCH_ASSOC) ?: [];

    $stmt = $pdo->prepare("SELECT * FROM container_nodes WHERE cluster_id = ? ORDER BY node_role, hostname");
    $stmt->execute([$clusterId]);
    $nodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo platformClusterDiagramHtml($cluster, $nodes, $clusterId, $canExport);
    exit;
}


/*
|--------------------------------------------------------------------------
| FILTERS (shared by the listing and the export)
|--------------------------------------------------------------------------
*/

$q           = trim((string) ($_GET['q'] ?? ''));
$fPlatform   = trim((string) ($_GET['f_platform'] ?? ''));
$fEnv        = trim((string) ($_GET['f_env'] ?? ''));
$fStatus     = trim((string) ($_GET['f_status'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(cluster_name LIKE ? OR project LIKE ? OR api_endpoint LIKE ? OR technical_owner LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fPlatform !== '') { $where[] = 'platform = ?';    $params[] = $fPlatform; }
if ($fEnv !== '')      { $where[] = 'environment = ?'; $params[] = $fEnv; }
if ($fStatus !== '')   { $where[] = 'status = ?';      $params[] = $fStatus; }

$whereSql = implode(' AND ', $where);


/*
|--------------------------------------------------------------------------
| EXPORT
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('container_platform', 'can_export');
    platformExportCsv($pdo, 'container_clusters', $cpFields, $whereSql, $params, 'container_platform');
}


/*
|--------------------------------------------------------------------------
| WRITES
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {

        requirePermission('container_platform', 'can_edit');

        $id   = (int) ($_POST['id'] ?? 0);
        $data = [];

        foreach (array_keys($cpFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        // Numeric columns stored as numbers, not text.
        foreach (['master_count', 'infra_count', 'worker_count', 'storage_count', 'other_count', 'total_cpu_cores', 'total_memory_gb'] as $n) {
            $data[$n] = (int) $data[$n];
        }
        $data['total_storage_tb'] = (float) $data['total_storage_tb'];

        /* Masters / Infra / Workers / Storage / Other are a straight count
           of the node rows below, not a value typed in separately -- so
           they're recomputed here from the submitted rows rather than
           trusted from the client, which keeps the listing table honest
           even if the browser's own tally ever drifts (JS disabled, a
           row edited without triggering its change event, etc). */
        $hosts = $_POST['node_hostname'] ?? [];
        $roles = $_POST['node_role'] ?? [];
        $cpus  = $_POST['node_cpu'] ?? [];
        $mems  = $_POST['node_mem'] ?? [];
        $states = $_POST['node_status'] ?? [];

        $roleCounts = ['master' => 0, 'infra' => 0, 'worker' => 0, 'storage' => 0, 'other' => 0];
        foreach ($hosts as $i => $h) {
            if (trim((string) $h) === '') { continue; }
            $role = trim((string) ($roles[$i] ?? 'worker'));
            if (isset($roleCounts[$role])) { $roleCounts[$role]++; }
        }
        $data['master_count']  = $roleCounts['master'];
        $data['infra_count']   = $roleCounts['infra'];
        $data['worker_count']  = $roleCounts['worker'];
        $data['storage_count'] = $roleCounts['storage'];
        $data['other_count']   = $roleCounts['other'];

        if ($data['cluster_name'] === '') {
            $err = 'Cluster name is required.';
        } else {
            try {
                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM container_clusters WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $stmt = $pdo->prepare("UPDATE container_clusters SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                    $stmt->execute([...array_values($data), $username, $id]);

                    platformLog($pdo, CP_MODULE, $id, 'UPDATED', $username,
                        "Updated cluster: {$data['cluster_name']}\n" . platformDiff($old, $data, $cpFields));

                    $msg = 'Cluster updated.';
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $stmt = $pdo->prepare("INSERT INTO container_clusters ($cols, created_by) VALUES ($ph, ?)");
                    $stmt->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    platformLog($pdo, CP_MODULE, $id, 'CREATED', $username, "Created cluster: {$data['cluster_name']}");

                    $msg = 'Cluster added.';
                }

                /* Nodes: replaced wholesale, which is simpler than diffing
                   and matches how the editor presents them. */
                $pdo->prepare("DELETE FROM container_nodes WHERE cluster_id = ?")->execute([$id]);

                $insNode = $pdo->prepare("
                    INSERT OR IGNORE INTO container_nodes
                        (cluster_id, hostname, node_role, cpu_cores, memory_gb, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                foreach ($hosts as $i => $h) {
                    $h = trim((string) $h);
                    if ($h === '') { continue; }
                    $insNode->execute([
                        $id, $h,
                        trim((string) ($roles[$i] ?? 'worker')),
                        (int) ($cpus[$i] ?? 0),
                        (int) ($mems[$i] ?? 0),
                        trim((string) ($states[$i] ?? 'Ready')),
                    ]);
                }

            } catch (Throwable $e) {
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('container_platform', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);

        $nameStmt = $pdo->prepare("SELECT cluster_name FROM container_clusters WHERE id = ?");
        $nameStmt->execute([$id]);
        $name = (string) ($nameStmt->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM container_clusters WHERE id = ?")->execute([$id]);
        platformLog($pdo, CP_MODULE, $id, 'DELETED', $username, "Deleted cluster: {$name}");

        $msg = 'Cluster deleted.';
    }
}


/*
|--------------------------------------------------------------------------
| DATA
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("SELECT * FROM container_clusters WHERE $whereSql ORDER BY cluster_name");
$stmt->execute($params);
$clusters = $stmt->fetchAll(PDO::FETCH_ASSOC);

$nodeCounts = [];
foreach ($pdo->query("SELECT cluster_id, COUNT(*) c FROM container_nodes GROUP BY cluster_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $nodeCounts[(int) $r['cluster_id']] = (int) $r['c'];
}

$totClusters = count($clusters);
$totNodes    = array_sum($nodeCounts);
$totCpu      = 0;
$totMem      = 0;
$prodCount   = 0;

foreach ($clusters as $c) {
    $totCpu += (int) $c['total_cpu_cores'];
    $totMem += (int) $c['total_memory_gb'];
    if (strcasecmp((string) $c['environment'], 'Production') === 0) { $prodCount++; }
}

$hostnames        = platformHostnames($pdo);
$invClusterNames  = platformDistinct($pdo, 'inventory', 'cluster_name');
$licenseProducts  = platformDistinct($pdo, 'license_warranty', 'product_name');
$ownershipProjects = platformOwnershipProjects($pdo);

$page_title = 'Container Platform | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">☸</div>
            <div>
                <h1>Container Platform</h1>
                <p>OpenShift and Kubernetes clusters, their capacity, and the nodes that make them up.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="cpOpen()">+ Add Cluster</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_platform=<?= urlencode($fPlatform) ?>&amp;f_env=<?= urlencode($fEnv) ?>&amp;f_status=<?= urlencode($fStatus) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="cpHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $totClusters ?></b><span>Clusters</span></div>
        <div class="plat-stat tone-ok"><b><?= $prodCount ?></b><span>Production</span></div>
        <div class="plat-stat"><b><?= number_format($totNodes) ?></b><span>Nodes</span></div>
        <div class="plat-stat"><b><?= number_format($totCpu) ?></b><span>Total vCPU</span></div>
        <div class="plat-stat"><b><?= number_format($totMem) ?></b><span>Memory (GB)</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Search &amp; Filters</h3>
        </div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Cluster, project, endpoint, owner…">
                </div>
                <div class="plat-field">
                    <label>Platform</label>
                    <select name="f_platform">
                        <option value="">All</option>
                        <?php foreach ($platforms as $p): ?>
                            <option value="<?= plat_h($p) ?>" <?= $fPlatform === $p ? 'selected' : '' ?>><?= plat_h($p) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Environment</label>
                    <select name="f_env">
                        <option value="">All</option>
                        <?php foreach ($environments as $e): ?>
                            <option value="<?= plat_h($e) ?>" <?= $fEnv === $e ? 'selected' : '' ?>><?= plat_h($e) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Status</label>
                    <select name="f_status">
                        <option value="">All</option>
                        <?php foreach ($statuses as $s): ?>
                            <option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="container_platform.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Clusters</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $totClusters ?> shown</span>
        </div>

        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Cluster</th>
                        <th>Platform</th>
                        <th>Environment</th>
                        <th>Nodes (M/I/W/S/O)</th>
                        <th>Capacity</th>
                        <th>Project</th>
                        <th>Owner</th>
                        <th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$clusters): ?>
                    <tr><td colspan="9"><p class="plat-empty">No clusters recorded yet.</p></td></tr>
                <?php else: foreach ($clusters as $c): ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($c['cluster_name']) ?></span>
                            <span class="plat-sub"><?= plat_h($c['api_endpoint'] ?: $c['ingress_domain'] ?: '—') ?></span>
                        </td>
                        <td>
                            <?= plat_h($c['platform']) ?>
                            <span class="plat-sub"><?= plat_h($c['distribution_version'] ?: $c['kubernetes_version'] ?: '') ?></span>
                        </td>
                        <td><span class="plat-pill neutral"><?= plat_h($c['environment'] ?: '—') ?></span></td>
                        <td>
                            <?= (int) $c['master_count'] ?> / <?= (int) $c['infra_count'] ?> / <?= (int) $c['worker_count'] ?> / <?= (int) $c['storage_count'] ?> / <?= (int) $c['other_count'] ?>
                            <?php if (!empty($nodeCounts[(int) $c['id']])): ?>
                                <span class="plat-sub"><?= (int) $nodeCounts[(int) $c['id']] ?> named</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= number_format((int) $c['total_cpu_cores']) ?> vCPU
                            <span class="plat-sub"><?= number_format((int) $c['total_memory_gb']) ?> GB · <?= (float) $c['total_storage_tb'] ?> TB</span>
                        </td>
                        <td><?= plat_h($c['project'] ?: '—') ?></td>
                        <td>
                            <?= plat_h($c['technical_owner'] ?: '—') ?>
                            <span class="plat-sub"><?= plat_h($c['technical_owner_email']) ?></span>
                        </td>
                        <td><span class="plat-pill <?= platformStatusClass((string) $c['status']) ?>"><?= plat_h($c['status']) ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <button type="button" class="plat-icon-btn plat-icon-view" title="Nodes"
                                    onclick="cpNodes(<?= (int) $c['id'] ?>, '<?= plat_h(addslashes($c['cluster_name'])) ?>')">🖧</button>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='cpOpen(<?= json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History"
                                        onclick="cpHistory(<?= (int) $c['id'] ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="cpDelete(<?= (int) $c['id'] ?>, '<?= plat_h(addslashes($c['cluster_name'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>


<!-- ADD / EDIT -->
<div class="plat-modal" id="cpModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="cpTitle">Add Cluster</h2>
            <button type="button" class="plat-close" onclick="platClose('cpModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Cluster identity, capacity and the nodes that belong to it.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="cp_id">

            <div class="plat-form-grid">
                <div class="plat-field">
                    <label>Cluster Name *</label>
                    <input type="text" name="cluster_name" id="cp_cluster_name" list="platClusterNames" required
                        onchange="cpClusterLookup(this.value)">
                </div>
                <div class="plat-field"><label>Platform</label>
                    <select name="platform" id="cp_platform">
                        <?php foreach ($platforms as $p): ?><option value="<?= plat_h($p) ?>"><?= plat_h($p) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Status</label>
                    <select name="status" id="cp_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Platform Version</label><input type="text" name="distribution_version" id="cp_distribution_version" placeholder="e.g. 4.14"></div>
                <div class="plat-field"><label>Kubernetes Version</label><input type="text" name="kubernetes_version" id="cp_kubernetes_version" placeholder="e.g. 1.27"></div>
                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="cp_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Project</label><input type="text" name="project" id="cp_project" list="platOwnershipProjects"></div>
                <div class="plat-field"><label>Location / DC</label><input type="text" name="location" id="cp_location"></div>

                <div class="plat-section-title">Endpoints</div>
                <div class="plat-field"><label>API Endpoint</label><input type="text" name="api_endpoint" id="cp_api_endpoint" placeholder="https://api.cluster.example:6443"></div>
                <div class="plat-field"><label>Console URL</label><input type="text" name="console_url" id="cp_console_url"></div>
                <div class="plat-field"><label>Ingress Domain</label><input type="text" name="ingress_domain" id="cp_ingress_domain" placeholder="*.apps.cluster.example"></div>

                <div class="plat-section-title">Capacity</div>
                <div class="plat-field"><label>Masters</label><input type="number" name="master_count" id="cp_master_count" value="0" min="0" readonly></div>
                <div class="plat-field"><label>Infra Nodes</label><input type="number" name="infra_count" id="cp_infra_count" value="0" min="0" readonly></div>
                <div class="plat-field"><label>Workers</label><input type="number" name="worker_count" id="cp_worker_count" value="0" min="0" readonly></div>
                <div class="plat-field"><label>Storage Nodes</label><input type="number" name="storage_count" id="cp_storage_count" value="0" min="0" readonly></div>
                <div class="plat-field"><label>Other Nodes</label><input type="number" name="other_count" id="cp_other_count" value="0" min="0" readonly></div>
                <div class="plat-field"><label>Total vCPU</label><input type="number" name="total_cpu_cores" id="cp_total_cpu_cores" value="0" min="0"></div>
                <div class="plat-field"><label>Total Memory (GB)</label><input type="number" name="total_memory_gb" id="cp_total_memory_gb" value="0" min="0"></div>
                <div class="plat-field"><label>Total Storage (TB)</label><input type="number" step="0.1" name="total_storage_tb" id="cp_total_storage_tb" value="0" min="0"></div>
                <p class="plat-field full" style="margin:-6px 0 0;color:var(--text-muted);font-size:12.5px;">Masters / Infra / Workers / Storage / Other are counted from the roles assigned below and can't be edited directly.</p>

                <div class="plat-section-title">Platform detail</div>
                <div class="plat-field"><label>Network Plugin</label>
                    <select name="network_plugin" id="cp_network_plugin">
                        <option value="">—</option>
                        <?php foreach ($netPlugins as $n): ?><option value="<?= plat_h($n) ?>"><?= plat_h($n) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Storage Backend</label><input type="text" name="storage_backend" id="cp_storage_backend" placeholder="ODF / NetApp / vSphere"></div>
                <div class="plat-field"><label>Registry</label><input type="text" name="registry_type" id="cp_registry_type" placeholder="Quay / Harbor / internal"></div>
                <div class="plat-field">
                    <label>Subscription</label>
                    <input type="text" name="subscription_type" id="cp_subscription_type" list="platLicenseProducts"
                        onchange="cpSubscriptionLookup(this.value)">
                </div>
                <div class="plat-field"><label>Subscription Expiry</label><input type="date" name="subscription_expiry" id="cp_subscription_expiry"></div>
                <div class="plat-field"><label>Managed By</label><input type="text" name="managed_by" id="cp_managed_by"></div>

                <div class="plat-section-title">Ownership</div>
                <div class="plat-field"><label>Technical Owner</label><input type="text" name="technical_owner" id="cp_technical_owner"></div>
                <div class="plat-field"><label>Owner Email</label><input type="email" name="technical_owner_email" id="cp_technical_owner_email"></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="cp_notes" rows="2"></textarea></div>

                <div class="plat-section-title">Nodes</div>
                <div class="full">
                    <div id="cpNodeRows"></div>
                    <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="cpAddNode()">+ Add node</button>
                </div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('cpModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Cluster</button>
            </div>
        </form>
    </div>
</div>


<!-- NODES / HISTORY / DELETE -->
<div class="plat-modal" id="cpNodesModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="cpNodesTitle">Nodes</h2>
            <button type="button" class="plat-close" onclick="platClose('cpNodesModal')">&times;</button>
        </div>
        <div id="cpNodesBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="cpHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="cpHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('cpHistModal')">&times;</button>
        </div>
        <div id="cpHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="cpDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head">
            <h2>Delete cluster</h2>
            <button type="button" class="plat-close" onclick="platClose('cpDelModal')">&times;</button>
        </div>
        <p style="color:var(--text-secondary);">Delete <strong id="cpDelName"></strong> and all of its recorded nodes? This cannot be undone.</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="cpDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('cpDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<datalist id="platClusterNames">
    <?php foreach ($invClusterNames as $c): ?><option value="<?= plat_h($c) ?>"></option><?php endforeach; ?>
</datalist>

<datalist id="platLicenseProducts">
    <?php foreach ($licenseProducts as $p): ?><option value="<?= plat_h($p) ?>"></option><?php endforeach; ?>
</datalist>

<datalist id="platOwnershipProjects">
    <?php foreach ($ownershipProjects as $p): ?><option value="<?= plat_h($p) ?>"></option><?php endforeach; ?>
</datalist>

<script>
const CP_NODE_ROLES = <?= json_encode($nodeRoles) ?>;
const CP_FIELDS = <?= json_encode(array_keys($cpFields)) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function cpNodeRow(n) {
    n = n || {};
    const roles = CP_NODE_ROLES.map(r =>
        `<option value="${r}" ${n.node_role === r ? 'selected' : ''}>${r}</option>`).join('');

    const row = document.createElement('div');
    row.className = 'plat-filters';
    row.style.marginBottom = '8px';
    row.innerHTML =
        `<div class="plat-field"><input list="platHostnames" name="node_hostname[]" placeholder="hostname" value="${n.hostname || ''}"></div>
         <div class="plat-field"><select name="node_role[]">${roles}</select></div>
         <div class="plat-field"><input type="number" name="node_cpu[]" placeholder="vCPU" style="min-width:90px" value="${n.cpu_cores || ''}"></div>
         <div class="plat-field"><input type="number" name="node_mem[]" placeholder="GB" style="min-width:90px" value="${n.memory_gb || ''}"></div>
         <div class="plat-field"><input name="node_status[]" placeholder="Ready" style="min-width:110px" value="${n.status || 'Ready'}"></div>
         <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="cpRemoveNode(this)">Remove</button>`;
    return row;
}

function cpAddNode(n) {
    document.getElementById('cpNodeRows').appendChild(cpNodeRow(n));
    cpRecalcCounts();
}

function cpRemoveNode(btn) {
    btn.closest('.plat-filters').remove();
    cpRecalcCounts();
}

/* Masters / Infra / Workers / Storage Nodes are never typed in directly --
   they're a straight count of whatever role each node row has, so the two
   can never disagree with each other. */
function cpRecalcCounts() {
    const counts = { master: 0, infra: 0, worker: 0, storage: 0, other: 0 };

    document.querySelectorAll('#cpNodeRows > div').forEach(row => {
        const host = row.querySelector('input[name="node_hostname[]"]');
        const role = row.querySelector('select[name="node_role[]"]');
        if (!host || !role || host.value.trim() === '') { return; } // not a real node yet
        if (Object.prototype.hasOwnProperty.call(counts, role.value)) { counts[role.value]++; }
    });

    document.getElementById('cp_master_count').value  = counts.master;
    document.getElementById('cp_infra_count').value   = counts.infra;
    document.getElementById('cp_worker_count').value  = counts.worker;
    document.getElementById('cp_storage_count').value = counts.storage;
    document.getElementById('cp_other_count').value   = counts.other;
}

document.getElementById('cpNodeRows').addEventListener('change', e => {
    if (e.target.name === 'node_role[]' || e.target.name === 'node_hostname[]') { cpRecalcCounts(); }
});

function cpSetEnvironment(value) {
    const el = document.getElementById('cp_environment');
    if (!el || !value) return;

    let opt = Array.from(el.options).find(o => o.value.toLowerCase() === value.toLowerCase());
    if (!opt) {
        // Inventory's support_level values are free text and don't
        // necessarily match one of the fixed Environment options.
        opt = document.createElement('option');
        opt.value = value;
        opt.textContent = value;
        el.appendChild(opt);
    }
    el.value = opt.value;
}

/* Cluster Name -> Inventory: pulls in the cluster's hosts (with their vCPU
   and memory), the environment (from support_level), and ownership. */
function cpClusterLookup(name) {
    name = (name || '').trim();
    if (!name) return;

    fetch('container_platform.php?action=cluster_lookup&name=' + encodeURIComponent(name) + '&_=' + Date.now(), { cache: 'no-store' })
        .then(r => r.ok ? r.json() : null)
        .then(data => {
            if (!data) return;

            // Cluster-level fields are set first and independently of each
            // other -- one throwing (a missing element, bad data) must not
            // stop the rest, Project included, from being applied.
            const setIfPresent = (id, value) => {
                if (!value) return;
                const el = document.getElementById(id);
                if (el) { el.value = value; }
            };

            setIfPresent('cp_project', data.project);
            setIfPresent('cp_total_cpu_cores', data.total_cpu_cores);
            setIfPresent('cp_total_memory_gb', data.total_memory_gb);
            setIfPresent('cp_technical_owner', data.technical_owner);
            setIfPresent('cp_technical_owner_email', data.technical_owner_email);
            setIfPresent('cp_managed_by', data.managed_by);
            if (data.support_level) { cpSetEnvironment(data.support_level); }

            const rows = document.getElementById('cpNodeRows');
            const existing = new Set(
                Array.from(rows.querySelectorAll('input[name="node_hostname[]"]'))
                    .map(i => i.value.trim().toLowerCase())
                    .filter(v => v !== '')
            );

            // Drop untouched blank rows before appending the fetched hosts.
            Array.from(rows.children).forEach(row => {
                const hostInput = row.querySelector('input[name="node_hostname[]"]');
                if (hostInput && hostInput.value.trim() === '') { row.remove(); }
            });

            (data.hosts || []).forEach(h => {
                const key = (h.hostname || '').trim().toLowerCase();
                if (key === '' || existing.has(key)) return;
                cpAddNode({ hostname: h.hostname, cpu_cores: h.cpu, memory_gb: h.memory, node_role: 'worker', status: 'Ready' });
                existing.add(key);
            });

            if (!rows.children.length) cpAddNode();
        })
        .catch(err => console.error('Cluster lookup failed:', err));
}

/* Subscription -> License/Warranty register: pulls in the expiry date for
   the product picked (or typed) in the Subscription field. */
function cpSubscriptionLookup(name) {
    name = (name || '').trim();
    if (!name) return;

    fetch('container_platform.php?action=subscription_lookup&name=' + encodeURIComponent(name) + '&_=' + Date.now(), { cache: 'no-store' })
        .then(r => r.ok ? r.json() : null)
        .then(data => {
            if (data && data.subscription_expiry) {
                document.getElementById('cp_subscription_expiry').value = data.subscription_expiry;
            }
        })
        .catch(err => console.error('Subscription lookup failed:', err));
}

function cpOpen(data) {
    const editing = !!data;
    document.getElementById('cpTitle').innerText = editing ? 'Edit Cluster' : 'Add Cluster';
    document.getElementById('cp_id').value = editing ? data.id : '';

    CP_FIELDS.forEach(f => {
        const el = document.getElementById('cp_' + f);
        if (!el) return;
        el.value = editing ? (data[f] ?? '') : (el.type === 'number' ? 0 : '');
    });

    const rows = document.getElementById('cpNodeRows');
    rows.innerHTML = '';

    if (editing) {
        // Nodes are fetched rather than embedded in the row: a cluster can
        // have many, and they are not needed until the editor is opened.
        fetch('container_platform.php?action=nodes_json&id=' + encodeURIComponent(data.id), { cache: 'no-store' })
            .then(r => r.ok ? r.json() : [])
            .then(list => {
                (list || []).forEach(cpAddNode);
                if (!list || !list.length) cpAddNode();
            })
            .catch(() => cpAddNode());
    } else {
        cpAddNode();
    }

    platOpen('cpModal');
}

function cpNodes(id, name) {
    document.getElementById('cpNodesTitle').innerText = 'Nodes — ' + name;
    document.getElementById('cpNodesBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('cpNodesModal');

    fetch('container_platform.php?action=nodes&id=' + encodeURIComponent(id), { cache: 'no-store' })
        .then(r => r.text())
        .then(html => { document.getElementById('cpNodesBody').innerHTML = html; })
        .catch(() => { document.getElementById('cpNodesBody').innerHTML = '<p class="plat-empty">Failed to load nodes.</p>'; });
}

function cpHistory(id) {
    document.getElementById('cpHistTitle').innerText = id ? 'Audit History — cluster #' + id : 'Module Audit History';
    document.getElementById('cpHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('cpHistModal');

    fetch('container_platform.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(html => { document.getElementById('cpHistBody').innerHTML = html; })
        .catch(() => { document.getElementById('cpHistBody').innerHTML = '<p class="plat-empty">Failed to load history.</p>'; });
}

function cpDelete(id, name) {
    document.getElementById('cpDelId').value = id;
    document.getElementById('cpDelName').innerText = name;
    platOpen('cpDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
