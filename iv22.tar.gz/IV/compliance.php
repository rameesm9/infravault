<?php

session_start();

require_once __DIR__ . '/config/db.php';

/*
| Authorization. This page previously had no login check and no
| permission check -- it read $_SESSION['user_id'] but was content for it
| to be null, defaulting the role to 'Read-only' and rendering anyway.
*/
requireLogin();
requirePermission('compliance', 'can_view');

$page_title = "Security Compliance | InfraVault";

$userId = isset($_SESSION['user_id'])
    ? (int)$_SESSION['user_id']
    : null;

$userName = $_SESSION['name'] ?? 'System';

$userRole = $_SESSION['role'] ?? 'Read-only';

$canEdit = can('compliance', 'can_edit');
$canDelete = can('compliance', 'can_delete');
$canAudit = can('compliance', 'can_audit');
$canExport = can('compliance', 'can_export');

/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['compliance_csrf'])) {

    $_SESSION['compliance_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf = $_SESSION['compliance_csrf'];

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function auditCompliance(
    PDO $pdo,
    ?int $platformId,
    ?int $controlId,
    string $action,
    string $performedBy,
    ?string $oldValue = null,
    ?string $newValue = null,
    ?string $details = null
): void {

    $stmt = $pdo->prepare("
        INSERT INTO compliance_audit
        (
            platform_id,
            control_id,
            action,
            performed_by,
            old_value,
            new_value,
            details
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $platformId,
        $controlId,
        $action,
        $performedBy,
        $oldValue,
        $newValue,
        $details
    ]);
}

/*
|--------------------------------------------------------------------------
| HISTORY (AJAX)
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'GET' &&
    ($_GET['ajax'] ?? '') === 'history'
) {

    header('Content-Type: application/json');

    if (!$canAudit) {
        http_response_code(403);
        echo json_encode(['error' => 'You do not have permission to view compliance history.']);
        exit;
    }

    $where = [];
    $params = [];

    if (!empty($_GET['platform_id'])) {
        $where[] = 'a.platform_id = ?';
        $params[] = (int)$_GET['platform_id'];
    }

    if (!empty($_GET['control_id'])) {
        $where[] = 'a.control_id = ?';
        $params[] = (int)$_GET['control_id'];
    }

    $sql = "
        SELECT
            a.*,
            p.platform_name,
            c.control_number,
            c.title AS control_title
        FROM compliance_audit a
        LEFT JOIN compliance_platforms p ON p.id = a.platform_id
        LEFT JOIN compliance_controls c ON c.id = a.control_id
        " . ($where ? ('WHERE ' . implode(' AND ', $where)) : '') . "
        ORDER BY a.created_at DESC, a.id DESC
        LIMIT 300
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        if (
            !isset($_POST['csrf']) ||
            !hash_equals(
                $_SESSION['compliance_csrf'],
                $_POST['csrf']
            )
        ) {
            throw new Exception(
                'Invalid security token.'
            );
        }

        $action = $_POST['action'] ?? '';

        $editActions = ['add_control', 'update_control', 'add_platform', 'update_platform'];
        $deleteActions = ['delete_control', 'delete_platform'];

        if (in_array($action, $editActions, true) && !$canEdit) {
            throw new Exception(
                'You do not have permission to edit compliance policies.'
            );
        }

        if (in_array($action, $deleteActions, true) && !$canDelete) {
            throw new Exception(
                'You do not have permission to delete compliance policies.'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Add Control
        |--------------------------------------------------------------------------
        */

        if ($action === 'add_control') {

            $platformId =
                (int)($_POST['platform_id'] ?? 0);

            $controlNumber =
                trim($_POST['control_number'] ?? '');

            $title =
                trim($_POST['title'] ?? '');

            $description =
                trim($_POST['description'] ?? '');

            $section =
                trim($_POST['section_name'] ?? '');

            $level =
                trim($_POST['level'] ?? 'Level 1');

            $severity =
                trim($_POST['severity'] ?? 'Medium');

            $controlType =
                trim($_POST['control_type'] ?? 'Configuration');

            $valueType =
                trim($_POST['value_type'] ?? 'Text');

            $cisValue =
                trim($_POST['cis_value'] ?? '');

            $ncgrValue =
                trim($_POST['ncgr_value'] ?? '');

            $unit =
                trim($_POST['unit'] ?? '');

            $remediation =
                trim($_POST['remediation'] ?? '');

            $auditProcedure =
                trim($_POST['audit_procedure'] ?? '');

            if (
                !$platformId ||
                !$controlNumber ||
                !$title
            ) {
                throw new Exception(
                    'Platform, control number and title are required.'
                );
            }

            $stmt = $pdo->prepare("
                INSERT INTO compliance_controls
                (
                    platform_id,
                    control_number,
                    title,
                    description,
                    section_name,
                    level,
                    severity,
                    control_type,
                    value_type,
                    cis_value,
                    ncgr_value,
                    unit,
                    remediation,
                    audit_procedure,
                    is_custom,
                    created_by,
                    updated_by
                )
                VALUES
                (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)
            ");

            $stmt->execute([
                $platformId,
                $controlNumber,
                $title,
                $description,
                $section,
                $level,
                $severity,
                $controlType,
                $valueType,
                $cisValue,
                $ncgrValue,
                $unit,
                $remediation,
                $auditProcedure,
                $userId,
                $userId
            ]);

            $controlId =
                (int)$pdo->lastInsertId();

            auditCompliance(
                $pdo,
                $platformId,
                $controlId,
                'CREATE',
                $userName,
                null,
                json_encode(
                    $_POST,
                    JSON_UNESCAPED_UNICODE
                ),
                'Custom compliance control created.'
            );

            $message =
                'Compliance control created successfully.';
        }

        /*
        |--------------------------------------------------------------------------
        | Update Control
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'update_control') {

            $controlId =
                (int)($_POST['control_id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT *
                FROM compliance_controls
                WHERE id = ?
            ");

            $stmt->execute([
                $controlId
            ]);

            $old =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$old) {

                throw new Exception(
                    'Compliance control not found.'
                );
            }

            $fields = [

                'control_number',
                'title',
                'description',
                'section_name',
                'level',
                'severity',
                'control_type',
                'value_type',
                'cis_value',
                'ncgr_value',
                'unit',
                'remediation',
                'audit_procedure'
            ];

            $values = [];

            foreach ($fields as $field) {

                $values[$field] =
                    trim($_POST[$field] ?? '');
            }

            $values['is_enabled'] =
                isset($_POST['is_enabled'])
                    ? 1
                    : 0;

            $stmt = $pdo->prepare("
                UPDATE compliance_controls

                SET
                    control_number = ?,
                    title = ?,
                    description = ?,
                    section_name = ?,
                    level = ?,
                    severity = ?,
                    control_type = ?,
                    value_type = ?,
                    cis_value = ?,
                    ncgr_value = ?,
                    unit = ?,
                    remediation = ?,
                    audit_procedure = ?,
                    is_enabled = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP

                WHERE id = ?
            ");

            $stmt->execute([

                $values['control_number'],
                $values['title'],
                $values['description'],
                $values['section_name'],
                $values['level'],
                $values['severity'],
                $values['control_type'],
                $values['value_type'],
                $values['cis_value'],
                $values['ncgr_value'],
                $values['unit'],
                $values['remediation'],
                $values['audit_procedure'],
                $values['is_enabled'],
                $userId,
                $controlId
            ]);

            auditCompliance(
                $pdo,
                (int)$old['platform_id'],
                $controlId,
                'UPDATE',
                $userName,
                json_encode(
                    $old,
                    JSON_UNESCAPED_UNICODE
                ),
                json_encode(
                    $values,
                    JSON_UNESCAPED_UNICODE
                ),
                'Compliance control updated.'
            );

            $message =
                'Compliance control updated successfully.';
        }

        /*
        |--------------------------------------------------------------------------
        | Delete Custom Control
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'delete_control') {

            $controlId =
                (int)($_POST['control_id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT *
                FROM compliance_controls
                WHERE id = ?
            ");

            $stmt->execute([
                $controlId
            ]);

            $control =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$control) {

                throw new Exception(
                    'Control not found.'
                );
            }

            if (!(int)$control['is_custom']) {

                throw new Exception(
                    'Built-in CIS controls cannot be deleted.'
                );
            }

            $stmt = $pdo->prepare("
                DELETE FROM compliance_controls
                WHERE id = ?
            ");

            $stmt->execute([
                $controlId
            ]);

            auditCompliance(
                $pdo,
                (int)$control['platform_id'],
                $controlId,
                'DELETE',
                $userName,
                json_encode(
                    $control,
                    JSON_UNESCAPED_UNICODE
                ),
                null,
                'Custom compliance control deleted.'
            );

            $message =
                'Custom control deleted.';
        }

        /*
        |--------------------------------------------------------------------------
        | Add Platform
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'add_platform') {

            $platformKey =
                trim($_POST['platform_key'] ?? '');

            $platformName =
                trim($_POST['platform_name'] ?? '');

            $category =
                trim($_POST['category'] ?? 'Red Hat');

            $description =
                trim($_POST['description'] ?? '');

            $framework =
                trim($_POST['framework'] ?? 'CIS');

            $benchmarkName =
                trim($_POST['benchmark_name'] ?? '');

            $benchmarkVersion =
                trim($_POST['benchmark_version'] ?? '');

            $isActive =
                isset($_POST['is_active'])
                    ? 1
                    : 0;

            if (
                !$platformKey ||
                !$platformName
            ) {
                throw new Exception(
                    'Platform key and platform name are required.'
                );
            }

            $dupStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM compliance_platforms
                WHERE platform_key = ?
            ");

            $dupStmt->execute([
                $platformKey
            ]);

            if ((int)$dupStmt->fetchColumn() > 0) {

                throw new Exception(
                    'A platform with that key already exists.'
                );
            }

            $maxSort = (int)$pdo->query("
                SELECT COALESCE(MAX(sort_order), 0)
                FROM compliance_platforms
            ")->fetchColumn();

            $stmt = $pdo->prepare("
                INSERT INTO compliance_platforms
                (
                    platform_key,
                    platform_name,
                    category,
                    description,
                    framework,
                    benchmark_name,
                    benchmark_version,
                    is_active,
                    sort_order,
                    created_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $platformKey,
                $platformName,
                $category,
                $description,
                $framework,
                $benchmarkName,
                $benchmarkVersion,
                $isActive,
                $maxSort + 10,
                $userId
            ]);

            $platformId =
                (int)$pdo->lastInsertId();

            auditCompliance(
                $pdo,
                $platformId,
                null,
                'CREATE',
                $userName,
                null,
                json_encode(
                    $_POST,
                    JSON_UNESCAPED_UNICODE
                ),
                'Compliance platform created.'
            );

            $message =
                'Platform created successfully.';
        }

        /*
        |--------------------------------------------------------------------------
        | Update Platform
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'update_platform') {

            $platformId =
                (int)($_POST['platform_id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT *
                FROM compliance_platforms
                WHERE id = ?
            ");

            $stmt->execute([
                $platformId
            ]);

            $old =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$old) {

                throw new Exception(
                    'Platform not found.'
                );
            }

            $platformKey =
                trim($_POST['platform_key'] ?? '');

            $platformName =
                trim($_POST['platform_name'] ?? '');

            $category =
                trim($_POST['category'] ?? 'Red Hat');

            $description =
                trim($_POST['description'] ?? '');

            $framework =
                trim($_POST['framework'] ?? 'CIS');

            $benchmarkName =
                trim($_POST['benchmark_name'] ?? '');

            $benchmarkVersion =
                trim($_POST['benchmark_version'] ?? '');

            $isActive =
                isset($_POST['is_active'])
                    ? 1
                    : 0;

            if (
                !$platformKey ||
                !$platformName
            ) {
                throw new Exception(
                    'Platform key and platform name are required.'
                );
            }

            $dupStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM compliance_platforms
                WHERE platform_key = ?
                  AND id != ?
            ");

            $dupStmt->execute([
                $platformKey,
                $platformId
            ]);

            if ((int)$dupStmt->fetchColumn() > 0) {

                throw new Exception(
                    'A platform with that key already exists.'
                );
            }

            $stmt = $pdo->prepare("
                UPDATE compliance_platforms

                SET
                    platform_key = ?,
                    platform_name = ?,
                    category = ?,
                    description = ?,
                    framework = ?,
                    benchmark_name = ?,
                    benchmark_version = ?,
                    is_active = ?,
                    updated_at = CURRENT_TIMESTAMP

                WHERE id = ?
            ");

            $stmt->execute([
                $platformKey,
                $platformName,
                $category,
                $description,
                $framework,
                $benchmarkName,
                $benchmarkVersion,
                $isActive,
                $platformId
            ]);

            auditCompliance(
                $pdo,
                $platformId,
                null,
                'UPDATE',
                $userName,
                json_encode(
                    $old,
                    JSON_UNESCAPED_UNICODE
                ),
                json_encode(
                    $_POST,
                    JSON_UNESCAPED_UNICODE
                ),
                'Compliance platform updated.'
            );

            $message =
                'Platform updated successfully.';
        }

        /*
        |--------------------------------------------------------------------------
        | Delete Platform
        |--------------------------------------------------------------------------
        */

        elseif ($action === 'delete_platform') {

            $platformId =
                (int)($_POST['platform_id'] ?? 0);

            $stmt = $pdo->prepare("
                SELECT *
                FROM compliance_platforms
                WHERE id = ?
            ");

            $stmt->execute([
                $platformId
            ]);

            $platform =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$platform) {

                throw new Exception(
                    'Platform not found.'
                );
            }

            $countStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM compliance_controls
                WHERE platform_id = ?
            ");

            $countStmt->execute([
                $platformId
            ]);

            $controlCount =
                (int)$countStmt->fetchColumn();

            /*
            | The FK declares ON DELETE CASCADE, but this app leaves
            | SQLite's PRAGMA foreign_keys at its default (off), so the
            | child controls have to go explicitly or they are orphaned.
            */
            $pdo->prepare("
                DELETE FROM compliance_controls
                WHERE platform_id = ?
            ")->execute([
                $platformId
            ]);

            $pdo->prepare("
                DELETE FROM compliance_platforms
                WHERE id = ?
            ")->execute([
                $platformId
            ]);

            auditCompliance(
                $pdo,
                null,
                null,
                'DELETE',
                $userName,
                json_encode(
                    $platform,
                    JSON_UNESCAPED_UNICODE
                ),
                null,
                'Compliance platform "' . $platform['platform_name'] . '" deleted, along with ' .
                    $controlCount . ' control' . ($controlCount === 1 ? '' : 's') . '.'
            );

            $message =
                'Platform deleted.';
        }

    } catch (Throwable $e) {

        $error = $e->getMessage();
    }
}

/*
|--------------------------------------------------------------------------
| Load Platforms
|--------------------------------------------------------------------------
*/

$platformStmt = $pdo->query("
    SELECT *
    FROM compliance_platforms
    ORDER BY sort_order, platform_name
");

$platforms =
    $platformStmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| Load Controls
|--------------------------------------------------------------------------
*/

$controls = [];

$stmt = $pdo->query("
    SELECT
        c.*,
        p.platform_name,
        p.platform_key,
        p.framework,
        p.benchmark_name,
        p.benchmark_version
    FROM compliance_controls c
    INNER JOIN compliance_platforms p
        ON p.id = c.platform_id
    ORDER BY
        p.sort_order,
        c.sort_order,
        c.control_number
");

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {

    $controls[$row['platform_id']][] =
        $row;
}

/*
|--------------------------------------------------------------------------
| Include Existing Layout
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<link rel="stylesheet"
      href="assets/css/compliance.css">

<div class="content compliance-page">

    <div class="compliance-header">

        <div>

            <div class="page-kicker">
                VULNERABILITY & CONTROLS
            </div>

            <h1>
                Security Compliance
            </h1>

            <p>
                CIS baseline and NCGR security policy controls.
            </p>

        </div>

        <div class="header-actions">

            <?php if ($canAudit): ?>

            <button
                type="button"
                class="btn-secondary"
                onclick="openHistory()">

                ⏱ History

            </button>

            <?php endif; ?>

            <?php if ($canExport): ?>

            <a
                class="btn-secondary"
                href="compliance-export.php">

                ⬇ Export to Word

            </a>

            <?php endif; ?>

            <?php if ($canEdit): ?>

            <button
                type="button"
                class="btn-secondary"
                onclick="openAddPlatform()">

                + Add Platform

            </button>

            <button
                type="button"
                class="btn-primary"
                onclick="openAddControl()">

                + Add Compliance Control

            </button>

            <?php endif; ?>

        </div>

    </div>


    <?php if ($message): ?>

        <div class="alert success">
            <?= h($message); ?>
        </div>

    <?php endif; ?>


    <?php if ($error): ?>

        <div class="alert error">
            <?= h($error); ?>
        </div>

    <?php endif; ?>


    <!-- =====================================================
         SUMMARY
    ====================================================== -->

    <div class="compliance-summary">

        <div class="summary-card">

            <span>
                Platforms
            </span>

            <strong>
                <?= count($platforms); ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                CIS Controls
            </span>

            <strong>
                <?=
                (int)$pdo->query("
                    SELECT COUNT(*)
                    FROM compliance_controls
                    WHERE is_custom = 0
                ")->fetchColumn();
                ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                NCGR Customized
            </span>

            <strong>
                <?=
                (int)$pdo->query("
                    SELECT COUNT(*)
                    FROM compliance_controls
                    WHERE ncgr_value != cis_value
                ")->fetchColumn();
                ?>
            </strong>

        </div>

        <div class="summary-card">

            <span>
                Custom Controls
            </span>

            <strong>
                <?=
                (int)$pdo->query("
                    SELECT COUNT(*)
                    FROM compliance_controls
                    WHERE is_custom = 1
                ")->fetchColumn();
                ?>
            </strong>

        </div>

    </div>


    <!-- =====================================================
         SEARCH
    ====================================================== -->

    <div class="compliance-toolbar">

        <div class="search-box">

            <span>⌕</span>

            <input
                type="text"
                id="complianceSearch"
                placeholder="Search controls, platform, CIS value or NCGR value..."
                onkeyup="filterCompliance()">

        </div>

        <select
            id="severityFilter"
            onchange="filterCompliance()">

            <option value="">
                All Severity
            </option>

            <option value="Critical">
                Critical
            </option>

            <option value="High">
                High
            </option>

            <option value="Medium">
                Medium
            </option>

            <option value="Low">
                Low
            </option>

        </select>

    </div>


    <!-- =====================================================
         PLATFORMS
    ====================================================== -->

    <div class="platform-list">

        <?php foreach ($platforms as $platform): ?>

            <?php

            $platformControls =
                $controls[$platform['id']] ?? [];

            ?>

            <section
                class="platform-card"
                data-platform="<?= h(strtolower($platform['platform_name'])); ?>">

                <!-- PLATFORM HEADER -->

                <div
                    class="platform-header"
                    role="button"
                    tabindex="0"
                    onclick="togglePlatform(this)"
                    onkeydown="if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); togglePlatform(this); }">

                    <div class="platform-left">

                        <div class="platform-icon">

                            <?php
                            $platformIcons = [
                                'rhel' => 'R',
                                'openshift' => 'O',
                                'kubernetes' => 'K',
                                'ipa' => 'I',
                                'satellite' => 'S',
                            ];

                            echo h(
                                $platformIcons[$platform['platform_key']]
                                ?? strtoupper(substr($platform['platform_key'], 0, 1))
                            );
                            ?>

                        </div>

                        <div>

                            <h2>
                                <?= h($platform['platform_name']); ?>
                            </h2>

                            <p>
                                <?= h($platform['description']); ?>
                            </p>

                        </div>

                    </div>

                    <div class="platform-right">

                        <span class="framework-badge">

                            <?= h($platform['framework']); ?>

                        </span>

                        <?php if (
                            $platform['benchmark_version']
                        ): ?>

                            <span class="version-badge">

                                v<?= h(
                                    $platform['benchmark_version']
                                ); ?>

                            </span>

                        <?php endif; ?>

                        <?php if (!(int)$platform['is_active']): ?>

                            <span class="status disabled platform-disabled-badge">
                                Disabled
                            </span>

                        <?php endif; ?>

                        <span class="control-count">

                            <?= count($platformControls); ?>
                            controls

                        </span>

                        <?php if ($canAudit || $canEdit || $canDelete || $canExport): ?>

                        <div class="platform-actions">

                            <?php if ($canAudit): ?>

                            <button
                                type="button"
                                class="icon-btn"
                                title="Platform History"
                                onclick='event.stopPropagation(); openHistory({ platformId: <?= (int)$platform['id']; ?>, title: <?= json_encode(
                                    $platform['platform_name'],
                                    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                                ); ?> });'>

                                ⏱

                            </button>

                            <?php endif; ?>

                            <?php if ($canExport): ?>

                            <a
                                class="icon-btn"
                                title="Export to Word"
                                href="compliance-export.php?platform_id=<?= (int)$platform['id']; ?>"
                                onclick="event.stopPropagation();">

                                ⬇

                            </a>

                            <?php endif; ?>

                            <?php if ($canEdit): ?>

                            <button
                                type="button"
                                class="icon-btn"
                                title="Edit Platform"
                                onclick="event.stopPropagation(); editPlatform(<?= json_encode(
                                    $platform,
                                    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                                ); ?>);">

                                ✎

                            </button>

                            <?php endif; ?>

                            <?php if ($canDelete): ?>

                            <button
                                type="button"
                                class="icon-btn danger"
                                title="Delete Platform"
                                onclick='event.stopPropagation(); deletePlatform(<?= (int)$platform['id']; ?>, <?= json_encode(
                                    $platform['platform_name'],
                                    JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                                ); ?>, <?= count($platformControls); ?>);'>

                                🗑

                            </button>

                            <?php endif; ?>

                        </div>

                        <?php endif; ?>

                        <span class="expand-arrow">
                            ▾
                        </span>

                    </div>

                </div>


                <!-- PLATFORM BODY -->

                <div class="platform-body">

                    <?php if (
                        empty($platformControls)
                    ): ?>

                        <div class="empty-state">

                            No compliance controls have been
                            configured for this platform.

                        </div>

                    <?php else: ?>

                        <div class="control-table-wrapper">

                            <table class="control-table">

                                <thead>

                                <tr>

                                    <th>
                                        Control
                                    </th>

                                    <th>
                                        Requirement
                                    </th>

                                    <th>
                                        CIS Baseline
                                    </th>

                                    <th>
                                        NCGR Policy
                                    </th>

                                    <th>
                                        Severity
                                    </th>

                                    <th>
                                        Status
                                    </th>

                                    <?php if ($canEdit || $canDelete || $canAudit): ?>

                                    <th>
                                        Action
                                    </th>

                                    <?php endif; ?>

                                </tr>

                                </thead>

                                <tbody>

                                <?php foreach (
                                    $platformControls
                                    as $control
                                ): ?>

                                    <tr
                                        class="control-row"
                                        data-search="<?=
                                            h(
                                                strtolower(
                                                    implode(
                                                        ' ',
                                                        [
                                                            $platform['platform_name'],
                                                            $control['control_number'],
                                                            $control['title'],
                                                            $control['description'],
                                                            $control['cis_value'],
                                                            $control['ncgr_value']
                                                        ]
                                                    )
                                                )
                                            );
                                        ?>"
                                        data-severity="<?=
                                            h(
                                                $control['severity']
                                            );
                                        ?>">

                                        <td>

                                            <strong
                                                class="control-number">

                                                <?= h(
                                                    $control['control_number']
                                                ); ?>

                                            </strong>

                                            <?php if (
                                                $control['is_custom']
                                            ): ?>

                                                <span class="custom-badge">
                                                    CUSTOM
                                                </span>

                                            <?php endif; ?>

                                            <small>

                                                <?= h(
                                                    $control['section_name']
                                                ); ?>

                                            </small>

                                        </td>


                                        <td>

                                            <strong>
                                                <?= h(
                                                    $control['title']
                                                ); ?>
                                            </strong>

                                            <p>
                                                <?= h(
                                                    $control['description']
                                                ); ?>
                                            </p>

                                        </td>


                                        <td>

                                            <span class="value-box cis">

                                                <?= h(
                                                    $control['cis_value']
                                                ); ?>

                                                <?php if (
                                                    $control['unit']
                                                ): ?>

                                                    <small>
                                                        <?= h(
                                                            $control['unit']
                                                        ); ?>
                                                    </small>

                                                <?php endif; ?>

                                            </span>

                                        </td>


                                        <td>

                                            <?php
                                            $different =
                                                trim(
                                                    $control['cis_value']
                                                )
                                                !==
                                                trim(
                                                    $control['ncgr_value']
                                                );
                                            ?>

                                            <span
                                                class="value-box ncgr
                                                <?= $different
                                                    ? 'changed'
                                                    : ''; ?>">

                                                <?= h(
                                                    $control['ncgr_value']
                                                ); ?>

                                                <?php if (
                                                    $control['unit']
                                                ): ?>

                                                    <small>
                                                        <?= h(
                                                            $control['unit']
                                                        ); ?>
                                                    </small>

                                                <?php endif; ?>

                                            </span>

                                        </td>


                                        <td>

                                            <span
                                                class="severity
                                                severity-<?=
                                                    strtolower(
                                                        h(
                                                            $control['severity']
                                                        )
                                                    );
                                                ?>">

                                                <?= h(
                                                    $control['severity']
                                                ); ?>

                                            </span>

                                        </td>


                                        <td>

                                            <?php if (
                                                $control['is_enabled']
                                            ): ?>

                                                <span
                                                    class="status enabled">

                                                    Active

                                                </span>

                                            <?php else: ?>

                                                <span
                                                    class="status disabled">

                                                    Disabled

                                                </span>

                                            <?php endif; ?>

                                        </td>


                                        <?php if ($canEdit || $canDelete || $canAudit): ?>

                                        <td>

                                            <div class="row-actions">

                                                <?php if ($canEdit): ?>

                                                <button
                                                    type="button"
                                                    class="action-btn"
                                                    onclick='editControl(
                                                        <?= json_encode(
                                                            $control,
                                                            JSON_HEX_TAG |
                                                            JSON_HEX_APOS |
                                                            JSON_HEX_QUOT |
                                                            JSON_HEX_AMP
                                                        ); ?>
                                                    )'>

                                                    Edit

                                                </button>

                                                <?php endif; ?>

                                                <?php if ($canAudit): ?>

                                                <button
                                                    type="button"
                                                    class="action-btn"
                                                    onclick='openHistory({ controlId: <?= (int)$control['id']; ?>, title: <?= json_encode(
                                                        $control['control_number'] . ' ' . $control['title'],
                                                        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                                                    ); ?> })'>

                                                    History

                                                </button>

                                                <?php endif; ?>

                                                <?php if ($canDelete && $control['is_custom']): ?>

                                                <button
                                                    type="button"
                                                    class="action-btn danger"
                                                    onclick='deleteControl(<?= (int)$control['id']; ?>, <?= json_encode(
                                                        $control['control_number'] . ' ' . $control['title'],
                                                        JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_AMP
                                                    ); ?>)'>

                                                    Delete

                                                </button>

                                                <?php endif; ?>

                                            </div>

                                        </td>

                                        <?php endif; ?>

                                    </tr>

                                <?php endforeach; ?>

                                </tbody>

                            </table>

                        </div>

                    <?php endif; ?>

                </div>

            </section>

        <?php endforeach; ?>

    </div>

</div>


<!-- =====================================================
     CONTROL MODAL
====================================================== -->

<?php if ($canEdit): ?>

<div
    id="controlModal"
    class="modal-overlay">

    <div class="control-modal">

        <div class="modal-header">

            <div>

                <h2 id="modalTitle">
                    Add Compliance Control
                </h2>

                <p>
                    Configure CIS baseline and NCGR policy values.
                </p>

            </div>

            <button
                type="button"
                onclick="closeControlModal()">

                ×

            </button>

        </div>


        <form
            method="POST"
            id="controlForm">

            <input
                type="hidden"
                name="csrf"
                value="<?= h($csrf); ?>">

            <input
                type="hidden"
                name="action"
                id="formAction"
                value="add_control">

            <input
                type="hidden"
                name="control_id"
                id="control_id"
                value="">


            <div class="form-grid">

                <div class="form-group">

                    <label>
                        Platform
                    </label>

                    <select
                        name="platform_id"
                        id="platform_id"
                        required>

                        <?php foreach (
                            $platforms
                            as $platform
                        ): ?>

                            <option
                                value="<?= $platform['id']; ?>">

                                <?= h(
                                    $platform['platform_name']
                                ); ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Control Number
                    </label>

                    <input
                        type="text"
                        name="control_number"
                        id="control_number"
                        placeholder="e.g. 5.4.1"
                        required>

                </div>


                <div class="form-group full">

                    <label>
                        Control Title
                    </label>

                    <input
                        type="text"
                        name="title"
                        id="title"
                        required>

                </div>


                <div class="form-group full">

                    <label>
                        Requirement / Description
                    </label>

                    <textarea
                        name="description"
                        id="description"
                        rows="3"></textarea>

                </div>


                <div class="form-group">

                    <label>
                        Section
                    </label>

                    <input
                        type="text"
                        name="section_name"
                        id="section_name">

                </div>


                <div class="form-group">

                    <label>
                        Level
                    </label>

                    <select
                        name="level"
                        id="level">

                        <option>
                            Level 1
                        </option>

                        <option>
                            Level 2
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Severity
                    </label>

                    <select
                        name="severity"
                        id="severity">

                        <option>
                            Critical
                        </option>

                        <option>
                            High
                        </option>

                        <option selected>
                            Medium
                        </option>

                        <option>
                            Low
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Value Type
                    </label>

                    <select
                        name="value_type"
                        id="value_type">

                        <option>
                            Text
                        </option>

                        <option>
                            Number
                        </option>

                        <option>
                            Boolean
                        </option>

                        <option>
                            Percentage
                        </option>

                        <option>
                            Duration
                        </option>

                        <option>
                            List
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        Unit
                    </label>

                    <input
                        type="text"
                        name="unit"
                        id="unit"
                        placeholder="Days / % / MB / etc.">

                </div>


                <div class="form-group">

                    <label>
                        Control Type
                    </label>

                    <select
                        name="control_type"
                        id="control_type">

                        <option>
                            Configuration
                        </option>

                        <option>
                            Process
                        </option>

                        <option>
                            Access Control
                        </option>

                        <option>
                            Monitoring
                        </option>

                        <option>
                            Logging
                        </option>

                        <option>
                            Manual
                        </option>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        CIS Baseline
                    </label>

                    <input
                        type="text"
                        name="cis_value"
                        id="cis_value"
                        placeholder="CIS recommended value">

                </div>


                <div class="form-group">

                    <label>
                        NCGR Policy Value
                    </label>

                    <input
                        type="text"
                        name="ncgr_value"
                        id="ncgr_value"
                        placeholder="NCGR approved value">

                </div>


                <div class="form-group full">

                    <label>
                        Remediation
                    </label>

                    <textarea
                        name="remediation"
                        id="remediation"
                        rows="4"></textarea>

                </div>


                <div class="form-group full">

                    <label>
                        Audit Procedure
                    </label>

                    <textarea
                        name="audit_procedure"
                        id="audit_procedure"
                        rows="4"></textarea>

                </div>


                <div
                    class="form-group"
                    id="enabledGroup">

                    <label class="checkbox-label">

                        <input
                            type="checkbox"
                            name="is_enabled"
                            id="is_enabled"
                            checked>

                        Control Enabled

                    </label>

                </div>

            </div>


            <div class="modal-footer">

                <button
                    type="button"
                    class="btn-secondary"
                    onclick="closeControlModal()">

                    Cancel

                </button>

                <button
                    type="submit"
                    class="btn-primary">

                    Save Control

                </button>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


<!-- =====================================================
     PLATFORM MODAL
====================================================== -->

<?php if ($canEdit): ?>

<div
    id="platformModal"
    class="modal-overlay">

    <div class="control-modal">

        <div class="modal-header">

            <div>

                <h2 id="platformModalTitle">
                    Add Platform
                </h2>

                <p>
                    Configure the platform and its benchmark metadata.
                </p>

            </div>

            <button
                type="button"
                onclick="closePlatformModal()">

                ×

            </button>

        </div>


        <form
            method="POST"
            id="platformForm">

            <input
                type="hidden"
                name="csrf"
                value="<?= h($csrf); ?>">

            <input
                type="hidden"
                name="action"
                id="platformFormAction"
                value="add_platform">

            <input
                type="hidden"
                name="platform_id"
                id="platform_id_field"
                value="">


            <div class="form-grid">

                <div class="form-group">

                    <label>
                        Platform Key
                    </label>

                    <input
                        type="text"
                        name="platform_key"
                        id="platform_key"
                        placeholder="e.g. windows"
                        required>

                </div>


                <div class="form-group">

                    <label>
                        Platform Name
                    </label>

                    <input
                        type="text"
                        name="platform_name"
                        id="platform_name"
                        placeholder="e.g. Windows Server"
                        required>

                </div>


                <div class="form-group">

                    <label>
                        Category
                    </label>

                    <input
                        type="text"
                        name="category"
                        id="category"
                        placeholder="e.g. Red Hat">

                </div>


                <div class="form-group">

                    <label>
                        Framework
                    </label>

                    <input
                        type="text"
                        name="framework"
                        id="framework"
                        placeholder="e.g. CIS">

                </div>


                <div class="form-group">

                    <label>
                        Benchmark Name
                    </label>

                    <input
                        type="text"
                        name="benchmark_name"
                        id="benchmark_name">

                </div>


                <div class="form-group">

                    <label>
                        Benchmark Version
                    </label>

                    <input
                        type="text"
                        name="benchmark_version"
                        id="benchmark_version">

                </div>


                <div class="form-group full">

                    <label>
                        Description
                    </label>

                    <textarea
                        name="description"
                        id="platform_description"
                        rows="3"></textarea>

                </div>


                <div class="form-group">

                    <label class="checkbox-label">

                        <input
                            type="checkbox"
                            name="is_active"
                            id="platform_is_active"
                            checked>

                        Platform Active

                    </label>

                </div>

            </div>


            <div class="modal-footer">

                <button
                    type="button"
                    class="btn-secondary"
                    onclick="closePlatformModal()">

                    Cancel

                </button>

                <button
                    type="submit"
                    class="btn-primary">

                    Save Platform

                </button>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


<!-- =====================================================
     HISTORY MODAL
====================================================== -->

<?php if ($canAudit): ?>

<div
    id="historyModal"
    class="modal-overlay">

    <div class="control-modal">

        <div class="modal-header">

            <div>

                <h2 id="historyModalTitle">
                    Compliance History
                </h2>

                <p>
                    Audit trail of platform and control changes.
                </p>

            </div>

            <button
                type="button"
                onclick="closeHistoryModal()">

                ×

            </button>

        </div>

        <div class="modal-body history-body" id="historyBody">

            <div class="empty-state">
                Loading history...
            </div>

        </div>

    </div>

</div>

<?php endif; ?>


<!-- =====================================================
     DELETE FORMS
====================================================== -->

<?php if ($canDelete): ?>

<form method="POST" id="deleteControlForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= h($csrf); ?>">
    <input type="hidden" name="action" value="delete_control">
    <input type="hidden" name="control_id" id="deleteControlId" value="">
</form>

<form method="POST" id="deletePlatformForm" style="display:none;">
    <input type="hidden" name="csrf" value="<?= h($csrf); ?>">
    <input type="hidden" name="action" value="delete_platform">
    <input type="hidden" name="platform_id" id="deletePlatformId" value="">
</form>

<?php endif; ?>


<script>

window.complianceCSRF =
    <?= json_encode($csrf); ?>;

window.complianceCanAudit =
    <?= json_encode($canAudit); ?>;

</script>

<script src="assets/js/compliance.js"></script>

<?php
/*
|--------------------------------------------------------------------------
| Footer
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/footer.php';
?>
