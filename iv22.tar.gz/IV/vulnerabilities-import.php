<?php

session_start();
require 'config/db.php';
require 'config/vulnerability_db.php';
require_once 'includes/branding-helpers.php';
require_once 'includes/csv-helpers.php';

$appName = getAppName($pdo);

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('vulnerabilities', 'can_view');
requirePermission('vulnerabilities', 'can_import');


$role = $_SESSION['role'] ?? 'User';

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

/* Delegates to the single authorization helper (includes/authz.php). */
function hasPermission(PDO $pdo, string $role, string $permission): bool
{
    return authzCan($pdo, $role, 'vulnerabilities', $permission);
}

$canImport = hasPermission($pdo, $role, 'can_import');

if (!$canImport) {
    die("Permission denied");
}

$message = "";
$errors = [];
$imported = 0;
$skipped = 0;

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];
        $filename = $_FILES['csv_file']['name'] ?? 'imported_vulnerabilities.csv';
        $upload_dir = __DIR__ . '/uploads/';
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0755, true);
        }

        $stored_filename = time() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
        $file_path = $upload_dir . $stored_filename;

        if (copy($file, $file_path) && ($handle = fopen($file, "r")) !== false) {

            /*
            | Not currently wired to any page (vulnerability_upload.php is
            | the live importer for this data, with its own fuzzy alias
            | matcher). This module's own export (vulnerability_export.php)
            | writes display labels ("IP Address", "Host Name", ...), so
            | apply the same label map here in case this file is ever
            | reached, rather than leaving the raw-key reads below matched
            | against nothing.
            */
            $columnMap = [
                'ip_address' => 'IP Address',
                'host_name' => 'Host Name',
                'vulnerability_name' => 'Vulnerability Name',
                'port' => 'Port',
                'severity' => 'Severity',
                'plugin_id' => 'Plugin ID',
                'cve' => 'CVE',
                'solution' => 'Solution',
                'plugin_output' => 'Plugin Output',
            ];
            $header = csvNormaliseHeader((array) fgetcsv($handle), $columnMap);

            while (($row = fgetcsv($handle)) !== false) {

                $row = array_pad(array_slice($row, 0, count($header)), count($header), '');
                $data = array_combine($header, $row);

                // Extract required fields
                $ip_address = trim($data['ip_address'] ?? '');
                $host_name = trim($data['host_name'] ?? '');
                $vulnerability_name = trim($data['vulnerability_name'] ?? '');

                if (!$ip_address || !$host_name || !$vulnerability_name) {
                    $skipped++;
                    continue;
                }

                // Create report if not exists (single import report)
                $stmt = $pdo->prepare("SELECT id FROM va_reports WHERE filename = ?");
                $stmt->execute([$filename]);
                $report_id = $stmt->fetchColumn();

                if (!$report_id) {
                    $stmt = $pdo->prepare("
                        INSERT INTO va_reports (filename, stored_filename, file_path, uploaded_by)
                        VALUES (?, ?, ?, ?)
                    ");
                    $stmt->execute([$filename, $stored_filename, $file_path, $_SESSION['user_id']]);
                    $report_id = $pdo->lastInsertId();
                }

                // Extract optional fields
                $port = trim($data['port'] ?? '');
                $severity = trim($data['severity'] ?? '');
                $plugin_id = trim($data['plugin_id'] ?? '');
                $cve = trim($data['cve'] ?? '');
                $solution = trim($data['solution'] ?? '');
                $plugin_output = trim($data['plugin_output'] ?? '');

                // Insert the vulnerability
                $stmt = $pdo->prepare("
                    INSERT INTO va_vulnerabilities
                    (report_id, ip_address, host_name, vulnerability_name, port, severity, plugin_id, cve, solution, plugin_output)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                try {
                    $stmt->execute([
                        $report_id,
                        $ip_address,
                        $host_name,
                        $vulnerability_name,
                        $port,
                        $severity,
                        $plugin_id,
                        $cve,
                        $solution,
                        $plugin_output
                    ]);

                    $imported++;
                } catch (Exception $e) {
                    $skipped++;
                }
            }

            fclose($handle);
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Vulnerabilities CSV | <?= htmlspecialchars($appName) ?></title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Vulnerabilities CSV</h2>

        <?php if ($imported > 0 || $skipped > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Imported</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped; ?></strong>
                </div>
            </div>
            <p class="text-center" style="margin-top: 20px;">
                <a href="vulnerabilities.php" class="btn btn-primary">Return to Vulnerabilities List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="vulnerabilities.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
