<?php
// compliance-export.php
//
// Exports the security compliance register (or a single platform, via
// ?platform_id=) as a Word-compatible document. Word (and most office
// suites) will happily open a .doc file that is really HTML, which avoids
// needing a PHPWord/COM dependency on the server -- the same technique
// sop-export.php and knowledge-export.php use.
//
// Unlike those two, this is a listing export (many controls across one or
// more platforms) rather than a single-record narrative, so it skips their
// MHTML image-packaging and running header/footer bands: there is nothing
// here to embed.

session_start();

require_once __DIR__ . '/config/db.php';

/*
| Authorization. The verb is checked here, in the file that does the
| work, so it cannot be bypassed by calling this endpoint directly.
*/
requireLogin();
requirePermission('compliance', 'can_view');
requirePermission('compliance', 'can_export');

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

$platformId = isset($_GET['platform_id'])
    ? (int)$_GET['platform_id']
    : 0;

/*
|--------------------------------------------------------------------------
| Load Platforms
|--------------------------------------------------------------------------
*/

if ($platformId) {

    $platformStmt = $pdo->prepare("
        SELECT *
        FROM compliance_platforms
        WHERE id = ?
    ");

    $platformStmt->execute([$platformId]);

} else {

    $platformStmt = $pdo->query("
        SELECT *
        FROM compliance_platforms
        ORDER BY sort_order, platform_name
    ");
}

$platforms = $platformStmt->fetchAll(PDO::FETCH_ASSOC);

if (!$platforms) {
    http_response_code(404);
    exit('No compliance platforms found to export.');
}

/*
|--------------------------------------------------------------------------
| Load Controls
|--------------------------------------------------------------------------
*/

$controls = [];

$controlStmt = $pdo->prepare("
    SELECT *
    FROM compliance_controls
    WHERE platform_id = ?
    ORDER BY sort_order, control_number
");

foreach ($platforms as $platform) {

    $controlStmt->execute([$platform['id']]);

    $controls[$platform['id']] =
        $controlStmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| Summary
|--------------------------------------------------------------------------
*/

$totalControls = 0;
$totalCustom = 0;
$totalCustomized = 0;

foreach ($controls as $platformControls) {
    foreach ($platformControls as $control) {

        $totalControls++;

        if ((int)$control['is_custom']) {
            $totalCustom++;
        }

        if (trim((string)$control['cis_value']) !== trim((string)$control['ncgr_value'])) {
            $totalCustomized++;
        }
    }
}

$generatedBy = trim(($_SESSION['name'] ?? '') ?: ($_SESSION['ncgr_id'] ?? 'Unknown user'));

$reportTitle = $platformId
    ? $platforms[0]['platform_name'] . ' Compliance Controls'
    : 'Security Compliance Register';

$filename = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $reportTitle);
$filename = trim($filename, '_') . '.doc';

ob_start();
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title><?= h($reportTitle) ?></title>
<!--[if gte mso 9]>
<xml>
<o:DocumentProperties>
    <o:Title><?= h($reportTitle) ?></o:Title>
    <o:Subject>Security Compliance Register</o:Subject>
    <o:Author><?= h($generatedBy) ?></o:Author>
    <o:Category>CIS / NCGR Compliance Controls</o:Category>
</o:DocumentProperties>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>100</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
    @page Section1 {
        size: 29.7cm 21.0cm;
        mso-page-orientation: landscape;
        margin: 2.0cm 1.6cm 2.0cm 1.6cm;
    }
    div.Section1 { page: Section1; }

    body {
        font-family: Calibri, Arial, sans-serif;
        font-size: 10pt;
        line-height: 1.4;
        color: #1F2937;
    }

    p { margin: 0 0 8pt; }

    .cover-rule {
        border-top: 3pt solid #0F2A44;
        margin-bottom: 14pt;
    }
    .cover-eyebrow {
        font-size: 9pt;
        letter-spacing: 1.4pt;
        text-transform: uppercase;
        color: #64748B;
        margin-bottom: 10pt;
    }
    .cover-title {
        font-size: 22pt;
        font-weight: bold;
        color: #0F2A44;
        margin: 0 0 8pt;
    }
    .cover-meta {
        font-size: 9.5pt;
        color: #475569;
        margin-bottom: 18pt;
    }

    table.summary-table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 20pt;
    }
    table.summary-table td {
        border: .75pt solid #D8E0EA;
        padding: 8pt 10pt;
        text-align: center;
    }
    table.summary-table .summary-label {
        display: block;
        font-size: 8pt;
        text-transform: uppercase;
        letter-spacing: .6pt;
        color: #64748B;
        margin-bottom: 3pt;
    }
    table.summary-table .summary-value {
        font-size: 15pt;
        font-weight: bold;
        color: #0F2A44;
    }

    h1.platform-h1 {
        font-size: 13pt;
        color: #0F2A44;
        border-bottom: 1.5pt solid #1D4ED8;
        padding-bottom: 4pt;
        margin: 20pt 0 8pt;
        page-break-after: avoid;
    }
    p.platform-meta {
        font-size: 9pt;
        color: #64748B;
        margin: -4pt 0 10pt;
    }

    table.control-table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 16pt;
        font-size: 9pt;
    }
    table.control-table th, table.control-table td {
        border: .75pt solid #D8E0EA;
        padding: 5pt 7pt;
        vertical-align: top;
        text-align: left;
    }
    table.control-table th {
        background: #0F2A44;
        color: #FFFFFF;
        font-size: 8pt;
        letter-spacing: .4pt;
        text-transform: uppercase;
    }
    tr.alt td { background: #F8FAFC; }

    .badge-custom {
        display: inline-block;
        background: #FEF3C7;
        color: #92400E;
        font-size: 7pt;
        font-weight: bold;
        padding: 1pt 4pt;
        margin-left: 4pt;
    }
    .badge-changed { color: #047857; font-weight: bold; }
    .badge-disabled { color: #94A3B8; font-style: italic; }

    p.doc-empty { color: #94A3B8; font-style: italic; }

    .doc-end {
        margin-top: 18pt;
        padding-top: 8pt;
        border-top: .75pt solid #D8E0EA;
        font-size: 8pt;
        color: #94A3B8;
        text-align: center;
        letter-spacing: 1pt;
        text-transform: uppercase;
    }
</style>
</head>
<body lang="EN-GB">

<div class="Section1">

    <div class="cover-rule"></div>
    <p class="cover-eyebrow">Vulnerability &amp; Controls</p>
    <p class="cover-title"><?= h($reportTitle) ?></p>
    <p class="cover-meta">Generated <?= h(date('d M Y H:i')) ?> by <?= h($generatedBy) ?></p>

    <table class="summary-table">
        <tr>
            <td style="width:25%">
                <span class="summary-label">Platforms</span>
                <span class="summary-value"><?= count($platforms) ?></span>
            </td>
            <td style="width:25%">
                <span class="summary-label">Total Controls</span>
                <span class="summary-value"><?= $totalControls ?></span>
            </td>
            <td style="width:25%">
                <span class="summary-label">NCGR Customized</span>
                <span class="summary-value"><?= $totalCustomized ?></span>
            </td>
            <td style="width:25%">
                <span class="summary-label">Custom Controls</span>
                <span class="summary-value"><?= $totalCustom ?></span>
            </td>
        </tr>
    </table>

    <?php foreach ($platforms as $platform): ?>

        <?php $platformControls = $controls[$platform['id']] ?? []; ?>

        <h1 class="platform-h1">
            <?= h($platform['platform_name']) ?>
            <?php if (!(int)$platform['is_active']): ?>
                <span class="badge-disabled">(Disabled)</span>
            <?php endif; ?>
        </h1>

        <p class="platform-meta">
            <?= h($platform['framework']) ?>
            <?php if ($platform['benchmark_name']): ?>
                &nbsp;&bull;&nbsp; <?= h($platform['benchmark_name']) ?>
            <?php endif; ?>
            <?php if ($platform['benchmark_version']): ?>
                v<?= h($platform['benchmark_version']) ?>
            <?php endif; ?>
            &nbsp;&bull;&nbsp; <?= count($platformControls) ?> control<?= count($platformControls) === 1 ? '' : 's' ?>
        </p>

        <?php if (!$platformControls): ?>

            <p class="doc-empty">No compliance controls have been configured for this platform.</p>

        <?php else: ?>

            <table class="control-table">
                <tr>
                    <th style="width:11%">Control</th>
                    <th style="width:25%">Requirement</th>
                    <th style="width:14%">CIS Baseline</th>
                    <th style="width:14%">NCGR Policy</th>
                    <th style="width:9%">Severity</th>
                    <th style="width:9%">Status</th>
                    <th style="width:18%">Remediation</th>
                </tr>
                <?php foreach ($platformControls as $i => $control): ?>
                    <?php $changed = trim((string)$control['cis_value']) !== trim((string)$control['ncgr_value']); ?>
                    <tr<?= $i % 2 ? ' class="alt"' : '' ?>>
                        <td>
                            <?= h($control['control_number']) ?>
                            <?php if ((int)$control['is_custom']): ?>
                                <span class="badge-custom">CUSTOM</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= h($control['title']) ?></strong><br>
                            <?= nl2br(h($control['description'])) ?>
                        </td>
                        <td><?= h($control['cis_value']) ?> <?= h($control['unit']) ?></td>
                        <td class="<?= $changed ? 'badge-changed' : '' ?>"><?= h($control['ncgr_value']) ?> <?= h($control['unit']) ?></td>
                        <td><?= h($control['severity']) ?></td>
                        <td><?= (int)$control['is_enabled'] ? 'Active' : 'Disabled' ?></td>
                        <td><?= nl2br(h($control['remediation'])) ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>

        <?php endif; ?>

    <?php endforeach; ?>

    <p class="doc-end">End of Report</p>

</div>

</body>
</html>
<?php

$document = ob_get_clean();

header('Content-Type: application/msword; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($document));
header('Cache-Control: max-age=0');

echo $document;
