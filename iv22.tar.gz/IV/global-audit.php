<?php

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/pagination-helpers.php';

requireLogin();

$current_user_id = (int) ($_SESSION['user_id'] ?? 0);

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| Combines the SOP / Knowledge Base / Known Issues audit trails (sop_audit,
| knowledge_base_audit, known_issue_audit -- all written by the shared
| logItemAction() in includes/permission-helpers.php) into one view.
|
| Reuses each module's own existing can_audit permission rather than a new
| page_key: a role only sees the modules it is already allowed to audit
| individually, Admin (can_audit=1 on every page) sees all three, and
| nothing new needs to be granted in Manage Permissions for this to work.
*/
$moduleMeta = [
    'sop'            => ['label' => 'SOP',            'permission_page' => 'sop',
                          'view_url' => 'sop.php?action=view&id=',
                          'code_label' => 'SOP #'],
    'knowledge_base' => ['label' => 'Knowledge Base',  'permission_page' => 'knowledge',
                          'view_url' => 'knowledge.php?action=view&id=',
                          'code_label' => 'KB #'],
    'known_issue'    => ['label' => 'Known Issue',     'permission_page' => 'known_issues',
                          'view_url' => 'known-issues.php?action=view&id=',
                          'code_label' => 'Issue #'],
];

$allowedModules = [];
foreach ($moduleMeta as $key => $meta) {
    if (can($meta['permission_page'], 'can_audit')) {
        $allowedModules[] = $key;
    }
}

if (empty($allowedModules)) {
    http_response_code(403);
    exit('You do not have permission to view the audit log.');
}

/*
|--------------------------------------------------------------------------
| BUILD THE COMBINED QUERY
|--------------------------------------------------------------------------
|
| Each `ON DELETE CASCADE` on these audit tables is a no-op (the shared
| $pdo connection never turns PRAGMA foreign_keys on), so audit rows for a
| SOP/article/issue that has since been deleted survive -- which is
| exactly what this page needs to show "who deleted X". Once the parent
| row is gone the LEFT JOIN returns NULL, so item_title falls back to the
| title snapshotted in `details` at log time (see logItemAction() callers).
*/
$unionParts = [];

if (in_array('sop', $allowedModules, true)) {
    $unionParts[] = "
        SELECT 'sop' AS module_key, sa.sop_id AS item_id,
               s.title AS item_title, s.sop_number AS item_code,
               sa.action AS action, sa.user_name AS user_name,
               sa.action_date AS action_date, sa.details AS details,
               (s.id IS NOT NULL) AS item_exists
        FROM sop_audit sa
        LEFT JOIN sops s ON s.id = sa.sop_id
    ";
}

if (in_array('knowledge_base', $allowedModules, true)) {
    $unionParts[] = "
        SELECT 'knowledge_base' AS module_key, ka.kb_id AS item_id,
               k.title AS item_title, NULL AS item_code,
               ka.action AS action, ka.user_name AS user_name,
               ka.action_date AS action_date, ka.details AS details,
               (k.id IS NOT NULL) AS item_exists
        FROM knowledge_base_audit ka
        LEFT JOIN knowledge_base k ON k.id = ka.kb_id
    ";
}

if (in_array('known_issue', $allowedModules, true)) {
    $unionParts[] = "
        SELECT 'known_issue' AS module_key, ia.issue_id AS item_id,
               ki.title AS item_title, ki.issue_number AS item_code,
               ia.action AS action, ia.user_name AS user_name,
               ia.action_date AS action_date, ia.details AS details,
               (ki.id IS NOT NULL) AS item_exists
        FROM known_issue_audit ia
        LEFT JOIN known_issues ki ON ki.id = ia.issue_id
    ";
}

$combined = '(' . implode(' UNION ALL ', $unionParts) . ')';

$actionOptions = $pdo->query("SELECT DISTINCT action FROM $combined AS t ORDER BY action")
    ->fetchAll(PDO::FETCH_COLUMN);

/*
|--------------------------------------------------------------------------
| FILTERS
|--------------------------------------------------------------------------
*/
$moduleFilter = trim($_GET['module'] ?? '');
if (!in_array($moduleFilter, $allowedModules, true)) {
    $moduleFilter = '';
}

$actionFilter = trim($_GET['action'] ?? '');
if (!in_array($actionFilter, $actionOptions, true)) {
    $actionFilter = '';
}

$keyword  = trim($_GET['keyword'] ?? '');
$dateFrom = trim($_GET['date_from'] ?? '');
$dateTo   = trim($_GET['date_to'] ?? '');

$where  = ['1=1'];
$params = [];

if ($moduleFilter !== '') {
    $where[] = 'module_key = ?';
    $params[] = $moduleFilter;
}

if ($actionFilter !== '') {
    $where[] = 'action = ?';
    $params[] = $actionFilter;
}

if ($keyword !== '') {
    $where[] = '(item_title LIKE ? OR item_code LIKE ? OR user_name LIKE ? OR details LIKE ?)';
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if ($dateFrom !== '') {
    $where[] = 'action_date >= ?';
    $params[] = $dateFrom . ' 00:00:00';
}

if ($dateTo !== '') {
    $where[] = 'action_date <= ?';
    $params[] = $dateTo . ' 23:59:59';
}

$where_sql = implode(' AND ', $where);

/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/
$limit  = resolveUserPageSize($pdo, $current_user_id);
$page   = max(1, (int) ($_GET['page'] ?? 1));
$offset = ($page - 1) * $limit;

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM $combined AS t WHERE $where_sql");
$total_stmt->execute($params);
$total_records = (int) $total_stmt->fetchColumn();
$total_pages   = max(1, (int) ceil($total_records / $limit));

if ($page > $total_pages) {
    $page   = $total_pages;
    $offset = ($page - 1) * $limit;
}

$data_stmt = $pdo->prepare("
    SELECT * FROM $combined AS t
    WHERE $where_sql
    ORDER BY action_date DESC, item_id DESC
    LIMIT $limit OFFSET $offset
");
$data_stmt->execute($params);
$rows = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

foreach ($rows as &$r) {
    $title = trim((string) ($r['item_title'] ?? ''));

    if ($title === '') {
        $det   = json_decode((string) ($r['details'] ?? ''), true);
        $title = is_array($det) ? trim((string) ($det['title'] ?? '')) : '';
    }

    if ($title === '') {
        $title = $moduleMeta[$r['module_key']]['code_label'] . $r['item_id'];
    }

    $r['_display_title'] = $title;
}
unset($r);

$hidden_filter_fields = ''
    . '<input type="hidden" name="module" value="' . htmlspecialchars($moduleFilter, ENT_QUOTES, 'UTF-8') . '">'
    . '<input type="hidden" name="action" value="' . htmlspecialchars($actionFilter, ENT_QUOTES, 'UTF-8') . '">'
    . '<input type="hidden" name="keyword" value="' . htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') . '">'
    . '<input type="hidden" name="date_from" value="' . htmlspecialchars($dateFrom, ENT_QUOTES, 'UTF-8') . '">'
    . '<input type="hidden" name="date_to" value="' . htmlspecialchars($dateTo, ENT_QUOTES, 'UTF-8') . '">';

$actionBadgeColors = [
    'CREATED'            => ['bg' => '#dcfce7', 'fg' => '#166534'],
    'EDITED'             => ['bg' => '#e0f2fe', 'fg' => '#0369a1'],
    'DELETED'            => ['bg' => '#fee2e2', 'fg' => '#991b1b'],
    'PUBLISHED'          => ['bg' => '#dcfce7', 'fg' => '#166534'],
    'REJECTED'           => ['bg' => '#fee2e2', 'fg' => '#991b1b'],
    'VISIBILITY_CHANGED' => ['bg' => '#fef3c7', 'fg' => '#92400e'],
];

$page_title = "Global Audit Log | InfraVault";

include "includes/header.php";
include "includes/sidebar.php";
?>
<link rel="stylesheet" href="assets/css/ip.css">
<div class="content">
<div class="ip-page">

<div class="page-header">
    <div>
        <h1>Global Audit Log</h1>
        <p>Every create, edit and delete recorded across SOP, Knowledge Base and Known Issues, newest first.</p>
    </div>
</div>

<div class="ip-toolbar">
    <form method="GET" class="search-box" style="display:flex;gap:10px;flex-wrap:wrap;align-items:center;">
        <input
            type="text"
            name="keyword"
            placeholder="Search item title, number, or user..."
            value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') ?>"
            style="min-width:220px;"
        >

        <?php if (count($allowedModules) > 1): ?>
        <select name="module" class="form-control" style="max-width:170px;">
            <option value="">All modules</option>
            <?php foreach ($allowedModules as $mk): ?>
                <option value="<?= htmlspecialchars($mk, ENT_QUOTES, 'UTF-8') ?>" <?= $moduleFilter === $mk ? 'selected' : '' ?>>
                    <?= htmlspecialchars($moduleMeta[$mk]['label'], ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php endif; ?>

        <select name="action" class="form-control" style="max-width:170px;">
            <option value="">All actions</option>
            <?php foreach ($actionOptions as $opt): ?>
                <option value="<?= htmlspecialchars($opt, ENT_QUOTES, 'UTF-8') ?>" <?= $actionFilter === $opt ? 'selected' : '' ?>>
                    <?= htmlspecialchars(ucwords(strtolower(str_replace('_', ' ', $opt))), ENT_QUOTES, 'UTF-8') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label style="font-size:12.5px;color:#6b7280;font-weight:600;">From
            <input type="date" name="date_from" value="<?= htmlspecialchars($dateFrom, ENT_QUOTES, 'UTF-8') ?>">
        </label>
        <label style="font-size:12.5px;color:#6b7280;font-weight:600;">To
            <input type="date" name="date_to" value="<?= htmlspecialchars($dateTo, ENT_QUOTES, 'UTF-8') ?>">
        </label>

        <button class="primary-btn">Search</button>
        <?php if ($keyword !== '' || $moduleFilter !== '' || $actionFilter !== '' || $dateFrom !== '' || $dateTo !== ''): ?>
            <a href="global-audit.php" class="secondary-btn">Clear</a>
        <?php endif; ?>
        <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
    </form>
</div>

<div class="ip-card">
<table class="ip-table">
<thead>
<tr>
    <th>Module</th>
    <th>Item</th>
    <th>Action</th>
    <th>Performed By</th>
    <th>Date &amp; Time</th>
</tr>
</thead>
<tbody>
<?php if (count($rows)): ?>
    <?php foreach ($rows as $r): ?>
    <?php
        $meta   = $moduleMeta[$r['module_key']];
        $color  = $actionBadgeColors[$r['action']] ?? ['bg' => '#e5e7eb', 'fg' => '#374151'];
        $canLink = (int) $r['item_exists'] === 1;
    ?>
    <tr>
        <td><?= htmlspecialchars($meta['label'], ENT_QUOTES, 'UTF-8') ?></td>
        <td>
            <?php if ($canLink): ?>
                <a href="<?= htmlspecialchars($meta['view_url'] . (int) $r['item_id'], ENT_QUOTES, 'UTF-8') ?>">
                    <?= htmlspecialchars($r['_display_title'], ENT_QUOTES, 'UTF-8') ?>
                </a>
            <?php else: ?>
                <span title="This item no longer exists"><?= htmlspecialchars($r['_display_title'], ENT_QUOTES, 'UTF-8') ?> <em style="color:#94a3b8;">(deleted)</em></span>
            <?php endif; ?>
        </td>
        <td>
            <span class="environment" style="background:<?= $color['bg'] ?>;color:<?= $color['fg'] ?>">
                <?= htmlspecialchars(ucwords(strtolower(str_replace('_', ' ', (string) $r['action']))), ENT_QUOTES, 'UTF-8') ?>
            </span>
        </td>
        <td><?= htmlspecialchars((string) $r['user_name'], ENT_QUOTES, 'UTF-8') ?></td>
        <td><?= htmlspecialchars((string) $r['action_date'], ENT_QUOTES, 'UTF-8') ?></td>
    </tr>
    <?php endforeach; ?>
<?php else: ?>
    <tr>
        <td colspan="5" class="empty">No audit history found</td>
    </tr>
<?php endif; ?>
</tbody>
</table>

<?= ivPager($page, $total_pages, [
    'module'    => $moduleFilter,
    'action'    => $actionFilter,
    'keyword'   => $keyword,
    'date_from' => $dateFrom,
    'date_to'   => $dateTo,
], ['base' => 'global-audit.php', 'total_records' => $total_records, 'per_page' => $limit]) ?>

</div>

</div>
</div>
<?php include "includes/footer.php"; ?>
