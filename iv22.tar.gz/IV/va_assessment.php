<?php
/**
 * VA Assessment -- folders of combined vulnerability-scan CSVs.
 *
 * Reached from the "DMZ Assessment" (vulnerabilities.php) page header.
 * Distinct from that page's per-report tracking workflow: here a folder
 * (e.g. a date, or an audit cycle name) holds one or more raw scanner CSV
 * exports -- one per project/application -- that get combined, tagged
 * with a Project column (matched from inventory by IP) and an RHEL /
 * RHEL-Kernel tag, and downloaded as a single two-sheet spreadsheet.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/va-assessment-helpers.php';
require_once __DIR__ . '/includes/audit-history-helpers.php';

requireLogin();
requirePermission('va_assessment', 'can_view');

$canEdit   = can('va_assessment', 'can_edit');
$canDelete = can('va_assessment', 'can_delete');
$canAudit  = can('va_assessment', 'can_audit');

$currentUserName = trim(
    ($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '')
) ?: 'Admin';

$page_title = 'VA Assessment | InfraVault';

$message = '';
$error = '';


/*
|--------------------------------------------------------------------------
| CREATE FOLDER
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['create_folder'])) {

    csrfVerifyOrDie();

    if (!$canEdit) {
        http_response_code(403);
        exit('You do not have permission to create a VA Assessment folder.');
    }

    $name = trim((string) ($_POST['folder_name'] ?? ''));

    if ($name === '') {
        $error = 'Please enter a folder name.';
    } else {
        $stmt = $pdo->prepare("
            INSERT INTO va_folders (name, created_by)
            VALUES (?, ?)
        ");
        $stmt->execute([$name, (int) ($_SESSION['user_id'] ?? 0)]);

        $newFolderId = (int) $pdo->lastInsertId();

        logAuditHistory($pdo, 'VA Folder', $newFolderId, 'Created', $currentUserName, 'Folder "' . $name . '" created.');

        header('Location: va_assessment_folder.php?id=' . $newFolderId);
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| DELETE FOLDER
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_folder'])) {

    csrfVerifyOrDie();

    if (!$canDelete) {
        http_response_code(403);
        exit('You do not have permission to delete a VA Assessment folder.');
    }

    $folderId = (int) ($_POST['folder_id'] ?? 0);

    if ($folderId > 0) {

        $folderNameStmt = $pdo->prepare("SELECT name FROM va_folders WHERE id = ?");
        $folderNameStmt->execute([$folderId]);
        $folderName = $folderNameStmt->fetchColumn() ?: ('#' . $folderId);

        $filesStmt = $pdo->prepare("SELECT file_path FROM va_folder_files WHERE folder_id = ?");
        $filesStmt->execute([$folderId]);
        $filePaths = $filesStmt->fetchAll(PDO::FETCH_COLUMN);

        /*
         * Deleted explicitly rather than relying on the ON DELETE CASCADE
         * in the schema: the shared $pdo connection from config/db.php
         * never runs `PRAGMA foreign_keys = ON`, so that cascade is a
         * silent no-op here and would otherwise leak orphaned rows.
         */
        $pdo->prepare("DELETE FROM va_folder_rows WHERE folder_id = ?")->execute([$folderId]);
        $pdo->prepare("DELETE FROM va_folder_files WHERE folder_id = ?")->execute([$folderId]);
        $pdo->prepare("DELETE FROM va_folders WHERE id = ?")->execute([$folderId]);

        foreach ($filePaths as $path) {
            if (!empty($path) && is_file($path)) {
                @unlink($path);
            }
        }

        logAuditHistory(
            $pdo,
            'VA Folder',
            $folderId,
            'Deleted',
            $currentUserName,
            'Deleted folder "' . $folderName . '" and its ' . count($filePaths) . ' file(s).'
        );

        header('Location: va_assessment.php?deleted=1');
        exit;
    }
}

if (isset($_GET['deleted'])) {
    $message = 'Folder deleted successfully.';
}


/*
|--------------------------------------------------------------------------
| HISTORY AJAX
|--------------------------------------------------------------------------
|
| No record_id -> every folder/file event across the module.
| With record_id -> just that one folder's events (its own create/delete
| entries, plus every file uploaded/removed inside it -- file-level
| entries are logged with the folder's id, not the file's, for exactly
| this reason).
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="va-history-empty">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyRecordId = isset($_GET['record_id']) && $_GET['record_id'] !== ''
        ? (int) $_GET['record_id']
        : null;

    echo auditHistoryHtml($pdo, ['VA Folder', 'VA Folder File'], $historyRecordId);
    exit;
}


require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<link rel="stylesheet" href="assets/css/vulnerabilities.css">
<link rel="stylesheet" href="assets/css/va-assessment.css">

<div class="content va-page">

    <div class="va-page-header">

        <div>
            <div class="va-breadcrumb">
                <a href="vulnerabilities.php">DMZ Assessment</a> / VA Assessment
            </div>
            <h1>VA Assessment</h1>
            <p>Combine multiple scanner CSV exports into one project-tagged dataset.</p>
        </div>

        <div class="va-header-actions">
            <a href="vulnerabilities.php" class="va-btn va-btn-secondary">&larr; Back to DMZ Assessment</a>
            <?php if ($canAudit): ?>
                <button type="button" class="va-btn va-btn-secondary" onclick="vaOpenHistory()">&#9201; History</button>
            <?php endif; ?>
            <?php if ($canEdit): ?>
                <button type="button" class="va-btn va-btn-primary" onclick="vaShowNewFolder()">+ New Folder</button>
            <?php endif; ?>
        </div>

    </div>

    <?php if ($message !== ''): ?>
        <div class="va-alert va-alert-success"><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <?php if ($error !== ''): ?>
        <div class="va-alert va-alert-error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8'); ?></div>
    <?php endif; ?>

    <?php if ($canEdit): ?>
    <div id="vaNewFolderCard" class="va-upload-card" style="display:none; max-width:520px;">
        <form method="POST" style="padding:22px;">
            <?= csrfField(); ?>
            <label style="display:block; font-size:13px; font-weight:700; color:var(--text-secondary); margin-bottom:8px;">
                Folder Name
            </label>
            <input
                type="text"
                name="folder_name"
                required
                value="<?= htmlspecialchars(date('Y-m-d'), ENT_QUOTES, 'UTF-8'); ?>"
                style="width:100%; padding:9px 10px; border:1px solid var(--border-color); border-radius:6px; background:var(--bg-content); color:var(--text-secondary); font-size:13px; margin-bottom:14px;"
            >
            <div style="display:flex; gap:8px;">
                <button type="submit" name="create_folder" value="1" class="va-btn va-btn-primary">Create</button>
                <button type="button" class="va-btn va-btn-secondary" onclick="vaHideNewFolder()">Cancel</button>
            </div>
        </form>
    </div>
    <?php endif; ?>

    <?php

    $folders = $pdo->query("
        SELECT
            f.*,
            u.first_name, u.last_name,
            (SELECT COUNT(*) FROM va_folder_files ff WHERE ff.folder_id = f.id) AS file_count,
            (SELECT COUNT(*) FROM va_folder_rows fr WHERE fr.folder_id = f.id) AS row_count
        FROM va_folders f
        LEFT JOIN users u ON u.id = f.created_by
        ORDER BY f.created_at DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    ?>

    <?php if (!$folders): ?>

        <div class="va-empty">
            <div class="va-empty-icon">&#128193;</div>
            <h2>No Folders Yet</h2>
            <p>Create a folder (e.g. today's date) and upload the scanner CSVs into it.</p>
            <?php if ($canEdit): ?>
                <button type="button" class="va-btn va-btn-primary" onclick="vaShowNewFolder()">+ New Folder</button>
            <?php endif; ?>
        </div>

    <?php else: ?>

        <div class="va-report-grid">

            <?php foreach ($folders as $folder): ?>

                <?php
                    $createdBy = trim((string) ($folder['created_by_name'] ?? ''));
                    if ($createdBy === '') {
                        $createdBy = trim(($folder['first_name'] ?? '') . ' ' . ($folder['last_name'] ?? ''));
                    }
                ?>

                <div class="va-report-card">

                    <div class="va-report-top">

                        <div class="va-file-icon">&#128193;</div>

                        <div class="va-report-info">
                            <a href="va_assessment_folder.php?id=<?= (int) $folder['id']; ?>" class="va-report-name">
                                <?= htmlspecialchars($folder['name'], ENT_QUOTES, 'UTF-8'); ?>
                            </a>
                            <div class="va-report-meta">
                                Created <?= htmlspecialchars($folder['created_at'] ?? '', ENT_QUOTES, 'UTF-8'); ?>
                                <?php if ($createdBy !== ''): ?>
                                    by <?= htmlspecialchars($createdBy, ENT_QUOTES, 'UTF-8'); ?>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>

                    <div class="va-report-stats" style="grid-template-columns: repeat(2, minmax(0,1fr));">
                        <div>
                            <strong><?= (int) $folder['file_count']; ?></strong>
                            <span>Files</span>
                        </div>
                        <div>
                            <strong><?= (int) $folder['row_count']; ?></strong>
                            <span>Findings</span>
                        </div>
                    </div>

                    <div class="va-report-footer">
                        <span>&nbsp;</span>
                        <div>
                            <a href="va_assessment_folder.php?id=<?= (int) $folder['id']; ?>" class="va-btn va-btn-secondary">Open</a>

                            <?php if ($canAudit): ?>
                                <button
                                    type="button"
                                    class="va-history-btn"
                                    title="History"
                                    aria-label="Folder history"
                                    onclick="vaOpenHistory(<?= (int) $folder['id']; ?>)"
                                >
                                    &#9201;
                                </button>
                            <?php endif; ?>

                            <?php if ($canDelete): ?>
                                <form
                                    method="POST"
                                    style="display:inline;"
                                    onsubmit="return confirm('Delete this folder and all its uploaded files? This cannot be undone.');"
                                >
                                    <?= csrfField(); ?>
                                    <input type="hidden" name="folder_id" value="<?= (int) $folder['id']; ?>">
                                    <button type="submit" name="delete_folder" value="1" class="va-btn va-btn-danger">Delete</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

    <?php if ($canAudit): ?>

        <!-- =================================================
             HISTORY MODAL
        ================================================== -->

        <div class="va-modal-overlay" id="vaHistoryModal" onclick="if (event.target === this) vaCloseHistory();">
            <div class="va-modal-box">
                <div class="va-modal-header">
                    <h3 id="vaHistoryTitle">Folder History</h3>
                    <button type="button" class="va-modal-close" aria-label="Close" onclick="vaCloseHistory();">&times;</button>
                </div>
                <div class="va-modal-body" id="vaHistoryBody">
                    <p class="va-history-empty">Loading...</p>
                </div>
            </div>
        </div>

    <?php endif; ?>

</div>

<script>
function vaShowNewFolder() {
    document.getElementById('vaNewFolderCard').style.display = 'block';
}
function vaHideNewFolder() {
    document.getElementById('vaNewFolderCard').style.display = 'none';
}

<?php if ($canAudit): ?>
function vaOpenHistory(folderId) {
    const modal = document.getElementById('vaHistoryModal');
    const title = document.getElementById('vaHistoryTitle');
    const body = document.getElementById('vaHistoryBody');

    title.textContent = folderId ? 'Folder History' : 'All VA Assessment History';
    body.innerHTML = '<p class="va-history-empty">Loading...</p>';
    modal.classList.add('is-open');

    const url = 'va_assessment.php?action=get_history' + (folderId ? '&record_id=' + folderId : '');

    fetch(url)
        .then(response => response.text())
        .then(html => { body.innerHTML = html; })
        .catch(() => { body.innerHTML = '<p class="va-history-empty">Failed to load history.</p>'; });
}

function vaCloseHistory() {
    document.getElementById('vaHistoryModal').classList.remove('is-open');
}
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
