/* =====================================================
   InfraVault Compliance
===================================================== */


/* =====================================================
   PLATFORM EXPAND / COLLAPSE
===================================================== */

function togglePlatform(button) {

    const card =
        button.closest('.platform-card');

    if (!card) {
        return;
    }

    card.classList.toggle('expanded');

}


/* =====================================================
   SEARCH
===================================================== */

function filterCompliance() {

    const search =
        document
            .getElementById('complianceSearch')
            .value
            .toLowerCase()
            .trim();

    const severity =
        document
            .getElementById('severityFilter')
            .value
            .toLowerCase();

    const cards =
        document.querySelectorAll(
            '.platform-card'
        );

    cards.forEach(function(card) {

        const rows =
            card.querySelectorAll(
                '.control-row'
            );

        let visible = 0;

        rows.forEach(function(row) {

            const text =
                row.dataset.search || '';

            const rowSeverity =
                (
                    row.dataset.severity || ''
                ).toLowerCase();

            const matchesSearch =
                !search ||
                text.includes(search);

            const matchesSeverity =
                !severity ||
                rowSeverity === severity;

            if (
                matchesSearch &&
                matchesSeverity
            ) {

                row.style.display = '';

                visible++;

            } else {

                row.style.display = 'none';

            }

        });


        /*
        |--------------------------------------------------------------------------
        | Show/hide platform
        |--------------------------------------------------------------------------
        */

        if (visible > 0) {

            card.style.display = '';

            if (search || severity) {

                card.classList.add(
                    'expanded'
                );

            }

        } else {

            card.style.display = 'none';

        }

    });

}


/* =====================================================
   ADD CONTROL
===================================================== */

function openAddControl() {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    document.getElementById(
        'modalTitle'
    ).textContent =
        'Add Compliance Control';

    document.getElementById(
        'formAction'
    ).value =
        'add_control';

    document.getElementById(
        'control_id'
    ).value = '';

    document.getElementById(
        'controlForm'
    ).reset();

    document.getElementById(
        'formAction'
    ).value =
        'add_control';

    document.getElementById(
        'control_id'
    ).value = '';

    document.getElementById(
        'is_enabled'
    ).checked = true;

    modal.classList.add('show');

}


/* =====================================================
   EDIT CONTROL
===================================================== */

function editControl(control) {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    document.getElementById(
        'modalTitle'
    ).textContent =
        'Edit Compliance Control';

    document.getElementById(
        'formAction'
    ).value =
        'update_control';

    document.getElementById(
        'control_id'
    ).value =
        control.id || '';

    setValue(
        'platform_id',
        control.platform_id
    );

    setValue(
        'control_number',
        control.control_number
    );

    setValue(
        'title',
        control.title
    );

    setValue(
        'description',
        control.description
    );

    setValue(
        'section_name',
        control.section_name
    );

    setValue(
        'level',
        control.level
    );

    setValue(
        'severity',
        control.severity
    );

    setValue(
        'control_type',
        control.control_type
    );

    setValue(
        'value_type',
        control.value_type
    );

    setValue(
        'cis_value',
        control.cis_value
    );

    setValue(
        'ncgr_value',
        control.ncgr_value
    );

    setValue(
        'unit',
        control.unit
    );

    setValue(
        'remediation',
        control.remediation
    );

    setValue(
        'audit_procedure',
        control.audit_procedure
    );

    document.getElementById(
        'is_enabled'
    ).checked =
        Number(control.is_enabled) === 1;

    modal.classList.add('show');

}


/* =====================================================
   FORM VALUE
===================================================== */

function setValue(id, value) {

    const element =
        document.getElementById(id);

    if (!element) {
        return;
    }

    element.value =
        value === null ||
        value === undefined
            ? ''
            : value;

}


/* =====================================================
   CLOSE MODAL
===================================================== */

function closeControlModal() {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    modal.classList.remove('show');

}


/* =====================================================
   ADD PLATFORM
===================================================== */

function openAddPlatform() {

    const modal =
        document.getElementById('platformModal');

    if (!modal) {
        return;
    }

    document.getElementById('platformModalTitle').textContent =
        'Add Platform';

    document.getElementById('platformFormAction').value =
        'add_platform';

    document.getElementById('platform_id_field').value = '';

    document.getElementById('platformForm').reset();

    document.getElementById('platformFormAction').value =
        'add_platform';

    document.getElementById('platform_id_field').value = '';

    document.getElementById('platform_is_active').checked = true;

    modal.classList.add('show');

}


/* =====================================================
   EDIT PLATFORM
===================================================== */

function editPlatform(platform) {

    const modal =
        document.getElementById('platformModal');

    if (!modal) {
        return;
    }

    document.getElementById('platformModalTitle').textContent =
        'Edit Platform';

    document.getElementById('platformFormAction').value =
        'update_platform';

    document.getElementById('platform_id_field').value =
        platform.id || '';

    setValue('platform_key', platform.platform_key);
    setValue('platform_name', platform.platform_name);
    setValue('category', platform.category);
    setValue('framework', platform.framework);
    setValue('benchmark_name', platform.benchmark_name);
    setValue('benchmark_version', platform.benchmark_version);
    setValue('platform_description', platform.description);

    document.getElementById('platform_is_active').checked =
        Number(platform.is_active) === 1;

    modal.classList.add('show');

}


/* =====================================================
   CLOSE PLATFORM MODAL
===================================================== */

function closePlatformModal() {

    const modal =
        document.getElementById('platformModal');

    if (!modal) {
        return;
    }

    modal.classList.remove('show');

}


/* =====================================================
   DELETE CONTROL / PLATFORM
===================================================== */

function deleteControl(id, label) {

    if (!confirm('Delete compliance control "' + label + '"? This cannot be undone.')) {
        return;
    }

    document.getElementById('deleteControlId').value = id;
    document.getElementById('deleteControlForm').submit();

}

function deletePlatform(id, name, controlCount) {

    const warning =
        controlCount > 0
            ? 'Delete platform "' + name + '"? This will also permanently delete its ' +
              controlCount + ' control' + (controlCount === 1 ? '' : 's') + '. This cannot be undone.'
            : 'Delete platform "' + name + '"? This cannot be undone.';

    if (!confirm(warning)) {
        return;
    }

    document.getElementById('deletePlatformId').value = id;
    document.getElementById('deletePlatformForm').submit();

}


/* =====================================================
   HISTORY
===================================================== */

function openHistory(options) {

    options = options || {};

    const modal =
        document.getElementById('historyModal');

    if (!modal) {
        return;
    }

    document.getElementById('historyModalTitle').textContent =
        options.title
            ? 'History: ' + options.title
            : 'Compliance History';

    const body =
        document.getElementById('historyBody');

    body.innerHTML =
        '<div class="empty-state">Loading history...</div>';

    modal.classList.add('show');

    const params = new URLSearchParams();
    params.set('ajax', 'history');

    if (options.platformId) {
        params.set('platform_id', options.platformId);
    }

    if (options.controlId) {
        params.set('control_id', options.controlId);
    }

    fetch('compliance.php?' + params.toString())
        .then(function(response) {
            return response.json();
        })
        .then(function(rows) {
            renderHistory(body, rows);
        })
        .catch(function() {
            body.innerHTML =
                '<div class="empty-state">Failed to load history.</div>';
        });

}

function renderHistory(body, rows) {

    if (rows && rows.error) {
        body.innerHTML =
            '<div class="empty-state">' + escapeHtml(rows.error) + '</div>';
        return;
    }

    if (!rows || !rows.length) {
        body.innerHTML =
            '<div class="empty-state">No history recorded yet.</div>';
        return;
    }

    let html = '<table class="control-table history-table"><thead><tr>' +
        '<th>Date</th><th>Platform</th><th>Control</th><th>Action</th>' +
        '<th>Performed By</th><th>Details</th>' +
        '</tr></thead><tbody>';

    rows.forEach(function(row) {

        const control =
            row.control_number
                ? row.control_number + ' - ' + (row.control_title || '')
                : '';

        html += '<tr>' +
            '<td><small>' + escapeHtml(row.created_at || '') + '</small></td>' +
            '<td>' + escapeHtml(row.platform_name || '') + '</td>' +
            '<td>' + escapeHtml(control) + '</td>' +
            '<td>' + escapeHtml(row.action || '') + '</td>' +
            '<td>' + escapeHtml(row.performed_by || '') + '</td>' +
            '<td>' + escapeHtml(row.details || '') + '</td>' +
            '</tr>';

    });

    html += '</tbody></table>';

    body.innerHTML = html;

}

function escapeHtml(value) {

    const div = document.createElement('div');
    div.textContent = value === null || value === undefined ? '' : String(value);
    return div.innerHTML;

}

function closeHistoryModal() {

    const modal =
        document.getElementById('historyModal');

    if (!modal) {
        return;
    }

    modal.classList.remove('show');

}


/* =====================================================
   CLICK OUTSIDE MODAL
===================================================== */

document.addEventListener(
    'click',
    function(event) {

        const modalIds = [
            ['controlModal', closeControlModal],
            ['platformModal', closePlatformModal],
            ['historyModal', closeHistoryModal]
        ];

        modalIds.forEach(function(pair) {

            const modal =
                document.getElementById(pair[0]);

            if (modal && event.target === modal) {
                pair[1]();
            }

        });

    }
);


/* =====================================================
   ESCAPE
===================================================== */

document.addEventListener(
    'keydown',
    function(event) {

        if (
            event.key === 'Escape'
        ) {

            closeControlModal();
            closePlatformModal();
            closeHistoryModal();

        }

    }
);

