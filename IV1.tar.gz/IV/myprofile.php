<?php

session_start();

require_once __DIR__ . '/config/db.php';


if (!isset($_SESSION['user_id'])) {

    header("Location: index.php");
    exit;

}



$user_id = $_SESSION['user_id'];

$success_msg = "";
$error_msg = "";


// ===============================
// UPDATE SETTINGS
// ===============================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    $first_name = trim($_POST['first_name'] ?? '');
    $last_name  = trim($_POST['last_name'] ?? '');
    $email      = trim($_POST['email'] ?? '');


    $current_password = $_POST['current_password'] ?? '';
    $new_password     = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';



    $stmt = $pdo->prepare(
        "SELECT * FROM users WHERE id=?"
    );

    $stmt->execute([$user_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);



    if (!$user) {

        $error_msg = "User account not found.";

    }

    else {


        // Email duplicate check

        $check = $pdo->prepare(
            "SELECT id FROM users 
             WHERE email=? 
             AND id != ?"
        );


        $check->execute([
            $email,
            $user_id
        ]);



        if ($check->fetch()) {


            $error_msg =
            "Email address already exists.";


        }

        else {



            // Password change

            if (!empty($new_password)) {



                if (
                    empty($current_password)
                ) {


                    $error_msg =
                    "Current password is required.";


                }


                elseif (
                    !password_verify(
                        $current_password,
                        $user['password']
                    )
                ) {


                    $error_msg =
                    "Current password is incorrect.";


                }


                elseif (
                    $new_password !== $confirm_password
                ) {


                    $error_msg =
                    "New passwords do not match.";


                }


                else {


                    $hash =
                    password_hash(
                        $new_password,
                        PASSWORD_DEFAULT
                    );



                    $update =
                    $pdo->prepare(
                    "UPDATE users SET
                    first_name=?,
                    last_name=?,
                    email=?,
                    password=?
                    WHERE id=?"
                    );


                    $update->execute([

                        $first_name,
                        $last_name,
                        $email,
                        $hash,
                        $user_id

                    ]);



                    $_SESSION['first_name']
                    =
                    $first_name;



                    $success_msg =
                    "Profile and password updated successfully.";

                }



            }



            else {



                $update =
                $pdo->prepare(
                "UPDATE users SET
                first_name=?,
                last_name=?,
                email=?
                WHERE id=?"
                );


                $update->execute([

                    $first_name,
                    $last_name,
                    $email,
                    $user_id

                ]);



                $_SESSION['first_name']
                =
                $first_name;



                $success_msg =
                "Profile updated successfully.";

            }


        }


    }


}



// Fetch user

$stmt =
$pdo->prepare(
"SELECT * FROM users WHERE id=?"
);


$stmt->execute([
    $user_id
]);


$current_user =
$stmt->fetch(PDO::FETCH_ASSOC);

require_once __DIR__ . '/includes/sidebar.php';
require_once __DIR__ . '/includes/header.php';
?>
<div class="content">
<!DOCTYPE html>

<html lang="en">


<head>


<meta charset="UTF-8">


<title>
Settings | InfraVault
</title>


<link rel="stylesheet"
href="assets/css/style.css">


<link rel="stylesheet"
href="assets/css/dashboard.css">



<style>


.settings-wrapper{


max-width:900px;

margin:auto;


}



.settings-grid{


display:grid;

grid-template-columns:

1fr 1fr;


gap:25px;


}



.settings-card{


background:#fff;

border:1px solid #E5E7EB;

border-radius:18px;

padding:28px;


box-shadow:

0 5px 20px rgba(15,23,42,.05);


}



.settings-card h2{


font-size:20px;

margin-bottom:8px;

color:#111827;


}



.settings-card p{


color:#64748B;

font-size:14px;

margin-bottom:25px;


}



.form-group{


margin-bottom:18px;


}



.form-group label{


display:block;

font-size:13px;

font-weight:600;

margin-bottom:6px;

color:#374151;


}



.form-control{


width:100%;

height:40px;

border-radius:8px;

border:1px solid #CBD5E1;

padding:0 12px;

font-size:14px;


}



.form-control:focus{


outline:none;

border-color:#2563EB;


}



.locked{


background:#F1F5F9;

color:#64748B;

cursor:not-allowed;


}



.save-btn{


background:#2563EB;

color:white;

border:none;

padding:11px 22px;

border-radius:9px;

font-weight:600;

cursor:pointer;


}



.save-btn:hover{


background:#1D4ED8;


}



.password-title{


margin-top:20px;

padding-top:20px;

border-top:1px solid #E5E7EB;


}



.alert{


padding:14px;

border-radius:10px;

margin-bottom:20px;

font-size:14px;


}



.alert-success{


background:#ECFDF5;

color:#047857;


}



.alert-error{


background:#FEF2F2;

color:#B91C1C;


}



@media(max-width:900px){


.settings-grid{


grid-template-columns:1fr;


}


}



</style>


</head>



<body>










<main>


<div class="settings-wrapper">



<?php if($success_msg): ?>

<div class="alert alert-success">

<?= htmlspecialchars($success_msg) ?>

</div>

<?php endif; ?>



<?php if($error_msg): ?>

<div class="alert alert-error">

<?= htmlspecialchars($error_msg) ?>

</div>

<?php endif; ?>





<form method="POST">



<div class="settings-grid">



<!-- PROFILE -->


<div class="settings-card">


<h2>
Profile Information
</h2>


<p>
Update your personal account details.
</p>




<div class="form-group">

<label>
NCGR ID
</label>


<input
class="form-control locked"
value="<?= htmlspecialchars($current_user['ncgr_id']) ?>"
disabled>


<small style="color:#64748B;font-size:12px;">
NCGR ID cannot be modified.
</small>


</div>




<div class="form-group">


<label>
First Name
</label>


<input
type="text"
name="first_name"
class="form-control"
value="<?= htmlspecialchars($current_user['first_name']) ?>"
required>


</div>





<div class="form-group">


<label>
Last Name
</label>


<input
type="text"
name="last_name"
class="form-control"
value="<?= htmlspecialchars($current_user['last_name']) ?>"
required>


</div>





<div class="form-group">


<label>
Email Address
</label>


<input
type="email"
name="email"
class="form-control"
value="<?= htmlspecialchars($current_user['email']) ?>"
required>


</div>


</div>







<!-- SECURITY -->


<div class="settings-card">


<h2>
Security
</h2>


<p>
Change your account password.
</p>




<div class="form-group">


<label>
Current Password
</label>


<input
type="password"
name="current_password"
class="form-control">


</div>





<div class="form-group">


<label>
New Password
</label>


<input
type="password"
name="new_password"
class="form-control">


</div>





<div class="form-group">


<label>
Confirm Password
</label>


<input
type="password"
name="confirm_password"
class="form-control">


</div>





<button
type="submit"
class="save-btn">


Save Changes


</button>



</div>



</div>


</form>



</div>



</main>


</div>




<?php

require_once __DIR__ .
'/includes/footer.php';

?>




<script src="assets/js/sidebar.js"></script>



</body>


</html>
