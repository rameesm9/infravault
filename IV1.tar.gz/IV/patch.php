<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function redirect_patch($id = null): void
{
    if ($id !== null) {
        header(
            'Location: patch.php?view=' . (int) $id
        );
    } else {
        header('Location: patch.php');
    }

    exit;
}


function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $token
        )
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| Generate Reference
|--------------------------------------------------------------------------
*/

function generate_exception_number(PDO $pdo): string
{
    $stmt = $pdo->query("
        SELECT reference_no
        FROM patch_exceptions
        ORDER BY id DESC
        LIMIT 1
    ");

    $last = $stmt->fetchColumn();

    if (!$last) {
        return 'EXC-001';
    }

    if (preg_match('/(\d+)$/', $last, $matches)) {

        $number =
            ((int) $matches[1]) + 1;

        return 'EXC-' .
            str_pad(
                $number,
                3,
                '0',
                STR_PAD_LEFT
            );
    }

    return 'EXC-001';
}


/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

function can_edit_exception(
    array $row,
    int $user_id,
    bool $is_admin
): bool {
    return $is_admin ||
        (int) $row['owner_id'] === $user_id ||
        (int) $row['requested_by'] === $user_id;
}


function can_delete_exception(
    array $row,
    int $user_id,
    bool $is_admin
): bool {
    return $is_admin ||
        (int) $row['owner_id'] === $user_id ||
        (int) $row['requested_by'] === $user_id;
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

function process_exception_attachments(
    PDO $pdo,
    string $upload_dir,
    int $exception_id,
    int $user_id
): void {

    if (
        empty($_FILES['attachments']) ||
        empty($_FILES['attachments']['name'][0])
    ) {
        return;
    }


    if (!is_dir($upload_dir)) {

        if (!mkdir(
            $upload_dir,
            0755,
            true
        ) && !is_dir($upload_dir)) {
            return;
        }
    }


    $allowed = [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'csv',
        'ppt',
        'pptx',
        'txt',
        'png',
        'jpg',
        'jpeg',
        'gif',
        'webp',
        'zip'
    ];


    $count =
        count($_FILES['attachments']['name']);


    for ($i = 0; $i < $count; $i++) {

        if (
            !isset(
                $_FILES['attachments']['error'][$i]
            ) ||
            $_FILES['attachments']['error'][$i]
                !== UPLOAD_ERR_OK
        ) {
            continue;
        }


        $original =
            basename(
                $_FILES['attachments']['name'][$i]
            );


        $extension =
            strtolower(
                pathinfo(
                    $original,
                    PATHINFO_EXTENSION
                )
            );


        if (!in_array(
            $extension,
            $allowed,
            true
        )) {
            continue;
        }


        $safe_original =
            preg_replace(
                '/[^a-zA-Z0-9._-]/',
                '_',
                $original
            );


        $stored =
            bin2hex(random_bytes(12))
            . '_'
            . $safe_original;


        $destination =
            $upload_dir . '/' . $stored;


        if (
            move_uploaded_file(
                $_FILES['attachments']['tmp_name'][$i],
                $destination
            )
        ) {

            $relative =
                'uploads/patch/' . $stored;


            $mime =
                function_exists('mime_content_type')
                    ? (
                        mime_content_type($destination)
                        ?: 'application/octet-stream'
                    )
                    : 'application/octet-stream';


            $file_size =
                is_file($destination)
                    ? filesize($destination)
                    : 0;


            $stmt = $pdo->prepare("
                INSERT INTO patch_exception_attachments
                (
                    exception_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size,
                    uploaded_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $exception_id,
                $original,
                $stored,
                $relative,
                $mime,
                $file_size,
                $user_id
            ]);
        }
    }
}


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['patch_success'] ?? '';

$error_msg =
    $_SESSION['patch_error'] ?? '';

unset(
    $_SESSION['patch_success'],
    $_SESSION['patch_error']
);


$upload_dir =
    __DIR__ . '/uploads/patch';


/*
|--------------------------------------------------------------------------
| ACTION
|--------------------------------------------------------------------------
*/

$action =
    $_GET['action'] ?? 'list';

if (isset($_GET['view'])) {
    $action = 'view';
}


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $form_action =
        $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE EXCEPTION
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_exception') {

        $id =
            (int) ($_POST['exception_id'] ?? 0);


        $title =
            trim($_POST['title'] ?? '');


        $exception_type =
            trim($_POST['exception_type'] ?? '');


        $short_description =
            trim($_POST['short_description'] ?? '');


        $system_name =
            trim($_POST['system_name'] ?? '');


        $application_name =
            trim($_POST['application_name'] ?? '');


        $current_version =
            trim($_POST['current_version'] ?? '');


        $target_version =
            trim($_POST['target_version'] ?? '');


        $reason =
            trim($_POST['reason'] ?? '');


        $risk_description =
            trim($_POST['risk_description'] ?? '');


        $mitigation =
            trim($_POST['mitigation'] ?? '');


        $additional_details =
            trim($_POST['additional_details'] ?? '');


        $visibility =
            trim(
                $_POST['visibility']
                ?? 'Private'
            );


        $start_date =
            trim($_POST['start_date'] ?? '');


        $expiry_date =
            trim($_POST['expiry_date'] ?? '');


        $team =
            trim($_POST['team'] ?? '');


        $after_save =
            $_POST['after_save'] ?? '';


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {

            $_SESSION['patch_error'] =
                'Title is required.';

            redirect_patch(
                $id ?: null
            );
        }


        if (!in_array(
            $exception_type,
            [
                'Patch Exception',
                'Upgrade Exception',
                'Control Fix Exception'
            ],
            true
        )) {

            $_SESSION['patch_error'] =
                'Invalid exception type.';

            redirect_patch(
                $id ?: null
            );
        }


        if (!in_array(
            $visibility,
            [
                'Private',
                'Team',
                'Public'
            ],
            true
        )) {

            $visibility =
                'Private';
        }


        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($id === 0) {

            $reference_no =
                generate_exception_number(
                    $pdo
                );


            /*
            | New records always start at 1.0
            */

            $version =
                '1.0';


            $owner_id =
                $current_user_id;


            /*
            | Admin can select owner
            */

            if ($is_admin) {

                $posted_owner =
                    (int) (
                        $_POST['owner_id']
                        ?? 0
                    );

                if ($posted_owner > 0) {
                    $owner_id =
                        $posted_owner;
                }
            }


            /*
            | Status
            */

            $status =
                $after_save === 'submit'
                    ? 'Pending Review'
                    : 'Draft';


            /*
            |--------------------------------------------------------------------------
            | Insert Main Exception
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                INSERT INTO patch_exceptions
                (
                    reference_no,
                    title,
                    exception_type,
                    version,
                    short_description,
                    system_name,
                    application_name,
                    current_version,
                    target_version,
                    reason,
                    risk_description,
                    mitigation,
                    owner_id,
                    team,
                    visibility,
                    start_date,
                    expiry_date,
                    status,
                    requested_by,
                    additional_details,
                    created_at,
                    updated_at
                )
                VALUES
                (
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");


            $stmt->execute([
                $reference_no,
                $title,
                $exception_type,
                $version,
                $short_description,
                $system_name,
                $application_name,
                $current_version,
                $target_version,
                $reason,
                $risk_description,
                $mitigation,
                $owner_id,
                $team,
                $visibility,
                $start_date ?: null,
                $expiry_date ?: null,
                $status,
                $current_user_id,
                $additional_details
            ]);


            /*
            |--------------------------------------------------------------------------
            | Get New ID
            |--------------------------------------------------------------------------
            */

            $id =
                (int) $pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | Initial Revision
            |--------------------------------------------------------------------------
            */

            $revision = $pdo->prepare("
                INSERT INTO patch_exception_revisions
                (
                    exception_id,
                    version,
                    title,
                    exception_type,
                    short_description,
                    system_name,
                    application_name,
                    current_version,
                    target_version,
                    reason,
                    risk_description,
                    mitigation,
                    owner_id,
                    team,
                    visibility,
                    start_date,
                    expiry_date,
                    status,
                    additional_details,
                    changed_by,
                    change_summary
                )
                VALUES
                (
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?
                )
            ");


            $revision->execute([
                $id,
                $version,
                $title,
                $exception_type,
                $short_description,
                $system_name,
                $application_name,
                $current_version,
                $target_version,
                $reason,
                $risk_description,
                $mitigation,
                $owner_id,
                $team,
                $visibility,
                $start_date ?: null,
                $expiry_date ?: null,
                $status,
                $additional_details,
                $current_user_id,
                'Initial exception created'
            ]);


            /*
            |--------------------------------------------------------------------------
            | Attachments
            |--------------------------------------------------------------------------
            */

            process_exception_attachments(
                $pdo,
                $upload_dir,
                $id,
                $current_user_id
            );


            /*
            |--------------------------------------------------------------------------
            | Success
            |--------------------------------------------------------------------------
            */

            $_SESSION['patch_success'] =
                $status === 'Pending Review'
                    ? 'Exception created and submitted for Admin review.'
                    : 'Exception created successfully.';


            redirect_patch($id);
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE EXISTING EXCEPTION
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);


        $existing =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$existing) {

            $_SESSION['patch_error'] =
                'Exception not found.';

            redirect_patch();
        }


        /*
        |--------------------------------------------------------------------------
        | Permission
        |--------------------------------------------------------------------------
        */

        if (!can_edit_exception(
            $existing,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Determine Next Revision Version
        |--------------------------------------------------------------------------
        */

        $revision_stmt = $pdo->prepare("
            SELECT version
            FROM patch_exception_revisions
            WHERE exception_id = ?
            ORDER BY id DESC
            LIMIT 1
        ");

        $revision_stmt->execute([
            $id
        ]);


        $old_version =
            $revision_stmt->fetchColumn();


        if (!$old_version) {

            $old_version =
                $existing['version']
                ?? '1.0';
        }


        $version_parts =
            explode(
                '.',
                $old_version
            );


        $major =
            (int) (
                $version_parts[0]
                ?? 1
            );


        $minor =
            (int) (
                $version_parts[1]
                ?? 0
            );


        $new_version =
            $major .
            '.' .
            ($minor + 1);


        /*
        |--------------------------------------------------------------------------
        | Determine Status
        |--------------------------------------------------------------------------
        */

        $status =
            $after_save === 'submit'
                ? 'Pending Review'
                : 'Draft';


        /*
        |--------------------------------------------------------------------------
        | Owner
        |--------------------------------------------------------------------------
        */

        $owner_id =
            (int) $existing['owner_id'];


        if ($is_admin) {

            $posted_owner =
                (int) (
                    $_POST['owner_id']
                    ?? 0
                );

            if ($posted_owner > 0) {
                $owner_id =
                    $posted_owner;
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Update Main Exception
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            UPDATE patch_exceptions
            SET
                title = ?,
                exception_type = ?,
                version = ?,
                short_description = ?,
                system_name = ?,
                application_name = ?,
                current_version = ?,
                target_version = ?,
                reason = ?,
                risk_description = ?,
                mitigation = ?,
                owner_id = ?,
                team = ?,
                visibility = ?,
                start_date = ?,
                expiry_date = ?,
                status = ?,
                rejection_reason = NULL,
                review_comment = '',
                additional_details = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");


        $stmt->execute([
            $title,
            $exception_type,
            $new_version,
            $short_description,
            $system_name,
            $application_name,
            $current_version,
            $target_version,
            $reason,
            $risk_description,
            $mitigation,
            $owner_id,
            $team,
            $visibility,
            $start_date ?: null,
            $expiry_date ?: null,
            $status,
            $additional_details,
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Create Revision
        |--------------------------------------------------------------------------
        */

        $revision = $pdo->prepare("
            INSERT INTO patch_exception_revisions
            (
                exception_id,
                version,
                title,
                exception_type,
                short_description,
                system_name,
                application_name,
                current_version,
                target_version,
                reason,
                risk_description,
                mitigation,
                owner_id,
                team,
                visibility,
                start_date,
                expiry_date,
                status,
                additional_details,
                changed_by,
                change_summary
            )
            VALUES
            (
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?
            )
        ");


        $revision->execute([
            $id,
            $new_version,
            $title,
            $exception_type,
            $short_description,
            $system_name,
            $application_name,
            $current_version,
            $target_version,
            $reason,
            $risk_description,
            $mitigation,
            $owner_id,
            $team,
            $visibility,
            $start_date ?: null,
            $expiry_date ?: null,
            $status,
            $additional_details,
            $current_user_id,
            'Exception updated'
        ]);


        /*
        |--------------------------------------------------------------------------
        | Attachments
        |--------------------------------------------------------------------------
        */

        process_exception_attachments(
            $pdo,
            $upload_dir,
            $id,
            $current_user_id
        );


        /*
        |--------------------------------------------------------------------------
        | Success
        |--------------------------------------------------------------------------
        */

        $_SESSION['patch_success'] =
            $status === 'Pending Review'
                ? 'Exception updated and submitted for Admin review.'
                : 'Exception updated successfully.';


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | SUBMIT FOR REVIEW
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'submit_review') {

        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);


        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$row) {

            $_SESSION['patch_error'] =
                'Exception not found.';

            redirect_patch();
        }


        if (!can_edit_exception(
            $row,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }


        $stmt = $pdo->prepare("
            UPDATE patch_exceptions
            SET
                status = 'Pending Review',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);


        $_SESSION['patch_success'] =
            'Exception submitted for Admin review.';


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | ADMIN REVIEW
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'review_exception') {

        if (!$is_admin) {

            http_response_code(403);

            exit(
                'Admin privileges required.'
            );
        }


        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $decision =
            $_POST['decision']
            ?? '';


        $comment =
            trim(
                $_POST['review_comment']
                ?? ''
            );


        /*
        |--------------------------------------------------------------------------
        | APPROVE
        |--------------------------------------------------------------------------
        */

        if ($decision === 'approve') {

            $stmt = $pdo->prepare("
                UPDATE patch_exceptions
                SET
                    status = 'Approved',
                    approved_by = ?,
                    approved_at = CURRENT_TIMESTAMP,
                    review_comment = ?,
                    rejection_reason = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");


            $stmt->execute([
                $current_user_id,
                $comment,
                $id
            ]);


            $_SESSION['patch_success'] =
                'Exception approved successfully.';
        }


        /*
        |--------------------------------------------------------------------------
        | REJECT
        |--------------------------------------------------------------------------
        */

        elseif ($decision === 'reject') {

            if ($comment === '') {

                $_SESSION['patch_error'] =
                    'Please provide a rejection reason.';

                redirect_patch($id);
            }


            $stmt = $pdo->prepare("
                UPDATE patch_exceptions
                SET
                    status = 'Rejected',
                    review_comment = ?,
                    rejection_reason = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");


            $stmt->execute([
                $comment,
                $comment,
                $id
            ]);


            $_SESSION['patch_success'] =
                'Exception rejected.';
        }


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_exception') {

        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);


        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$row) {
            redirect_patch();
        }


        if (!can_delete_exception(
            $row,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Delete Physical Files
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT file_path
            FROM patch_exception_attachments
            WHERE exception_id = ?
        ");


        $stmt->execute([
            $id
        ]);


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            ) as $file
        ) {

            $path =
                __DIR__ . '/' .
                ltrim(
                    $file['file_path'],
                    '/\\'
                );


            if (is_file($path)) {
                @unlink($path);
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Delete Attachments
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exception_attachments
            WHERE exception_id = ?
        ")->execute([
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Delete Revisions
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exception_revisions
            WHERE exception_id = ?
        ")->execute([
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Delete Exception
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exceptions
            WHERE id = ?
        ")->execute([
            $id
        ]);


        $_SESSION['patch_success'] =
            'Exception deleted successfully.';


        redirect_patch();
    }
}


/*
|--------------------------------------------------------------------------
| File Download
|--------------------------------------------------------------------------
*/

if ($action === 'file') {

    $id =
        (int) (
            $_GET['id']
            ?? 0
        );


    $stmt = $pdo->prepare("
        SELECT *
        FROM patch_exception_attachments
        WHERE id = ?
    ");


    $stmt->execute([
        $id
    ]);


    $file =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$file) {

        http_response_code(404);

        exit(
            'File not found.'
        );
    }


    $path =
        __DIR__ . '/' .
        ltrim(
            $file['file_path'],
            '/\\'
        );


    if (!is_file($path)) {

        http_response_code(404);

        exit(
            'File not found.'
        );
    }


    header(
        'Content-Type: ' .
        (
            $file['mime_type']
            ?: 'application/octet-stream'
        )
    );


    header(
        'Content-Length: ' .
        filesize($path)
    );


    header(
        'Content-Disposition: attachment; filename="' .
        basename(
            $file['original_name']
        ) .
        '"'
    );


    header(
        'X-Content-Type-Options: nosniff'
    );


    readfile($path);

    exit;
}


/*
|--------------------------------------------------------------------------
| Load Selected Exception
|--------------------------------------------------------------------------
*/

$exception = null;


if (
    $action === 'view' ||
    $action === 'edit'
) {

    $id =
        (int) (
            $_GET['view']
            ?? $_GET['id']
            ?? 0
        );


    $stmt = $pdo->prepare("
        SELECT
            e.*,

            owner.first_name AS owner_first,
            owner.last_name AS owner_last,
            owner.email AS owner_email,

            creator.first_name AS creator_first,
            creator.last_name AS creator_last,

            approver.first_name AS approver_first,
            approver.last_name AS approver_last

        FROM patch_exceptions e

        LEFT JOIN users owner
            ON owner.id = e.owner_id

        LEFT JOIN users creator
            ON creator.id = e.requested_by

        LEFT JOIN users approver
            ON approver.id = e.approved_by

        WHERE e.id = ?

        LIMIT 1
    ");


    $stmt->execute([
        $id
    ]);


    $exception =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$exception) {

        $_SESSION['patch_error'] =
            'Exception not found.';

        redirect_patch();
    }


    /*
    |--------------------------------------------------------------------------
    | Security For Private / Team Data
    |--------------------------------------------------------------------------
    */

    $can_access =
        false;


    if ($is_admin) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Public'
    ) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Private' &&
        (
            (int) $exception['owner_id']
                === $current_user_id
            ||
            (int) $exception['requested_by']
                === $current_user_id
        )
    ) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Team'
    ) {

        $stmt =
            $pdo->prepare("
                SELECT team
                FROM users
                WHERE id = ?
                LIMIT 1
            ");


        $stmt->execute([
            $current_user_id
        ]);


        $my_team =
            $stmt->fetchColumn();


        if (
            $my_team &&
            $my_team === $exception['team']
        ) {

            $can_access =
                true;
        }
    }


    if (!$can_access) {

        http_response_code(403);

        exit(
            'You do not have permission to view this exception.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

$attachments = [];


if ($exception) {

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            u.first_name,
            u.last_name
        FROM patch_exception_attachments a

        LEFT JOIN users u
            ON u.id = a.uploaded_by

        WHERE a.exception_id = ?

        ORDER BY a.created_at DESC
    ");


    $stmt->execute([
        $exception['id']
    ]);


    $attachments =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
}


/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teams_stmt = $pdo->query("
    SELECT DISTINCT team
    FROM users
    WHERE team IS NOT NULL
      AND TRIM(team) <> ''
    ORDER BY team
");


$teams =
    $teams_stmt->fetchAll(
        PDO::FETCH_COLUMN
    );


/*
|--------------------------------------------------------------------------
| Users
|--------------------------------------------------------------------------
*/

$users = [];


if ($is_admin) {

    $stmt = $pdo->query("
        SELECT
            id,
            first_name,
            last_name,
            email,
            team
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name, last_name
    ");


    $users =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
}


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT status, COUNT(*) total
    FROM patch_exceptions
    GROUP BY status
");


$stats = [];


foreach (
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    ) as $row
) {

    $stats[$row['status']] =
        (int) $row['total'];
}


$total =
    array_sum($stats);


$draft =
    $stats['Draft'] ?? 0;


$pending =
    $stats['Pending Review'] ?? 0;


$approved =
    $stats['Approved'] ?? 0;


$active =
    $stats['Active'] ?? 0;


$rejected =
    $stats['Rejected'] ?? 0;


$expired =
    $stats['Expired'] ?? 0;


$page_title =
    'Patch & Exception Register';


require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>


<link
    rel="stylesheet"
    href="assets/css/sop.css"
>


<style>

.exception-content {
    padding-bottom: 50px;
}

.exception-header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:25px;
}

.exception-header h1 {
    margin:0;
}

.exception-header p {
    margin:5px 0 0;
    color:#777;
}

.exception-stats {
    display:grid;
    grid-template-columns:
        repeat(6, minmax(120px, 1fr));
    gap:14px;
    margin-bottom:25px;
}

.exception-stat {
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:18px;
}

.exception-stat span {
    display:block;
    color:#777;
    font-size:13px;
}

.exception-stat strong {
    display:block;
    font-size:26px;
    margin-top:5px;
}

.exception-panel {
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:20px;
}

.exception-toolbar {
    display:flex;
    justify-content:space-between;
    gap:15px;
    margin-bottom:20px;
}

.exception-search {
    width:300px;
    padding:10px 12px;
    border:1px solid #ddd;
    border-radius:7px;
}

.exception-table {
    width:100%;
    border-collapse:collapse;
}

.exception-table th,
.exception-table td {
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:left;
    vertical-align:middle;
}

.exception-table th {
    font-size:12px;
    color:#666;
    text-transform:uppercase;
}

.exception-reference {
    font-weight:700;
    color:#2563eb;
}

.exception-title {
    font-weight:600;
    color:#111827;
}

.exception-type {
    font-size:12px;
    padding:5px 8px;
    border-radius:5px;
    background:#eef2ff;
}

.exception-status {
    display:inline-block;
    padding:5px 9px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.status-draft {
    background:#f3f4f6;
    color:#374151;
}

.status-pending-review {
    background:#fff7ed;
    color:#c2410c;
}

.status-approved {
    background:#ecfdf5;
    color:#047857;
}

.status-active {
    background:#dbeafe;
    color:#1d4ed8;
}

.status-rejected {
    background:#fef2f2;
    color:#b91c1c;
}

.status-expired {
    background:#f3f4f6;
    color:#6b7280;
}

.exception-actions {
    display:flex;
    gap:8px;
    align-items:center;
}

.exception-actions a,
.exception-actions button {
    border:0;
    background:none;
    cursor:pointer;
    color:#2563eb;
    padding:0;
}

.exception-actions .delete {
    color:#dc2626;
}

.exception-form {
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:25px;
}

.exception-grid {
    display:grid;
    grid-template-columns:
        repeat(2, minmax(0, 1fr));
    gap:18px;
}

.exception-field {
    display:flex;
    flex-direction:column;
    gap:7px;
}

.exception-field.full {
    grid-column:1 / -1;
}

.exception-field label {
    font-weight:600;
    font-size:14px;
}

.exception-field input,
.exception-field select,
.exception-field textarea {
    width:100%;
    box-sizing:border-box;
    border:1px solid #d1d5db;
    border-radius:7px;
    padding:10px 12px;
    font:inherit;
}

.exception-field textarea {
    min-height:120px;
    resize:vertical;
}

.exception-document {
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:10px;
    padding:30px;
}

.exception-document-header {
    display:flex;
    justify-content:space-between;
    gap:20px;
    border-bottom:1px solid #eee;
    padding-bottom:20px;
    margin-bottom:25px;
}

.exception-document h1 {
    margin:5px 0;
}

.exception-reference-large {
    color:#2563eb;
    font-weight:700;
}

.exception-meta {
    display:grid;
    grid-template-columns:
        repeat(4, minmax(0, 1fr));
    gap:15px;
    margin-bottom:30px;
}

.exception-meta div {
    background:#f8fafc;
    padding:13px;
    border-radius:8px;
}

.exception-meta span {
    display:block;
    font-size:11px;
    color:#64748b;
    margin-bottom:5px;
}

.exception-section {
    margin-top:30px;
}

.exception-section h2 {
    font-size:18px;
    margin-bottom:10px;
}

.exception-risk {
    background:#fff7ed;
    border-left:4px solid #f97316;
    padding:15px;
}

.exception-mitigation {
    background:#ecfdf5;
    border-left:4px solid #10b981;
    padding:15px;
}

.exception-attachments {
    display:flex;
    flex-direction:column;
    gap:8px;
}

.exception-attachment {
    padding:10px 12px;
    background:#f8fafc;
    border:1px solid #e5e7eb;
    border-radius:7px;
}

.exception-review {
    margin-top:30px;
    background:#f8fafc;
    border:1px solid #e5e7eb;
    border-radius:8px;
    padding:20px;
}

.exception-review textarea {
    width:100%;
    min-height:100px;
    margin-bottom:15px;
}

@media(max-width:1000px) {

    .exception-stats {
        grid-template-columns:
            repeat(3, 1fr);
    }

    .exception-meta {
        grid-template-columns:
            repeat(2, 1fr);
    }
}

@media(max-width:700px) {

    .exception-grid,
    .exception-stats,
    .exception-meta {
        grid-template-columns:1fr;
    }

    .exception-header,
    .exception-toolbar,
    .exception-document-header {
        flex-direction:column;
        align-items:stretch;
    }

    .exception-search {
        width:100%;
    }
}

</style>


<div class="content exception-content">


<?php if ($success_msg): ?>

    <div class="sop-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="sop-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<?php

/*
|--------------------------------------------------------------------------
| CREATE / EDIT
|--------------------------------------------------------------------------
*/

if (
    $action === 'create' ||
    $action === 'edit'
):


    $editing =
        $action === 'edit';


    if (
        $editing &&
        !$exception
    ) {

        $_SESSION['patch_error'] =
            'Exception not found.';

        redirect_patch();
    }


    if (
        $editing &&
        !can_edit_exception(
            $exception,
            $current_user_id,
            $is_admin
        )
    ) {

        http_response_code(403);

        exit(
            'Permission denied.'
        );
    }


    $form =
        $exception ?: [];

?>


<div class="exception-header">

    <div>

        <h1>

            <?= $editing
                ? 'Edit Exception'
                : 'New Patch / Upgrade Exception'
            ?>

        </h1>

        <p>
            Record patching, upgrade and control-fix exceptions.
        </p>

    </div>


    <a
        href="patch.php"
        class="sop-secondary-btn"
    >
        Back to Register
    </a>

</div>


<form
    method="POST"
    action="patch.php"
    enctype="multipart/form-data"
    class="exception-form"
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?= h($csrf_token) ?>"
    >


    <input
        type="hidden"
        name="form_action"
        value="save_exception"
    >


    <input
        type="hidden"
        name="exception_id"
        value="<?= (int) (
            $form['id'] ?? 0
        ) ?>"
    >


    <div class="exception-grid">


        <div class="exception-field">

            <label>
                Reference
            </label>

            <input
                type="text"
                readonly
                value="<?= h(
                    $form['reference_no']
                    ?? generate_exception_number($pdo)
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Type *
            </label>

            <select
                name="exception_type"
                required
            >

                <?php foreach ([
                    'Patch Exception',
                    'Upgrade Exception',
                    'Control Fix Exception'
                ] as $type): ?>

                    <option
                        value="<?= h($type) ?>"
                        <?= (
                            $form['exception_type']
                            ?? 'Patch Exception'
                        ) === $type
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($type) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field full">

            <label>
                Title *
            </label>

            <input
                type="text"
                name="title"
                required
                value="<?= h(
                    $form['title'] ?? ''
                ) ?>"
                placeholder="Example: RHEL 9.4 production patch exception"
            >

        </div>


        <div class="exception-field full">

            <label>
                Short Description
            </label>

            <textarea
                name="short_description"
                placeholder="Brief description of the exception."
            ><?= h(
                $form['short_description'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field">

            <label>
                System / Host
            </label>

            <input
                type="text"
                name="system_name"
                value="<?= h(
                    $form['system_name'] ?? ''
                ) ?>"
                placeholder="Server / cluster / platform"
            >

        </div>


        <div class="exception-field">

            <label>
                Application
            </label>

            <input
                type="text"
                name="application_name"
                value="<?= h(
                    $form['application_name'] ?? ''
                ) ?>"
                placeholder="Application / service"
            >

        </div>


        <div class="exception-field">

            <label>
                Current Version
            </label>

            <input
                type="text"
                name="current_version"
                value="<?= h(
                    $form['current_version'] ?? ''
                ) ?>"
                placeholder="Current version"
            >

        </div>


        <div class="exception-field">

            <label>
                Target Version
            </label>

            <input
                type="text"
                name="target_version"
                value="<?= h(
                    $form['target_version'] ?? ''
                ) ?>"
                placeholder="Required / target version"
            >

        </div>


        <div class="exception-field full">

            <label>
                Reason / Justification
            </label>

            <textarea
                name="reason"
                placeholder="Why can the patch, upgrade or control fix not be completed?"
            ><?= h(
                $form['reason'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Risk Description
            </label>

            <textarea
                name="risk_description"
                placeholder="Describe the risk created by this exception."
            ><?= h(
                $form['risk_description'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Mitigation / Compensating Control
            </label>

            <textarea
                name="mitigation"
                placeholder="What temporary or compensating control is being used?"
            ><?= h(
                $form['mitigation'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field">

            <label>
                Team
            </label>

            <select name="team">

                <option value="">
                    Select Team
                </option>


                <?php foreach (
                    $teams
                    as $team
                ): ?>

                    <option
                        value="<?= h($team) ?>"
                        <?= (
                            $form['team'] ?? ''
                        ) === $team
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($team) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field">

            <label>
                Owner
            </label>


            <?php if ($is_admin): ?>

                <select name="owner_id">

                    <?php foreach (
                        $users
                        as $user
                    ): ?>

                        <option
                            value="<?= (int) $user['id'] ?>"
                            <?= (int) (
                                $form['owner_id']
                                ?? $current_user_id
                            )
                            === (int) $user['id']
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= h(
                                trim(
                                    $user['first_name']
                                    . ' '
                                    . $user['last_name']
                                )
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            <?php else: ?>

                <input
                    type="text"
                    readonly
                    value="Current User"
                >

            <?php endif; ?>

        </div>


        <div class="exception-field">

            <label>
                Start Date
            </label>

            <input
                type="date"
                name="start_date"
                value="<?= h(
                    $form['start_date'] ?? ''
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Expiry Date
            </label>

            <input
                type="date"
                name="expiry_date"
                value="<?= h(
                    $form['expiry_date'] ?? ''
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Visibility
            </label>

            <select name="visibility">

                <?php foreach ([
                    'Private',
                    'Team',
                    'Public'
                ] as $visibility): ?>

                    <option
                        value="<?= h($visibility) ?>"
                        <?= (
                            $form['visibility']
                            ?? 'Private'
                        ) === $visibility
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($visibility) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field full">

            <label>
                Additional Details
            </label>

            <textarea
                name="additional_details"
                placeholder="Additional technical or operational information."
            ><?= h(
                $form['additional_details'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Attachments
            </label>

            <input
                type="file"
                name="attachments[]"
                multiple
            >

            <small>
                Supporting evidence, change records,
                screenshots, vendor documents, etc.
            </small>

        </div>

    </div>


    <div
        class="sop-form-actions"
        style="margin-top:25px;"
    >

        <a
            href="patch.php"
            class="sop-secondary-btn"
        >
            Cancel
        </a>


        <button
            type="submit"
            class="sop-secondary-btn"
        >
            Save Draft
        </button>


        <button
            type="submit"
            name="after_save"
            value="submit"
            class="sop-primary-btn"
        >
            Save & Submit for Review
        </button>

    </div>

</form>


<?php

/*
|--------------------------------------------------------------------------
| VIEW
|--------------------------------------------------------------------------
*/

elseif (
    $action === 'view' &&
    $exception
):


    $can_edit =
        can_edit_exception(
            $exception,
            $current_user_id,
            $is_admin
        );

?>


<div class="exception-header">

    <div>

        <h1>
            Patch & Exception Register
        </h1>

        <p>
            Review exception details and supporting evidence.
        </p>

    </div>


    <div
        style="display:flex;gap:8px;"
    >

        <a
            href="patch.php"
            class="sop-secondary-btn"
        >
            Back
        </a>


        <?php if ($can_edit): ?>

            <a
                href="patch.php?action=edit&id=<?= (int) $exception['id'] ?>"
                class="sop-secondary-btn"
            >
                Edit
            </a>

        <?php endif; ?>

    </div>

</div>


<div class="exception-document">


    <div class="exception-document-header">

        <div>

            <div class="exception-reference-large">

                <?= h(
                    $exception['reference_no']
                ) ?>

            </div>


            <h1>

                <?= h(
                    $exception['title']
                ) ?>

            </h1>


            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'short_description'
                        ]
                    )
                ) ?>

            </p>

        </div>


        <div>

            <span
                class="exception-status status-<?= strtolower(
                    str_replace(
                        ' ',
                        '-',
                        $exception['status']
                    )
                ) ?>"
            >

                <?= h(
                    $exception['status']
                ) ?>

            </span>

        </div>

    </div>


    <div class="exception-meta">


        <div>

            <span>
                TYPE
            </span>

            <strong>

                <?= h(
                    $exception[
                        'exception_type'
                    ]
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                REGISTER VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'version'
                    ] ?? '1.0'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                SYSTEM
            </span>

            <strong>

                <?= h(
                    $exception[
                        'system_name'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                APPLICATION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'application_name'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                TEAM
            </span>

            <strong>

                <?= h(
                    $exception['team']
                    ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                CURRENT VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'current_version'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                TARGET VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'target_version'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                VISIBILITY
            </span>

            <strong>

                <?= h(
                    $exception[
                        'visibility'
                    ]
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                START DATE
            </span>

            <strong>

                <?= h(
                    $exception[
                        'start_date'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                EXPIRY
            </span>

            <strong>

                <?= h(
                    $exception[
                        'expiry_date'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>

    </div>


    <div class="exception-section">

        <h2>
            Reason / Justification
        </h2>

        <p>

            <?= nl2br(
                h(
                    $exception['reason']
                )
            ) ?>

        </p>

    </div>


    <div class="exception-section">

        <h2>
            Risk
        </h2>

        <div class="exception-risk">

            <?= nl2br(
                h(
                    $exception[
                        'risk_description'
                    ]
                )
            ) ?>

        </div>

    </div>


    <div class="exception-section">

        <h2>
            Mitigation / Compensating Control
        </h2>

        <div class="exception-mitigation">

            <?= nl2br(
                h(
                    $exception[
                        'mitigation'
                    ]
                )
            ) ?>

        </div>

    </div>


    <?php if (
        trim(
            $exception[
                'additional_details'
            ] ?? ''
        ) !== ''
    ): ?>

        <div class="exception-section">

            <h2>
                Additional Details
            </h2>

            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'additional_details'
                        ]
                    )
                ) ?>

            </p>

        </div>

    <?php endif; ?>


    <div class="exception-section">

        <h2>
            Attachments
        </h2>


        <div class="exception-attachments">

            <?php if ($attachments): ?>

                <?php foreach (
                    $attachments
                    as $attachment
                ): ?>

                    <a
                        class="exception-attachment"
                        href="patch.php?action=file&id=<?= (int) $attachment['id'] ?>"
                    >

                        📎

                        <?= h(
                            $attachment[
                                'original_name'
                            ]
                        ) ?>


                        <small>

                            (
                            <?= h(
                                number_format(
                                    (
                                        (int) $attachment[
                                            'file_size'
                                        ]
                                    ) / 1024,
                                    1
                                )
                            ) ?>
                            KB)

                        </small>

                    </a>

                <?php endforeach; ?>

            <?php else: ?>

                <span class="muted">
                    No attachments.
                </span>

            <?php endif; ?>

        </div>

    </div>


    <?php if (
        $exception['status'] === 'Rejected' &&
        !empty(
            $exception['rejection_reason']
        )
    ): ?>

        <div class="exception-section">

            <h2>
                Rejection Reason
            </h2>


            <div class="exception-risk">

                <?= nl2br(
                    h(
                        $exception[
                            'rejection_reason'
                        ]
                    )
                ) ?>

            </div>

        </div>

    <?php endif; ?>


    <?php if (
        !empty(
            $exception['review_comment']
        ) &&
        $exception['status'] !== 'Rejected'
    ): ?>

        <div class="exception-section">

            <h2>
                Review Comment
            </h2>

            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'review_comment'
                        ]
                    )
                ) ?>

            </p>

        </div>

    <?php endif; ?>


    <?php if (
        $is_admin &&
        $exception['status']
            === 'Pending Review'
    ): ?>

        <div class="exception-review">

            <h2>
                Admin Review
            </h2>


            <form
                method="POST"
                action="patch.php?view=<?= (int) $exception['id'] ?>"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h($csrf_token) ?>"
                >


                <input
                    type="hidden"
                    name="form_action"
                    value="review_exception"
                >


                <input
                    type="hidden"
                    name="exception_id"
                    value="<?= (int) $exception['id'] ?>"
                >


                <textarea
                    name="review_comment"
                    placeholder="Review comments / approval conditions / rejection reason"
                ></textarea>


                <div
                    style="display:flex;gap:10px;"
                >

                    <button
                        type="submit"
                        name="decision"
                        value="reject"
                        class="sop-secondary-btn"
                    >
                        Reject
                    </button>


                    <button
                        type="submit"
                        name="decision"
                        value="approve"
                        class="sop-primary-btn"
                    >
                        Approve Exception
                    </button>

                </div>

            </form>

        </div>

    <?php endif; ?>


</div>


<?php

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

else:

?>


<div class="exception-header">

    <div>

        <h1>
            Patch & Exception Register
        </h1>

        <p>
            Track patching, upgrade and control-fix exceptions.
        </p>

    </div>


    <a
        href="patch.php?action=create"
        class="sop-primary-btn"
    >
        + New Exception
    </a>

</div>


<div class="exception-stats">


    <div class="exception-stat">

        <span>
            Total
        </span>

        <strong>
            <?= $total ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Draft
        </span>

        <strong>
            <?= $draft ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Pending Review
        </span>

        <strong>
            <?= $pending ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Approved
        </span>

        <strong>
            <?= $approved ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Rejected
        </span>

        <strong>
            <?= $rejected ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Expired
        </span>

        <strong>
            <?= $expired ?>
        </strong>

    </div>

</div>


<div class="exception-panel">


    <div class="exception-toolbar">

        <h2>
            Exception Register
        </h2>


        <input
            type="text"
            id="exceptionSearch"
            class="exception-search"
            placeholder="Search exceptions..."
        >

    </div>


    <div style="overflow-x:auto;">

        <table
            class="exception-table"
            id="exceptionTable"
        >

            <thead>

                <tr>

                    <th>
                        Reference
                    </th>

                    <th>
                        Title
                    </th>

                    <th>
                        Type
                    </th>

                    <th>
                        System
                    </th>

                    <th>
                        Team
                    </th>

                    <th>
                        Owner
                    </th>

                    <th>
                        Expiry
                    </th>

                    <th>
                        Status
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>


<?php

/*
|--------------------------------------------------------------------------
| Load List
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        e.*,

        owner.first_name AS owner_first,
        owner.last_name AS owner_last,

        creator.first_name AS creator_first,
        creator.last_name AS creator_last

    FROM patch_exceptions e

    LEFT JOIN users owner
        ON owner.id = e.owner_id

    LEFT JOIN users creator
        ON creator.id = e.requested_by

    ORDER BY e.updated_at DESC
");


$rows =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


$visible_count = 0;


/*
|--------------------------------------------------------------------------
| Visibility Filtering
|--------------------------------------------------------------------------
*/

foreach (
    $rows
    as $row
):


    $visible =
        false;


    if ($is_admin) {

        $visible =
            true;
    }


    elseif (
        $row['visibility']
        === 'Public'
    ) {

        $visible =
            true;
    }


    elseif (
        $row['visibility']
        === 'Private' &&
        (
            (int) $row['owner_id']
                === $current_user_id
            ||
            (int) $row['requested_by']
                === $current_user_id
        )
    ) {

        $visible =
            true;
    }


    elseif (
        $row['visibility']
        === 'Team'
    ) {

        $stmt_team =
            $pdo->prepare("
                SELECT team
                FROM users
                WHERE id = ?
                LIMIT 1
            ");


        $stmt_team->execute([
            $current_user_id
        ]);


        $my_team =
            $stmt_team->fetchColumn();


        if (
            $my_team &&
            $my_team === $row['team']
        ) {

            $visible =
                true;
        }
    }


    if (!$visible) {
        continue;
    }


    $visible_count++;


    $owner =
        trim(
            ($row['owner_first'] ?? '')
            . ' '
            . ($row['owner_last'] ?? '')
        );


    $can_edit =
        can_edit_exception(
            $row,
            $current_user_id,
            $is_admin
        );


    $can_delete =
        can_delete_exception(
            $row,
            $current_user_id,
            $is_admin
        );

?>


<tr>


    <td>

        <a
            class="exception-reference"
            href="patch.php?view=<?= (int) $row['id'] ?>"
        >

            <?= h(
                $row['reference_no']
            ) ?>

        </a>

    </td>


    <td>

        <a
            class="exception-title"
            href="patch.php?view=<?= (int) $row['id'] ?>"
        >

            <?= h(
                $row['title']
            ) ?>

        </a>


        <?php if (
            !empty(
                $row['short_description']
            )
        ): ?>

            <br>

            <small>

                <?= h(
                    substr(
                        $row[
                            'short_description'
                        ],
                        0,
                        100
                    )
                ) ?>

            </small>

        <?php endif; ?>

    </td>


    <td>

        <span class="exception-type">

            <?= h(
                $row['exception_type']
            ) ?>

        </span>

    </td>


    <td>

        <?= h(
            $row['system_name']
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $row['team']
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $owner
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $row['expiry_date']
            ?: '—'
        ) ?>

    </td>


    <td>

        <span
            class="exception-status status-<?= strtolower(
                str_replace(
                    ' ',
                    '-',
                    $row['status']
                )
            ) ?>"
        >

            <?= h(
                $row['status']
            ) ?>

        </span>

    </td>


    <td>

        <div class="exception-actions">


            <a
                href="patch.php?view=<?= (int) $row['id'] ?>"
            >
                View
            </a>


            <?php if ($can_edit): ?>

                <a
                    href="patch.php?action=edit&id=<?= (int) $row['id'] ?>"
                >
                    Edit
                </a>

            <?php endif; ?>


            <?php if (
                $is_admin &&
                $row['status']
                    === 'Pending Review'
            ): ?>

                <a
                    href="patch.php?view=<?= (int) $row['id'] ?>"
                >
                    Review
                </a>

            <?php endif; ?>


            <?php if ($can_delete): ?>

                <form
                    method="POST"
                    action="patch.php"
                    style="display:inline;"
                    onsubmit="return confirm('Delete this exception permanently?');"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= h(
                            $csrf_token
                        ) ?>"
                    >


                    <input
                        type="hidden"
                        name="form_action"
                        value="delete_exception"
                    >


                    <input
                        type="hidden"
                        name="exception_id"
                        value="<?= (int) $row['id'] ?>"
                    >


                    <button
                        type="submit"
                        class="delete"
                    >
                        Delete
                    </button>

                </form>

            <?php endif; ?>


        </div>

    </td>

</tr>


<?php endforeach; ?>


<?php if ($visible_count === 0): ?>

<tr>

    <td
        colspan="9"
        style="text-align:center;padding:40px;"
    >

        No exceptions have been created.

    </td>

</tr>

<?php endif; ?>


            </tbody>

        </table>

    </div>

</div>


<?php endif; ?>


</div>


<script>

const exceptionSearch =
    document.getElementById(
        'exceptionSearch'
    );


if (exceptionSearch) {

    exceptionSearch.addEventListener(
        'input',
        function () {

            const value =
                this.value.toLowerCase();


            document
                .querySelectorAll(
                    '#exceptionTable tbody tr'
                )
                .forEach(
                    function(row) {

                        row.style.display =
                            row.innerText
                                .toLowerCase()
                                .includes(value)
                                ? ''
                                : 'none';

                    }
                );

        }
    );

}

</script>


<?php

require_once 'includes/footer.php';

?>
