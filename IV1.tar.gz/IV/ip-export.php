<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}


$role=$_SESSION['role'] ?? 'User';



if(
    $role!="Admin" &&
    $role!="Edit"
){

    die("Permission denied");

}




$stmt=$pdo->query("

SELECT

id,
ip_range,
vlan,
subnet,
gateway,
environment,
project,
project_code,
portgroup,
cidr,
usable_range,
broadcast,
total_hosts,
usable_hosts,
comments,
created_by,
created_at,
updated_by,
updated_at

FROM ip_ranges

ORDER BY id DESC

");



$rows=$stmt->fetchAll(PDO::FETCH_ASSOC);





/*
====================================
CSV HEADER
====================================
*/


$file="ip_ranges_".date("Y-m-d_H-i-s").".csv";



header("Content-Type: text/csv; charset=UTF-8");

header(
"Content-Disposition: attachment; filename=".$file
);



/*
Excel UTF-8 support
*/

echo "\xEF\xBB\xBF";




$output=fopen("php://output","w");




$headers=[

"ID",

"IP Range",

"VLAN",

"Subnet",

"Gateway",

"Environment",

"Project",

"Project Code",

"Port Group",

"CIDR",

"Usable Range",

"Broadcast",

"Total Hosts",

"Usable Hosts",

"Comments",

"Created By",

"Created Date",

"Updated By",

"Updated Date"

];



fputcsv($output,$headers);





foreach($rows as $row){


fputcsv($output,[

$row['id'],

$row['ip_range'],

$row['vlan'],

$row['subnet'],

$row['gateway'],

$row['environment'],

$row['project'],

$row['project_code'],

$row['portgroup'],

$row['cidr'],

$row['usable_range'],

$row['broadcast'],

$row['total_hosts'],

$row['usable_hosts'],

$row['comments'],

$row['created_by'],

$row['created_at'],

$row['updated_by'],

$row['updated_at']

]);


}



fclose($output);

exit;


?>
