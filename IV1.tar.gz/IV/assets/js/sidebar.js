console.log("InfraVault sidebar.js loaded");


(function(){


    function initSidebar(){


        const sidebar = document.getElementById("sidebar");
        const toggleButton = document.getElementById("sidebarToggle");


        if(!sidebar || !toggleButton){

            console.error("Sidebar or toggle button missing");

            return;

        }



        toggleButton.onclick = function(e){

            e.preventDefault();


            sidebar.classList.toggle("collapsed");


            document.body.classList.toggle(
                "sidebar-collapsed"
            );


            console.log(
                "Sidebar collapsed:",
                sidebar.classList.contains("collapsed")
            );


            // close submenu while collapsing

            if(sidebar.classList.contains("collapsed")){


                document.querySelectorAll(".submenu")
                .forEach(function(menu){

                    menu.classList.remove("show");

                });


                document.querySelectorAll(".menu-header")
                .forEach(function(header){

                    header.classList.remove("open");

                });


            }


        };


    }



    window.addEventListener(
        "load",
        initSidebar
    );


})();





// =================================
// SUB MENU
// =================================

function toggleMenu(header){


    const sidebar =
        document.getElementById("sidebar");


    if(sidebar.classList.contains("collapsed")){

        return;

    }



    const submenu =
        header.nextElementSibling;



    const isOpen =
        submenu.classList.contains("show");



    document.querySelectorAll(".submenu")
    .forEach(function(item){

        item.classList.remove("show");

    });



    document.querySelectorAll(".menu-header")
    .forEach(function(item){

        item.classList.remove("open");

    });



    if(!isOpen){

        submenu.classList.add("show");

        header.classList.add("open");

    }


}
