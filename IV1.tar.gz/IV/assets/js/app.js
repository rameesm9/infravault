console.log("InfraVault app.js loaded");

// Global application scripts will go here
// Sidebar functionality is handled by sidebar.js
