/* =====================================================
   InfraVault IPAM JavaScript
===================================================== */


/*
=====================================================
OPEN ADD DRAWER
=====================================================
*/

function openIPDrawer(){


    const drawer=document.getElementById("ipDrawer");


    if(drawer){

        drawer.classList.add("show");

    }


    resetIPForm();


}





/*
=====================================================
CLOSE DRAWER
=====================================================
*/


function closeIPDrawer(){


    const drawer=document.getElementById("ipDrawer");


    if(drawer){

        drawer.classList.remove("show");

    }


}





/*
=====================================================
RESET FORM
=====================================================
*/


function resetIPForm(){


    const form=document.querySelector("#ipDrawer form");


    if(form){

        form.reset();

    }



    let id=document.getElementById("id");


    if(id){

        id.value="";

    }


    let title=document.getElementById("drawerTitle");


    if(title){

        title.innerHTML="Add IP Range";

    }


}






/*
=====================================================
EDIT IP
=====================================================
*/


function editIP(data){


    const drawer=document.getElementById("ipDrawer");


    if(drawer){

        drawer.classList.add("show");

    }




    let title=document.getElementById("drawerTitle");


    if(title){

        title.innerHTML="Edit IP Range";

    }





    Object.keys(data).forEach(function(key){


        let field=document.getElementById(key);



        if(field){

            field.value=data[key] ?? "";

        }


    });



}





/*
=====================================================
VIEW DETAILS
=====================================================
*/


function viewIP(data){



let html="";



Object.keys(data).forEach(function(key){



html += `

<div class="detail-box">


<label>

${key.replaceAll("_"," ")}

</label>


<strong>

${data[key] ?? "-"}

</strong>


</div>


`;



});






let overlay=document.createElement("div");


overlay.className="ip-overlay";



overlay.innerHTML=`


<div class="ip-modal">


<div class="ip-modal-header">


<h2>

IP Range Details

</h2>



<button onclick="this.closest('.ip-overlay').remove()">

×

</button>


</div>



<div class="details-grid">


${html}


</div>


</div>



`;




document.body.appendChild(overlay);



}







/*
=====================================================
CIDR CALCULATION
=====================================================
*/


document.addEventListener(
"input",
function(e){


if(e.target.id==="ip_range"){


calculateCIDR();


}


});






function calculateCIDR(){



let field=document.getElementById("ip_range");



if(!field){

return;

}



let value=field.value.trim();




if(!value.includes("/")){

return;

}





let parts=value.split("/");



let ip=parts[0];

let cidr=parseInt(parts[1]);





if(

isNaN(cidr) ||

cidr<0 ||

cidr>32

){

return;

}




let octets=ip.split(".");



if(octets.length!==4){

return;

}





let ipNumber=

(

(parseInt(octets[0])<<24)

|

(parseInt(octets[1])<<16)

|

(parseInt(octets[2])<<8)

|

parseInt(octets[3])

) >>>0;





let mask=

cidr===0 ?

0 :

(0xffffffff << (32-cidr)) >>>0;





let network=

(ipNumber & mask) >>>0;





let broadcast=

(network | (~mask >>>0)) >>>0;







function ipConvert(num){


return [

(num>>>24)&255,

(num>>>16)&255,

(num>>>8)&255,

num&255

].join(".");


}






let subnet=document.getElementById("subnet");


if(subnet){

subnet.value=ipConvert(mask);

}






let cidrField=document.getElementById("cidr");


if(cidrField){

cidrField.value=cidr;

}





let broadcastField=document.getElementById("broadcast");


if(broadcastField){

broadcastField.value=
ipConvert(broadcast);

}





let total=

Math.pow(
2,
32-cidr
);





let totalField=document.getElementById("total_hosts");


if(totalField){

totalField.value=total;

}






let usableRange=document.getElementById("usable_range");


let usableHosts=document.getElementById("usable_hosts");





if(cidr<31){



if(usableRange){

usableRange.value=

ipConvert(network+1)

+" - "+

ipConvert(broadcast-1);

}





if(usableHosts){

usableHosts.value=

total-2;

}



}

else{



if(usableRange){

usableRange.value=

ipConvert(network)

+" - "+

ipConvert(broadcast);

}



if(usableHosts){

usableHosts.value=total;

}



}



}







/*
=====================================================
ESC CLOSE MODALS
=====================================================
*/


document.addEventListener(
"keydown",
function(e){


if(e.key==="Escape"){


document.querySelectorAll(".ip-overlay")
.forEach(
x=>x.remove()
);


closeIPDrawer();


}



});
