/* =====================================================
   InfraVault Compliance
===================================================== */


/* =====================================================
   PLATFORM EXPAND / COLLAPSE
===================================================== */

function togglePlatform(button) {

    const card =
        button.closest('.platform-card');

    if (!card) {
        return;
    }

    card.classList.toggle('expanded');

}


/* =====================================================
   SEARCH
===================================================== */

function filterCompliance() {

    const search =
        document
            .getElementById('complianceSearch')
            .value
            .toLowerCase()
            .trim();

    const severity =
        document
            .getElementById('severityFilter')
            .value
            .toLowerCase();

    const cards =
        document.querySelectorAll(
            '.platform-card'
        );

    cards.forEach(function(card) {

        const rows =
            card.querySelectorAll(
                '.control-row'
            );

        let visible = 0;

        rows.forEach(function(row) {

            const text =
                row.dataset.search || '';

            const rowSeverity =
                (
                    row.dataset.severity || ''
                ).toLowerCase();

            const matchesSearch =
                !search ||
                text.includes(search);

            const matchesSeverity =
                !severity ||
                rowSeverity === severity;

            if (
                matchesSearch &&
                matchesSeverity
            ) {

                row.style.display = '';

                visible++;

            } else {

                row.style.display = 'none';

            }

        });


        /*
        |--------------------------------------------------------------------------
        | Show/hide platform
        |--------------------------------------------------------------------------
        */

        if (visible > 0) {

            card.style.display = '';

            if (search || severity) {

                card.classList.add(
                    'expanded'
                );

            }

        } else {

            card.style.display = 'none';

        }

    });

}


/* =====================================================
   ADD CONTROL
===================================================== */

function openAddControl() {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    document.getElementById(
        'modalTitle'
    ).textContent =
        'Add Compliance Control';

    document.getElementById(
        'formAction'
    ).value =
        'add_control';

    document.getElementById(
        'control_id'
    ).value = '';

    document.getElementById(
        'controlForm'
    ).reset();

    document.getElementById(
        'formAction'
    ).value =
        'add_control';

    document.getElementById(
        'control_id'
    ).value = '';

    document.getElementById(
        'is_enabled'
    ).checked = true;

    modal.classList.add('show');

}


/* =====================================================
   EDIT CONTROL
===================================================== */

function editControl(control) {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    document.getElementById(
        'modalTitle'
    ).textContent =
        'Edit Compliance Control';

    document.getElementById(
        'formAction'
    ).value =
        'update_control';

    document.getElementById(
        'control_id'
    ).value =
        control.id || '';

    setValue(
        'platform_id',
        control.platform_id
    );

    setValue(
        'control_number',
        control.control_number
    );

    setValue(
        'title',
        control.title
    );

    setValue(
        'description',
        control.description
    );

    setValue(
        'section_name',
        control.section_name
    );

    setValue(
        'level',
        control.level
    );

    setValue(
        'severity',
        control.severity
    );

    setValue(
        'control_type',
        control.control_type
    );

    setValue(
        'value_type',
        control.value_type
    );

    setValue(
        'cis_value',
        control.cis_value
    );

    setValue(
        'ncgr_value',
        control.ncgr_value
    );

    setValue(
        'unit',
        control.unit
    );

    setValue(
        'remediation',
        control.remediation
    );

    setValue(
        'audit_procedure',
        control.audit_procedure
    );

    document.getElementById(
        'is_enabled'
    ).checked =
        Number(control.is_enabled) === 1;

    modal.classList.add('show');

}


/* =====================================================
   FORM VALUE
===================================================== */

function setValue(id, value) {

    const element =
        document.getElementById(id);

    if (!element) {
        return;
    }

    element.value =
        value === null ||
        value === undefined
            ? ''
            : value;

}


/* =====================================================
   CLOSE MODAL
===================================================== */

function closeControlModal() {

    const modal =
        document.getElementById(
            'controlModal'
        );

    if (!modal) {
        return;
    }

    modal.classList.remove('show');

}


/* =====================================================
   CLICK OUTSIDE MODAL
===================================================== */

document.addEventListener(
    'click',
    function(event) {

        const modal =
            document.getElementById(
                'controlModal'
            );

        if (!modal) {
            return;
        }

        if (
            event.target === modal
        ) {

            closeControlModal();

        }

    }
);


/* =====================================================
   ESCAPE
===================================================== */

document.addEventListener(
    'keydown',
    function(event) {

        if (
            event.key === 'Escape'
        ) {

            closeControlModal();

        }

    }
);

