<?php
/*
=====================================================
InfraVault IPAM Add / Edit Drawer
=====================================================
*/
?>


<div id="ipDrawer" class="ip-drawer">


<div class="drawer-header">


<h2>
Add IP Range
</h2>


<button onclick="closeIPDrawer()">
×
</button>


</div>





<form method="POST"
action="ip-save.php">



<input type="hidden"
name="id"
id="id">



<div class="drawer-body">





<div class="form-group">

<label>
IP Range *
</label>

<input

type="text"

name="ip_range"

id="ip_range"

placeholder="10.10.10.0/24"

required

>

</div>






<div class="form-row">


<div class="form-group">

<label>
VLAN
</label>

<input

name="vlan"

id="vlan"

>

</div>



<div class="form-group">

<label>
CIDR
</label>

<input

name="cidr"

id="cidr"

readonly

>

</div>



</div>







<div class="form-group">

<label>
Subnet
</label>

<input

name="subnet"

id="subnet"

>

</div>





<div class="form-group">

<label>
Gateway
</label>

<input

name="gateway"

id="gateway"

>

</div>







<div class="form-row">



<div class="form-group">

<label>
Environment
</label>


<select name="environment"
id="environment">


<option value="">
Select
</option>


<option>
Production
</option>


<option>
Development
</option>


<option>
Test
</option>


<option>
DMZ
</option>


</select>


</div>






<div class="form-group">

<label>
Project
</label>


<input

name="project"

id="project"

>


</div>



</div>







<div class="form-row">


<div class="form-group">

<label>
Port Group
</label>


<input

name="portgroup"

id="portgroup"

>


</div>




<div class="form-group">

<label>
Project Code
</label>


<input

name="project_code"

id="project_code"

>


</div>



</div>







<div class="form-row">



<div class="form-group">

<label>
Usable Range
</label>


<input

name="usable_range"

id="usable_range"

readonly

>


</div>




<div class="form-group">

<label>
Broadcast
</label>


<input

name="broadcast"

id="broadcast"

readonly

>


</div>



</div>






<div class="form-row">



<div class="form-group">

<label>
Total Hosts
</label>


<input

name="total_hosts"

id="total_hosts"

readonly

>


</div>





<div class="form-group">

<label>
Usable Hosts
</label>


<input

name="usable_hosts"

id="usable_hosts"

readonly

>


</div>



</div>






<div class="form-group">


<label>
Comments
</label>


<textarea

name="comments"

id="comments"

rows="4"

></textarea>


</div>




</div>






<div class="drawer-footer">



<button

type="button"

class="secondary-btn"

onclick="closeIPDrawer()">

Cancel

</button>




<button

class="primary-btn">

Save IP Range

</button>



</div>





</form>



</div>
