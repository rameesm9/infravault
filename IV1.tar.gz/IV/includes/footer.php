</div>


<footer>


InfraVault © <?= date("Y"); ?>

&nbsp; | &nbsp;

Enterprise IT Inventory Management


</footer>



<style>


footer{


padding:15px;

text-align:center;

color:#64748B;

font-size:13px;

background:white;

border-top:1px solid #E2E8F0;

}



</style>

<script src="assets/js/app.js"></script>
<script src="assets/js/sidebar.js"></script>
</body>

</html>
