<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');
$success_msg = '';
$error_msg = '';

// Fetch technical owners from the ownership table
$owners_stmt = $pdo->query("SELECT DISTINCT technical_owner FROM ownership WHERE technical_owner IS NOT NULL AND technical_owner != '' ORDER BY technical_owner ASC");
$tech_owners = $owners_stmt->fetchAll(PDO::FETCH_COLUMN);

// Handle Form Submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_handover') {
        $project_name = trim($_POST['project_name'] ?? '');
        $project_id = trim($_POST['project_id'] ?? '');
        $current_owner = trim($_POST['current_owner'] ?? '');
        $new_owner = trim($_POST['new_owner'] ?? '');
        $handover_date = trim($_POST['handover_date'] ?? '');
        $handover_status = trim($_POST['handover_status'] ?? '');
        $reason_for_handover = trim($_POST['reason_for_handover'] ?? '');
        $project_phase = trim($_POST['project_phase'] ?? '');
        $documentation_status = trim($_POST['documentation_status'] ?? '');
        $open_issues = trim($_POST['open_issues'] ?? '');
        $pending_actions = trim($_POST['pending_actions'] ?? '');
        $risks = trim($_POST['risks'] ?? '');
        $dependencies = trim($_POST['dependencies'] ?? '');
        $kt_completed = trim($_POST['kt_completed'] ?? 'No');
        $training_completed = trim($_POST['training_completed'] ?? 'No');
        $access_transferred = trim($_POST['access_transferred'] ?? 'No');
        $stakeholder_signoff = trim($_POST['stakeholder_signoff'] ?? '');
        $client_notified = trim($_POST['client_notified'] ?? 'No');
        $warranty_period = trim($_POST['warranty_period'] ?? '');
        $notes = trim($_POST['notes'] ?? '');

        if (empty($project_name) || empty($current_owner) || empty($new_owner)) {
            $error_msg = "Please fill in all required fields (Project Name, Current Owner, New Owner).";
        } else {
            $stmt = $pdo->prepare("INSERT INTO handovers (project_name, project_id, current_owner, new_owner, handover_date, handover_status, reason_for_handover, project_phase, documentation_status, open_issues, pending_actions, risks, dependencies, kt_completed, training_completed, access_transferred, stakeholder_signoff, client_notified, warranty_period, notes, user_id, last_updated) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)");
            $stmt->execute([
                $project_name, $project_id, $current_owner, $new_owner, $handover_date,
                $handover_status, $reason_for_handover, $project_phase, $documentation_status,
                $open_issues, $pending_actions, $risks, $dependencies, $kt_completed,
                $training_completed, $access_transferred, $stakeholder_signoff, $client_notified,
                $warranty_period, $notes, $current_user_id
            ]);
            $handover_id = $pdo->lastInsertId();

            // Handle File Attachments
            if (!empty($_FILES['attachments']['name'][0])) {
                $upload_dir = 'uploads/handovers/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                foreach ($_FILES['attachments']['name'] as $key => $filename) {
                    if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                        $safe_filename = time() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
                        $destination = $upload_dir . $safe_filename;

                        if (move_uploaded_file($tmp_name, $destination)) {
                            $att_stmt = $pdo->prepare("INSERT INTO handover_attachments (handover_id, filename, filepath) VALUES (?, ?, ?)");
                            $att_stmt->execute([$handover_id, $filename, $destination]);
                        }
                    }
                }
            }

            $success_msg = "New project handover record successfully created!";
        }
    } elseif ($action === 'update_handover') {
        $handover_id = $_POST['handover_id'] ?? '';

        $check_stmt = $pdo->prepare("SELECT user_id FROM handovers WHERE id = ?");
        $check_stmt->execute([$handover_id]);
        $handover_owner = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$handover_owner) {
            $error_msg = "Handover record not found.";
        } elseif ($role !== 'Admin' && $handover_owner['user_id'] != $current_user_id) {
            $error_msg = "You do not have permission to modify this handover record.";
        } else {
            $project_name = trim($_POST['project_name'] ?? '');
            $project_id = trim($_POST['project_id'] ?? '');
            $current_owner = trim($_POST['current_owner'] ?? '');
            $new_owner = trim($_POST['new_owner'] ?? '');
            $handover_date = trim($_POST['handover_date'] ?? '');
            $handover_status = trim($_POST['handover_status'] ?? '');
            $reason_for_handover = trim($_POST['reason_for_handover'] ?? '');
            $project_phase = trim($_POST['project_phase'] ?? '');
            $documentation_status = trim($_POST['documentation_status'] ?? '');
            $open_issues = trim($_POST['open_issues'] ?? '');
            $pending_actions = trim($_POST['pending_actions'] ?? '');
            $risks = trim($_POST['risks'] ?? '');
            $dependencies = trim($_POST['dependencies'] ?? '');
            $kt_completed = trim($_POST['kt_completed'] ?? 'No');
            $training_completed = trim($_POST['training_completed'] ?? 'No');
            $access_transferred = trim($_POST['access_transferred'] ?? 'No');
            $stakeholder_signoff = trim($_POST['stakeholder_signoff'] ?? '');
            $client_notified = trim($_POST['client_notified'] ?? 'No');
            $warranty_period = trim($_POST['warranty_period'] ?? '');
            $notes = trim($_POST['notes'] ?? '');

            $update_stmt = $pdo->prepare("UPDATE handovers SET project_name = ?, project_id = ?, current_owner = ?, new_owner = ?, handover_date = ?, handover_status = ?, reason_for_handover = ?, project_phase = ?, documentation_status = ?, open_issues = ?, pending_actions = ?, risks = ?, dependencies = ?, kt_completed = ?, training_completed = ?, access_transferred = ?, stakeholder_signoff = ?, client_notified = ?, warranty_period = ?, notes = ?, last_updated = CURRENT_TIMESTAMP WHERE id = ?");
            $update_stmt->execute([
                $project_name, $project_id, $current_owner, $new_owner, $handover_date,
                $handover_status, $reason_for_handover, $project_phase, $documentation_status,
                $open_issues, $pending_actions, $risks, $dependencies, $kt_completed,
                $training_completed, $access_transferred, $stakeholder_signoff, $client_notified,
                $warranty_period, $notes, $handover_id
            ]);

            if (!empty($_FILES['attachments']['name'][0])) {
                $upload_dir = 'uploads/handovers/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                foreach ($_FILES['attachments']['name'] as $key => $filename) {
                    if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                        $safe_filename = time() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
                        $destination = $upload_dir . $safe_filename;

                        if (move_uploaded_file($tmp_name, $destination)) {
                            $att_stmt = $pdo->prepare("INSERT INTO handover_attachments (handover_id, filename, filepath) VALUES (?, ?, ?)");
                            $att_stmt->execute([$handover_id, $filename, $destination]);
                        }
                    }
                }
            }

            $success_msg = "Handover record successfully updated!";
        }
    } elseif ($action === 'delete_handover') {
        $handover_id = $_POST['handover_id'] ?? '';

        $check_stmt = $pdo->prepare("SELECT user_id FROM handovers WHERE id = ?");
        $check_stmt->execute([$handover_id]);
        $handover_owner = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$handover_owner) {
            $error_msg = "Handover record not found.";
        } elseif ($role !== 'Admin' && $handover_owner['user_id'] != $current_user_id) {
            $error_msg = "You do not have permission to delete this handover record.";
        } else {
            $att_query = $pdo->prepare("SELECT filepath FROM handover_attachments WHERE handover_id = ?");
            $att_query->execute([$handover_id]);
            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($attachments as $att) {
                if (file_exists($att['filepath'])) {
                    unlink($att['filepath']);
                }
            }

            $del_stmt = $pdo->prepare("DELETE FROM handovers WHERE id = ?");
            $del_stmt->execute([$handover_id]);
            $success_msg = "Handover record successfully deleted.";
        }
    }
}

// Fetch all handovers for viewing (All users can view)
$handovers_stmt = $pdo->query("
    SELECT h.*, u.first_name AS creator_first, u.last_name AS creator_last
    FROM handovers h
    LEFT JOIN users u ON h.user_id = u.id
    ORDER BY h.last_updated DESC
");
$handovers = $handovers_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "Project Handovers - InfraVault";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
    /* =========================================
       PROJECT HANDOVER - PAGE STYLES
       (extends existing dashboard-card / dashboard-panel look)
    ========================================= */

    .ho-alert {
        padding: 13px 18px;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 20px;
        border: 1px solid transparent;
    }

    .ho-alert.success {
        background: #ECFDF5;
        border-color: #A7F3D0;
        color: #047857;
    }

    .ho-alert.error {
        background: #FEF2F2;
        border-color: #FECACA;
        color: #B91C1C;
    }

    .ho-form-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 18px;
        margin-bottom: 18px;
    }

    .ho-form-grid.cols-2 {
        grid-template-columns: repeat(2, 1fr);
    }

    .ho-field label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 7px;
    }

    .ho-field input[type="text"],
    .ho-field input[type="date"],
    .ho-field select,
    .ho-field textarea,
    .ho-field input[type="file"] {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #E2E8F0;
        border-radius: 9px;
        font-family: inherit;
        font-size: 14px;
        color: #1E293B;
        background: #F8FAFC;
        transition: .15s;
    }

    .ho-field textarea {
        resize: vertical;
        min-height: 60px;
    }

    .ho-field input:focus,
    .ho-field select:focus,
    .ho-field textarea:focus {
        outline: none;
        border-color: #2563EB;
        background: #fff;
        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
    }

    .ho-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: none;
        border-radius: 9px;
        padding: 11px 20px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        font-family: inherit;
        transition: .15s;
    }

    .ho-btn-primary {
        background: #2563EB;
        color: #fff;
    }

    .ho-btn-primary:hover {
        background: #1D4ED8;
    }

    .ho-btn-danger {
        background: #FEF2F2;
        color: #DC2626;
    }

    .ho-btn-danger:hover {
        background: #FEE2E2;
    }

    .ho-btn-ghost {
        background: #F1F5F9;
        color: #334155;
    }

    .ho-btn-ghost:hover {
        background: #E2E8F0;
    }

    .ho-btn-sm {
        padding: 7px 12px;
        font-size: 12.5px;
        border-radius: 7px;
    }

    /* Table */
    .ho-table-wrap {
        overflow-x: auto;
    }

    table.ho-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13.5px;
    }

    table.ho-table thead th {
        text-align: left;
        padding: 13px 16px;
        background: #F8FAFC;
        color: #64748B;
        font-weight: 600;
        font-size: 12.5px;
        text-transform: uppercase;
        letter-spacing: .03em;
        border-bottom: 1px solid #E5E7EB;
        white-space: nowrap;
    }

    table.ho-table tbody td {
        padding: 14px 16px;
        border-bottom: 1px solid #F1F5F9;
        color: #334155;
        vertical-align: middle;
    }

    table.ho-table tbody tr:last-child td {
        border-bottom: none;
    }

    table.ho-table tbody tr:hover {
        background: #FAFBFF;
    }

    .ho-empty {
        text-align: center;
        padding: 40px 20px;
        color: #94A3B8;
        font-size: 14px;
    }

    .ho-badge {
        display: inline-block;
        padding: 4px 11px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 700;
        white-space: nowrap;
    }

    .ho-badge.st-planned { background: #EEF2FF; color: #4338CA; }
    .ho-badge.st-inprogress { background: #FFF7ED; color: #C2410C; }
    .ho-badge.st-completed { background: #ECFDF5; color: #047857; }
    .ho-badge.st-delayed { background: #FEF2F2; color: #B91C1C; }

    .ho-pill {
        display: inline-block;
        padding: 3px 9px;
        border-radius: 6px;
        font-size: 11.5px;
        font-weight: 600;
    }

    .ho-pill.yes { background: #ECFDF5; color: #059669; }
    .ho-pill.no { background: #F1F5F9; color: #64748B; }

    /* File chip */
    .ho-file-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #F1F5F9;
        padding: 7px 13px;
        border-radius: 8px;
        font-size: 13px;
        margin: 0 8px 8px 0;
        text-decoration: none;
        color: #2563EB;
        font-weight: 500;
        transition: .15s;
    }

    .ho-file-chip:hover {
        background: #E2E8F0;
    }

    /* Modal */
    .ho-modal {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 3000;
        background: rgba(15, 23, 42, .5);
        overflow-y: auto;
        padding: 40px 20px;
    }

    .ho-modal-content {
        background: #fff;
        margin: 0 auto;
        max-width: 780px;
        width: 100%;
        border-radius: 18px;
        padding: 28px 30px;
        box-shadow: 0 20px 60px rgba(15,23,42,.25);
        position: relative;
    }

    .ho-modal-close {
        position: absolute;
        top: 20px;
        right: 24px;
        font-size: 22px;
        color: #94A3B8;
        cursor: pointer;
        line-height: 1;
        background: none;
        border: none;
    }

    .ho-modal-close:hover {
        color: #1E293B;
    }

    .ho-modal-title {
        font-size: 19px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 20px;
        padding-right: 30px;
    }

    .ho-detail-row {
        display: grid;
        grid-template-columns: 190px 1fr;
        padding: 10px 0;
        border-bottom: 1px solid #F1F5F9;
        font-size: 13.5px;
    }

    .ho-detail-row:last-child {
        border-bottom: none;
    }

    .ho-detail-label {
        font-weight: 600;
        color: #64748B;
    }

    .ho-detail-value {
        color: #1E293B;
    }

    .ho-subheading {
        margin-top: 22px;
        font-size: 13px;
        font-weight: 700;
        color: #374151;
        text-transform: uppercase;
        letter-spacing: .03em;
        border-bottom: 2px solid #F1F5F9;
        padding-bottom: 8px;
        margin-bottom: 12px;
    }

    @media (max-width: 900px) {
        .ho-form-grid,
        .ho-form-grid.cols-2 {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Project Handovers</h1>
            <p>Track ownership transitions, knowledge transfer status, and sign-off across all projects.</p>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div class="ho-alert success"><?= htmlspecialchars($success_msg) ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="ho-alert error"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>

    <!-- Create Handover -->
    <div class="dashboard-panel" style="margin-bottom:22px;">
        <div class="panel-header">
            <h3>Create New Project Handover</h3>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create_handover">

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Project Name *</label>
                    <input type="text" name="project_name" placeholder="Name of the project" required>
                </div>
                <div class="ho-field">
                    <label>Project ID</label>
                    <input type="text" name="project_id" placeholder="Unique identifier">
                </div>
                <div class="ho-field">
                    <label>Current Owner *</label>
                    <select name="current_owner" required>
                        <option value="">-- Select Tech Owner --</option>
                        <?php foreach ($tech_owners as $owner): ?>
                            <option value="<?= htmlspecialchars($owner) ?>"><?= htmlspecialchars($owner) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>New Owner *</label>
                    <select name="new_owner" required>
                        <option value="">-- Select Tech Owner --</option>
                        <?php foreach ($tech_owners as $owner): ?>
                            <option value="<?= htmlspecialchars($owner) ?>"><?= htmlspecialchars($owner) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Handover Date</label>
                    <input type="date" name="handover_date">
                </div>
                <div class="ho-field">
                    <label>Handover Status</label>
                    <select name="handover_status">
                        <option value="Planned">Planned</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Delayed">Delayed</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Reason for Handover</label>
                    <input type="text" name="reason_for_handover" placeholder="Project completion, team change, etc.">
                </div>
                <div class="ho-field">
                    <label>Project Phase</label>
                    <select name="project_phase">
                        <option value="Planning">Planning</option>
                        <option value="Execution">Execution</option>
                        <option value="Closing">Closing</option>
                        <option value="Operations">Operations</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Documentation Status</label>
                    <select name="documentation_status">
                        <option value="Complete">Complete</option>
                        <option value="Partial">Partial</option>
                        <option value="Missing">Missing</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid cols-2">
                <div class="ho-field">
                    <label>Open Issues</label>
                    <textarea name="open_issues" rows="2" placeholder="Outstanding risks or issues"></textarea>
                </div>
                <div class="ho-field">
                    <label>Pending Actions</label>
                    <textarea name="pending_actions" rows="2" placeholder="Tasks to be completed after handover"></textarea>
                </div>
            </div>

            <div class="ho-form-grid cols-2">
                <div class="ho-field">
                    <label>Risks</label>
                    <textarea name="risks" rows="2" placeholder="Known risks that the new owner should monitor"></textarea>
                </div>
                <div class="ho-field">
                    <label>Dependencies</label>
                    <textarea name="dependencies" rows="2" placeholder="External teams, systems, or vendors involved"></textarea>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Knowledge Transfer Completed</label>
                    <select name="kt_completed">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Training Completed</label>
                    <select name="training_completed">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Access Transferred</label>
                    <select name="access_transferred">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Stakeholder Sign-off</label>
                    <input type="text" name="stakeholder_signoff" placeholder="Names and dates of approvals">
                </div>
                <div class="ho-field">
                    <label>Customer/Client Notified</label>
                    <select name="client_notified">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Warranty/Support Period</label>
                    <input type="text" name="warranty_period" placeholder="If applicable">
                </div>
            </div>

            <div class="ho-field" style="margin-bottom:18px;">
                <label>Notes</label>
                <textarea name="notes" rows="2" placeholder="Additional comments or special instructions"></textarea>
            </div>

            <div class="ho-field" style="margin-bottom:20px;">
                <label>Attach Docs (Multiple)</label>
                <input type="file" name="attachments[]" multiple>
            </div>

            <button type="submit" class="ho-btn ho-btn-primary">Create Handover Record</button>
        </form>
    </div>

    <!-- Existing Handovers -->
    <div class="dashboard-panel" style="padding-bottom:8px;">
        <div class="panel-header">
            <h3>Existing Project Handovers</h3>
            <span><?= count($handovers) ?> record<?= count($handovers) === 1 ? '' : 's' ?></span>
        </div>

        <div class="ho-table-wrap">
            <table class="ho-table">
                <thead>
                    <tr>
                        <th>Project Name</th>
                        <th>Project ID</th>
                        <th>Current Owner</th>
                        <th>New Owner</th>
                        <th>Status</th>
                        <th>Phase</th>
                        <th>KT</th>
                        <th>Access</th>
                        <th>Last Updated</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($handovers)): ?>
                        <tr><td colspan="10" class="ho-empty">No handover records found.</td></tr>
                    <?php else: ?>
                        <?php foreach ($handovers as $h):
                            $att_query = $pdo->prepare("SELECT * FROM handover_attachments WHERE handover_id = ?");
                            $att_query->execute([$h['id']]);
                            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);

                            $can_modify = ($role === 'Admin' || $h['user_id'] == $current_user_id);

                            $status_class = 'st-planned';
                            switch ($h['handover_status']) {
                                case 'In Progress': $status_class = 'st-inprogress'; break;
                                case 'Completed': $status_class = 'st-completed'; break;
                                case 'Delayed': $status_class = 'st-delayed'; break;
                            }
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($h['project_name']) ?></strong></td>
                            <td><?= htmlspecialchars($h['project_id'] ?: '-') ?></td>
                            <td><?= htmlspecialchars($h['current_owner']) ?></td>
                            <td><?= htmlspecialchars($h['new_owner']) ?></td>
                            <td><span class="ho-badge <?= $status_class ?>"><?= htmlspecialchars($h['handover_status']) ?></span></td>
                            <td><?= htmlspecialchars($h['project_phase'] ?: '-') ?></td>
                            <td><span class="ho-pill <?= $h['kt_completed'] === 'Yes' ? 'yes' : 'no' ?>"><?= htmlspecialchars($h['kt_completed']) ?></span></td>
                            <td><span class="ho-pill <?= $h['access_transferred'] === 'Yes' ? 'yes' : 'no' ?>"><?= htmlspecialchars($h['access_transferred']) ?></span></td>
                            <td><?= htmlspecialchars($h['last_updated']) ?></td>
                            <td style="white-space:nowrap;">
                                <button type="button" class="ho-btn ho-btn-ghost ho-btn-sm" onclick='openViewModal(<?= json_encode($h) ?>, <?= json_encode($attachments) ?>)'>View</button>

                                <?php if ($can_modify): ?>
                                    <button type="button" class="ho-btn ho-btn-primary ho-btn-sm" onclick='openEditModal(<?= json_encode($h) ?>)'>Modify</button>

                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this handover record?');">
                                        <input type="hidden" name="action" value="delete_handover">
                                        <input type="hidden" name="handover_id" value="<?= $h['id'] ?>">
                                        <button type="submit" class="ho-btn ho-btn-danger ho-btn-sm">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- View Modal -->
<div id="viewModal" class="ho-modal">
    <div class="ho-modal-content">
        <button class="ho-modal-close" onclick="closeViewModal()">&times;</button>
        <h2 id="viewModalTitle" class="ho-modal-title">Project Handover Details</h2>

        <div id="viewModalContentContainer"></div>

        <div class="ho-subheading">Attached Documents</div>
        <div id="viewAttachmentsListContainer"></div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="ho-modal">
    <div class="ho-modal-content">
        <button class="ho-modal-close" onclick="closeEditModal()">&times;</button>
        <h2 class="ho-modal-title">Modify Project Handover</h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_handover">
            <input type="hidden" name="handover_id" id="edit_handover_id">

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Project Name *</label>
                    <input type="text" name="project_name" id="edit_project_name" required>
                </div>
                <div class="ho-field">
                    <label>Project ID</label>
                    <input type="text" name="project_id" id="edit_project_id">
                </div>
                <div class="ho-field">
                    <label>Current Owner *</label>
                    <select name="current_owner" id="edit_current_owner" required>
                        <option value="">-- Select Tech Owner --</option>
                        <?php foreach ($tech_owners as $owner): ?>
                            <option value="<?= htmlspecialchars($owner) ?>"><?= htmlspecialchars($owner) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>New Owner *</label>
                    <select name="new_owner" id="edit_new_owner" required>
                        <option value="">-- Select Tech Owner --</option>
                        <?php foreach ($tech_owners as $owner): ?>
                            <option value="<?= htmlspecialchars($owner) ?>"><?= htmlspecialchars($owner) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Handover Date</label>
                    <input type="date" name="handover_date" id="edit_handover_date">
                </div>
                <div class="ho-field">
                    <label>Handover Status</label>
                    <select name="handover_status" id="edit_handover_status">
                        <option value="Planned">Planned</option>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="Delayed">Delayed</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Reason for Handover</label>
                    <input type="text" name="reason_for_handover" id="edit_reason_for_handover">
                </div>
                <div class="ho-field">
                    <label>Project Phase</label>
                    <select name="project_phase" id="edit_project_phase">
                        <option value="Planning">Planning</option>
                        <option value="Execution">Execution</option>
                        <option value="Closing">Closing</option>
                        <option value="Operations">Operations</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Documentation Status</label>
                    <select name="documentation_status" id="edit_documentation_status">
                        <option value="Complete">Complete</option>
                        <option value="Partial">Partial</option>
                        <option value="Missing">Missing</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid cols-2">
                <div class="ho-field">
                    <label>Open Issues</label>
                    <textarea name="open_issues" id="edit_open_issues" rows="2"></textarea>
                </div>
                <div class="ho-field">
                    <label>Pending Actions</label>
                    <textarea name="pending_actions" id="edit_pending_actions" rows="2"></textarea>
                </div>
            </div>

            <div class="ho-form-grid cols-2">
                <div class="ho-field">
                    <label>Risks</label>
                    <textarea name="risks" id="edit_risks" rows="2"></textarea>
                </div>
                <div class="ho-field">
                    <label>Dependencies</label>
                    <textarea name="dependencies" id="edit_dependencies" rows="2"></textarea>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Knowledge Transfer Completed</label>
                    <select name="kt_completed" id="edit_kt_completed">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Training Completed</label>
                    <select name="training_completed" id="edit_training_completed">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Access Transferred</label>
                    <select name="access_transferred" id="edit_access_transferred">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
            </div>

            <div class="ho-form-grid">
                <div class="ho-field">
                    <label>Stakeholder Sign-off</label>
                    <input type="text" name="stakeholder_signoff" id="edit_stakeholder_signoff">
                </div>
                <div class="ho-field">
                    <label>Customer/Client Notified</label>
                    <select name="client_notified" id="edit_client_notified">
                        <option value="No">No</option>
                        <option value="Yes">Yes</option>
                    </select>
                </div>
                <div class="ho-field">
                    <label>Warranty/Support Period</label>
                    <input type="text" name="warranty_period" id="edit_warranty_period">
                </div>
            </div>

            <div class="ho-field" style="margin-bottom:18px;">
                <label>Notes</label>
                <textarea name="notes" id="edit_notes" rows="2"></textarea>
            </div>

            <div class="ho-field" style="margin-bottom:20px;">
                <label>Attach More Docs</label>
                <input type="file" name="attachments[]" multiple>
            </div>

            <button type="submit" class="ho-btn ho-btn-primary">Update Handover Record</button>
        </form>
    </div>
</div>

<script>
    function openViewModal(h, attachments) {
        document.getElementById('viewModalTitle').innerText = 'Handover Details: ' + (h.project_name || '');

        const rows = [
            ['Project Name', h.project_name],
            ['Project ID', h.project_id],
            ['Current Owner', h.current_owner],
            ['New Owner', h.new_owner],
            ['Handover Date', h.handover_date],
            ['Handover Status', h.handover_status],
            ['Reason for Handover', h.reason_for_handover],
            ['Project Phase', h.project_phase],
            ['Documentation Status', h.documentation_status],
            ['Open Issues', h.open_issues],
            ['Pending Actions', h.pending_actions],
            ['Risks', h.risks],
            ['Dependencies', h.dependencies],
            ['Knowledge Transfer Completed', h.kt_completed],
            ['Training Completed', h.training_completed],
            ['Access Transferred', h.access_transferred],
            ['Stakeholder Sign-off', h.stakeholder_signoff],
            ['Customer/Client Notified', h.client_notified],
            ['Warranty/Support Period', h.warranty_period],
            ['Notes', h.notes],
            ['Last Updated', h.last_updated],
        ];

        let detailsHtml = '';
        rows.forEach(([label, value]) => {
            detailsHtml += `<div class="ho-detail-row"><div class="ho-detail-label">${label}</div><div class="ho-detail-value">${value || '-'}</div></div>`;
        });
        document.getElementById('viewModalContentContainer').innerHTML = detailsHtml;

        let attContainer = document.getElementById('viewAttachmentsListContainer');
        attContainer.innerHTML = '';

        if (!attachments || attachments.length === 0) {
            attContainer.innerHTML = '<p style="color:#94A3B8; font-style:italic; font-size:13.5px;">No documents attached to this handover record.</p>';
        } else {
            let listHtml = '';
            attachments.forEach(att => {
                listHtml += `<a href="${att.filepath}" class="ho-file-chip" target="_blank">📄 ${att.filename}</a>`;
            });
            attContainer.innerHTML = listHtml;
        }

        document.getElementById('viewModal').style.display = 'block';
    }

    function closeViewModal() {
        document.getElementById('viewModal').style.display = 'none';
    }

    function openEditModal(h) {
        document.getElementById('edit_handover_id').value = h.id;
        document.getElementById('edit_project_name').value = h.project_name || '';
        document.getElementById('edit_project_id').value = h.project_id || '';
        document.getElementById('edit_current_owner').value = h.current_owner || '';
        document.getElementById('edit_new_owner').value = h.new_owner || '';
        document.getElementById('edit_handover_date').value = h.handover_date || '';
        document.getElementById('edit_handover_status').value = h.handover_status || 'Planned';
        document.getElementById('edit_reason_for_handover').value = h.reason_for_handover || '';
        document.getElementById('edit_project_phase').value = h.project_phase || 'Planning';
        document.getElementById('edit_documentation_status').value = h.documentation_status || 'Complete';
        document.getElementById('edit_open_issues').value = h.open_issues || '';
        document.getElementById('edit_pending_actions').value = h.pending_actions || '';
        document.getElementById('edit_risks').value = h.risks || '';
        document.getElementById('edit_dependencies').value = h.dependencies || '';
        document.getElementById('edit_kt_completed').value = h.kt_completed || 'No';
        document.getElementById('edit_training_completed').value = h.training_completed || 'No';
        document.getElementById('edit_access_transferred').value = h.access_transferred || 'No';
        document.getElementById('edit_stakeholder_signoff').value = h.stakeholder_signoff || '';
        document.getElementById('edit_client_notified').value = h.client_notified || 'No';
        document.getElementById('edit_warranty_period').value = h.warranty_period || '';
        document.getElementById('edit_notes').value = h.notes || '';
        document.getElementById('editModal').style.display = 'block';
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }

    window.addEventListener('click', function (event) {
        const editModal = document.getElementById('editModal');
        const viewModal = document.getElementById('viewModal');
        if (event.target === editModal) editModal.style.display = 'none';
        if (event.target === viewModal) viewModal.style.display = 'none';
    });
</script>

<?php include 'includes/footer.php'; ?>
