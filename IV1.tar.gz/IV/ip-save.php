<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}



$user = $_SESSION['name'] ?? "Unknown";



try{


$id = $_POST['id'] ?? "";



$data=[

    "ip_range"       => trim($_POST['ip_range'] ?? ""),

    "cidr"           => trim($_POST['cidr'] ?? ""),

    "subnet"         => trim($_POST['subnet'] ?? ""),

    "gateway"        => trim($_POST['gateway'] ?? ""),

    "portgroup"      => trim($_POST['portgroup'] ?? ""),

    "vlan"           => trim($_POST['vlan'] ?? ""),

    "environment"    => trim($_POST['environment'] ?? ""),

    "project"        => trim($_POST['project'] ?? ""),

    "usable_range"   => trim($_POST['usable_range'] ?? ""),

    "broadcast"      => trim($_POST['broadcast'] ?? ""),

    "total_hosts"    => intval($_POST['total_hosts'] ?? 0),

    "usable_hosts"   => intval($_POST['usable_hosts'] ?? 0),

    "comments"       => trim($_POST['comments'] ?? "")

];




if($data['ip_range']==""){

    throw new Exception("IP Range is required");

}




/*
=====================================================
UPDATE
=====================================================
*/


if($id!=""){


$sql="
UPDATE ip_ranges SET

ip_range=?,
cidr=?,
subnet=?,
gateway=?,
portgroup=?,
vlan=?,
environment=?,
project=?,
usable_range=?,
broadcast=?,
total_hosts=?,
usable_hosts=?,
comments=?,
updated_by=?,
updated_at=CURRENT_TIMESTAMP


WHERE id=?

";



$stmt=$pdo->prepare($sql);



$stmt->execute([


$data['ip_range'],
$data['cidr'],
$data['subnet'],
$data['gateway'],
$data['portgroup'],
$data['vlan'],
$data['environment'],
$data['project'],
$data['usable_range'],
$data['broadcast'],
$data['total_hosts'],
$data['usable_hosts'],
$data['comments'],
$user,
$id


]);




/*
AUDIT
*/


$history=$pdo->prepare("

INSERT INTO ip_ranges_history

(
ip_range_id,
action_type,
performed_by,
details
)

VALUES(?,?,?,?)

");


$history->execute([

$id,

"UPDATED",

$user,

json_encode($data)

]);



}





/*
=====================================================
INSERT
=====================================================
*/


else{


$sql="
INSERT INTO ip_ranges
(

ip_range,
cidr,
subnet,
gateway,
portgroup,
vlan,
environment,
project,
usable_range,
broadcast,
total_hosts,
usable_hosts,
comments,
created_by

)

VALUES
(?,?,?,?,?,?,?,?,?,?,?,?,?,?)

";



$stmt=$pdo->prepare($sql);



$stmt->execute([


$data['ip_range'],
$data['cidr'],
$data['subnet'],
$data['gateway'],
$data['portgroup'],
$data['vlan'],
$data['environment'],
$data['project'],
$data['usable_range'],
$data['broadcast'],
$data['total_hosts'],
$data['usable_hosts'],
$data['comments'],
$user


]);



$newID=$pdo->lastInsertId();



/*
AUDIT
*/


$history=$pdo->prepare("

INSERT INTO ip_ranges_history

(
ip_range_id,
action_type,
performed_by,
details
)

VALUES(?,?,?,?)

");


$history->execute([


$newID,

"CREATED",

$user,

json_encode($data)


]);



}



header("Location: ip.php?success=1");

exit;



}

catch(Exception $e){


echo "

<h2>IP Save Error</h2>

<pre>

".$e->getMessage()."

</pre>


";


}

?>
