<?php
// decommission.php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');
$username = $_SESSION['first_name'] . ' (' . $_SESSION['ncgr_id'] . ')';
$msg = "";
$error = "";

$default_tasks = [
    ["name" => "CRQ Raised and Approved (it Must be CR).", "has_req" => false],
    ["name" => "System Owner approval attached.", "has_req" => false],
    ["name" => "Taken a full server backup as per the defined retention policy.", "has_req" => true],
    ["name" => "Removed NFS exports (if applicable) and inform Storage team to remove from ACL (tick if no NFS).", "has_req" => true],
    ["name" => "Raised ticket with the Splunk team to remove monitoring alerts.", "has_req" => true],
    ["name" => "Removed from the maintenance calendar for the decommission activity.", "has_req" => false],
    ["name" => "Deleted CMDB records", "has_req" => true],
    ["name" => "Informed SecOps team to remove the rules.", "has_req" => true],
    ["name" => "Security tools removed such as SEP, XDR.", "has_req" => true],
    ["name" => "Powered off the server.", "has_req" => false],
    ["name" => "Rename the server by appending '_tbd' in the Vcenter", "has_req" => false],
    ["name" => "server powered off for 1–2 weeks to identify any dependency or accessibility issues.", "has_req" => false],
    ["name" => "Released the Production and Management IP addresses and remove the DNS entries.", "has_req" => false],
    ["name" => "Removed the iLO and Virtual Connect (VC) configuration.", "has_req" => false],
    ["name" => "Removed the server from IPA.", "has_req" => false],
    ["name" => "Removed the server from Satellite", "has_req" => false],
    ["name" => "Deleted the server.", "has_req" => true],
    ["name" => "Updated all relevant tracking documents (Patch Calendar, Decommission Tracker, Inventory, etc.).", "has_req" => false],
    ["name" => "Closed the Change Request (CR).", "has_req" => false],
    ["name" => "Updated the server status in the Ramp-Down/Decommission list.", "has_req" => false]
];

$upload_dir = __DIR__ . '/uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Export CSV
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=decommission_export_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Hostname', 'Server State', 'Support Level', 'Project', 'Application Name', 'IP Address', 'Additional IPs', 'Start Date', 'End Date', 'Attachment', 'Created By', 'Created At']);

    $rows = $pdo->query("SELECT * FROM decommission")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        fputcsv($output, [
            $row['id'], $row['hostname'], $row['server_state'], $row['support_level'],
            $row['project'], $row['application_name'], $row['ip_address'], $row['additional_ips'],
            $row['decommission_start_date'], $row['decommission_end_date'], $row['attachment'] ?? '',
            $row['created_by'], $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

// AJAX Inventory Details
if (isset($_GET['action']) && $_GET['action'] === 'get_inventory_details') {
    $hname = $_GET['hostname'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM inventory WHERE hostname = ? LIMIT 1");
    $stmt->execute([$hname]);
    $inv = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($inv) {
        echo json_encode([
            'success' => true,
            'project' => $inv['project'] ?? $inv['project_name'] ?? '',
            'support_level' => $inv['support_level'] ?? $inv['environment'] ?? 'Production',
            'application_name' => $inv['application_name'] ?? $inv['app_name'] ?? '',
            'ip_address' => $inv['ip_address'] ?? $inv['ip'] ?? '',
            'additional_ips' => $inv['additional_ips'] ?? '',
            'server_state' => $inv['server_state'] ?? $inv['status'] ?? 'Active'
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// Global History AJAX
if (isset($_GET['action']) && $_GET['action'] === 'get_history' && $role === 'Admin') {
    $stmt = $pdo->query("SELECT * FROM decommission_history ORDER BY timestamp DESC");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table style="width:100%; font-size:0.85rem;" class="table table-bordered">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $badge_color = 'background: #e2e8f0; color: #1e293b;';
            if ($log['action_type'] === 'CREATED') $badge_color = 'background: #dcfce7; color: #166534;';
            if ($log['action_type'] === 'DELETED') $badge_color = 'background: #fee2e2; color: #991b1b;';
            if ($log['action_type'] === 'UPDATED') $badge_color = 'background: #fef9c3; color: #854d0e;';

            echo '<tr>';
            echo '<td><span style="padding: 0.2rem 0.5rem; border-radius: 4px; font-weight: 600; ' . $badge_color . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td>' . htmlspecialchars($log['details']) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p style="color: var(--text-muted); font-style: italic;">No audit history records found.</p>';
    }
    exit;
}

// Handle Form Submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    if ($action_type === 'save' && ($role === 'Admin' || $role === 'Edit')) {
        $id = $_POST['id'] ?? '';
        $hostname = trim($_POST['hostname']);
        $server_state = trim($_POST['server_state']);
        $support_level = $_POST['support_level'];
        $project = trim($_POST['project']);
        $application_name = trim($_POST['application_name']);
        $ip_address = trim($_POST['ip_address']);
        $additional_ips = trim($_POST['additional_ips']);
        $decommission_start_date = $_POST['decommission_start_date'];
        $decommission_end_date = !empty($_POST['decommission_end_date']) ? $_POST['decommission_end_date'] : null;

        // Handle existing attachments list if editing
        $existing_attachments = [];
        if (!empty($_POST['existing_attachment'])) {
            $existing_attachments = array_filter(explode(',', $_POST['existing_attachment']));
        }

        // Handle multiple file uploads
        $uploaded_files = $existing_attachments;
        if (isset($_FILES['attachment_files']) && !empty($_FILES['attachment_files']['name'][0])) {
            $file_count = count($_FILES['attachment_files']['name']);

            // Comprehensive Office formats + CSV, PDFs, Archives, and standard documents
            $allowed_exts = [
                'pdf', 'doc', 'docx', 'dot', 'dotx', 'docm', 'dotm',
                'xls', 'xlsx', 'xlt', 'xltx', 'xlsm', 'xltm', 'xlsb', 'xla', 'xlam',
                'ppt', 'pptx', 'pot', 'potx', 'pptm', 'potm', 'pps', 'ppsx', 'ppsm',
                'msg', 'eml', 'pst', 'ost',
                'vsd', 'vsdx', 'vss', 'vst', 'vstm', 'vstx',
                'accdb', 'mdb', 'csv',
                'png', 'jpg', 'jpeg', 'gif', 'txt', 'zip', 'rar', '7z', 'tar', 'gz'
            ];

            for ($i = 0; $i < $file_count; $i++) {
                if ($_FILES['attachment_files']['error'][$i] === UPLOAD_ERR_OK) {
                    $file_tmp = $_FILES['attachment_files']['tmp_name'][$i];
                    $file_orig = basename($_FILES['attachment_files']['name'][$i]);
                    $file_ext = strtolower(pathinfo($file_orig, PATHINFO_EXTENSION));

                    if (in_array($file_ext, $allowed_exts)) {
                        $new_filename = time() . '_' . $i . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $file_orig);
                        if (move_uploaded_file($file_tmp, $upload_dir . $new_filename)) {
                            $uploaded_files[] = $new_filename;
                        }
                    } else {
                        $error = "One or more files have an unsupported extension.";
                    }
                }
            }
        }

        $attachment_name_string = !empty($uploaded_files) ? implode(',', array_unique($uploaded_files)) : '';

        if (empty($hostname)) {
            $error = "Hostname is a required field.";
        } else if (empty($error)) {
            $inv_up = $pdo->prepare("UPDATE inventory SET server_state = ? WHERE hostname = ?");
            $inv_up->execute([$server_state, $hostname]);

            if (empty($id)) {
                $stmt = $pdo->prepare("INSERT INTO decommission (hostname, server_state, support_level, project, application_name, ip_address, additional_ips, decommission_start_date, decommission_end_date, attachment, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$hostname, $server_state, $support_level, $project, $application_name, $ip_address, $additional_ips, $decommission_start_date, $decommission_end_date, $attachment_name_string, $username]);
                $new_id = $pdo->lastInsertId();

                foreach ($default_tasks as $t) {
                    $t_stmt = $pdo->prepare("INSERT INTO decommission_tasks (decommission_id, task_name, status, req_no) VALUES (?, ?, 'Pending', '')");
                    $t_stmt->execute([$new_id, $t['name']]);
                }

                $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                $h_stmt->execute([$new_id, $username, "Created decommission record for hostname: $hostname"]);
                $msg = "Decommission entry created successfully.";
            } else {
                $stmt = $pdo->prepare("UPDATE decommission SET hostname=?, server_state=?, support_level=?, project=?, application_name=?, ip_address=?, additional_ips=?, decommission_start_date=?, decommission_end_date=?, attachment=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->execute([$hostname, $server_state, $support_level, $project, $application_name, $ip_address, $additional_ips, $decommission_start_date, $decommission_end_date, $attachment_name_string, $username, $id]);

                $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                $h_stmt->execute([$id, $username, "Updated decommission record for hostname: $hostname"]);
                $msg = "Decommission entry updated successfully.";
            }
        }
    }

    if ($action_type === 'delete' && $role === 'Admin') {
        $id = $_POST['id'];
        $p_stmt = $pdo->prepare("SELECT hostname FROM decommission WHERE id = ?");
        $p_stmt->execute([$id]);
        $row = $p_stmt->fetch(PDO::FETCH_ASSOC);
        $hname = $row ? $row['hostname'] : 'Unknown';

        $stmt = $pdo->prepare("DELETE FROM decommission WHERE id = ?");
        $stmt->execute([$id]);

        $t_stmt = $pdo->prepare("DELETE FROM decommission_tasks WHERE decommission_id = ?");
        $t_stmt->execute([$id]);

        $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
        $h_stmt->execute([$id, $username, "Deleted decommission record for hostname: $hname"]);
        $msg = "Decommission entry deleted successfully.";
    }
}

// Pagination & Search
$limit = 25;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $limit) - $limit : 0;

$keyword = trim($_GET['keyword'] ?? '');
$s_hostname = trim($_GET['s_hostname'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_support = trim($_GET['s_support'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(hostname LIKE ? OR project LIKE ? OR ip_address LIKE ? OR application_name LIKE ?)";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_hostname)) {
    $where_clauses[] = "hostname LIKE ?";
    $params[] = "%$s_hostname%";
}
if (!empty($s_project)) {
    $where_clauses[] = "project LIKE ?";
    $params[] = "%$s_project%";
}
if (!empty($s_support)) {
    $where_clauses[] = "support_level = ?";
    $params[] = "$s_support";
}

$where_sql = implode(" AND ", $where_clauses);

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM decommission WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

$data_stmt = $pdo->prepare("SELECT * FROM decommission WHERE $where_sql ORDER BY id DESC LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

$inventory_list = [];
try {
    $inv_stmt = $pdo->query("SELECT DISTINCT hostname FROM inventory ORDER BY hostname ASC");
    $inventory_list = $inv_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {}

$support_levels = ['Production', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox', 'DR', 'POC'];

// Used by includes/header.php for the <title> tag
$page_title = "Decommission Registry | InfraVault";

require 'includes/header.php';
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/decommission.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Server Decommission Management</h1>
            <p>Track servers going through the decommission process, from CR approval to final cleanup.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                <button type="button" class="btn btn-primary" onclick="openCreateModal()">+ New Decommission</button>
            <?php endif; ?>
            <a href="decommission.php?action=export" class="btn btn-outline-secondary">Export CSV</a>
            <?php if ($role === 'Admin'): ?>
                <button type="button" class="btn btn-outline-secondary" onclick="openGlobalHistoryModal()">Global Audit History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="alert alert-warning border-warning mb-4">
        <strong>Note:</strong> Server decommissioning must always be performed through an approved Change Request (CR). Make sure all stakeholders approved and alert removed.
    </div>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header" style="margin-bottom:0;">
            <span class="panel-title">Search</span>
            <form method="GET" action="decommission.php" style="display: flex; gap: 0.5rem;">
                <input type="text" name="keyword" class="form-control" placeholder="Search hostname/project..." value="<?php echo htmlspecialchars($keyword); ?>" style="width: 240px;">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <span class="panel-title">Decommission Records</span>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="table table-hover align-middle mb-0 decom-table">
                <thead>
                    <tr>
                        <th>Hostname</th>
                        <th>Project</th>
                        <th>Server State</th>
                        <th>Support Level</th>
                        <th>App Name</th>
                        <th>IP Address</th>
                        <th>Timeline</th>
                        <th>Attachments</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                        <tr>
                            <td class="cell-primary"><?php echo htmlspecialchars($r['hostname']); ?></td>
                            <td><?php echo htmlspecialchars($r['project']); ?></td>
                            <td><span class="badge-state"><?php echo htmlspecialchars($r['server_state']); ?></span></td>
                            <td><span class="badge-support"><?php echo htmlspecialchars($r['support_level']); ?></span></td>
                            <td><?php echo htmlspecialchars($r['application_name']); ?></td>
                            <td><?php echo htmlspecialchars($r['ip_address']); ?></td>
                            <td><small><?php echo htmlspecialchars($r['decommission_start_date'] ?? 'N/A'); ?><?php if(!empty($r['decommission_end_date'])) echo ' to ' . htmlspecialchars($r['decommission_end_date']); ?></small></td>
                            <td>
                                <?php if (!empty($r['attachment'])): ?>
                                    <?php
                                        $files = explode(',', $r['attachment']);
                                        foreach ($files as $idx => $file):
                                            $file = trim($file);
                                            if(empty($file)) continue;
                                    ?>
                                        <a href="uploads/<?php echo htmlspecialchars($file); ?>" target="_blank" class="btn btn-sm btn-outline-info mb-1">File <?php echo ($idx + 1); ?></a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <span class="text-muted small">None</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; white-space: nowrap;">
                                <button type="button" class="btn btn-sm btn-info text-white" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars($r['hostname']); ?>', false)">View Tasks</button>
                                <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                                    <button type="button" class="btn btn-sm btn-warning text-dark" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars($r['hostname']); ?>', true)">Tasks</button>
                                    <button type="button" class="btn btn-sm btn-primary" onclick='openEditModal(<?php echo json_encode($r); ?>)'>Edit</button>
                                <?php endif; ?>
                                <?php if ($role === 'Admin'): ?>
                                    <button type="button" class="btn btn-sm btn-danger" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['hostname'])); ?>')">Delete</button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9"><p class="empty-state">No decommission records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination-row" style="padding-bottom:22px;">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="decommission.php?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>" class="btn btn-sm btn-outline-secondary <?php if ($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- Modals -->
<div class="modal fade" id="recordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Decommission Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="decommission.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="form_action" value="save">
                    <input type="hidden" name="id" id="rec_id">
                    <input type="hidden" name="existing_attachment" id="rec_existing_attachment">
                    <div class="row g-3">
                        <div class="col-md-6" id="hostnameSearchContainer">
                            <label class="form-label">Search/Select Hostname from Inventory *</label>
                            <select name="hostname" id="rec_hostname_select" class="form-control" onchange="fetchInventoryData(this.value)">
                                <option value="">-- Choose Hostname --</option>
                                <?php foreach ($inventory_list as $inv_host): ?>
                                    <option value="<?php echo htmlspecialchars($inv_host); ?>"><?php echo htmlspecialchars($inv_host); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6" id="hostnameDisplayContainer" style="display:none;">
                            <label class="form-label">Hostname *</label>
                            <input type="text" name="hostname" id="rec_hostname_input" class="form-control" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Server State</label>
                            <select class="form-select" name="server_state" id="server_state" required>
                                <option value="">Select Server State...</option>
                                <option value="powered on">Powered On / Active</option>
                                <option value="powered off">Powered Off</option>
                                <option value="to be decomm">To Be Decommissioned</option>
                                <option value="decommissioned">Decommissioned</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Project Name</label><input type="text" name="project" id="rec_project" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Support Level</label><input type="text" name="support_level" id="rec_support_level" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Application Name</label><input type="text" name="application_name" id="rec_application_name" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">IP Address</label><input type="text" name="ip_address" id="rec_ip_address" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Additional IPs</label><input type="text" name="additional_ips" id="rec_additional_ips" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Decommission Start Date *</label><input type="date" name="decommission_start_date" id="rec_start_date" class="form-control" required></div>
                        <div class="col-md-6"><label class="form-label">Decommission End Date</label><input type="date" name="decommission_end_date" id="rec_end_date" class="form-control"></div>
                        <div class="col-md-12">
                            <label class="form-label">Attachment Documents (Microsoft Office files, CSV, PDFs, Images, Archives allowed)</label>
                            <input type="file" name="attachment_files[]" class="form-control" multiple>
                            <div id="fileHelpBlock" class="form-text"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-primary">Save Record</button></div>
            </form>
        </div>
    </div>
</div>

<!-- Task Modal Container -->
<div class="modal fade" id="taskModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title"><span id="taskModalTitleMode">Checklist Tasks</span>: <span id="taskModalHostname" class="text-warning"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="taskModalBody" style="max-height: 70vh; overflow-y: auto;">
                <p class="text-muted">Loading checklist tasks...</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content text-center">
            <div class="modal-header"><h5 class="modal-title">Confirm Deletion</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"><p>Are you sure you want to delete decommission record for hostname: <strong id="del_hostname"></strong>?</p></div>
            <div class="modal-footer justify-content-center">
                <form method="POST" action="decommission.php">
                    <input type="hidden" name="form_action" value="delete">
                    <input type="hidden" name="id" id="del_id">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="globalHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Module Audit History</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body" id="globalHistoryContent" style="max-height: 60vh; overflow-y: auto;"><p class="text-muted">Loading audit trails...</p></div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function fetchInventoryData(hostname) {
        if (!hostname) { clearInventoryFields(); return; }
        fetch('decommission.php?action=get_inventory_details&hostname=' + encodeURIComponent(hostname))
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('rec_project').value = data.project || '';
                    document.getElementById('rec_support_level').value = data.support_level || '';
                    document.getElementById('server_state').value = data.server_state || '';
                    document.getElementById('rec_application_name').value = data.application_name || '';
                    document.getElementById('rec_ip_address').value = data.ip_address || '';
                    document.getElementById('rec_additional_ips').value = data.additional_ips || '';
                } else { clearInventoryFields(); }
            }).catch(() => clearInventoryFields());
    }

    function clearInventoryFields() {
        ['rec_project', 'rec_support_level', 'server_state', 'rec_application_name', 'rec_ip_address', 'rec_additional_ips'].forEach(id => document.getElementById(id).value = '');
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'New Decommission Entry';
        document.getElementById('rec_id').value = '';
        document.getElementById('rec_existing_attachment').value = '';
        document.getElementById('fileHelpBlock').innerHTML = '';
        document.getElementById('hostnameSearchContainer').style.display = 'block';
        document.getElementById('hostnameDisplayContainer').style.display = 'none';
        document.getElementById('rec_hostname_select').value = '';
        document.getElementById('rec_hostname_select').required = true;
        document.getElementById('rec_hostname_select').setAttribute('name', 'hostname');
        document.getElementById('rec_hostname_input').removeAttribute('name');
        clearInventoryFields();
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Decommission Entry';
        document.getElementById('rec_id').value = data.id;
        document.getElementById('hostnameSearchContainer').style.display = 'none';
        document.getElementById('hostnameDisplayContainer').style.display = 'block';
        document.getElementById('rec_hostname_select').removeAttribute('name');
        document.getElementById('rec_hostname_input').setAttribute('name', 'hostname');
        document.getElementById('rec_hostname_input').value = data.hostname;
        document.getElementById('server_state').value = data.server_state || '';
        document.getElementById('rec_support_level').value = data.support_level || '';
        document.getElementById('rec_project').value = data.project || '';
        document.getElementById('rec_application_name').value = data.application_name || '';
        document.getElementById('rec_ip_address').value = data.ip_address || '';
        document.getElementById('rec_additional_ips').value = data.additional_ips || '';
        document.getElementById('rec_start_date').value = data.decommission_start_date || '';
        document.getElementById('rec_end_date').value = data.decommission_end_date || '';
        document.getElementById('rec_existing_attachment').value = data.attachment || '';

        let fileListHtml = 'No files currently attached.';
        if (data.attachment) {
            let files = data.attachment.split(',');
            fileListHtml = 'Current files: ';
            files.forEach((f, idx) => {
                fileListHtml += `<br><a href="uploads/${f.trim()}" target="_blank">File ${idx + 1} (${f.trim()})</a>`;
            });
        }
        document.getElementById('fileHelpBlock').innerHTML = fileListHtml;
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openDeleteModal(id, hostname) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_hostname').innerText = hostname;
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    }

    function openTaskModal(decommissionId, hostname, isEditable) {
        document.getElementById('taskModalHostname').innerText = hostname;
        document.getElementById('taskModalTitleMode').innerText = isEditable ? 'Modify Checklist Tasks' : 'View Checklist Tasks';
        document.getElementById('taskModalBody').innerHTML = '<p class="text-muted">Loading checklist tasks...</p>';

        fetch('get_tasks.php?decommission_id=' + decommissionId + '&edit=' + (isEditable ? 1 : 0))
            .then(res => res.text())
            .then(html => { document.getElementById('taskModalBody').innerHTML = html; })
            .catch(() => { document.getElementById('taskModalBody').innerHTML = '<p class="text-danger">Failed to load tasks.</p>'; });

        new bootstrap.Modal(document.getElementById('taskModal')).show();
    }

    function submitTaskForm(event, decommissionId, editable) {
        event.preventDefault();
        const form = document.getElementById('inlineTaskForm');
        const formData = new FormData(form);

        fetch('save_tasks.php?decommission_id=' + decommissionId, {
            method: 'POST',
            body: formData
        })
        .then(res => res.text())
        .then(() => {
            openTaskModal(decommissionId, document.getElementById('taskModalHostname').innerText, editable == 1);
        })
        .catch(() => {
            alert('Failed to save task progress.');
        });
    }

    function openGlobalHistoryModal() {
        new bootstrap.Modal(document.getElementById('globalHistoryModal')).show();
        document.getElementById('globalHistoryContent').innerHTML = '<p class="text-muted">Loading audit history...</p>';
        fetch('decommission.php?action=get_history')
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="text-danger">Failed to load audit history.</p>'; });
    }
</script>

<?php require 'includes/footer.php'; ?>
