<?php

require_once __DIR__ . '/config/db.php';

session_start();


/*
=========================================
FLASH MESSAGE
=========================================
*/

$success_msg = $_SESSION['success_msg'] ?? '';
$error_msg   = $_SESSION['error_msg'] ?? '';

unset($_SESSION['success_msg']);
unset($_SESSION['error_msg']);



/*
=========================================
AUTHENTICATION
=========================================
*/

if (!isset($_SESSION['user_id'])) {

    header("Location: login.php");
    exit;

}



$current_user_id = (int)$_SESSION['user_id'];

$current_name = $_SESSION['first_name'] ?? $_SESSION['name'] ?? '';

$role = strtolower(trim($_SESSION['role'] ?? ''));




/*
=========================================
HELPERS
=========================================
*/

function isAdmin($role)
{
    return strtolower($role) === 'admin';
}



function canManage($owner_id,$current_id,$role)
{
    return (
        (int)$owner_id === (int)$current_id
        ||
        isAdmin($role)
    );
}





/*
=========================================
POST ACTIONS
=========================================
*/

if($_SERVER['REQUEST_METHOD']==='POST'){


    $action = $_POST['action'] ?? '';



    /*
    =========================================
    CREATE REMINDER
    =========================================
    */


    if($action === 'save_reminder'){


        $title = trim($_POST['title'] ?? '');

        $message = trim($_POST['message'] ?? '');

        $visibility = $_POST['visibility'] ?? 'all';

        $emails = trim($_POST['additional_emails'] ?? '');



        /*
        FIX DATE HANDLING
        */

        $date = trim($_POST['full_reminder_date'] ?? '');

        if(
            empty($date)
            &&
            !empty($_POST['reminder_date'])
            &&
            !empty($_POST['reminder_time'])
        ){

            $date =
            $_POST['reminder_date']
            .' '
            .$_POST['reminder_time']
            .':00';

        }



        if(
            empty($title)
            ||
            empty($message)
            ||
            empty($date)
        ){

            $_SESSION['error_msg'] =
            "Please fill all reminder fields.";

            header("Location: reminders.php");
            exit;

        }




        try{


            $pdo->beginTransaction();



            $stmt=$pdo->prepare(

            "INSERT INTO reminders
            (
                user_id,
                title,
                message,
                reminder_date,
                visibility,
                additional_emails
            )

            VALUES(?,?,?,?,?,?)"

            );



            $stmt->execute([

                $current_user_id,
                $title,
                $message,
                $date,
                $visibility,
                $emails

            ]);



            $pdo->commit();



            $_SESSION['success_msg'] =
            "Reminder created successfully.";



            /*
            PRG PATTERN
            Prevent duplicate submission
            */

            header("Location: reminders.php");
            exit;



        }
        catch(Exception $e){


            if($pdo->inTransaction()){
                $pdo->rollBack();
            }


            $_SESSION['error_msg'] =
            "Unable to save reminder: ".$e->getMessage();


            header("Location: reminders.php");
            exit;

        }



    }






    /*
    =========================================
    EDIT REMINDER
    =========================================
    */


    if($action==='edit_reminder'){


        $id=(int)$_POST['reminder_id'];



        $stmt=$pdo->prepare(

        "UPDATE reminders SET

        title=?,
        message=?,
        reminder_date=?,
        visibility=?,
        additional_emails=?

        WHERE id=?

        AND
        (
            user_id=?
            OR LOWER(?)='admin'
        )

        "

        );



        $stmt->execute([

            $_POST['title'],

            $_POST['message'],

            $_POST['full_reminder_date'],

            $_POST['visibility'],

            $_POST['additional_emails'],

            $id,

            $current_user_id,

            $role

        ]);



        $_SESSION['success_msg']="Reminder updated successfully.";

        header("Location: reminders.php");
        exit;

    }







    /*
    =========================================
    DELETE REMINDER
    =========================================
    */


    if($action==='delete_reminder'){


        $id=(int)$_POST['reminder_id'];



        $stmt=$pdo->prepare(

        "DELETE FROM reminders

        WHERE id=?

        AND
        (
            user_id=?
            OR LOWER(?)='admin'
        )"

        );



        $stmt->execute([

            $id,
            $current_user_id,
            $role

        ]);



        $_SESSION['success_msg']="Reminder deleted successfully.";

        header("Location: reminders.php");
        exit;

    }
        /*
    =========================================
    SAVE STICKY NOTE
    =========================================
    */

    if($action === 'save_note'){


        $content = trim($_POST['content'] ?? '');

        $visibility = $_POST['visibility'] ?? 'all';

        $id = (int)($_POST['note_id'] ?? 0);



        header('Content-Type: application/json');


        if(empty($content)){

            echo json_encode([
                "status"=>"error",
                "message"=>"Empty note"
            ]);

            exit;

        }



        try{


            if($id > 0){


                $stmt=$pdo->prepare("

                UPDATE sticky_notes SET

                content=?,

                visibility=?,

                updated_at=CURRENT_TIMESTAMP

                WHERE id=?

                AND
                (
                    user_id=?
                    OR LOWER(?)='admin'
                )

                ");



                $stmt->execute([

                    $content,

                    $visibility,

                    $id,

                    $current_user_id,

                    $role

                ]);


            }
            else{


                $stmt=$pdo->prepare("

                INSERT INTO sticky_notes

                (
                    user_id,
                    content,
                    visibility
                )

                VALUES(?,?,?)

                ");



                $stmt->execute([

                    $current_user_id,

                    $content,

                    $visibility

                ]);


            }



            echo json_encode([
                "status"=>"success"
            ]);


        }
        catch(Exception $e){


            echo json_encode([

                "status"=>"error",

                "message"=>$e->getMessage()

            ]);


        }


        exit;

    }






    /*
    =========================================
    DELETE STICKY NOTE
    =========================================
    */


    if($action === 'delete_note'){


        $id=(int)($_POST['note_id'] ?? 0);



        $stmt=$pdo->prepare("

        DELETE FROM sticky_notes

        WHERE id=?

        AND
        (
            user_id=?
            OR LOWER(?)='admin'
        )

        ");



        $stmt->execute([

            $id,

            $current_user_id,

            $role

        ]);



        header('Content-Type: application/json');


        echo json_encode([

            "status"=>"success"

        ]);


        exit;


    }

}






/*
=========================================
FETCH STICKY NOTES
=========================================
*/


$stmt=$pdo->prepare(

"SELECT *

FROM sticky_notes

WHERE

visibility='all'

OR user_id=?

OR LOWER(?)='admin'

ORDER BY updated_at DESC"

);



$stmt->execute([

$current_user_id,
$role

]);



$sticky_notes=$stmt->fetchAll(PDO::FETCH_ASSOC);







/*
=========================================
FETCH REMINDERS
=========================================
*/


$stmt = $pdo->prepare("
SELECT
    r.*,
    u.first_name,
    u.last_name
FROM reminders r
LEFT JOIN users u
    ON r.user_id = u.id
WHERE
    r.visibility = 'all'
    OR r.user_id = ?
    OR LOWER(?) = 'admin'
ORDER BY r.reminder_date ASC
");


$stmt->execute([

$current_user_id,
$role

]);



$reminders=$stmt->fetchAll(PDO::FETCH_ASSOC);





/*
=========================================
EDIT LOAD
=========================================
*/


$edit_reminder=null;


if(isset($_GET['edit_reminder'])){


$stmt=$pdo->prepare(

"SELECT *

FROM reminders

WHERE id=?"

);


$stmt->execute([

$_GET['edit_reminder']

]);


$edit_reminder=$stmt->fetch(PDO::FETCH_ASSOC);


}
require_once __DIR__ . '/includes/sidebar.php';
require_once __DIR__ . '/includes/header.php';

?>
<main class="content">
<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="UTF-8">

<title>
InfraVault - Alerts & Reminders
</title>


<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/dashboard.css">

<link rel="stylesheet" href="assets/css/reminders-enterprise.css">


</head>


<body>





<!-- =================================
MAIN AREA
================================= -->


<div class="main-wrapper">









<!-- =================================
STICKY NOTES FEED
================================= -->


<section class="enterprise-card">


<h2 class="enterprise-title">

📝 Sticky Notes Feed

</h2>



<div class="notes-container">



<?php if(empty($sticky_notes)): ?>


<p>

No sticky notes available.

</p>


<?php endif; ?>





<?php foreach($sticky_notes as $note): ?>


<div class="enterprise-note">



<div class="note-text">

<?=nl2br(
htmlspecialchars(
$note['content']
)
)?>

</div>




<div class="note-footer">


Visibility:

<?php if($note['visibility']=='all'): ?>

<span class="status-all">

Everyone

</span>


<?php else: ?>

<span class="status-private">

Private

</span>


<?php endif; ?>



<br>


Updated:

<?=$note['updated_at']?>



</div>







<?php if(canManage(
$note['user_id'],
$current_user_id,
$role
)): ?>



<div class="note-actions">



<button

class="enterprise-btn btn-edit"


onclick="editNote(

<?=$note['id']?>,

`<?=htmlspecialchars(
addslashes(
$note['content']
)
)?>`,

'<?=$note['visibility']?>'

)">


✏ Edit

</button>





<button

class="enterprise-btn btn-delete"


onclick="deleteNote(
<?=$note['id']?>
)">


🗑 Delete


</button>



</div>



<?php endif; ?>





</div>



<?php endforeach; ?>



</div>


</section>









<!-- =================================
REMINDER TABLE
================================= -->


<section class="enterprise-card">


<h2 class="enterprise-title">

🔔 Scheduled Reminders

</h2>





<div class="table-wrapper">


<table class="enterprise-table">


<thead>


<tr>

<th>
Title
</th>


<th>
Date
</th>


<th>
Owner
</th>


<th>
Visibility
</th>


<th>
Action
</th>


</tr>


</thead>



<tbody>



<?php foreach($reminders as $rem): ?>


<tr>


<td>

<strong>

<?=htmlspecialchars(
$rem['title']
)?>

</strong>

</td>




<td>

<?=htmlspecialchars(
$rem['reminder_date']
)?>

</td>



<td>

<?= htmlspecialchars(trim(($rem['first_name'] ?? '') . ' ' . ($rem['last_name'] ?? ''))) ?>
</td>




<td>


<?php if($rem['visibility']=='all'): ?>

<span class="status-all">

Everyone

</span>


<?php else: ?>


<span class="status-private">

Private

</span>


<?php endif; ?>


</td>




<td>


<?php if(canManage(
$rem['user_id'],
$current_user_id,
$role
)): ?>



<a

href="reminders.php?edit_reminder=<?=$rem['id']?>"

class="enterprise-btn btn-edit">


✏ Edit


</a>





<form method="POST"
style="display:inline">


<input type="hidden"
name="action"
value="delete_reminder">



<input type="hidden"
name="reminder_id"
value="<?=$rem['id']?>">





<button

class="enterprise-btn btn-delete"

onclick="return confirm('Delete reminder?')">


🗑 Delete


</button>



</form>



<?php else: ?>


<span style="color:#94a3b8">

View Only

</span>


<?php endif; ?>



</td>


</tr>



<?php endforeach; ?>



</tbody>


</table>


</div>


</section>









<!-- =================================
CREATE / EDIT AREA
================================= -->


<div class="reminder-grid">



<section class="enterprise-card">


<h2 class="enterprise-title">


<?=

$edit_reminder

?

"✏ Edit Reminder"

:

"⏰ Create Reminder"

?>


</h2>





<form method="POST">


<input type="hidden"
name="action"
value="<?=

$edit_reminder

?

'edit_reminder'

:

'save_reminder'

?>">



<?php if($edit_reminder): ?>


<input type="hidden"
name="reminder_id"
value="<?=$edit_reminder['id']?>">


<?php endif; ?>





<div class="form-group">


<label>

Title

</label>


<input

class="form-control"

name="title"

required

value="<?=htmlspecialchars(
$edit_reminder['title'] ?? ''
)?>">


</div>







<div class="form-group">


<label>

Message

</label>


<textarea

class="form-control"

name="message"

required><?=htmlspecialchars(
$edit_reminder['message'] ?? ''
)?></textarea>


</div>





<div class="datetime-grid">


<div>


<label>
Date
</label>


<input

type="date"

name="reminder_date"
id="reminder_date"

class="form-control"

required>


</div>





<div>


<label>
Time
</label>


<input

type="time"
name="reminder_date"

id="reminder_time"

class="form-control"

step="60"

required>


</div>


</div>





<input

type="hidden"

name="full_reminder_date"

id="full_reminder_date">






<div class="form-group">


<label>

Additional Emails

</label>


<input

class="form-control"

name="additional_emails"

value="<?=htmlspecialchars(
$edit_reminder['additional_emails'] ?? ''
)?>">


</div>





<div class="form-group">


<label>

Visibility

</label>



<select

name="visibility"

class="form-control">


<option value="all">

Everyone

</option>


<option value="me">

Private

</option>


</select>


</div>




<button type="submit" class="enterprise-btn btn-save">
💾 Save Reminder
</button>


</form>



</section>





<section class="enterprise-card">


<h2 class="enterprise-title">

📝 Sticky Note Editor

</h2>



<input type="hidden"
id="active-note-id">





<textarea

id="sticky-content"

class="form-control"

placeholder="Write note..."></textarea>





<br>



<select

id="sticky-visibility"

class="form-control">


<option value="all">

Everyone

</option>


<option value="me">

Private

</option>


</select>



<br>



<button

class="enterprise-btn btn-save"

onclick="saveNote()">



💾 Save Note


</button>




<button

class="enterprise-btn btn-delete"

onclick="deleteNote()">



🗑 Delete


</button>




</section>




</div>






</main>






</div>


<script>


/*







=========================================
DATE + TIME PICKER FIX

Chrome supports input type=time
Firefox sometimes does not show picker properly.

This creates the final datetime value
correctly.
=========================================
*/


function updateReminderDateTime(){


let date =
document.getElementById(
"reminder_date"
).value;



let time =
document.getElementById(
"reminder_time"
).value;



if(date && time){


document.getElementById(
"full_reminder_date"
).value =
date+" "+time+":00";


}


}



document
.getElementById("reminder_date")
.addEventListener(
"change",
updateReminderDateTime
);



document
.getElementById("reminder_time")
.addEventListener(
"change",
updateReminderDateTime
);









/*
=========================================
LOAD REMINDER EDIT DATE/TIME
=========================================
*/


<?php if($edit_reminder): ?>


let existingDate =
"<?=$edit_reminder['reminder_date']?>";


if(existingDate){


let parts =
existingDate.split(" ");



document.getElementById(
"reminder_date"
).value =
parts[0];



document.getElementById(
"reminder_time"
).value =
parts[1].substring(0,5);



document.getElementById(
"full_reminder_date"
).value =
existingDate;


}


<?php endif; ?>











/*
=========================================
STICKY NOTE SAVE
=========================================
*/


function saveNote(){



let content =
document.getElementById(
"sticky-content"
).value;



let visibility =
document.getElementById(
"sticky-visibility"
).value;



let id =
document.getElementById(
"active-note-id"
).value;





if(content.trim()===""){


alert(
"Please enter note content"
);


return;


}




let data =
new FormData();



data.append(
"action",
"save_note"
);



data.append(
"content",
content
);



data.append(
"visibility",
visibility
);



if(id){


data.append(
"note_id",
id
);


}




fetch(
"reminders.php",
{

method:"POST",

body:data

}

)


.then(
response=>response.json()
)


.then(
result=>{


if(result.status==="success"){


location.reload();


}

else{


alert(
result.message
);


}


}

);


}










/*
=========================================
LOAD NOTE INTO EDITOR
=========================================
*/


function editNote(
id,
content,
visibility
){



document.getElementById(
"active-note-id"
).value=id;



document.getElementById(
"sticky-content"
).value=content;



document.getElementById(
"sticky-visibility"
).value=visibility;



window.scrollTo({

top:

document.getElementById(
"sticky-content"
).offsetTop-200,

behavior:"smooth"

});


}









/*
=========================================
DELETE NOTE
=========================================
*/


function deleteNote(id){



if(!id){


id=document.getElementById(
"active-note-id"
).value;


}




if(!id){


alert(
"Select a note first"
);


return;


}




if(
!confirm(
"Delete this sticky note?"
)

){

return;


}





let data =
new FormData();



data.append(
"action",
"delete_note"
);



data.append(
"note_id",
id
);




fetch(
"reminders.php",
{

method:"POST",

body:data

}

)


.then(
response=>response.json()
)


.then(
()=>{


location.reload();


}

);


}





</script>




</main>



<?php

include "includes/footer.php";

?>




<script src="assets/js/sidebar.js"></script>
