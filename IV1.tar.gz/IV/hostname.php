<?php

require_once 'config/db.php';


/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int)$_SESSION['user_id'];

$role = strtolower(
    trim($_SESSION['role'] ?? '')
);

$is_admin = in_array(
    $role,
    [
        'admin',
        'administrator',
        'super admin',
        'superadmin'
    ],
    true
);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['hostname_csrf'])) {
    $_SESSION['hostname_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf_token =
    $_SESSION['hostname_csrf'];


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function redirect_hostname(): void
{
    header('Location: hostname.php');
    exit;
}


function check_hostname_csrf(): void
{
    $token =
        $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['hostname_csrf']) ||
        !hash_equals(
            $_SESSION['hostname_csrf'],
            $token
        )
    ) {

        http_response_code(403);

        exit(
            'Invalid security token.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| NORMALIZE ABBREVIATION
|--------------------------------------------------------------------------
|
| Only letters and numbers.
| Maximum 3 characters.
|
*/

function normalize_code(
    string $value,
    int $length = 3
): string {

    $value = strtoupper(
        trim($value)
    );

    $value = preg_replace(
        '/[^A-Z0-9]/',
        '',
        $value
    );

    return substr(
        $value,
        0,
        $length
    );
}


/*
|--------------------------------------------------------------------------
| GENERATE ABBREVIATION
|--------------------------------------------------------------------------
|
| Example:
|
| Customer Billing Platform
| -> CBP
|
| Payment Gateway
| -> PAY
|
*/

function generate_abbreviation(
    string $name
): string {

    $name = trim($name);

    if ($name === '') {
        return '';
    }

    $words = preg_split(
        '/\s+/',
        $name
    );

    $letters = '';

    foreach ($words as $word) {

        $word = preg_replace(
            '/[^A-Za-z0-9]/',
            '',
            $word
        );

        if ($word !== '') {
            $letters .= strtoupper(
                substr($word, 0, 1)
            );
        }

        if (strlen($letters) >= 3) {
            break;
        }
    }

    /*
    |--------------------------------------------------------------------------
    | If initials are fewer than 3 characters,
    | take additional characters from the full name.
    |--------------------------------------------------------------------------
    */

    if (strlen($letters) < 3) {

        $compact = strtoupper(
            preg_replace(
                '/[^A-Za-z0-9]/',
                '',
                $name
            )
        );

        for (
            $i = 0;
            $i < strlen($compact);
            $i++
        ) {

            $char = $compact[$i];

            if (
                strpos(
                    $letters,
                    $char
                ) === false
            ) {

                $letters .= $char;
            }

            if (strlen($letters) >= 3) {
                break;
            }
        }
    }

    return substr(
        $letters,
        0,
        3
    );
}


/*
|--------------------------------------------------------------------------
| LOAD CODES
|--------------------------------------------------------------------------
*/

function load_hostname_codes(
    PDO $pdo,
    string $category
): array {

    $stmt = $pdo->prepare("
        SELECT
            code_key,
            code_value,
            is_admin_only
        FROM hostname_generator_codes
        WHERE category = ?
        ORDER BY id ASC
    ");

    $stmt->execute([
        $category
    ]);

    return $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );
}


$platform_codes =
    load_hostname_codes(
        $pdo,
        'platform'
    );

$environment_codes =
    load_hostname_codes(
        $pdo,
        'environment'
    );

$os_codes =
    load_hostname_codes(
        $pdo,
        'os'
    );


/*
|--------------------------------------------------------------------------
| FIND CODE
|--------------------------------------------------------------------------
*/

function find_code(
    array $codes,
    string $key
): ?array {

    foreach ($codes as $code) {

        if ($code['code_key'] === $key) {
            return $code;
        }
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| HOSTNAME EXISTS
|--------------------------------------------------------------------------
|
| Check BOTH:
|
| 1. inventory
| 2. hostname_reservations
|
*/

function hostname_exists(
    PDO $pdo,
    string $hostname,
    ?int $exclude_reservation_id = null
): bool {

    /*
    |--------------------------------------------------------------------------
    | Inventory
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT 1
        FROM inventory
        WHERE hostname = ?
        LIMIT 1
    ");

    $stmt->execute([
        $hostname
    ]);

    if ($stmt->fetchColumn()) {
        return true;
    }


    /*
    |--------------------------------------------------------------------------
    | Reservations
    |--------------------------------------------------------------------------
    */

    if ($exclude_reservation_id !== null) {

        $stmt = $pdo->prepare("
            SELECT 1
            FROM hostname_reservations
            WHERE hostname = ?
              AND id != ?
            LIMIT 1
        ");

        $stmt->execute([
            $hostname,
            $exclude_reservation_id
        ]);

    } else {

        $stmt = $pdo->prepare("
            SELECT 1
            FROM hostname_reservations
            WHERE hostname = ?
            LIMIT 1
        ");

        $stmt->execute([
            $hostname
        ]);
    }

    return (bool)$stmt->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| BUILD HOSTNAME
|--------------------------------------------------------------------------
|
| Structure:
|
| PLATFORM 3
| ENV       1
| OS        1
| P/V       1
| PROJECT   3
| APP       3
| NODE      2
|
| Example:
|
| RY1PWPABCAPP01
|
| Maximum = 14 characters with this structure.
|
| We still enforce the global 23-character limit.
|
*/

function build_hostname(
    string $platform,
    string $environment,
    string $os,
    string $physical_virtual,
    string $project,
    string $application,
    int $node
): string {

    $platform =
        normalize_code(
            $platform,
            3
        );

    $environment =
        normalize_code(
            $environment,
            1
        );

    $os =
        normalize_code(
            $os,
            1
        );

    $physical_virtual =
        normalize_code(
            $physical_virtual,
            1
        );

    $project =
        normalize_code(
            $project,
            3
        );

    $application =
        normalize_code(
            $application,
            3
        );

    $node =
        max(
            1,
            $node
        );

    $node_code =
        str_pad(
            (string)$node,
            2,
            '0',
            STR_PAD_LEFT
        );

    $hostname =
        $platform .
        $environment .
        $os .
        $physical_virtual .
        $project .
        $application .
        $node_code;

    if (strlen($hostname) > 23) {

        throw new RuntimeException(
            'Generated hostname exceeds 23 characters.'
        );
    }

    if (
        !preg_match(
            '/^[A-Z0-9]+$/',
            $hostname
        )
    ) {

        throw new RuntimeException(
            'Generated hostname contains invalid characters.'
        );
    }

    return $hostname;
}


/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['hostname_success']
    ?? '';

$error_msg =
    $_SESSION['hostname_error']
    ?? '';

unset(
    $_SESSION['hostname_success'],
    $_SESSION['hostname_error']
);


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    check_hostname_csrf();

    $form_action =
        $_POST['form_action']
        ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE GENERATED HOSTNAMES
    |--------------------------------------------------------------------------
    */

    if (
        $form_action
        === 'save_reservations'
    ) {

        $hostnames =
            $_POST['hostname'] ?? [];

        $platform_key =
            trim(
                $_POST['platform_key']
                ?? ''
            );

        $environment_key =
            trim(
                $_POST['environment_key']
                ?? ''
            );

        $os_key =
            trim(
                $_POST['os_key']
                ?? ''
            );

        $physical_virtual =
            trim(
                $_POST['physical_virtual']
                ?? ''
            );

        $project_name =
            trim(
                $_POST['project_name']
                ?? ''
            );

        $project_code =
            trim(
                $_POST['project_code']
                ?? ''
            );

        $project_abbreviation =
            normalize_code(
                $_POST['project_abbreviation']
                ?? '',
                3
            );

        $application_name =
            trim(
                $_POST['application_name']
                ?? ''
            );

        $application_abbreviation =
            normalize_code(
                $_POST[
                    'application_abbreviation'
                ]
                ?? '',
                3
            );

        $platform =
            find_code(
                $platform_codes,
                $platform_key
            );

        $environment =
            find_code(
                $environment_codes,
                $environment_key
            );

        $os =
            find_code(
                $os_codes,
                $os_key
            );


        if (
            !$platform ||
            !$environment ||
            !$os
        ) {

            $_SESSION['hostname_error'] =
                'Invalid hostname code selection.';

            redirect_hostname();
        }


        if (
            !in_array(
                $physical_virtual,
                ['P', 'V'],
                true
            )
        ) {

            $_SESSION['hostname_error'] =
                'Please select Physical or Virtual.';

            redirect_hostname();
        }


        if (
            $project_abbreviation === ''
            ||
            strlen($project_abbreviation) !== 3
        ) {

            $_SESSION['hostname_error'] =
                'Project abbreviation must contain exactly 3 characters.';

            redirect_hostname();
        }


        if (
            $application_abbreviation === ''
            ||
            strlen($application_abbreviation) !== 3
        ) {

            $_SESSION['hostname_error'] =
                'Application abbreviation must contain exactly 3 characters.';

            redirect_hostname();
        }


        if (!is_array($hostnames)) {
            $hostnames = [];
        }


        $hostnames =
            array_values(
                array_unique(
                    array_filter(
                        $hostnames
                    )
                )
            );


        if (!$hostnames) {

            $_SESSION['hostname_error'] =
                'No hostnames were supplied.';

            redirect_hostname();
        }


        $pdo->beginTransaction();

        try {

            $stmt = $pdo->prepare("
                INSERT INTO hostname_reservations
                (
                    hostname,

                    platform_key,
                    platform_code,

                    environment_key,
                    environment_code,

                    os_key,
                    os_code,

                    physical_virtual,

                    project_name,
                    project_code,
                    project_abbreviation,

                    application_name,
                    application_abbreviation,

                    node_number,

                    status,
                    generated_by,

                    created_at,
                    updated_at
                )
                VALUES
                (
                    ?,
                    ?, ?,
                    ?, ?,
                    ?, ?,
                    ?,
                    ?, ?, ?,
                    ?, ?,
                    ?,
                    'Reserved',
                    ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");


            $saved = 0;


            foreach (
                $hostnames
                as $hostname
            ) {

                $hostname =
                    strtoupper(
                        trim($hostname)
                    );


                /*
                |--------------------------------------------------------------------------
                | Check inventory + reservations
                |--------------------------------------------------------------------------
                */

                if (
                    hostname_exists(
                        $pdo,
                        $hostname
                    )
                ) {

                    continue;
                }


                /*
                |--------------------------------------------------------------------------
                | Extract node number
                |--------------------------------------------------------------------------
                */

                $node_number = 1;

                if (
                    preg_match(
                        '/(\d{2})$/',
                        $hostname,
                        $match
                    )
                ) {

                    $node_number =
                        (int)$match[1];
                }


                try {

                    $stmt->execute([

                        $hostname,

                        $platform['code_key'],
                        $platform['code_value'],

                        $environment['code_key'],
                        $environment['code_value'],

                        $os['code_key'],
                        $os['code_value'],

                        $physical_virtual,

                        $project_name,
                        $project_code,
                        $project_abbreviation,

                        $application_name,
                        $application_abbreviation,

                        $node_number,

                        $current_user_id
                    ]);

                    $saved++;

                } catch (
                    PDOException $e
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | UNIQUE hostname collision
                    |--------------------------------------------------------------------------
                    */

                    if (
                        strpos(
                            strtolower(
                                $e->getMessage()
                            ),
                            'unique'
                        ) !== false
                    ) {
                        continue;
                    }

                    throw $e;
                }
            }


            $pdo->commit();


            if ($saved > 0) {

                $_SESSION['hostname_success'] =
                    $saved .
                    ' hostname(s) reserved successfully.';

            } else {

                $_SESSION['hostname_error'] =
                    'No hostname was saved. All generated hostnames already exist.';
            }

        } catch (
            Throwable $e
        ) {

            if (
                $pdo->inTransaction()
            ) {
                $pdo->rollBack();
            }

            $_SESSION['hostname_error'] =
                'Unable to save hostnames: ' .
                $e->getMessage();
        }

        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE RESERVATION
    |--------------------------------------------------------------------------
    */

    if (
        $form_action
        === 'delete_reservation'
    ) {

        $id =
            (int)(
                $_POST['reservation_id']
                ?? 0
            );

        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_reservations
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $reservation =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$reservation) {

            $_SESSION['hostname_error'] =
                'Reservation not found.';

            redirect_hostname();
        }


        if (
            !$is_admin &&
            (int)$reservation['generated_by']
                !== $current_user_id
        ) {

            http_response_code(403);

            exit(
                'You do not have permission to delete this reservation.'
            );
        }


        $stmt = $pdo->prepare("
            DELETE FROM hostname_reservations
            WHERE id = ?
        ");

        $stmt->execute([
            $id
        ]);


        $_SESSION['hostname_success'] =
            'Hostname reservation deleted.';

        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE RESERVATION
    |--------------------------------------------------------------------------
    */

    if (
        $form_action
        === 'update_reservation'
    ) {

        $id =
            (int)(
                $_POST['reservation_id']
                ?? 0
            );

        $project_name =
            trim(
                $_POST['project_name']
                ?? ''
            );

        $project_code =
            trim(
                $_POST['project_code']
                ?? ''
            );

        $application_name =
            trim(
                $_POST['application_name']
                ?? ''
            );

        $project_abbreviation =
            normalize_code(
                $_POST['project_abbreviation']
                ?? '',
                3
            );

        $application_abbreviation =
            normalize_code(
                $_POST[
                    'application_abbreviation'
                ]
                ?? '',
                3
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_reservations
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $reservation =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$reservation) {

            $_SESSION['hostname_error'] =
                'Reservation not found.';

            redirect_hostname();
        }


        if (
            !$is_admin &&
            (int)$reservation['generated_by']
                !== $current_user_id
        ) {

            http_response_code(403);

            exit(
                'You do not have permission to edit this reservation.'
            );
        }


        if (
            strlen($project_abbreviation)
            !== 3
            ||
            strlen($application_abbreviation)
            !== 3
        ) {

            $_SESSION['hostname_error'] =
                'Project and application abbreviations must be exactly 3 characters.';

            redirect_hostname();
        }


        /*
        |--------------------------------------------------------------------------
        | Rebuild hostname
        |--------------------------------------------------------------------------
        */

        try {

            $new_hostname =
                build_hostname(

                    $reservation[
                        'platform_code'
                    ],

                    $reservation[
                        'environment_code'
                    ],

                    $reservation[
                        'os_code'
                    ],

                    $reservation[
                        'physical_virtual'
                    ],

                    $project_abbreviation,

                    $application_abbreviation,

                    (int)$reservation[
                        'node_number'
                    ]
                );

        } catch (
            Throwable $e
        ) {

            $_SESSION['hostname_error'] =
                $e->getMessage();

            redirect_hostname();
        }


        if (
            hostname_exists(
                $pdo,
                $new_hostname,
                $id
            )
        ) {

            $_SESSION['hostname_error'] =
                'The new hostname already exists in inventory or another reservation.';

            redirect_hostname();
        }


        $stmt = $pdo->prepare("
            UPDATE hostname_reservations

            SET
                hostname = ?,

                project_name = ?,
                project_code = ?,
                project_abbreviation = ?,

                application_name = ?,
                application_abbreviation = ?,

                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?
        ");

        $stmt->execute([

            $new_hostname,

            $project_name,
            $project_code,
            $project_abbreviation,

            $application_name,
            $application_abbreviation,

            $id
        ]);


        $_SESSION['hostname_success'] =
            'Hostname reservation updated.';

        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | ADMIN CODE UPDATE
    |--------------------------------------------------------------------------
    */

    if (
        $form_action
        === 'update_code'
    ) {

        if (!$is_admin) {

            http_response_code(403);

            exit(
                'Administrator privileges required.'
            );
        }


        $id =
            (int)(
                $_POST['code_id']
                ?? 0
            );

        $new_value =
            strtoupper(
                trim(
                    $_POST['code_value']
                    ?? ''
                )
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_generator_codes
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $code =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$code) {

            $_SESSION['hostname_error'] =
                'Code not found.';

            redirect_hostname();
        }


        $required_length =
            $code['category']
            === 'platform'
                ? 3
                : 1;


        $new_value =
            normalize_code(
                $new_value,
                $required_length
            );


        if (
            strlen($new_value)
            !== $required_length
        ) {

            $_SESSION['hostname_error'] =
                ucfirst(
                    $code['category']
                )
                .
                ' code must contain exactly '
                .
                $required_length
                .
                ' character(s).';

            redirect_hostname();
        }


        try {

            $stmt = $pdo->prepare("
                UPDATE hostname_generator_codes

                SET
                    code_value = ?,
                    updated_at = CURRENT_TIMESTAMP

                WHERE id = ?
            ");

            $stmt->execute([
                $new_value,
                $id
            ]);


            $_SESSION['hostname_success'] =
                'Hostname code updated.';

        } catch (
            PDOException $e
        ) {

            $_SESSION['hostname_error'] =
                'That code is already being used.';
        }

        redirect_hostname();
    }
}


/*
|--------------------------------------------------------------------------
| PROJECT / APPLICATION SUGGESTIONS
|--------------------------------------------------------------------------
*/

$project_suggestions = $pdo->query("
    SELECT
        project_name,
        project_code,
        project_abbreviation
    FROM hostname_reservations
    WHERE project_name IS NOT NULL
      AND TRIM(project_name) <> ''
    GROUP BY
        project_name,
        project_code,
        project_abbreviation
    ORDER BY project_name
")->fetchAll(
    PDO::FETCH_ASSOC
);


$application_suggestions = $pdo->query("
    SELECT
        application_name,
        application_abbreviation
    FROM hostname_reservations
    WHERE application_name IS NOT NULL
      AND TRIM(application_name) <> ''
    GROUP BY
        application_name,
        application_abbreviation
    ORDER BY application_name
")->fetchAll(
    PDO::FETCH_ASSOC
);


/*
|--------------------------------------------------------------------------
| SAVED RESERVATIONS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        r.*,

        u.first_name,
        u.last_name,
        u.email

    FROM hostname_reservations r

    LEFT JOIN users u
        ON u.id = r.generated_by

    ORDER BY
        r.created_at DESC,
        r.id DESC
");

$stmt->execute();

$reservations =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

$page_title =
    'Hostname Generator';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<style>

.hostname-page {
    padding-bottom:50px;
}

.hostname-header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:25px;
}

.hostname-header h1 {
    margin:0;
}

.hostname-header p {
    color:#64748b;
    margin:5px 0 0;
}

.hostname-card {
    background:#fff;
    border:1px solid #e5e7eb;
    border-radius:12px;
    padding:24px;
    margin-bottom:22px;
}

.hostname-card h2 {
    margin-top:0;
    margin-bottom:18px;
}

.hostname-grid {
    display:grid;
    grid-template-columns:
        repeat(3, minmax(0,1fr));
    gap:18px;
}

.hostname-field {
    display:flex;
    flex-direction:column;
    gap:7px;
}

.hostname-field.full {
    grid-column:1/-1;
}

.hostname-field label {
    font-weight:600;
    font-size:14px;
}

.hostname-field input,
.hostname-field select {
    width:100%;
    box-sizing:border-box;
    border:1px solid #d1d5db;
    border-radius:7px;
    padding:10px 12px;
    font:inherit;
}

.hostname-field small {
    color:#64748b;
}

.hostname-preview {
    margin-top:20px;
    background:#0f172a;
    color:#fff;
    border-radius:10px;
    padding:20px;
}

.hostname-preview-title {
    color:#94a3b8;
    font-size:12px;
    text-transform:uppercase;
    margin-bottom:8px;
}

.hostname-preview-list {
    display:flex;
    flex-direction:column;
    gap:8px;
    font-family:monospace;
    font-size:18px;
    font-weight:bold;
}

.hostname-preview-item {
    display:flex;
    justify-content:space-between;
    gap:15px;
    padding:10px 12px;
    background:#1e293b;
    border-radius:6px;
}

.hostname-preview-item.available {
    color:#86efac;
}

.hostname-preview-item.exists {
    color:#fca5a5;
}

.hostname-actions {
    display:flex;
    justify-content:flex-end;
    gap:10px;
    margin-top:20px;
}

.hostname-btn {
    border:0;
    border-radius:7px;
    padding:10px 16px;
    cursor:pointer;
    font-weight:600;
}

.hostname-btn-primary {
    background:#2563eb;
    color:#fff;
}

.hostname-btn-secondary {
    background:#e5e7eb;
    color:#111827;
}

.hostname-btn-danger {
    background:#dc2626;
    color:#fff;
}

.hostname-btn-success {
    background:#059669;
    color:#fff;
}

.hostname-table-wrap {
    overflow-x:auto;
}

.hostname-table {
    width:100%;
    border-collapse:collapse;
}

.hostname-table th,
.hostname-table td {
    padding:11px;
    border-bottom:1px solid #e5e7eb;
    text-align:left;
    vertical-align:middle;
}

.hostname-table th {
    font-size:12px;
    color:#64748b;
    text-transform:uppercase;
}

.hostname-value {
    font-family:monospace;
    font-weight:bold;
    color:#2563eb;
    white-space:nowrap;
}

.hostname-status {
    display:inline-block;
    padding:5px 9px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    background:#ecfdf5;
    color:#047857;
}

.hostname-row-actions {
    display:flex;
    gap:8px;
}

.hostname-row-actions button {
    border:0;
    background:none;
    cursor:pointer;
    color:#2563eb;
    padding:0;
}

.hostname-row-actions .delete {
    color:#dc2626;
}

.hostname-alert {
    padding:12px 15px;
    border-radius:8px;
    margin-bottom:20px;
}

.hostname-alert.success {
    background:#ecfdf5;
    color:#047857;
    border:1px solid #a7f3d0;
}

.hostname-alert.error {
    background:#fef2f2;
    color:#b91c1c;
    border:1px solid #fecaca;
}

.hostname-code-table {
    width:100%;
    border-collapse:collapse;
}

.hostname-code-table th,
.hostname-code-table td {
    padding:10px;
    border-bottom:1px solid #e5e7eb;
    text-align:left;
}

.hostname-code-input {
    width:90px;
    text-align:center;
    font-family:monospace;
    font-weight:bold;
    text-transform:uppercase;
    border:1px solid #d1d5db;
    border-radius:6px;
    padding:7px;
}

.hostname-section-title {
    margin-top:30px;
    margin-bottom:12px;
    font-size:18px;
}

@media(max-width:1000px) {

    .hostname-grid {
        grid-template-columns:
            repeat(2,minmax(0,1fr));
    }
}

@media(max-width:700px) {

    .hostname-grid {
        grid-template-columns:1fr;
    }

    .hostname-header {
        flex-direction:column;
        align-items:stretch;
    }

    .hostname-actions {
        flex-direction:column;
    }

    .hostname-btn {
        width:100%;
    }
}

</style>


<div class="content hostname-page">


<?php if ($success_msg): ?>

    <div class="hostname-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="hostname-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<div class="hostname-header">

    <div>

        <h1>
            Hostname Generator
        </h1>

        <p>
            Generate, validate and reserve infrastructure hostnames.
        </p>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| GENERATOR
|--------------------------------------------------------------------------
-->

<div class="hostname-card">

    <h2>
        Generate Hostnames
    </h2>


    <form
        id="hostnameGeneratorForm"
        method="POST"
        action="hostname.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h($csrf_token) ?>"
        >

        <input
            type="hidden"
            name="form_action"
            value="save_reservations"
        >


        <div class="hostname-grid">


            <!-- PLATFORM -->

            <div class="hostname-field">

                <label>
                    Platform *
                </label>

                <select
                    id="platform_key"
                    name="platform_key"
                    required
                >

                    <option value="">
                        Select Platform
                    </option>

                    <?php foreach (
                        $platform_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >

                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>

                            —

                            <?= h(
                                $code['code_value']
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

                <small>
                    Platform code is exactly 3 characters.
                </small>

            </div>


            <!-- ENVIRONMENT -->

            <div class="hostname-field">

                <label>
                    Environment *
                </label>

                <select
                    id="environment_key"
                    name="environment_key"
                    required
                >

                    <option value="">
                        Select Environment
                    </option>

                    <?php foreach (
                        $environment_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >

                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>

                            —

                            <?= h(
                                $code['code_value']
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- OS -->

            <div class="hostname-field">

                <label>
                    Operating System *
                </label>

                <select
                    id="os_key"
                    name="os_key"
                    required
                >

                    <option value="">
                        Select OS
                    </option>

                    <?php foreach (
                        $os_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >

                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>

                            —

                            <?= h(
                                $code['code_value']
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- PHYSICAL / VIRTUAL -->

            <div class="hostname-field">

                <label>
                    Infrastructure Type *
                </label>

                <select
                    id="physical_virtual"
                    name="physical_virtual"
                    required
                >

                    <option value="">
                        Select
                    </option>

                    <option value="P">
                        Physical — P
                    </option>

                    <option value="V">
                        Virtual — V
                    </option>

                </select>

            </div>


            <!-- PROJECT -->

            <div class="hostname-field">

                <label>
                    Project Name
                </label>

                <input
                    type="text"
                    id="project_name"
                    name="project_name"
                    list="projectSuggestions"
                    placeholder="Full project name"
                >

                <datalist id="projectSuggestions">

                    <?php foreach (
                        $project_suggestions
                        as $project
                    ): ?>

                        <option
                            value="<?= h(
                                $project['project_name']
                            ) ?>"
                        >

                    <?php endforeach; ?>

                </datalist>

            </div>


            <!-- PROJECT CODE -->

            <div class="hostname-field">

                <label>
                    Project Code
                </label>

                <input
                    type="text"
                    id="project_code"
                    name="project_code"
                    placeholder="Separate project code"
                >

                <small>
                    Stored separately from the 3-character hostname abbreviation.
                </small>

            </div>


            <!-- PROJECT ABBREVIATION -->

            <div class="hostname-field">

                <label>
                    Project Abbreviation *
                </label>

                <input
                    type="text"
                    id="project_abbreviation"
                    name="project_abbreviation"
                    maxlength="3"
                    minlength="3"
                    pattern="[A-Za-z0-9]{3}"
                    required
                    placeholder="ABC"
                >

                <small>
                    Automatically suggested from project name.
                </small>

            </div>


            <!-- APPLICATION -->

            <div class="hostname-field">

                <label>
                    Application Name
                </label>

                <input
                    type="text"
                    id="application_name"
                    name="application_name"
                    list="applicationSuggestions"
                    placeholder="Full application name"
                >

                <datalist id="applicationSuggestions">

                    <?php foreach (
                        $application_suggestions
                        as $application
                    ): ?>

                        <option
                            value="<?= h(
                                $application[
                                    'application_name'
                                ]
                            ) ?>"
                        >

                    <?php endforeach; ?>

                </datalist>

            </div>


            <!-- APPLICATION ABBREVIATION -->

            <div class="hostname-field">

                <label>
                    Application Abbreviation *
                </label>

                <input
                    type="text"
                    id="application_abbreviation"
                    name="application_abbreviation"
                    maxlength="3"
                    minlength="3"
                    pattern="[A-Za-z0-9]{3}"
                    required
                    placeholder="APP"
                >

                <small>
                    Suggested automatically. User can customize it.
                </small>

            </div>


            <!-- APPLICATION COUNT -->

            <div class="hostname-field">

                <label>
                    Number of Applications
                </label>

                <input
                    type="number"
                    id="application_count"
                    min="1"
                    max="100"
                    value="1"
                >

                <small>
                    Generate separate application groups.
                </small>

            </div>


            <!-- NODES -->

            <div class="hostname-field">

                <label>
                    Nodes per Application
                </label>

                <input
                    type="number"
                    id="nodes_per_application"
                    min="1"
                    max="99"
                    value="1"
                >

                <small>
                    Example: 2 nodes = 01, 02.
                </small>

            </div>


            <!-- START NODE -->

            <div class="hostname-field">

                <label>
                    Starting Node Number
                </label>

                <input
                    type="number"
                    id="starting_node"
                    min="1"
                    max="99"
                    value="1"
                >

            </div>


        </div>


        <!-- PREVIEW -->

        <div class="hostname-preview">

            <div class="hostname-preview-title">
                Generated Preview
            </div>

            <div
                id="hostnamePreview"
                class="hostname-preview-list"
            >

                <div>
                    Select the required options.
                </div>

            </div>

        </div>


        <!-- Hidden generated hostname fields -->

        <div id="generatedHostnameInputs"></div>


        <div class="hostname-actions">

            <button
                type="button"
                class="hostname-btn hostname-btn-secondary"
                id="generateButton"
            >
                Generate
            </button>

            <button
                type="button"
                class="hostname-btn hostname-btn-success"
                id="saveButton"
            >
                Save Reservations
            </button>

        </div>

    </form>

</div>


<!--
|--------------------------------------------------------------------------
| SAVED RESERVATIONS
|--------------------------------------------------------------------------
-->

<div class="hostname-card">

    <h2>
        Reserved Hostnames
    </h2>


    <div class="hostname-table-wrap">

        <table class="hostname-table">

            <thead>

                <tr>

                    <th>Hostname</th>
                    <th>Platform</th>
                    <th>Environment</th>
                    <th>OS</th>
                    <th>Type</th>
                    <th>Project</th>
                    <th>Project Code</th>
                    <th>Application</th>
                    <th>Node</th>
                    <th>Status</th>
                    <th>Reserved By</th>
                    <th>Actions</th>

                </tr>

            </thead>

            <tbody>

            <?php if (
                !$reservations
            ): ?>

                <tr>

                    <td
                        colspan="12"
                        style="text-align:center;padding:35px;"
                    >
                        No hostname reservations yet.
                    </td>

                </tr>

            <?php endif; ?>


            <?php foreach (
                $reservations
                as $reservation
            ): ?>

                <tr>

                    <td>

                        <span class="hostname-value">

                            <?= h(
                                $reservation[
                                    'hostname'
                                ]
                            ) ?>

                        </span>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'platform_code'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'environment_code'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'os_code'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'physical_virtual'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'project_name'
                            ]
                            ?: '—'
                        ) ?>

                        <?php if (
                            $reservation[
                                'project_abbreviation'
                            ]
                        ): ?>

                            <br>

                            <small>

                                <?= h(
                                    $reservation[
                                        'project_abbreviation'
                                    ]
                                ) ?>

                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'project_code'
                            ]
                            ?: '—'
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'application_name'
                            ]
                            ?: '—'
                        ) ?>

                        <?php if (
                            $reservation[
                                'application_abbreviation'
                            ]
                        ): ?>

                            <br>

                            <small>

                                <?= h(
                                    $reservation[
                                        'application_abbreviation'
                                    ]
                                ) ?>

                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= sprintf(
                            '%02d',
                            (int)$reservation[
                                'node_number'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <span
                            class="hostname-status"
                        >
                            <?= h(
                                $reservation[
                                    'status'
                                ]
                            ) ?>
                        </span>

                    </td>


                    <td>

                        <?= h(
                            trim(
                                ($reservation[
                                    'first_name'
                                ] ?? '')
                                . ' '
                                . ($reservation[
                                    'last_name'
                                ] ?? '')
                            )
                        ) ?>

                    </td>


                    <td>

                        <?php if (
                            $is_admin ||
                            (int)$reservation[
                                'generated_by'
                            ]
                            === $current_user_id
                        ): ?>

                            <div
                                class="hostname-row-actions"
                            >

                                <button
                                    type="button"
                                    onclick='editReservation(
                                        <?= json_encode(
                                            $reservation,
                                            JSON_HEX_TAG |
                                            JSON_HEX_APOS |
                                            JSON_HEX_QUOT |
                                            JSON_HEX_AMP
                                        ) ?>
                                    )'
                                >
                                    Edit
                                </button>


                                <form
                                    method="POST"
                                    action="hostname.php"
                                    style="display:inline;"
                                    onsubmit="return confirm('Delete this hostname reservation?');"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h(
                                            $csrf_token
                                        ) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="form_action"
                                        value="delete_reservation"
                                    >

                                    <input
                                        type="hidden"
                                        name="reservation_id"
                                        value="<?= (int)$reservation['id'] ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="delete"
                                    >
                                        Delete
                                    </button>

                                </form>

                            </div>

                        <?php endif; ?>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| ADMIN CODE MANAGEMENT
|--------------------------------------------------------------------------
-->

<?php if ($is_admin): ?>

<div class="hostname-card">

    <h2>
        Hostname Code Administration
    </h2>

    <p>
        Only administrators can modify these codes.
        Platform codes must be exactly 3 characters.
        Environment and OS codes must be exactly 1 character.
    </p>


    <h3 class="hostname-section-title">
        Platform Codes
    </h3>


    <div class="hostname-table-wrap">

        <table class="hostname-code-table">

            <thead>

                <tr>
                    <th>Platform</th>
                    <th>Code</th>
                    <th>Action</th>
                </tr>

            </thead>

            <tbody>

            <?php foreach (
                $platform_codes
                as $code
            ): ?>

                <tr>

                    <td>
                        <?= h(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $code['code_key']
                                )
                            )
                        ) ?>
                    </td>

                    <td>

                        <form
                            method="POST"
                            action="hostname.php"
                            style="display:flex;gap:8px;"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h(
                                    $csrf_token
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="form_action"
                                value="update_code"
                            >

                            <input
                                type="hidden"
                                name="code_id"
                                value="<?= (int)$code['id'] ?>"
                            >

                            <input
                                class="hostname-code-input"
                                type="text"
                                name="code_value"
                                maxlength="3"
                                minlength="3"
                                pattern="[A-Za-z0-9]{3}"
                                value="<?= h(
                                    $code['code_value']
                                ) ?>"
                                required
                            >

                            <button
                                type="submit"
                                class="hostname-btn hostname-btn-primary"
                            >
                                Save
                            </button>

                        </form>

                    </td>

                    <td>
                        Admin only
                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    </div>


    <h3 class="hostname-section-title">
        Environment Codes
    </h3>


    <div class="hostname-table-wrap">

        <table class="hostname-code-table">

            <thead>

                <tr>
                    <th>Environment</th>
                    <th>Code</th>
                    <th>Action</th>
                </tr>

            </thead>

            <tbody>

            <?php foreach (
                $environment_codes
                as $code
            ): ?>

                <tr>

                    <td>
                        <?= h(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $code['code_key']
                                )
                            )
                        ) ?>
                    </td>

                    <td>

                        <form
                            method="POST"
                            action="hostname.php"
                            style="display:flex;gap:8px;"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h(
                                    $csrf_token
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="form_action"
                                value="update_code"
                            >

                            <input
                                type="hidden"
                                name="code_id"
                                value="<?= (int)$code['id'] ?>"
                            >

                            <input
                                class="hostname-code-input"
                                type="text"
                                name="code_value"
                                maxlength="1"
                                minlength="1"
                                pattern="[A-Za-z0-9]"
                                value="<?= h(
                                    $code['code_value']
                                ) ?>"
                                required
                            >

                            <button
                                type="submit"
                                class="hostname-btn hostname-btn-primary"
                            >
                                Save
                            </button>

                        </form>

                    </td>

                    <td>
                        Admin only
                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    </div>


    <h3 class="hostname-section-title">
        Operating System Codes
    </h3>


    <div class="hostname-table-wrap">

        <table class="hostname-code-table">

            <thead>

                <tr>
                    <th>Operating System</th>
                    <th>Code</th>
                    <th>Action</th>
                </tr>

            </thead>

            <tbody>

            <?php foreach (
                $os_codes
                as $code
            ): ?>

                <tr>

                    <td>
                        <?= h(
                            ucwords(
                                str_replace(
                                    '_',
                                    ' ',
                                    $code['code_key']
                                )
                            )
                        ) ?>
                    </td>

                    <td>

                        <form
                            method="POST"
                            action="hostname.php"
                            style="display:flex;gap:8px;"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= h(
                                    $csrf_token
                                ) ?>"
                            >

                            <input
                                type="hidden"
                                name="form_action"
                                value="update_code"
                            >

                            <input
                                type="hidden"
                                name="code_id"
                                value="<?= (int)$code['id'] ?>"
                            >

                            <input
                                class="hostname-code-input"
                                type="text"
                                name="code_value"
                                maxlength="1"
                                minlength="1"
                                pattern="[A-Za-z0-9]"
                                value="<?= h(
                                    $code['code_value']
                                ) ?>"
                                required
                            >

                            <button
                                type="submit"
                                class="hostname-btn hostname-btn-primary"
                            >
                                Save
                            </button>

                        </form>

                    </td>

                    <td>
                        Admin only
                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    </div>

</div>

<?php endif; ?>


</div>


<!--
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
-->

<div
    id="editModal"
    style="
        display:none;
        position:fixed;
        inset:0;
        background:rgba(0,0,0,.55);
        z-index:9999;
        padding:30px;
        overflow:auto;
    "
>

    <div
        style="
            background:#fff;
            max-width:650px;
            margin:50px auto;
            border-radius:12px;
            padding:25px;
        "
    >

        <h2>
            Edit Hostname Reservation
        </h2>


        <form
            method="POST"
            action="hostname.php"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(
                    $csrf_token
                ) ?>"
            >

            <input
                type="hidden"
                name="form_action"
                value="update_reservation"
            >

            <input
                type="hidden"
                name="reservation_id"
                id="edit_reservation_id"
            >


            <div class="hostname-grid">

                <div class="hostname-field full">

                    <label>
                        Hostname
                    </label>

                    <input
                        type="text"
                        id="edit_hostname"
                        readonly
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Name
                    </label>

                    <input
                        type="text"
                        name="project_name"
                        id="edit_project_name"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Code
                    </label>

                    <input
                        type="text"
                        name="project_code"
                        id="edit_project_code"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Abbreviation
                    </label>

                    <input
                        type="text"
                        name="project_abbreviation"
                        id="edit_project_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        required
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Application Name
                    </label>

                    <input
                        type="text"
                        name="application_name"
                        id="edit_application_name"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Application Abbreviation
                    </label>

                    <input
                        type="text"
                        name="application_abbreviation"
                        id="edit_application_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        required
                    >

                </div>

            </div>


            <div class="hostname-actions">

                <button
                    type="button"
                    class="hostname-btn hostname-btn-secondary"
                    onclick="closeEditModal()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="hostname-btn hostname-btn-primary"
                >
                    Save Changes
                </button>

            </div>

        </form>

    </div>

</div>


<script>

/*
|--------------------------------------------------------------------------
| CODE DATA
|--------------------------------------------------------------------------
*/

const platformCodes =
    <?= json_encode(
        $platform_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;

const environmentCodes =
    <?= json_encode(
        $environment_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;

const osCodes =
    <?= json_encode(
        $os_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;


/*
|--------------------------------------------------------------------------
| ELEMENTS
|--------------------------------------------------------------------------
*/

const platformSelect =
    document.getElementById(
        'platform_key'
    );

const environmentSelect =
    document.getElementById(
        'environment_key'
    );

const osSelect =
    document.getElementById(
        'os_key'
    );

const physicalVirtual =
    document.getElementById(
        'physical_virtual'
    );

const projectName =
    document.getElementById(
        'project_name'
    );

const projectAbbreviation =
    document.getElementById(
        'project_abbreviation'
    );

const applicationName =
    document.getElementById(
        'application_name'
    );

const applicationAbbreviation =
    document.getElementById(
        'application_abbreviation'
    );

const applicationCount =
    document.getElementById(
        'application_count'
    );

const nodesPerApplication =
    document.getElementById(
        'nodes_per_application'
    );

const startingNode =
    document.getElementById(
        'starting_node'
    );

const preview =
    document.getElementById(
        'hostnamePreview'
    );

const hiddenInputs =
    document.getElementById(
        'generatedHostnameInputs'
    );


/*
|--------------------------------------------------------------------------
| SUGGEST PROJECT ABBREVIATION
|--------------------------------------------------------------------------
*/

let projectAbbreviationManuallyChanged =
    false;

projectAbbreviation.addEventListener(
    'input',
    function() {

        if (
            this.value !== ''
        ) {
            projectAbbreviationManuallyChanged =
                true;
        }

        this.value =
            this.value
                .toUpperCase()
                .replace(
                    /[^A-Z0-9]/g,
                    ''
                )
                .substring(
                    0,
                    3
                );

        generatePreview();
    }
);


projectName.addEventListener(
    'input',
    function() {

        if (
            !projectAbbreviationManuallyChanged
        ) {

            projectAbbreviation.value =
                makeAbbreviation(
                    this.value
                );
        }

        generatePreview();
    }
);


/*
|--------------------------------------------------------------------------
| SUGGEST APPLICATION ABBREVIATION
|--------------------------------------------------------------------------
*/

let applicationAbbreviationManuallyChanged =
    false;

applicationAbbreviation.addEventListener(
    'input',
    function() {

        applicationAbbreviationManuallyChanged =
            true;

        this.value =
            this.value
                .toUpperCase()
                .replace(
                    /[^A-Z0-9]/g,
                    ''
                )
                .substring(
                    0,
                    3
                );

        generatePreview();
    }
);


applicationName.addEventListener(
    'input',
    function() {

        if (
            !applicationAbbreviationManuallyChanged
        ) {

            applicationAbbreviation.value =
                makeAbbreviation(
                    this.value
                );
        }

        generatePreview();
    }
);


/*
|--------------------------------------------------------------------------
| ABBREVIATION
|--------------------------------------------------------------------------
*/

function makeAbbreviation(
    name
) {

    name =
        name
            .trim();

    if (!name) {
        return '';
    }

    const words =
        name
            .split(/\s+/)
            .filter(Boolean);

    let result = '';

    words.forEach(
        function(word) {

            if (
                result.length >= 3
            ) {
                return;
            }

            word =
                word
                    .replace(
                        /[^A-Za-z0-9]/g,
                        ''
                    );

            if (word) {

                result +=
                    word
                        .charAt(0)
                        .toUpperCase();
            }
        }
    );


    /*
    |--------------------------------------------------------------------------
    | Fill remaining characters
    |--------------------------------------------------------------------------
    */

    const compact =
        name
            .replace(
                /[^A-Za-z0-9]/g,
                ''
            )
            .toUpperCase();


    for (
        let i = 0;
        i < compact.length &&
        result.length < 3;
        i++
    ) {

        if (
            !result.includes(
                compact.charAt(i)
            )
        ) {

            result +=
                compact.charAt(i);
        }
    }

    return result.substring(
        0,
        3
    );
}


/*
|--------------------------------------------------------------------------
| GET CODE
|--------------------------------------------------------------------------
*/

function getCode(
    collection,
    key
) {

    return collection.find(
        function(item) {
            return item.code_key === key;
        }
    );
}


/*
|--------------------------------------------------------------------------
| BUILD HOSTNAME
|--------------------------------------------------------------------------
*/

function buildHostname(
    platform,
    environment,
    os,
    pv,
    project,
    application,
    node
) {

    const nodeCode =
        String(node)
            .padStart(
                2,
                '0'
            );

    return (
        platform +
        environment +
        os +
        pv +
        project +
        application +
        nodeCode
    )
        .toUpperCase();
}


/*
|--------------------------------------------------------------------------
| GENERATE PREVIEW
|--------------------------------------------------------------------------
*/

function generatePreview() {

    preview.innerHTML = '';

    hiddenInputs.innerHTML = '';


    const platform =
        getCode(
            platformCodes,
            platformSelect.value
        );

    const environment =
        getCode(
            environmentCodes,
            environmentSelect.value
        );

    const os =
        getCode(
            osCodes,
            osSelect.value
        );


    const pv =
        physicalVirtual.value;

    const project =
        projectAbbreviation.value
            .toUpperCase();

    const application =
        applicationAbbreviation.value
            .toUpperCase();


    const appCount =
        Math.max(
            1,
            parseInt(
                applicationCount.value
            ) || 1
        );

    const nodeCount =
        Math.max(
            1,
            parseInt(
                nodesPerApplication.value
            ) || 1
        );

    const startNode =
        Math.max(
            1,
            parseInt(
                startingNode.value
            ) || 1
        );


    if (
        !platform ||
        !environment ||
        !os ||
        !pv ||
        project.length !== 3 ||
        application.length !== 3
    ) {

        preview.innerHTML =
            '<div>Select the required options.</div>';

        return;
    }


    let total =
        appCount *
        nodeCount;


    if (total > 100) {

        preview.innerHTML =
            '<div style="color:#fca5a5;">Maximum 100 hostnames per generation.</div>';

        return;
    }


    let node =
        startNode;


    for (
        let appIndex = 0;
        appIndex < appCount;
        appIndex++
    ) {

        /*
        |--------------------------------------------------------------------------
        | For multiple applications:
        |
        | APP1 uses the entered abbreviation.
        | APP2+ receive sequential variations.
        |
        | Example:
        |
        | PAY01
        | PAY02
        | PAY03
        |
        | If 2 application groups:
        |
        | PAY01
        | PAY02
        | PAY03
        |
        | The user can later edit the reservation.
        |--------------------------------------------------------------------------
        */

        let currentApplication =
            application;


        if (
            appIndex > 0
        ) {

            currentApplication =
                generateApplicationCode(
                    application,
                    appIndex
                );
        }


        for (
            let n = 0;
            n < nodeCount;
            n++
        ) {

            const hostname =
                buildHostname(
                    platform.code_value,
                    environment.code_value,
                    os.code_value,
                    pv,
                    project,
                    currentApplication,
                    node
                );


            const row =
                document.createElement(
                    'div'
                );

            row.className =
                'hostname-preview-item';


            const hostnameSpan =
                document.createElement(
                    'span'
                );

            hostnameSpan.textContent =
                hostname;


            const nodeSpan =
                document.createElement(
                    'span'
                );

            nodeSpan.textContent =
                'Node ' +
                String(node)
                    .padStart(
                        2,
                        '0'
                    );


            row.appendChild(
                hostnameSpan
            );

            row.appendChild(
                nodeSpan
            );


            preview.appendChild(
                row
            );


            const hidden =
                document.createElement(
                    'input'
                );

            hidden.type =
                'hidden';

            hidden.name =
                'hostname[]';

            hidden.value =
                hostname;

            hiddenInputs.appendChild(
                hidden
            );


            node++;
        }
    }
}


/*
|--------------------------------------------------------------------------
| MULTI-APPLICATION CODE
|--------------------------------------------------------------------------
|
| We keep exactly 3 characters.
|
| Example:
|
| APP
| AP2
| AP3
| ...
|
*/

function generateApplicationCode(
    base,
    index
) {

    base =
        base
            .toUpperCase()
            .replace(
                /[^A-Z0-9]/g,
                ''
            )
            .substring(
                0,
                3
            );


    const suffix =
        String(index + 1);


    if (
        base.length >= 2
    ) {

        return (
            base.substring(
                0,
                2
            ) +
            suffix
        )
            .substring(
                0,
                3
            );
    }


    return (
        (base + suffix + 'X')
            .substring(
                0,
                3
            )
    );
}


/*
|--------------------------------------------------------------------------
| GENERATE BUTTON
|--------------------------------------------------------------------------
*/

document
    .getElementById(
        'generateButton'
    )
    .addEventListener(
        'click',
        generatePreview
    );


/*
|--------------------------------------------------------------------------
| SAVE BUTTON
|--------------------------------------------------------------------------
*/

document
    .getElementById(
        'saveButton'
    )
    .addEventListener(
        'click',
        function() {

            generatePreview();

            const hostnames =
                document.querySelectorAll(
                    'input[name="hostname[]"]'
                );


            if (
                !hostnames.length
            ) {

                alert(
                    'Please generate at least one hostname first.'
                );

                return;
            }


            if (
                !projectAbbreviation.value ||
                projectAbbreviation.value.length !== 3
            ) {

                alert(
                    'Project abbreviation must be exactly 3 characters.'
                );

                return;
            }


            if (
                !applicationAbbreviation.value ||
                applicationAbbreviation.value.length !== 3
            ) {

                alert(
                    'Application abbreviation must be exactly 3 characters.'
                );

                return;
            }


            if (
                !confirm(
                    'Save all generated hostnames as reservations?'
                )
            ) {
                return;
            }


            document
                .getElementById(
                    'hostnameGeneratorForm'
                )
                .submit();
        }
    );


/*
|--------------------------------------------------------------------------
| LIVE PREVIEW
|--------------------------------------------------------------------------
*/

[
    platformSelect,
    environmentSelect,
    osSelect,
    physicalVirtual,
    applicationCount,
    nodesPerApplication,
    startingNode
]
.forEach(
    function(element) {

        element.addEventListener(
            'change',
            generatePreview
        );

        element.addEventListener(
            'input',
            generatePreview
        );
    }
);


/*
|--------------------------------------------------------------------------
| EDIT RESERVATION
|--------------------------------------------------------------------------
*/

function editReservation(
    reservation
) {

    document
        .getElementById(
            'edit_reservation_id'
        )
        .value =
        reservation.id;


    document
        .getElementById(
            'edit_hostname'
        )
        .value =
        reservation.hostname;


    document
        .getElementById(
            'edit_project_name'
        )
        .value =
        reservation.project_name || '';


    document
        .getElementById(
            'edit_project_code'
        )
        .value =
        reservation.project_code || '';


    document
        .getElementById(
            'edit_project_abbreviation'
        )
        .value =
        reservation.project_abbreviation || '';


    document
        .getElementById(
            'edit_application_name'
        )
        .value =
        reservation.application_name || '';


    document
        .getElementById(
            'edit_application_abbreviation'
        )
        .value =
        reservation.application_abbreviation || '';


    document
        .getElementById(
            'editModal'
        )
        .style.display =
        'block';
}


function closeEditModal() {

    document
        .getElementById(
            'editModal'
        )
        .style.display =
        'none';
}


document
    .getElementById(
        'editModal'
    )
    .addEventListener(
        'click',
        function(event) {

            if (
                event.target === this
            ) {

                closeEditModal();
            }
        }
    );


/*
|--------------------------------------------------------------------------
| INITIAL PREVIEW
|--------------------------------------------------------------------------
*/

generatePreview();

</script>


<?php

require_once 'includes/footer.php';

?>
