<?php

session_start();

require_once __DIR__ . '/config/db.php';


/*
|--------------------------------------------------------------------------
| ADMIN ONLY ACCESS
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION['user_id']) ||
    !isset($_SESSION['role']) ||
    $_SESSION['role'] !== 'Admin'
) {

    header("Location: home.php");
    exit;

}



$msg = "";
$error = "";



/*
|--------------------------------------------------------------------------
| HANDLE ADMIN ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {


    $action =
        $_POST['action'] ?? "";


    $target_id =
        $_POST['user_id'] ?? "";



    if ($target_id) {


        $query =
            $pdo->prepare(
                "SELECT *
                 FROM users
                 WHERE id=?"
            );


        $query->execute([
            $target_id
        ]);


        $target =
            $query->fetch(PDO::FETCH_ASSOC);



        if (!$target) {


            $error =
            "User not found.";


        } else {



            /*
            --------------------------------------
            APPROVE USER
            --------------------------------------
            */


            if ($action === "approve") {


                $role =
                    $_POST['role'] ?? "Read-only";


                $team =
                    $_POST['team'] ?? "";



                if ($target['ncgr_id'] === "ADMIN001") {

                    $role = "Admin";
                    $team = "Linux";

                }



                $stmt =
                    $pdo->prepare(
                        "UPDATE users
                         SET
                         is_approved=1,
                         role=?,
                         team=?
                         WHERE id=?"
                    );



                $stmt->execute([
                    $role,
                    $team,
                    $target_id
                ]);



                $msg =
                "User approved successfully.";

            }



            /*
            --------------------------------------
            UPDATE DETAILS
            --------------------------------------
            */


            elseif ($action === "update_details") {


                $role =
                    $_POST['role'] ?? "Read-only";


                $team =
                    $_POST['team'] ?? "";



                /*
                Protect primary admin
                */

                if ($target['ncgr_id'] === "ADMIN001") {

                    $role = "Admin";
                    $team = "Linux";

                }



                $stmt =
                    $pdo->prepare(
                        "UPDATE users
                         SET role=?,
                             team=?
                         WHERE id=?"
                    );


                $stmt->execute([
                    $role,
                    $team,
                    $target_id
                ]);



                $msg =
                "User details updated.";

            }





            /*
            --------------------------------------
            FORCE PASSWORD RESET
            --------------------------------------
            */
	    elseif ($action === "force_password_change") {


    // Generate random password
    $new_password = bin2hex(random_bytes(5));


    // Hash password before saving
    $password_hash =
        password_hash(
            $new_password,
            PASSWORD_DEFAULT
        );



    $stmt =
        $pdo->prepare(
            "UPDATE users
             SET password=?
             WHERE id=?"
        );



    $stmt->execute([
        $password_hash,
        $target_id
    ]);



    $msg =
    "Password reset successfully. New password: "
    . $new_password;


}
/*

            --------------------------------------
            DEACTIVATE
            --------------------------------------
            */


            elseif ($action === "deactivate") {



                if ($target['ncgr_id'] === "ADMIN001") {


                    $error =
                    "ADMIN001 cannot be deactivated.";


                } else {



                    $stmt =
                    $pdo->prepare(
                        "UPDATE users
                         SET is_approved=0
                         WHERE id=?"
                    );



                    $stmt->execute([
                        $target_id
                    ]);



                    $msg =
                    "User deactivated.";

                }


            }





            /*
            --------------------------------------
            DELETE
            --------------------------------------
            */


            elseif ($action === "delete") {



                if (
                    $target_id == $_SESSION['user_id']
                    ||
                    $target['ncgr_id'] === "ADMIN001"
                ) {


                    $error =
                    "Administrator account cannot be deleted.";


                } else {


                    $stmt =
                    $pdo->prepare(
                        "DELETE FROM users
                         WHERE id=?"
                    );


                    $stmt->execute([
                        $target_id
                    ]);



                    $msg =
                    "User deleted.";

                }


            }


        }


    }


}





/*
|--------------------------------------------------------------------------
| FETCH USERS
|--------------------------------------------------------------------------
*/


$pending_users =
$pdo->query(
    "SELECT *
     FROM users
     WHERE is_approved=0
     ORDER BY id DESC"
)
->fetchAll(PDO::FETCH_ASSOC);



$approved_users =
$pdo->query(
    "SELECT *
     FROM users
     WHERE is_approved=1
     ORDER BY id DESC"
)
->fetchAll(PDO::FETCH_ASSOC);




$total_users =
count($approved_users);



$total_pending =
count($pending_users);



$total_admins =
$pdo->query(
    "SELECT COUNT(*)
     FROM users
     WHERE role='Admin'
     AND is_approved=1"
)
->fetchColumn();



$total_editors =
$pdo->query(
    "SELECT COUNT(*)
     FROM users
     WHERE role='Edit'
     AND is_approved=1"
)
->fetchColumn();



/*
|--------------------------------------------------------------------------
| COMMON LAYOUT
|--------------------------------------------------------------------------
*/


require_once __DIR__ . '/includes/header.php';

require_once __DIR__ . '/includes/sidebar.php';

?>


<div class="content">


<div class="page-title">


<div>

<h1>
User Management
</h1>

<link rel="stylesheet" href="assets/css/users.css">
<p>
Manage user accounts, roles and permissions
</p>


</div>


</div>



<?php if($msg): ?>

<div class="alert alert-success">

<?= htmlspecialchars($msg) ?>

</div>

<?php endif; ?>



<?php if($error): ?>

<div class="alert alert-error">

<?= htmlspecialchars($error) ?>

</div>

<?php endif; ?>





<div class="user-stats">


<div class="dashboard-card">

<div>

<span>
Active Users
</span>

<h2>
<?= $total_users ?>
</h2>

</div>

</div>



<div class="dashboard-card">

<div>

<span>
Pending
</span>

<h2>
<?= $total_pending ?>
</h2>

</div>

</div>



<div class="dashboard-card">

<div>

<span>
Admins
</span>

<h2>
<?= $total_admins ?>
</h2>

</div>

</div>



<div class="dashboard-card">

<div>

<span>
Editors
</span>

<h2>
<?= $total_editors ?>
</h2>

</div>

</div>



</div>





<section class="admin-card">


<div class="card-header">

<h2>
Pending Approvals
</h2>

</div>


<div class="table-responsive">


<table class="admin-table">


<thead>

<tr>

<th>User</th>
<th>NCGR ID</th>
<th>Team</th>
<th>Role</th>
<th>Action</th>

</tr>

</thead>


<tbody>



<?php foreach($pending_users as $user): ?>


<tr>


<form method="POST">


<input type="hidden"
name="user_id"
value="<?= $user['id'] ?>">



<td>

<?= htmlspecialchars(
$user['first_name']." ".$user['last_name']
) ?>

</td>


<td>

<?= htmlspecialchars(
$user['ncgr_id']
) ?>

</td>


<td>


<input class="form-control"
name="team"
value="<?= htmlspecialchars($user['team']) ?>">


</td>



<td>


<select name="role"
class="form-control">


<option>
Read-only
</option>

<option>
Edit
</option>

<option>
Admin
</option>


</select>


</td>



<td>


<button
class="btn btn-primary"
name="action"
value="approve">

Approve

</button>



<button
class="btn btn-danger"
name="action"
value="delete">

Reject

</button>


</td>


</form>


</tr>


<?php endforeach; ?>


</tbody>


</table>


</div>


</section>
<section class="admin-card">


<div class="card-header">


<div>

<h2>
Active Users
</h2>

<p>
Manage approved accounts and permissions.
</p>

</div>



<input
type="text"
id="userSearch"
class="form-control search-box"
placeholder="Search users...">


</div>





<div class="table-responsive">


<table class="admin-table"
id="usersTable">


<thead>

<tr>

<th>
User
</th>

<th>
NCGR ID
</th>

<th>
Team
</th>

<th>
Role
</th>

<th>
Actions
</th>

</tr>

</thead>



<tbody>



<?php foreach($approved_users as $user): ?>


<tr>


<form method="POST"
action="users.php">


<input type="hidden"
name="user_id"
value="<?= $user['id'] ?>">



<td>


<div class="user-name">


<strong>

<?= htmlspecialchars(
$user['first_name']." ".$user['last_name']
) ?>

</strong>


<small>

<?= htmlspecialchars(
$user['email']
) ?>

</small>


</div>


</td>




<td>


<?= htmlspecialchars(
$user['ncgr_id']
) ?>



<?php if($user['ncgr_id']==='ADMIN001'): ?>

<br>

<span class="badge badge-admin">

Primary Admin

</span>


<?php endif; ?>


</td>





<td>


<?php if($user['ncgr_id']==='ADMIN001'): ?>


<input type="hidden"
name="team"
value="Linux">


<span class="locked-field">

Linux 🔒

</span>



<?php else: ?>

<select
name="team"
class="form-control">


<option value="Cloud"
<?= $user['team']=="Cloud" ? "selected" : "" ?>>
Cloud
</option>


<option value="Backup and Storage"
<?= $user['team']=="Backup and Storage" ? "selected" : "" ?>>
Backup and Storage
</option>


<option value="DR"
<?= $user['team']=="DR" ? "selected" : "" ?>>
DR
</option>


<option value="Others"
<?= $user['team']=="Others" ? "selected" : "" ?>>
Others
</option>


<option value="Database"
<?= $user['team']=="Database" ? "selected" : "" ?>>
Database
</option>


<option value="AD and Exchange"
<?= $user['team']=="AD and Exchange" ? "selected" : "" ?>>
AD and Exchange
</option>


<option value="Windows"
<?= $user['team']=="Windows" ? "selected" : "" ?>>
Windows
</option>

<option value="Linux and Containers"
<?= $user['team']=="Linux and Containers" ? "selected" : "" ?>>
Linux and Containers
</option>
<option value="PAM"
<?= $user['team']=="PAM" ? "selected" : "" ?>>
PAM
</option>


</select>


<?php endif; ?>
</td>




<td>



<?php if($user['ncgr_id']==='ADMIN001'): ?>


<input type="hidden"
name="role"
value="Admin">



<span class="badge badge-admin">

Admin

</span>



<?php else: ?>



<select
class="form-control"
name="role">


<option value="Read-only"
<?= $user['role']=="Read-only"?'selected':'' ?>>

Read-only

</option>



<option value="Edit"
<?= $user['role']=="Edit"?'selected':'' ?>>

Edit

</option>



<option value="Admin"
<?= $user['role']=="Admin"?'selected':'' ?>>

Admin

</option>


</select>



<?php endif; ?>


</td>





<td>


<div class="action-buttons">



<button
class="btn btn-primary"
name="action"
value="update_details">


✏ Update
</button>




<button
class="btn btn-purple"
name="action"
value="force_password_change"
onclick="return confirm('Reset password for this user?')">

🔑 Reset
</button>





<?php if($user['ncgr_id']!=='ADMIN001'): ?>


<button
class="btn btn-warning"
name="action"
value="deactivate"
onclick="return confirm('Deactivate this user?')">

⏸ Disable

</button>




<button
class="btn btn-danger"
name="action"
value="delete"
onclick="return confirm('Delete this user permanently?')">

🗑 Delete

</button>



<?php endif; ?>



</div>


</td>



</form>


</tr>



<?php endforeach; ?>



</tbody>


</table>


</div>


</section>





</div>


<?php


require_once __DIR__ . '/includes/footer.php';


?>





<script>


const search =
document.getElementById("userSearch");



if(search){


search.addEventListener(
"keyup",
function(){



let value =
this.value.toLowerCase();



document
.querySelectorAll("#usersTable tbody tr")
.forEach(function(row){



row.style.display =
row.innerText
.toLowerCase()
.includes(value)
?
""
:
"none";



});



});


}



</script>

