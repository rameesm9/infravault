<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}


$page_title="IP History";


include "includes/header.php";
include "includes/sidebar.php";



$keyword = trim($_GET['keyword'] ?? "");





if($keyword!=""){


$stmt=$pdo->prepare("

SELECT 

h.*,

i.ip_range

FROM ip_ranges_history h

LEFT JOIN ip_ranges i

ON i.id=h.ip_range_id

WHERE 

i.ip_range LIKE ?

OR h.performed_by LIKE ?

OR h.action_type LIKE ?

ORDER BY h.id DESC


");


$search="%".$keyword."%";


$stmt->execute([

$search,
$search,
$search

]);



}else{


$stmt=$pdo->query("

SELECT

h.*,

i.ip_range

FROM ip_ranges_history h

LEFT JOIN ip_ranges i

ON i.id=h.ip_range_id

ORDER BY h.id DESC


");


}



$history=$stmt->fetchAll(PDO::FETCH_ASSOC);



?>


<link rel="stylesheet" href="assets/css/ip.css">



<div class="content">


<div class="ip-page">



<div class="page-header">


<div>

<h1>
IP Address History
</h1>


<p>
Audit trail for IP range changes
</p>


</div>



<a href="ip.php"
class="secondary-btn">

Back to IPAM

</a>


</div>





<div class="ip-toolbar">


<form method="GET">


<input

type="text"

name="keyword"

placeholder="Search IP, User, Action..."

value="<?=htmlspecialchars($keyword)?>"

>


<button class="primary-btn">

Search

</button>


</form>


</div>







<div class="ip-card">


<table class="ip-table">


<thead>

<tr>


<th>
IP Range
</th>


<th>
Action
</th>


<th>
Performed By
</th>


<th>
Details
</th>


<th>
Date
</th>


</tr>


</thead>



<tbody>



<?php if(count($history)): ?>



<?php foreach($history as $h): ?>


<tr>


<td>


<span class="ip-tag">

<?=htmlspecialchars($h['ip_range'] ?? 'Deleted Record')?>

</span>


</td>




<td>


<?php if($h['action_type']=="CREATE"): ?>


<span class="environment"
style="background:#dcfce7;color:#166534">

CREATE

</span>


<?php elseif($h['action_type']=="UPDATE"): ?>


<span class="environment"
style="background:#fef3c7;color:#92400e">

UPDATE

</span>


<?php else: ?>


<span class="environment"
style="background:#fee2e2;color:#991b1b">

DELETE

</span>


<?php endif; ?>


</td>





<td>

<?=htmlspecialchars($h['performed_by'])?>

</td>





<td>

<?=htmlspecialchars($h['details'])?>

</td>





<td>

<?=htmlspecialchars($h['timestamp'])?>

</td>



</tr>


<?php endforeach; ?>



<?php else: ?>


<tr>

<td colspan="5"
class="empty">

No history found

</td>

</tr>


<?php endif; ?>


</tbody>


</table>


</div>



</div>


</div>



<?php include "includes/footer.php"; ?>
