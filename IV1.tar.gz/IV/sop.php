<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect_sop($id = null): void
{
    if ($id !== null) {
        header('Location: sop.php?action=view&id=' . (int) $id);
    } else {
        header('Location: sop.php');
    }

    exit;
}

function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}

/*
|--------------------------------------------------------------------------
| HTML Sanitizer — allows normal SOP formatting while removing
| executable HTML.
|--------------------------------------------------------------------------
*/

function sanitize_sop_html(string $html): string
{
    $allowed_tags = [
        'p', 'br', 'strong', 'b', 'em', 'i', 'u',
        'h1', 'h2', 'h3', 'h4',
        'ul', 'ol', 'li', 'blockquote', 'pre', 'code',
        'table', 'thead', 'tbody', 'tr', 'th', 'td',
        'a', 'img', 'hr'
    ];

    $html = strip_tags($html, '<' . implode('><', $allowed_tags) . '>');

    // Remove event handlers.
    $html = preg_replace('/\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i', '', $html);

    // Remove javascript: URLs.
    $html = preg_replace('/javascript\s*:/i', '', $html);

    // Remove data URLs except images.
    $html = preg_replace_callback(
        '/<img\b([^>]*)>/i',
        function ($match) {
            $attributes = $match[1];

            if (preg_match('/src\s*=\s*["\']\s*data:/i', $attributes)) {
                return '';
            }

            return '<img' . $attributes . '>';
        },
        $html
    );

    return trim($html);
}

/*
|--------------------------------------------------------------------------
| Generate SOP number
|--------------------------------------------------------------------------
*/

function generate_sop_number(PDO $pdo): string
{
    $stmt = $pdo->query("SELECT sop_number FROM sops ORDER BY id DESC LIMIT 1");

    $last = $stmt->fetchColumn();

    if (!$last) {
        return 'SOP-001';
    }

    if (preg_match('/(\d+)$/', $last, $matches)) {
        $number = ((int) $matches[1]) + 1;
        return 'SOP-' . str_pad($number, 3, '0', STR_PAD_LEFT);
    }

    return 'SOP-001';
}

/*
|--------------------------------------------------------------------------
| User name
|--------------------------------------------------------------------------
*/

function get_user_name(PDO $pdo, int $user_id): string
{
    if ($user_id <= 0) {
        return 'Unassigned';
    }

    $stmt = $pdo->prepare("SELECT first_name, last_name FROM users WHERE id = ? LIMIT 1");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return 'Unknown User';
    }

    return trim($user['first_name'] . ' ' . $user['last_name']);
}

/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

function can_edit_sop(array $sop, int $user_id, bool $is_admin): bool
{
    return $is_admin || ((int) $sop['owner_id'] === $user_id);
}

function can_delete_sop(array $sop, int $user_id, bool $is_admin): bool
{
    return $is_admin || ((int) $sop['owner_id'] === $user_id);
}

/*
|--------------------------------------------------------------------------
| Attachment upload (shared by create + edit)
|--------------------------------------------------------------------------
*/

function process_sop_attachments(PDO $pdo, string $upload_dir_fs, int $sop_id, int $uploader_id): void
{
    if (empty($_FILES['attachments']) || empty($_FILES['attachments']['name'][0])) {
        return;
    }

    if (!is_dir($upload_dir_fs)) {
        mkdir($upload_dir_fs, 0755, true);
    }

    $allowed_exts = [
        'pdf', 'doc', 'docx', 'dot', 'dotx', 'docm',
        'xls', 'xlsx', 'xlsm', 'csv',
        'ppt', 'pptx', 'pptm',
        'png', 'jpg', 'jpeg', 'gif', 'webp',
        'txt', 'zip', 'rar', '7z'
    ];

    $count = count($_FILES['attachments']['name']);

    for ($i = 0; $i < $count; $i++) {
        if ($_FILES['attachments']['error'][$i] !== UPLOAD_ERR_OK) {
            continue;
        }

        $orig = basename($_FILES['attachments']['name'][$i]);
        $ext = strtolower(pathinfo($orig, PATHINFO_EXTENSION));

        if (!in_array($ext, $allowed_exts, true)) {
            continue;
        }

        $stored = bin2hex(random_bytes(8)) . '_' . preg_replace("/[^a-zA-Z0-9._-]/", "_", $orig);
        $destination = $upload_dir_fs . '/' . $stored;

        if (move_uploaded_file($_FILES['attachments']['tmp_name'][$i], $destination)) {
            $relative = 'uploads/sops/' . $stored;
            $mime = mime_content_type($destination) ?: 'application/octet-stream';

            $stmt = $pdo->prepare("
                INSERT INTO sop_attachments (
                    sop_id, original_name, stored_name, file_path, mime_type, file_size, uploaded_by
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $sop_id,
                $orig,
                $stored,
                $relative,
                $mime,
                filesize($destination),
                $uploader_id
            ]);
        }
    }
}

/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/

$categories = [
    'Server Management',
    'Network',
    'Database',
    'Security',
    'Backup',
    'Monitoring',
    'Incident Management',
    'Change Management',
    'Disaster Recovery',
    'Application',
    'Cloud',
    'Linux',
    'Windows',
    'Container Platform',
    'IPA',
    'Satellite',
    'PCS Cluster',
    'ODF',
    'General',
    'Others'
];

/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg = $_SESSION['sop_success'] ?? '';
$error_msg = $_SESSION['sop_error'] ?? '';

unset($_SESSION['sop_success'], $_SESSION['sop_error']);

/*
|--------------------------------------------------------------------------
| ACTION
|--------------------------------------------------------------------------
*/

$action = $_GET['action'] ?? 'list';

$upload_dir_fs = __DIR__ . '/uploads/sops';

/*
|--------------------------------------------------------------------------
| CREATE / UPDATE / DELETE / REVIEW
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $post_action = $_POST['form_action'] ?? '';

    /*
    |--------------------------------------------------------------------------
    | SAVE SOP (create or update)
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'save_sop') {

        $sop_id = (int) ($_POST['sop_id'] ?? 0);

        $title = trim($_POST['title'] ?? '');
        $category = trim($_POST['category'] ?? '');
        $criticality = trim($_POST['criticality'] ?? 'Medium');
        $description = trim($_POST['description'] ?? '');

        $prerequisites = sanitize_sop_html($_POST['prerequisites_html'] ?? '');
        $content = sanitize_sop_html($_POST['content_html'] ?? '');
        $validation = sanitize_sop_html($_POST['validation_html'] ?? '');
        $rollback = sanitize_sop_html($_POST['rollback_html'] ?? '');
        $escalation = sanitize_sop_html($_POST['escalation_html'] ?? '');

        $review_date = trim($_POST['review_date'] ?? '');

        $reviewer_id = (int) ($_POST['reviewer_id'] ?? 0);
        $reviewer_id = $reviewer_id > 0 ? $reviewer_id : null;

        // Was "Save & Submit for Review" clicked?
        $after_save = $_POST['after_save'] ?? '';

        if ($title === '') {
            $_SESSION['sop_error'] = 'SOP title is required.';
            redirect_sop($sop_id ?: null);
        }

        if ($category === '') {
            $_SESSION['sop_error'] = 'SOP category is required.';
            redirect_sop($sop_id ?: null);
        }

        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($sop_id === 0) {

            $sop_number = generate_sop_number($pdo);

            // Admins may assign a different owner at creation time.
            $owner_id = $current_user_id;

            if ($is_admin) {
                $owner_id_post = (int) ($_POST['owner_id'] ?? 0);
                if ($owner_id_post > 0) {
                    $owner_id = $owner_id_post;
                }
            }

            $initial_status = ($after_save === 'submit') ? 'Pending Review' : 'Draft';
            $submitted_at = ($initial_status === 'Pending Review') ? date('Y-m-d H:i:s') : null;

            $stmt = $pdo->prepare("
                INSERT INTO sops (
                    sop_number, title, category, description, criticality,
                    owner_id, reviewer_id, version, status,
                    content_html, prerequisites_html, validation_html, rollback_html, escalation_html,
                    review_date, submitted_at, created_at, updated_at
                )
                VALUES (
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
            ");

            $stmt->execute([
                $sop_number,
                $title,
                $category,
                $description,
                $criticality,
                $owner_id,
                $reviewer_id,
                '1.0',
                $initial_status,
                $content,
                $prerequisites,
                $validation,
                $rollback,
                $escalation,
                $review_date ?: null,
                $submitted_at
            ]);

            $sop_id = (int) $pdo->lastInsertId();

            // Initial revision.
            $revision = $pdo->prepare("
                INSERT INTO sop_revisions (sop_id, version, title, content_html, changed_by, change_summary)
                VALUES (?, ?, ?, ?, ?, ?)
            ");

            $revision->execute([
                $sop_id,
                '1.0',
                $title,
                $content,
                $current_user_id,
                'Initial SOP created'
            ]);

            process_sop_attachments($pdo, $upload_dir_fs, $sop_id, $current_user_id);

            $_SESSION['sop_success'] = $initial_status === 'Pending Review'
                ? 'SOP created and submitted for Admin review.'
                : 'SOP created successfully.';

            redirect_sop($sop_id);
        }

        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("SELECT * FROM sops WHERE id = ? LIMIT 1");
        $stmt->execute([$sop_id]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {
            $_SESSION['sop_error'] = 'SOP not found.';
            redirect_sop();
        }

        if (!can_edit_sop($existing, $current_user_id, $is_admin)) {
            http_response_code(403);
            exit('You do not have permission to edit this SOP.');
        }

        // Version bump.
        $old_version = $existing['version'] ?: '1.0';
        $parts = explode('.', $old_version);
        $major = (int) ($parts[0] ?? 1);
        $minor = (int) ($parts[1] ?? 0);
        $new_version = $major . '.' . ($minor + 1);

        // Editing a Published SOP, or explicitly submitting, sends it back for review.
        $new_status = 'Draft';

        if ($existing['status'] === 'Published' || $after_save === 'submit') {
            $new_status = 'Pending Review';
        }

        $stmt = $pdo->prepare("
            UPDATE sops
            SET
                title = ?,
                category = ?,
                description = ?,
                criticality = ?,
                reviewer_id = ?,
                version = ?,
                status = ?,
                content_html = ?,
                prerequisites_html = ?,
                validation_html = ?,
                rollback_html = ?,
                escalation_html = ?,
                review_date = ?,
                updated_at = CURRENT_TIMESTAMP,
                submitted_at = CASE
                    WHEN ? = 'Pending Review'
                    THEN CURRENT_TIMESTAMP
                    ELSE submitted_at
                END
            WHERE id = ?
        ");

        $stmt->execute([
            $title,
            $category,
            $description,
            $criticality,
            $reviewer_id,
            $new_version,
            $new_status,
            $content,
            $prerequisites,
            $validation,
            $rollback,
            $escalation,
            $review_date ?: null,
            $new_status,
            $sop_id
        ]);

        $revision = $pdo->prepare("
            INSERT INTO sop_revisions (sop_id, version, title, content_html, changed_by, change_summary)
            VALUES (?, ?, ?, ?, ?, ?)
        ");

        $revision->execute([
            $sop_id,
            $new_version,
            $title,
            $content,
            $current_user_id,
            'SOP updated'
        ]);

        process_sop_attachments($pdo, $upload_dir_fs, $sop_id, $current_user_id);

        $_SESSION['sop_success'] = $new_status === 'Pending Review'
            ? 'SOP updated and submitted for Admin review.'
            : 'SOP updated successfully.';

        redirect_sop($sop_id);
    }

    /*
    |--------------------------------------------------------------------------
    | SUBMIT FOR REVIEW
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'submit_review') {

        $sop_id = (int) ($_POST['sop_id'] ?? 0);

        $stmt = $pdo->prepare("SELECT * FROM sops WHERE id = ? LIMIT 1");
        $stmt->execute([$sop_id]);
        $sop = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$sop) {
            $_SESSION['sop_error'] = 'SOP not found.';
            redirect_sop();
        }

        if (!can_edit_sop($sop, $current_user_id, $is_admin)) {
            http_response_code(403);
            exit('Permission denied.');
        }

        $stmt = $pdo->prepare("
            UPDATE sops
            SET status = 'Pending Review', submitted_at = CURRENT_TIMESTAMP, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");

        $stmt->execute([$sop_id]);

        $_SESSION['sop_success'] = 'SOP submitted for Admin review.';

        redirect_sop($sop_id);
    }

    /*
    |--------------------------------------------------------------------------
    | ADMIN REVIEW
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'review_sop') {

        if (!$is_admin) {
            http_response_code(403);
            exit('Admin privileges required.');
        }

        $sop_id = (int) ($_POST['sop_id'] ?? 0);
        $decision = $_POST['decision'] ?? '';
        $comment = trim($_POST['review_comment'] ?? '');

        if (!in_array($decision, ['publish', 'reject'], true)) {
            $_SESSION['sop_error'] = 'Invalid review decision.';
            redirect_sop($sop_id);
        }

        if ($decision === 'publish') {

            $stmt = $pdo->prepare("
                UPDATE sops
                SET
                    status = 'Published',
                    reviewer_id = ?,
                    review_comment = ?,
                    rejection_reason = NULL,
                    reviewed_at = CURRENT_TIMESTAMP,
                    published_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");

            $stmt->execute([$current_user_id, $comment, $sop_id]);

            $_SESSION['sop_success'] = 'SOP approved and published.';
        }

        if ($decision === 'reject') {

            if ($comment === '') {
                $_SESSION['sop_error'] = 'Please provide a rejection reason.';
                redirect_sop($sop_id);
            }

            $stmt = $pdo->prepare("
                UPDATE sops
                SET
                    status = 'Rejected',
                    reviewer_id = ?,
                    review_comment = ?,
                    rejection_reason = ?,
                    reviewed_at = CURRENT_TIMESTAMP,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");

            $stmt->execute([$current_user_id, $comment, $comment, $sop_id]);

            $_SESSION['sop_success'] = 'SOP rejected and returned to the owner.';
        }

        redirect_sop($sop_id);
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE SOP
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'delete_sop') {

        $sop_id = (int) ($_POST['sop_id'] ?? 0);

        $stmt = $pdo->prepare("SELECT * FROM sops WHERE id = ? LIMIT 1");
        $stmt->execute([$sop_id]);
        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {
            $_SESSION['sop_error'] = 'SOP not found.';
            redirect_sop();
        }

        if (!can_delete_sop($existing, $current_user_id, $is_admin)) {
            http_response_code(403);
            exit('You do not have permission to delete this SOP.');
        }

        $att_stmt = $pdo->prepare("SELECT file_path FROM sop_attachments WHERE sop_id = ?");
        $att_stmt->execute([$sop_id]);

        foreach ($att_stmt->fetchAll(PDO::FETCH_ASSOC) as $att) {
            $file = __DIR__ . '/' . ltrim($att['file_path'], '/\\');
            if (is_file($file)) {
                @unlink($file);
            }
        }

        $pdo->prepare("DELETE FROM sop_attachments WHERE sop_id = ?")->execute([$sop_id]);
        $pdo->prepare("DELETE FROM sop_revisions WHERE sop_id = ?")->execute([$sop_id]);
        $pdo->prepare("DELETE FROM sops WHERE id = ?")->execute([$sop_id]);

        $_SESSION['sop_success'] = 'SOP deleted successfully.';

        redirect_sop();
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE ATTACHMENT
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'delete_attachment') {

        $attachment_id = (int) ($_POST['attachment_id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT a.*, s.owner_id, s.status
            FROM sop_attachments a
            INNER JOIN sops s ON s.id = a.sop_id
            WHERE a.id = ?
            LIMIT 1
        ");

        $stmt->execute([$attachment_id]);
        $attachment = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$attachment) {
            $_SESSION['sop_error'] = 'Attachment not found.';
            redirect_sop();
        }

        if (!$is_admin && (int) $attachment['owner_id'] !== $current_user_id) {
            http_response_code(403);
            exit('Permission denied.');
        }

        if ($attachment['status'] === 'Pending Review') {
            $_SESSION['sop_error'] = 'Attachments cannot be changed while under review.';
            redirect_sop($attachment['sop_id']);
        }

        $file = __DIR__ . '/' . ltrim($attachment['file_path'], '/\\');

        if (is_file($file)) {
            @unlink($file);
        }

        $stmt = $pdo->prepare("DELETE FROM sop_attachments WHERE id = ?");
        $stmt->execute([$attachment_id]);

        $_SESSION['sop_success'] = 'Attachment removed.';

        redirect_sop($attachment['sop_id']);
    }
}

/*
|--------------------------------------------------------------------------
| IMAGE UPLOAD (used by the editor)
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_image'])) {

    check_csrf();

    header('Content-Type: application/json');

    $sop_id = (int) ($_POST['sop_id'] ?? 0);

    if ($sop_id > 0) {

        $stmt = $pdo->prepare("SELECT * FROM sops WHERE id = ? LIMIT 1");
        $stmt->execute([$sop_id]);
        $sop = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$sop || !can_edit_sop($sop, $current_user_id, $is_admin)) {
            echo json_encode(['success' => false, 'message' => 'Permission denied.']);
            exit;
        }
    }

    if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
        echo json_encode(['success' => false, 'message' => 'Image upload failed.']);
        exit;
    }

    $file = $_FILES['image'];

    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'Maximum image size is 5 MB.']);
        exit;
    }

    $allowed = [
        'image/png' => 'png',
        'image/jpeg' => 'jpg',
        'image/gif' => 'gif',
        'image/webp' => 'webp'
    ];

    $mime = mime_content_type($file['tmp_name']);

    if (!isset($allowed[$mime])) {
        echo json_encode(['success' => false, 'message' => 'Unsupported image format.']);
        exit;
    }

    if (!is_dir($upload_dir_fs)) {
        mkdir($upload_dir_fs, 0755, true);
    }

    $stored_name = bin2hex(random_bytes(16)) . '.' . $allowed[$mime];
    $destination = $upload_dir_fs . '/' . $stored_name;

    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        echo json_encode(['success' => false, 'message' => 'Unable to save image.']);
        exit;
    }

    $relative_path = 'uploads/sops/' . $stored_name;

    // Store as attachment if the SOP already exists.
    if ($sop_id > 0) {

        $stmt = $pdo->prepare("
            INSERT INTO sop_attachments (sop_id, original_name, stored_name, file_path, mime_type, file_size, uploaded_by)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");

        $stmt->execute([
            $sop_id,
            $file['name'],
            $stored_name,
            $relative_path,
            $mime,
            $file['size'],
            $current_user_id
        ]);

        $attachment_id = (int) $pdo->lastInsertId();
        $image_url = 'sop.php?action=file&id=' . $attachment_id;

    } else {
        // New SOP: image is temporarily public by path until the SOP is saved.
        $image_url = $relative_path;
    }

    echo json_encode(['success' => true, 'url' => $image_url]);
    exit;
}

/*
|--------------------------------------------------------------------------
| SECURE FILE / IMAGE DELIVERY
|--------------------------------------------------------------------------
*/

if ($action === 'file') {

    $attachment_id = (int) ($_GET['id'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM sop_attachments WHERE id = ? LIMIT 1");
    $stmt->execute([$attachment_id]);
    $attachment = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$attachment) {
        http_response_code(404);
        exit('File not found.');
    }

    $file = __DIR__ . '/' . ltrim($attachment['file_path'], '/\\');

    if (!is_file($file)) {
        http_response_code(404);
        exit('File not found.');
    }

    $mime = $attachment['mime_type'] ?? 'application/octet-stream';

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . filesize($file));
    header('X-Content-Type-Options: nosniff');

    if (strpos($mime, 'image/') === 0) {
        header('Content-Disposition: inline; filename="' . basename($attachment['original_name']) . '"');
    } else {
        header('Content-Disposition: attachment; filename="' . basename($attachment['original_name']) . '"');
    }

    readfile($file);
    exit;
}

/*
|--------------------------------------------------------------------------
| Load SOP (with owner / assigned reviewer / actual reviewer names)
|--------------------------------------------------------------------------
*/

$sop_id = (int) ($_GET['id'] ?? 0);
$sop = null;

if ($sop_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            s.*,
            owner.first_name, owner.last_name, owner.email, owner.team,
            assigned.first_name AS assigned_first, assigned.last_name AS assigned_last,
            reviewer.first_name AS reviewer_first, reviewer.last_name AS reviewer_last
        FROM sops s
        LEFT JOIN users owner    ON owner.id = s.owner_id
        LEFT JOIN users assigned ON assigned.id = s.reviewer_id
        LEFT JOIN users reviewer ON reviewer.id = s.reviewer_id
        WHERE s.id = ?
        LIMIT 1
    ");

    $stmt->execute([$sop_id]);
    $sop = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$sop) {
        $_SESSION['sop_error'] = 'SOP not found.';
        redirect_sop();
    }
}

/*
|--------------------------------------------------------------------------
| CREATE / EDIT mode
|--------------------------------------------------------------------------
*/

$is_form = in_array($action, ['create', 'edit'], true);
$is_view = $action === 'view';

if ($action === 'edit' && $sop) {
    if (!can_edit_sop($sop, $current_user_id, $is_admin)) {
        http_response_code(403);
        exit('You do not have permission to edit this SOP.');
    }
}

/*
|--------------------------------------------------------------------------
| Users for Admin owner selection
|--------------------------------------------------------------------------
*/

$users = [];

if ($is_form && $is_admin) {

    $stmt = $pdo->query("
        SELECT id, first_name, last_name, email, team
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name, last_name
    ");

    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| Admin users available to be picked as a reviewer.
| Any author (not just Admins) can propose a reviewer for their SOP.
|--------------------------------------------------------------------------
*/

$reviewers = [];

if ($is_form) {

    $stmt = $pdo->query("
        SELECT id, first_name, last_name, email, team
        FROM users
        WHERE is_approved = 1
          AND LOWER(role) IN ('admin', 'administrator', 'super admin', 'superadmin')
        ORDER BY first_name, last_name
    ");

    $reviewers = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

$attachments = [];

if ($sop_id > 0) {

    $stmt = $pdo->prepare("
        SELECT a.*, u.first_name, u.last_name
        FROM sop_attachments a
        LEFT JOIN users u ON u.id = a.uploaded_by
        WHERE a.sop_id = ?
        ORDER BY a.created_at DESC
    ");

    $stmt->execute([$sop_id]);
    $attachments = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("SELECT status, COUNT(*) AS total FROM sops GROUP BY status");

$status_counts = [];

foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $status_counts[$row['status']] = (int) $row['total'];
}

$total_sops = array_sum($status_counts);
$published = $status_counts['Published'] ?? 0;
$pending = $status_counts['Pending Review'] ?? 0;
$draft = $status_counts['Draft'] ?? 0;
$rejected = $status_counts['Rejected'] ?? 0;

$page_title = 'SOP Management';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<link rel="stylesheet" href="assets/css/sop.css">

<div class="content sop-content">

<?php if ($success_msg): ?>
    <div class="sop-alert success"><?= h($success_msg) ?></div>
<?php endif; ?>

<?php if ($error_msg): ?>
    <div class="sop-alert error"><?= h($error_msg) ?></div>
<?php endif; ?>

<?php

/*
|--------------------------------------------------------------------------
| CREATE / EDIT
|--------------------------------------------------------------------------
*/

if ($is_form):

    $editing = ($action === 'edit');
    $form_title = $editing ? 'Edit SOP' : 'Create Standard Operating Procedure';

    $form_sop_number = $sop['sop_number'] ?? generate_sop_number($pdo);
    $form_title_value = $sop['title'] ?? '';
    $form_category = $sop['category'] ?? '';
    $form_criticality = $sop['criticality'] ?? 'Medium';
    $form_description = $sop['description'] ?? '';
    $form_prerequisites = $sop['prerequisites_html'] ?? '';
    $form_content = $sop['content_html'] ?? '';
    $form_validation = $sop['validation_html'] ?? '';
    $form_rollback = $sop['rollback_html'] ?? '';
    $form_escalation = $sop['escalation_html'] ?? '';
    $form_review_date = $sop['review_date'] ?? '';
    $owner_id = $sop['owner_id'] ?? $current_user_id;
    $form_reviewer_id = (int) ($sop['reviewer_id'] ?? 0);

?>

    <div class="sop-page-header">
        <div>
            <h1><?= h($form_title) ?></h1>
            <p>Create and maintain controlled infrastructure procedures.</p>
        </div>

        <a href="sop.php" class="sop-secondary-btn">Back to SOP Library</a>
    </div>

    <form method="POST" action="sop.php" enctype="multipart/form-data" id="sopForm">

        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
        <input type="hidden" name="form_action" value="save_sop">
        <input type="hidden" name="sop_id" value="<?= (int) ($sop['id'] ?? 0) ?>">

        <!-- BASIC INFORMATION -->
        <div class="sop-form-panel">

            <div class="sop-section-title">
                <h2>Basic Information</h2>
                <span>SOP identification, ownership and review assignment</span>
            </div>

            <div class="sop-form-grid">

                <div class="sop-field">
                    <label>SOP Number</label>
                    <input type="text" value="<?= h($form_sop_number) ?>" readonly>
                </div>

                <div class="sop-field">
                    <label>Version</label>
                    <input type="text" value="<?= h($sop['version'] ?? '1.0') ?>" readonly>
                </div>

                <div class="sop-field full">
                    <label>Title <span>*</span></label>
                    <input
                        type="text"
                        name="title"
                        required
                        value="<?= h($form_title_value) ?>"
                        placeholder="Example: Production Linux Server Patching"
                    >
                </div>

                <div class="sop-field">
                    <label>Category <span>*</span></label>
                    <select name="category" required>
                        <option value="">Select Category</option>
                        <?php foreach ($categories as $category): ?>
                            <option value="<?= h($category) ?>" <?= $form_category === $category ? 'selected' : '' ?>>
                                <?= h($category) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="sop-field">
                    <label>Criticality</label>
                    <select name="criticality">
                        <?php foreach (['Low', 'Medium', 'High', 'Critical'] as $level): ?>
                            <option value="<?= h($level) ?>" <?= $form_criticality === $level ? 'selected' : '' ?>>
                                <?= h($level) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="sop-field">
                    <label>Owner</label>

                    <?php if ($is_admin): ?>
                        <select name="owner_id">
                            <?php foreach ($users as $user): ?>
                                <option
                                    value="<?= (int) $user['id'] ?>"
                                    <?= (int) $owner_id === (int) $user['id'] ? 'selected' : '' ?>
                                >
                                    <?= h(trim($user['first_name'] . ' ' . $user['last_name'])) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    <?php else: ?>
                        <input type="text" readonly value="<?= h(get_user_name($pdo, (int) $owner_id)) ?>">
                    <?php endif; ?>
                </div>

                <div class="sop-field">
                    <label>Reviewer</label>
                    <select name="reviewer_id">
                        <option value="0">-- No specific reviewer (any Admin) --</option>
                        <?php foreach ($reviewers as $reviewer): ?>
                            <option
                                value="<?= (int) $reviewer['id'] ?>"
                                <?= $form_reviewer_id === (int) $reviewer['id'] ? 'selected' : '' ?>
                            >
                                <?= h(trim($reviewer['first_name'] . ' ' . $reviewer['last_name'])) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="sop-field">
                    <label>Review Date</label>
                    <input type="date" name="review_date" value="<?= h($form_review_date) ?>">
                </div>

                <div class="sop-field full">
                    <label>Description</label>
                    <textarea
                        name="description"
                        rows="4"
                        placeholder="Briefly describe the purpose and scope of this SOP."
                    ><?= h($form_description) ?></textarea>
                </div>

            </div>
        </div>

        <!-- PREREQUISITES -->
        <div class="sop-form-panel">
            <div class="sop-section-title">
                <h2>Prerequisites</h2>
                <span>Requirements before starting the procedure</span>
            </div>

            <div class="rich-editor" data-target="prerequisites_html" contenteditable="true"><?= $form_prerequisites ?></div>
            <textarea name="prerequisites_html" class="editor-hidden"></textarea>
        </div>

        <!-- PROCEDURE -->
        <div class="sop-form-panel">
            <div class="sop-section-title">
                <h2>Procedure</h2>
                <span>Detailed operational procedure</span>
            </div>

            <div class="editor-toolbar">
                <button type="button" onclick="formatEditor('bold')"><b>B</b></button>
                <button type="button" onclick="formatEditor('italic')"><i>I</i></button>
                <button type="button" onclick="formatBlock('h2')">H2</button>
                <button type="button" onclick="formatBlock('h3')">H3</button>
                <button type="button" onclick="formatEditor('insertUnorderedList')">&bull; List</button>
                <button type="button" onclick="formatEditor('insertOrderedList')">1. List</button>
                <button type="button" onclick="insertLink()">Link</button>
                <button type="button" onclick="insertCodeBlock()">&lt;/&gt; Command</button>

                <label class="editor-upload">
                    Image
                    <input type="file" id="editorImage" accept="image/png,image/jpeg,image/gif,image/webp" hidden>
                </label>
            </div>

            <div id="procedureEditor" class="rich-editor large" contenteditable="true"><?= $form_content ?></div>
            <textarea name="content_html" id="contentHtml" class="editor-hidden"></textarea>
        </div>

        <!-- VALIDATION -->
        <div class="sop-form-panel">
            <div class="sop-section-title">
                <h2>Validation</h2>
                <span>Checks required after completion</span>
            </div>

            <div class="rich-editor" data-target="validation_html" contenteditable="true"><?= $form_validation ?></div>
            <textarea name="validation_html" class="editor-hidden"></textarea>
        </div>

        <!-- ROLLBACK -->
        <div class="sop-form-panel">
            <div class="sop-section-title">
                <h2>Rollback</h2>
                <span>Recovery or rollback procedure</span>
            </div>

            <div class="rich-editor" data-target="rollback_html" contenteditable="true"><?= $form_rollback ?></div>
            <textarea name="rollback_html" class="editor-hidden"></textarea>
        </div>

        <!-- ESCALATION -->
        <div class="sop-form-panel">
            <div class="sop-section-title">
                <h2>Escalation</h2>
                <span>Escalation path and responsible teams</span>
            </div>

            <div class="rich-editor" data-target="escalation_html" contenteditable="true"><?= $form_escalation ?></div>
            <textarea name="escalation_html" class="editor-hidden"></textarea>
        </div>

        <!-- ATTACHMENTS -->
        <?php if ($editing): ?>
            <div class="sop-form-panel">
                <div class="sop-section-title">
                    <h2>Attachments</h2>
                    <span>Supporting infrastructure documents</span>
                </div>

                <input type="file" name="attachments[]" multiple class="attachment-input">

                <?php if ($attachments): ?>
                    <div class="attachment-list">
                        <?php foreach ($attachments as $attachment): ?>
                            <div class="attachment-item">
                                <div>
                                    <strong><?= h($attachment['original_name']) ?></strong>
                                    <small><?= h(number_format($attachment['file_size'] / 1024, 1)) ?> KB</small>
                                </div>

                                <div>
                                    <a href="sop.php?action=file&id=<?= (int) $attachment['id'] ?>" class="attachment-download">Download</a>

                                    <?php if ($can_edit = can_edit_sop($sop, $current_user_id, $is_admin)): ?>
                                        <?php if ($sop['status'] !== 'Pending Review'): ?>
                                            <button
                                                type="submit"
                                                name="form_action"
                                                value="delete_attachment"
                                                formaction="sop.php"
                                                formmethod="POST"
                                                onclick="return confirm('Remove this attachment?');"
                                                class="attachment-remove"
                                            >
                                                Remove
                                            </button>
                                            <input type="hidden" name="attachment_id" value="<?= (int) $attachment['id'] ?>">
                                        <?php endif; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="sop-form-panel">
                <div class="sop-section-title">
                    <h2>Attachments</h2>
                    <span>You can attach supporting documents once the SOP has been created</span>
                </div>
                <p class="muted">Save the SOP first, then open it for editing to attach files.</p>
            </div>
        <?php endif; ?>

        <!-- ACTIONS -->
        <div class="sop-form-actions">
            <a href="sop.php" class="sop-secondary-btn">Cancel</a>
            <button type="submit" class="sop-secondary-btn">Save Draft</button>
            <button type="submit" name="after_save" value="submit" class="sop-primary-btn">Save &amp; Submit for Review</button>
        </div>

    </form>

<?php

/*
|--------------------------------------------------------------------------
| VIEW
|--------------------------------------------------------------------------
*/

elseif ($is_view && $sop):

    $is_owner = (int) $sop['owner_id'] === $current_user_id;
    $can_edit = $is_admin || $is_owner;

    $assigned_reviewer_name = trim(($sop['assigned_first'] ?? '') . ' ' . ($sop['assigned_last'] ?? ''));
    $actual_reviewer_name = trim(($sop['reviewer_first'] ?? '') . ' ' . ($sop['reviewer_last'] ?? ''));

?>

    <div class="sop-document-header">
        <div>
            <div class="sop-document-number"><?= h($sop['sop_number']) ?></div>
            <h1><?= h($sop['title']) ?></h1>
            <p><?= h($sop['description']) ?></p>
        </div>

        <div class="sop-document-actions">
            <?php if ($can_edit): ?>
                <a href="sop.php?action=edit&id=<?= (int) $sop['id'] ?>" class="sop-secondary-btn">Edit</a>
            <?php endif; ?>

            <?php if ($is_admin && $sop['status'] === 'Pending Review'): ?>
                <a href="#reviewPanel" class="sop-review-btn">Review</a>
            <?php endif; ?>

            <a href="sop-export.php?id=<?= (int) $sop['id'] ?>" class="sop-secondary-btn">Export Word</a>
        </div>
    </div>

    <!-- METADATA -->
    <div class="sop-meta-grid">

        <div>
            <span>STATUS</span>
            <strong class="sop-status status-<?= strtolower(str_replace(' ', '-', $sop['status'])) ?>">
                <?= h($sop['status']) ?>
            </strong>
        </div>

        <div>
            <span>VERSION</span>
            <strong><?= h($sop['version']) ?></strong>
        </div>

        <div>
            <span>CATEGORY</span>
            <strong><?= h($sop['category']) ?></strong>
        </div>

        <div>
            <span>CRITICALITY</span>
            <strong><?= h($sop['criticality']) ?></strong>
        </div>

        <div>
            <span>CREATOR</span>
            <strong><?= h(trim($sop['first_name'] . ' ' . $sop['last_name'])) ?></strong>
        </div>

        <div>
            <span>ASSIGNED REVIEWER</span>
            <strong><?= h($assigned_reviewer_name ?: 'Not assigned') ?></strong>
        </div>

        <?php if (!empty($sop['reviewed_at'])): ?>
            <div>
                <span><?= $sop['status'] === 'Rejected' ? 'REJECTED BY' : 'APPROVED BY' ?></span>
                <strong>
                    <?= h($actual_reviewer_name ?: 'Unknown') ?>
                    <?php if ($assigned_reviewer_name !== '' && $actual_reviewer_name === $assigned_reviewer_name): ?>
                        <span class="reviewer-hint">Reviewed by the assigned reviewer</span>
                    <?php endif; ?>
                </strong>
            </div>
        <?php endif; ?>

        <div>
            <span>LAST UPDATED</span>
            <strong><?= h(date('d M Y H:i', strtotime($sop['updated_at']))) ?></strong>
        </div>

    </div>

    <!-- DOCUMENT -->
    <div class="sop-document">

        <?php if (trim((string) $sop['prerequisites_html']) !== ''): ?>
            <section>
                <h2>Prerequisites</h2>
                <div class="sop-rich-content"><?= $sop['prerequisites_html'] ?></div>
            </section>
        <?php endif; ?>

        <section>
            <h2>Procedure</h2>
            <div class="sop-rich-content"><?= $sop['content_html'] ?: '<p>No procedure provided.</p>' ?></div>
        </section>

        <?php if (trim((string) $sop['validation_html']) !== ''): ?>
            <section>
                <h2>Validation</h2>
                <div class="sop-rich-content"><?= $sop['validation_html'] ?></div>
            </section>
        <?php endif; ?>

        <?php if (trim((string) $sop['rollback_html']) !== ''): ?>
            <section>
                <h2>Rollback</h2>
                <div class="sop-rich-content"><?= $sop['rollback_html'] ?></div>
            </section>
        <?php endif; ?>

        <?php if (trim((string) $sop['escalation_html']) !== ''): ?>
            <section>
                <h2>Escalation</h2>
                <div class="sop-rich-content"><?= $sop['escalation_html'] ?></div>
            </section>
        <?php endif; ?>

        <!-- ATTACHMENTS -->
        <section>
            <h2>Attachments</h2>

            <?php if ($attachments): ?>
                <div class="view-attachment-list">
                    <?php foreach ($attachments as $attachment): ?>
                        <a href="sop.php?action=file&id=<?= (int) $attachment['id'] ?>" class="view-attachment">
                            <span class="attachment-icon">📎</span>
                            <span>
                                <strong><?= h($attachment['original_name']) ?></strong>
                                <small><?= h(number_format($attachment['file_size'] / 1024, 1)) ?> KB</small>
                            </span>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <p class="muted">No attachments.</p>
            <?php endif; ?>
        </section>

        <!-- REVIEW -->
        <?php if ($sop['status'] === 'Rejected' && $sop['rejection_reason']): ?>
            <section class="review-box rejected">
                <h2>Review Feedback</h2>
                <p><?= nl2br(h($sop['rejection_reason'])) ?></p>
            </section>
        <?php endif; ?>

        <?php if ($is_admin && $sop['status'] === 'Pending Review'): ?>
            <section class="review-box" id="reviewPanel">
                <h2>Admin Review</h2>

                <?php if ($assigned_reviewer_name !== ''): ?>
                    <p class="muted">Assigned reviewer: <strong><?= h($assigned_reviewer_name) ?></strong></p>
                <?php endif; ?>

                <form method="POST" action="sop.php?action=view&id=<?= (int) $sop['id'] ?>">
                    <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
                    <input type="hidden" name="form_action" value="review_sop">
                    <input type="hidden" name="sop_id" value="<?= (int) $sop['id'] ?>">

                    <textarea name="review_comment" rows="5" placeholder="Review comments. Required when rejecting."></textarea>

                    <div class="review-actions">
                        <button type="submit" name="decision" value="reject" class="reject-btn">Reject</button>
                        <button
                            type="submit"
                            name="decision"
                            value="publish"
                            class="publish-btn"
                            onclick="return confirm('Publish this SOP?');"
                        >
                            Approve &amp; Publish
                        </button>
                    </div>
                </form>
            </section>
        <?php endif; ?>

    </div>

<?php

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

else:

?>

    <div class="sop-page-header">
        <div>
            <h1>Standard Operating Procedures</h1>
            <p>Infrastructure procedures, operational standards and runbooks.</p>
        </div>

        <a href="sop.php?action=create" class="sop-primary-btn">+ New SOP</a>
    </div>

    <!-- STATISTICS -->
    <div class="sop-stats">
        <div class="sop-stat-card">
            <span>Total SOPs</span>
            <strong><?= $total_sops ?></strong>
        </div>

        <div class="sop-stat-card published">
            <span>Published</span>
            <strong><?= $published ?></strong>
        </div>

        <div class="sop-stat-card review">
            <span>Pending Review</span>
            <strong><?= $pending ?></strong>
        </div>

        <div class="sop-stat-card draft">
            <span>Draft / Rejected</span>
            <strong><?= $draft + $rejected ?></strong>
        </div>
    </div>

    <!-- LIBRARY -->
    <div class="sop-panel">

        <div class="sop-panel-header">
            <div>
                <h2>SOP Library</h2>
                <span>Controlled infrastructure documentation</span>
            </div>

            <input type="text" id="sopSearch" class="sop-search" placeholder="Search SOP...">
        </div>

        <div class="sop-table-wrapper">
            <table class="sop-table">
                <thead>
                    <tr>
                        <th>SOP</th>
                        <th>Title</th>
                        <th>Category</th>
                        <th>Criticality</th>
                        <th>Creator</th>
                        <th>Reviewer</th>
                        <th>Version</th>
                        <th>Status</th>
                        <th>Updated</th>
                        <th>Actions</th>
                    </tr>
                </thead>

                <tbody>

                <?php

                $stmt = $pdo->query("
                    SELECT
                        s.*,
                        owner.first_name, owner.last_name,
                        assigned.first_name AS assigned_first, assigned.last_name AS assigned_last,
                        reviewer.first_name AS reviewer_first, reviewer.last_name AS reviewer_last
                    FROM sops s
                    LEFT JOIN users owner    ON owner.id = s.owner_id
                    LEFT JOIN users assigned ON assigned.id = s.reviewer_id
                    LEFT JOIN users reviewer ON reviewer.id = s.reviewer_id
                    ORDER BY s.updated_at DESC
                ");

                $sops = $stmt->fetchAll(PDO::FETCH_ASSOC);

                ?>

                <?php if (!$sops): ?>
                    <tr><td colspan="10" class="sop-empty">No SOPs have been created yet.</td></tr>
                <?php endif; ?>

                <?php foreach ($sops as $row): ?>

                    <?php
                        $owner = trim($row['first_name'] . ' ' . $row['last_name']);
                        $assigned_reviewer = trim(($row['assigned_first'] ?? '') . ' ' . ($row['assigned_last'] ?? ''));
                        $actual_reviewer = trim(($row['reviewer_first'] ?? '') . ' ' . ($row['reviewer_last'] ?? ''));

                        $can_edit = can_edit_sop($row, $current_user_id, $is_admin);
                        $can_delete = can_delete_sop($row, $current_user_id, $is_admin);
                    ?>

                    <tr>
                        <td><strong><?= h($row['sop_number']) ?></strong></td>

                        <td>
                            <a href="sop.php?action=view&id=<?= (int) $row['id'] ?>" class="sop-title">
                                <?= h($row['title']) ?>
                            </a>
                        </td>

                        <td><?= h($row['category']) ?></td>

                        <td>
                            <span class="criticality <?= strtolower(h($row['criticality'])) ?>">
                                <?= h($row['criticality']) ?>
                            </span>
                        </td>

                        <td><?= h($owner) ?></td>

                        <td>
                            <?php if ($row['status'] === 'Published' || $row['status'] === 'Rejected'): ?>
                                <?= h($actual_reviewer ?: '—') ?>
                            <?php elseif ($assigned_reviewer !== ''): ?>
                                <?= h($assigned_reviewer) ?>
                                <span class="reviewer-hint">Assigned</span>
                            <?php else: ?>
                                —
                            <?php endif; ?>
                        </td>

                        <td><?= h($row['version']) ?></td>

                        <td>
                            <span class="sop-status status-<?= strtolower(str_replace(' ', '-', h($row['status']))) ?>">
                                <?= h($row['status']) ?>
                            </span>
                        </td>

                        <td><?= h(date('d M Y', strtotime($row['updated_at']))) ?></td>

                        <td>
                            <div class="sop-actions">
                                <a href="sop.php?action=view&id=<?= (int) $row['id'] ?>">View</a>

                                <?php if ($can_edit): ?>
                                    <a class="edit" href="sop.php?action=edit&id=<?= (int) $row['id'] ?>">Edit</a>
                                <?php endif; ?>

                                <?php if ($is_admin && $row['status'] === 'Pending Review'): ?>
                                    <a class="review" href="sop.php?action=view&id=<?= (int) $row['id'] ?>#reviewPanel">Review</a>
                                <?php endif; ?>

                                <?php if ($can_delete): ?>
                                    <form
                                        method="POST"
                                        action="sop.php"
                                        style="display:inline"
                                        onsubmit="return confirm('Delete this SOP permanently?');"
                                    >
                                        <input type="hidden" name="csrf_token" value="<?= h($csrf_token) ?>">
                                        <input type="hidden" name="form_action" value="delete_sop">
                                        <input type="hidden" name="sop_id" value="<?= (int) $row['id'] ?>">
                                        <button type="submit" class="delete">Delete</button>
                                    </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>

                <?php endforeach; ?>

                </tbody>
            </table>
        </div>
    </div>

<?php endif; ?>

</div>

<script>

function formatEditor(command) {
    document.execCommand(command, false, null);
}

function formatBlock(tag) {
    document.execCommand('formatBlock', false, tag);
}

function insertLink() {
    const url = prompt('Enter URL:');
    if (!url) return;
    document.execCommand('createLink', false, url);
}

function insertCodeBlock() {
    const selection = window.getSelection();
    const text = selection.toString();
    const code = document.createElement('pre');
    code.className = 'sop-command';
    code.textContent = text || 'Enter command here';

    const range = selection.rangeCount ? selection.getRangeAt(0) : null;

    if (range) {
        range.deleteContents();
        range.insertNode(code);
    } else {
        document.getElementById('procedureEditor')?.appendChild(code);
    }
}

const imageInput = document.getElementById('editorImage');

if (imageInput) {
    imageInput.addEventListener('change', async function () {
        if (!this.files.length) return;

        const file = this.files[0];
        const formData = new FormData();

        formData.append('upload_image', '1');
        formData.append('csrf_token', '<?= h($csrf_token) ?>');
        formData.append('sop_id', '<?= (int) ($sop['id'] ?? 0) ?>');
        formData.append('image', file);

        try {
            const response = await fetch('sop.php', { method: 'POST', body: formData });
            const result = await response.json();

            if (!result.success) {
                alert(result.message || 'Image upload failed.');
                return;
            }

            const editor = document.getElementById('procedureEditor');
            const image = document.createElement('img');
            image.src = result.url;
            image.className = 'sop-inline-image';

            editor.focus();
            document.execCommand('insertHTML', false, image.outerHTML);

        } catch (error) {
            alert('Unable to upload image.');
        }
    });
}

/*
|--------------------------------------------------------------------------
| Copy editor HTML into hidden fields before submit
|--------------------------------------------------------------------------
*/

document.getElementById('sopForm')?.addEventListener('submit', function () {

    document.querySelectorAll('.rich-editor').forEach(function (editor) {
        const target = editor.dataset.target;
        if (!target) return;

        const field = document.querySelector('[name="' + target + '"]');
        if (field) field.value = editor.innerHTML;
    });

    const procedure = document.getElementById('procedureEditor');
    const content = document.getElementById('contentHtml');

    if (procedure && content) {
        content.value = procedure.innerHTML;
    }
});

/*
|--------------------------------------------------------------------------
| SOP search
|--------------------------------------------------------------------------
*/

const search = document.getElementById('sopSearch');

if (search) {
    search.addEventListener('input', function () {
        const value = this.value.toLowerCase();

        document.querySelectorAll('.sop-table tbody tr').forEach(function (row) {
            row.style.display = row.innerText.toLowerCase().includes(value) ? '' : 'none';
        });
    });
}

</script>

<?php

require_once 'includes/footer.php';

?>
