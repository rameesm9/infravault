<?php

require_once "config/db.php";

$message = "";
$message_type = "";


if ($_SERVER["REQUEST_METHOD"] === "POST") {


    $ncgr_id    = trim($_POST['ncgr_id']);
    $first_name = trim($_POST['first_name']);
    $last_name  = trim($_POST['last_name']);
    $email      = trim($_POST['email']);
    $team       = trim($_POST['team']);
    $password   = $_POST['password'];
    $confirm    = $_POST['confirm_password'];



    if (
        empty($ncgr_id) ||
        empty($first_name) ||
        empty($last_name) ||
        empty($email) ||
        empty($team) ||
        empty($password)
    ) {

        $message = "Please complete all required fields.";
        $message_type = "error";


    } elseif ($password !== $confirm) {


        $message = "Passwords do not match.";
        $message_type = "error";


    } else {


        $check = $pdo->prepare("
            SELECT id
            FROM users
            WHERE ncgr_id = ?
        ");


        $check->execute([$ncgr_id]);


        if ($check->fetch()) {


            $message = "NCGR ID already exists.";
            $message_type = "error";


        } else {


            $hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );


            $stmt = $pdo->prepare("
                INSERT INTO users
                (
                    ncgr_id,
                    first_name,
                    last_name,
                    email,
                    team,
                    password,
                    role,
                    is_approved
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    'Read-only',
                    0
                )
            ");



            $stmt->execute([
                $ncgr_id,
                $first_name,
                $last_name,
                $email,
                $team,
                $hash
            ]);



            $message =
            "Registration completed. Your account is waiting for administrator approval.";

            $message_type = "success";


        }

    }

}

?>


<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
InfraVault Registration
</title>



<style>


@font-face{

font-family:Inter;

src:url("assets/webfonts/Inter-Regular.woff2");

}



*{

box-sizing:border-box;

}



body{

margin:0;

min-height:100vh;

background:
linear-gradient(
135deg,
#020617,
#172554
);

font-family:Inter,Segoe UI,sans-serif;

display:flex;

align-items:center;

justify-content:center;

}



.container{

width:1050px;

display:flex;

border-radius:25px;

overflow:hidden;

background:white;

box-shadow:
0 30px 80px rgba(0,0,0,.5);

}



.brand{

width:40%;

padding:55px;

background:
linear-gradient(
160deg,
#0F172A,
#1E3A8A
);

color:white;

}



.logo{

width:110px;

}



.brand h1{

font-size:42px;

color:#38BDF8;

margin-top:25px;

}



.brand p{

color:#CBD5E1;

font-size:17px;

}



.features{

margin-top:45px;

}



.features div{

margin:18px 0;

color:#E2E8F0;

}



.form{

width:60%;

padding:45px 60px;

}



.form h2{

font-size:30px;

color:#0F172A;

margin-bottom:5px;

}



.subtitle{

color:#64748B;

}



.message{

margin-top:20px;

padding:12px;

border-radius:8px;

}



.error{

background:#FEE2E2;

color:#991B1B;

}



.success{

background:#DCFCE7;

color:#166534;

}



label{

display:block;

margin-top:15px;

font-weight:600;

color:#334155;

}



input,
select{

width:100%;

padding:12px;

margin-top:6px;

border-radius:9px;

border:1px solid #CBD5E1;

}



.row{

display:flex;

gap:15px;

}



.row div{

width:50%;

}



button{

width:100%;

margin-top:25px;

padding:14px;

background:#2563EB;

border:none;

border-radius:10px;

color:white;

font-size:16px;

cursor:pointer;

}



button:hover{

background:#1D4ED8;

}



.login{

text-align:center;

margin-top:20px;

}



.login a{

color:#2563EB;

font-weight:bold;

text-decoration:none;

}



</style>


</head>



<body>



<div class="container">



<div class="brand">


<img
class="logo"
src="assets/images/infravault-logo.svg">


<h1>
InfraVault
</h1>


<p>
Enterprise IT Inventory Management
</p>


<div class="features">


<div>
🛡 Secure Access Control
</div>


<div>
🖥 IT Infrastructure Platform
</div>


<div>
🔒 Administrator Approval Required
</div>


</div>


</div>




<div class="form">


<h2>
Create Account
</h2>


<div class="subtitle">

Register for InfraVault access

</div>



<?php if($message): ?>


<div class="message <?= $message_type; ?>">

<?= htmlspecialchars($message); ?>

</div>


<?php endif; ?>




<form method="POST">



<label>
NCGR ID
</label>

<input
type="text"
name="ncgr_id"
placeholder="Example: EMP001"
required>



<div class="row">


<div>

<label>
First Name
</label>

<input
type="text"
name="first_name"
required>

</div>



<div>

<label>
Last Name
</label>

<input
type="text"
name="last_name"
required>

</div>


</div>




<label>
Email
</label>

<input
type="email"
name="email"
required>




<label>
Team
</label>


<select name="team" required>

<option value="">
Select Team
</option>

<option>
Cloud
</option>

<option>
Backup and Storage
</option>

<option>
DR
</option>

<option>
Others
</option>

<option>
Database
</option>
<option>
AD and Exchage
</option>
<option>
Windows
</option>
<option>
Linux and Containers
</option>
<option>
PAM
</option>
</select>




<label>
Password
</label>

<input
type="password"
name="password"
required>




<label>
Confirm Password
</label>

<input
type="password"
name="confirm_password"
required>



<button type="submit">

CREATE ACCOUNT

</button>



</form>




<div class="login">

<a href="index.php">

Already have an account? Sign In

</a>

</div>



</div>



</div>



</body>

</html>
