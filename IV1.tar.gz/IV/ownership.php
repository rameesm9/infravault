<?php
session_start();
require 'config/db.php';


if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Normalize role to trim any accidental whitespace
$role = trim($_SESSION['role'] ?? '');
$username = $_SESSION['name'] ?? 'Unknown User';
$msg = "";
$error = "";

// 1. Handle Export CSV Action
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=ownership_export_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    fputcsv($output, ['ID', 'Project', 'Support Level', 'Technical Owner', 'Technical Owner Email', 'Team DL', 'Technical Manager', 'Technical Manager Email', 'SDM Name', 'SDM Email', 'NCGR Owner', 'NCGR Owner Email', 'Created By', 'Created At']);

    $rows = $pdo->query("SELECT * FROM ownership")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// 2. Handle Global History AJAX Call
if (isset($_GET['action']) && $_GET['action'] === 'get_history' && $role === 'Admin') {
    $stmt = $pdo->query("SELECT * FROM ownership_history ORDER BY timestamp DESC");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table class="audit-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $badge_color = 'background:#e2e8f0;color:#1e293b;';
            if ($log['action_type'] === 'CREATED') $badge_color = 'background:#dcfce7;color:#166534;';
            if ($log['action_type'] === 'DELETED') $badge_color = 'background:#fee2e2;color:#991b1b;';
            if ($log['action_type'] === 'UPDATED') $badge_color = 'background:#fef9c3;color:#854d0e;';

            echo '<tr>';
            echo '<td><span class="audit-badge" style="' . $badge_color . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td>' . htmlspecialchars($log['details']) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">No audit history records found.</p>';
    }
    exit;
}

// 3. Handle Form Submissions (Create, Update, Delete, Bulk Upload)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    // Create or Update Record
    if ($action_type === 'save' && ($role === 'Admin' || $role === 'Edit')) {
        $id = $_POST['id'] ?? '';
        $project = trim($_POST['project']);
        $support_level = $_POST['support_level'];
        $technical_owner = trim($_POST['technical_owner']);
        $technical_owner_email = trim($_POST['technical_owner_email']);
        $team_dl = trim($_POST['team_dl']);
        $technical_manager = trim($_POST['technical_manager']);
        $technical_manager_email = trim($_POST['technical_manager_email']);
        $sdm_name = trim($_POST['sdm_name']);
        $sdm_email = trim($_POST['sdm_email']);
        $ncgr_owner = trim($_POST['ncgr_owner']);
        $ncgr_owner_email = trim($_POST['ncgr_owner_email']);

        if (empty($project) || empty($support_level)) {
            $error = "Project and Support Level are required fields.";
        } else {
            if (empty($id)) {
                // Insert
                $stmt = $pdo->prepare("INSERT INTO ownership (project, support_level, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([$project, $support_level, $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, $username]);
                $new_id = $pdo->lastInsertId();

                // Audit History
                $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                $h_stmt->execute([$new_id, $username, "Created project: $project"]);
                $msg = "Ownership entry created successfully.";
            } else {
                // Update
                $stmt = $pdo->prepare("UPDATE ownership SET project=?, support_level=?, technical_owner=?, technical_owner_email=?, team_dl=?, technical_manager=?, technical_manager_email=?, sdm_name=?, sdm_email=?, ncgr_owner=?, ncgr_owner_email=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->execute([$project, $support_level, $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, $username, $id]);

                // Audit History
                $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                $h_stmt->execute([$id, $username, "Updated project: $project"]);
                $msg = "Ownership entry updated successfully.";
            }
        }
    }

    // Delete Record (Admin Only)
    if ($action_type === 'delete' && $role === 'Admin') {
        $id = $_POST['id'];

        // Fetch project name for audit logs before deleting
        $p_stmt = $pdo->prepare("SELECT project FROM ownership WHERE id = ?");
        $p_stmt->execute([$id]);
        $proj_row = $p_stmt->fetch(PDO::FETCH_ASSOC);
        $proj_name = $proj_row ? $proj_row['project'] : 'Unknown';

        $stmt = $pdo->prepare("DELETE FROM ownership WHERE id = ?");
        $stmt->execute([$id]);

        $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
        $h_stmt->execute([$id, $username, "Deleted project: $proj_name"]);
        $msg = "Ownership entry deleted successfully.";
    }

    // Excel CSV Bulk Upload (Admin Only)
    if ($action_type === 'upload_csv' && $role === 'Admin') {
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['csv_file']['tmp_name'];
            if (($handle = fopen($file_tmp, 'r')) !== FALSE) {
                fgetcsv($handle); // Skip header
                $count = 0;
                while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    if (count($data) >= 12) {
                        $stmt = $pdo->prepare("INSERT INTO ownership (project, support_level, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8], $data[9], $data[10], $data[11] ?? '', $username]);
                        $new_id = $pdo->lastInsertId();

                        $h_stmt = $pdo->prepare("INSERT INTO ownership_history (ownership_id, action_type, performed_by, details) VALUES (?, 'BULK IMPORT', ?, ?)");
                        $h_stmt->execute([$new_id, $username, "Imported via CSV bulk upload"]);
                        $count++;
                    }
                }
                fclose($handle);
                $msg = "Successfully imported $count records from CSV.";
            } else {
                $error = "Failed to read uploaded CSV file.";
            }
        } else {
            $error = "Please upload a valid CSV file.";
        }
    }
}

// 4. Pagination & Advanced Search Filtering setup
$limit = 25;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $limit) - $limit : 0;

$keyword = trim($_GET['keyword'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_support = trim($_GET['s_support'] ?? '');
$s_owner = trim($_GET['s_owner'] ?? '');
$s_manager = trim($_GET['s_manager'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(project LIKE ? OR technical_owner LIKE ? OR ncgr_owner LIKE ? OR team_dl LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if (!empty($s_project)) {
    $where_clauses[] = "project LIKE ?";
    $params[] = "%$s_project%";
}
if (!empty($s_support)) {
    $where_clauses[] = "support_level = ?";
    $params[] = "$s_support";
}
if (!empty($s_owner)) {
    $where_clauses[] = "technical_owner LIKE ?";
    $params[] = "%$s_owner%";
}
if (!empty($s_manager)) {
    $where_clauses[] = "technical_manager LIKE ?";
    $params[] = "%$s_manager%";
}

$where_sql = implode(" AND ", $where_clauses);

// Count total records for pagination
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM ownership WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Fetch paginated data
$data_stmt = $pdo->prepare("SELECT * FROM ownership WHERE $where_sql ORDER BY id DESC LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

$support_levels = ['Production', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox', 'DR', 'POC'];

// Helper: initials for the owner avatar
function ownerInitials($name) {
    $name = trim($name);
    if ($name === '') return '?';
    $parts = preg_split('/\s+/', $name);
    $initials = strtoupper(substr($parts[0], 0, 1));
    if (count($parts) > 1) {
        $initials .= strtoupper(substr(end($parts), 0, 1));
    }
    return $initials;
}

// Used by includes/header.php for the <title> tag
$page_title = "Ownership Registry | InfraVault";

require 'includes/header.php';
?>
<link rel="stylesheet" href="assets/css/ownership.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Ownership Registry</h1>
            <p>Technical, managerial and NCGR ownership contacts for every ITAM project.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                <button type="button" class="btn btn-primary" onclick="openCreateModal()">+ Add New Ownership</button>
            <?php endif; ?>
            <a href="ownership.php?action=export" class="btn">Export CSV</a>
            <?php if ($role === 'Admin'): ?>
                <button type="button" class="btn" onclick="openUploadModal()">Upload CSV</button>
                <button type="button" class="btn" onclick="openGlobalHistoryModal()">Audit History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header" style="margin-bottom:14px;">
            <h3 class="panel-title" style="margin:0;">Search &amp; Filters</h3>
            <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">Advanced &#9662;</span>
        </div>

        <form method="GET" action="ownership.php" style="display:flex;gap:10px;flex-wrap:wrap;">
            <input type="text" name="keyword" class="form-control" style="max-width:320px;" placeholder="Search project, owner, team DL..." value="<?php echo htmlspecialchars($keyword); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if (!empty($keyword) || !empty($s_project) || !empty($s_support) || !empty($s_owner) || !empty($s_manager)): ?>
                <a href="ownership.php" class="btn">Clear</a>
            <?php endif; ?>
        </form>

        <div id="advancedSearchPanel" style="display:<?php echo (!empty($s_project) || !empty($s_support) || !empty($s_owner) || !empty($s_manager)) ? 'block' : 'none'; ?>; margin-top:18px; padding-top:18px; border-top:1px solid #F1F5F9;">
            <form method="GET" action="ownership.php" class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
                <div class="form-group">
                    <label>Project Name</label>
                    <input type="text" name="s_project" class="form-control" value="<?php echo htmlspecialchars($s_project); ?>">
                </div>
                <div class="form-group">
                    <label>Support Level</label>
                    <select name="s_support" class="form-control">
                        <option value="">All Levels</option>
                        <?php foreach ($support_levels as $lvl): ?>
                            <option value="<?php echo $lvl; ?>" <?php if ($s_support == $lvl) echo 'selected'; ?>><?php echo $lvl; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Technical Owner</label>
                    <input type="text" name="s_owner" class="form-control" value="<?php echo htmlspecialchars($s_owner); ?>">
                </div>
                <div class="form-group">
                    <label>Technical Manager</label>
                    <input type="text" name="s_manager" class="form-control" value="<?php echo htmlspecialchars($s_manager); ?>">
                </div>
                <div style="grid-column:1/-1; display:flex; gap:10px;">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="ownership.php" class="btn">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <h3 class="panel-title" style="margin:0;">Ownership Records</h3>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Project</th>
                        <th>Support Level</th>
                        <th>Technical Owner</th>
                        <th>Team DL</th>
                        <th>Technical Manager</th>
                        <th>SDM</th>
                        <th>NCGR Owner</th>
                        <th style="text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                            <tr>
                                <td class="cell-primary"><?php echo htmlspecialchars($r['project']); ?></td>
                                <td>
                                    <?php $badgeClass = 'badge-' . str_replace(' ', '-', $r['support_level']); ?>
                                    <span class="badge <?php echo htmlspecialchars($badgeClass); ?>"><?php echo htmlspecialchars($r['support_level']); ?></span>
                                </td>
                                <td>
                                    <div class="owner-cell">
                                        <div class="owner-avatar"><?php echo ownerInitials($r['technical_owner']); ?></div>
                                        <div>
                                            <?php echo htmlspecialchars($r['technical_owner']); ?>
                                            <span class="cell-sub"><?php echo htmlspecialchars($r['technical_owner_email']); ?></span>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo htmlspecialchars($r['team_dl']); ?></td>
                                <td><?php echo htmlspecialchars($r['technical_manager']); ?></td>
                                <td><?php echo htmlspecialchars($r['sdm_name']); ?></td>
                                <td><?php echo htmlspecialchars($r['ncgr_owner']); ?></td>
                                <td>
                                    <div class="row-actions">
                                        <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                                            <button type="button" class="btn btn-sm btn-primary" onclick='openEditModal(<?php echo json_encode($r); ?>)'>Update</button>
                                        <?php endif; ?>
                                        <?php if ($role === 'Admin'): ?>
                                            <button type="button" class="btn btn-sm btn-danger" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['project'])); ?>')">Delete</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="8"><p class="empty-state">No ownership records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination" style="padding-bottom:22px;">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="ownership.php?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>&s_project=<?php echo urlencode($s_project); ?>&s_support=<?php echo urlencode($s_support); ?>" class="<?php if ($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- CREATE / UPDATE MODAL -->
<div id="recordModal" class="modal-overlay">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle">Add Ownership Entry</h3>
            <button type="button" class="close-modal" onclick="closeModal('recordModal')">&times;</button>
        </div>
        <form method="POST" action="ownership.php">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="rec_id">

            <div class="form-grid">
                <div class="form-group">
                    <label>Project Name *</label>
                    <input type="text" name="project" id="rec_project" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Support Level *</label>
                    <select name="support_level" id="rec_support_level" class="form-control" required>
                        <?php foreach ($support_levels as $lvl): ?>
                            <option value="<?php echo $lvl; ?>"><?php echo $lvl; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Technical Owner</label>
                    <input type="text" name="technical_owner" id="rec_technical_owner" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Owner Email</label>
                    <input type="email" name="technical_owner_email" id="rec_technical_owner_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>Team DL</label>
                    <input type="text" name="team_dl" id="rec_team_dl" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Manager</label>
                    <input type="text" name="technical_manager" id="rec_technical_manager" class="form-control">
                </div>
                <div class="form-group">
                    <label>Technical Manager Email</label>
                    <input type="email" name="technical_manager_email" id="rec_technical_manager_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>SDM Name</label>
                    <input type="text" name="sdm_name" id="rec_sdm_name" class="form-control">
                </div>
                <div class="form-group">
                    <label>SDM Email</label>
                    <input type="email" name="sdm_email" id="rec_sdm_email" class="form-control">
                </div>
                <div class="form-group">
                    <label>NCGR Owner</label>
                    <input type="text" name="ncgr_owner" id="rec_ncgr_owner" class="form-control">
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label>NCGR Owner Email</label>
                    <input type="email" name="ncgr_owner_email" id="rec_ncgr_owner_email" class="form-control">
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('recordModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Record</button>
            </div>
        </form>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content" style="max-width:400px; text-align:center;">
        <div class="modal-header">
            <h3>Confirm Deletion</h3>
            <button type="button" class="close-modal" onclick="closeModal('deleteModal')">&times;</button>
        </div>
        <p style="margin:1rem 0; color:#64748B;">Are you sure you want to delete project: <strong id="del_project_name"></strong>?</p>
        <form method="POST" action="ownership.php">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="del_id">
            <div class="modal-footer" style="justify-content:center;">
                <button type="button" class="btn" onclick="closeModal('deleteModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- GLOBAL HISTORY MODAL -->
<div id="globalHistoryModal" class="modal-overlay">
    <div class="modal-content" style="max-width:800px;">
        <div class="modal-header">
            <h3>Module Audit History (Created, Updated, Deleted)</h3>
            <button type="button" class="close-modal" onclick="closeModal('globalHistoryModal')">&times;</button>
        </div>
        <div id="globalHistoryContent" style="margin-top:1rem; max-height:60vh; overflow-y:auto;">
            <p class="empty-state">Loading audit trails...</p>
        </div>
    </div>
</div>

<!-- UPLOAD CSV MODAL -->
<div id="uploadModal" class="modal-overlay">
    <div class="modal-content" style="max-width:450px;">
        <div class="modal-header">
            <h3>Bulk Upload via CSV</h3>
            <button type="button" class="close-modal" onclick="closeModal('uploadModal')">&times;</button>
        </div>
        <form method="POST" action="ownership.php" enctype="multipart/form-data">
            <input type="hidden" name="form_action" value="upload_csv">
            <p style="font-size:0.85rem; color:#64748B; margin-bottom:1rem;">Upload a CSV file formatted to match the exported column structure.</p>
            <div class="form-group">
                <input type="file" name="csv_file" accept=".csv" class="form-control" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('uploadModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload &amp; Import</button>
            </div>
        </form>
    </div>
</div>

<!-- JavaScript Interactions -->
<script>
    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'Add Ownership Entry';
        document.getElementById('rec_id').value = '';
        document.querySelectorAll('#recordModal input[type="text"], #recordModal input[type="email"]').forEach(i => i.value = '');
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Ownership Entry';
        document.getElementById('rec_id').value = data.id;
        document.getElementById('rec_project').value = data.project;
        document.getElementById('rec_support_level').value = data.support_level;
        document.getElementById('rec_technical_owner').value = data.technical_owner;
        document.getElementById('rec_technical_owner_email').value = data.technical_owner_email;
        document.getElementById('rec_team_dl').value = data.team_dl;
        document.getElementById('rec_technical_manager').value = data.technical_manager;
        document.getElementById('rec_technical_manager_email').value = data.technical_manager_email;
        document.getElementById('rec_sdm_name').value = data.sdm_name;
        document.getElementById('rec_sdm_email').value = data.sdm_email;
        document.getElementById('rec_ncgr_owner').value = data.ncgr_owner;
        document.getElementById('rec_ncgr_owner_email').value = data.ncgr_owner_email;
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openDeleteModal(id, projectName) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_project_name').innerText = projectName;
        document.getElementById('deleteModal').style.display = 'flex';
    }

    function openUploadModal() {
        document.getElementById('uploadModal').style.display = 'flex';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    function openGlobalHistoryModal() {
        document.getElementById('globalHistoryModal').style.display = 'flex';
        document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state">Loading audit history...</p>';

        fetch('ownership.php?action=get_history')
            .then(res => res.text())
            .then(html => {
                document.getElementById('globalHistoryContent').innerHTML = html;
            })
            .catch(() => {
                document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state" style="color:#EF4444;">Failed to load audit history logs.</p>';
            });
    }
</script>

<?php require 'includes/footer.php'; ?>
