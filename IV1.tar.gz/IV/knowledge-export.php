<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


$kb_id =
    (int) ($_GET['id'] ?? 0);


$stmt = $pdo->prepare("
    SELECT
        k.*,
        u.first_name,
        u.last_name,
        u.email,
        u.team
    FROM knowledge_base k
    LEFT JOIN users u
        ON u.id = k.created_by
    WHERE k.id = ?
    LIMIT 1
");

$stmt->execute([
    $kb_id
]);

$kb =
    $stmt->fetch(PDO::FETCH_ASSOC);


if (!$kb) {

    http_response_code(404);

    exit(
        'Knowledge note not found.'
    );
}


/*
|--------------------------------------------------------------------------
| Visibility
|--------------------------------------------------------------------------
*/

$can_view =
    $is_admin ||
    $kb['visibility'] === 'Public' ||
    (int) $kb['created_by'] === $current_user_id;


if (!$can_view) {

    http_response_code(403);

    exit(
        'You do not have permission to export this knowledge note.'
    );
}


/*
|--------------------------------------------------------------------------
| Clean filename
|--------------------------------------------------------------------------
*/

$filename =
    preg_replace(
        '/[^a-zA-Z0-9_-]/',
        '_',
        $kb['kb_number'] . '_' . $kb['title']
    );

$filename .= '.doc';


/*
|--------------------------------------------------------------------------
| Word-compatible HTML
|--------------------------------------------------------------------------
*/

header(
    'Content-Type: application/msword; charset=UTF-8'
);

header(
    'Content-Disposition: attachment; filename="' .
    $filename .
    '"'
);

header(
    'Cache-Control: max-age=0'
);

?>
<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
<?= h($kb['title']) ?>
</title>

<style>

body {
    font-family: Arial, Helvetica, sans-serif;
    color: #222;
    line-height: 1.6;
}

h1 {
    color: #16324f;
    font-size: 24px;
}

h2 {
    color: #16324f;
    border-bottom: 1px solid #ccc;
    padding-bottom: 5px;
}

.metadata {
    background: #f3f5f7;
    padding: 12px;
    margin-bottom: 20px;
}

.metadata table {
    width: 100%;
}

.metadata td {
    padding: 4px 8px;
}

.command,
pre {
    background: #111827;
    color: #f9fafb;
    padding: 12px;
    font-family: Consolas, monospace;
}

img {
    max-width: 650px;
}

a {
    color: #1769aa;
}

</style>

</head>

<body>

<h1>
<?= h($kb['title']) ?>
</h1>


<div class="metadata">

<table>

<tr>

<td>
<strong>KB Number</strong>
</td>

<td>
<?= h($kb['kb_number']) ?>
</td>

</tr>


<tr>

<td>
<strong>Category</strong>
</td>

<td>
<?= h($kb['category']) ?>
</td>

</tr>


<tr>

<td>
<strong>Owner</strong>
</td>

<td>
<?= h(
    trim(
        $kb['first_name'] .
        ' ' .
        $kb['last_name']
    )
) ?>
</td>

</tr>


<tr>

<td>
<strong>Visibility</strong>
</td>

<td>
<?= h($kb['visibility']) ?>
</td>

</tr>


<tr>

<td>
<strong>Version</strong>
</td>

<td>
<?= h($kb['version']) ?>
</td>

</tr>


<tr>

<td>
<strong>Last Updated</strong>
</td>

<td>
<?= h($kb['updated_at']) ?>
</td>

</tr>

</table>

</div>


<?php if (
    trim(
        (string) $kb['description']
    ) !== ''
): ?>

<h2>
Description
</h2>

<p>
<?= nl2br(
    h($kb['description'])
) ?>
</p>

<?php endif; ?>


<h2>
Knowledge
</h2>

<div>

<?= $kb['content_html'] ?>

</div>


</body>

</html>

