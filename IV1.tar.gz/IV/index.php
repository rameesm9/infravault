<?php

session_start();

require_once "config/db.php";

$message = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $ncgr_id  = trim($_POST['ncgr_id']);
    $password = $_POST['password'];


    $stmt = $pdo->prepare("
        SELECT *
        FROM users
        WHERE ncgr_id = ?
        LIMIT 1
    ");

    $stmt->execute([$ncgr_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);


    if ($user) {

        if (password_verify($password, $user['password'])) {


            if ($user['is_approved'] == 1) {


                session_regenerate_id(true);


                $_SESSION['user_id'] = $user['id'];
                $_SESSION['name'] =
                    $user['first_name']." ".$user['last_name'];

                $_SESSION['role'] = $user['role'];


                header("Location: home.php");
                exit;


            } else {

                $message =
                "Your account is waiting for administrator approval.";

            }


        } else {

            $message = "Invalid password.";

        }


    } else {

        $message = "User not found.";

    }

}


?>


<!DOCTYPE html>

<html>

<head>

<meta charset="UTF-8">

<title>
InfraVault Login
</title>


<style>


@font-face{

font-family:Inter;

src:url("assets/webfonts/Inter-Regular.woff2");

}


*{

box-sizing:border-box;

}


body{

margin:0;

height:100vh;

background:
linear-gradient(
135deg,
#020617,
#172554
);

font-family:Inter,Segoe UI,sans-serif;

display:flex;

align-items:center;

justify-content:center;

}



.container{

width:1000px;

height:600px;

display:flex;

border-radius:25px;

overflow:hidden;

background:white;

box-shadow:
0 30px 80px rgba(0,0,0,.5);

}



.brand{

width:50%;

padding:60px;

background:
linear-gradient(
160deg,
#0F172A,
#1E3A8A
);

color:white;

}



.logo{

width:120px;

}



.brand h1{

font-size:44px;

color:#38BDF8;

margin:25px 0 10px;

}



.brand p{

font-size:18px;

color:#CBD5E1;

}



.info{

margin-top:45px;

}



.info div{

margin:18px 0;

color:#E2E8F0;

}



.login{

width:50%;

padding:70px 60px;

}



.login h2{

font-size:32px;

color:#0F172A;

margin-bottom:10px;

}


.login small{

color:#64748B;

}



.error{

background:#FEE2E2;

color:#991B1B;

padding:12px;

border-radius:8px;

margin:20px 0;

}



label{

display:block;

margin-top:20px;

font-weight:bold;

color:#334155;

}



input{

width:100%;

padding:14px;

margin-top:8px;

border-radius:10px;

border:1px solid #CBD5E1;

}



button{

width:100%;

margin-top:30px;

padding:15px;

border:none;

border-radius:10px;

background:#2563EB;

color:white;

font-size:16px;

cursor:pointer;

}



button:hover{

background:#1D4ED8;

}



.signup{

text-align:center;

margin-top:25px;

}



.signup a{

color:#2563EB;

text-decoration:none;

font-weight:bold;

}



</style>


</head>


<body>



<div class="container">


<div class="brand">


<img class="logo"
src="assets/images/infravault-logo.svg">


<h1>
InfraVault
</h1>


<p>
Enterprise IT Inventory Management
</p>


<div class="info">

<div>
🛡 Secure Asset Management
</div>

<div>
🖥 Infrastructure Control
</div>

<div>
🔒 Offline Enterprise Platform
</div>


</div>


</div>




<div class="login">


<h2>
Welcome Back
</h2>


<small>
Sign in to your InfraVault account
</small>



<?php if($message): ?>

<div class="error">

<?=htmlspecialchars($message);?>

</div>

<?php endif; ?>



<form method="POST">


<label>
NCGR ID
</label>

<input
type="text"
name="ncgr_id"
required
>



<label>
Password
</label>

<input
type="password"
name="password"
required
>


<button>
SIGN IN
</button>


</form>


<div class="signup">

<a href="signup.php">
Create New Account
</a>


</div>


</div>


</div>


</body>

</html>
