<?php
require 'config/db.php';
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');
$username = $_SESSION['first_name'] . ' (' . $_SESSION['ncgr_id'] . ')';
$msg = "";
$error = "";

// 1. Handle Export CSV Action
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=asset_export_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');

    // CSV Header matching fields
    fputcsv($output, [
        'ID', 'Asset Name', 'Asset Type', 'Manufacturer', 'Model', 'Serial Number', 'Service Tag',
        'Hostname', 'IP Address', 'Location', 'Site', 'Region', 'Room', 'Row', 'Rack',
        'CPU Model', 'CPU Count', 'Total Cores', 'Memory (GB)', 'Internal Storage', 'Number of NICs',
        'HBA Details', 'GPU Details', 'VLAN', 'Purchase Date', 'Vendor', 'Warranty Start Date',
        'Warranty Expiry Date', 'Support Vendor', 'Status', 'End-of-Life', 'Remarks', 'Created By', 'Created At'
    ]);

    $rows = $pdo->query("SELECT * FROM asset")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $row) {
        fputcsv($output, $row);
    }
    fclose($output);
    exit;
}

// 2. Handle Global History AJAX Call
if (isset($_GET['action']) && $_GET['action'] === 'get_history' && $role === 'Admin') {
    $stmt = $pdo->query("SELECT * FROM asset_history ORDER BY timestamp DESC");
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table class="audit-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $badge_color = 'background:#e2e8f0;color:#1e293b;';
            if ($log['action_type'] === 'CREATED') $badge_color = 'background:#dcfce7;color:#166534;';
            if ($log['action_type'] === 'DELETED') $badge_color = 'background:#fee2e2;color:#991b1b;';
            if ($log['action_type'] === 'UPDATED') $badge_color = 'background:#fef9c3;color:#854d0e;';

            echo '<tr>';
            echo '<td><span class="audit-badge" style="' . $badge_color . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td>' . htmlspecialchars($log['details']) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">No audit history records found.</p>';
    }
    exit;
}

// 3. Handle Form Submissions (Create, Update, Delete, Bulk Upload)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    // Create or Update Record
    if ($action_type === 'save' && ($role === 'Admin' || $role === 'Edit')) {
        $id = $_POST['id'] ?? '';
        $asset_name = trim($_POST['asset_name']);
        $asset_type = trim($_POST['asset_type']);
        $manufacturer = trim($_POST['manufacturer']);
        $model = trim($_POST['model']);
        $serial_number = trim($_POST['serial_number']);
        $service_tag = trim($_POST['service_tag']);
        $hostname = trim($_POST['hostname']);
        $ip_address = trim($_POST['ip_address']);
        $location = trim($_POST['location']);
        $site = trim($_POST['site']);
        $region = trim($_POST['region']);
        $room = trim($_POST['room']);
        $row = trim($_POST['row']);
        $rack = trim($_POST['rack']);
        $cpu_model = trim($_POST['cpu_model']);
        $cpu_count = trim($_POST['cpu_count']);
        $total_cores = trim($_POST['total_cores']);
        $memory_gb = trim($_POST['memory_gb']);
        $internal_storage = trim($_POST['internal_storage']);
        $number_of_nics = trim($_POST['number_of_nics']);
        $hba_details = trim($_POST['hba_details']);
        $gpu_details = trim($_POST['gpu_details']);
        $vlan = trim($_POST['vlan']);
        $purchase_date = trim($_POST['purchase_date']);
        $vendor = trim($_POST['vendor']);
        $warranty_start_date = trim($_POST['warranty_start_date']);
        $warranty_expiry_date = trim($_POST['warranty_expiry_date']);
        $support_vendor = trim($_POST['support_vendor']);
        $status = trim($_POST['status']);
        $end_of_life = trim($_POST['end_of_life']);
        $remarks = trim($_POST['remarks']);

        if (empty($asset_name) || empty($asset_type)) {
            $error = "Asset Name and Asset Type are required fields.";
        } else {
            if (empty($id)) {
                // Insert
                $stmt = $pdo->prepare("INSERT INTO asset (asset_name, asset_type, manufacturer, model, serial_number, service_tag, hostname, ip_address, location, site, region, room, row, rack, cpu_model, cpu_count, total_cores, memory_gb, internal_storage, number_of_nics, hba_details, gpu_details, vlan, purchase_date, vendor, warranty_start_date, warranty_expiry_date, support_vendor, status, end_of_life, remarks, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $asset_name, $asset_type, $manufacturer, $model, $serial_number, $service_tag,
                    $hostname, $ip_address, $location, $site, $region, $room, $row, $rack,
                    $cpu_model, $cpu_count, $total_cores, $memory_gb, $internal_storage, $number_of_nics,
                    $hba_details, $gpu_details, $vlan, $purchase_date, $vendor, $warranty_start_date,
                    $warranty_expiry_date, $support_vendor, $status, $end_of_life, $remarks, $username
                ]);
                $new_id = $pdo->lastInsertId();

                // Audit History
                $h_stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                $h_stmt->execute([$new_id, $username, "Created asset: $asset_name"]);
                $msg = "Asset record created successfully.";
            } else {
                // Update
                $stmt = $pdo->prepare("UPDATE asset SET asset_name=?, asset_type=?, manufacturer=?, model=?, serial_number=?, service_tag=?, hostname=?, ip_address=?, location=?, site=?, region=?, room=?, row=?, rack=?, cpu_model=?, cpu_count=?, total_cores=?, memory_gb=?, internal_storage=?, number_of_nics=?, hba_details=?, gpu_details=?, vlan=?, purchase_date=?, vendor=?, warranty_start_date=?, warranty_expiry_date=?, support_vendor=?, status=?, end_of_life=?, remarks=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                $stmt->execute([
                    $asset_name, $asset_type, $manufacturer, $model, $serial_number, $service_tag,
                    $hostname, $ip_address, $location, $site, $region, $room, $row, $rack,
                    $cpu_model, $cpu_count, $total_cores, $memory_gb, $internal_storage, $number_of_nics,
                    $hba_details, $gpu_details, $vlan, $purchase_date, $vendor, $warranty_start_date,
                    $warranty_expiry_date, $support_vendor, $status, $end_of_life, $remarks, $username, $id
                ]);

                // Audit History
                $h_stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                $h_stmt->execute([$id, $username, "Updated asset: $asset_name"]);
                $msg = "Asset record updated successfully.";
            }
        }
    }

    // Delete Record (Admin Only)
    if ($action_type === 'delete' && $role === 'Admin') {
        $id = $_POST['id'];

        $p_stmt = $pdo->prepare("SELECT asset_name FROM asset WHERE id = ?");
        $p_stmt->execute([$id]);
        $asset_row = $p_stmt->fetch(PDO::FETCH_ASSOC);
        $asset_name = $asset_row ? $asset_row['asset_name'] : 'Unknown';

        $stmt = $pdo->prepare("DELETE FROM asset WHERE id = ?");
        $stmt->execute([$id]);

        $h_stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
        $h_stmt->execute([$id, $username, "Deleted asset: $asset_name"]);
        $msg = "Asset record deleted successfully.";
    }

    // Excel CSV Bulk Upload (Admin Only)
    if ($action_type === 'upload_csv' && $role === 'Admin') {
        if (isset($_FILES['csv_file']) && $_FILES['csv_file']['error'] === UPLOAD_ERR_OK) {
            $file_tmp = $_FILES['csv_file']['tmp_name'];
            if (($handle = fopen($file_tmp, 'r')) !== FALSE) {
                fgetcsv($handle); // Skip header row
                $count = 0;
                while (($data = fgetcsv($handle, 1000, ',')) !== FALSE) {
                    if (count($data) >= 31) {
                        $stmt = $pdo->prepare("INSERT INTO asset (asset_name, asset_type, manufacturer, model, serial_number, service_tag, hostname, ip_address, location, site, region, room, row, rack, cpu_model, cpu_count, total_cores, memory_gb, internal_storage, number_of_nics, hba_details, gpu_details, vlan, purchase_date, vendor, warranty_start_date, warranty_expiry_date, support_vendor, status, end_of_life, remarks, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([
                            $data[1], $data[2], $data[3], $data[4], $data[5], $data[6], $data[7], $data[8],
                            $data[9], $data[10], $data[11], $data[12], $data[13], $data[14], $data[15], $data[16],
                            $data[17], $data[18], $data[19], $data[20], $data[21], $data[22], $data[23], $data[24],
                            $data[25], $data[26], $data[27], $data[28], $data[29], $data[30], $data[31] ?? '', $username
                        ]);
                        $new_id = $pdo->lastInsertId();

                        $h_stmt = $pdo->prepare("INSERT INTO asset_history (asset_id, action_type, performed_by, details) VALUES (?, 'BULK IMPORT', ?, ?)");
                        $h_stmt->execute([$new_id, $username, "Imported via CSV bulk upload"]);
                        $count++;
                    }
                }
                fclose($handle);
                $msg = "Successfully imported $count records from CSV.";
            } else {
                $error = "Failed to read uploaded CSV file.";
            }
        } else {
            $error = "Please upload a valid CSV file.";
        }
    }
}

// 4. Pagination & Search setup
$limit = 25;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $limit) - $limit : 0;

$keyword = trim($_GET['keyword'] ?? '');
$s_name = trim($_GET['s_name'] ?? '');
$s_type = trim($_GET['s_type'] ?? '');
$s_status = trim($_GET['s_status'] ?? '');
$s_ip = trim($_GET['s_ip'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(asset_name LIKE ? OR hostname LIKE ? OR ip_address LIKE ? OR serial_number LIKE ?)";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
    $params[] = "%$keyword%";
}

if (!empty($s_name)) {
    $where_clauses[] = "asset_name LIKE ?";
    $params[] = "%$s_name%";
}
if (!empty($s_type)) {
    $where_clauses[] = "asset_type = ?";
    $params[] = "$s_type";
}
if (!empty($s_status)) {
    $where_clauses[] = "status = ?";
    $params[] = "$s_status";
}
if (!empty($s_ip)) {
    $where_clauses[] = "ip_address LIKE ?";
    $params[] = "%$s_ip%";
}

$where_sql = implode(" AND ", $where_clauses);

// Count total records for pagination
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM asset WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = ceil($total_records / $limit);

// Fetch paginated data
$data_stmt = $pdo->prepare("SELECT * FROM asset WHERE $where_sql ORDER BY id DESC LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

$asset_types = ['Server', 'Switch', 'Storage', 'Firewall', 'PDU', 'UPS', 'Others'];
$status_options = ['In Service', 'Standby', 'Decommissioned'];
$eol_options = ['yes', 'no'];

// All asset table columns available for the "Customize Fields" picker.
// Key => Column label. Order here controls column order in the table.
$asset_columns = [
    'asset_name'            => 'Asset Name',
    'asset_type'             => 'Type',
    'manufacturer'           => 'Manufacturer',
    'model'                  => 'Model',
    'serial_number'          => 'Serial Number',
    'service_tag'            => 'Service Tag',
    'hostname'               => 'Hostname',
    'ip_address'             => 'IP Address',
    'location'               => 'Location',
    'site'                   => 'Site',
    'region'                 => 'Region',
    'room'                   => 'Room',
    'row'                    => 'Row',
    'rack'                   => 'Rack',
    'cpu_model'              => 'CPU Model',
    'cpu_count'              => 'CPU Count',
    'total_cores'            => 'Total Cores',
    'memory_gb'              => 'Memory (GB)',
    'internal_storage'       => 'Internal Storage',
    'number_of_nics'         => 'NICs',
    'hba_details'            => 'HBA Details',
    'gpu_details'            => 'GPU Details',
    'vlan'                   => 'VLAN',
    'purchase_date'          => 'Purchase Date',
    'vendor'                 => 'Vendor',
    'warranty_start_date'    => 'Warranty Start',
    'warranty_expiry_date'   => 'Warranty Expiry',
    'support_vendor'         => 'Support Vendor',
    'status'                 => 'Status',
    'end_of_life'            => 'EOL',
    'remarks'                => 'Remarks',
];

// Columns visible by default; the rest are available via "Customize Fields".
$default_visible_columns = ['asset_name', 'asset_type', 'manufacturer', 'model', 'hostname', 'ip_address', 'location', 'status', 'end_of_life'];

// Used by includes/header.php for the <title> tag
$page_title = "Asset Inventory | InfraVault";

require 'includes/header.php';
?>
<link rel="stylesheet" href="assets/css/asset.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Hardware Asset Inventory</h1>
            <p>Track servers, network hardware, and their lifecycle status across sites.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                <button type="button" class="btn btn-success" onclick="openCreateModal()">
                    <i class="fas fa-plus-circle"></i> Add Asset
                </button>
            <?php endif; ?>

            <a href="asset.php?action=export" class="btn btn-info">
                <i class="fas fa-file-export"></i> Export CSV
            </a>

            <?php if ($role === 'Admin'): ?>
                <button type="button" class="btn btn-warning" onclick="openUploadModal()">
                    <i class="fas fa-upload"></i> Upload CSV
                </button>

                <button type="button" class="btn btn-dark" onclick="openGlobalHistoryModal()">
                    <i class="fas fa-history"></i> Audit History
                </button>
            <?php endif; ?>

            <button type="button" class="btn btn-secondary" onclick="openColumnsModal()">
                <i class="fas fa-sliders-h"></i> Customize Fields
            </button>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header" style="margin-bottom:14px;">
            <h3 class="panel-title" style="margin:0;">Search &amp; Filters</h3>
            <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">Advanced &#9662;</span>
        </div>

        <form method="GET" action="asset.php" style="display:flex;gap:10px;flex-wrap:wrap;">
            <input type="text" name="keyword" class="form-control" style="max-width:320px;" placeholder="Search asset name, hostname, IP, serial..." value="<?php echo htmlspecialchars($keyword); ?>">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if (!empty($keyword) || !empty($s_name) || !empty($s_type) || !empty($s_status) || !empty($s_ip)): ?>
                <a href="asset.php" class="btn">Clear</a>
            <?php endif; ?>
        </form>

        <div id="advancedSearchPanel" style="display:<?php echo (!empty($s_name) || !empty($s_type) || !empty($s_status) || !empty($s_ip)) ? 'block' : 'none'; ?>; margin-top:18px; padding-top:18px; border-top:1px solid #F1F5F9;">
            <form method="GET" action="asset.php" class="form-grid" style="grid-template-columns:repeat(auto-fit,minmax(200px,1fr));">
                <div class="form-group">
                    <label>Asset Name</label>
                    <input type="text" name="s_name" class="form-control" value="<?php echo htmlspecialchars($s_name); ?>">
                </div>
                <div class="form-group">
                    <label>Asset Type</label>
                    <select name="s_type" class="form-control">
                        <option value="">All Types</option>
                        <?php foreach ($asset_types as $t): ?>
                            <option value="<?php echo $t; ?>" <?php if ($s_type == $t) echo 'selected'; ?>><?php echo $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="s_status" class="form-control">
                        <option value="">All Statuses</option>
                        <?php foreach ($status_options as $stat): ?>
                            <option value="<?php echo $stat; ?>" <?php if ($s_status == $stat) echo 'selected'; ?>><?php echo $stat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>IP Address</label>
                    <input type="text" name="s_ip" class="form-control" value="<?php echo htmlspecialchars($s_ip); ?>">
                </div>
                <div style="grid-column:1/-1; display:flex; gap:10px;">
                    <button type="submit" class="btn btn-primary">Apply Filters</button>
                    <a href="asset.php" class="btn">Reset</a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <h3 class="panel-title" style="margin:0;">Asset Records</h3>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table" id="assetTable">
                <thead>
                    <tr>
                        <?php foreach ($asset_columns as $col_key => $col_label): ?>
                            <th class="col-th-<?php echo $col_key; ?> <?php echo in_array($col_key, $default_visible_columns) ? '' : 'hidden-col'; ?>"><?php echo htmlspecialchars($col_label); ?></th>
                        <?php endforeach; ?>
                        <th style="text-align:right;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                            <tr>
                                <?php foreach ($asset_columns as $col_key => $col_label): ?>
                                    <td class="col-td-<?php echo $col_key; ?> <?php echo in_array($col_key, $default_visible_columns) ? '' : 'hidden-col'; ?>">
                                        <?php if ($col_key === 'asset_name'): ?>
                                            <span class="cell-primary"><?php echo htmlspecialchars($r['asset_name']); ?></span>
                                        <?php elseif ($col_key === 'asset_type'): ?>
                                            <span class="badge"><?php echo htmlspecialchars($r['asset_type']); ?></span>
                                        <?php elseif ($col_key === 'status'): ?>
                                            <?php $statusClass = 'badge-' . str_replace(' ', '', $r['status']); ?>
                                            <span class="badge <?php echo htmlspecialchars($statusClass); ?>"><?php echo htmlspecialchars($r['status']); ?></span>
                                        <?php elseif ($col_key === 'end_of_life'): ?>
                                            <?php if (strtolower($r['end_of_life']) === 'yes'): ?>
                                                <span class="eol-yes">Yes</span>
                                            <?php else: ?>
                                                <span class="eol-no"><?php echo htmlspecialchars($r['end_of_life'] ?: 'No'); ?></span>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <?php echo htmlspecialchars($r[$col_key] ?? ''); ?>
                                        <?php endif; ?>
                                    </td>
                                <?php endforeach; ?>
                                <td style="text-align: center; white-space: nowrap;">
                                    <div class="row-actions">
                                        <button type="button" class="btn btn-secondary btn-sm" onclick='openViewModal(<?php echo json_encode($r); ?>)'>
                                            <i class="fas fa-eye"></i> View
                                        </button>

                                        <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                                            <button type="button" class="btn btn-primary btn-sm" onclick='openEditModal(<?php echo json_encode($r); ?>)'>
                                                <i class="fas fa-pen"></i> Update
                                            </button>
                                        <?php endif; ?>

                                        <?php if ($role === 'Admin'): ?>
                                            <button type="button" class="btn btn-danger btn-sm" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['asset_name'])); ?>')">
                                                <i class="fas fa-trash"></i> Delete
                                            </button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="<?php echo count($asset_columns) + 1; ?>"><p class="empty-state">No hardware asset records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination" style="padding-bottom:22px;">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="asset.php?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>&s_name=<?php echo urlencode($s_name); ?>&s_type=<?php echo urlencode($s_type); ?>" class="<?php if ($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- CREATE / UPDATE MODAL -->
<div id="recordModal" class="modal-overlay">
    <div class="modal-content" style="max-width:900px;">
        <div class="modal-header">
            <h3 id="modalTitle">Add Asset Record</h3>
            <button type="button" class="close-modal" onclick="closeModal('recordModal')">&times;</button>
        </div>
        <form method="POST" action="asset.php">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="rec_id">

            <div class="form-grid-3">
                <div class="form-group">
                    <label>Asset Name *</label>
                    <input type="text" name="asset_name" id="rec_asset_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Asset Type *</label>
                    <select name="asset_type" id="rec_asset_type" class="form-control" required>
                        <?php foreach ($asset_types as $t): ?>
                            <option value="<?php echo $t; ?>"><?php echo $t; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>Manufacturer</label>
                    <input type="text" name="manufacturer" id="rec_manufacturer" class="form-control">
                </div>
                <div class="form-group">
                    <label>Model</label>
                    <input type="text" name="model" id="rec_model" class="form-control">
                </div>
                <div class="form-group">
                    <label>Serial Number</label>
                    <input type="text" name="serial_number" id="rec_serial_number" class="form-control">
                </div>
                <div class="form-group">
                    <label>Service Tag</label>
                    <input type="text" name="service_tag" id="rec_service_tag" class="form-control">
                </div>
                <div class="form-group">
                    <label>Hostname</label>
                    <input type="text" name="hostname" id="rec_hostname" class="form-control">
                </div>
                <div class="form-group">
                    <label>IP Address</label>
                    <input type="text" name="ip_address" id="rec_ip_address" class="form-control">
                </div>
                <div class="form-group">
                    <label>Location</label>
                    <input type="text" name="location" id="rec_location" class="form-control">
                </div>
                <div class="form-group">
                    <label>Site</label>
                    <input type="text" name="site" id="rec_site" class="form-control">
                </div>
                <div class="form-group">
                    <label>Region</label>
                    <input type="text" name="region" id="rec_region" class="form-control">
                </div>
                <div class="form-group">
                    <label>Room</label>
                    <input type="text" name="room" id="rec_room" class="form-control">
                </div>
                <div class="form-group">
                    <label>Row</label>
                    <input type="text" name="row" id="rec_row" class="form-control">
                </div>
                <div class="form-group">
                    <label>Rack</label>
                    <input type="text" name="rack" id="rec_rack" class="form-control">
                </div>
                <div class="form-group">
                    <label>CPU Model</label>
                    <input type="text" name="cpu_model" id="rec_cpu_model" class="form-control">
                </div>
                <div class="form-group">
                    <label>CPU Count</label>
                    <input type="text" name="cpu_count" id="rec_cpu_count" class="form-control">
                </div>
                <div class="form-group">
                    <label>Total Cores</label>
                    <input type="text" name="total_cores" id="rec_total_cores" class="form-control">
                </div>
                <div class="form-group">
                    <label>Memory (GB)</label>
                    <input type="text" name="memory_gb" id="rec_memory_gb" class="form-control">
                </div>
                <div class="form-group">
                    <label>Internal Storage</label>
                    <input type="text" name="internal_storage" id="rec_internal_storage" class="form-control">
                </div>
                <div class="form-group">
                    <label>Number of NICs</label>
                    <input type="text" name="number_of_nics" id="rec_number_of_nics" class="form-control">
                </div>
                <div class="form-group">
                    <label>HBA Details</label>
                    <input type="text" name="hba_details" id="rec_hba_details" class="form-control">
                </div>
                <div class="form-group">
                    <label>GPU Details</label>
                    <input type="text" name="gpu_details" id="rec_gpu_details" class="form-control">
                </div>
                <div class="form-group">
                    <label>VLAN</label>
                    <input type="text" name="vlan" id="rec_vlan" class="form-control">
                </div>
                <div class="form-group">
                    <label>Purchase Date</label>
                    <input type="date" name="purchase_date" id="rec_purchase_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>Vendor</label>
                    <input type="text" name="vendor" id="rec_vendor" class="form-control">
                </div>
                <div class="form-group">
                    <label>Warranty Start Date</label>
                    <input type="date" name="warranty_start_date" id="rec_warranty_start_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>Warranty Expiry Date</label>
                    <input type="date" name="warranty_expiry_date" id="rec_warranty_expiry_date" class="form-control">
                </div>
                <div class="form-group">
                    <label>Support Vendor</label>
                    <input type="text" name="support_vendor" id="rec_support_vendor" class="form-control">
                </div>
                <div class="form-group">
                    <label>Status</label>
                    <select name="status" id="rec_status" class="form-control">
                        <?php foreach ($status_options as $stat): ?>
                            <option value="<?php echo $stat; ?>"><?php echo $stat; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label>End-of-Life (yes/no)</label>
                    <select name="end_of_life" id="rec_end_of_life" class="form-control">
                        <?php foreach ($eol_options as $eol): ?>
                            <option value="<?php echo $eol; ?>"><?php echo $eol; ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group" style="grid-column:1/-1;">
                    <label>Remarks</label>
                    <textarea name="remarks" id="rec_remarks" class="form-control" rows="2"></textarea>
                </div>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('recordModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Asset</button>
            </div>
        </form>
    </div>
</div>

<!-- VIEW MODAL (available to all users) -->
<div id="viewModal" class="modal-overlay">
    <div class="modal-content" style="max-width:700px;">
        <div class="modal-header">
            <h3>Asset Details</h3>
            <button type="button" class="close-modal" onclick="closeModal('viewModal')">&times;</button>
        </div>

        <div class="view-grid">
            <div class="view-item"><label>Asset Name</label><span id="v_asset_name"></span></div>
            <div class="view-item"><label>Type</label><span id="v_asset_type"></span></div>
            <div class="view-item"><label>Manufacturer</label><span id="v_manufacturer"></span></div>
            <div class="view-item"><label>Model</label><span id="v_model"></span></div>
            <div class="view-item"><label>Hostname</label><span id="v_hostname"></span></div>
            <div class="view-item"><label>IP Address</label><span id="v_ip_address"></span></div>
            <div class="view-item"><label>Serial Number</label><span id="v_serial_number"></span></div>
            <div class="view-item"><label>Service Tag</label><span id="v_service_tag"></span></div>
            <div class="view-item"><label>Location</label><span id="v_location"></span></div>
            <div class="view-item"><label>Rack</label><span id="v_rack"></span></div>
            <div class="view-item"><label>Status</label><span id="v_status"></span></div>
            <div class="view-item"><label>Warranty Expiry</label><span id="v_warranty_expiry_date"></span></div>
            <div class="view-item full"><label>Remarks</label><span id="v_remarks"></span></div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn" onclick="closeModal('viewModal')">Close</button>
        </div>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content" style="max-width:400px; text-align:center;">
        <div class="modal-header">
            <h3>Confirm Deletion</h3>
            <button type="button" class="close-modal" onclick="closeModal('deleteModal')">&times;</button>
        </div>
        <p style="margin:1rem 0; color:#64748B;">Are you sure you want to delete asset: <strong id="del_asset_name"></strong>?</p>
        <form method="POST" action="asset.php">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="del_id">
            <div class="modal-footer" style="justify-content:center;">
                <button type="button" class="btn" onclick="closeModal('deleteModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Yes, Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- GLOBAL HISTORY MODAL -->
<div id="globalHistoryModal" class="modal-overlay">
    <div class="modal-content" style="max-width:800px;">
        <div class="modal-header">
            <h3>Asset Audit History (Created, Updated, Deleted)</h3>
            <button type="button" class="close-modal" onclick="closeModal('globalHistoryModal')">&times;</button>
        </div>
        <div id="globalHistoryContent" style="margin-top:1rem; max-height:60vh; overflow-y:auto;">
            <p class="empty-state">Loading audit trails...</p>
        </div>
    </div>
</div>

<!-- UPLOAD CSV MODAL -->
<div id="uploadModal" class="modal-overlay">
    <div class="modal-content" style="max-width:450px;">
        <div class="modal-header">
            <h3>Bulk Upload via CSV</h3>
            <button type="button" class="close-modal" onclick="closeModal('uploadModal')">&times;</button>
        </div>
        <form method="POST" action="asset.php" enctype="multipart/form-data">
            <input type="hidden" name="form_action" value="upload_csv">
            <p style="font-size:0.85rem; color:#64748B; margin-bottom:1rem;">Upload a CSV file formatted to match the exported column structure.</p>
            <div class="form-group">
                <input type="file" name="csv_file" accept=".csv" class="form-control" required>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('uploadModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Upload &amp; Import</button>
            </div>
        </form>
    </div>
</div>

<!-- CUSTOMIZE FIELDS MODAL -->
<div id="columnsModal" class="modal-overlay">
    <div class="modal-content" style="max-width:550px;">
        <div class="modal-header">
            <h3>Customize Visible Fields</h3>
            <button type="button" class="close-modal" onclick="closeModal('columnsModal')">&times;</button>
        </div>
        <div style="display:grid; grid-template-columns:1fr 1fr; gap:0.6rem; max-height:50vh; overflow-y:auto; padding-right:0.5rem;">
            <?php foreach ($asset_columns as $col_key => $col_label):
                $is_checked = in_array($col_key, $default_visible_columns) ? 'checked' : '';
            ?>
                <label style="font-size:0.85rem; display:flex; align-items:center; gap:0.4rem;">
                    <input type="checkbox" <?php echo $is_checked; ?> onchange="toggleCol('<?php echo $col_key; ?>', this.checked)"> <?php echo htmlspecialchars($col_label); ?>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="closeModal('columnsModal')">Done</button>
        </div>
    </div>
</div>

<!-- JavaScript Interactions -->
<script>
    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'Add Asset Record';
        document.getElementById('rec_id').value = '';
        document.querySelectorAll('#recordModal input[type="text"], #recordModal input[type="date"], #recordModal textarea').forEach(i => i.value = '');
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Asset Record';
        document.getElementById('rec_id').value = data.id;

        // Loop through keys and fill form inputs dynamically based on ID prefixes
        for (const key in data) {
            const el = document.getElementById('rec_' + key);
            if (el) {
                el.value = data[key] !== null ? data[key] : '';
            }
        }

        document.getElementById('recordModal').style.display = 'flex';
    }

    function openViewModal(data) {
        const fields = ['asset_name', 'asset_type', 'manufacturer', 'model', 'hostname', 'ip_address', 'serial_number', 'service_tag', 'location', 'rack', 'status', 'warranty_expiry_date', 'remarks'];
        fields.forEach(key => {
            const el = document.getElementById('v_' + key);
            if (el) {
                el.textContent = (data[key] !== null && data[key] !== undefined && data[key] !== '') ? data[key] : '';
            }
        });
        document.getElementById('viewModal').style.display = 'flex';
    }

    function openDeleteModal(id, assetName) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_asset_name').innerText = assetName;
        document.getElementById('deleteModal').style.display = 'flex';
    }

    function openUploadModal() {
        document.getElementById('uploadModal').style.display = 'flex';
    }

    function openColumnsModal() {
        document.getElementById('columnsModal').style.display = 'flex';
    }

    function closeModal(modalId) {
        document.getElementById(modalId).style.display = 'none';
    }

    function toggleCol(colKey, show) {
        document.querySelectorAll('.col-th-' + colKey + ', .col-td-' + colKey).forEach(el => {
            el.classList.toggle('hidden-col', !show);
        });
    }

    function openGlobalHistoryModal() {
        document.getElementById('globalHistoryModal').style.display = 'flex';
        document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state">Loading audit history...</p>';

        fetch('asset.php?action=get_history')
            .then(res => res.text())
            .then(html => {
                document.getElementById('globalHistoryContent').innerHTML = html;
            })
            .catch(() => {
                document.getElementById('globalHistoryContent').innerHTML = '<p class="empty-state" style="color:#EF4444;">Failed to load audit history logs.</p>';
            });
    }
</script>

<?php require 'includes/footer.php'; ?>
