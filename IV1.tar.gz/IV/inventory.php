<?php
session_start();
require 'config/db.php';
$_SESSION['first_name'] = $user['first_name'];
$_SESSION['ncgr_id'] = $user['ncgr_id'];

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');
$username = $_SESSION['first_name'] . ' (' . $_SESSION['ncgr_id'] . ')';
$msg = "";
$error = "";

// 5. AJAX HW Model Lookup from asset table (Asset Name search) - MUST BE HANDLED BEFORE HTML OUTPUT
if (isset($_GET['action']) && $_GET['action'] === 'search_hardware') {
    header('Content-Type: application/json');
    $q = trim($_GET['q'] ?? '');
    try {
        // SQLite-compatible search on asset table including location
        $stmt = $pdo->prepare("SELECT asset_name, manufacturer, model, location FROM asset WHERE asset_name LIKE :q OR model LIKE :q LIMIT 15");
        $stmt->execute([':q' => '%' . $q . '%']);
        $results = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $output = [];
        foreach ($results as $row) {
            $output[] = [
                'asset_name' => $row['asset_name'] ?? '',
                'manufacturer' => $row['manufacturer'] ?? ($row['model'] ?? 'N/A'),
                'location' => $row['location'] ?? ''
            ];
        }
        echo json_encode($output);
    } catch (Exception $e) {
        echo json_encode([]);
    }
    exit;
}

// Helper: Match IP address to IP range table (ip.php / ip_ranges) to auto-populate port group and VLAN
function lookupIPDetails($pdo, $ip) {
    if (empty($ip)) return ['port_group' => '', 'vlan' => ''];
    $ranges = $pdo->query("SELECT ip_range, portgroup, vlan FROM ip_ranges")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($ranges as $r) {
        $subnet_base = substr($r['ip_range'], 0, strrpos($r['ip_range'], '.'));
        if (strpos($ip, $subnet_base) === 0) {
            return ['port_group' => $r['portgroup'], 'vlan' => $r['vlan']];
        }
    }
    return ['port_group' => '', 'vlan' => ''];
}

// Helper: Fetch Ownership details based on project and support level match
function lookupOwnershipDetails($pdo, $project, $support_level) {
    $stmt = $pdo->prepare("SELECT * FROM ownership WHERE project = ? AND support_level = ? LIMIT 1");
    $stmt->execute([$project, $support_level]);
    $own = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($own) {
        return [
            'technical_owner' => $own['technical_owner'],
            'technical_owner_email' => $own['technical_owner_email'],
            'team_dl' => $own['team_dl'],
            'technical_manager' => $own['technical_manager'],
            'technical_manager_email' => $own['technical_manager_email'],
            'sdm_name' => $own['sdm_name'],
            'sdm_email' => $own['sdm_email'],
            'ncgr_owner' => $own['ncgr_owner'],
            'ncgr_owner_email' => $own['ncgr_owner_email']
        ];
    }
    return [];
}

// All inventory columns definition map
$inventory_columns = [
    'hostname' => 'Hostname',
    'ip_address' => 'IP Address',
    'additional_ips' => 'Additional IPs',
    'os_family' => 'OS Family',
    'os_version' => 'OS Version',
    'kernel_version' => 'Kernel Version',
    'cpu' => 'CPU',
    'memory' => 'Memory',
    'support_level' => 'Support Level',
    'server_state' => 'Server State',
    'domain' => 'Domain',
    'joined_in' => 'Joined In',
    'role' => 'Role',
    'cluster_name' => 'Cluster Name',
    'managed_by' => 'Managed By',
    'cluster_type' => 'Cluster Type',
    'project' => 'Project',
    'application' => 'Application',
    'technical_owner' => 'Technical Owner',
    'technical_owner_email' => 'Technical Owner Email',
    'team_dl' => 'Team DL',
    'technical_manager' => 'Technical Manager',
    'technical_manager_email' => 'Technical Manager Email',
    'sdm_name' => 'SDM Name',
    'sdm_email' => 'SDM Email',
    'ncgr_owner' => 'NCGR Owner',
    'ncgr_owner_email' => 'NCGR Owner Email',
    'server_type' => 'Server Type',
    'appliance' => 'Appliance',
    'port_group' => 'Port Group',
    'vlan' => 'VLAN',
    'location' => 'Location',
    'criticality' => 'Criticality',
    'project_code' => 'Project Code',
    'commissioned_date' => 'Commissioned Date',
    'host_type' => 'Host Type',
    'hw_model' => 'HW Model',
    'esxi_cluster' => 'ESXI Cluster',
    'vendor' => 'Vendor',
    'dmz' => 'DMZ',
    'db_type' => 'DB Type',
    'live' => 'Live',
    'eol' => 'EOL',
    'backup' => 'Backup',
    'monitoring' => 'Monitoring',
    'infra' => 'Infra'
];

// 1. Export CSV
if (isset($_GET['action']) && $_GET['action'] === 'export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=inventory_full_export_' . date('Y-m-d') . '.csv');
    $output = fopen('php://output', 'w');
    $cols = array_merge(['id'], array_keys($inventory_columns));
    fputcsv($output, $cols);
    $rows = $pdo->query("SELECT * FROM inventory")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $r) {
        $line = [];
        foreach($cols as $c) { $line[] = $r[$c] ?? ''; }
        fputcsv($output, $line);
    }
    fclose($output);
    exit;
}

// 2. Audit History AJAX
if (isset($_GET['action']) && $_GET['action'] === 'get_history' && $role === 'Admin') {
    $logs = $pdo->query("SELECT * FROM inventory_history ORDER BY timestamp DESC")->fetchAll(PDO::FETCH_ASSOC);
    if (count($logs) > 0) {
        echo '<table class="audit-table"><thead><tr><th>Action</th><th>User</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $l) {
            echo '<tr><td><strong>' . htmlspecialchars($l['action_type']) . '</strong></td><td>' . htmlspecialchars($l['performed_by']) . '</td><td>' . htmlspecialchars($l['details']) . '</td><td>' . htmlspecialchars($l['timestamp']) . '</td></tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">No history records found.</p>';
    }
    exit;
}

// 3. AJAX Ownership Lookup
if (isset($_GET['action']) && $_GET['action'] === 'get_ownership_details') {
    header('Content-Type: application/json');
    $project = trim($_GET['project'] ?? '');
    $support_level = trim($_GET['support_level'] ?? '');
    echo json_encode(lookupOwnershipDetails($pdo, $project, $support_level));
    exit;
}

// 4. AJAX IP Details Lookup (Port Group & VLAN from ip_ranges)
if (isset($_GET['action']) && $_GET['action'] === 'get_ip_details') {
    header('Content-Type: application/json');
    $ip = trim($_GET['ip'] ?? '');
    echo json_encode(lookupIPDetails($pdo, $ip));
    exit;
}

// 6. Form Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['form_action'] ?? '';

    // CSV Bulk Import Action
    if ($act === 'import_csv' && ($role === 'Admin' || $role === 'Edit')) {
        $csv_data_raw = trim($_POST['csv_data'] ?? '');
        $imported_count = 0;
        $failed_count = 0;

        $lines = [];
        if (isset($_FILES['csv_file']['tmp_name']) && !empty($_FILES['csv_file']['tmp_name'])) {
            $lines = file($_FILES['csv_file']['tmp_name'], FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        } elseif (!empty($csv_data_raw)) {
            $lines = explode("\n", $csv_data_raw);
        }

        if (count($lines) > 0) {
            $start_index = 0;
            $first_line = strtolower(trim($lines[0]));
            if (strpos($first_line, 'hostname') !== false) {
                $start_index = 1;
            }

            for ($i = $start_index; $i < count($lines); $i++) {
                $row_data = str_getcsv(trim($lines[$i]));
                if (count($row_data) < 2) continue;

                $hostname = trim($row_data[0] ?? '');
                $ip_address = trim($row_data[1] ?? '');

                if (empty($hostname) || empty($ip_address)) {
                    $failed_count++;
                    continue;
                }

                $chk = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE hostname = ? OR ip_address = ?");
                $chk->execute([$hostname, $ip_address]);
                if ($chk->fetchColumn() > 0) {
                    $failed_count++;
                    continue;
                }

                $support_level = trim($row_data[8] ?? 'production');
                $project = trim($row_data[16] ?? '');

                $ip_match = lookupIPDetails($pdo, $ip_address);
                $port_group = $ip_match['port_group'];
                $vlan = $ip_match['vlan'];

                $own_match = lookupOwnershipDetails($pdo, $project, $support_level);
                $technical_owner = $own_match['technical_owner'] ?? (trim($row_data[19] ?? ''));
                $technical_owner_email = $own_match['technical_owner_email'] ?? (trim($row_data[20] ?? ''));
                $team_dl = $own_match['team_dl'] ?? (trim($row_data[21] ?? ''));
                $technical_manager = $own_match['technical_manager'] ?? (trim($row_data[22] ?? ''));
                $technical_manager_email = $own_match['technical_manager_email'] ?? (trim($row_data[23] ?? ''));
                $sdm_name = $own_match['sdm_name'] ?? (trim($row_data[24] ?? ''));
                $sdm_email = $own_match['sdm_email'] ?? (trim($row_data[25] ?? ''));
                $ncgr_owner = $own_match['ncgr_owner'] ?? (trim($row_data[26] ?? ''));
                $ncgr_owner_email = $own_match['ncgr_owner_email'] ?? (trim($row_data[27] ?? ''));

                $stmt = $pdo->prepare("INSERT INTO inventory (hostname, ip_address, additional_ips, os_family, os_version, kernel_version, cpu, memory, support_level, server_state, domain, joined_in, role, cluster_name, managed_by, cluster_type, project, application, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, server_type, appliance, port_group, vlan, location, criticality, project_code, commissioned_date, host_type, hw_model, esxi_cluster, vendor, dmz, db_type, live, eol, backup, monitoring, infra, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");

                $executed = $stmt->execute([
                    $hostname,
                    $ip_address,
                    trim($row_data[2] ?? ''),
                    trim($row_data[3] ?? ''),
                    trim($row_data[4] ?? ''),
                    trim($row_data[5] ?? ''),
                    trim($row_data[6] ?? ''),
                    trim($row_data[7] ?? ''),
                    $support_level,
                    trim($row_data[9] ?? 'powered on'),
                    trim($row_data[10] ?? ''),
                    trim($row_data[11] ?? ''),
                    trim($row_data[12] ?? ''),
                    trim($row_data[13] ?? ''),
                    trim($row_data[14] ?? ''),
                    trim($row_data[15] ?? ''),
                    $project,
                    trim($row_data[17] ?? ''),
                    $technical_owner,
                    $technical_owner_email,
                    $team_dl,
                    $technical_manager,
                    $technical_manager_email,
                    $sdm_name,
                    $sdm_email,
                    $ncgr_owner,
                    $ncgr_owner_email,
                    trim($row_data[28] ?? 'Virtual'),
                    trim($row_data[29] ?? 'no'),
                    $port_group,
                    $vlan,
                    trim($row_data[32] ?? ''),
                    trim($row_data[33] ?? ''),
                    trim($row_data[34] ?? ''),
                    trim($row_data[35] ?? ''),
                    trim($row_data[36] ?? ''),
                    trim($row_data[37] ?? ''),
                    trim($row_data[38] ?? ''),
                    trim($row_data[39] ?? ''),
                    trim($row_data[40] ?? 'no'),
                    trim($row_data[41] ?? 'no'),
                    trim($row_data[42] ?? 'yes'),
                    trim($row_data[43] ?? 'no'),
                    trim($row_data[44] ?? 'yes'),
                    trim($row_data[45] ?? 'yes'),
                    trim($row_data[46] ?? 'yes'),
                    $username
                ]);

                if ($executed) {
                    $imported_count++;
                    $new_id = $pdo->lastInsertId();
                    $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'CSV_IMPORT', ?, ?)")->execute([$new_id, $username, "Bulk imported inventory record: $hostname"]);
                } else {
                    $failed_count++;
                }
            }
            $msg = "CSV Import completed. Successfully imported: $imported_count records" . ($failed_count > 0 ? ", Failed/Duplicates skipped: $failed_count" : "");
        } else {
            $error = "No valid data found in CSV upload or text area.";
        }
    }

    if ($act === 'save' && ($role === 'Admin' || $role === 'Edit')) {
        $id = $_POST['id'] ?? '';
        $hostname = trim($_POST['hostname']);
        $ip_address = trim($_POST['ip_address']);
        $support_level = trim($_POST['support_level']);
        $project = trim($_POST['project']);

        if (empty($hostname) || empty($ip_address)) {
            $error = "Hostname and IP Address are mandatory fields.";
        } else {
            if (empty($id)) {
                $dup = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE hostname = ? OR ip_address = ?");
                $dup->execute([$hostname, $ip_address]);
                if ($dup->fetchColumn() > 0) {
                    $error = "Error: A record with this Hostname or IP Address already exists.";
                }
            } else {
                $dup = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE (hostname = ? OR ip_address = ?) AND id != ?");
                $dup->execute([$hostname, $ip_address, $id]);
                if ($dup->fetchColumn() > 0) {
                    $error = "Error: Another record with this Hostname or IP Address already exists.";
                }
            }

            if (empty($error)) {
                $ip_match = lookupIPDetails($pdo, $ip_address);
                $port_group = $ip_match['port_group'];
                $vlan = $ip_match['vlan'];

                $own_match = lookupOwnershipDetails($pdo, $project, $support_level);
                $technical_owner = $own_match['technical_owner'] ?? trim($_POST['technical_owner']);
                $technical_owner_email = $own_match['technical_owner_email'] ?? trim($_POST['technical_owner_email']);
                $team_dl = $own_match['team_dl'] ?? trim($_POST['team_dl']);
                $technical_manager = $own_match['technical_manager'] ?? trim($_POST['technical_manager']);
                $technical_manager_email = $own_match['technical_manager_email'] ?? trim($_POST['technical_manager_email']);
                $sdm_name = $own_match['sdm_name'] ?? trim($_POST['sdm_name']);
                $sdm_email = $own_match['sdm_email'] ?? trim($_POST['sdm_email']);
                $ncgr_owner = $own_match['ncgr_owner'] ?? trim($_POST['ncgr_owner']);
                $ncgr_owner_email = $own_match['ncgr_owner_email'] ?? trim($_POST['ncgr_owner_email']);

                $hw_model = trim($_POST['hw_model']);
                $vendor = trim($_POST['vendor']);
                $location = trim($_POST['location']);

                if (!empty($hw_model)) {
                    $v_stmt = $pdo->prepare("SELECT manufacturer, location FROM asset WHERE asset_name = ? LIMIT 1");
                    $v_stmt->execute([$hw_model]);
                    $asset_data = $v_stmt->fetch(PDO::FETCH_ASSOC);
                    if ($asset_data) {
                        if (empty($vendor)) {
                            $vendor = $asset_data['manufacturer'] ?? '';
                        }
                        if (empty($location)) {
                            $location = $asset_data['location'] ?? '';
                        }
                    }
                }

                if (empty($id)) {
                    $stmt = $pdo->prepare("INSERT INTO inventory (hostname, ip_address, additional_ips, os_family, os_version, kernel_version, cpu, memory, support_level, server_state, domain, joined_in, role, cluster_name, managed_by, cluster_type, project, application, technical_owner, technical_owner_email, team_dl, technical_manager, technical_manager_email, sdm_name, sdm_email, ncgr_owner, ncgr_owner_email, server_type, appliance, port_group, vlan, location, criticality, project_code, commissioned_date, host_type, hw_model, esxi_cluster, vendor, dmz, db_type, live, eol, backup, monitoring, infra, created_by) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                    $stmt->execute([
                        $hostname, $ip_address, trim($_POST['additional_ips']), trim($_POST['os_family']), trim($_POST['os_version']), trim($_POST['kernel_version']), trim($_POST['cpu']), trim($_POST['memory']), $support_level, trim($_POST['server_state']), trim($_POST['domain']), trim($_POST['joined_in']), trim($_POST['role']), trim($_POST['cluster_name']), trim($_POST['managed_by']), trim($_POST['cluster_type']), $project, trim($_POST['application']), $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, trim($_POST['server_type']), trim($_POST['appliance']), $port_group, $vlan, $location, trim($_POST['criticality']), trim($_POST['project_code']), trim($_POST['commissioned_date']), trim($_POST['host_type']), $hw_model, trim($_POST['esxi_cluster']), $vendor, trim($_POST['dmz']), trim($_POST['db_type']), trim($_POST['live']), trim($_POST['eol']), trim($_POST['backup']), trim($_POST['monitoring']), trim($_POST['infra']), $username
                    ]);
                    $new_id = $pdo->lastInsertId();
                    $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)")->execute([$new_id, $username, "Created inventory record: $hostname"]);
                    $msg = "Server inventory entry created successfully.";
                } else {
                    $edit_comments = trim($_POST['edit_comments'] ?? '');
                    $stmt = $pdo->prepare("UPDATE inventory SET hostname=?, ip_address=?, additional_ips=?, os_family=?, os_version=?, kernel_version=?, cpu=?, memory=?, support_level=?, server_state=?, domain=?, joined_in=?, role=?, cluster_name=?, managed_by=?, cluster_type=?, project=?, application=?, technical_owner=?, technical_owner_email=?, team_dl=?, technical_manager=?, technical_manager_email=?, sdm_name=?, sdm_email=?, ncgr_owner=?, ncgr_owner_email=?, server_type=?, appliance=?, port_group=?, vlan=?, location=?, criticality=?, project_code=?, commissioned_date=?, host_type=?, hw_model=?, esxi_cluster=?, vendor=?, dmz=?, db_type=?, live=?, eol=?, backup=?, monitoring=?, infra=?, edit_comments=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                    $stmt->execute([
                        $hostname, $ip_address, trim($_POST['additional_ips']), trim($_POST['os_family']), trim($_POST['os_version']), trim($_POST['kernel_version']), trim($_POST['cpu']), trim($_POST['memory']), $support_level, trim($_POST['server_state']), trim($_POST['domain']), trim($_POST['joined_in']), trim($_POST['role']), trim($_POST['cluster_name']), trim($_POST['managed_by']), trim($_POST['cluster_type']), $project, trim($_POST['application']), $technical_owner, $technical_owner_email, $team_dl, $technical_manager, $technical_manager_email, $sdm_name, $sdm_email, $ncgr_owner, $ncgr_owner_email, trim($_POST['server_type']), trim($_POST['appliance']), $port_group, $vlan, $location, trim($_POST['criticality']), trim($_POST['project_code']), trim($_POST['commissioned_date']), trim($_POST['host_type']), $hw_model, trim($_POST['esxi_cluster']), $vendor, trim($_POST['dmz']), trim($_POST['db_type']), trim($_POST['live']), trim($_POST['eol']), trim($_POST['backup']), trim($_POST['monitoring']), trim($_POST['infra']), $edit_comments, $username, $id
                    ]);
                    $detail_msg = "Updated inventory record: $hostname" . (!empty($edit_comments) ? " | Comment: $edit_comments" : "");
                    $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)")->execute([$id, $username, $detail_msg]);
                    $msg = "Server inventory entry updated successfully.";
                }
            }
        }
    }

    if ($act === 'delete' && $role === 'Admin') {
        $id = $_POST['id'];
        $h_name = $pdo->prepare("SELECT hostname FROM inventory WHERE id=?");
        $h_name->execute([$id]);
        $val = $h_name->fetchColumn();

        $pdo->prepare("DELETE FROM inventory WHERE id=?")->execute([$id]);
        $pdo->prepare("INSERT INTO inventory_history (inventory_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)")->execute([$id, $username, "Deleted inventory record: $val"]);
        $msg = "Server deleted successfully.";
    }
}

// Pagination & Search
$limit = 25;
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$start = ($page > 1) ? ($page * $limit) - $limit : 0;
$keyword = trim($_GET['keyword'] ?? '');
$advanced_search = trim($_GET['advanced_search'] ?? '');
$active_servers = isset($_GET['active_servers']) ? $_GET['active_servers'] : '';

$where = "1=1";
$params = [];

// Handle Advanced Search (Multi-value newline or comma separated tokens)
if (!empty($advanced_search)) {
    // Split tokens by newlines, commas, or semicolons
    $tokens = preg_split('/[\r\n,\;]+/', $advanced_search);
    $tokens = array_filter(array_map('trim', $tokens));

    if (count($tokens) > 0) {
        $clauses = [];
        foreach ($tokens as $token) {
            if ($token === '') continue;
            // Match token across common multi-target query fields: hostname, ip_address, project, application, os_family
            $clauses[] = "(hostname LIKE ? OR ip_address LIKE ? OR project LIKE ? OR application LIKE ? OR os_family LIKE ?)";
            $wildcard = "%$token%";
            array_push($params, $wildcard, $wildcard, $wildcard, $wildcard, $wildcard);
        }
        if (count($clauses) > 0) {
            $where .= " AND (" . implode(" OR ", $clauses) . ")";
        }
    }
} elseif (!empty($keyword)) {
    $where .= " AND (hostname LIKE ? OR ip_address LIKE ? OR project LIKE ? OR os_family LIKE ? OR application LIKE ?)";
    $params = array_merge($params, ["%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%"]);
}

if ($active_servers === '1') {
    $where .= " AND LOWER(server_state) = 'powered on' AND LOWER(live) = 'yes'";
}

$total = $pdo->prepare("SELECT COUNT(*) FROM inventory WHERE $where");
$total->execute($params);
$total_records = $total->fetchColumn();
$total_pages = ceil($total_records / $limit);

$stmt = $pdo->prepare("SELECT * FROM inventory WHERE $where ORDER BY id DESC LIMIT $limit OFFSET $start");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Dropdowns Options
$os_families = ['Windows', 'RHEL', 'RHCOS', 'Ubuntu', 'Rocky Linux', 'Debian', 'Appliance', 'Datapower', 'Suse linux', 'Fedora', 'Centos', 'Oralce Linux', 'FreeBSD', 'others', 'other linux'];
$server_states = ['powered on', 'powered off', 'decommissioned', 'to be decomm'];
$domains = ['mof.gov.sa', 'ncgr.gov.sa', 'moftest.com', 'mof.dmz', 'other'];
$joined_in_opts = ['redhat IPA', 'ldap', 'active directory', 'local'];
$roles_opts = ['APP', 'DB', 'WEB'];
$managed_by_opts = ['HCL', 'Ejada', 'STC', 'Alfa', 'MOF', 'NCGR', 'UGRP', 'Others', 'GRC', 'ADT'];
$cluster_opts = ['kubernetes', 'openshift', 'oracle ASM', 'Redhat pcs', 'nkp', 'others', 'rancher', 'no cluster'];
$server_types = ['Physical', 'Virtual'];
$yes_no = ['yes', 'no'];
$criticalities = ['critical', 'low', 'high', 'Mission critical', 'Business critical', 'medium', 'VIP', 'N/A'];
$db_opts = ['no', 'oracle', 'other DBs'];

$ownership_projects = $pdo->query("SELECT DISTINCT project FROM ownership WHERE project IS NOT NULL AND project != '' ORDER BY project ASC")->fetchAll(PDO::FETCH_COLUMN);
$ownership_support_levels = $pdo->query("SELECT DISTINCT support_level FROM ownership WHERE support_level IS NOT NULL AND support_level != '' ORDER BY support_level ASC")->fetchAll(PDO::FETCH_COLUMN);
if (empty($ownership_support_levels)) {
    $ownership_support_levels = ['production', 'pre-prod', 'sit', 'test', 'development', 'sandbox', 'DR', 'POC'];
}

// Used by includes/header.php for the <title> tag
$page_title = "Server & Application Inventory | InfraVault";

require 'includes/header.php';
?>
<link rel="stylesheet" href="assets/css/inventory.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Server &amp; Application Inventory</h1>
            <p>Full lifecycle inventory of servers and applications, cross-linked with Ownership and IPAM.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                <button type="button" class="btn btn-primary" onclick="openCreateModal()">+ Add Inventory Record</button>
                <button type="button" class="btn btn-success" onclick="openImportModal()">Upload CSV / Multi-Line</button>
            <?php endif; ?>
            <a href="inventory.php?action=export" class="btn">Export CSV</a>
            <?php if ($role === 'Admin'): ?>
                <button type="button" class="btn" onclick="openHistoryModal()">Global History</button>
            <?php endif; ?>
            <button type="button" class="btn" onclick="openColumnsModal()">Customize Fields</button>
            <button type="button" class="btn btn-accent" onclick="openAdvancedSearchModal()">Advanced Multi-Search</button>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Quick Search Panel -->
    <div class="panel">
        <div class="toolbar">
            <div class="toolbar-left">
                <span class="panel-title" style="margin-bottom:0;">Quick Search</span>
            </div>
            <div class="toolbar-right">
                <form method="GET" action="inventory.php" style="display: flex; gap: 0.5rem; align-items: center;">
                    <input type="hidden" name="advanced_search" value="<?php echo htmlspecialchars($advanced_search); ?>">
                    <label style="display: flex; align-items: center; gap: 0.3rem; font-size: 0.85rem; font-weight: 600; cursor: pointer;">
                        <input type="checkbox" name="active_servers" value="1" <?php if($active_servers === '1') echo 'checked'; ?> onclick="this.form.submit();"> Active Servers
                    </label>
                    <input type="text" name="keyword" class="form-control" placeholder="Search hostname, IP, project..." value="<?php echo htmlspecialchars($keyword); ?>" style="width: 240px;">
                    <button type="submit" class="btn btn-primary">Search</button>
                </form>
            </div>
        </div>
    </div>

    <?php if (!empty($advanced_search)): ?>
        <div class="alert alert-info">
            <span><strong>Active Advanced Search Multi-Filter:</strong> <?php echo htmlspecialchars(str_replace(["\r", "\n"], ' | ', $advanced_search)); ?></span>
            <a href="inventory.php" class="btn btn-sm">Clear Filter</a>
        </div>
    <?php endif; ?>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <h3 class="panel-title" style="margin:0;">Inventory Records</h3>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table" id="inventoryTable">
                <thead>
                    <tr>
                        <?php foreach ($inventory_columns as $col_key => $col_label): ?>
                            <th class="col-th-<?php echo $col_key; ?> <?php echo in_array($col_key, ['hostname', 'ip_address', 'os_family', 'support_level', 'project']) ? '' : 'hidden-col'; ?>"><?php echo htmlspecialchars($col_label); ?></th>
                        <?php endforeach; ?>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($rows) > 0): ?>
                        <?php foreach ($rows as $r): ?>
                        <tr>
                            <?php foreach ($inventory_columns as $col_key => $col_label): ?>
                                <td class="col-td-<?php echo $col_key; ?> <?php echo in_array($col_key, ['hostname', 'ip_address', 'os_family', 'support_level', 'project']) ? '' : 'hidden-col'; ?>">
                                    <?php if ($col_key === 'hostname'): ?>
                                        <span class="cell-primary"><?php echo htmlspecialchars($r[$col_key] ?? ''); ?></span>
                                    <?php elseif ($col_key === 'support_level'): ?>
                                        <span class="badge"><?php echo htmlspecialchars($r[$col_key] ?? ''); ?></span>
                                    <?php else: ?>
                                        <?php echo htmlspecialchars($r[$col_key] ?? ''); ?>
                                    <?php endif; ?>
                                </td>
                            <?php endforeach; ?>
                            <td style="text-align: center; white-space: nowrap;">
                                <div class="row-actions">
                                    <button type="button" class="btn btn-sm" onclick='openViewModal(<?php echo json_encode($r); ?>)'>View</button>
                                    <?php if ($role === 'Admin' || $role === 'Edit'): ?>
                                        <button type="button" class="btn btn-sm btn-primary" onclick='openEditModal(<?php echo json_encode($r); ?>)'>Edit</button>
                                    <?php endif; ?>
                                    <?php if ($role === 'Admin'): ?>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['hostname'])); ?>')">Delete</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="<?php echo count($inventory_columns) + 1; ?>"><p class="empty-state">No inventory entries available.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <div class="pagination" style="padding-bottom:22px;">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="inventory.php?page=<?php echo $i; ?>&keyword=<?php echo urlencode($keyword); ?>&advanced_search=<?php echo urlencode($advanced_search); ?>&active_servers=<?php echo urlencode($active_servers); ?>" class="<?php if($page == $i) echo 'active'; ?>"><?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        <?php endif; ?>
    </div>

</div>

<!-- ADVANCED SEARCH MODAL -->
<div id="advancedSearchModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3>Advanced Multi-Combination Search</h3>
            <button type="button" class="close-modal" onclick="closeModal('advancedSearchModal')">&times;</button>
        </div>
        <form method="GET" action="inventory.php">
            <?php if ($active_servers === '1'): ?>
                <input type="hidden" name="active_servers" value="1">
            <?php endif; ?>
            <div class="form-group" style="margin-top: 1rem;">
                <label><strong>Enter Multiple Search Items (Hostnames, IPs, Projects, or Apps)</strong></label>
                <p style="font-size: 0.8rem; color: #64748B; margin-bottom: 0.5rem;">Provide multiple values separated by commas, semicolons, or new lines. This matches combinations across different projects or attributes simultaneously.</p>
                <textarea name="advanced_search" class="form-control" rows="8" placeholder="server-app-01&#10;192.168.1.50&#10;ProjectXYZ&#10;10.0.4.12"><?php echo htmlspecialchars($advanced_search); ?></textarea>
            </div>
            <div class="modal-footer">
                <a href="inventory.php" class="btn" style="text-decoration:none; display:inline-flex; align-items:center;">Reset Filter</a>
                <button type="button" class="btn" onclick="closeModal('advancedSearchModal')">Cancel</button>
                <button type="submit" class="btn btn-accent">Apply Multi-Search</button>
            </div>
        </form>
    </div>
</div>

<!-- CREATE / EDIT MODAL -->
<div id="recordModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 950px;">
        <div class="modal-header">
            <h3 id="modalTitle">Add Server Inventory</h3>
            <button type="button" class="close-modal" onclick="closeModal('recordModal')">&times;</button>
        </div>
        <form method="POST" action="inventory.php">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="rec_id">

            <div class="modal-grid">
                <div class="form-group"><label>Hostname *</label><input type="text" name="hostname" id="rec_hostname" class="form-control" required></div>

                <div class="form-group"><label>IP Address *</label><input type="text" name="ip_address" id="rec_ip_address" class="form-control" onblur="fetchIPDetails()" onchange="fetchIPDetails()" required></div>

                <div class="form-group"><label>Additional IPs (comma)</label><input type="text" name="additional_ips" id="rec_additional_ips" class="form-control"></div>

                <div class="form-group"><label>OS Family</label>
                    <select name="os_family" id="rec_os_family" class="form-control"><?php foreach($os_families as $o): ?><option value="<?php echo $o; ?>"><?php echo $o; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>OS Version</label><input type="text" name="os_version" id="rec_os_version" class="form-control"></div>
                <div class="form-group"><label>Kernel Version</label><input type="text" name="kernel_version" id="rec_kernel_version" class="form-control"></div>

                <div class="form-group"><label>CPU</label><input type="text" name="cpu" id="rec_cpu" class="form-control"></div>
                <div class="form-group"><label>Memory</label><input type="text" name="memory" id="rec_memory" class="form-control"></div>

                <div class="form-group"><label>Support Level *</label>
                    <select name="support_level" id="rec_support_level" class="form-control" onchange="fetchOwnershipData()" required>
                        <?php foreach($ownership_support_levels as $s): ?>
                            <option value="<?php echo htmlspecialchars($s); ?>"><?php echo htmlspecialchars($s); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group"><label>Server State</label>
                    <select name="server_state" id="rec_server_state" class="form-control"><?php foreach($server_states as $st): ?><option value="<?php echo $st; ?>"><?php echo $st; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>Domain</label>
                    <select name="domain" id="rec_domain" class="form-control"><?php foreach($domains as $d): ?><option value="<?php echo $d; ?>"><?php echo $d; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>Joined In</label>
                    <select name="joined_in" id="rec_joined_in" class="form-control"><?php foreach($joined_in_opts as $j): ?><option value="<?php echo $j; ?>"><?php echo $j; ?></option><?php endforeach; ?></select>
                </div>

                <div class="form-group"><label>Role</label>
                    <select name="role" id="rec_role" class="form-control"><?php foreach($roles_opts as $r): ?><option value="<?php echo $r; ?>"><?php echo $r; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>Cluster Name</label><input type="text" name="cluster_name" id="rec_cluster_name" class="form-control"></div>
                <div class="form-group"><label>Managed By</label>
                    <select name="managed_by" id="rec_managed_by" class="form-control"><?php foreach($managed_by_opts as $m): ?><option value="<?php echo $m; ?>"><?php echo $m; ?></option><?php endforeach; ?></select>
                </div>

                <div class="form-group"><label>Cluster Type</label>
                    <select name="cluster_type" id="rec_cluster_type" class="form-control"><?php foreach($cluster_opts as $c): ?><option value="<?php echo $c; ?>"><?php echo $c; ?></option><?php endforeach; ?></select>
                </div>

                <div class="form-group"><label>Project *</label>
                    <select name="project" id="rec_project" class="form-control" onchange="fetchOwnershipData()" required>
                        <option value="">-- Select Project --</option>
                        <?php foreach($ownership_projects as $proj): ?>
                            <option value="<?php echo htmlspecialchars($proj); ?>"><?php echo htmlspecialchars($proj); ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group"><label>Application</label><input type="text" name="application" id="rec_application" class="form-control"></div>

                <div class="form-group"><label>Technical Owner</label><input type="text" name="technical_owner" id="rec_technical_owner" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>Technical Owner Email</label><input type="text" name="technical_owner_email" id="rec_technical_owner_email" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>Team DL</label><input type="text" name="team_dl" id="rec_team_dl" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>Technical Manager</label><input type="text" name="technical_manager" id="rec_technical_manager" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>Technical Manager Email</label><input type="text" name="technical_manager_email" id="rec_technical_manager_email" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>SDM Name</label><input type="text" name="sdm_name" id="rec_sdm_name" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>SDM Email</label><input type="text" name="sdm_email" id="rec_sdm_email" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>NCGR Owner</label><input type="text" name="ncgr_owner" id="rec_ncgr_owner" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>NCGR Owner Email</label><input type="text" name="ncgr_owner_email" id="rec_ncgr_owner_email" class="form-control auto-filled-field" readonly></div>

                <div class="form-group"><label>Server Type</label>
                    <select name="server_type" id="rec_server_type" class="form-control"><?php foreach($server_types as $st): ?><option value="<?php echo $st; ?>"><?php echo $st; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>Appliance</label>
                    <select name="appliance" id="rec_appliance" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select>
                </div>

                <div class="form-group"><label>Port Group</label><input type="text" name="port_group" id="rec_port_group" class="form-control auto-filled-field" readonly></div>
                <div class="form-group"><label>VLAN</label><input type="text" name="vlan" id="rec_vlan" class="form-control auto-filled-field" readonly></div>

                <div class="form-group"><label>Location</label><input type="text" name="location" id="rec_location" class="form-control"></div>

                <div class="form-group"><label>Criticality</label>
                    <select name="criticality" id="rec_criticality" class="form-control"><?php foreach($criticalities as $cr): ?><option value="<?php echo $cr; ?>"><?php echo $cr; ?></option><?php endforeach; ?></select>
                </div>
                <div class="form-group"><label>Project Code</label><input type="text" name="project_code" id="rec_project_code" class="form-control"></div>
                <div class="form-group"><label>Commissioned Date</label><input type="date" name="commissioned_date" id="rec_commissioned_date" class="form-control"></div>

                <div class="form-group"><label>Host Type</label><input type="text" name="host_type" id="rec_host_type" class="form-control"></div>

                <!-- HW Model Search Field -->
                <div class="form-group" style="position: relative;">
                    <label>HW Model (Asset Name)</label>
                    <input type="text" name="hw_model" id="rec_hw_model" class="form-control" placeholder="Search asset name..." autocomplete="off" oninput="searchHardware(this.value)">
                    <div id="hwSuggestions" class="autocomplete-suggestions" style="display:none;"></div>
                </div>

                <div class="form-group"><label>ESXI Cluster</label><input type="text" name="esxi_cluster" id="rec_esxi_cluster" class="form-control"></div>

                <div class="form-group"><label>Vendor</label><input type="text" name="vendor" id="rec_vendor" class="form-control"></div>
                <div class="form-group"><label>DMZ</label><select name="dmz" id="rec_dmz" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>DB Type</label><select name="db_type" id="rec_db_type" class="form-control"><?php foreach($db_opts as $db): ?><option value="<?php echo $db; ?>"><?php echo $db; ?></option><?php endforeach; ?></select></div>

                <div class="form-group"><label>Live</label><select name="live" id="rec_live" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>EOL</label><select name="eol" id="rec_eol" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Backup</label><select name="backup" id="rec_backup" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>

                <div class="form-group"><label>Monitoring</label><select name="monitoring" id="rec_monitoring" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>
                <div class="form-group"><label>Infra</label><select name="infra" id="rec_infra" class="form-control"><?php foreach($yes_no as $yn): ?><option value="<?php echo $yn; ?>"><?php echo $yn; ?></option><?php endforeach; ?></select></div>
            </div>

            <div class="form-group" id="commentFieldGroup" style="display:none; margin-top:1rem;">
                <label>Edit Comments (Required/Recorded in history)</label>
                <textarea name="edit_comments" class="form-control" rows="2" placeholder="Describe edits..."></textarea>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('recordModal')">Cancel</button>
                <button type="submit" class="btn btn-primary">Save Inventory</button>
            </div>
        </form>
    </div>
</div>

<!-- CSV UPLOAD / IMPORT MODAL -->
<div id="importModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 600px;">
        <div class="modal-header">
            <h3>Bulk Import Inventory (CSV / Multi-Line)</h3>
            <button type="button" class="close-modal" onclick="closeModal('importModal')">&times;</button>
        </div>
        <form method="POST" action="inventory.php" enctype="multipart/form-data">
            <input type="hidden" name="form_action" value="import_csv">

            <div class="form-group" style="margin-top: 1rem;">
                <label><strong>Option A: Upload CSV File</strong></label>
                <input type="file" name="csv_file" accept=".csv, .txt" class="form-control">
            </div>

            <hr style="margin: 1.5rem 0; border:0; border-top:1px solid #E5E7EB;">

            <div class="form-group">
                <label><strong>Option B: Paste Multi-Line CSV Data</strong></label>
                <p style="font-size:0.8rem; color:#64748B; margin-bottom:0.5rem;">Paste comma-separated rows. Each line represents one server record matching the export structure.</p>
                <textarea name="csv_data" class="form-control" rows="8" placeholder="hostname,ip_address,additional_ips,os_family,..."></textarea>
            </div>

            <div class="modal-footer">
                <button type="button" class="btn" onclick="closeModal('importModal')">Cancel</button>
                <button type="submit" class="btn btn-success">Import Records</button>
            </div>
        </form>
    </div>
</div>

<!-- VIEW MODAL -->
<div id="viewModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 650px;">
        <div class="modal-header">
            <h3>Server Inventory Details</h3>
            <button type="button" class="close-modal" onclick="closeModal('viewModal')">&times;</button>
        </div>
        <div id="viewContent" style="max-height: 60vh; overflow-y:auto; margin-top:1rem; font-size:0.9rem; line-height: 1.6; display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem;"></div>
        <div class="modal-footer" style="justify-content:flex-end;">
            <button type="button" class="btn btn-primary" onclick="closeModal('viewModal')">Close</button>
        </div>
    </div>
</div>

<!-- DELETE MODAL -->
<div id="deleteModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 400px; text-align: center;">
        <div class="modal-header"><h3>Confirm Delete</h3><button type="button" class="close-modal" onclick="closeModal('deleteModal')">&times;</button></div>
        <p style="margin: 1rem 0; color:#64748B;">Delete server <strong id="del_name"></strong>?</p>
        <form method="POST" action="inventory.php">
            <input type="hidden" name="form_action" value="delete"><input type="hidden" name="id" id="del_id">
            <div class="modal-footer" style="justify-content:center;">
                <button type="button" class="btn" onclick="closeModal('deleteModal')">Cancel</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- HISTORY MODAL -->
<div id="historyModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 700px;">
        <div class="modal-header"><h3>Audit History</h3><button type="button" class="close-modal" onclick="closeModal('historyModal')">&times;</button></div>
        <div id="historyContent" style="max-height: 50vh; overflow-y:auto; margin-top:1rem;"><p class="empty-state">Loading...</p></div>
    </div>
</div>

<!-- COLUMNS CUSTOMIZATION MODAL -->
<div id="columnsModal" class="modal-overlay">
    <div class="modal-content" style="max-width: 550px;">
        <div class="modal-header"><h3>Customize Visible Fields</h3><button type="button" class="close-modal" onclick="closeModal('columnsModal')">&times;</button></div>
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 0.5rem; max-height: 50vh; overflow-y:auto; margin-top: 1rem; padding-right: 0.5rem;">
            <?php foreach ($inventory_columns as $col_key => $col_label):
                $is_checked = in_array($col_key, ['hostname', 'ip_address', 'os_family', 'support_level', 'project']) ? 'checked' : '';
            ?>
                <label style="font-size:0.85rem; display:flex; align-items:center; gap:0.4rem;">
                    <input type="checkbox" <?php echo $is_checked; ?> onchange="toggleCol('<?php echo $col_key; ?>', this.checked)"> <?php echo htmlspecialchars($col_label); ?>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="modal-footer" style="justify-content:flex-end;">
            <button type="button" class="btn btn-primary" onclick="closeModal('columnsModal')">Done</button>
        </div>
    </div>
</div>

<script>
    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'Add Server Inventory';
        document.getElementById('rec_id').value = '';
        document.querySelectorAll('#recordModal input').forEach(i => { if(i.type !== 'hidden') i.value = ''; });
        document.querySelectorAll('#recordModal select').forEach(s => { s.selectedIndex = 0; });
        document.getElementById('commentFieldGroup').style.display = 'none';
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openImportModal() { document.getElementById('importModal').style.display = 'flex'; }
    function openAdvancedSearchModal() { document.getElementById('advancedSearchModal').style.display = 'flex'; }

    function openEditModal(d) {
        document.getElementById('modalTitle').innerText = 'Edit Server Inventory';
        document.getElementById('rec_id').value = d.id;
        for (let k in d) { const el = document.getElementById('rec_' + k); if(el) el.value = d[k]; }
        document.getElementById('commentFieldGroup').style.display = 'block';
        document.getElementById('recordModal').style.display = 'flex';
    }

    function openViewModal(d) {
        let html = '';
        for(let k in d) { html += `<div style="padding:0.25rem 0; border-bottom:1px solid #f1f5f9;"><strong>${k.replace(/_/g, ' ')}:</strong> ${d[k] || '-'}</div>`; }
        document.getElementById('viewContent').innerHTML = html;
        document.getElementById('viewModal').style.display = 'flex';
    }

    function openDeleteModal(id, name) { document.getElementById('del_id').value = id; document.getElementById('del_name').innerText = name; document.getElementById('deleteModal').style.display = 'flex'; }
    function openColumnsModal() { document.getElementById('columnsModal').style.display = 'flex'; }
    function closeModal(id) { document.getElementById(id).style.display = 'none'; }

    function toggleCol(colKey, show) {
        document.querySelectorAll('.col-th-' + colKey + ', .col-td-' + colKey).forEach(el => {
            el.classList.toggle('hidden-col', !show);
        });
    }

    function openHistoryModal() {
        document.getElementById('historyModal').style.display = 'flex';
        fetch('inventory.php?action=get_history').then(r => r.text()).then(h => document.getElementById('historyContent').innerHTML = h);
    }

    function fetchOwnershipData() {
        const project = document.getElementById('rec_project').value;
        const supportLevel = document.getElementById('rec_support_level').value;

        if (!project || !supportLevel) return;

        fetch(`inventory.php?action=get_ownership_details&project=${encodeURIComponent(project)}&support_level=${encodeURIComponent(supportLevel)}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('rec_technical_owner').value = data.technical_owner || '';
                document.getElementById('rec_technical_owner_email').value = data.technical_owner_email || '';
                document.getElementById('rec_team_dl').value = data.team_dl || '';
                document.getElementById('rec_technical_manager').value = data.technical_manager || '';
                document.getElementById('rec_technical_manager_email').value = data.technical_manager_email || '';
                document.getElementById('rec_sdm_name').value = data.sdm_name || '';
                document.getElementById('rec_sdm_email').value = data.sdm_email || '';
                document.getElementById('rec_ncgr_owner').value = data.ncgr_owner || '';
                document.getElementById('rec_ncgr_owner_email').value = data.ncgr_owner_email || '';
            })
            .catch(err => console.error('Error fetching ownership details:', err));
    }

    function fetchIPDetails() {
        const ip = document.getElementById('rec_ip_address').value;
        if (!ip) return;

        fetch(`inventory.php?action=get_ip_details&ip=${encodeURIComponent(ip)}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('rec_port_group').value = data.port_group || '';
                document.getElementById('rec_vlan').value = data.vlan || '';
            })
            .catch(err => console.error('Error fetching IP details:', err));
    }

    function searchHardware(query) {
        const container = document.getElementById('hwSuggestions');
        if (!query || query.trim().length < 1) {
            container.style.display = 'none';
            container.innerHTML = '';
            return;
        }

        fetch(`inventory.php?action=search_hardware&q=${encodeURIComponent(query.trim())}`)
            .then(res => res.json())
            .then(data => {
                if (Array.isArray(data) && data.length > 0) {
                    let html = '';
                    data.forEach(item => {
                        const name = item.asset_name || '';
                        const mfg = item.manufacturer || 'N/A';
                        const loc = item.location || '';
                        html += `<div class="autocomplete-suggestion" onclick="selectHardware('${name.replace(/'/g, "\\'")}', '${mfg.replace(/'/g, "\\'")}', '${loc.replace(/'/g, "\\'")}')">${name} (${mfg}) ${loc ? '— ' + loc : ''}</div>`;
                    });
                    container.innerHTML = html;
                    container.style.display = 'block';
                } else {
                    container.style.display = 'none';
                    container.innerHTML = '';
                }
            })
            .catch(err => {
                console.error('Error srching hardware:', err);
                container.style.display = 'none';
            });
    }

    function selectHarare(assetName, manufacturer, location) {
        document.getElementById('rec_hw_model').value = assetName;
        document.getElementById('rec_vendor').value = (manufacturer && manufacturer !== 'N/A') ? manufacturer : '';

        const locationField = document.getElementById('rec_location');
        if (locationField && location && location.trim() !== '') {
            locationField.value = location;
        }

        document.getElementById('hwSuggestions').style.display = 'none';
    }

    document.addEventListener('click', function(e) {
        const hwInput = document.getElementById('rec_hw_model');
        const container = document.getElementById('hwSuggestions');
        if (hwInput && container && !hwInput.contains(e.target) && !container.contains(e.target)) {
            container.style.display = 'none';
        }
    });
</script>

<?php require 'includes/footer.php'; ?>

