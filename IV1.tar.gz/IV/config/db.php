<?php

// ============================================================
// DATABASE CONNECTION
// ============================================================

$db_file = __DIR__ . '/infravault.db';

try {

    $pdo = new PDO('sqlite:' . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // ========================================================
    // USERS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ncgr_id TEXT UNIQUE NOT NULL,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            email TEXT NOT NULL,
            team TEXT NOT NULL,
            password TEXT NOT NULL,
            role TEXT DEFAULT 'Read-only',
            is_approved INTEGER DEFAULT 0
        )
    ");

    // Safely insert default admin if not already present
    $hashed_password = password_hash('admin123', PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("
        INSERT OR IGNORE INTO users
        (
            ncgr_id,
            first_name,
            last_name,
            email,
            team,
            password,
            role,
            is_approved
        )
        VALUES
        (
            'ADMIN001',
            'System',
            'Admin',
            'admin@infravault.local',
            'Cloud',
            ?,
            'Admin',
            1
        )
    ");

    $stmt->execute([$hashed_password]);


    // ========================================================
    // OWNERSHIP INVENTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ownership (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project TEXT NOT NULL,
            support_level TEXT NOT NULL,
            technical_owner TEXT NOT NULL,
            technical_owner_email TEXT NOT NULL,
            team_dl TEXT NOT NULL,
            technical_manager TEXT NOT NULL,
            technical_manager_email TEXT NOT NULL,
            sdm_name TEXT NOT NULL,
            sdm_email TEXT NOT NULL,
            ncgr_owner TEXT NOT NULL,
            ncgr_owner_email TEXT NOT NULL,
            notes TEXT,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");


    // ========================================================
    // SOPS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sops (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sop_number TEXT NOT NULL UNIQUE,
            title TEXT NOT NULL,
            category TEXT NOT NULL,
            description TEXT,
            criticality TEXT DEFAULT 'Medium',
            owner_id INTEGER NOT NULL,
            reviewer_id INTEGER,
            version TEXT DEFAULT '1.0',
            status TEXT DEFAULT 'Draft',
            content_html TEXT,
            prerequisites_html TEXT,
            validation_html TEXT,
            rollback_html TEXT,
            escalation_html TEXT,
            review_comment TEXT,
            rejection_reason TEXT,
            review_date DATE,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            submitted_at DATETIME,
            reviewed_at DATETIME,
            published_at DATETIME,
            FOREIGN KEY (owner_id) REFERENCES users(id),
            FOREIGN KEY (reviewer_id) REFERENCES users(id)
        )
    ");


    // ========================================================
    // PATCH EXCEPTIONS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS patch_exceptions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            reference_no TEXT UNIQUE NOT NULL,

            title TEXT NOT NULL,
            exception_type TEXT NOT NULL DEFAULT 'Patch Exception',
            version TEXT NOT NULL DEFAULT '1.0',

            short_description TEXT DEFAULT '',
            system_name TEXT DEFAULT '',
            application_name TEXT DEFAULT '',

            current_version TEXT DEFAULT '',
            target_version TEXT DEFAULT '',

            reason TEXT DEFAULT '',
            risk_description TEXT DEFAULT '',
            mitigation TEXT DEFAULT '',

            owner_id INTEGER NOT NULL,
            team TEXT DEFAULT '',

            visibility TEXT NOT NULL DEFAULT 'Private',

            start_date DATE,
            expiry_date DATE,

            status TEXT NOT NULL DEFAULT 'Draft',

            requested_by INTEGER NOT NULL,

            approved_by INTEGER,
            approved_at DATETIME,

            rejection_reason TEXT DEFAULT '',
            review_comment TEXT DEFAULT '',

            additional_details TEXT DEFAULT '',

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (owner_id) REFERENCES users(id),
            FOREIGN KEY (requested_by) REFERENCES users(id),
            FOREIGN KEY (approved_by) REFERENCES users(id)
        )
    ");


    // ========================================================
    // PATCH EXCEPTION ATTACHMENTS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS patch_exception_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            exception_id INTEGER NOT NULL,

            original_name TEXT NOT NULL,
            stored_name TEXT NOT NULL,
            file_path TEXT NOT NULL,

            mime_type TEXT DEFAULT 'application/octet-stream',
            file_size INTEGER DEFAULT 0,

            uploaded_by INTEGER NOT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (exception_id)
                REFERENCES patch_exceptions(id)
                ON DELETE CASCADE,

            FOREIGN KEY (uploaded_by)
                REFERENCES users(id)
        )
    ");


    // ========================================================
    // PATCH EXCEPTION REVISIONS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS patch_exception_revisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            exception_id INTEGER NOT NULL,

            version TEXT NOT NULL DEFAULT '1.0',

            title TEXT NOT NULL,
            exception_type TEXT NOT NULL,

            short_description TEXT DEFAULT '',
            system_name TEXT DEFAULT '',
            application_name TEXT DEFAULT '',

            current_version TEXT DEFAULT '',
            target_version TEXT DEFAULT '',

            reason TEXT DEFAULT '',
            risk_description TEXT DEFAULT '',
            mitigation TEXT DEFAULT '',

            owner_id INTEGER,
            team TEXT DEFAULT '',

            visibility TEXT DEFAULT 'Private',

            start_date DATE,
            expiry_date DATE,

            status TEXT DEFAULT 'Draft',

            additional_details TEXT DEFAULT '',

            changed_by INTEGER NOT NULL,

            change_summary TEXT DEFAULT '',

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (exception_id)
                REFERENCES patch_exceptions(id)
                ON DELETE CASCADE,

            FOREIGN KEY (changed_by)
                REFERENCES users(id)
        )
    ");


    // ========================================================
    // SOP REVISIONS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sop_revisions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            sop_id INTEGER NOT NULL,

            version TEXT NOT NULL,

            title TEXT NOT NULL,

            content_html TEXT,

            changed_by INTEGER NOT NULL,

            change_summary TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (sop_id) REFERENCES sops(id),

            FOREIGN KEY (changed_by) REFERENCES users(id)
        )
    ");


    // ========================================================
    // SOP ATTACHMENTS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sop_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            sop_id INTEGER NOT NULL,

            original_name TEXT NOT NULL,

            stored_name TEXT NOT NULL,

            file_path TEXT NOT NULL,

            mime_type TEXT,

            file_size INTEGER DEFAULT 0,

            uploaded_by INTEGER NOT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (sop_id) REFERENCES sops(id),

            FOREIGN KEY (uploaded_by) REFERENCES users(id)
        )
    ");


    // ========================================================
    // AUDIT HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS audit_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            module TEXT NOT NULL,

            record_id INTEGER NOT NULL,

            action TEXT NOT NULL,

            performed_by TEXT NOT NULL,

            details TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // ASSET INVENTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            asset_name TEXT NOT NULL,
            asset_type TEXT NOT NULL,

            manufacturer TEXT,
            model TEXT,
            serial_number TEXT,
            service_tag TEXT,
            hostname TEXT,
            ip_address TEXT,

            location TEXT,
            site TEXT,
            region TEXT,
            room TEXT,
            row TEXT,
            rack TEXT,

            cpu_model TEXT,
            cpu_count TEXT,
            total_cores TEXT,
            memory_gb TEXT,
            internal_storage TEXT,
            number_of_nics TEXT,
            hba_details TEXT,
            gpu_details TEXT,

            vlan TEXT,

            purchase_date TEXT,
            vendor TEXT,

            warranty_start_date TEXT,
            warranty_expiry_date TEXT,

            support_vendor TEXT,

            status TEXT,

            end_of_life TEXT,

            remarks TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            updated_by TEXT,
            updated_at DATETIME
        )
    ");


    // ========================================================
    // ASSET HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            asset_id INTEGER,

            action_type TEXT,

            performed_by TEXT,

            details TEXT,

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // SERVER INVENTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            hostname TEXT NOT NULL,
            ip_address TEXT NOT NULL,
            additional_ips TEXT,

            os_family TEXT,
            os_version TEXT,
            kernel_version TEXT,

            cpu TEXT,
            memory TEXT,

            support_level TEXT,
            server_state TEXT,

            domain TEXT,
            joined_in TEXT,

            role TEXT,

            cluster_name TEXT,
            managed_by TEXT,
            cluster_type TEXT,

            project TEXT,
            application TEXT,

            technical_owner TEXT,
            technical_owner_email TEXT,

            team_dl TEXT,

            technical_manager TEXT,
            technical_manager_email TEXT,

            sdm_name TEXT,
            sdm_email TEXT,

            ncgr_owner TEXT,
            ncgr_owner_email TEXT,

            server_type TEXT,
            appliance TEXT,

            port_group TEXT,
            vlan TEXT,

            location TEXT,

            criticality TEXT,

            project_code TEXT,

            commissioned_date TEXT,

            host_type TEXT,
            hw_model TEXT,

            esxi_cluster TEXT,

            vendor TEXT,

            dmz TEXT,

            db_type TEXT,

            live TEXT,
            eol TEXT,

            backup TEXT,
            monitoring TEXT,
            infra TEXT,

            edit_comments TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            updated_by TEXT,
            updated_at DATETIME
        )
    ");


    // ========================================================
    // INVENTORY HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS inventory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            inventory_id INTEGER,

            action_type TEXT,

            performed_by TEXT,

            details TEXT,

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // REMINDERS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS reminders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,

            title TEXT NOT NULL,

            message TEXT NOT NULL,

            reminder_date DATETIME NOT NULL,

            visibility TEXT DEFAULT 'all',

            additional_emails TEXT,

            status TEXT DEFAULT 'pending',

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // STICKY NOTES
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sticky_notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,

            content TEXT NOT NULL,

            visibility TEXT DEFAULT 'all',

            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // BUILDS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS builds (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            build_no TEXT NOT NULL,

            project TEXT NOT NULL,

            status TEXT NOT NULL,

            build_by INTEGER NOT NULL,

            supported_by TEXT,

            build_from TEXT,

            user_id INTEGER NOT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // BUILD ATTACHMENTS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS build_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            build_id INTEGER NOT NULL,

            filename TEXT NOT NULL,

            filepath TEXT NOT NULL,

            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (build_id)
                REFERENCES builds(id)
                ON DELETE CASCADE
        )
    ");


    // ========================================================
    // HANDOVERS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS handovers (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            project_name TEXT NOT NULL,

            project_id TEXT,

            current_owner TEXT NOT NULL,

            new_owner TEXT NOT NULL,

            handover_date TEXT,

            handover_status TEXT,

            reason_for_handover TEXT,

            project_phase TEXT,

            documentation_status TEXT,

            open_issues TEXT,

            pending_actions TEXT,

            risks TEXT,

            dependencies TEXT,

            kt_completed TEXT,

            training_completed TEXT,

            access_transferred TEXT,

            stakeholder_signoff TEXT,

            client_notified TEXT,

            warranty_period TEXT,

            notes TEXT,

            user_id INTEGER NOT NULL,

            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // HELP ARTICLES
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS help_articles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            menu_name TEXT NOT NULL,

            title TEXT NOT NULL,

            content TEXT NOT NULL,

            suggestions TEXT,

            comments TEXT,

            last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,

            is_active INTEGER DEFAULT 1
        )
    ");


    // ========================================================
    // COMMUNICATIONS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS communications (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,

            message TEXT NOT NULL,

            note_type TEXT DEFAULT 'Announcement',

            assigned_to INTEGER,

            priority TEXT DEFAULT 'Normal',

            status TEXT DEFAULT 'Pending',

            target_date TEXT,

            completion_date TEXT,

            created_by INTEGER NOT NULL,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // COMMUNICATION USERS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS communication_users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            communication_id INTEGER NOT NULL,

            user_id INTEGER NOT NULL
        )
    ");


    // ========================================================
    // HANDOVER ATTACHMENTS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS handover_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            handover_id INTEGER NOT NULL,

            filename TEXT NOT NULL,

            filepath TEXT NOT NULL,

            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            FOREIGN KEY (handover_id)
                REFERENCES handovers(id)
                ON DELETE CASCADE
        )
    ");


    // ========================================================
    // IP ADDRESS MANAGEMENT
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ip_ranges (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            ip_range TEXT NOT NULL,

            vlan TEXT,

            subnet TEXT,

            subnet_mask TEXT,

            gateway TEXT,

            network_address TEXT,

            portgroup TEXT,

            cidr TEXT,

            usable_range TEXT,

            broadcast TEXT,

            total_hosts INTEGER DEFAULT 0,

            usable_hosts INTEGER DEFAULT 0,

            environment TEXT,

            project TEXT,

            project_code TEXT,

            comments TEXT,

            created_by TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            updated_by TEXT,

            updated_at DATETIME
        )
    ");


    // ========================================================
    // SAFE IP COLUMN UPGRADES
    // ========================================================

    $ip_columns = [
        "subnet_mask TEXT",
        "network_address TEXT",
        "project_code TEXT",
        "updated_by TEXT",
        "updated_at DATETIME"
    ];

    foreach ($ip_columns as $column) {

        try {

            $pdo->exec(
                "ALTER TABLE ip_ranges ADD COLUMN " . $column
            );

        } catch (PDOException $e) {

            // Column already exists.

        }
    }


    // ========================================================
    // IP RANGE HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ip_ranges_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            ip_range_id INTEGER NOT NULL,

            action_type TEXT NOT NULL,

            old_data TEXT,

            new_data TEXT,

            performed_by TEXT,

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // OWNERSHIP HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ownership_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            ownership_id INTEGER,

            action_type TEXT,

            performed_by TEXT,

            details TEXT,

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // IP COLUMN PREFERENCES
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ip_column_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,

            columns TEXT NOT NULL,

            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // IP TABLE USER COLUMN SETTINGS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ip_column_settings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            username TEXT UNIQUE NOT NULL,

            columns TEXT NOT NULL,

            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // DECOMMISSION
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS decommission (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            hostname TEXT NOT NULL,

            server_state TEXT,

            support_level TEXT,

            project TEXT,

            application_name TEXT,

            ip_address TEXT,

            additional_ips TEXT,

            decommission_start_date TEXT,

            decommission_end_date TEXT,

            created_by TEXT,

            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            updated_by TEXT,

            updated_at DATETIME
        )
    ");


    // ========================================================
    // DECOMMISSION TASKS
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS decommission_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            decommission_id INTEGER,

            task_name TEXT NOT NULL,

            status TEXT DEFAULT 'Pending',

            remarks TEXT
        )
    ");


    // ========================================================
    // DECOMMISSION HISTORY
    // ========================================================

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS decommission_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            decommission_id INTEGER,

            action_type TEXT,

            performed_by TEXT,

            details TEXT,

            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    // ========================================================
    // SAFE DECOMMISSION TASK COLUMN UPGRADES
    // ========================================================

    try {

        $pdo->exec("
            ALTER TABLE decommission_tasks
            ADD COLUMN status TEXT DEFAULT 'Pending'
        ");

    } catch (PDOException $e) {

        // Column already exists.

    }

    try {

        $pdo->exec("
            ALTER TABLE decommission_tasks
            ADD COLUMN remarks TEXT
        ");

    } catch (PDOException $e) {

        // Column already exists.

    }

} catch (PDOException $e) {

    die(
        "Database connection failed: " .
        $e->getMessage()
    );
}


// ============================================================
// KNOWLEDGE BASE
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_number TEXT NOT NULL UNIQUE,

        title TEXT NOT NULL,

        category TEXT NOT NULL,

        description TEXT,

        visibility TEXT NOT NULL DEFAULT 'Private'
            CHECK (visibility IN ('Private', 'Public')),

        content_html TEXT,

        created_by INTEGER NOT NULL,

        updated_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (created_by)
            REFERENCES users(id),

        FOREIGN KEY (updated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_visibility
    ON knowledge_base(visibility)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_created_by
    ON knowledge_base(created_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_category
    ON knowledge_base(category)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_updated_at
    ON knowledge_base(updated_at)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_attachments_kb_id
    ON knowledge_base_attachments(kb_id)
");


// ============================================================
// KNOWLEDGE BASE REVISION HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        version TEXT NOT NULL DEFAULT '1.0',

        title TEXT,

        content_html TEXT,

        changed_by INTEGER,

        change_summary TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (changed_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE REVISION INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_kb_id
    ON knowledge_base_revisions(kb_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_changed_by
    ON knowledge_base_revisions(changed_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_created_at
    ON knowledge_base_revisions(created_at)
");


// ============================================================
// MY DATA
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS my_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        title TEXT NOT NULL,

        short_description TEXT,

        additional_details TEXT,

        visibility TEXT NOT NULL DEFAULT 'Private',

        team_name TEXT,

        shared_user_id INTEGER,

        file_original_name TEXT,

        file_stored_name TEXT,

        file_path TEXT,

        file_mime TEXT,

        file_size INTEGER DEFAULT 0,

        owner_id INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// MY DATA INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_owner
    ON my_data(owner_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_visibility
    ON my_data(visibility)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_team
    ON my_data(team_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_shared_user
    ON my_data(shared_user_id)
");


// ============================================================
// KNOWN ISSUES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_number TEXT UNIQUE NOT NULL,

        title TEXT NOT NULL,

        description TEXT,

        category TEXT,

        severity TEXT DEFAULT 'Medium',

        status TEXT DEFAULT 'Open',

        owner_id INTEGER NOT NULL,

        affected_team TEXT,

        affected_system TEXT,

        environment TEXT,

        symptoms_html TEXT,

        cause_html TEXT,

        workaround_html TEXT,

        resolution_html TEXT,

        notes_html TEXT,

        visibility TEXT DEFAULT 'Private',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        resolved_at DATETIME,

        FOREIGN KEY (owner_id)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWN ISSUE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issue_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (issue_id)
            REFERENCES known_issues(id),

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// HOSTNAME GENERATOR
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_generators (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL UNIQUE,

        environment TEXT NOT NULL,

        platform TEXT NOT NULL,

        os_code TEXT NOT NULL,

        host_type TEXT NOT NULL,

        project_name TEXT NOT NULL,

        application_name TEXT NOT NULL,

        sequence_number INTEGER NOT NULL,

        generated_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (generated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// HOSTNAME RESERVATIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL UNIQUE,

        platform_key TEXT NOT NULL,

        platform_code TEXT NOT NULL,

        environment_key TEXT NOT NULL,

        environment_code TEXT NOT NULL,

        os_key TEXT NOT NULL,

        os_code TEXT NOT NULL,

        physical_virtual TEXT NOT NULL,

        project_name TEXT DEFAULT '',

        project_code TEXT DEFAULT '',

        project_abbreviation TEXT DEFAULT '',

        application_name TEXT DEFAULT '',

        application_abbreviation TEXT DEFAULT '',

        node_number INTEGER DEFAULT 1,

        status TEXT NOT NULL DEFAULT 'Reserved',

        generated_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (generated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// HOSTNAME RESERVATION INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_project
    ON hostname_reservations(project_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_project_code
    ON hostname_reservations(project_code)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_application
    ON hostname_reservations(application_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_status
    ON hostname_reservations(status)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_generated_by
    ON hostname_reservations(generated_by)
");


// ============================================================
// INVENTORY HOSTNAME UNIQUE INDEX
// ============================================================
//
// This prevents duplicate hostnames in inventory.
//
// If the existing inventory table contains duplicate hostnames,
// SQLite will reject this index. Clean duplicates first if needed.
//

try {

    $pdo->exec("
        CREATE UNIQUE INDEX IF NOT EXISTS
        idx_inventory_hostname_unique
        ON inventory(hostname)
    ");

} catch (PDOException $e) {

    // Existing duplicate hostnames can prevent this index.
    // Do not stop database initialization.

}


// ============================================================
// HOSTNAME GENERATOR CODES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_generator_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        category TEXT NOT NULL,

        code_key TEXT NOT NULL,

        code_value TEXT NOT NULL,

        is_admin_only INTEGER NOT NULL DEFAULT 1,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        UNIQUE(category, code_key),

        UNIQUE(category, code_value)
    )
");


// ============================================================
// DEFAULT HOSTNAME CODES
// ============================================================
//
// Platform = exactly 3 characters
// Environment = exactly 1 character
// OS = exactly 1 character
//

$hostname_codes = [

    // --------------------------------------------------------
    // PLATFORM
    // --------------------------------------------------------

    ['platform', 'production', 'RY1'],
    ['platform', 'dr',         'DC2'],
    ['platform', 'gcp',        'GCP'],
    ['platform', 'nutanix',    'NTX'],
    ['platform', 'ugrp',       'UGR'],


    // --------------------------------------------------------
    // ENVIRONMENT
    // --------------------------------------------------------

    ['environment', 'production', 'P'],
    ['environment', 'dr',         'D'],
    ['environment', 'sandbox',    'S'],
    ['environment', 'poc',        'O'],
    ['environment', 'dev',        'V'],
    ['environment', 'test',       'T'],
    ['environment', 'management', 'M'],
    ['environment', 'preprod',    'R'],


    // --------------------------------------------------------
    // OPERATING SYSTEM
    // --------------------------------------------------------

    ['os', 'windows',    'W'],
    ['os', 'redhat',     'R'],
    ['os', 'coreos',     'C'],
    ['os', 'appliance',  'A'],
    ['os', 'rockylinux', 'K'],
    ['os', 'esxi',       'E']
];


// ============================================================
// INSERT DEFAULT HOSTNAME CODES
// ============================================================

$stmt_hostname_codes = $pdo->prepare("
    INSERT OR IGNORE INTO hostname_generator_codes
    (
        category,
        code_key,
        code_value,
        is_admin_only
    )
    VALUES
    (
        ?,
        ?,
        ?,
        1
    )
");

foreach ($hostname_codes as $code) {

    $stmt_hostname_codes->execute([
        $code[0],
        $code[1],
        $code[2]
    ]);

}





$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_platforms (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_key TEXT NOT NULL UNIQUE,

    platform_name TEXT NOT NULL,

    category TEXT NOT NULL DEFAULT 'Red Hat',

    description TEXT DEFAULT '',

    framework TEXT DEFAULT 'CIS',

    benchmark_name TEXT DEFAULT '',

    benchmark_version TEXT DEFAULT '',

    is_active INTEGER NOT NULL DEFAULT 1,

    sort_order INTEGER NOT NULL DEFAULT 0,

    created_by INTEGER,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
)
");

/*
|--------------------------------------------------------------------------
| Compliance Controls
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_controls (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_id INTEGER NOT NULL,

    control_number TEXT NOT NULL,

    title TEXT NOT NULL,

    description TEXT DEFAULT '',

    section_name TEXT DEFAULT '',

    level TEXT DEFAULT 'Level 1',

    severity TEXT DEFAULT 'Medium',

    control_type TEXT DEFAULT 'Configuration',

    value_type TEXT DEFAULT 'Text',

    cis_value TEXT DEFAULT '',

    ncgr_value TEXT DEFAULT '',

    unit TEXT DEFAULT '',

    remediation TEXT DEFAULT '',

    audit_procedure TEXT DEFAULT '',

    source_reference TEXT DEFAULT '',

    cis_version TEXT DEFAULT '',

    is_custom INTEGER NOT NULL DEFAULT 0,

    is_enabled INTEGER NOT NULL DEFAULT 1,

    sort_order INTEGER NOT NULL DEFAULT 0,

    created_by INTEGER,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    updated_by INTEGER,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (platform_id)
        REFERENCES compliance_platforms(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id),

    FOREIGN KEY (updated_by)
        REFERENCES users(id),

    UNIQUE(platform_id, control_number)
)
");

/*
|--------------------------------------------------------------------------
| Compliance Audit
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_audit (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_id INTEGER,

    control_id INTEGER,

    action TEXT NOT NULL,

    performed_by TEXT NOT NULL,

    old_value TEXT,

    new_value TEXT,

    details TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (platform_id)
        REFERENCES compliance_platforms(id)
        ON DELETE SET NULL,

    FOREIGN KEY (control_id)
        REFERENCES compliance_controls(id)
        ON DELETE SET NULL
)
");

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_platform_category
ON compliance_platforms(category)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_platform
ON compliance_controls(platform_id)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_severity
ON compliance_controls(severity)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_enabled
ON compliance_controls(is_enabled)
");

/*
|--------------------------------------------------------------------------
| Default Platforms
|--------------------------------------------------------------------------
|
| One and only one record for each platform.
|
*/

$platforms = [

    [
        'rhel',
        'RHEL',
        'Red Hat',
        'Red Hat Enterprise Linux security compliance.',
        'CIS',
        'CIS Red Hat Enterprise Linux 9 Benchmark',
        '2.0.0',
        10
    ],

    [
        'openshift',
        'OpenShift',
        'Red Hat',
        'Red Hat OpenShift Container Platform security compliance.',
        'CIS',
        'CIS Red Hat OpenShift Container Platform Benchmark',
        '1.9.0',
        20
    ],

    [
        'ipa',
        'IPA',
        'Red Hat',
        'Identity Management / FreeIPA security policy.',
        'NCGR / Custom',
        '',
        '',
        30
    ],

    [
        'satellite',
        'Satellite',
        'Red Hat',
        'Red Hat Satellite security policy.',
        'NCGR / Custom',
        '',
        '',
        40
    ],

    [
        'kubernetes',
        'Kubernetes',
        'Red Hat',
        'Kubernetes cluster security compliance.',
        'CIS',
        'CIS Kubernetes Benchmark',
        '2.0.1',
        50
    ]
];

$stmt = $pdo->prepare("
    INSERT OR IGNORE INTO compliance_platforms
    (
        platform_key,
        platform_name,
        category,
        description,
        framework,
        benchmark_name,
        benchmark_version,
        sort_order
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

foreach ($platforms as $platform) {

    $stmt->execute($platform);
}

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function compliance_platform_id(PDO $pdo, string $key): ?int
{
    $stmt = $pdo->prepare("
        SELECT id
        FROM compliance_platforms
        WHERE platform_key = ?
        LIMIT 1
    ");

    $stmt->execute([$key]);

    $id = $stmt->fetchColumn();

    return $id ? (int)$id : null;
}

/*
|--------------------------------------------------------------------------
| Seed Controls
|--------------------------------------------------------------------------
|
| These are baseline examples / commonly used controls.
|
| The application supports importing the complete benchmark data
| from your authorized CIS benchmark source rather than embedding
| the complete copyrighted benchmark text into the application.
|
|--------------------------------------------------------------------------
*/

$seedControls = [

    /*
    |--------------------------------------------------------------------------
    | RHEL
    |--------------------------------------------------------------------------
    */

    [
        'rhel',
        '5.4.1',
        'Ensure password expiration is configured',
        'Configure maximum password age according to security policy.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '90',
        '30',
        'Days'
    ],

    [
        'rhel',
        '5.4.2',
        'Ensure minimum password age is configured',
        'Configure minimum password age to prevent rapid password cycling.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '1',
        '1',
        'Days'
    ],

    [
        'rhel',
        '5.4.3',
        'Ensure password expiration warning is configured',
        'Configure the password expiration warning period.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '7',
        '7',
        'Days'
    ],

    [
        'rhel',
        '5.4.4',
        'Ensure inactive password lock is configured',
        'Configure inactive accounts according to security policy.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '30',
        '15',
        'Days'
    ],

    [
        'rhel',
        '5.3.1',
        'Ensure SSH root login is disabled',
        'Direct SSH login using the root account should be disabled.',
        'SSH Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '5.3.2',
        'Ensure SSH empty passwords are disabled',
        'SSH must not allow authentication using empty passwords.',
        'SSH Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '5.3.3',
        'Ensure SSH X11 forwarding is disabled',
        'Disable X11 forwarding unless explicitly required.',
        'SSH Server',
        'Level 1',
        'Medium',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '1.1.1',
        'Ensure filesystem configuration is secure',
        'Ensure required filesystem configuration follows the approved security baseline.',
        'Filesystem Configuration',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    /*
    |--------------------------------------------------------------------------
    | OpenShift
    |--------------------------------------------------------------------------
    */

    [
        'openshift',
        '1.1.1',
        'Ensure authentication configuration is secured',
        'Ensure cluster authentication configuration follows the approved security baseline.',
        'Control Plane Configuration',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '1.2.1',
        'Ensure API server access is restricted',
        'Restrict access to the OpenShift API server to authorized sources.',
        'API Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '1.3.1',
        'Ensure audit logging is enabled',
        'Cluster audit logging must be enabled and retained according to policy.',
        'Logging',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '5.1.1',
        'Ensure RBAC is configured securely',
        'Use role based access controls and least privilege.',
        'RBAC',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    /*
    |--------------------------------------------------------------------------
    | Kubernetes
    |--------------------------------------------------------------------------
    */

    [
        'kubernetes',
        '1.1.1',
        'Ensure API server authentication is configured securely',
        'Ensure API server authentication mechanisms follow the security baseline.',
        'API Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '1.2.1',
        'Ensure audit logging is enabled',
        'Ensure Kubernetes audit logging is enabled and retained.',
        'Logging',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '5.1.1',
        'Ensure RBAC is configured',
        'Use RBAC and least privilege for Kubernetes resources.',
        'RBAC',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '5.2.1',
        'Ensure privileged containers are restricted',
        'Restrict privileged container execution.',
        'Pod Security',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Restricted',
        'Restricted',
        ''
    ]
];

/*
|--------------------------------------------------------------------------
| Insert Seed Controls
|--------------------------------------------------------------------------
*/

$stmtControl = $pdo->prepare("
    INSERT OR IGNORE INTO compliance_controls
    (
        platform_id,
        control_number,
        title,
        description,
        section_name,
        level,
        severity,
        control_type,
        value_type,
        cis_value,
        ncgr_value,
        unit,
        cis_version
    )
    VALUES
    (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        (
            SELECT benchmark_version
            FROM compliance_platforms
            WHERE id = ?
        )
    )
");

foreach ($seedControls as $control) {

    $platformKey = $control[0];

    $platformId = compliance_platform_id(
        $pdo,
        $platformKey
    );

    if (!$platformId) {
        continue;
    }

    $stmtControl->execute([
        $platformId,
        $control[1],
        $control[2],
        $control[3],
        $control[4],
        $control[5],
        $control[6],
        $control[7],
        $control[8],
        $control[9],
        $control[10],
        $control[11],
        $platformId
    ]);
}


// ============================================================
// DATABASE READY
// ============================================================

?>
