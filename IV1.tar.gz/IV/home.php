<?php

session_start();

$page_title = "Dashboard";

include "includes/header.php";

include "includes/sidebar.php";

?>


<main class="content">


<div class="dashboard-header">


    <div>

        <h1>
            Welcome back, <?= $_SESSION['name'] ?? 'Admin'; ?> 👋
        </h1>


        <p>
            Here is your IT infrastructure overview
        </p>

    </div>



    <div class="dashboard-actions">

        <button>
            Export Report
        </button>


        <button>
            Refresh
        </button>

    </div>


</div>





<!-- KPI CARDS -->

<div class="stats-grid">


<div class="dashboard-card">

<div class="card-icon blue">
🖥
</div>

<div>

<span>
Total Assets
</span>

<h2>
12,540
</h2>

<p class="success">
↑ 8.4% this month
</p>

</div>

</div>





<div class="dashboard-card">

<div class="card-icon green">
🗄
</div>

<div>

<span>
Servers
</span>

<h2>
482
</h2>

<p>
Stable
</p>

</div>

</div>





<div class="dashboard-card">

<div class="card-icon orange">
📄
</div>

<div>

<span>
Licenses
</span>

<h2>
1,260
</h2>

<p>
24 Expiring
</p>

</div>

</div>





<div class="dashboard-card">

<div class="card-icon red">
🛡
</div>

<div>

<span>
Security Issues
</span>

<h2>
24
</h2>

<p>
Critical Findings
</p>

</div>

</div>



</div>








<!-- CHART ROW -->

<div class="dashboard-row">



<div class="dashboard-panel large">


<div class="panel-header">

<h3>
Asset Growth
</h3>

<span>
Last 12 Months
</span>

</div>


<div class="chart-container">

<canvas id="assetChart"></canvas>

</div>


</div>





<div class="dashboard-panel">


<div class="panel-header">

<h3>
Asset Types
</h3>

</div>


<div class="chart-container">

<canvas id="typeChart"></canvas>

</div>


</div>



</div>









<!-- LOWER ROW -->

<div class="dashboard-row">



<div class="dashboard-panel">


<h3>
Compliance Status
</h3>



<div class="compliance">


<div>

<span>
Security Compliance
</span>


<strong>
98%
</strong>


</div>


<div class="progress">

<div style="width:98%">
</div>

</div>


</div>


</div>







<div class="dashboard-panel">


<h3>
Recent Activities
</h3>


<ul class="activity">

<li>
New server added
</li>


<li>
License renewal completed
</li>


<li>
Quarterly patching completed
</li>


<li>
New user awaiting approval
</li>


</ul>


</div>



</div>



</main>



<?php

include "includes/footer.php";

?>



<script src="assets/js/chart.min.js"></script>


<script>


const assetChart =
document.getElementById('assetChart');


if(assetChart){


new Chart(
assetChart,
{

type:'line',

data:{


labels:[

"Jan",
"Feb",
"Mar",
"Apr",
"May",
"Jun",
"Jul",
"Aug",
"Sep",
"Oct",
"Nov",
"Dec"

],


datasets:[{

label:"Assets",

data:[

8500,
9000,
9200,
9700,
10000,
10500,
11000,
11400,
11800,
12100,
12500,
12540

],


borderColor:"#4F46E5",

backgroundColor:
"rgba(79,70,229,.1)",


fill:true,

tension:.4


}]


},

options:{


responsive:true,

maintainAspectRatio:false


}

});

}



const typeChart =
document.getElementById('typeChart');


if(typeChart){


new Chart(

typeChart,

{

type:'doughnut',

data:{


labels:[

"Servers",
"Network",
"Software",
"Other"

],


datasets:[{

data:[

45,
25,
20,
10

],


backgroundColor:[

"#4F46E5",
"#10B981",
"#F59E0B",
"#94A3B8"

]


}]


},

options:{


responsive:true,

maintainAspectRatio:false


}


}

);


}



</script>
