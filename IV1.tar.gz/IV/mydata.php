<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect_data($id = null): void
{
    if ($id !== null) {
        header('Location: mydata.php?view=' . (int) $id);
    } else {
        header('Location: mydata.php');
    }

    exit;
}

function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| Upload directory
|--------------------------------------------------------------------------
*/

$upload_dir_fs = __DIR__ . '/uploads/mydata';

if (!is_dir($upload_dir_fs)) {
    mkdir($upload_dir_fs, 0755, true);
}


/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

function can_view_data(array $row, int $user_id, bool $is_admin): bool
{
    if ($is_admin) {
        return true;
    }

    if ((int) $row['owner_id'] === $user_id) {
        return true;
    }

    $visibility = $row['visibility'] ?? 'Private';

    if ($visibility === 'Public') {
        return true;
    }

    if (
        $visibility === 'Person' &&
        (int) ($row['shared_user_id'] ?? 0) === $user_id
    ) {
        return true;
    }

    if (
        $visibility === 'Team' &&
        isset($row['team_name']) &&
        isset($row['viewer_team']) &&
        $row['team_name'] !== '' &&
        $row['team_name'] === $row['viewer_team']
    ) {
        return true;
    }

    return false;
}

function can_edit_data(array $row, int $user_id, bool $is_admin): bool
{
    return $is_admin || (int) $row['owner_id'] === $user_id;
}

function can_delete_data(array $row, int $user_id, bool $is_admin): bool
{
    return $is_admin || (int) $row['owner_id'] === $user_id;
}


/*
|--------------------------------------------------------------------------
| Current user's team
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT team
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$current_user_id]);

$current_user_team = trim((string) $stmt->fetchColumn());


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg = $_SESSION['mydata_success'] ?? '';
$error_msg = $_SESSION['mydata_error'] ?? '';

unset(
    $_SESSION['mydata_success'],
    $_SESSION['mydata_error']
);


/*
|--------------------------------------------------------------------------
| ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $form_action = $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE DATA
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_data') {

        $data_id = (int) ($_POST['data_id'] ?? 0);

        $title = trim($_POST['title'] ?? '');
        $short_description = trim($_POST['short_description'] ?? '');
        $additional_details = trim($_POST['additional_details'] ?? '');

        $visibility = trim($_POST['visibility'] ?? 'Private');

        $team_name = trim($_POST['team_name'] ?? '');
        $shared_user_id = (int) ($_POST['shared_user_id'] ?? 0);

        if ($title === '') {
            $_SESSION['mydata_error'] = 'Name / title is required.';
            redirect_data($data_id ?: null);
        }

        if (!in_array($visibility, ['Private', 'Public', 'Team', 'Person'], true)) {
            $_SESSION['mydata_error'] = 'Invalid sharing option.';
            redirect_data($data_id ?: null);
        }


        /*
        |--------------------------------------------------------------------------
        | TEAM VALIDATION
        |--------------------------------------------------------------------------
        */

        if ($visibility === 'Team') {

            if ($team_name === '') {
                $_SESSION['mydata_error'] = 'Please select a team.';
                redirect_data($data_id ?: null);
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM users
                WHERE is_approved = 1
                  AND team = ?
            ");

            $stmt->execute([$team_name]);

            if ((int) $stmt->fetchColumn() === 0) {
                $_SESSION['mydata_error'] = 'Selected team does not exist.';
                redirect_data($data_id ?: null);
            }

        } else {
            $team_name = null;
        }


        /*
        |--------------------------------------------------------------------------
        | PERSON VALIDATION
        |--------------------------------------------------------------------------
        */

        if ($visibility === 'Person') {

            if ($shared_user_id <= 0) {
                $_SESSION['mydata_error'] = 'Please select a user.';
                redirect_data($data_id ?: null);
            }

            $stmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM users
                WHERE id = ?
                  AND is_approved = 1
            ");

            $stmt->execute([$shared_user_id]);

            if ((int) $stmt->fetchColumn() === 0) {
                $_SESSION['mydata_error'] = 'Selected user does not exist.';
                redirect_data($data_id ?: null);
            }

        } else {
            $shared_user_id = null;
        }


        /*
        |--------------------------------------------------------------------------
        | NEW RECORD
        |--------------------------------------------------------------------------
        */

        if ($data_id === 0) {

            $file_original_name = null;
            $file_stored_name = null;
            $file_path = null;
            $file_mime = null;
            $file_size = 0;


            /*
            |--------------------------------------------------------------------------
            | FILE UPLOAD
            |--------------------------------------------------------------------------
            */

            if (
                isset($_FILES['data_file']) &&
                $_FILES['data_file']['error'] !== UPLOAD_ERR_NO_FILE
            ) {

                if ($_FILES['data_file']['error'] !== UPLOAD_ERR_OK) {
                    $_SESSION['mydata_error'] = 'File upload failed.';
                    redirect_data();
                }

                $file = $_FILES['data_file'];

                /*
                | 100 MB maximum
                */

                if ($file['size'] > 100 * 1024 * 1024) {
                    $_SESSION['mydata_error'] = 'Maximum file size is 100 MB.';
                    redirect_data();
                }

                $file_original_name = basename($file['name']);

                $safe_name = preg_replace(
                    '/[^a-zA-Z0-9._-]/',
                    '_',
                    $file_original_name
                );

                $file_stored_name =
                    bin2hex(random_bytes(16)) . '_' . $safe_name;

                $destination =
                    $upload_dir_fs . '/' . $file_stored_name;

                if (!move_uploaded_file(
                    $file['tmp_name'],
                    $destination
                )) {
                    $_SESSION['mydata_error'] =
                        'Unable to save uploaded file.';

                    redirect_data();
                }

                $file_path =
                    'uploads/mydata/' . $file_stored_name;

                $file_mime =
                    mime_content_type($destination)
                    ?: 'application/octet-stream';

                $file_size =
                    filesize($destination);
            }


            /*
            |--------------------------------------------------------------------------
            | INSERT
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                INSERT INTO my_data (
                    title,
                    short_description,
                    additional_details,
                    visibility,
                    team_name,
                    shared_user_id,
                    file_original_name,
                    file_stored_name,
                    file_path,
                    file_mime,
                    file_size,
                    owner_id,
                    created_at,
                    updated_at
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");

            $stmt->execute([
                $title,
                $short_description,
                $additional_details,
                $visibility,
                $team_name,
                $shared_user_id,
                $file_original_name,
                $file_stored_name,
                $file_path,
                $file_mime,
                $file_size,
                $current_user_id
            ]);

            $_SESSION['mydata_success'] =
                'Data shared successfully.';

            redirect_data();
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM my_data
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$data_id]);

        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {
            $_SESSION['mydata_error'] = 'Data record not found.';
            redirect_data();
        }

        if (!can_edit_data(
            $existing,
            $current_user_id,
            $is_admin
        )) {
            http_response_code(403);
            exit('You do not have permission to edit this record.');
        }


        /*
        |--------------------------------------------------------------------------
        | Existing file
        |--------------------------------------------------------------------------
        */

        $file_original_name =
            $existing['file_original_name'];

        $file_stored_name =
            $existing['file_stored_name'];

        $file_path =
            $existing['file_path'];

        $file_mime =
            $existing['file_mime'];

        $file_size =
            (int) $existing['file_size'];


        /*
        |--------------------------------------------------------------------------
        | Replace file
        |--------------------------------------------------------------------------
        */

        if (
            isset($_FILES['data_file']) &&
            $_FILES['data_file']['error'] !== UPLOAD_ERR_NO_FILE
        ) {

            if ($_FILES['data_file']['error'] !== UPLOAD_ERR_OK) {
                $_SESSION['mydata_error'] =
                    'File upload failed.';

                redirect_data($data_id);
            }

            $file = $_FILES['data_file'];

            if ($file['size'] > 100 * 1024 * 1024) {
                $_SESSION['mydata_error'] =
                    'Maximum file size is 100 MB.';

                redirect_data($data_id);
            }

            $file_original_name =
                basename($file['name']);

            $safe_name = preg_replace(
                '/[^a-zA-Z0-9._-]/',
                '_',
                $file_original_name
            );

            $file_stored_name =
                bin2hex(random_bytes(16))
                . '_' . $safe_name;

            $destination =
                $upload_dir_fs . '/' . $file_stored_name;

            if (!move_uploaded_file(
                $file['tmp_name'],
                $destination
            )) {
                $_SESSION['mydata_error'] =
                    'Unable to save uploaded file.';

                redirect_data($data_id);
            }

            /*
            | Delete old file
            */

            if (!empty($existing['file_path'])) {

                $old_file =
                    __DIR__ . '/' .
                    ltrim(
                        $existing['file_path'],
                        '/\\'
                    );

                if (is_file($old_file)) {
                    @unlink($old_file);
                }
            }

            $file_path =
                'uploads/mydata/' .
                $file_stored_name;

            $file_mime =
                mime_content_type($destination)
                ?: 'application/octet-stream';

            $file_size =
                filesize($destination);
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            UPDATE my_data
            SET
                title = ?,
                short_description = ?,
                additional_details = ?,
                visibility = ?,
                team_name = ?,
                shared_user_id = ?,
                file_original_name = ?,
                file_stored_name = ?,
                file_path = ?,
                file_mime = ?,
                file_size = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");

        $stmt->execute([
            $title,
            $short_description,
            $additional_details,
            $visibility,
            $team_name,
            $shared_user_id,
            $file_original_name,
            $file_stored_name,
            $file_path,
            $file_mime,
            $file_size,
            $data_id
        ]);

        $_SESSION['mydata_success'] =
            'Data updated successfully.';

        redirect_data($data_id);
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_data') {

        $data_id = (int) ($_POST['data_id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT *
            FROM my_data
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$data_id]);

        $existing = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {
            $_SESSION['mydata_error'] =
                'Data record not found.';

            redirect_data();
        }

        if (!can_delete_data(
            $existing,
            $current_user_id,
            $is_admin
        )) {
            http_response_code(403);
            exit('You do not have permission to delete this record.');
        }


        /*
        | Delete physical file
        */

        if (!empty($existing['file_path'])) {

            $file =
                __DIR__ . '/' .
                ltrim(
                    $existing['file_path'],
                    '/\\'
                );

            if (is_file($file)) {
                @unlink($file);
            }
        }


        $stmt = $pdo->prepare("
            DELETE FROM my_data
            WHERE id = ?
        ");

        $stmt->execute([$data_id]);

        $_SESSION['mydata_success'] =
            'Data deleted successfully.';

        redirect_data();
    }
}


/*
|--------------------------------------------------------------------------
| FILE DOWNLOAD
|--------------------------------------------------------------------------
*/

if (isset($_GET['download'])) {

    $data_id = (int) $_GET['download'];

    $stmt = $pdo->prepare("
        SELECT
            d.*,
            owner.team AS viewer_team
        FROM my_data d
        LEFT JOIN users owner
            ON owner.id = ?
        WHERE d.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $current_user_id,
        $data_id
    ]);

    $data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$data) {
        http_response_code(404);
        exit('Data not found.');
    }


    /*
    | Need viewer team separately because owner.team alias
    | above represents current user's team.
    */

    $data['viewer_team'] = $current_user_team;

    if (!can_view_data(
        $data,
        $current_user_id,
        $is_admin
    )) {
        http_response_code(403);
        exit('You do not have permission to download this file.');
    }


    if (empty($data['file_path'])) {
        http_response_code(404);
        exit('No file attached.');
    }

    $file =
        __DIR__ . '/' .
        ltrim(
            $data['file_path'],
            '/\\'
        );

    if (!is_file($file)) {
        http_response_code(404);
        exit('File not found.');
    }

    $mime =
        $data['file_mime']
        ?: 'application/octet-stream';

    header('Content-Type: ' . $mime);

    header(
        'Content-Length: ' .
        filesize($file)
    );

    header(
        'Content-Disposition: attachment; filename="' .
        basename($data['file_original_name']) .
        '"'
    );

    header(
        'X-Content-Type-Options: nosniff'
    );

    readfile($file);
    exit;
}


/*
|--------------------------------------------------------------------------
| USERS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        id,
        first_name,
        last_name,
        email,
        team
    FROM users
    WHERE is_approved = 1
    ORDER BY first_name, last_name
");

$users = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| TEAMS
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT DISTINCT team
    FROM users
    WHERE is_approved = 1
      AND TRIM(team) <> ''
    ORDER BY team
");

$teams = $stmt->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| VIEW RECORD
|--------------------------------------------------------------------------
*/

$view_id = (int) ($_GET['view'] ?? 0);

$view_data = null;

if ($view_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            d.*,

            owner.first_name AS owner_first,
            owner.last_name AS owner_last,
            owner.email AS owner_email,
            owner.team AS owner_team,

            shared.first_name AS shared_first,
            shared.last_name AS shared_last,
            shared.email AS shared_email

        FROM my_data d

        LEFT JOIN users owner
            ON owner.id = d.owner_id

        LEFT JOIN users shared
            ON shared.id = d.shared_user_id

        WHERE d.id = ?

        LIMIT 1
    ");

    $stmt->execute([$view_id]);

    $view_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$view_data) {
        $_SESSION['mydata_error'] =
            'Data record not found.';

        redirect_data();
    }

    $view_data['viewer_team'] =
        $current_user_team;

    if (!can_view_data(
        $view_data,
        $current_user_id,
        $is_admin
    )) {
        http_response_code(403);
        exit('You do not have permission to view this data.');
    }
}


/*
|--------------------------------------------------------------------------
| EDIT RECORD
|--------------------------------------------------------------------------
*/

$edit_id = (int) ($_GET['edit'] ?? 0);

$edit_data = null;

if ($edit_id > 0) {

    $stmt = $pdo->prepare("
        SELECT *
        FROM my_data
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$edit_id]);

    $edit_data = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$edit_data) {
        $_SESSION['mydata_error'] =
            'Data record not found.';

        redirect_data();
    }

    if (!can_edit_data(
        $edit_data,
        $current_user_id,
        $is_admin
    )) {
        http_response_code(403);
        exit('You do not have permission to edit this record.');
    }
}


/*
|--------------------------------------------------------------------------
| LIBRARY
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT
        d.*,

        owner.first_name AS owner_first,
        owner.last_name AS owner_last,
        owner.team AS owner_team,

        shared.first_name AS shared_first,
        shared.last_name AS shared_last

    FROM my_data d

    LEFT JOIN users owner
        ON owner.id = d.owner_id

    LEFT JOIN users shared
        ON shared.id = d.shared_user_id

    ORDER BY d.updated_at DESC
");

$stmt->execute();

$all_data = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| Filter records based on permissions
|--------------------------------------------------------------------------
*/

$visible_data = [];

foreach ($all_data as $row) {

    $row['viewer_team'] =
        $current_user_team;

    if (can_view_data(
        $row,
        $current_user_id,
        $is_admin
    )) {
        $visible_data[] = $row;
    }
}


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$total_data = count($visible_data);

$my_data_count = 0;
$public_count = 0;
$team_count = 0;
$private_count = 0;

foreach ($visible_data as $row) {

    if ((int) $row['owner_id'] === $current_user_id) {
        $my_data_count++;
    }

    switch ($row['visibility']) {

        case 'Public':
            $public_count++;
            break;

        case 'Team':
            $team_count++;
            break;

        case 'Private':
            $private_count++;
            break;
    }
}


$page_title = 'My Data';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<link rel="stylesheet" href="assets/css/mydata.css">

<div class="content mydata-content">

    <?php if ($success_msg): ?>
        <div class="mydata-alert success">
            <?= h($success_msg) ?>
        </div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="mydata-alert error">
            <?= h($error_msg) ?>
        </div>
    <?php endif; ?>


    <!-- HEADER -->

    <div class="mydata-page-header">

        <div>
            <h1>My Data</h1>
            <p>
                Share files and information with your team,
                colleagues or the entire portal.
            </p>
        </div>

        <button
            type="button"
            class="mydata-primary-btn"
            onclick="openDataModal()"
        >
            + Share Data
        </button>

    </div>


    <!-- STATS -->

    <div class="mydata-stats">

        <div class="mydata-stat-card">
            <span>Available to Me</span>
            <strong><?= $total_data ?></strong>
        </div>

        <div class="mydata-stat-card">
            <span>My Data</span>
            <strong><?= $my_data_count ?></strong>
        </div>

        <div class="mydata-stat-card public">
            <span>Public</span>
            <strong><?= $public_count ?></strong>
        </div>

        <div class="mydata-stat-card team">
            <span>Team Shared</span>
            <strong><?= $team_count ?></strong>
        </div>

        <div class="mydata-stat-card private">
            <span>Private</span>
            <strong><?= $private_count ?></strong>
        </div>

    </div>


    <!-- LIBRARY -->

    <div class="mydata-panel">

        <div class="mydata-panel-header">

            <div>
                <h2>Data Library</h2>
                <span>
                    Files and information shared with you
                </span>
            </div>

            <input
                type="text"
                id="myDataSearch"
                class="mydata-search"
                placeholder="Search data..."
            >

        </div>


        <div class="mydata-table-wrapper">

            <table class="mydata-table">

                <thead>

                    <tr>
                        <th>Name</th>
                        <th>Description</th>
                        <th>Owner</th>
                        <th>Sharing</th>
                        <th>File</th>
                        <th>Updated</th>
                        <th>Actions</th>
                    </tr>

                </thead>

                <tbody>

                <?php if (!$visible_data): ?>

                    <tr>
                        <td
                            colspan="7"
                            class="mydata-empty"
                        >
                            No shared data is available.
                        </td>
                    </tr>

                <?php endif; ?>


                <?php foreach ($visible_data as $row): ?>

                    <?php

                    $owner_name =
                        trim(
                            $row['owner_first'] . ' ' .
                            $row['owner_last']
                        );

                    $can_edit =
                        can_edit_data(
                            $row,
                            $current_user_id,
                            $is_admin
                        );

                    $can_delete =
                        can_delete_data(
                            $row,
                            $current_user_id,
                            $is_admin
                        );

                    ?>

                    <tr>

                        <td>

                            <a
                                href="mydata.php?view=<?= (int) $row['id'] ?>"
                                class="mydata-title"
                            >
                                <?= h($row['title']) ?>
                            </a>

                        </td>


                        <td>

                            <?= h(
                                substr($row['description'] ?? '', 0, 80)
                            ) ?>

                        </td>


                        <td>

                            <?= h(
                                $owner_name ?: 'Unknown'
                            ) ?>

                        </td>


                        <td>

                            <?php if ($row['visibility'] === 'Private'): ?>

                                <span class="sharing-badge private">
                                    Private
                                </span>

                            <?php elseif ($row['visibility'] === 'Public'): ?>

                                <span class="sharing-badge public">
                                    Public
                                </span>

                            <?php elseif ($row['visibility'] === 'Team'): ?>

                                <span class="sharing-badge team">
                                    Team:
                                    <?= h($row['team_name']) ?>
                                </span>

                            <?php else: ?>

                                <span class="sharing-badge person">
                                    Person:
                                    <?= h(
                                        trim(
                                            $row['shared_first'] . ' ' .
                                            $row['shared_last']
                                        )
                                    ) ?>
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?php if (!empty($row['file_original_name'])): ?>

                                <a
                                    href="mydata.php?download=<?= (int) $row['id'] ?>"
                                    class="mydata-download"
                                >
                                    Download
                                </a>

                            <?php else: ?>

                                <span class="muted">
                                    No file
                                </span>

                            <?php endif; ?>

                        </td>


                        <td>

                            <?= h(
                                date(
                                    'd M Y',
                                    strtotime(
                                        $row['updated_at']
                                    )
                                )
                            ) ?>

                        </td>


                        <td>

                            <div class="mydata-actions">

                                <a
                                    href="mydata.php?view=<?= (int) $row['id'] ?>"
                                >
                                    View
                                </a>


                                <?php if ($can_edit): ?>

                                    <a
                                        class="edit"
                                        href="mydata.php?edit=<?= (int) $row['id'] ?>"
                                    >
                                        Edit
                                    </a>

                                <?php endif; ?>


                                <?php if ($can_delete): ?>

                                    <form
                                        method="POST"
                                        action="mydata.php"
                                        onsubmit="return confirm('Delete this data permanently?');"
                                    >

                                        <input
                                            type="hidden"
                                            name="csrf_token"
                                            value="<?= h($csrf_token) ?>"
                                        >

                                        <input
                                            type="hidden"
                                            name="form_action"
                                            value="delete_data"
                                        >

                                        <input
                                            type="hidden"
                                            name="data_id"
                                            value="<?= (int) $row['id'] ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="delete"
                                        >
                                            Delete
                                        </button>

                                    </form>

                                <?php endif; ?>

                            </div>

                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>


<!-- ============================================================
     CREATE / EDIT MODAL
============================================================ -->

<div
    id="dataModal"
    class="mydata-modal"
    style="<?= $edit_data ? 'display:flex;' : 'display:none;' ?>"
>

    <div class="mydata-modal-backdrop" onclick="closeDataModal()"></div>

    <div class="mydata-modal-dialog">

        <div class="mydata-modal-header">

            <div>

                <h2>
                    <?= $edit_data
                        ? 'Edit Shared Data'
                        : 'Share Data' ?>
                </h2>

                <span>
                    Add a file and control who can access it.
                </span>

            </div>

            <button
                type="button"
                class="mydata-modal-close"
                onclick="closeDataModal()"
            >
                &times;
            </button>

        </div>


        <form
            method="POST"
            action="mydata.php"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h($csrf_token) ?>"
            >

            <input
                type="hidden"
                name="form_action"
                value="save_data"
            >

            <input
                type="hidden"
                name="data_id"
                value="<?= (int) ($edit_data['id'] ?? 0) ?>"
            >


            <div class="mydata-modal-body">


                <!-- NAME -->

                <div class="mydata-field">

                    <label>
                        Name / Title
                        <span>*</span>
                    </label>

                    <input
                        type="text"
                        name="title"
                        required
                        value="<?= h(
                            $edit_data['title'] ?? ''
                        ) ?>"
                        placeholder="Example: Production Network Diagram"
                    >

                </div>


                <!-- SHORT DESCRIPTION -->

                <div class="mydata-field">

                    <label>
                        Short Description
                    </label>

                    <textarea
                        name="short_description"
                        rows="3"
                        placeholder="Briefly describe this data..."
                    ><?= h(
                        $edit_data['short_description'] ?? ''
                    ) ?></textarea>

                </div>


                <!-- ADDITIONAL DETAILS -->

                <div class="mydata-field">

                    <label>
                        Additional Details
                    </label>

                    <textarea
                        name="additional_details"
                        rows="6"
                        placeholder="Add any additional information, instructions or context..."
                    ><?= h(
                        $edit_data['additional_details'] ?? ''
                    ) ?></textarea>

                </div>


                <!-- SHARING -->

                <div class="mydata-sharing-box">

                    <div class="mydata-section-label">
                        Sharing
                    </div>


                    <div class="mydata-visibility-grid">


                        <label class="visibility-option">

                            <input
                                type="radio"
                                name="visibility"
                                value="Private"
                                <?= ($edit_data['visibility'] ?? 'Private') === 'Private'
                                    ? 'checked'
                                    : '' ?>
                                onchange="updateSharingFields()"
                            >

                            <span>

                                <strong>Private</strong>

                                <small>
                                    Only you can access it.
                                </small>

                            </span>

                        </label>


                        <label class="visibility-option">

                            <input
                                type="radio"
                                name="visibility"
                                value="Public"
                                <?= ($edit_data['visibility'] ?? '') === 'Public'
                                    ? 'checked'
                                    : '' ?>
                                onchange="updateSharingFields()"
                            >

                            <span>

                                <strong>Public</strong>

                                <small>
                                    Available to all approved users.
                                </small>

                            </span>

                        </label>


                        <label class="visibility-option">

                            <input
                                type="radio"
                                name="visibility"
                                value="Team"
                                <?= ($edit_data['visibility'] ?? '') === 'Team'
                                    ? 'checked'
                                    : '' ?>
                                onchange="updateSharingFields()"
                            >

                            <span>

                                <strong>Team</strong>

                                <small>
                                    Share with an entire team.
                                </small>

                            </span>

                        </label>


                        <label class="visibility-option">

                            <input
                                type="radio"
                                name="visibility"
                                value="Person"
                                <?= ($edit_data['visibility'] ?? '') === 'Person'
                                    ? 'checked'
                                    : '' ?>
                                onchange="updateSharingFields()"
                            >

                            <span>

                                <strong>Specific Person</strong>

                                <small>
                                    Share with one portal user.
                                </small>

                            </span>

                        </label>

                    </div>


                    <!-- TEAM -->

                    <div
                        id="teamField"
                        class="mydata-field sharing-dependent"
                    >

                        <label>
                            Team
                        </label>

                        <select name="team_name">

                            <option value="">
                                Select Team
                            </option>

                            <?php foreach ($teams as $team): ?>

                                <option
                                    value="<?= h($team) ?>"
                                    <?= ($edit_data['team_name'] ?? '') === $team
                                        ? 'selected'
                                        : '' ?>
                                >
                                    <?= h($team) ?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                        <small class="field-help">
                            Teams are loaded directly from the approved
                            users in the portal.
                        </small>

                    </div>


                    <!-- PERSON -->

                    <div
                        id="personField"
                        class="mydata-field sharing-dependent"
                    >

                        <label>
                            Portal User
                        </label>

                        <select name="shared_user_id">

                            <option value="">
                                Select User
                            </option>

                            <?php foreach ($users as $user): ?>

                                <?php
                                $user_name =
                                    trim(
                                        $user['first_name'] . ' ' .
                                        $user['last_name']
                                    );
                                ?>

                                <option
                                    value="<?= (int) $user['id'] ?>"
                                    <?= (int) ($edit_data['shared_user_id'] ?? 0)
                                        === (int) $user['id']
                                        ? 'selected'
                                        : '' ?>
                                >

                                    <?= h($user_name) ?>

                                    -
                                    <?= h($user['team']) ?>

                                    (<?= h($user['email']) ?>)

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                </div>


                <!-- FILE -->

                <div class="mydata-field">

                    <label>
                        File
                    </label>

                    <?php if (
                        $edit_data &&
                        !empty($edit_data['file_original_name'])
                    ): ?>

                        <div class="existing-file">

                            <span>📎</span>

                            <div>

                                <strong>
                                    <?= h(
                                        $edit_data['file_original_name']
                                    ) ?>
                                </strong>

                                <small>
                                    <?= h(
                                        number_format(
                                            $edit_data['file_size'] / 1024,
                                            1
                                        )
                                    ) ?>
                                    KB
                                </small>

                            </div>

                        </div>

                    <?php endif; ?>


                    <input
                        type="file"
                        name="data_file"
                        class="mydata-file-input"
                    >

                    <small class="field-help">
                        Maximum file size: 100 MB.
                    </small>

                </div>

            </div>


            <!-- FOOTER -->

            <div class="mydata-modal-footer">

                <button
                    type="button"
                    class="mydata-secondary-btn"
                    onclick="closeDataModal()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="mydata-primary-btn"
                >
                    <?= $edit_data
                        ? 'Save Changes'
                        : 'Share Data' ?>
                </button>

            </div>

        </form>

    </div>

</div>


<!-- ============================================================
     VIEW MODAL
============================================================ -->

<?php if ($view_data): ?>

<div
    id="viewDataModal"
    class="mydata-modal"
    style="display:flex;"
>

    <div
        class="mydata-modal-backdrop"
        onclick="closeViewModal()"
    ></div>

    <div class="mydata-modal-dialog view-dialog">

        <div class="mydata-modal-header">

            <div>

                <div class="mydata-view-label">
                    DATA
                </div>

                <h2>
                    <?= h($view_data['title']) ?>
                </h2>

            </div>

            <button
                type="button"
                class="mydata-modal-close"
                onclick="closeViewModal()"
            >
                &times;
            </button>

        </div>


        <div class="mydata-modal-body">


            <!-- DESCRIPTION -->

            <div class="mydata-view-section">

                <span>
                    SHORT DESCRIPTION
                </span>

                <p>
                    <?= nl2br(
                        h(
                            $view_data['short_description']
                        )
                    ) ?>
                </p>

            </div>


            <!-- DETAILS -->

            <div class="mydata-view-section">

                <span>
                    ADDITIONAL DETAILS
                </span>

                <p>
                    <?= nl2br(
                        h(
                            $view_data['additional_details']
                        )
                    ) ?: '<em>No additional details.</em>' ?>
                </p>

            </div>


            <!-- OWNER -->

            <div class="mydata-detail-grid">

                <div>

                    <span>OWNER</span>

                    <strong>
                        <?= h(
                            trim(
                                $view_data['owner_first'] .
                                ' ' .
                                $view_data['owner_last']
                            )
                        ) ?>
                    </strong>

                </div>


                <div>

                    <span>TEAM</span>

                    <strong>
                        <?= h(
                            $view_data['owner_team']
                        ) ?>
                    </strong>

                </div>


                <div>

                    <span>SHARING</span>

                    <strong>
                        <?= h(
                            $view_data['visibility']
                        ) ?>
                    </strong>

                </div>


                <div>

                    <span>UPDATED</span>

                    <strong>
                        <?= h(
                            date(
                                'd M Y H:i',
                                strtotime(
                                    $view_data['updated_at']
                                )
                            )
                        ) ?>
                    </strong>

                </div>

            </div>


            <!-- SHARING DETAILS -->

            <?php if (
                $view_data['visibility'] === 'Team'
            ): ?>

                <div class="mydata-sharing-summary">

                    <strong>
                        Shared with team:
                    </strong>

                    <?= h(
                        $view_data['team_name']
                    ) ?>

                </div>

            <?php elseif (
                $view_data['visibility'] === 'Person'
            ): ?>

                <div class="mydata-sharing-summary">

                    <strong>
                        Shared with:
                    </strong>

                    <?= h(
                        trim(
                            $view_data['shared_first'] .
                            ' ' .
                            $view_data['shared_last']
                        )
                    ) ?>

                </div>

            <?php endif; ?>


            <!-- FILE -->

            <?php if (
                !empty(
                    $view_data['file_original_name']
                )
            ): ?>

                <div class="mydata-file-card">

                    <div class="file-icon">
                        📎
                    </div>

                    <div class="file-info">

                        <strong>
                            <?= h(
                                $view_data[
                                    'file_original_name'
                                ]
                            ) ?>
                        </strong>

                        <small>

                            <?= h(
                                number_format(
                                    $view_data['file_size'] / 1024,
                                    1
                                )
                            ) ?>

                            KB

                        </small>

                    </div>


                    <a
                        href="mydata.php?download=<?= (int) $view_data['id'] ?>"
                        class="mydata-primary-btn"
                    >
                        Download
                    </a>

                </div>

            <?php else: ?>

                <div class="mydata-no-file">
                    No file attached to this record.
                </div>

            <?php endif; ?>

        </div>


        <div class="mydata-modal-footer">

            <?php if (
                can_edit_data(
                    $view_data,
                    $current_user_id,
                    $is_admin
                )
            ): ?>

                <a
                    href="mydata.php?edit=<?= (int) $view_data['id'] ?>"
                    class="mydata-secondary-btn"
                >
                    Edit
                </a>

            <?php endif; ?>


            <button
                type="button"
                class="mydata-secondary-btn"
                onclick="closeViewModal()"
            >
                Close
            </button>

        </div>

    </div>

</div>

<?php endif; ?>


<script>

/*
|--------------------------------------------------------------------------
| CREATE / EDIT MODAL
|--------------------------------------------------------------------------
*/

function openDataModal() {

    const modal =
        document.getElementById('dataModal');

    if (modal) {
        modal.style.display = 'flex';
    }

    updateSharingFields();
}


function closeDataModal() {

    const modal =
        document.getElementById('dataModal');

    if (modal) {
        modal.style.display = 'none';
    }
}


/*
|--------------------------------------------------------------------------
| VIEW MODAL
|--------------------------------------------------------------------------
*/

function closeViewModal() {

    window.location.href =
        'mydata.php';

}


/*
|--------------------------------------------------------------------------
| Sharing fields
|--------------------------------------------------------------------------
*/

function updateSharingFields() {

    const selected =
        document.querySelector(
            'input[name="visibility"]:checked'
        );

    const teamField =
        document.getElementById('teamField');

    const personField =
        document.getElementById('personField');

    if (!selected) {
        return;
    }

    if (teamField) {

        teamField.style.display =
            selected.value === 'Team'
                ? 'block'
                : 'none';

    }

    if (personField) {

        personField.style.display =
            selected.value === 'Person'
                ? 'block'
                : 'none';

    }
}


/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

const dataSearch =
    document.getElementById('myDataSearch');

if (dataSearch) {

    dataSearch.addEventListener(
        'input',
        function () {

            const value =
                this.value.toLowerCase();

            document
                .querySelectorAll(
                    '.mydata-table tbody tr'
                )
                .forEach(function (row) {

                    row.style.display =
                        row.innerText
                            .toLowerCase()
                            .includes(value)
                            ? ''
                            : 'none';

                });

        }
    );

}


/*
|--------------------------------------------------------------------------
| Initial state
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'DOMContentLoaded',
    function () {

        updateSharingFields();

    }
);


/*
|--------------------------------------------------------------------------
| Escape key
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Escape') {

            closeDataModal();

            <?php if ($view_data): ?>
            closeViewModal();
            <?php endif; ?>

        }

    }
);

</script>


<?php

require_once 'includes/footer.php';

?>

