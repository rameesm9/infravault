<?php
// sop-export.php
//
// Exports a single SOP as a Word-compatible document. Word (and most
// office suites) will happily open an .doc file that is really HTML,
// which avoids needing a PHPWord/COM dependency on the server.

session_start();
require_once 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Rewrite relative attachment/image URLs to absolute ones so Word can
| actually fetch them when it renders the exported document.
|--------------------------------------------------------------------------
*/
function sop_export_absolute_urls(string $html, string $base_url): string
{
    return preg_replace_callback(
        '/\ssrc\s*=\s*(["\'])(?!https?:\/\/|data:)([^"\']*)\1/i',
        function ($match) use ($base_url) {
            $quote = $match[1];
            $path = ltrim($match[2], '/');
            return ' src=' . $quote . $base_url . $path . $quote;
        },
        $html
    );
}

$sop_id = (int) ($_GET['id'] ?? 0);

if ($sop_id <= 0) {
    http_response_code(400);
    exit('Invalid SOP.');
}

$stmt = $pdo->prepare("
    SELECT
        s.*,
        owner.first_name  AS owner_first,
        owner.last_name   AS owner_last,
        assigned.first_name AS assigned_first,
        assigned.last_name  AS assigned_last,
        reviewer.first_name AS reviewer_first,
        reviewer.last_name  AS reviewer_last
    FROM sops s
    LEFT JOIN users owner    ON owner.id = s.owner_id
    LEFT JOIN users assigned ON assigned.id = s.reviewer_id
    LEFT JOIN users reviewer ON reviewer.id = s.reviewer_id
    WHERE s.id = ?
    LIMIT 1
");
$stmt->execute([$sop_id]);
$sop = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$sop) {
    http_response_code(404);
    exit('SOP not found.');
}

$owner_name = trim($sop['owner_first'] . ' ' . $sop['owner_last']);
$assigned_reviewer_name = trim(($sop['assigned_first'] ?? '') . ' ' . ($sop['assigned_last'] ?? ''));
$actual_reviewer_name = trim(($sop['reviewer_first'] ?? '') . ' ' . ($sop['reviewer_last'] ?? ''));

$base_url = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/')
    . '/';

$filename = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $sop['sop_number'] . '_' . $sop['title']);
$filename = trim($filename, '_') . '.doc';

header('Content-Type: application/msword; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title><?= h($sop['title']) ?></title>
<!--[if gte mso 9]>
<xml>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>100</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
    body { font-family: Calibri, Arial, sans-serif; font-size: 11pt; color: #1E293B; }
    h1 { font-size: 20pt; color: #111827; margin-bottom: 4pt; }
    h2 { font-size: 14pt; color: #111827; border-bottom: 1pt solid #E5E7EB; padding-bottom: 4pt; margin-top: 22pt; }
    .meta-table { width: 100%; border-collapse: collapse; margin: 14pt 0 20pt; }
    .meta-table td { border: 1pt solid #E5E7EB; padding: 6pt 10pt; font-size: 10pt; vertical-align: top; }
    .meta-label { background: #F8FAFC; font-weight: bold; width: 130pt; color: #64748B; }
    .sop-command { background: #0F172A; color: #E2E8F0; padding: 8pt; font-family: Consolas, monospace; }
    table { border-collapse: collapse; }
    table td, table th { border: 1pt solid #E5E7EB; padding: 4pt 8pt; }
</style>
</head>
<body>

<h1><?= h($sop['sop_number']) ?> &mdash; <?= h($sop['title']) ?></h1>
<p><?= h($sop['description']) ?></p>

<table class="meta-table">
    <tr>
        <td class="meta-label">Status</td><td><?= h($sop['status']) ?></td>
        <td class="meta-label">Version</td><td><?= h($sop['version']) ?></td>
    </tr>
    <tr>
        <td class="meta-label">Category</td><td><?= h($sop['category']) ?></td>
        <td class="meta-label">Criticality</td><td><?= h($sop['criticality']) ?></td>
    </tr>
    <tr>
        <td class="meta-label">Creator</td><td><?= h($owner_name ?: '—') ?></td>
        <td class="meta-label">Assigned Reviewer</td><td><?= h($assigned_reviewer_name ?: '—') ?></td>
    </tr>
    <?php if (!empty($sop['reviewed_at'])): ?>
    <tr>
        <td class="meta-label">Reviewed By</td><td><?= h($actual_reviewer_name ?: '—') ?></td>
        <td class="meta-label">Reviewed On</td><td><?= h(date('d M Y H:i', strtotime($sop['reviewed_at']))) ?></td>
    </tr>
    <?php endif; ?>
    <tr>
        <td class="meta-label">Last Updated</td>
        <td colspan="3"><?= h(date('d M Y H:i', strtotime($sop['updated_at']))) ?></td>
    </tr>
</table>

<?php if (trim((string) $sop['prerequisites_html']) !== ''): ?>
<h2>Prerequisites</h2>
<?= sop_export_absolute_urls($sop['prerequisites_html'], $base_url) ?>
<?php endif; ?>

<h2>Procedure</h2>
<?= $sop['content_html'] !== '' ? sop_export_absolute_urls($sop['content_html'], $base_url) : '<p>No procedure provided.</p>' ?>

<?php if (trim((string) $sop['validation_html']) !== ''): ?>
<h2>Validation</h2>
<?= sop_export_absolute_urls($sop['validation_html'], $base_url) ?>
<?php endif; ?>

<?php if (trim((string) $sop['rollback_html']) !== ''): ?>
<h2>Rollback</h2>
<?= sop_export_absolute_urls($sop['rollback_html'], $base_url) ?>
<?php endif; ?>

<?php if (trim((string) $sop['escalation_html']) !== ''): ?>
<h2>Escalation</h2>
<?= sop_export_absolute_urls($sop['escalation_html'], $base_url) ?>
<?php endif; ?>

<?php if (!empty($sop['rejection_reason'])): ?>
<h2>Review Feedback</h2>
<p><?= nl2br(h($sop['rejection_reason'])) ?></p>
<?php endif; ?>

</body>
</html>
