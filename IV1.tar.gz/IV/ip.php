<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}


$page_title="IP Address Management";


include "includes/header.php";
include "includes/sidebar.php";



$role=strtolower($_SESSION['role'] ?? "read-only");


$canManage=in_array($role,[
    "admin",
    "administrator",
    "edit",
    "editor"
]);


$canDelete=($role=="admin");



/*
=====================================================
SEARCH
=====================================================
*/


$keyword=trim($_GET['keyword'] ?? "");


$sql="
SELECT *
FROM ip_ranges
WHERE 1=1
";


$params=[];



if($keyword!=""){


$sql.="

AND
(
ip_range LIKE ?
OR vlan LIKE ?
OR project LIKE ?
OR gateway LIKE ?
OR environment LIKE ?
)

";


$search="%".$keyword."%";


$params[]=$search;
$params[]=$search;
$params[]=$search;
$params[]=$search;
$params[]=$search;


}



$sql.=" ORDER BY id DESC";



$stmt=$pdo->prepare($sql);

$stmt->execute($params);


$rows=$stmt->fetchAll(PDO::FETCH_ASSOC);





/*
=====================================================
STATISTICS
=====================================================
*/


$totalNetworks=count($rows);


$production=0;
$preprod=0;
$uat=0;
$dmz=0;
$totalHosts=0;



foreach($rows as $r){


$env=strtolower($r['environment'] ?? "");



if($env=="production"){
    $production++;
}


if($env=="preprod" || $env=="pre-prod"){
    $preprod++;
}


if($env=="uat"){
    $uat++;
}


if($env=="dmz"){
    $dmz++;
}



$totalHosts+=intval(
$r['usable_hosts'] ?? 0
);


}



?>


<link rel="stylesheet" href="assets/css/ip.css">


<div class="content">


<div class="ip-container">



<div class="ip-header">


<div>

<h1>
IP Address Management
</h1>


<p>
Enterprise Network Address Management
</p>


</div>



<div class="ip-header-actions">


<?php if($canManage): ?>


<button
class="btn-primary"
onclick="newIP()">


<i class="fa-solid fa-plus"></i>

Add IP Range


</button>



<button
class="btn-secondary"
onclick="openImportModal()">


<i class="fa-solid fa-file-import"></i>

Import CSV


</button>



<?php endif; ?>



<a href="ip-export.php"
class="btn-secondary">


<i class="fa-solid fa-file-export"></i>

Export


</a>



<a href="ip-history.php"
class="btn-secondary">


<i class="fa-solid fa-clock"></i>

History


</a>



</div>


</div>





<div class="stats-grid">


<div class="stat-card">

<span>
Total Networks
</span>

<strong>
<?=$totalNetworks?>
</strong>

</div>



<div class="stat-card green">

<span>
Production
</span>

<strong>
<?=$production?>
</strong>

</div>




<div class="stat-card blue">

<span>
PreProd
</span>

<strong>
<?=$preprod?>
</strong>

</div>




<div class="stat-card purple">

<span>
UAT
</span>

<strong>
<?=$uat?>
</strong>

</div>



<div class="stat-card red">

<span>
DMZ
</span>

<strong>
<?=$dmz?>
</strong>

</div>




<div class="stat-card">

<span>
Usable Hosts
</span>

<strong>
<?=number_format($totalHosts)?>
</strong>

</div>



</div>





<div class="ip-toolbar">



<form method="GET"
class="search-box">



<div class="search-input">


<i class="fa-solid fa-magnifying-glass"></i>



<input

type="text"

name="keyword"

placeholder="Search IP Range, VLAN, Project, Gateway..."

value="<?=htmlspecialchars($keyword)?>"

>



<?php if($keyword!=""): ?>


<a href="ip.php"
class="clear-search">

<i class="fa-solid fa-xmark"></i>

</a>


<?php endif; ?>



</div>



<button class="btn-primary">

Search

</button>



</form>




<a href="ip.php"
class="btn-secondary">

Reset

</a>



<button
class="btn-secondary"
onclick="openColumnSettings()">


<i class="fa-solid fa-table-columns"></i>

Columns


</button>



</div>





<div class="table-card">


<table class="ip-table">



<thead>


<tr>


<th data-col="ip_range">
IP Range
</th>


<th data-col="cidr">
CIDR
</th>


<th data-col="subnet">
Subnet
</th>


<th data-col="vlan">
VLAN
</th>


<th data-col="environment">
Environment
</th>


<th data-col="project">
Project
</th>


<th data-col="gateway">
Gateway
</th>


<th data-col="usable_hosts">
Hosts
</th>


<th>
Created By
</th>


<th>
Actions
</th>


</tr>


</thead>



<tbody>

<?php if(count($rows)>0): ?>


<?php foreach($rows as $row): ?>


<tr>


<td data-field="ip_range">

<span class="ip-badge">

<?=htmlspecialchars($row['ip_range'])?>

</span>

</td>



<td data-field="cidr">

<?=htmlspecialchars($row['cidr'] ?? "-")?>

</td>



<td data-field="subnet">

<?=htmlspecialchars($row['subnet'] ?? "-")?>

</td>



<td data-field="vlan">

<?=htmlspecialchars($row['vlan'] ?? "-")?>

</td>



<td data-field="environment">

<span class="environment">

<?=htmlspecialchars($row['environment'] ?? "-")?>

</span>

</td>



<td data-field="project">

<?=htmlspecialchars($row['project'] ?? "-")?>

</td>



<td data-field="gateway">

<?=htmlspecialchars($row['gateway'] ?? "-")?>

</td>



<td data-field="usable_hosts">

<?=htmlspecialchars($row['usable_hosts'] ?? "0")?>

</td>



<td>

<?=htmlspecialchars($row['created_by'] ?? "-")?>

</td>



<td>


<div class="action-wrapper">


<button
class="action-button"
onclick="toggleMenu(this)">

<i class="fa-solid fa-ellipsis"></i>

</button>




<div class="action-menu">


<button
onclick='viewIP(<?=json_encode($row)?>)'>

<i class="fa-solid fa-eye"></i>

View

</button>




<?php if($canManage): ?>


<button
onclick='editIP(<?=json_encode($row)?>)'>

<i class="fa-solid fa-pen"></i>

Edit

</button>


<?php endif; ?>





<?php if($canDelete): ?>


<form method="POST"
action="ip-delete.php">


<input type="hidden"
name="id"
value="<?=$row['id']?>">


<button
onclick="return confirm('Delete this IP range?')">

<i class="fa-solid fa-trash"></i>

Delete

</button>


</form>


<?php endif; ?>


</div>


</div>


</td>


</tr>



<?php endforeach; ?>



<?php else: ?>


<tr>

<td colspan="10"
class="empty">

No IP ranges found

</td>

</tr>


<?php endif; ?>


</tbody>


</table>


</div>







<!-- ============================
ADD / EDIT DRAWER
============================ -->


<div id="ipDrawer"
class="drawer">


<div class="drawer-header">


<h2 id="drawerTitle">

Add IP Range

</h2>



<button onclick="closeIPDrawer()">

×

</button>


</div>





<form method="POST"
action="ip-save.php"
id="ipSaveForm">


<input type="hidden"
name="id"
id="id">





<div class="drawer-body">



<div class="section">


<h3>
Network Details
</h3>



<div class="form-grid">



<div>

<label>
IP Range / CIDR
</label>


<input

id="ip_range"

name="ip_range"

placeholder="10.10.10.0/24"

required

>


</div>




<div>

<label>
CIDR
</label>


<input

id="cidr"

name="cidr"

readonly

>


</div>




<div>

<label>
Subnet Mask
</label>


<input

id="subnet"

name="subnet"

readonly

>


</div>




<div>

<label>
Gateway
</label>


<input

id="gateway"

name="gateway"

>

</div>



</div>


</div>







<div class="section">


<h3>
Calculated Network Information
</h3>



<div class="form-grid">



<div>

<label>
Network Address
</label>


<input

id="network"

name="network"

readonly

>


</div>




<div>

<label>
Broadcast
</label>


<input

id="broadcast"

name="broadcast"

readonly

>


</div>





<div>

<label>
Usable Range
</label>


<input

id="usable_range"

name="usable_range"

readonly

>


</div>





<div>

<label>
Total Hosts
</label>


<input

id="total_hosts"

name="total_hosts"

readonly

>


</div>





<div>

<label>
Usable Hosts
</label>


<input

id="usable_hosts"

name="usable_hosts"

readonly

>


</div>



</div>


</div>






<div class="section">


<h3>
Classification
</h3>



<div class="form-grid">



<div>

<label>
VLAN
</label>


<input

id="vlan"

name="vlan"

>

</div>




<div>

<label>
Port Group
</label>


<input

id="portgroup"

name="portgroup"

>

</div>





<div>

<label>
Environment
</label>


<select

id="environment"

name="environment">


<option value="">
Select Environment
</option>


<option>Production</option>

<option>PreProd</option>

<option>UAT</option>

<option>Development</option>

<option>Test</option>

<option>Sandbox</option>

<option>POC</option>

<option>DMZ</option>


</select>


</div>




<div>

<label>
Project
</label>


<input

id="project"

name="project"

>


</div>



</div>


</div>







<div class="section">


<label>
Comments
</label>


<textarea

id="comments"

name="comments"

rows="4">

</textarea>


</div>



</div>








<div class="drawer-footer">



<button

type="button"

class="btn-secondary"

onclick="closeIPDrawer()">

Cancel

</button>




<button

type="submit"

class="btn-primary">

<i class="fa-solid fa-save"></i>

Save IP Range

</button>



</div>



</form>


</div>





<!-- =============================
COLUMN CUSTOMIZATION
============================= -->


<div id="columnPanel"
class="side-panel">



<div class="panel-header">


<h3>
Customize Columns
</h3>



<button onclick="closeColumnSettings()">

×

</button>


</div>




<div class="column-options">


<label>

<input

type="checkbox"

checked

data-field="ip_range">

IP Range

</label>



<label>

<input

type="checkbox"

checked

data-field="cidr">

CIDR

</label>



<label>

<input

type="checkbox"

checked

data-field="subnet">

Subnet

</label>



<label>

<input

type="checkbox"

checked

data-field="vlan">

VLAN

</label>



<label>

<input

type="checkbox"

checked

data-field="environment">

Environment

</label>



<label>

<input

type="checkbox"

checked

data-field="project">

Project

</label>



<label>

<input

type="checkbox"

checked

data-field="gateway">

Gateway

</label>



<label>

<input

type="checkbox"

checked

data-field="usable_hosts">

Hosts

</label>


</div>





<button

class="btn-primary"

onclick="saveColumns()">

<i class="fa-solid fa-check"></i>

Apply Layout

</button>



</div>

<!-- =============================
CSV IMPORT
============================= -->


<div id="importModal"
class="overlay">


<div class="modal">


<div class="modal-header">

<h2>
Import IP CSV
</h2>


<button onclick="closeImportModal()">

×

</button>


</div>



<form

action="ip-import.php"

method="POST"

enctype="multipart/form-data">


<input

type="file"

name="csv_file"

accept=".csv"

required>


<p>

CSV Format:

</p>


<code>

ip_range,vlan,gateway,environment,project,portgroup,comments

</code>



<br><br>


<button

class="btn-primary">

<i class="fa-solid fa-upload"></i>

Upload

</button>



<button

type="button"

class="btn-secondary"

onclick="closeImportModal()">

Cancel

</button>


</form>


</div>

</div>





<!-- =============================
HISTORY MODAL
============================= -->


<div id="historyModal"
class="overlay">


<div class="modal">


<div class="modal-header">


<h2>
Change History
</h2>



<button onclick="closeHistory()">

×

</button>


</div>



<div id="historyContent">

Loading...

</div>


</div>


</div>






</div>



<script src="assets/js/ip.js"></script>


<script>


/* ============================
ACTION MENU
============================ */


function toggleMenu(btn){


document
.querySelectorAll(".action-menu")
.forEach(function(menu){


menu.classList.remove("show");


});


btn.nextElementSibling.classList.toggle("show");


}





/* ============================
DRAWER
============================ */


function openIPDrawer(){


document
.getElementById("ipDrawer")
.classList.add("show");


}



function closeIPDrawer(){


document
.getElementById("ipDrawer")
.classList.remove("show");


}




function newIP(){


openIPDrawer();



document
.getElementById("ipSaveForm")
.reset();



document
.getElementById("id")
.value="";



document
.getElementById("drawerTitle")
.innerHTML="Add IP Range";


}





function editIP(data){


openIPDrawer();



document
.getElementById("drawerTitle")
.innerHTML="Edit IP Range";



Object.keys(data).forEach(function(key){


let field=document.getElementById(key);



if(field){


field.value=data[key] ?? "";


}



});



}







/* ============================
VIEW
============================ */


function viewIP(data){


let html="";


Object.keys(data).forEach(function(k){


html+=`

<div class="detail-item">

<label>
${k.replaceAll("_"," ")}
</label>


<strong>

${data[k] ?? "-"}

</strong>


</div>

`;


});




let modal=document.createElement("div");


modal.className="overlay";


modal.style.display="flex";



modal.innerHTML=`

<div class="modal">


<div class="modal-header">


<h2>
IP Details
</h2>


<button onclick="this.closest('.overlay').remove()">

×

</button>


</div>


<div class="details-grid">

${html}

</div>


</div>

`;



document.body.appendChild(modal);


}






/* ============================
IMPORT
============================ */


function openImportModal(){


document
.getElementById("importModal")
.style.display="flex";


}



function closeImportModal(){


document
.getElementById("importModal")
.style.display="none";


}






/* ============================
HISTORY
============================ */


function openHistory(id){


document
.getElementById("historyModal")
.style.display="flex";



fetch(
"ip-history.php?id="+id
)


.then(r=>r.text())


.then(data=>{


document
.getElementById("historyContent")
.innerHTML=data;


});


}



function closeHistory(){


document
.getElementById("historyModal")
.style.display="none";


}







/* ============================
COLUMN SETTINGS
============================ */


function openColumnSettings(){


document
.getElementById("columnPanel")
.classList.add("show");


}




function closeColumnSettings(){


document
.getElementById("columnPanel")
.classList.remove("show");


}







function saveColumns(){



document
.querySelectorAll(".column-options input")
.forEach(function(cb){



let field =
cb.dataset.field;



let visible =
cb.checked;



document
.querySelectorAll(
"th[data-col='"+field+"'],td[data-field='"+field+"']"
)

.forEach(function(el){


el.style.display =
visible ? "" : "none";


});



localStorage.setItem(

"ip_column_"+field,

visible

);



});



closeColumnSettings();


}





function loadColumns(){


document
.querySelectorAll(".column-options input")
.forEach(function(cb){



let field =
cb.dataset.field;



let saved =
localStorage.getItem(
"ip_column_"+field
);



if(saved!==null){



cb.checked =
(saved==="true");



document
.querySelectorAll(
"th[data-col='"+field+"'],td[data-field='"+field+"']"
)

.forEach(function(el){


el.style.display =
cb.checked ? "" : "none";


});


}



});


}





window.addEventListener(
"load",
loadColumns
);



</script>




<?php include "includes/footer.php"; ?>
