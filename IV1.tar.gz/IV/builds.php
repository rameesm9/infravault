<?php
require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');
$success_msg = '';
$error_msg = '';

// Fetch all portal users for the "Build By" dropdown
$users_stmt = $pdo->query("SELECT id, first_name, last_name FROM users WHERE is_approved = 1 ORDER BY first_name ASC");
$all_portal_users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);

$support_options = ['HCL', 'Ejada', 'STC', 'Alfa', 'MOF', 'NCGR', 'UGRP', 'Others', 'GRC', 'ADT'];

// Handle Form Submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'create_build') {
        $build_no = trim($_POST['build_no'] ?? '');
        $project = trim($_POST['project'] ?? '');
        $status = trim($_POST['status'] ?? '');
        $build_by = trim($_POST['build_by'] ?? '');
        $supported_by = trim($_POST['supported_by'] ?? '');
        $build_from = trim($_POST['build_from'] ?? '');

        if (empty($build_no) || empty($project) || empty($status) || empty($build_by)) {
            $error_msg = "Please fill in all required fields (Build No, Project, Status, Build By).";
        } else {
            $stmt = $pdo->prepare("INSERT INTO builds (build_no, project, status, build_by, supported_by, build_from, user_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$build_no, $project, $status, $build_by, $supported_by, $build_from, $current_user_id]);
            $build_id = $pdo->lastInsertId();

            // Handle File Attachments
            if (!empty($_FILES['attachments']['name'][0])) {
                $upload_dir = 'uploads/builds/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                foreach ($_FILES['attachments']['name'] as $key => $filename) {
                    if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                        $safe_filename = time() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
                        $destination = $upload_dir . $safe_filename;

                        if (move_uploaded_file($tmp_name, $destination)) {
                            $att_stmt = $pdo->prepare("INSERT INTO build_attachments (build_id, filename, filepath) VALUES (?, ?, ?)");
                            $att_stmt->execute([$build_id, $filename, $destination]);
                        }
                    }
                }
            }

            $success_msg = "New build record successfully created with attachments!";
        }
    } elseif ($action === 'update_build') {
        $build_id = $_POST['build_id'] ?? '';

        $check_stmt = $pdo->prepare("SELECT user_id FROM builds WHERE id = ?");
        $check_stmt->execute([$build_id]);
        $build_owner = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$build_owner) {
            $error_msg = "Build record not found.";
        } elseif ($role !== 'Admin' && $build_owner['user_id'] != $current_user_id) {
            $error_msg = "You do not have permission to modify this build.";
        } else {
            $build_no = trim($_POST['build_no'] ?? '');
            $project = trim($_POST['project'] ?? '');
            $status = trim($_POST['status'] ?? '');
            $build_by = trim($_POST['build_by'] ?? '');
            $supported_by = trim($_POST['supported_by'] ?? '');
            $build_from = trim($_POST['build_from'] ?? '');

            $update_stmt = $pdo->prepare("UPDATE builds SET build_no = ?, project = ?, status = ?, build_by = ?, supported_by = ?, build_from = ? WHERE id = ?");
            $update_stmt->execute([$build_no, $project, $status, $build_by, $supported_by, $build_from, $build_id]);

            if (!empty($_FILES['attachments']['name'][0])) {
                $upload_dir = 'uploads/builds/';
                if (!is_dir($upload_dir)) {
                    mkdir($upload_dir, 0755, true);
                }

                foreach ($_FILES['attachments']['name'] as $key => $filename) {
                    if ($_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK) {
                        $tmp_name = $_FILES['attachments']['tmp_name'][$key];
                        $safe_filename = time() . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $filename);
                        $destination = $upload_dir . $safe_filename;

                        if (move_uploaded_file($tmp_name, $destination)) {
                            $att_stmt = $pdo->prepare("INSERT INTO build_attachments (build_id, filename, filepath) VALUES (?, ?, ?)");
                            $att_stmt->execute([$build_id, $filename, $destination]);
                        }
                    }
                }
            }

            $success_msg = "Build record successfully updated!";
        }
    } elseif ($action === 'delete_build') {
        $build_id = $_POST['build_id'] ?? '';

        $check_stmt = $pdo->prepare("SELECT user_id FROM builds WHERE id = ?");
        $check_stmt->execute([$build_id]);
        $build_owner = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$build_owner) {
            $error_msg = "Build record not found.";
        } elseif ($role !== 'Admin' && $build_owner['user_id'] != $current_user_id) {
            $error_msg = "You do not have permission to delete this build.";
        } else {
            $att_query = $pdo->prepare("SELECT filepath FROM build_attachments WHERE build_id = ?");
            $att_query->execute([$build_id]);
            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);
            foreach ($attachments as $att) {
                if (file_exists($att['filepath'])) {
                    unlink($att['filepath']);
                }
            }

            $del_stmt = $pdo->prepare("DELETE FROM builds WHERE id = ?");
            $del_stmt->execute([$build_id]);
            $success_msg = "Build record successfully deleted.";
        }
    }
}

// Fetch all builds for global viewing along with user metadata
$builds_stmt = $pdo->query("
    SELECT b.*, u.first_name AS creator_first, u.last_name AS creator_last,
           bu.first_name AS builder_first, bu.last_name AS builder_last
    FROM builds b
    LEFT JOIN users u ON b.user_id = u.id
    LEFT JOIN users bu ON b.build_by = bu.id
    ORDER BY b.created_at DESC
");
$builds = $builds_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "New Build Management - InfraVault";
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>
    /* =========================================
       BUILDS MANAGEMENT - PAGE STYLES
       (extends existing dashboard-card / dashboard-panel look)
    ========================================= */

    .bd-alert {
        padding: 13px 18px;
        border-radius: 10px;
        font-size: 14px;
        font-weight: 500;
        margin-bottom: 20px;
        border: 1px solid transparent;
    }

    .bd-alert.success {
        background: #ECFDF5;
        border-color: #A7F3D0;
        color: #047857;
    }

    .bd-alert.error {
        background: #FEF2F2;
        border-color: #FECACA;
        color: #B91C1C;
    }

    .bd-form-grid {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 18px;
        margin-bottom: 18px;
    }

    .bd-field label {
        display: block;
        font-size: 13px;
        font-weight: 600;
        color: #374151;
        margin-bottom: 7px;
    }

    .bd-field small {
        display: block;
        margin-top: 6px;
        color: #94A3B8;
        font-size: 12px;
    }

    .bd-field input[type="text"],
    .bd-field select,
    .bd-field input[type="file"] {
        width: 100%;
        padding: 10px 12px;
        border: 1px solid #E2E8F0;
        border-radius: 9px;
        font-family: inherit;
        font-size: 14px;
        color: #1E293B;
        background: #F8FAFC;
        transition: .15s;
    }

    .bd-field input:focus,
    .bd-field select:focus {
        outline: none;
        border-color: #2563EB;
        background: #fff;
        box-shadow: 0 0 0 3px rgba(37,99,235,.12);
    }

    .bd-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        border: none;
        border-radius: 9px;
        padding: 11px 20px;
        font-size: 14px;
        font-weight: 600;
        cursor: pointer;
        font-family: inherit;
        transition: .15s;
    }

    .bd-btn-primary {
        background: #2563EB;
        color: #fff;
    }

    .bd-btn-primary:hover {
        background: #1D4ED8;
    }

    .bd-btn-danger {
        background: #FEF2F2;
        color: #DC2626;
    }

    .bd-btn-danger:hover {
        background: #FEE2E2;
    }

    .bd-btn-ghost {
        background: #F1F5F9;
        color: #334155;
    }

    .bd-btn-ghost:hover {
        background: #E2E8F0;
    }

    .bd-btn-sm {
        padding: 7px 12px;
        font-size: 12.5px;
        border-radius: 7px;
    }

    .bd-view-only {
        color: #94A3B8;
        font-size: 12.5px;
        font-style: italic;
    }

    /* Table */
    .bd-table-wrap {
        overflow-x: auto;
    }

    table.bd-table {
        width: 100%;
        border-collapse: collapse;
        font-size: 13.5px;
    }

    table.bd-table thead th {
        text-align: left;
        padding: 13px 16px;
        background: #F8FAFC;
        color: #64748B;
        font-weight: 600;
        font-size: 12.5px;
        text-transform: uppercase;
        letter-spacing: .03em;
        border-bottom: 1px solid #E5E7EB;
        white-space: nowrap;
    }

    table.bd-table tbody td {
        padding: 14px 16px;
        border-bottom: 1px solid #F1F5F9;
        color: #334155;
        vertical-align: middle;
    }

    table.bd-table tbody tr:last-child td {
        border-bottom: none;
    }

    table.bd-table tbody tr:hover {
        background: #FAFBFF;
    }

    .bd-empty {
        text-align: center;
        padding: 40px 20px;
        color: #94A3B8;
        font-size: 14px;
    }

    .bd-badge {
        display: inline-block;
        padding: 4px 11px;
        border-radius: 20px;
        font-size: 11.5px;
        font-weight: 700;
        white-space: nowrap;
    }

    .bd-badge.st-inprogress { background: #EEF2FF; color: #4338CA; }
    .bd-badge.st-completed { background: #ECFDF5; color: #047857; }
    .bd-badge.st-onhold { background: #FFF7ED; color: #C2410C; }
    .bd-badge.st-cancelled { background: #FEF2F2; color: #B91C1C; }

    /* File chip */
    .bd-file-chip {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        background: #F1F5F9;
        padding: 7px 13px;
        border-radius: 8px;
        font-size: 13px;
        margin: 0 8px 8px 0;
        text-decoration: none;
        color: #2563EB;
        font-weight: 500;
        transition: .15s;
    }

    .bd-file-chip:hover {
        background: #E2E8F0;
    }

    /* Modal */
    .bd-modal {
        display: none;
        position: fixed;
        inset: 0;
        z-index: 3000;
        background: rgba(15, 23, 42, .5);
        overflow-y: auto;
        padding: 40px 20px;
    }

    .bd-modal-content {
        background: #fff;
        margin: 0 auto;
        max-width: 640px;
        width: 100%;
        border-radius: 18px;
        padding: 28px 30px;
        box-shadow: 0 20px 60px rgba(15,23,42,.25);
        position: relative;
    }

    .bd-modal-close {
        position: absolute;
        top: 20px;
        right: 24px;
        font-size: 22px;
        color: #94A3B8;
        cursor: pointer;
        line-height: 1;
        background: none;
        border: none;
    }

    .bd-modal-close:hover {
        color: #1E293B;
    }

    .bd-modal-title {
        font-size: 19px;
        font-weight: 700;
        color: #111827;
        margin-bottom: 20px;
        padding-right: 30px;
    }

    @media (max-width: 900px) {
        .bd-form-grid {
            grid-template-columns: 1fr;
        }
    }
</style>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Builds Management</h1>
            <p>Register and track infrastructure builds, ownership, and supporting documentation.</p>
        </div>
    </div>

    <?php if ($success_msg): ?>
        <div class="bd-alert success"><?= htmlspecialchars($success_msg) ?></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
        <div class="bd-alert error"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>

    <!-- Register New Build -->
    <div class="dashboard-panel" style="margin-bottom:22px;">
        <div class="panel-header">
            <h3>Register New Infrastructure Build</h3>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="create_build">

            <div class="bd-form-grid">
                <div class="bd-field">
                    <label>Build No *</label>
                    <input type="text" name="build_no" placeholder="e.g., BLD-2026-001" required>
                </div>
                <div class="bd-field">
                    <label>Project *</label>
                    <input type="text" name="project" placeholder="Project Name" required>
                </div>
                <div class="bd-field">
                    <label>Status *</label>
                    <select name="status" required>
                        <option value="In Progress">In Progress</option>
                        <option value="Completed">Completed</option>
                        <option value="On Hold">On Hold</option>
                        <option value="Cancelled">Cancelled</option>
                    </select>
                </div>
            </div>

            <div class="bd-form-grid">
                <div class="bd-field">
                    <label>Build By *</label>
                    <select name="build_by" required>
                        <option value="">-- Select Portal User --</option>
                        <?php foreach ($all_portal_users as $usr): ?>
                            <option value="<?= $usr['id'] ?>"><?= htmlspecialchars($usr['first_name'] . ' ' . $usr['last_name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="bd-field">
                    <label>Supported By</label>
                    <select name="supported_by">
                        <option value="">-- Select Support Team --</option>
                        <?php foreach ($support_options as $opt): ?>
                            <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="bd-field">
                    <label>From</label>
                    <select name="build_from">
                        <option value="">-- Select Source/Stage --</option>
                        <option value="provisioning team">Provisioning Team</option>
                        <option value="others">Others</option>
                        <option value="handedover">Handedover</option>
                    </select>
                </div>
            </div>

            <div class="bd-field" style="margin-bottom:20px;">
                <label>Attachments</label>
                <input type="file" name="attachments[]" multiple>
                <small>You can select multiple files.</small>
            </div>

            <button type="submit" class="bd-btn bd-btn-primary">Create Build Record</button>
        </form>
    </div>

    <!-- Existing Builds -->
    <div class="dashboard-panel" style="padding-bottom:8px;">
        <div class="panel-header">
            <h3>Existing Infrastructure Builds Directory</h3>
            <span><?= count($builds) ?> record<?= count($builds) === 1 ? '' : 's' ?></span>
        </div>

        <div class="bd-table-wrap">
            <table class="bd-table">
                <thead>
                    <tr>
                        <th>Build No</th>
                        <th>Project</th>
                        <th>Status</th>
                        <th>Build By</th>
                        <th>Supported By</th>
                        <th>From</th>
                        <th>Created Date</th>
                        <th>Attachments</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($builds)): ?>
                        <tr><td colspan="9" class="bd-empty">No builds registered yet.</td></tr>
                    <?php else: ?>
                        <?php foreach ($builds as $b):
                            $att_query = $pdo->prepare("SELECT * FROM build_attachments WHERE build_id = ?");
                            $att_query->execute([$b['id']]);
                            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);

                            $can_modify = ($role === 'Admin' || $b['user_id'] == $current_user_id);

                            $status_class = 'st-inprogress';
                            switch ($b['status']) {
                                case 'Completed': $status_class = 'st-completed'; break;
                                case 'On Hold': $status_class = 'st-onhold'; break;
                                case 'Cancelled': $status_class = 'st-cancelled'; break;
                            }
                        ?>
                        <tr>
                            <td><strong><?= htmlspecialchars($b['build_no']) ?></strong></td>
                            <td><?= htmlspecialchars($b['project']) ?></td>
                            <td><span class="bd-badge <?= $status_class ?>"><?= htmlspecialchars($b['status']) ?></span></td>
                            <td><?= htmlspecialchars($b['builder_first'] . ' ' . $b['builder_last']) ?></td>
                            <td><?= htmlspecialchars($b['supported_by'] ?: '-') ?></td>
                            <td><?= htmlspecialchars($b['build_from'] ?: '-') ?></td>
                            <td><?= htmlspecialchars($b['created_at']) ?></td>
                            <td>
                                <button type="button" class="bd-btn bd-btn-ghost bd-btn-sm" onclick='openViewModal(<?= json_encode($attachments) ?>, "<?= htmlspecialchars($b['build_no'], ENT_QUOTES) ?>")'>View Docs (<?= count($attachments) ?>)</button>
                            </td>
                            <td style="white-space:nowrap;">
                                <?php if ($can_modify): ?>
                                    <button type="button" class="bd-btn bd-btn-primary bd-btn-sm" onclick='openEditModal(<?= json_encode($b) ?>)'>Edit</button>
                                    <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this build record?');">
                                        <input type="hidden" name="action" value="delete_build">
                                        <input type="hidden" name="build_id" value="<?= $b['id'] ?>">
                                        <button type="submit" class="bd-btn bd-btn-danger bd-btn-sm">Delete</button>
                                    </form>
                                <?php else: ?>
                                    <span class="bd-view-only">View Only</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>

<!-- View Attachments Modal -->
<div id="viewAttachmentsModal" class="bd-modal">
    <div class="bd-modal-content">
        <button class="bd-modal-close" onclick="closeViewModal()">&times;</button>
        <h2 id="viewModalTitle" class="bd-modal-title">Attached Documents</h2>
        <div id="attachmentsListContainer"></div>
    </div>
</div>

<!-- Edit Modal -->
<div id="editModal" class="bd-modal">
    <div class="bd-modal-content">
        <button class="bd-modal-close" onclick="closeEditModal()">&times;</button>
        <h2 class="bd-modal-title">Edit Infrastructure Build</h2>

        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="update_build">
            <input type="hidden" name="build_id" id="edit_build_id">

            <div class="bd-field" style="margin-bottom:16px;">
                <label>Build No *</label>
                <input type="text" name="build_no" id="edit_build_no" required>
            </div>
            <div class="bd-field" style="margin-bottom:16px;">
                <label>Project *</label>
                <input type="text" name="project" id="edit_project" required>
            </div>
            <div class="bd-field" style="margin-bottom:16px;">
                <label>Status *</label>
                <select name="status" id="edit_status" required>
                    <option value="In Progress">In Progress</option>
                    <option value="Completed">Completed</option>
                    <option value="On Hold">On Hold</option>
                    <option value="Cancelled">Cancelled</option>
                </select>
            </div>
            <div class="bd-field" style="margin-bottom:16px;">
                <label>Build By *</label>
                <select name="build_by" id="edit_build_by" required>
                    <option value="">-- Select Portal User --</option>
                    <?php foreach ($all_portal_users as $usr): ?>
                        <option value="<?= $usr['id'] ?>"><?= htmlspecialchars($usr['first_name'] . ' ' . $usr['last_name']) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="bd-field" style="margin-bottom:16px;">
                <label>Supported By</label>
                <select name="supported_by" id="edit_supported_by">
                    <option value="">-- Select Support Team --</option>
                    <?php foreach ($support_options as $opt): ?>
                        <option value="<?= htmlspecialchars($opt) ?>"><?= htmlspecialchars($opt) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="bd-field" style="margin-bottom:16px;">
                <label>From</label>
                <select name="build_from" id="edit_build_from">
                    <option value="">-- Select Source/Stage --</option>
                    <option value="provisioning team">Provisioning Team</option>
                    <option value="others">Others</option>
                    <option value="handedover">Handedover</option>
                </select>
            </div>
            <div class="bd-field" style="margin-bottom:20px;">
                <label>Add More Attachments</label>
                <input type="file" name="attachments[]" multiple>
            </div>

            <button type="submit" class="bd-btn bd-btn-primary">Update Build Record</button>
        </form>
    </div>
</div>

<script>
    function openViewModal(attachments, buildNo) {
        document.getElementById('viewModalTitle').innerText = 'Attached Documents for ' + buildNo;
        let container = document.getElementById('attachmentsListContainer');
        container.innerHTML = '';

        if (attachments.length === 0) {
            container.innerHTML = '<p style="color:#94A3B8; font-style:italic; font-size:13.5px;">No documents attached to this build.</p>';
        } else {
            let listHtml = '';
            attachments.forEach(att => {
                listHtml += `<a href="${att.filepath}" class="bd-file-chip" target="_blank">📄 ${att.filename}</a>`;
            });
            container.innerHTML = listHtml;
        }
        document.getElementById('viewAttachmentsModal').style.display = 'block';
    }

    function closeViewModal() {
        document.getElementById('viewAttachmentsModal').style.display = 'none';
    }

    function openEditModal(build) {
        document.getElementById('edit_build_id').value = build.id;
        document.getElementById('edit_build_no').value = build.build_no;
        document.getElementById('edit_project').value = build.project;
        document.getElementById('edit_status').value = build.status;
        document.getElementById('edit_build_by').value = build.build_by;
        document.getElementById('edit_supported_by').value = build.supported_by || '';
        document.getElementById('edit_build_from').value = build.build_from || '';
        document.getElementById('editModal').style.display = 'block';
    }

    function closeEditModal() {
        document.getElementById('editModal').style.display = 'none';
    }

    window.addEventListener('click', function (event) {
        const editModal = document.getElementById('editModal');
        const viewModal = document.getElementById('viewAttachmentsModal');
        if (event.target === editModal) editModal.style.display = 'none';
        if (event.target === viewModal) viewModal.style.display = 'none';
    });
</script>

<?php include 'includes/footer.php'; ?>
