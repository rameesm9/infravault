<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function redirect_issue($id = null): void
{
    if ($id !== null) {
        header('Location: known-issues.php?view=' . (int)$id);
    } else {
        header('Location: known-issues.php');
    }

    exit;
}

function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}

function short_text(string $text, int $length = 90): string
{
    $text = trim($text);

    if (strlen($text) <= $length) {
        return $text;
    }

    return substr($text, 0, $length) . '...';
}

function get_user_name(PDO $pdo, int $user_id): string
{
    if ($user_id <= 0) {
        return 'Unknown User';
    }

    $stmt = $pdo->prepare("
        SELECT first_name, last_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return 'Unknown User';
    }

    return trim(
        $user['first_name'] . ' ' . $user['last_name']
    );
}

function sanitize_issue_html(string $html): string
{
    $allowed_tags = [
        'p',
        'br',
        'strong',
        'b',
        'em',
        'i',
        'u',
        'h2',
        'h3',
        'ul',
        'ol',
        'li',
        'blockquote',
        'pre',
        'code',
        'a',
        'img',
        'hr',
        'table',
        'thead',
        'tbody',
        'tr',
        'th',
        'td'
    ];

    $html = strip_tags(
        $html,
        '<' . implode('><', $allowed_tags) . '>'
    );

    // Remove event handlers.
    $html = preg_replace(
        '/\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i',
        '',
        $html
    );

    // Remove javascript URLs.
    $html = preg_replace(
        '/javascript\s*:/i',
        '',
        $html
    );

    return trim($html);
}


/*
|--------------------------------------------------------------------------
| Generate Issue Number
|--------------------------------------------------------------------------
*/

function generate_issue_number(PDO $pdo): string
{
    $stmt = $pdo->query("
        SELECT issue_number
        FROM known_issues
        ORDER BY id DESC
        LIMIT 1
    ");

    $last = $stmt->fetchColumn();

    if (!$last) {
        return 'KI-001';
    }

    if (preg_match('/(\d+)$/', $last, $matches)) {

        $number = ((int)$matches[1]) + 1;

        return 'KI-' . str_pad(
            $number,
            3,
            '0',
            STR_PAD_LEFT
        );
    }

    return 'KI-001';
}


/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

function can_edit_issue(
    array $issue,
    int $user_id,
    bool $is_admin
): bool {

    return $is_admin ||
        ((int)$issue['owner_id'] === $user_id);
}

function can_delete_issue(
    array $issue,
    int $user_id,
    bool $is_admin
): bool {

    return $is_admin ||
        ((int)$issue['owner_id'] === $user_id);
}


/*
|--------------------------------------------------------------------------
| Visibility
|--------------------------------------------------------------------------
*/

function can_view_issue(
    array $issue,
    int $user_id,
    bool $is_admin,
    ?string $user_team = null
): bool {

    if ($is_admin) {
        return true;
    }

    if ((int)$issue['owner_id'] === $user_id) {
        return true;
    }

    $visibility = strtolower(
        trim($issue['visibility'] ?? 'private')
    );

    if ($visibility === 'public') {
        return true;
    }

    if (
        $visibility === 'team' &&
        $user_team !== null &&
        trim($user_team) !== '' &&
        strtolower(trim($issue['affected_team'] ?? '')) ===
        strtolower(trim($user_team))
    ) {
        return true;
    }

    return false;
}


/*
|--------------------------------------------------------------------------
| Current user's team
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT team
    FROM users
    WHERE id = ?
    LIMIT 1
");

$stmt->execute([$current_user_id]);

$current_user_team = $stmt->fetchColumn() ?: '';


/*
|--------------------------------------------------------------------------
| Upload directory
|--------------------------------------------------------------------------
*/

$upload_dir_fs = __DIR__ . '/uploads/known-issues';


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg = $_SESSION['known_issue_success'] ?? '';
$error_msg = $_SESSION['known_issue_error'] ?? '';

unset(
    $_SESSION['known_issue_success'],
    $_SESSION['known_issue_error']
);


/*
|--------------------------------------------------------------------------
| ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $form_action = $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | CREATE / UPDATE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_issue') {

        $issue_id = (int)($_POST['issue_id'] ?? 0);

        $title = trim($_POST['title'] ?? '');
        $description = trim($_POST['description'] ?? '');

        $category = trim($_POST['category'] ?? 'General');

        $severity = trim(
            $_POST['severity'] ?? 'Medium'
        );

        $status = trim(
            $_POST['status'] ?? 'Open'
        );

        $affected_team = trim(
            $_POST['affected_team'] ?? ''
        );

        $affected_system = trim(
            $_POST['affected_system'] ?? ''
        );

        $environment = trim(
            $_POST['environment'] ?? ''
        );

        $visibility = trim(
            $_POST['visibility'] ?? 'Private'
        );

        $symptoms = sanitize_issue_html(
            $_POST['symptoms_html'] ?? ''
        );

        $cause = sanitize_issue_html(
            $_POST['cause_html'] ?? ''
        );

        $workaround = sanitize_issue_html(
            $_POST['workaround_html'] ?? ''
        );

        $resolution = sanitize_issue_html(
            $_POST['resolution_html'] ?? ''
        );

        $notes = sanitize_issue_html(
            $_POST['notes_html'] ?? ''
        );


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {

            $_SESSION['known_issue_error'] =
                'Issue title is required.';

            redirect_issue(
                $issue_id ?: null
            );
        }


        $valid_severity = [
            'Low',
            'Medium',
            'High',
            'Critical'
        ];

        if (!in_array($severity, $valid_severity, true)) {
            $severity = 'Medium';
        }


        $valid_status = [
            'Open',
            'Investigating',
            'Workaround Available',
            'Resolved',
            'Closed'
        ];

        if (!in_array($status, $valid_status, true)) {
            $status = 'Open';
        }


        $valid_visibility = [
            'Private',
            'Team',
            'Public'
        ];

        if (!in_array($visibility, $valid_visibility, true)) {
            $visibility = 'Private';
        }


        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($issue_id === 0) {

            $issue_number = generate_issue_number($pdo);

            $resolved_at = null;

            if (
                $status === 'Resolved' ||
                $status === 'Closed'
            ) {
                $resolved_at = date('Y-m-d H:i:s');
            }


            $stmt = $pdo->prepare("
                INSERT INTO known_issues (
                    issue_number,
                    title,
                    description,
                    category,
                    severity,
                    status,
                    owner_id,
                    affected_team,
                    affected_system,
                    environment,
                    symptoms_html,
                    cause_html,
                    workaround_html,
                    resolution_html,
                    notes_html,
                    visibility,
                    resolved_at,
                    created_at,
                    updated_at
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");

            $stmt->execute([
                $issue_number,
                $title,
                $description,
                $category,
                $severity,
                $status,
                $current_user_id,
                $affected_team,
                $affected_system,
                $environment,
                $symptoms,
                $cause,
                $workaround,
                $resolution,
                $notes,
                $visibility,
                $resolved_at
            ]);

            $issue_id = (int)$pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | Attachments
            |--------------------------------------------------------------------------
            */

            process_issue_attachments(
                $pdo,
                $upload_dir_fs,
                $issue_id,
                $current_user_id
            );


            $_SESSION['known_issue_success'] =
                'Known issue created successfully.';

            redirect_issue($issue_id);
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM known_issues
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$issue_id]);

        $existing = $stmt->fetch(
            PDO::FETCH_ASSOC
        );

        if (!$existing) {

            $_SESSION['known_issue_error'] =
                'Known issue not found.';

            redirect_issue();
        }


        if (!can_edit_issue(
            $existing,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'You do not have permission to edit this issue.'
            );
        }


        $resolved_at = $existing['resolved_at'];

        if (
            $status === 'Resolved' ||
            $status === 'Closed'
        ) {

            if (empty($resolved_at)) {
                $resolved_at =
                    date('Y-m-d H:i:s');
            }

        } else {

            $resolved_at = null;
        }


        $stmt = $pdo->prepare("
            UPDATE known_issues
            SET
                title = ?,
                description = ?,
                category = ?,
                severity = ?,
                status = ?,
                affected_team = ?,
                affected_system = ?,
                environment = ?,
                symptoms_html = ?,
                cause_html = ?,
                workaround_html = ?,
                resolution_html = ?,
                notes_html = ?,
                visibility = ?,
                resolved_at = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");

        $stmt->execute([
            $title,
            $description,
            $category,
            $severity,
            $status,
            $affected_team,
            $affected_system,
            $environment,
            $symptoms,
            $cause,
            $workaround,
            $resolution,
            $notes,
            $visibility,
            $resolved_at,
            $issue_id
        ]);


        process_issue_attachments(
            $pdo,
            $upload_dir_fs,
            $issue_id,
            $current_user_id
        );


        $_SESSION['known_issue_success'] =
            'Known issue updated successfully.';

        redirect_issue($issue_id);
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE ISSUE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_issue') {

        $issue_id = (int)(
            $_POST['issue_id'] ?? 0
        );


        $stmt = $pdo->prepare("
            SELECT *
            FROM known_issues
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$issue_id]);

        $issue = $stmt->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$issue) {

            $_SESSION['known_issue_error'] =
                'Known issue not found.';

            redirect_issue();
        }


        if (!can_delete_issue(
            $issue,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'You do not have permission to delete this issue.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Delete attachment files
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT file_path
            FROM known_issue_attachments
            WHERE issue_id = ?
        ");

        $stmt->execute([$issue_id]);

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            as $attachment
        ) {

            $file = __DIR__ . '/' .
                ltrim(
                    $attachment['file_path'],
                    '/\\'
                );

            if (is_file($file)) {
                @unlink($file);
            }
        }


        $pdo->prepare("
            DELETE FROM known_issue_attachments
            WHERE issue_id = ?
        ")->execute([$issue_id]);


        $pdo->prepare("
            DELETE FROM known_issues
            WHERE id = ?
        ")->execute([$issue_id]);


        $_SESSION['known_issue_success'] =
            'Known issue deleted successfully.';

        redirect_issue();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE ATTACHMENT
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_attachment') {

        $attachment_id = (int)(
            $_POST['attachment_id'] ?? 0
        );


        $stmt = $pdo->prepare("
            SELECT
                a.*,
                k.owner_id
            FROM known_issue_attachments a
            INNER JOIN known_issues k
                ON k.id = a.issue_id
            WHERE a.id = ?
            LIMIT 1
        ");

        $stmt->execute([$attachment_id]);

        $attachment = $stmt->fetch(
            PDO::FETCH_ASSOC
        );


        if (!$attachment) {

            $_SESSION['known_issue_error'] =
                'Attachment not found.';

            redirect_issue();
        }


        if (
            !$is_admin &&
            (int)$attachment['owner_id']
                !== $current_user_id
        ) {

            http_response_code(403);

            exit('Permission denied.');
        }


        $file = __DIR__ . '/' .
            ltrim(
                $attachment['file_path'],
                '/\\'
            );

        if (is_file($file)) {
            @unlink($file);
        }


        $stmt = $pdo->prepare("
            DELETE FROM known_issue_attachments
            WHERE id = ?
        ");

        $stmt->execute([
            $attachment_id
        ]);


        $_SESSION['known_issue_success'] =
            'Attachment removed.';

        redirect_issue(
            $attachment['issue_id']
        );
    }
}


/*
|--------------------------------------------------------------------------
| Attachment processing
|--------------------------------------------------------------------------
*/

function process_issue_attachments(
    PDO $pdo,
    string $upload_dir_fs,
    int $issue_id,
    int $uploader_id
): void {

    if (
        empty($_FILES['attachments']) ||
        empty($_FILES['attachments']['name'][0])
    ) {
        return;
    }


    if (!is_dir($upload_dir_fs)) {
        mkdir(
            $upload_dir_fs,
            0755,
            true
        );
    }


    $allowed_extensions = [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'csv',
        'ppt',
        'pptx',
        'txt',
        'png',
        'jpg',
        'jpeg',
        'gif',
        'webp',
        'zip'
    ];


    $count = count(
        $_FILES['attachments']['name']
    );


    for ($i = 0; $i < $count; $i++) {

        if (
            $_FILES['attachments']['error'][$i]
            !== UPLOAD_ERR_OK
        ) {
            continue;
        }


        $original_name = basename(
            $_FILES['attachments']['name'][$i]
        );

        $extension = strtolower(
            pathinfo(
                $original_name,
                PATHINFO_EXTENSION
            )
        );


        if (
            !in_array(
                $extension,
                $allowed_extensions,
                true
            )
        ) {
            continue;
        }


        $safe_name = preg_replace(
            '/[^a-zA-Z0-9._-]/',
            '_',
            $original_name
        );


        $stored_name =
            bin2hex(random_bytes(12)) .
            '_' .
            $safe_name;


        $destination =
            $upload_dir_fs .
            '/' .
            $stored_name;


        if (
            move_uploaded_file(
                $_FILES['attachments']['tmp_name'][$i],
                $destination
            )
        ) {

            $relative_path =
                'uploads/known-issues/' .
                $stored_name;


            $mime = 'application/octet-stream';

            if (function_exists('mime_content_type')) {
                $mime =
                    mime_content_type($destination)
                    ?: $mime;
            }


            $stmt = $pdo->prepare("
                INSERT INTO known_issue_attachments (
                    issue_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size,
                    uploaded_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $issue_id,
                $original_name,
                $stored_name,
                $relative_path,
                $mime,
                filesize($destination),
                $uploader_id
            ]);
        }
    }
}


/*
|--------------------------------------------------------------------------
| FILE DOWNLOAD
|--------------------------------------------------------------------------
*/

$action = $_GET['action'] ?? '';

if ($action === 'download') {

    $attachment_id = (int)(
        $_GET['id'] ?? 0
    );


    $stmt = $pdo->prepare("
        SELECT
            a.*,
            k.owner_id,
            k.visibility,
            k.affected_team
        FROM known_issue_attachments a
        INNER JOIN known_issues k
            ON k.id = a.issue_id
        WHERE a.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $attachment_id
    ]);

    $attachment = $stmt->fetch(
        PDO::FETCH_ASSOC
    );


    if (!$attachment) {
        http_response_code(404);
        exit('File not found.');
    }


    if (!can_view_issue(
        $attachment,
        $current_user_id,
        $is_admin,
        $current_user_team
    )) {

        http_response_code(403);

        exit(
            'You do not have permission to access this file.'
        );
    }


    $file = __DIR__ . '/' .
        ltrim(
            $attachment['file_path'],
            '/\\'
        );


    if (!is_file($file)) {

        http_response_code(404);

        exit('File not found.');
    }


    $mime =
        $attachment['mime_type']
        ?: 'application/octet-stream';


    header(
        'Content-Type: ' . $mime
    );

    header(
        'Content-Length: ' .
        filesize($file)
    );

    header(
        'X-Content-Type-Options: nosniff'
    );

    header(
        'Content-Disposition: attachment; filename="' .
        basename($attachment['original_name']) .
        '"'
    );


    readfile($file);

    exit;
}


/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT DISTINCT team
    FROM users
    WHERE is_approved = 1
      AND team IS NOT NULL
      AND TRIM(team) <> ''
    ORDER BY team
");

$teams = $stmt->fetchAll(
    PDO::FETCH_COLUMN
);


/*
|--------------------------------------------------------------------------
| Issue Categories
|--------------------------------------------------------------------------
*/

$categories = [
    'General',
    'Application',
    'Database',
    'Network',
    'Server',
    'Linux',
    'Windows',
    'Security',
    'Backup',
    'Storage',
    'Monitoring',
    'Cloud',
    'Container Platform',
    'Authentication',
    'Performance',
    'Hardware',
    'Other'
];


/*
|--------------------------------------------------------------------------
| Issue data
|--------------------------------------------------------------------------
*/

$issue_id = (int)(
    $_GET['view'] ??
    $_GET['edit'] ??
    0
);

$issue = null;

if ($issue_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            k.*,
            u.first_name AS owner_first_name,
            u.last_name AS owner_last_name,
            u.email AS owner_email,
            u.team AS owner_team
        FROM known_issues k
        LEFT JOIN users u
            ON u.id = k.owner_id
        WHERE k.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $issue_id
    ]);

    $issue = $stmt->fetch(
        PDO::FETCH_ASSOC
    );


    if (!$issue) {

        $_SESSION['known_issue_error'] =
            'Known issue not found.';

        redirect_issue();
    }


    if (!can_view_issue(
        $issue,
        $current_user_id,
        $is_admin,
        $current_user_team
    )) {

        http_response_code(403);

        exit(
            'You do not have permission to view this issue.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

$attachments = [];

if ($issue_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            u.first_name,
            u.last_name
        FROM known_issue_attachments a
        LEFT JOIN users u
            ON u.id = a.uploaded_by
        WHERE a.issue_id = ?
        ORDER BY a.created_at DESC
    ");

    $stmt->execute([
        $issue_id
    ]);

    $attachments =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
}


/*
|--------------------------------------------------------------------------
| Mode
|--------------------------------------------------------------------------
*/

$is_view =
    isset($_GET['view']) &&
    $issue !== null;

$is_edit =
    isset($_GET['edit']) &&
    $issue !== null;

$is_create =
    isset($_GET['new']) &&
    !$is_view &&
    !$is_edit;


/*
|--------------------------------------------------------------------------
| Edit permission
|--------------------------------------------------------------------------
*/

if ($is_edit) {

    if (!can_edit_issue(
        $issue,
        $current_user_id,
        $is_admin
    )) {

        http_response_code(403);

        exit(
            'You do not have permission to edit this issue.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT status, COUNT(*) AS total
    FROM known_issues
    GROUP BY status
");

$status_counts = [];

foreach (
    $stmt->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {

    $status_counts[
        $row['status']
    ] = (int)$row['total'];
}


$total_issues =
    array_sum($status_counts);

$open =
    $status_counts['Open'] ?? 0;

$investigating =
    $status_counts['Investigating'] ?? 0;

$workaround =
    $status_counts['Workaround Available'] ?? 0;

$resolved =
    ($status_counts['Resolved'] ?? 0) +
    ($status_counts['Closed'] ?? 0);


$page_title = 'Known Issues';

require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<link
    rel="stylesheet"
    href="assets/css/known-issues.css"
>

<div class="content known-issues-content">

<?php if ($success_msg): ?>

    <div class="known-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="known-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<?php
/*
|--------------------------------------------------------------------------
| CREATE / EDIT
|--------------------------------------------------------------------------
*/

if ($is_create || $is_edit):

    $form_title =
        $is_edit
        ? 'Edit Known Issue'
        : 'Create Known Issue';


    $form_issue_number =
        $issue['issue_number']
        ?? generate_issue_number($pdo);


    $form_name =
        $issue['title'] ?? '';


    $form_description =
        $issue['description'] ?? '';


    $form_category =
        $issue['category'] ?? 'General';


    $form_severity =
        $issue['severity'] ?? 'Medium';


    $form_status =
        $issue['status'] ?? 'Open';


    $form_team =
        $issue['affected_team'] ?? '';


    $form_system =
        $issue['affected_system'] ?? '';


    $form_environment =
        $issue['environment'] ?? '';


    $form_visibility =
        $issue['visibility'] ?? 'Private';


    $form_symptoms =
        $issue['symptoms_html'] ?? '';


    $form_cause =
        $issue['cause_html'] ?? '';


    $form_workaround =
        $issue['workaround_html'] ?? '';


    $form_resolution =
        $issue['resolution_html'] ?? '';


    $form_notes =
        $issue['notes_html'] ?? '';

?>

<div class="known-page-header">

    <div>
        <h1><?= h($form_title) ?></h1>

        <p>
            Track infrastructure issues,
            symptoms, workarounds and resolutions.
        </p>
    </div>

    <a
        href="known-issues.php"
        class="known-secondary-btn"
    >
        Back to Known Issues
    </a>

</div>


<form
    method="POST"
    action="known-issues.php"
    enctype="multipart/form-data"
    id="knownIssueForm"
>


<input
    type="hidden"
    name="csrf_token"
    value="<?= h($csrf_token) ?>"
>

<input
    type="hidden"
    name="form_action"
    value="save_issue"
>

<input
    type="hidden"
    name="issue_id"
    value="<?= (int)($issue['id'] ?? 0) ?>"
>


<!-- BASIC INFORMATION -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Basic Information</h2>

        <span>
            Issue identification and classification
        </span>

    </div>


    <div class="known-form-grid">


        <div class="known-field">

            <label>Issue Number</label>

            <input
                type="text"
                value="<?= h($form_issue_number) ?>"
                readonly
            >

        </div>


        <div class="known-field">

            <label>Owner</label>

            <input
                type="text"
                value="<?= h(
                    $is_edit
                    ? trim(
                        ($issue['owner_first_name'] ?? '') .
                        ' ' .
                        ($issue['owner_last_name'] ?? '')
                    )
                    : get_user_name(
                        $pdo,
                        $current_user_id
                    )
                ) ?>"
                readonly
            >

        </div>


        <div class="known-field full">

            <label>
                Title <span>*</span>
            </label>

            <input
                type="text"
                name="title"
                required
                value="<?= h($form_name) ?>"
                placeholder="Example: Intermittent DNS resolution failure"
            >

        </div>


        <div class="known-field">

            <label>Category</label>

            <select name="category">

                <?php foreach ($categories as $category): ?>

                    <option
                        value="<?= h($category) ?>"
                        <?= $form_category === $category
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($category) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="known-field">

            <label>Severity</label>

            <select name="severity">

                <?php foreach (
                    ['Low', 'Medium', 'High', 'Critical']
                    as $level
                ): ?>

                    <option
                        value="<?= h($level) ?>"
                        <?= $form_severity === $level
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($level) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="known-field">

            <label>Status</label>

            <select name="status">

                <?php foreach (
                    [
                        'Open',
                        'Investigating',
                        'Workaround Available',
                        'Resolved',
                        'Closed'
                    ]
                    as $status
                ): ?>

                    <option
                        value="<?= h($status) ?>"
                        <?= $form_status === $status
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($status) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="known-field">

            <label>Environment</label>

            <select name="environment">

                <option value="">Select</option>

                <?php foreach (
                    [
                        'Production',
                        'UAT',
                        'Development',
                        'Test',
                        'DR',
                        'Other'
                    ]
                    as $environment
                ): ?>

                    <option
                        value="<?= h($environment) ?>"
                        <?= $form_environment === $environment
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($environment) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="known-field">

            <label>Affected Team</label>

            <select name="affected_team">

                <option value="">
                    -- Select Team --
                </option>

                <?php foreach ($teams as $team): ?>

                    <option
                        value="<?= h($team) ?>"
                        <?= $form_team === $team
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($team) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="known-field">

            <label>Affected System / Service</label>

            <input
                type="text"
                name="affected_system"
                value="<?= h($form_system) ?>"
                placeholder="Example: DNS / Satellite / API"
            >

        </div>


        <div class="known-field">

            <label>Visibility</label>

            <select name="visibility">

                <?php foreach (
                    ['Private', 'Team', 'Public']
                    as $visibility
                ): ?>

                    <option
                        value="<?= h($visibility) ?>"
                        <?= $form_visibility === $visibility
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($visibility) ?>
                    </option>

                <?php endforeach; ?>

            </select>

            <small class="field-help">
                Private = owner/admin.
                Team = selected team.
                Public = all portal users.
            </small>

        </div>


        <div class="known-field full">

            <label>Description</label>

            <textarea
                name="description"
                rows="4"
                placeholder="Brief description of the known issue."
            ><?= h($form_description) ?></textarea>

        </div>

    </div>

</div>


<!-- SYMPTOMS -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Symptoms</h2>

        <span>
            What users or administrators observe
        </span>

    </div>


    <div
        class="known-rich-editor"
        contenteditable="true"
        data-target="symptoms_html"
    ><?= $form_symptoms ?></div>

    <textarea
        name="symptoms_html"
        class="known-editor-hidden"
    ></textarea>

</div>


<!-- CAUSE -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Known Cause</h2>

        <span>
            Root cause or suspected cause
        </span>

    </div>


    <div
        class="known-rich-editor"
        contenteditable="true"
        data-target="cause_html"
    ><?= $form_cause ?></div>

    <textarea
        name="cause_html"
        class="known-editor-hidden"
    ></textarea>

</div>


<!-- WORKAROUND -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Workaround</h2>

        <span>
            Temporary solution available to users
        </span>

    </div>


    <div
        class="known-rich-editor"
        contenteditable="true"
        data-target="workaround_html"
    ><?= $form_workaround ?></div>

    <textarea
        name="workaround_html"
        class="known-editor-hidden"
    ></textarea>

</div>


<!-- RESOLUTION -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Resolution</h2>

        <span>
            Permanent solution or corrective action
        </span>

    </div>


    <div
        class="known-rich-editor"
        contenteditable="true"
        data-target="resolution_html"
    ><?= $form_resolution ?></div>

    <textarea
        name="resolution_html"
        class="known-editor-hidden"
    ></textarea>

</div>


<!-- NOTES -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Additional Notes</h2>

        <span>
            Other operational information
        </span>

    </div>


    <div
        class="known-rich-editor"
        contenteditable="true"
        data-target="notes_html"
    ><?= $form_notes ?></div>

    <textarea
        name="notes_html"
        class="known-editor-hidden"
    ></textarea>

</div>


<!-- ATTACHMENTS -->

<div class="known-form-panel">

    <div class="known-section-title">

        <h2>Attachments</h2>

        <span>
            Logs, screenshots, reports and supporting files
        </span>

    </div>


    <input
        type="file"
        name="attachments[]"
        multiple
        class="known-attachment-input"
    >


    <?php if ($attachments): ?>

        <div class="known-attachment-list">

            <?php foreach ($attachments as $attachment): ?>

                <div class="known-attachment-item">

                    <div>

                        <strong>
                            <?= h(
                                $attachment['original_name']
                            ) ?>
                        </strong>

                        <small>
                            <?= h(
                                number_format(
                                    $attachment['file_size'] / 1024,
                                    1
                                )
                            ) ?>
                            KB
                        </small>

                    </div>


                    <div>

                        <a
                            href="known-issues.php?action=download&id=<?= (int)$attachment['id'] ?>"
                            class="known-download"
                        >
                            Download
                        </a>


                        <?php if (
                            can_edit_issue(
                                $issue,
                                $current_user_id,
                                $is_admin
                            )
                        ): ?>

                            <button
                                type="submit"
                                name="form_action"
                                value="delete_attachment"
                                class="known-remove"
                                formaction="known-issues.php"
                                onclick="return confirm('Remove this attachment?');"
                            >
                                Remove
                            </button>

                            <input
                                type="hidden"
                                name="attachment_id"
                                value="<?= (int)$attachment['id'] ?>"
                            >

                        <?php endif; ?>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

    <?php endif; ?>

</div>


<!-- FORM ACTIONS -->

<div class="known-form-actions">

    <a
        href="known-issues.php"
        class="known-secondary-btn"
    >
        Cancel
    </a>

    <button
        type="submit"
        class="known-primary-btn"
    >
        Save Known Issue
    </button>

</div>


</form>


<?php

/*
|--------------------------------------------------------------------------
| VIEW
|--------------------------------------------------------------------------
*/

elseif ($is_view && $issue):

?>

<div class="known-page-header">

    <div>

        <div class="known-issue-number">
            <?= h($issue['issue_number']) ?>
        </div>

        <h1>
            <?= h($issue['title']) ?>
        </h1>

        <p>
            <?= h($issue['description']) ?>
        </p>

    </div>


    <div class="known-header-actions">

        <?php if (
            can_edit_issue(
                $issue,
                $current_user_id,
                $is_admin
            )
        ): ?>

            <a
                href="known-issues.php?edit=<?= (int)$issue['id'] ?>"
                class="known-secondary-btn"
            >
                Edit
            </a>

        <?php endif; ?>


        <a
            href="known-issues.php"
            class="known-secondary-btn"
        >
            Back
        </a>

    </div>

</div>


<!-- META -->

<div class="known-meta-grid">

    <div>

        <span>STATUS</span>

        <strong class="known-status status-<?= strtolower(
            str_replace(
                ' ',
                '-',
                $issue['status']
            )
        ) ?>">
            <?= h($issue['status']) ?>
        </strong>

    </div>


    <div>

        <span>SEVERITY</span>

        <strong class="known-severity severity-<?= strtolower(
            $issue['severity']
        ) ?>">
            <?= h($issue['severity']) ?>
        </strong>

    </div>


    <div>

        <span>CATEGORY</span>

        <strong>
            <?= h($issue['category']) ?>
        </strong>

    </div>


    <div>

        <span>ENVIRONMENT</span>

        <strong>
            <?= h($issue['environment'] ?: '—') ?>
        </strong>

    </div>


    <div>

        <span>AFFECTED TEAM</span>

        <strong>
            <?= h($issue['affected_team'] ?: '—') ?>
        </strong>

    </div>


    <div>

        <span>SYSTEM / SERVICE</span>

        <strong>
            <?= h($issue['affected_system'] ?: '—') ?>
        </strong>

    </div>


    <div>

        <span>OWNER</span>

        <strong>
            <?= h(
                trim(
                    ($issue['owner_first_name'] ?? '') .
                    ' ' .
                    ($issue['owner_last_name'] ?? '')
                )
            ) ?>
        </strong>

    </div>


    <div>

        <span>VISIBILITY</span>

        <strong>
            <?= h($issue['visibility']) ?>
        </strong>

    </div>


    <div>

        <span>UPDATED</span>

        <strong>
            <?= h(
                date(
                    'd M Y H:i',
                    strtotime(
                        $issue['updated_at']
                    )
                )
            ) ?>
        </strong>

    </div>

</div>


<!-- DOCUMENT -->

<div class="known-document">


    <?php if (
        trim(
            (string)$issue['symptoms_html']
        ) !== ''
    ): ?>

        <section>

            <h2>Symptoms</h2>

            <div class="known-rich-content">
                <?= $issue['symptoms_html'] ?>
            </div>

        </section>

    <?php endif; ?>


    <?php if (
        trim(
            (string)$issue['cause_html']
        ) !== ''
    ): ?>

        <section>

            <h2>Known Cause</h2>

            <div class="known-rich-content">
                <?= $issue['cause_html'] ?>
            </div>

        </section>

    <?php endif; ?>


    <?php if (
        trim(
            (string)$issue['workaround_html']
        ) !== ''
    ): ?>

        <section class="known-workaround">

            <h2>Workaround</h2>

            <div class="known-rich-content">
                <?= $issue['workaround_html'] ?>
            </div>

        </section>

    <?php endif; ?>


    <?php if (
        trim(
            (string)$issue['resolution_html']
        ) !== ''
    ): ?>

        <section class="known-resolution">

            <h2>Resolution</h2>

            <div class="known-rich-content">
                <?= $issue['resolution_html'] ?>
            </div>

        </section>

    <?php endif; ?>


    <?php if (
        trim(
            (string)$issue['notes_html']
        ) !== ''
    ): ?>

        <section>

            <h2>Additional Notes</h2>

            <div class="known-rich-content">
                <?= $issue['notes_html'] ?>
            </div>

        </section>

    <?php endif; ?>


    <!-- ATTACHMENTS -->

    <section>

        <h2>Attachments</h2>


        <?php if ($attachments): ?>

            <div class="known-view-attachments">

                <?php foreach (
                    $attachments
                    as $attachment
                ): ?>

                    <a
                        href="known-issues.php?action=download&id=<?= (int)$attachment['id'] ?>"
                        class="known-view-attachment"
                    >

                        <span>📎</span>

                        <span>

                            <strong>
                                <?= h(
                                    $attachment['original_name']
                                ) ?>
                            </strong>

                            <small>
                                <?= h(
                                    number_format(
                                        $attachment['file_size'] / 1024,
                                        1
                                    )
                                ) ?>
                                KB
                            </small>

                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <p class="muted">
                No attachments.
            </p>

        <?php endif; ?>

    </section>


</div>


<?php

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

else:

?>

<div class="known-page-header">

    <div>

        <h1>Known Issues</h1>

        <p>
            Track infrastructure problems,
            workarounds and resolutions.
        </p>

    </div>


    <a
        href="known-issues.php?new=1"
        class="known-primary-btn"
    >
        + New Known Issue
    </a>

</div>


<!-- STATS -->

<div class="known-stats">

    <div class="known-stat-card">

        <span>Total Issues</span>

        <strong>
            <?= $total_issues ?>
        </strong>

    </div>


    <div class="known-stat-card open">

        <span>Open</span>

        <strong>
            <?= $open ?>
        </strong>

    </div>


    <div class="known-stat-card investigating">

        <span>Investigating</span>

        <strong>
            <?= $investigating ?>
        </strong>

    </div>


    <div class="known-stat-card workaround">

        <span>Workaround Available</span>

        <strong>
            <?= $workaround ?>
        </strong>

    </div>


    <div class="known-stat-card resolved">

        <span>Resolved / Closed</span>

        <strong>
            <?= $resolved ?>
        </strong>

    </div>

</div>


<!-- LIBRARY -->

<div class="known-panel">

    <div class="known-panel-header">

        <div>

            <h2>Known Issue Library</h2>

            <span>
                Operational issues and resolutions
            </span>

        </div>


        <div class="known-filter-area">

            <input
                type="text"
                id="knownIssueSearch"
                class="known-search"
                placeholder="Search issues..."
            >


            <select
                id="statusFilter"
                class="known-filter"
            >

                <option value="">
                    All Statuses
                </option>

                <option value="Open">
                    Open
                </option>

                <option value="Investigating">
                    Investigating
                </option>

                <option value="Workaround Available">
                    Workaround Available
                </option>

                <option value="Resolved">
                    Resolved
                </option>

                <option value="Closed">
                    Closed
                </option>

            </select>


            <select
                id="severityFilter"
                class="known-filter"
            >

                <option value="">
                    All Severity
                </option>

                <option value="Low">
                    Low
                </option>

                <option value="Medium">
                    Medium
                </option>

                <option value="High">
                    High
                </option>

                <option value="Critical">
                    Critical
                </option>

            </select>

        </div>

    </div>


    <div class="known-table-wrapper">

        <table class="known-table">

            <thead>

                <tr>

                    <th>Issue</th>

                    <th>Title</th>

                    <th>Category</th>

                    <th>Severity</th>

                    <th>Status</th>

                    <th>Team</th>

                    <th>Owner</th>

                    <th>Updated</th>

                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>


<?php

$stmt = $pdo->prepare("
    SELECT
        k.*,
        u.first_name,
        u.last_name
    FROM known_issues k
    LEFT JOIN users u
        ON u.id = k.owner_id
    ORDER BY k.updated_at DESC
");

$stmt->execute();

$issues = $stmt->fetchAll(
    PDO::FETCH_ASSOC
);


/*
|--------------------------------------------------------------------------
| Filter visible issues
|--------------------------------------------------------------------------
*/

$visible_issues = [];

foreach ($issues as $row) {

    if (
        can_view_issue(
            $row,
            $current_user_id,
            $is_admin,
            $current_user_team
        )
    ) {

        $visible_issues[] = $row;
    }
}


if (!$visible_issues):

?>

<tr>

    <td
        colspan="9"
        class="known-empty"
    >
        No known issues are available.
    </td>

</tr>

<?php endif; ?>


<?php foreach (
    $visible_issues
    as $row
): ?>

<?php

$owner_name = trim(
    ($row['first_name'] ?? '') .
    ' ' .
    ($row['last_name'] ?? '')
);

$can_edit =
    can_edit_issue(
        $row,
        $current_user_id,
        $is_admin
    );

$can_delete =
    can_delete_issue(
        $row,
        $current_user_id,
        $is_admin
    );

?>

<tr
    data-status="<?= h($row['status']) ?>"
    data-severity="<?= h($row['severity']) ?>"
>


<td>

    <strong class="known-number">
        <?= h($row['issue_number']) ?>
    </strong>

</td>


<td>

    <a
        href="known-issues.php?view=<?= (int)$row['id'] ?>"
        class="known-title"
    >
        <?= h($row['title']) ?>
    </a>


    <?php if (
        !empty($row['description'])
    ): ?>

        <small class="known-description">
            <?= h(
                short_text(
                    $row['description'],
                    70
                )
            ) ?>
        </small>

    <?php endif; ?>

</td>


<td>

    <?= h($row['category']) ?>

</td>


<td>

    <span
        class="known-severity severity-<?= strtolower(
            $row['severity']
        ) ?>"
    >
        <?= h($row['severity']) ?>
    </span>

</td>


<td>

    <span
        class="known-status status-<?= strtolower(
            str_replace(
                ' ',
                '-',
                $row['status']
            )
        ) ?>"
    >
        <?= h($row['status']) ?>
    </span>

</td>


<td>

    <?= h(
        $row['affected_team']
        ?: '—'
    ) ?>

</td>


<td>

    <?= h(
        $owner_name
        ?: 'Unknown'
    ) ?>

</td>


<td>

    <?= h(
        date(
            'd M Y',
            strtotime(
                $row['updated_at']
            )
        )
    ) ?>

</td>


<td>

    <div class="known-actions">


        <a
            href="known-issues.php?view=<?= (int)$row['id'] ?>"
            class="known-action view"
        >
            View
        </a>


        <?php if ($can_edit): ?>

            <a
                href="known-issues.php?edit=<?= (int)$row['id'] ?>"
                class="known-action edit"
            >
                Edit
            </a>

        <?php endif; ?>


        <?php if ($can_delete): ?>

            <form
                method="POST"
                action="known-issues.php"
                style="display:inline"
                onsubmit="return confirm('Delete this known issue permanently?');"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h($csrf_token) ?>"
                >

                <input
                    type="hidden"
                    name="form_action"
                    value="delete_issue"
                >

                <input
                    type="hidden"
                    name="issue_id"
                    value="<?= (int)$row['id'] ?>"
                >

                <button
                    type="submit"
                    class="known-action delete"
                >
                    Delete
                </button>

            </form>

        <?php endif; ?>


    </div>

</td>


</tr>

<?php endforeach; ?>


            </tbody>

        </table>

    </div>

</div>


<?php endif; ?>

</div>


<script>

/*
|--------------------------------------------------------------------------
| Rich editor
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll('.known-rich-editor')
    .forEach(function(editor) {

        editor.addEventListener(
            'paste',
            function() {

                setTimeout(function() {

                    const target =
                        editor.dataset.target;

                    const field =
                        document.querySelector(
                            '[name="' +
                            target +
                            '"]'
                        );

                    if (field) {
                        field.value =
                            editor.innerHTML;
                    }

                }, 100);

            }
        );

    });


/*
|--------------------------------------------------------------------------
| Form submit
|--------------------------------------------------------------------------
*/

document
    .getElementById('knownIssueForm')
    ?.addEventListener(
        'submit',
        function() {

            document
                .querySelectorAll(
                    '.known-rich-editor'
                )
                .forEach(function(editor) {

                    const target =
                        editor.dataset.target;

                    const field =
                        document.querySelector(
                            '[name="' +
                            target +
                            '"]'
                        );

                    if (field) {
                        field.value =
                            editor.innerHTML;
                    }

                });

        }
    );


/*
|--------------------------------------------------------------------------
| Search
|--------------------------------------------------------------------------
*/

const issueSearch =
    document.getElementById(
        'knownIssueSearch'
    );

const statusFilter =
    document.getElementById(
        'statusFilter'
    );

const severityFilter =
    document.getElementById(
        'severityFilter'
    );


function filterKnownIssues() {

    const search =
        (
            issueSearch?.value ||
            ''
        ).toLowerCase();


    const status =
        statusFilter?.value ||
        '';


    const severity =
        severityFilter?.value ||
        '';


    document
        .querySelectorAll(
            '.known-table tbody tr'
        )
        .forEach(function(row) {

            const rowText =
                row.innerText.toLowerCase();


            const rowStatus =
                row.dataset.status ||
                '';


            const rowSeverity =
                row.dataset.severity ||
                '';


            const matchesSearch =
                !search ||
                rowText.includes(search);


            const matchesStatus =
                !status ||
                rowStatus === status;


            const matchesSeverity =
                !severity ||
                rowSeverity === severity;


            row.style.display =
                (
                    matchesSearch &&
                    matchesStatus &&
                    matchesSeverity
                )
                ? ''
                : 'none';

        });
}


issueSearch?.addEventListener(
    'input',
    filterKnownIssues
);

statusFilter?.addEventListener(
    'change',
    filterKnownIssues
);

severityFilter?.addEventListener(
    'change',
    filterKnownIssues
);

</script>


<?php

require_once 'includes/footer.php';

?>

