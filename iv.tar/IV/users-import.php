<?php

session_start();

require_once __DIR__ . '/config/db.php';


/*
|--------------------------------------------------------------------------
| PERMISSION CHECK
|--------------------------------------------------------------------------
*/

/*
| Governed by the permissions table under 'users', like every other
| page. This was a hardcoded `!== 'Admin'` string comparison -- the last
| of the competing permission models -- which ignored the table entirely
| and locked out any role differing only in case.
*/
requireLogin();
requirePermission('users', 'can_view');
requirePermission('users', 'can_import');

/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

function usersHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'users', $permission);
}


$role = trim($_SESSION['role'] ?? '');
$canImport = usersHasPermission($pdo, $role, 'can_import');

if (!$canImport) {
    http_response_code(403);
    exit('You do not have permission to import users.');
}


/*
|--------------------------------------------------------------------------
| HANDLE CSV UPLOAD
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_users') {

    if (!isset($_FILES['csv'])) {
        http_response_code(400);
        echo 'CSV file required';
        exit;
    }

    $file = $_FILES['csv']['tmp_name'];

    if (($handle = fopen($file, 'r')) !== false) {

        $header = fgetcsv($handle);

        $imported = 0;
        $skipped = 0;
        $errors = [];

        while (($row = fgetcsv($handle)) !== false) {

            $data = array_combine($header, $row);

            $first_name = trim($data['First Name'] ?? '');
            $last_name = trim($data['Last Name'] ?? '');
            $email = trim($data['Email'] ?? '');
            $ncgr_id = trim($data['NCGR ID'] ?? '');
            $team = trim($data['Team'] ?? 'Cloud');
            $role = trim($data['Role'] ?? 'Read-only');

            /*
            |--------------------------------------------------------------------------
            | VALIDATION
            |--------------------------------------------------------------------------
            */

            if (!$first_name || !$last_name || !$email || !$ncgr_id) {
                $skipped++;
                continue;
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                $skipped++;
                continue;
            }

            /*
            |--------------------------------------------------------------------------
            | DUPLICATE CHECK
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                SELECT id
                FROM users
                WHERE ncgr_id = ? OR email = ?
            ");

            $stmt->execute([$ncgr_id, $email]);

            if ($stmt->fetch()) {
                $skipped++;
                continue;
            }

            /*
            |--------------------------------------------------------------------------
            | GENERATE TEMPORARY PASSWORD
            |--------------------------------------------------------------------------
            */

            $tempPassword = bin2hex(random_bytes(5));
            $passwordHash = password_hash($tempPassword, PASSWORD_DEFAULT);

            /*
            |--------------------------------------------------------------------------
            | INSERT USER
            |--------------------------------------------------------------------------
            */

            try {

                $stmt = $pdo->prepare("
                    INSERT INTO users
                    (first_name, last_name, email, ncgr_id, team, role, password, is_approved)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 0)
                ");

                $stmt->execute([
                    $first_name,
                    $last_name,
                    $email,
                    $ncgr_id,
                    $team,
                    $role,
                    $passwordHash
                ]);

                $user_id = $pdo->lastInsertId();

                /*
                |--------------------------------------------------------------------------
                | AUDIT LOG
                |--------------------------------------------------------------------------
                */

                $historyStmt = $pdo->prepare("
                    INSERT INTO user_action_history
                    (user_id, action, changes, created_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                ");

                $historyStmt->execute([
                    $user_id,
                    'Created',
                    'User imported via CSV'
                ]);

                $imported++;

            } catch (Throwable $e) {

                $errors[] = "Error importing {$first_name} {$last_name}: " . $e->getMessage();
                $skipped++;

            }

        }

        fclose($handle);

        /*
        |--------------------------------------------------------------------------
        | RESPONSE
        |--------------------------------------------------------------------------
        */

        $message = "Imported: {$imported}, Skipped: {$skipped}";

        if (!empty($errors)) {
            $message .= ". Errors: " . implode("; ", array_slice($errors, 0, 5));
        }

        echo $message;
        exit;

    } else {

        http_response_code(400);
        echo 'Unable to open CSV file';
        exit;

    }

}

?>
