<?php

require_once 'config/db.php';
require_once 'includes/pagination-helpers.php';

requireLogin();
requirePermission('uid_gid', 'can_view');

$flags = authzFlags('uid_gid');

$canView   = $flags['can_view'];
$canEdit   = $flags['can_edit'];
$canDelete = $flags['can_delete'];
$canExport = $flags['can_export'];
$canImport = $flags['can_import'];
$canAudit  = $flags['can_audit'];

$current_user_id = authzUserId();


/*
|--------------------------------------------------------------------------
| RESOLVE CURRENT USERNAME (for audit trail display)
|--------------------------------------------------------------------------
*/

$username = 'Unknown User';

if ($current_user_id > 0) {

    $userStmt = $pdo->prepare("
        SELECT first_name, last_name, ncgr_id
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $userStmt->execute([$current_user_id]);
    $currentUser = $userStmt->fetch(PDO::FETCH_ASSOC);

    if ($currentUser) {
        $firstName = trim($currentUser['first_name'] ?? '');
        $lastName  = trim($currentUser['last_name'] ?? '');
        $ncgrId    = trim($currentUser['ncgr_id'] ?? '');
        $fullName  = trim($firstName . ' ' . $lastName);

        if ($fullName !== '' && $ncgrId !== '') {
            $username = $fullName . ' (' . $ncgrId . ')';
        } elseif ($fullName !== '') {
            $username = $fullName;
        } elseif ($ncgrId !== '') {
            $username = $ncgrId;
        }
    }
}


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function ug_initials(string $name): string
{
    $name = trim($name);

    if ($name === '') {
        return '?';
    }

    $parts = preg_split('/\s+/', $name);
    $initials = strtoupper(substr($parts[0], 0, 1));

    if (count($parts) > 1) {
        $initials .= strtoupper(substr(end($parts), 0, 1));
    } elseif (strlen($parts[0]) > 1) {
        $initials .= strtoupper(substr($parts[0], 1, 1));
    }

    return $initials;
}


const UG_ACCOUNT_TYPES = ['Named User', 'Service Account', 'System Account'];
const UG_STATUSES = ['Active', 'Disabled', 'Decommissioned'];
const UG_ID_FLOOR = 10000;

/*
| Next-available suggestion for the UID/GID fields, starting at the
| custom-range floor (10000). Always increments past the current high
| water mark rather than filling gaps left by deleted records -- a
| freed-up number is not offered again, so an old UID/GID can't quietly
| get reassigned to a different identity later.
*/
function ug_next_available(PDO $pdo, string $column): int
{
    $max = (int) $pdo->query("
        SELECT MAX(`$column`)
        FROM uid_gid_accounts
        WHERE `$column` >= " . UG_ID_FLOOR . "
    ")->fetchColumn();

    return $max > 0 ? $max + 1 : UG_ID_FLOOR;
}

$ug_field_labels = [
    'hostname'         => 'Hostname',
    'username'         => 'Username',
    'uid'              => 'UID',
    'gid'              => 'GID',
    'gecos'            => 'GECOS',
    'home_directory'   => 'Home Directory',
    'login_shell'      => 'Login Shell',
    'account_type'     => 'Account Type',
    'application'      => 'Application',
    'status'           => 'Status',
    'change_request'   => 'Change Request',
    'requested_by'     => 'Requested By',
    'approved_by'      => 'Ownership Confirmed By',
    'notes'            => 'Notes',
];


/*
|--------------------------------------------------------------------------
| DROPDOWN SOURCES (Inventory)
|--------------------------------------------------------------------------
*/

$hostnames = $pdo->query("
    SELECT DISTINCT hostname
    FROM inventory
    WHERE hostname IS NOT NULL
      AND hostname != ''
    ORDER BY hostname ASC
")->fetchAll(PDO::FETCH_COLUMN);

$applications = $pdo->query("
    SELECT DISTINCT application
    FROM inventory
    WHERE application IS NOT NULL
      AND application != ''
    ORDER BY application ASC
")->fetchAll(PDO::FETCH_COLUMN);


/*
|--------------------------------------------------------------------------
| STATUS OVERVIEW (KPI CARDS)
|--------------------------------------------------------------------------
*/

$status_counts = [
    'Active'         => 0,
    'Disabled'       => 0,
    'Decommissioned' => 0,
];

$status_count_stmt = $pdo->query("
    SELECT status, COUNT(*) AS cnt
    FROM uid_gid_accounts
    GROUP BY status
");

foreach ($status_count_stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    if (isset($status_counts[$row['status']])) {
        $status_counts[$row['status']] = (int) $row['cnt'];
    }
}

$total_accounts = array_sum($status_counts);

$service_account_count = (int) $pdo->query("
    SELECT COUNT(*)
    FROM uid_gid_accounts
    WHERE account_type = 'Service Account'
")->fetchColumn();


/*
|--------------------------------------------------------------------------
| EXPORT CSV
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export UID/GID records.');
    }

    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_hostname = trim($_GET['s_hostname'] ?? '');
    $s_account_type = trim($_GET['s_account_type'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');

    if (!empty($keyword)) {
        $export_where_clauses[] = "(hostname LIKE ? OR username LIKE ? OR application LIKE ? OR change_request LIKE ?)";
        array_push($export_params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
    }
    if (!empty($s_hostname)) {
        $export_where_clauses[] = "hostname = ?";
        $export_params[] = $s_hostname;
    }
    if (!empty($s_account_type)) {
        $export_where_clauses[] = "account_type = ?";
        $export_params[] = $s_account_type;
    }
    if (!empty($s_status)) {
        $export_where_clauses[] = "status = ?";
        $export_params[] = $s_status;
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=uid_gid_export_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    fputcsv($output, array_merge(array_values($ug_field_labels), ['Last Updated']));

    $cols = array_keys($ug_field_labels);

    $export_stmt = $pdo->prepare("
        SELECT *
        FROM uid_gid_accounts
        WHERE $export_where_sql
        ORDER BY id DESC
    ");

    $export_stmt->execute($export_params);

    while ($row = $export_stmt->fetch(PDO::FETCH_ASSOC)) {

        $line = [];

        foreach ($cols as $c) {
            $line[] = $row[$c] ?? '';
        }

        $line[] = $row['updated_at'] ?? '';

        fputcsv($output, $line);
    }

    fclose($output);
    exit;
}


/*
|--------------------------------------------------------------------------
| AUDIT HISTORY AJAX
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="ug-file-empty">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

    if ($historyId > 0) {

        $h_stmt = $pdo->prepare("
            SELECT *
            FROM uid_gid_history
            WHERE record_id = ?
            ORDER BY timestamp DESC, id DESC
        ");

        $h_stmt->execute([$historyId]);

    } else {

        $h_stmt = $pdo->query("
            SELECT *
            FROM uid_gid_history
            ORDER BY timestamp DESC, id DESC
        ");
    }

    $logs = $h_stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {

        echo '<table class="audit-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead>';
        echo '<tbody>';

        foreach ($logs as $log) {

            $badge_class = '';

            if ($log['action_type'] === 'CREATED') {
                $badge_class = 'action-created';
            } elseif ($log['action_type'] === 'DELETED') {
                $badge_class = 'action-deleted';
            } elseif ($log['action_type'] === 'UPDATED') {
                $badge_class = 'action-updated';
            }

            echo '<tr>';
            echo '<td><span class="audit-badge ' . $badge_class . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by'] ?? '') . '</td>';
            echo '<td class="audit-details">' . nl2br(htmlspecialchars($log['details'] ?? '')) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp'] ?? '') . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

    } else {

        echo '<p class="ug-file-empty">' .
            ($historyId > 0 ? 'No history found for this record.' : 'No audit history records found.') .
            '</p>';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| HANDLE FORM SUBMISSIONS
|--------------------------------------------------------------------------
*/

$success_msg = '';
$error_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    csrfVerifyOrDie();

    $action = $_POST['action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | CREATE
    |--------------------------------------------------------------------------
    */

    if ($action === 'create_account') {

        if (!$canEdit) {

            $error_msg = "You do not have permission to create UID/GID records.";

        } else {

            $target_hostnames = array_values(array_filter(array_map('trim', $_POST['hostnames'] ?? [])));
            $account_username  = trim($_POST['username'] ?? '');
            $uid               = trim($_POST['uid'] ?? '');
            $gid               = trim($_POST['gid'] ?? '');
            $gecos             = trim($_POST['gecos'] ?? '');
            $home_directory    = trim($_POST['home_directory'] ?? '');
            $login_shell       = trim($_POST['login_shell'] ?? '');
            $account_type      = trim($_POST['account_type'] ?? 'Named User');
            $application       = trim($_POST['application'] ?? '');
            $status            = trim($_POST['status'] ?? 'Active');
            $change_request    = trim($_POST['change_request'] ?? '');
            $requested_by      = trim($_POST['requested_by'] ?? '');
            $approved_by       = trim($_POST['approved_by'] ?? '');
            $notes             = trim($_POST['notes'] ?? '');

            if (!in_array($account_type, UG_ACCOUNT_TYPES, true)) {
                $account_type = 'Named User';
            }
            if (!in_array($status, UG_STATUSES, true)) {
                $status = 'Active';
            }

            if (empty($target_hostnames) || $account_username === '') {

                $error_msg = "Please fill in all required fields (at least one Server, Username).";

            } elseif (
                $uid !== '' &&
                ($uidOwner = $pdo->prepare("SELECT DISTINCT username FROM uid_gid_accounts WHERE uid = ? AND username != ? LIMIT 1")) &&
                $uidOwner->execute([(int) $uid, $account_username]) &&
                ($conflictUser = $uidOwner->fetchColumn())
            ) {

                $error_msg = "UID $uid is already assigned to '$conflictUser'. UIDs must be unique across the whole registry -- choose a different UID.";

            } else {

                /*
                |--------------------------------------------------------------------------
                | ONE ACCOUNT, POSSIBLY MANY SERVERS
                |--------------------------------------------------------------------------
                |
                | The same request often needs the same account created on
                | several servers at once. Username is unique per server (a
                | second row for a hostname that already has this username is
                | skipped, not overwritten); UID was already checked above as
                | a whole-registry constraint, above, before any row is
                | written, so a request never partially succeeds because of
                | a UID collision discovered halfway through the host list.
                */

                $created_ids = [];
                $skipped_hosts = [];

                foreach ($target_hostnames as $hostname) {

                    $dup_stmt = $pdo->prepare("SELECT COUNT(*) FROM uid_gid_accounts WHERE hostname = ? AND username = ?");
                    $dup_stmt->execute([$hostname, $account_username]);

                    if ((int) $dup_stmt->fetchColumn() > 0) {
                        $skipped_hosts[] = $hostname;
                        continue;
                    }

                    $stmt = $pdo->prepare("
                        INSERT INTO uid_gid_accounts (
                            hostname, username, uid, gid, gecos, home_directory, login_shell,
                            account_type, application, status, change_request, requested_by,
                            approved_by, notes, created_by, updated_at
                        ) VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP
                        )
                    ");

                    $stmt->execute([
                        $hostname,
                        $account_username,
                        $uid !== '' ? (int) $uid : null,
                        $gid !== '' ? (int) $gid : null,
                        $gecos !== '' ? $gecos : null,
                        $home_directory !== '' ? $home_directory : null,
                        $login_shell !== '' ? $login_shell : null,
                        $account_type,
                        $application !== '' ? $application : null,
                        $status,
                        $change_request !== '' ? $change_request : null,
                        $requested_by !== '' ? $requested_by : null,
                        $approved_by !== '' ? $approved_by : null,
                        $notes !== '' ? $notes : null,
                        $current_user_id,
                    ]);

                    $record_id = (int) $pdo->lastInsertId();
                    $created_ids[] = $record_id;

                    $h_stmt = $pdo->prepare("
                        INSERT INTO uid_gid_history (record_id, action_type, performed_by, details)
                        VALUES (?, 'CREATED', ?, ?)
                    ");

                    $h_stmt->execute([
                        $record_id,
                        $username,
                        "Created account: $account_username@$hostname (UID " . ($uid !== '' ? $uid : '-') . " / GID " . ($gid !== '' ? $gid : '-') . ")",
                    ]);
                }


                /*
                |--------------------------------------------------------------------------
                | OWNERSHIP CONFIRMATION ATTACHMENTS
                |--------------------------------------------------------------------------
                |
                | Uploaded once, linked to every server's record this
                | request just created -- the confirmation document covers
                | the whole request, not one server in isolation.
                */

                if (
                    !empty($created_ids) &&
                    isset($_FILES['attachments']['name']) &&
                    is_array($_FILES['attachments']['name']) &&
                    !empty($_FILES['attachments']['name'][0])
                ) {

                    $upload_dir = 'uploads/uid_gid/';

                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }

                    foreach ($_FILES['attachments']['name'] as $key => $filename) {

                        if (
                            !isset($_FILES['attachments']['error'][$key]) ||
                            $_FILES['attachments']['error'][$key] !== UPLOAD_ERR_OK
                        ) {
                            continue;
                        }

                        $tmp_name = $_FILES['attachments']['tmp_name'][$key];

                        $safe_filename = time() . '_' . preg_replace(
                            "/[^a-zA-Z0-9\._-]/",
                            "_",
                            basename($filename)
                        );

                        $destination = $upload_dir . $safe_filename;

                        if (move_uploaded_file($tmp_name, $destination)) {

                            $att_stmt = $pdo->prepare("
                                INSERT INTO uid_gid_attachments (record_id, filename, filepath)
                                VALUES (?, ?, ?)
                            ");

                            foreach ($created_ids as $created_id) {
                                $att_stmt->execute([$created_id, $filename, $destination]);
                            }
                        }
                    }
                }


                if (empty($created_ids)) {

                    $error_msg = "Username '$account_username' already exists on every selected server -- no records were created.";

                } else {

                    $success_msg = "Created " . count($created_ids) . " UID/GID record(s) across " . count($created_ids) . " server(s).";

                    if (!empty($skipped_hosts)) {
                        $success_msg .= " Skipped " . count($skipped_hosts) . " server(s) where '$account_username' already exists: " . implode(', ', $skipped_hosts) . ".";
                    }
                }
            }
        }


    /*
    |--------------------------------------------------------------------------
    | UPDATE
    |--------------------------------------------------------------------------
    */

    } elseif ($action === 'update_account') {

        $record_id = (int) ($_POST['record_id'] ?? 0);

        if ($record_id <= 0) {

            $error_msg = "Invalid UID/GID record.";

        } elseif (!$canEdit) {

            $error_msg = "You do not have permission to modify UID/GID records.";

        } else {

            $check_stmt = $pdo->prepare("SELECT * FROM uid_gid_accounts WHERE id = ? LIMIT 1");
            $check_stmt->execute([$record_id]);
            $oldRecord = $check_stmt->fetch(PDO::FETCH_ASSOC);

            if (!$oldRecord) {

                $error_msg = "UID/GID record not found.";

            } else {

                $hostname          = trim($_POST['hostname'] ?? '');
                $account_username  = trim($_POST['username'] ?? '');
                $uid               = trim($_POST['uid'] ?? '');
                $gid               = trim($_POST['gid'] ?? '');
                $gecos             = trim($_POST['gecos'] ?? '');
                $home_directory    = trim($_POST['home_directory'] ?? '');
                $login_shell       = trim($_POST['login_shell'] ?? '');
                $account_type      = trim($_POST['account_type'] ?? 'Named User');
                $application       = trim($_POST['application'] ?? '');
                $status            = trim($_POST['status'] ?? 'Active');
                $change_request    = trim($_POST['change_request'] ?? '');
                $requested_by      = trim($_POST['requested_by'] ?? '');
                $approved_by       = trim($_POST['approved_by'] ?? '');
                $notes             = trim($_POST['notes'] ?? '');

                if (!in_array($account_type, UG_ACCOUNT_TYPES, true)) {
                    $account_type = 'Named User';
                }
                if (!in_array($status, UG_STATUSES, true)) {
                    $status = 'Active';
                }

                $dup_stmt = $pdo->prepare("SELECT COUNT(*) FROM uid_gid_accounts WHERE hostname = ? AND username = ? AND id != ?");
                $dup_stmt->execute([$hostname, $account_username, $record_id]);

                $uidOwner = null;
                if ($uid !== '') {
                    $uidOwner_stmt = $pdo->prepare("SELECT DISTINCT username FROM uid_gid_accounts WHERE uid = ? AND username != ? AND id != ? LIMIT 1");
                    $uidOwner_stmt->execute([(int) $uid, $account_username, $record_id]);
                    $uidOwner = $uidOwner_stmt->fetchColumn();
                }

                if ($hostname === '' || $account_username === '') {

                    $error_msg = "Please fill in all required fields.";

                } elseif ((int) $dup_stmt->fetchColumn() > 0) {

                    $error_msg = "Username '$account_username' already exists on $hostname.";

                } elseif ($uidOwner) {

                    $error_msg = "UID $uid is already assigned to '$uidOwner'. UIDs must be unique across the whole registry -- choose a different UID.";

                } else {

                    $update_stmt = $pdo->prepare("
                        UPDATE uid_gid_accounts SET
                            hostname = ?, username = ?, uid = ?, gid = ?, gecos = ?,
                            home_directory = ?, login_shell = ?, account_type = ?,
                            application = ?, status = ?, change_request = ?,
                            requested_by = ?, approved_by = ?, notes = ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ");

                    $update_stmt->execute([
                        $hostname,
                        $account_username,
                        $uid !== '' ? (int) $uid : null,
                        $gid !== '' ? (int) $gid : null,
                        $gecos !== '' ? $gecos : null,
                        $home_directory !== '' ? $home_directory : null,
                        $login_shell !== '' ? $login_shell : null,
                        $account_type,
                        $application !== '' ? $application : null,
                        $status,
                        $change_request !== '' ? $change_request : null,
                        $requested_by !== '' ? $requested_by : null,
                        $approved_by !== '' ? $approved_by : null,
                        $notes !== '' ? $notes : null,
                        $record_id,
                    ]);


                    if (
                        isset($_FILES['attachments']['name']) &&
                        is_array($_FILES['attachments']['name']) &&
                        !empty($_FILES['attachments']['name'][0])
                    ) {

                        $upload_dir = 'uploads/uid_gid/';

                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }

                        foreach ($_FILES['attachments']['name'] as $key => $filename) {

                            if (
                                !isset($_FILES['attachments']['error'][$key]) ||
                                $_FILES['attachments']['error'][$key] !== UPLOAD_ERR_OK
                            ) {
                                continue;
                            }

                            $tmp_name = $_FILES['attachments']['tmp_name'][$key];

                            $safe_filename = time() . '_' . preg_replace(
                                "/[^a-zA-Z0-9\._-]/",
                                "_",
                                basename($filename)
                            );

                            $destination = $upload_dir . $safe_filename;

                            if (move_uploaded_file($tmp_name, $destination)) {

                                $att_stmt = $pdo->prepare("
                                    INSERT INTO uid_gid_attachments (record_id, filename, filepath)
                                    VALUES (?, ?, ?)
                                ");

                                $att_stmt->execute([$record_id, $filename, $destination]);
                            }
                        }
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | FIELD-LEVEL AUDIT DIFF
                    |--------------------------------------------------------------------------
                    */

                    $newValuesByColumn = [
                        'hostname'        => $hostname,
                        'username'        => $account_username,
                        'uid'             => $uid,
                        'gid'             => $gid,
                        'gecos'           => $gecos,
                        'home_directory'  => $home_directory,
                        'login_shell'     => $login_shell,
                        'account_type'    => $account_type,
                        'application'     => $application,
                        'status'          => $status,
                        'change_request'  => $change_request,
                        'requested_by'    => $requested_by,
                        'approved_by'     => $approved_by,
                        'notes'           => $notes,
                    ];

                    $changedFields = [];

                    foreach ($newValuesByColumn as $columnKey => $newVal) {

                        $oldValStr = trim((string) ($oldRecord[$columnKey] ?? ''));
                        $newValStr = trim((string) $newVal);

                        if ($oldValStr !== $newValStr) {

                            $fieldLabel = $ug_field_labels[$columnKey] ?? $columnKey;
                            $oldDisplay = $oldValStr === '' ? '(empty)' : $oldValStr;
                            $newDisplay = $newValStr === '' ? '(empty)' : $newValStr;

                            $changedFields[] = "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                        }
                    }

                    $detail_msg = "Updated account: $account_username@$hostname\n";
                    $detail_msg .= count($changedFields) > 0
                        ? implode("\n", $changedFields)
                        : "No field value changes detected.";

                    $h_stmt = $pdo->prepare("
                        INSERT INTO uid_gid_history (record_id, action_type, performed_by, details)
                        VALUES (?, 'UPDATED', ?, ?)
                    ");

                    $h_stmt->execute([$record_id, $username, $detail_msg]);

                    $success_msg = "UID/GID record successfully updated!";
                }
            }
        }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    } elseif ($action === 'delete_account') {

        $record_id = (int) ($_POST['record_id'] ?? 0);

        $check_stmt = $pdo->prepare("SELECT * FROM uid_gid_accounts WHERE id = ? LIMIT 1");
        $check_stmt->execute([$record_id]);
        $existing = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$existing) {

            $error_msg = "UID/GID record not found.";

        } elseif (!$canDelete) {

            $error_msg = "You do not have permission to delete UID/GID records.";

        } else {

            $att_query = $pdo->prepare("SELECT filepath FROM uid_gid_attachments WHERE record_id = ?");
            $att_query->execute([$record_id]);

            foreach ($att_query->fetchAll(PDO::FETCH_ASSOC) as $att) {
                if (!empty($att['filepath']) && file_exists($att['filepath'])) {
                    unlink($att['filepath']);
                }
            }

            $del_stmt = $pdo->prepare("DELETE FROM uid_gid_accounts WHERE id = ?");
            $del_stmt->execute([$record_id]);

            $h_stmt = $pdo->prepare("
                INSERT INTO uid_gid_history (record_id, action_type, performed_by, details)
                VALUES (?, 'DELETED', ?, ?)
            ");

            $h_stmt->execute([
                $record_id,
                $username,
                "Deleted account: " . ($existing['username'] ?? 'Unknown') . "@" . ($existing['hostname'] ?? 'Unknown'),
            ]);

            $success_msg = "UID/GID record successfully deleted.";
        }
    }
}


/*
|--------------------------------------------------------------------------
| NEXT-AVAILABLE UID/GID SUGGESTIONS
|--------------------------------------------------------------------------
*/

$next_uid_suggestion = ug_next_available($pdo, 'uid');
$next_gid_suggestion = ug_next_available($pdo, 'gid');


/*
|--------------------------------------------------------------------------
| PAGINATION & SEARCH
|--------------------------------------------------------------------------
*/

$limit = 15;

$page = isset($_GET['page']) ? max(1, (int) $_GET['page']) : 1;
$start = ($page - 1) * $limit;

$keyword        = trim($_GET['keyword'] ?? '');
$s_hostname     = trim($_GET['s_hostname'] ?? '');
$s_account_type = trim($_GET['s_account_type'] ?? '');
$s_status       = trim($_GET['s_status'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(hostname LIKE ? OR username LIKE ? OR application LIKE ? OR change_request LIKE ? OR gecos LIKE ?)";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_hostname)) {
    $where_clauses[] = "hostname = ?";
    $params[] = $s_hostname;
}
if (!empty($s_account_type)) {
    $where_clauses[] = "account_type = ?";
    $params[] = $s_account_type;
}
if (!empty($s_status)) {
    $where_clauses[] = "status = ?";
    $params[] = $s_status;
}

$where_sql = implode(" AND ", $where_clauses);

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM uid_gid_accounts WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int) ceil($total_records / $limit));

if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

$sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

$valid_sort_columns = ['id', 'hostname', 'username', 'uid', 'gid', 'account_type', 'status', 'application', 'change_request', 'updated_at'];
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'id';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'DESC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

$data_stmt = $pdo->prepare("
    SELECT *
    FROM uid_gid_accounts
    WHERE $where_sql
    ORDER BY `$sort_by` $sort_dir
    LIMIT $limit OFFSET $start
");

$data_stmt->execute($params);
$accounts = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_hostname' => $s_hostname,
    's_account_type' => $s_account_type,
    's_status' => $s_status,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
] as $hfk => $hfv) {
    if ($hfv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($hfk) . '" value="' . htmlspecialchars($hfv) . '">';
    }
}

$page_title = "UID/GID Tracking - InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/uid-gid-tracking.css">

<div class="content">

    <div class="ug-hero">

        <div class="ug-hero-main">
            <div class="ug-hero-icon">🐧</div>
            <div>
                <h1>UID/GID Tracking</h1>
                <p>
                    Track RHEL user accounts across the estate: UID/GID, GECOS,
                    owning application, and the change request that authorized creation.
                </p>
            </div>
        </div>

        <div class="dashboard-actions">

            <?php if ($canEdit): ?>
                <button type="button" class="ug-btn ug-btn-primary" onclick="openCreateModal()">
                    + Add Account
                </button>
            <?php endif; ?>

            <?php if ($canExport): ?>
                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_hostname !== '') $export_params['s_hostname'] = $s_hostname;
                if ($s_account_type !== '') $export_params['s_account_type'] = $s_account_type;
                if ($s_status !== '') $export_params['s_status'] = $s_status;
                $export_url = 'uid-gid-tracking.php?' . http_build_query($export_params);
                ?>
                <a href="<?= htmlspecialchars($export_url) ?>" class="ug-btn ug-btn-primary" style="background:#4F46E5;">
                    Export CSV
                </a>
            <?php endif; ?>

            <?php if ($canAudit): ?>
                <button type="button" class="ug-btn ug-btn-primary" style="background:#F97316;" onclick="openGlobalHistoryModal()">
                    ⏱ History
                </button>
            <?php endif; ?>

        </div>

    </div>


    <div class="ug-stats-grid">

        <div class="ug-stat-card st-total">
            <div class="ug-stat-icon">📦</div>
            <div>
                <div class="ug-stat-value"><?= (int) $total_accounts ?></div>
                <div class="ug-stat-label">Total Accounts</div>
            </div>
        </div>

        <div class="ug-stat-card st-active">
            <div class="ug-stat-icon">✅</div>
            <div>
                <div class="ug-stat-value"><?= (int) $status_counts['Active'] ?></div>
                <div class="ug-stat-label">Active</div>
            </div>
        </div>

        <div class="ug-stat-card st-service">
            <div class="ug-stat-icon">⚙️</div>
            <div>
                <div class="ug-stat-value"><?= (int) $service_account_count ?></div>
                <div class="ug-stat-label">Service Accounts</div>
            </div>
        </div>

        <div class="ug-stat-card st-disabled">
            <div class="ug-stat-icon">⛔</div>
            <div>
                <div class="ug-stat-value"><?= (int) ($status_counts['Disabled'] + $status_counts['Decommissioned']) ?></div>
                <div class="ug-stat-label">Disabled / Decommissioned</div>
            </div>
        </div>

    </div>


    <?php if ($success_msg): ?>
        <div class="ug-alert success"><?= htmlspecialchars($success_msg) ?></div>
    <?php endif; ?>

    <?php if ($error_msg): ?>
        <div class="ug-alert error"><?= htmlspecialchars($error_msg) ?></div>
    <?php endif; ?>


    <!-- Search Panel -->
    <div class="panel">
        <div style="padding:20px 22px;">
            <div class="ug-toolbar-head">
                <h3 class="panel-title">Search &amp; Filters</h3>
                <button type="button" class="ug-toolbar-link" onclick="toggleAdvancedSearch()">
                    More Filters &#9662;
                </button>
            </div>

            <div class="ug-toolbar-row">
            <form method="GET" action="uid-gid-tracking.php" class="ug-search-row">
                <div class="ug-search-input-wrap">
                    <span class="ug-search-icon">🔍</span>
                    <input
                        type="text"
                        name="keyword"
                        class="form-control"
                        placeholder="Search hostname, username, application, CR#..."
                        value="<?= htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8') ?>"
                    >
                </div>

                <div class="ug-status-chips">
                    <?php
                    $chip_statuses = ['' => 'All', 'Active' => 'Active', 'Disabled' => 'Disabled', 'Decommissioned' => 'Decommissioned'];
                    foreach ($chip_statuses as $chip_value => $chip_label):
                        $chip_params = ['s_status' => $chip_value];
                        if ($keyword !== '') $chip_params['keyword'] = $keyword;
                        $chip_url = 'uid-gid-tracking.php?' . http_build_query($chip_params);
                    ?>
                        <a href="<?= htmlspecialchars($chip_url) ?>" class="ug-chip <?= $s_status === $chip_value ? 'active' : '' ?>">
                            <?= htmlspecialchars($chip_label) ?>
                        </a>
                    <?php endforeach; ?>
                </div>

                <button type="submit" class="btn btn-primary">Search</button>
                <?php if ($keyword !== '' || $s_hostname !== '' || $s_account_type !== '' || $s_status !== ''): ?>
                    <a href="uid-gid-tracking.php" class="btn">Clear</a>
                <?php endif; ?>
            </form>

            </div>

            <div id="advancedSearchPanel" class="ug-advanced-panel" style="display:<?= ($s_hostname !== '' || $s_account_type !== '') ? 'block' : 'none' ?>;">
                <form method="GET" action="uid-gid-tracking.php" class="ug-advanced-grid">

                    <div class="form-group">
                        <label>Hostname</label>
                        <select name="s_hostname" class="form-control">
                            <option value="">All Hostnames</option>
                            <?php foreach ($hostnames as $h): ?>
                                <option value="<?= htmlspecialchars($h) ?>" <?= $s_hostname === $h ? 'selected' : '' ?>><?= htmlspecialchars($h) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label>Account Type</label>
                        <select name="s_account_type" class="form-control">
                            <option value="">All Types</option>
                            <?php foreach (UG_ACCOUNT_TYPES as $t): ?>
                                <option value="<?= htmlspecialchars($t) ?>" <?= $s_account_type === $t ? 'selected' : '' ?>><?= htmlspecialchars($t) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="ug-advanced-actions">
                        <button type="submit" class="btn btn-primary" style="flex:1;min-width:120px;">🔍 Apply Filters</button>
                        <a href="uid-gid-tracking.php" class="btn" style="flex:1;min-width:120px;text-align:center;">↺ Reset</a>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <!-- Records -->
    <div class="panel" style="padding:0;">

        <div class="panel-header">
            <span class="panel-title">UID/GID Accounts</span>
            <span style="color:var(--text-muted);font-size:13px;"><?= (int) $total_records ?> total</span>
        </div>

        <div class="ug-table-wrap">
            <table class="ug-table">
                <thead>
                    <tr>
                        <?php
                        $sortLink = function ($col, $label) use ($next_sort_dir, $sort_by, $sort_dir, $keyword, $s_hostname, $s_account_type, $s_status) {
                            $url = 'uid-gid-tracking.php?sort_by=' . $col . '&sort_dir=' . $next_sort_dir . '&page=1'
                                . '&keyword=' . urlencode($keyword)
                                . '&s_hostname=' . urlencode($s_hostname)
                                . '&s_account_type=' . urlencode($s_account_type)
                                . '&s_status=' . urlencode($s_status);
                            $arrow = $sort_by === $col ? '<span style="color:var(--accent);">' . ($sort_dir === 'ASC' ? '↑' : '↓') . '</span>' : '';
                            return '<a href="' . htmlspecialchars($url) . '">' . htmlspecialchars($label) . ' ' . $arrow . '</a>';
                        };
                        ?>
                        <th><?= $sortLink('hostname', 'Hostname') ?></th>
                        <th><?= $sortLink('username', 'Account') ?></th>
                        <th>Application</th>
                        <th><?= $sortLink('account_type', 'Type') ?></th>
                        <th><?= $sortLink('status', 'Status') ?></th>
                        <th>Change Request</th>
                        <th><?= $sortLink('updated_at', 'Last Updated') ?></th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (empty($accounts)): ?>
                        <tr>
                            <td colspan="8">
                                <div class="ug-empty-state">
                                    <div class="ug-empty-icon">🐧</div>
                                    <div class="ug-empty-title">No UID/GID records found</div>
                                    <div class="ug-empty-sub">
                                        <?= ($keyword !== '' || $s_hostname !== '' || $s_account_type !== '' || $s_status !== '')
                                            ? 'No records match your current search or filters. Try clearing them.'
                                            : 'Start tracking RHEL account UID/GID assignments by adding your first record.' ?>
                                    </div>
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="ug-btn ug-btn-primary" onclick="openCreateModal()">+ Add Account</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                    <?php else: ?>

                        <?php foreach ($accounts as $a):

                            $att_query = $pdo->prepare("SELECT * FROM uid_gid_attachments WHERE record_id = ?");
                            $att_query->execute([$a['id']]);
                            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);

                            $status_class = 'st-active';
                            if ($a['status'] === 'Disabled') $status_class = 'st-disabled';
                            if ($a['status'] === 'Decommissioned') $status_class = 'st-decommissioned';

                            $type_class = $a['account_type'] === 'Service Account' ? 'service' : '';
                        ?>
                            <tr>
                                <td>
                                    <span class="ug-host-chip"><?= htmlspecialchars($a['hostname']) ?></span>
                                </td>

                                <td>
                                    <div class="ug-cell-primary"><?= htmlspecialchars($a['username']) ?></div>
                                    <div class="ug-cell-sub">UID <?= htmlspecialchars((string)($a['uid'] ?? '-')) ?> · GID <?= htmlspecialchars((string)($a['gid'] ?? '-')) ?></div>
                                </td>

                                <td><?= htmlspecialchars($a['application'] ?: '-') ?></td>

                                <td><span class="ug-type-pill <?= $type_class ?>"><?= htmlspecialchars($a['account_type']) ?></span></td>

                                <td><span class="ug-badge <?= $status_class ?>"><?= htmlspecialchars($a['status']) ?></span></td>

                                <td><?= htmlspecialchars($a['change_request'] ?: '-') ?></td>

                                <td><?= htmlspecialchars($a['updated_at'] ?? '') ?></td>

                                <td style="text-align:center;white-space:nowrap;">
                                    <div class="row-actions">
                                        <button type="button" class="btn btn-sm btn-secondary btn-icon" title="View" aria-label="View" onclick='openViewModal(<?= json_encode($a) ?>, <?= json_encode($attachments) ?>)'>👁</button>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="btn btn-sm btn-primary btn-icon" title="Edit" aria-label="Edit" onclick='openEditModal(<?= json_encode($a) ?>)'>✎</button>
                                        <?php endif; ?>
                                        <?php if ($canDelete): ?>
                                            <button type="button" class="btn btn-sm btn-danger btn-icon" title="Delete" aria-label="Delete" onclick="openDeleteModal(<?= (int)$a['id'] ?>, '<?= htmlspecialchars(addslashes($a['username'] . '@' . $a['hostname'])) ?>')">🗑</button>
                                        <?php endif; ?>
                                        <?php if ($canAudit): ?>
                                            <button type="button" class="btn btn-sm btn-warning btn-icon" title="Audit History" aria-label="Audit History" onclick="openRowHistoryModal(<?= (int)$a['id'] ?>, '<?= htmlspecialchars($a['username']) ?>')">⏱</button>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?php if ($total_pages > 1): ?>
            <?php
            $page_link = function ($p) use ($keyword, $s_hostname, $s_account_type, $s_status, $sort_by, $sort_dir) {
                return 'uid-gid-tracking.php?page=' . $p . '&keyword=' . urlencode($keyword) . '&s_hostname=' . urlencode($s_hostname) . '&s_account_type=' . urlencode($s_account_type) . '&s_status=' . urlencode($s_status) . '&sort_by=' . urlencode($sort_by) . '&sort_dir=' . urlencode($sort_dir);
            };
            ?>
            <?= ivPager($page, $total_pages, [], [
                'base'          => 'uid-gid-tracking.php',
                'link'          => $page_link,
                'total_records' => $total_records ?? null,
                'per_page'      => $limit ?? null,
            ]) ?>
        <?php endif; ?>
    </div>

</div>


<!-- =========================================================
     DELETE CONFIRMATION MODAL
========================================================= -->

<div id="deleteModal" class="ug-modal">
    <div class="ug-modal-content">
        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 class="ug-modal-title">🗑 Confirm Deletion</h2>
                <div class="ug-modal-head-sub">This action cannot be undone.</div>
            </div>
            <button class="ug-modal-close" onclick="closeDeleteModal()">&times;</button>
        </div>

        <form method="POST">
            <div class="ug-modal-body">
                <p>Are you sure you want to delete the account <strong id="del_account_name"></strong>?</p>
            </div>
            <div class="ug-modal-footer">
                <?= csrfField() ?>
                <input type="hidden" name="action" value="delete_account">
                <input type="hidden" name="record_id" id="del_record_id">
                <button type="button" class="ug-btn ug-btn-ghost" onclick="closeDeleteModal()">Cancel</button>
                <button type="submit" class="ug-btn ug-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>


<!-- =========================================================
     CREATE MODAL
========================================================= -->

<?php if ($canEdit): ?>

<div id="createModal" class="ug-modal">
    <div class="ug-modal-content ug-modal-wide">

        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 class="ug-modal-title">Add UID/GID Record</h2>
                <div class="ug-modal-head-sub">Register a RHEL account, its POSIX identity, and change control evidence.</div>
            </div>
            <button type="button" class="ug-modal-close" onclick="closeCreateModal()">&times;</button>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="create_account">

            <div class="ug-modal-body">

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">🖥 Server(s) &amp; Account</div>
                    <div class="ug-field" style="margin-bottom:18px;">
                        <label>
                            Servers <span class="req">*</span>
                            <span style="color:var(--text-muted);font-weight:500;text-transform:none;letter-spacing:0;">
                                &nbsp;-- search and pick every server this account should exist on
                            </span>
                        </label>
                        <div class="ug-host-picker" id="hostPicker">
                            <div class="ug-host-chips" id="hostChips"></div>
                            <input
                                type="text"
                                class="ug-host-search"
                                id="hostSearchInput"
                                placeholder="Type to search hostnames..."
                                autocomplete="off"
                            >
                            <div class="ug-host-list" id="hostList">
                                <?php foreach ($hostnames as $h): ?>
                                    <label class="ug-host-option">
                                        <input type="checkbox" name="hostnames[]" value="<?= htmlspecialchars($h) ?>" class="ug-host-checkbox">
                                        <span><?= htmlspecialchars($h) ?></span>
                                    </label>
                                <?php endforeach; ?>
                                <div class="ug-host-no-match" id="hostNoMatch" style="display:none;">No servers match your search.</div>
                            </div>
                        </div>
                    </div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>Username <span class="req">*</span></label>
                            <input type="text" name="username" class="mono" placeholder="e.g. appuser01" required>
                        </div>
                        <div class="ug-field">
                            <label>Account Type</label>
                            <select name="account_type">
                                <?php foreach (UG_ACCOUNT_TYPES as $t): ?>
                                    <option value="<?= htmlspecialchars($t) ?>"><?= htmlspecialchars($t) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">🔢 POSIX Attributes</div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>
                                UID
                                <span style="color:var(--text-muted);font-weight:500;text-transform:none;letter-spacing:0;">(suggested: <?= (int) $next_uid_suggestion ?>)</span>
                            </label>
                            <input type="number" name="uid" value="<?= (int) $next_uid_suggestion ?>">
                        </div>
                        <div class="ug-field">
                            <label>
                                GID
                                <span style="color:var(--text-muted);font-weight:500;text-transform:none;letter-spacing:0;">(suggested: <?= (int) $next_gid_suggestion ?>)</span>
                            </label>
                            <input type="number" name="gid" value="<?= (int) $next_gid_suggestion ?>">
                        </div>
                        <div class="ug-field">
                            <label>Login Shell</label>
                            <input type="text" name="login_shell" class="mono" list="shellOptions" placeholder="/bin/bash">
                            <datalist id="shellOptions">
                                <option value="/bin/bash">
                                <option value="/bin/sh">
                                <option value="/sbin/nologin">
                                <option value="/usr/sbin/nologin">
                                <option value="/bin/csh">
                            </datalist>
                        </div>
                    </div>
                    <div class="ug-form-grid cols-2">
                        <div class="ug-field">
                            <label>GECOS</label>
                            <input type="text" name="gecos" placeholder="Full name / description field">
                        </div>
                        <div class="ug-field">
                            <label>Home Directory</label>
                            <input type="text" name="home_directory" class="mono" placeholder="/home/appuser01">
                        </div>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">📋 Ownership &amp; Application</div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>Application</label>
                            <input type="text" name="application" list="applicationOptions" placeholder="Owning application">
                            <datalist id="applicationOptions">
                                <?php foreach ($applications as $app): ?>
                                    <option value="<?= htmlspecialchars($app) ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                        <div class="ug-field">
                            <label>Status</label>
                            <select name="status">
                                <?php foreach (UG_STATUSES as $st): ?>
                                    <option value="<?= htmlspecialchars($st) ?>"><?= htmlspecialchars($st) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="ug-field">
                            <label>Change Request</label>
                            <input type="text" name="change_request" placeholder="e.g. CR-2026-00456">
                        </div>
                    </div>
                    <div class="ug-form-grid cols-2">
                        <div class="ug-field">
                            <label>Requested By</label>
                            <input type="text" name="requested_by" placeholder="Name of requester">
                        </div>
                        <div class="ug-field">
                            <label>Ownership Confirmed By</label>
                            <input type="text" name="approved_by" placeholder="Name of approver">
                        </div>
                    </div>
                    <div class="ug-field" style="margin-bottom:0;">
                        <label>Notes</label>
                        <textarea name="notes" rows="2" placeholder="Additional context"></textarea>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">📎 Ownership Confirmation Attachment</div>
                    <div class="ug-field">
                        <label>Attach Docs (approval email, signed CR, etc.)</label>
                        <div class="ug-file-drop">
                            📄
                            <input type="file" name="attachments[]" multiple>
                        </div>
                    </div>
                </div>

            </div>

            <div class="ug-modal-footer">
                <button type="button" class="ug-btn ug-btn-ghost" onclick="closeCreateModal()">Cancel</button>
                <button type="submit" class="ug-btn ug-btn-primary">Create Record</button>
            </div>
        </form>

    </div>
</div>

<?php endif; ?>


<!-- =========================================================
     VIEW MODAL
========================================================= -->

<div id="viewModal" class="ug-modal">
    <div class="ug-modal-content">
        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 id="viewModalTitle" class="ug-modal-title">Account Details</h2>
            </div>
            <button class="ug-modal-close" onclick="closeViewModal()">&times;</button>
        </div>

        <div class="ug-modal-body">
            <div id="viewModalContentContainer"></div>
            <div class="ug-subheading">📎 Ownership Confirmation Documents</div>
            <div id="viewAttachmentsListContainer"></div>
        </div>
    </div>
</div>


<!-- =========================================================
     EDIT MODAL
========================================================= -->

<?php if ($canEdit): ?>

<div id="editModal" class="ug-modal">
    <div class="ug-modal-content ug-modal-wide">

        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 class="ug-modal-title">Edit UID/GID Record</h2>
                <div class="ug-modal-head-sub">Update account identity or change-control details.</div>
            </div>
            <button class="ug-modal-close" onclick="closeEditModal()">&times;</button>
        </div>

        <form method="POST" enctype="multipart/form-data">
            <?= csrfField() ?>
            <input type="hidden" name="action" value="update_account">
            <input type="hidden" name="record_id" id="edit_record_id">

            <div class="ug-modal-body">

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">🖥 Server &amp; Account</div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>Hostname <span class="req">*</span></label>
                            <select name="hostname" id="edit_hostname" required>
                                <option value="">-- Select Server --</option>
                                <?php foreach ($hostnames as $h): ?>
                                    <option value="<?= htmlspecialchars($h) ?>"><?= htmlspecialchars($h) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="ug-field">
                            <label>Username <span class="req">*</span></label>
                            <input type="text" name="username" id="edit_username" class="mono" required>
                        </div>
                        <div class="ug-field">
                            <label>Account Type</label>
                            <select name="account_type" id="edit_account_type">
                                <?php foreach (UG_ACCOUNT_TYPES as $t): ?>
                                    <option value="<?= htmlspecialchars($t) ?>"><?= htmlspecialchars($t) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">🔢 POSIX Attributes</div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>UID</label>
                            <input type="number" name="uid" id="edit_uid">
                        </div>
                        <div class="ug-field">
                            <label>GID</label>
                            <input type="number" name="gid" id="edit_gid">
                        </div>
                        <div class="ug-field">
                            <label>Login Shell</label>
                            <input type="text" name="login_shell" id="edit_login_shell" class="mono" list="shellOptionsEdit">
                            <datalist id="shellOptionsEdit">
                                <option value="/bin/bash">
                                <option value="/bin/sh">
                                <option value="/sbin/nologin">
                                <option value="/usr/sbin/nologin">
                                <option value="/bin/csh">
                            </datalist>
                        </div>
                    </div>
                    <div class="ug-form-grid cols-2">
                        <div class="ug-field">
                            <label>GECOS</label>
                            <input type="text" name="gecos" id="edit_gecos">
                        </div>
                        <div class="ug-field">
                            <label>Home Directory</label>
                            <input type="text" name="home_directory" id="edit_home_directory" class="mono">
                        </div>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">📋 Ownership &amp; Application</div>
                    <div class="ug-form-grid">
                        <div class="ug-field">
                            <label>Application</label>
                            <input type="text" name="application" id="edit_application" list="applicationOptionsEdit">
                            <datalist id="applicationOptionsEdit">
                                <?php foreach ($applications as $app): ?>
                                    <option value="<?= htmlspecialchars($app) ?>">
                                <?php endforeach; ?>
                            </datalist>
                        </div>
                        <div class="ug-field">
                            <label>Status</label>
                            <select name="status" id="edit_status">
                                <?php foreach (UG_STATUSES as $st): ?>
                                    <option value="<?= htmlspecialchars($st) ?>"><?= htmlspecialchars($st) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="ug-field">
                            <label>Change Request</label>
                            <input type="text" name="change_request" id="edit_change_request">
                        </div>
                    </div>
                    <div class="ug-form-grid cols-2">
                        <div class="ug-field">
                            <label>Requested By</label>
                            <input type="text" name="requested_by" id="edit_requested_by">
                        </div>
                        <div class="ug-field">
                            <label>Ownership Confirmed By</label>
                            <input type="text" name="approved_by" id="edit_approved_by">
                        </div>
                    </div>
                    <div class="ug-field" style="margin-bottom:0;">
                        <label>Notes</label>
                        <textarea name="notes" id="edit_notes" rows="2"></textarea>
                    </div>
                </div>

                <div class="ug-modal-section">
                    <div class="ug-modal-section-title">📎 Ownership Confirmation Attachment</div>
                    <div class="ug-field">
                        <label>Attach More Docs</label>
                        <div class="ug-file-drop">
                            📄
                            <input type="file" name="attachments[]" multiple>
                        </div>
                    </div>
                </div>

            </div>

            <div class="ug-modal-footer">
                <button type="button" class="ug-btn ug-btn-ghost" onclick="closeEditModal()">Cancel</button>
                <button type="submit" class="ug-btn ug-btn-primary">Update Record</button>
            </div>
        </form>

    </div>
</div>

<?php endif; ?>


<!-- =========================================================
     GLOBAL HISTORY MODAL
========================================================= -->

<div id="globalHistoryModal" class="ug-modal">
    <div class="ug-modal-content ug-modal-wide">
        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 class="ug-modal-title">⏱ Audit History</h2>
                <div class="ug-modal-head-sub">Every create, update, and delete across all UID/GID records.</div>
            </div>
            <button class="ug-modal-close" onclick="closeGlobalHistoryModal()">&times;</button>
        </div>
        <div id="globalHistoryContent" class="ug-modal-body">
            <p class="ug-file-empty">Loading audit trails...</p>
        </div>
    </div>
</div>


<!-- =========================================================
     ROW HISTORY MODAL
========================================================= -->

<div id="historyModal" class="ug-modal">
    <div class="ug-modal-content ug-modal-wide">
        <div class="ug-modal-head">
            <div class="ug-modal-head-text">
                <h2 id="historyModalTitle" class="ug-modal-title">Audit History</h2>
            </div>
            <button class="ug-modal-close" onclick="closeHistoryModal()">&times;</button>
        </div>
        <div id="historyModalContent" class="ug-modal-body">
            <p class="ug-file-empty">Loading audit history...</p>
        </div>
    </div>
</div>


<script>

    const ugFieldLabels = <?= json_encode($ug_field_labels) ?>;

    /* Create Modal */
    function openCreateModal() { document.getElementById('createModal').style.display = 'block'; }
    function closeCreateModal() { document.getElementById('createModal').style.display = 'none'; }

    /* View Modal */
    function openViewModal(a, attachments) {

        document.getElementById('viewModalTitle').innerText = 'Account: ' + (a.username || '') + '@' + (a.hostname || '');

        const groups = [
            { title: '🖥 Server &amp; Account', keys: ['hostname', 'username', 'account_type'] },
            { title: '🔢 POSIX Attributes', keys: ['uid', 'gid', 'gecos', 'home_directory', 'login_shell'] },
            { title: '📋 Ownership &amp; Application', keys: ['application', 'status', 'change_request', 'requested_by', 'approved_by', 'notes'] },
        ];

        let html = '';
        groups.forEach(group => {
            let rows = '';
            group.keys.forEach(key => {
                const label = ugFieldLabels[key] || key;
                const value = a[key];
                rows += `<div class="ug-detail-row">
                    <div class="ug-detail-label">${label}</div>
                    <div class="ug-detail-value">${value !== null && value !== undefined && value !== '' ? value : '-'}</div>
                </div>`;
            });
            html += `<div class="ug-modal-section">
                <div class="ug-modal-section-title">${group.title}</div>
                ${rows}
            </div>`;
        });

        document.getElementById('viewModalContentContainer').innerHTML = html;

        const attContainer = document.getElementById('viewAttachmentsListContainer');
        attContainer.innerHTML = '';

        if (!attachments || attachments.length === 0) {
            attContainer.innerHTML = '<p class="ug-file-empty">No ownership confirmation documents attached.</p>';
        } else {
            let listHtml = '';
            attachments.forEach(att => {
                listHtml += `<a href="${att.filepath}" class="ug-file-chip" target="_blank">📄 ${att.filename}</a>`;
            });
            attContainer.innerHTML = listHtml;
        }

        document.getElementById('viewModal').style.display = 'block';
    }
    function closeViewModal() { document.getElementById('viewModal').style.display = 'none'; }

    /* Edit Modal */
    function openEditModal(a) {
        document.getElementById('edit_record_id').value = a.id;
        document.getElementById('edit_hostname').value = a.hostname || '';
        document.getElementById('edit_username').value = a.username || '';
        document.getElementById('edit_account_type').value = a.account_type || 'Named User';
        document.getElementById('edit_uid').value = a.uid || '';
        document.getElementById('edit_gid').value = a.gid || '';
        document.getElementById('edit_login_shell').value = a.login_shell || '';
        document.getElementById('edit_gecos').value = a.gecos || '';
        document.getElementById('edit_home_directory').value = a.home_directory || '';
        document.getElementById('edit_application').value = a.application || '';
        document.getElementById('edit_status').value = a.status || 'Active';
        document.getElementById('edit_change_request').value = a.change_request || '';
        document.getElementById('edit_requested_by').value = a.requested_by || '';
        document.getElementById('edit_approved_by').value = a.approved_by || '';
        document.getElementById('edit_notes').value = a.notes || '';
        document.getElementById('editModal').style.display = 'block';
    }
    function closeEditModal() { document.getElementById('editModal').style.display = 'none'; }

    /* Delete Modal */
    function openDeleteModal(recordId, accountName) {
        document.getElementById('del_record_id').value = recordId;
        document.getElementById('del_account_name').innerText = accountName;
        document.getElementById('deleteModal').style.display = 'block';
    }
    function closeDeleteModal() { document.getElementById('deleteModal').style.display = 'none'; }

    /* Global History */
    function openGlobalHistoryModal() {
        document.getElementById('globalHistoryModal').style.display = 'block';
        document.getElementById('globalHistoryContent').innerHTML = '<p class="ug-file-empty">Loading audit trails...</p>';
        fetch('uid-gid-tracking.php?action=get_history')
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="ug-file-empty" style="color:#DC2626;">Failed to load audit history.</p>'; });
    }
    function closeGlobalHistoryModal() { document.getElementById('globalHistoryModal').style.display = 'none'; }

    /* Row History */
    function openRowHistoryModal(recordId, accountName) {
        document.getElementById('historyModal').style.display = 'block';
        document.getElementById('historyModalTitle').innerText = 'Record Audit History (' + accountName + ')';
        document.getElementById('historyModalContent').innerHTML = '<p class="ug-file-empty">Loading audit history...</p>';
        fetch(`uid-gid-tracking.php?action=get_history&id=${recordId}`)
            .then(res => res.text())
            .then(html => { document.getElementById('historyModalContent').innerHTML = html; })
            .catch(() => { document.getElementById('historyModalContent').innerHTML = '<p class="ug-file-empty" style="color:#DC2626;">Failed to load audit history.</p>'; });
    }
    function closeHistoryModal() { document.getElementById('historyModal').style.display = 'none'; }

    /* Advanced Search Toggle */
    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        panel.style.display = (panel.style.display === 'none') ? 'block' : 'none';
    }

    /* Close modals on outside click */
    window.addEventListener('click', function (event) {
        ['createModal', 'editModal', 'viewModal', 'historyModal', 'deleteModal', 'globalHistoryModal'].forEach(id => {
            const modal = document.getElementById(id);
            if (modal && event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });

    /*
    |--------------------------------------------------------------------------
    | SEARCHABLE HOST PICKER (Create modal)
    |--------------------------------------------------------------------------
    */

    (function () {
        const picker = document.getElementById('hostPicker');
        if (!picker) {
            return;
        }

        const searchInput = document.getElementById('hostSearchInput');
        const list = document.getElementById('hostList');
        const chips = document.getElementById('hostChips');
        const noMatch = document.getElementById('hostNoMatch');
        const checkboxes = Array.from(list.querySelectorAll('.ug-host-checkbox'));

        function renderChips() {
            chips.innerHTML = '';

            const selected = checkboxes.filter(cb => cb.checked);

            selected.forEach(cb => {
                const chip = document.createElement('span');
                chip.className = 'ug-host-chip-selected';

                const label = document.createElement('span');
                label.textContent = cb.value;

                const removeBtn = document.createElement('button');
                removeBtn.type = 'button';
                removeBtn.innerHTML = '&times;';
                removeBtn.setAttribute('aria-label', 'Remove ' + cb.value);
                removeBtn.addEventListener('click', function () {
                    cb.checked = false;
                    renderChips();
                });

                chip.appendChild(label);
                chip.appendChild(removeBtn);
                chips.appendChild(chip);
            });

            chips.style.display = selected.length ? 'flex' : 'none';
        }

        function filterList() {
            const term = searchInput.value.trim().toLowerCase();
            let visibleCount = 0;

            checkboxes.forEach(cb => {
                const option = cb.closest('.ug-host-option');
                const matches = term === '' || cb.value.toLowerCase().includes(term);
                option.style.display = matches ? 'flex' : 'none';
                if (matches) {
                    visibleCount++;
                }
            });

            noMatch.style.display = visibleCount === 0 ? 'block' : 'none';
        }

        function openList() {
            list.classList.add('open');
        }

        function closeList() {
            list.classList.remove('open');
        }

        checkboxes.forEach(cb => cb.addEventListener('change', renderChips));

        searchInput.addEventListener('input', filterList);
        searchInput.addEventListener('focus', openList);

        document.addEventListener('click', function (event) {
            if (!picker.contains(event.target)) {
                closeList();
            }
        });

        renderChips();
    })();

    /* Require at least one server selected before the Create form submits */
    document.querySelector('#createModal form').addEventListener('submit', function (event) {
        const anyChecked = document.querySelectorAll('#hostList .ug-host-checkbox:checked').length > 0;
        if (!anyChecked) {
            event.preventDefault();
            alert('Select at least one server.');
        }
    });

</script>

<?php include 'includes/footer.php'; ?>
