<?php
/**
 * Special Projects -- infrastructure programmes tracked to completion.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('special_projects', 'can_view');

$canEdit   = can('special_projects', 'can_edit');
$canDelete = can('special_projects', 'can_delete');
$canExport = can('special_projects', 'can_export');
$canAudit  = can('special_projects', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const SP_MODULE = 'special_projects';

$categories = [
    'OS Major Upgrade',
    'Database Upgrade',
    'Container Platform Upgrade',
    'Security Hardening',
    'LDAP / LDAPS Conversion',
    'Certificate Renewal',
    'Migration',
    'Decommissioning',
    'Network Change',
    'Storage Refresh',
    'Backup / DR',
    'Compliance Remediation',
    'Other',
];

$statuses    = ['Planning', 'Approved', 'In Progress', 'On Hold', 'Testing', 'Completed', 'Cancelled'];
$priorities  = ['Critical', 'High', 'Medium', 'Low'];
$healths     = ['On Track', 'At Risk', 'Off Track'];
$msStatuses  = ['Pending', 'In Progress', 'Completed', 'Blocked', 'Skipped'];
$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development', 'All'];

$spFields = [
    'project_name'      => 'Project Name',
    'project_code'      => 'Project Code',
    'category'          => 'Category',
    'description'       => 'Description',
    'objective'         => 'Objective',
    'status'            => 'Status',
    'priority'          => 'Priority',
    'health'            => 'Health',
    'start_date'        => 'Start Date',
    'target_date'       => 'Target Date',
    'completed_date'    => 'Completed Date',
    'total_systems'     => 'Total Systems',
    'completed_systems' => 'Completed Systems',
    'systems'           => 'Systems In Scope',
    'progress_percent'  => 'Progress %',
    'environment'       => 'Environment',
    'affected_projects' => 'Affected Projects',
    'technology'        => 'Technology',
    'project_lead'      => 'Project Lead',
    'lead_email'        => 'Lead Email',
    'team'              => 'Team',
    'sponsor'           => 'Sponsor',
    'change_reference'  => 'Change Reference',
    'risks'             => 'Risks',
    'blockers'          => 'Blockers',
    'notes'             => 'Notes',
];


/**
 * Progress for one project.
 *
 * Precedence: an explicit percentage set by the lead wins, then the
 * system counters, then completed milestones. A programme is only ever
 * measured one way, and the lead's own figure is the most informed.
 *
 * @return array{percent:int,source:string}
 */
function spProgress(array $p, int $msTotal = 0, int $msDone = 0): array
{
    if ($p['progress_percent'] !== null && $p['progress_percent'] !== '') {
        return ['percent' => max(0, min(100, (int) $p['progress_percent'])), 'source' => 'manual'];
    }

    $total = (int) $p['total_systems'];
    if ($total > 0) {
        return [
            'percent' => max(0, min(100, (int) round(((int) $p['completed_systems'] / $total) * 100))),
            'source'  => 'systems',
        ];
    }

    if ($msTotal > 0) {
        return ['percent' => (int) round(($msDone / $msTotal) * 100), 'source' => 'milestones'];
    }

    return ['percent' => 0, 'source' => 'none'];
}


/* ---------------- AJAX ---------------- */

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('special_projects', 'can_audit');
    echo platformHistoryHtml($pdo, SP_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}

if (($_GET['action'] ?? '') === 'milestones_json') {
    header('Content-Type: application/json; charset=utf-8');
    $s = $pdo->prepare("SELECT milestone_name, target_date, completed_date, status, owner, notes
                        FROM project_milestones WHERE project_id = ? ORDER BY milestone_order, id");
    $s->execute([(int) ($_GET['id'] ?? 0)]);
    echo json_encode($s->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if (($_GET['action'] ?? '') === 'milestones') {
    $s = $pdo->prepare("SELECT * FROM project_milestones WHERE project_id = ? ORDER BY milestone_order, id");
    $s->execute([(int) ($_GET['id'] ?? 0)]);
    $rows = $s->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) { echo '<p class="plat-empty">No milestones defined for this project.</p>'; exit; }

    $today = date('Y-m-d');

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>#</th><th>Milestone</th><th>Target</th><th>Completed</th><th>Status</th><th>Owner</th><th>Notes</th>'
       . '</tr></thead><tbody>';

    foreach ($rows as $i => $m) {
        $tone = match ((string) $m['status']) {
            'Completed'   => 'ok',
            'In Progress' => 'neutral',
            'Blocked'     => 'crit',
            'Skipped'     => 'neutral',
            default       => 'warn',
        };

        // Overdue only matters while the milestone is still open.
        $overdue = $m['status'] !== 'Completed' && $m['status'] !== 'Skipped'
                && !empty($m['target_date']) && $m['target_date'] < $today;

        echo '<tr>'
           . '<td>' . ($i + 1) . '</td>'
           . '<td class="plat-primary">' . plat_h($m['milestone_name']) . '</td>'
           . '<td>' . plat_h($m['target_date'] ?: '—')
             . ($overdue ? ' <span class="plat-pill crit">overdue</span>' : '') . '</td>'
           . '<td>' . plat_h($m['completed_date'] ?: '—') . '</td>'
           . '<td><span class="plat-pill ' . $tone . '">' . plat_h($m['status']) . '</span></td>'
           . '<td>' . plat_h($m['owner'] ?: '—') . '</td>'
           . '<td>' . plat_h($m['notes'] ?: '—') . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/* ---------------- FILTERS ---------------- */

$q        = trim((string) ($_GET['q'] ?? ''));
$fStatus  = trim((string) ($_GET['f_status'] ?? ''));
$fCat     = trim((string) ($_GET['f_cat'] ?? ''));
$fHealth  = trim((string) ($_GET['f_health'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    // systems included so searching a hostname finds every project that
    // machine is caught up in -- the question asked during an incident.
    $where[] = '(project_name LIKE ? OR project_code LIKE ? OR description LIKE ?'
             . ' OR technology LIKE ? OR project_lead LIKE ? OR systems LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fStatus !== '') { $where[] = 'status = ?';   $params[] = $fStatus; }
if ($fCat !== '')    { $where[] = 'category = ?'; $params[] = $fCat; }
if ($fHealth !== '') { $where[] = 'health = ?';   $params[] = $fHealth; }

$whereSql = implode(' AND ', $where);

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('special_projects', 'can_export');
    platformExportCsv($pdo, 'special_projects', $spFields, $whereSql, $params, 'special_projects');
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('special_projects', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);
        $data = [];
        foreach (array_keys($spFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        $data['total_systems']     = (int) $data['total_systems'];
        $data['completed_systems'] = (int) $data['completed_systems'];

        // Normalised on the way in, so the list is stored one host per line
        // however it was typed, pasted or picked -- everything downstream
        // (count, search, CSV) can then split on newlines alone.
        $scopeHosts = platformSplitHosts($data['systems']);
        $data['systems'] = implode("\n", $scopeHosts);

        // Blank stays NULL so "not set" and "0%" remain distinguishable --
        // spProgress() falls back to the counters only when it is NULL.
        $data['progress_percent'] = $data['progress_percent'] === ''
            ? null
            : max(0, min(100, (int) $data['progress_percent']));

        if ($data['project_name'] === '') {
            $err = 'Project name is required.';
        } elseif ($data['total_systems'] > 0 && $data['completed_systems'] > $data['total_systems']) {
            $err = 'Completed systems cannot exceed total systems.';
        } else {
            try {
                $pdo->beginTransaction();

                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM special_projects WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $pdo->prepare("UPDATE special_projects SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($data), $username, $id]);

                    $action = 'UPDATED';
                    $detail = "Updated project: {$data['project_name']}\n" . platformDiff($old, $data, $spFields);
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $pdo->prepare("INSERT INTO special_projects ($cols, created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    $action = 'CREATED';
                    $detail = "Created project: {$data['project_name']}";
                }

                /* Milestones replaced wholesale -- they are reordered and
                   renamed freely in the editor, so there is no stable
                   client-side identity to diff against. */
                $pdo->prepare("DELETE FROM project_milestones WHERE project_id = ?")->execute([$id]);

                $names  = $_POST['ms_name'] ?? [];
                $targets = $_POST['ms_target'] ?? [];
                $dones   = $_POST['ms_done'] ?? [];
                $states  = $_POST['ms_status'] ?? [];
                $owners  = $_POST['ms_owner'] ?? [];

                $insMs = $pdo->prepare("
                    INSERT INTO project_milestones
                        (project_id, milestone_name, target_date, completed_date, status, owner, milestone_order)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ");

                $order = 0;
                foreach ($names as $i => $n) {
                    $n = trim((string) $n);
                    if ($n === '') { continue; }

                    $insMs->execute([
                        $id, $n,
                        trim((string) ($targets[$i] ?? '')) ?: null,
                        trim((string) ($dones[$i] ?? '')) ?: null,
                        trim((string) ($states[$i] ?? 'Pending')),
                        trim((string) ($owners[$i] ?? '')),
                        $order++,
                    ]);
                }

                $pdo->commit();

                platformLog($pdo, SP_MODULE, $id, $action, $username, $detail . "\n{$order} milestone(s)");
                $msg = $action === 'CREATED' ? 'Project added.' : 'Project updated.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('special_projects', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);
        $n = $pdo->prepare("SELECT project_name FROM special_projects WHERE id = ?");
        $n->execute([$id]);
        $name = (string) ($n->fetchColumn() ?: 'Unknown');

        // The milestones FK declares ON DELETE CASCADE, but SQLite only
        // honours that when PRAGMA foreign_keys is on -- and this app leaves
        // it at the default (off), so the child rows have to go explicitly or
        // they are orphaned with no way left to reach them.
        $pdo->prepare("DELETE FROM project_milestones WHERE project_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM special_projects WHERE id = ?")->execute([$id]);
        platformLog($pdo, SP_MODULE, $id, 'DELETED', $username, "Deleted project: {$name}");
        $msg = 'Project deleted.';
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("
    SELECT * FROM special_projects WHERE $whereSql
    ORDER BY
        CASE status WHEN 'Completed' THEN 2 WHEN 'Cancelled' THEN 3 ELSE 1 END,
        CASE priority WHEN 'Critical' THEN 1 WHEN 'High' THEN 2 WHEN 'Medium' THEN 3 ELSE 4 END,
        target_date IS NULL, target_date
");
$stmt->execute($params);
$projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Milestone tallies for every project in two queries, not two per row. */
$msTotal = $msDone = [];
foreach ($pdo->query("SELECT project_id, COUNT(*) c FROM project_milestones GROUP BY project_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $msTotal[(int) $r['project_id']] = (int) $r['c'];
}
foreach ($pdo->query("SELECT project_id, COUNT(*) c FROM project_milestones WHERE status = 'Completed' GROUP BY project_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $msDone[(int) $r['project_id']] = (int) $r['c'];
}

/* Hostname pool for the scope picker: inventory plus the asset register. */
$allHosts = platformHostnamesAll($pdo);

$today = date('Y-m-d');
$active = $atRisk = $overdue = $done = 0;

foreach ($projects as $p) {
    $isClosed = in_array((string) $p['status'], ['Completed', 'Cancelled'], true);

    if ($isClosed) {
        if ((string) $p['status'] === 'Completed') { $done++; }
        continue;
    }

    $active++;
    if (in_array((string) $p['health'], ['At Risk', 'Off Track'], true)) { $atRisk++; }
    if (!empty($p['target_date']) && $p['target_date'] < $today) { $overdue++; }
}

$page_title = 'Special Projects | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🚧</div>
            <div>
                <h1>Special Projects</h1>
                <p>Major upgrades and infrastructure programmes — scope, milestones and progress in one place.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="spOpen()">+ New Project</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_status=<?= urlencode($fStatus) ?>&amp;f_cat=<?= urlencode($fCat) ?>&amp;f_health=<?= urlencode($fHealth) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="spHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= count($projects) ?></b><span>Shown</span></div>
        <div class="plat-stat"><b><?= $active ?></b><span>Active</span></div>
        <div class="plat-stat tone-crit"><b><?= $atRisk ?></b><span>At Risk</span></div>
        <div class="plat-stat tone-warn"><b><?= $overdue ?></b><span>Past Target</span></div>
        <div class="plat-stat tone-ok"><b><?= $done ?></b><span>Completed</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search &amp; Filters</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Name, code, technology, lead…">
                </div>
                <div class="plat-field">
                    <label>Category</label>
                    <select name="f_cat">
                        <option value="">All</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>" <?= $fCat === $c ? 'selected' : '' ?>><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Status</label>
                    <select name="f_status">
                        <option value="">All</option>
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Health</label>
                    <select name="f_health">
                        <option value="">All</option>
                        <?php foreach ($healths as $h): ?><option value="<?= plat_h($h) ?>" <?= $fHealth === $h ? 'selected' : '' ?>><?= plat_h($h) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="special_projects.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Projects</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= count($projects) ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Project</th><th>Category</th><th>Progress</th><th>Milestones</th>
                        <th>Timeline</th><th>Health</th><th>Status</th><th>Lead</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$projects): ?>
                    <tr><td colspan="9"><p class="plat-empty">No special projects tracked yet. Add one to start following a major upgrade or conversion.</p></td></tr>
                <?php else: foreach ($projects as $p): ?>
                    <?php
                        $pid = (int) $p['id'];
                        $mt = $msTotal[$pid] ?? 0;
                        $md = $msDone[$pid] ?? 0;
                        $prog = spProgress($p, $mt, $md);

                        $isClosed = in_array((string) $p['status'], ['Completed', 'Cancelled'], true);
                        $isOverdue = !$isClosed && !empty($p['target_date']) && $p['target_date'] < $today;

                        $healthTone = match ((string) $p['health']) {
                            'On Track'  => 'ok',
                            'At Risk'   => 'warn',
                            'Off Track' => 'crit',
                            default     => 'neutral',
                        };
                        $statusTone = match ((string) $p['status']) {
                            'Completed'   => 'ok',
                            'Cancelled'   => 'neutral',
                            'On Hold'     => 'warn',
                            'In Progress' => 'neutral',
                            default       => 'neutral',
                        };
                        $barTone = $prog['percent'] >= 100 ? 'ok' : ($isOverdue ? 'crit' : 'accent');
                    ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($p['project_name']) ?></span>
                            <span class="plat-sub">
                                <?= plat_h($p['project_code'] ?: '') ?>
                                <?= $p['technology'] ? ($p['project_code'] ? ' · ' : '') . plat_h($p['technology']) : '' ?>
                            </span>
                        </td>
                        <td><span class="plat-pill neutral"><?= plat_h($p['category'] ?: '—') ?></span></td>
                        <td style="min-width:150px;">
                            <div class="sp-bar"><span class="sp-bar-fill tone-<?= $barTone ?>" style="width:<?= $prog['percent'] ?>%"></span></div>
                            <span class="plat-sub">
                                <?= $prog['percent'] ?>%
                                <?php if ($prog['source'] === 'systems'): ?>
                                    · <?= (int) $p['completed_systems'] ?>/<?= (int) $p['total_systems'] ?> systems
                                <?php elseif ($prog['source'] === 'milestones'): ?>
                                    · from milestones
                                <?php elseif ($prog['source'] === 'manual'): ?>
                                    · set manually
                                <?php endif; ?>
                                <?php $scope = platformSplitHosts($p['systems'] ?? ''); ?>
                                <?php if ($scope): ?>
                                    · <button type="button" class="sp-host-link"
                                        onclick='spScope(<?= json_encode($p["systems"] ?? "", JSON_HEX_APOS | JSON_HEX_QUOT) ?>, <?= json_encode($p["project_name"], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'><?= count($scope) ?> host<?= count($scope) === 1 ? '' : 's' ?></button>
                                <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php if ($mt): ?>
                                <?= $md ?> / <?= $mt ?>
                                <span class="plat-sub">complete</span>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td>
                            <?= plat_h($p['start_date'] ?: '—') ?>
                            <span class="plat-sub">
                                <?php if ($isOverdue): ?>
                                    <span class="plat-pill crit">due <?= plat_h($p['target_date']) ?></span>
                                <?php elseif ($p['completed_date']): ?>
                                    done <?= plat_h($p['completed_date']) ?>
                                <?php elseif ($p['target_date']): ?>
                                    → <?= plat_h($p['target_date']) ?>
                                <?php endif; ?>
                            </span>
                        </td>
                        <td><span class="plat-pill <?= $healthTone ?>"><?= plat_h($p['health']) ?></span></td>
                        <td><span class="plat-pill <?= $statusTone ?>"><?= plat_h($p['status']) ?></span></td>
                        <td>
                            <?= plat_h($p['project_lead'] ?: '—') ?>
                            <?php if ($p['team']): ?><span class="plat-sub"><?= plat_h($p['team']) ?></span><?php endif; ?>
                        </td>
                        <td>
                            <div class="plat-row-actions">
                                <button type="button" class="plat-icon-btn plat-icon-view" title="Milestones"
                                    onclick="spMilestones(<?= $pid ?>, '<?= plat_h(addslashes($p['project_name'])) ?>')">◷</button>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='spOpen(<?= json_encode($p, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History"
                                        onclick="spHistory(<?= $pid ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="spDelete(<?= $pid ?>, '<?= plat_h(addslashes($p['project_name'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="plat-modal" id="spModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="spTitle">New Project</h2>
            <button type="button" class="plat-close" onclick="platClose('spModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Scope, timeline and the phases the programme moves through.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="sp_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Project Name *</label><input type="text" name="project_name" id="sp_project_name" required placeholder="RHEL 7 → 9 estate upgrade"></div>
                <div class="plat-field"><label>Project Code</label><input type="text" name="project_code" id="sp_project_code"></div>
                <div class="plat-field"><label>Category</label>
                    <select name="category" id="sp_category">
                        <option value="">—</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>"><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field full"><label>Description</label><textarea name="description" id="sp_description" rows="2"></textarea></div>
                <div class="plat-field full"><label>Objective</label><input type="text" name="objective" id="sp_objective" placeholder="What does done look like?"></div>

                <div class="plat-field"><label>Status</label>
                    <select name="status" id="sp_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Priority</label>
                    <select name="priority" id="sp_priority">
                        <?php foreach ($priorities as $p2): ?><option value="<?= plat_h($p2) ?>" <?= $p2 === 'Medium' ? 'selected' : '' ?>><?= plat_h($p2) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Health</label>
                    <select name="health" id="sp_health">
                        <?php foreach ($healths as $h2): ?><option value="<?= plat_h($h2) ?>"><?= plat_h($h2) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-section-title">Timeline</div>
                <div class="plat-field"><label>Start Date</label><input type="date" name="start_date" id="sp_start_date"></div>
                <div class="plat-field"><label>Target Date</label><input type="date" name="target_date" id="sp_target_date"></div>
                <div class="plat-field"><label>Completed Date</label><input type="date" name="completed_date" id="sp_completed_date"></div>

                <div class="plat-section-title">Scope &amp; progress</div>
                <div class="plat-field"><label>Total Systems</label><input type="number" name="total_systems" id="sp_total_systems" value="0" min="0"></div>
                <div class="plat-field"><label>Completed Systems</label><input type="number" name="completed_systems" id="sp_completed_systems" value="0" min="0"></div>
                <div class="plat-field">
                    <label>Progress % <span style="font-weight:400;color:var(--text-muted);">— blank = auto</span></label>
                    <input type="number" name="progress_percent" id="sp_progress_percent" min="0" max="100" placeholder="auto">
                </div>

                <div class="plat-field full">
                    <label>Systems In Scope
                        <span style="font-weight:400;color:var(--text-muted);">— pick from inventory &amp; assets</span>
                    </label>

                    <div class="sp-host-pick">
                        <input type="text" id="sp_host_input" list="spAllHostnames" autocomplete="off"
                               placeholder="Type a hostname, then Enter or Add">
                        <button type="button" class="plat-btn-sm" id="sp_host_add">Add</button>
                    </div>

                    <div class="sp-host-chips" id="sp_host_chips"></div>

                    <div class="sp-host-foot">
                        <span id="sp_host_count">No systems selected</span>
                        <button type="button" class="sp-host-link" id="sp_host_to_total">Use count as Total Systems</button>
                        <button type="button" class="sp-host-link" id="sp_host_clear">Clear all</button>
                    </div>

                    <!-- Submitted value. Kept in sync by the chip editor, and
                         still editable directly for bulk paste. -->
                    <textarea name="systems" id="sp_systems" rows="2"
                              placeholder="One hostname per line"></textarea>
                </div>

                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="sp_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Technology</label><input type="text" name="technology" id="sp_technology" placeholder="RHEL 9 / Oracle 19c / OCP 4.14"></div>
                <div class="plat-field"><label>Affected Projects</label><input type="text" name="affected_projects" id="sp_affected_projects"></div>

                <div class="plat-section-title">Ownership</div>
                <div class="plat-field"><label>Project Lead</label><input type="text" name="project_lead" id="sp_project_lead"></div>
                <div class="plat-field"><label>Lead Email</label><input type="email" name="lead_email" id="sp_lead_email"></div>
                <div class="plat-field"><label>Team</label><input type="text" name="team" id="sp_team"></div>
                <div class="plat-field"><label>Sponsor</label><input type="text" name="sponsor" id="sp_sponsor"></div>
                <div class="plat-field"><label>Change Reference</label><input type="text" name="change_reference" id="sp_change_reference" placeholder="CR / ticket number"></div>

                <div class="plat-field full"><label>Risks</label><textarea name="risks" id="sp_risks" rows="2"></textarea></div>
                <div class="plat-field full"><label>Blockers</label><textarea name="blockers" id="sp_blockers" rows="2"></textarea></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="sp_notes" rows="2"></textarea></div>

                <div class="plat-section-title">Milestones</div>
                <div class="full">
                    <div id="spMsRows"></div>
                    <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="spAddMs()">+ Add milestone</button>
                </div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('spModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Project</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="spMsModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="spMsTitle">Milestones</h2>
            <button type="button" class="plat-close" onclick="platClose('spMsModal')">&times;</button></div>
        <div id="spMsBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="spScopeModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="spScopeTitle">Systems In Scope</h2>
            <button type="button" class="plat-close" onclick="platClose('spScopeModal')">&times;</button></div>
        <div id="spScopeBody"></div>
    </div>
</div>

<div class="plat-modal" id="spHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="spHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('spHistModal')">&times;</button></div>
        <div id="spHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="spDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete project</h2>
            <button type="button" class="plat-close" onclick="platClose('spDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete <strong id="spDelName"></strong> and all of its milestones?</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="spDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('spDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<!-- Scope picker suggestions: inventory first, then asset-only hosts. The
     label carries the source so the two are told apart while typing. -->
<datalist id="spAllHostnames">
    <?php foreach ($allHosts as $h): ?>
        <option value="<?= plat_h($h['hostname']) ?>"><?= plat_h(
            ucfirst($h['source']) . ($h['detail'] !== '' ? ' — ' . $h['detail'] : '')
        ) ?></option>
    <?php endforeach; ?>
</datalist>

<style>
.sp-bar {
    height: 7px;
    border-radius: 999px;
    background: var(--border-light);
    overflow: hidden;
}

.sp-bar-fill {
    display: block;
    height: 100%;
    border-radius: 999px;
    min-width: 2px;
    transition: width .3s ease;
}

.sp-bar-fill.tone-accent { background: #4338CA; }
.sp-bar-fill.tone-ok     { background: #0D9488; }
.sp-bar-fill.tone-crit   { background: #B42318; }

[data-theme="dark"] .sp-bar-fill.tone-accent { background: #6366F1; }
[data-theme="dark"] .sp-bar-fill.tone-ok     { background: #0D9488; }
[data-theme="dark"] .sp-bar-fill.tone-crit   { background: #F43F5E; }

/* ---- systems-in-scope picker ---- */
.sp-host-pick { display: flex; gap: 8px; align-items: center; }
.sp-host-pick input { flex: 1; }

.sp-host-chips {
    display: flex;
    flex-wrap: wrap;
    gap: 6px;
    margin-top: 8px;
    max-height: 150px;
    overflow-y: auto;
}

.sp-host-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 4px 6px 4px 4px;
    border: 1px solid var(--border-color);
    border-radius: 999px;
    background: var(--bg-subtle, #F8FAFC);
    font-size: 12.5px;
    line-height: 1.2;
}

.sp-host-src {
    display: inline-grid;
    place-items: center;
    width: 17px;
    height: 17px;
    border-radius: 50%;
    font-size: 10px;
    font-weight: 700;
    color: #fff;
    background: #64748B;
}

.sp-host-chip.src-inventory .sp-host-src { background: #0369A1; }
.sp-host-chip.src-asset     .sp-host-src { background: #6D28D9; }

/* A host in neither list is not an error -- it may be built next week --
   but it is worth showing as unverified rather than silently accepting. */
.sp-host-chip.src-unknown {
    border-style: dashed;
    border-color: #B45309;
}
.sp-host-chip.src-unknown .sp-host-src { background: #B45309; }

.sp-host-name { color: var(--text-primary); }

.sp-host-x {
    border: 0;
    background: none;
    cursor: pointer;
    font-size: 15px;
    line-height: 1;
    padding: 0 2px;
    color: var(--text-muted);
}
.sp-host-x:hover { color: #B42318; }

.sp-host-foot {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
    margin: 8px 0 6px;
    font-size: 12px;
    color: var(--text-secondary);
}

.sp-host-link {
    border: 0;
    background: none;
    padding: 0;
    cursor: pointer;
    font-size: 12px;
    font-family: inherit;
    color: var(--accent);
    text-decoration: underline;
}

#sp_systems { font-family: ui-monospace, Menlo, Consolas, monospace; font-size: 12.5px; }

/* Source badges in the read-only scope modal. */
.sp-src {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 999px;
    font-size: 11px;
    font-weight: 600;
    color: #fff;
    background: #64748B;
}
.sp-src.src-inventory { background: #0369A1; }
.sp-src.src-asset     { background: #6D28D9; }
.sp-src.src-unknown   { background: #B45309; }

[data-theme="dark"] .sp-host-chip { background: rgba(255,255,255,.04); }
</style>

<script>
const SP_FIELDS   = <?= json_encode(array_keys($spFields)) ?>;
const SP_MS_STATUS = <?= json_encode($msStatuses) ?>;

/* Hostname pool for the scope picker. Only the name and source travel to
   the client -- the detail text is for the datalist and stays in markup. */
const SP_ALL_HOSTS = <?= json_encode(array_map(
    fn($h) => ['hostname' => $h['hostname'], 'source' => $h['source']],
    $allHosts
), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function spMsRow(m) {
    m = m || {};
    const opts = SP_MS_STATUS.map(s =>
        `<option value="${s}" ${m.status === s ? 'selected' : ''}>${s}</option>`).join('');

    const row = document.createElement('div');
    row.className = 'plat-filters';
    row.style.marginBottom = '8px';
    row.innerHTML =
        `<div class="plat-field"><input name="ms_name[]" placeholder="Milestone" style="min-width:220px" value="${spEsc(m.milestone_name)}"></div>
         <div class="plat-field"><input type="date" name="ms_target[]" title="Target" value="${spEsc(m.target_date)}"></div>
         <div class="plat-field"><input type="date" name="ms_done[]" title="Completed" value="${spEsc(m.completed_date)}"></div>
         <div class="plat-field"><select name="ms_status[]">${opts}</select></div>
         <div class="plat-field"><input name="ms_owner[]" placeholder="Owner" style="min-width:130px" value="${spEsc(m.owner)}"></div>
         <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="this.parentNode.remove()">Remove</button>`;
    return row;
}

function spAddMs(m) { document.getElementById('spMsRows').appendChild(spMsRow(m)); }

/* ---------- systems-in-scope picker ---------- */

/* Hostname -> source, so a chip can show where the machine is recorded
   and flag one that matches neither list. */
const SP_HOST_SRC = {};
SP_ALL_HOSTS.forEach(h => { SP_HOST_SRC[h.hostname.toLowerCase()] = h.source; });

let spHosts = [];

function spHostsSet(raw) {
    spHosts = [];
    String(raw || '').split(/[\r\n,;]+/).forEach(spHostPush);
    spHostsRender();
}

/* Case-insensitive de-dupe: inventory and the asset register disagree on
   casing often enough that the same host would otherwise land twice. */
function spHostPush(name) {
    const h = String(name || '').trim();
    if (!h) return false;
    if (spHosts.some(x => x.toLowerCase() === h.toLowerCase())) return false;
    spHosts.push(h);
    return true;
}

function spHostsRender() {
    const wrap = document.getElementById('sp_host_chips');
    wrap.innerHTML = '';

    spHosts.forEach((h, i) => {
        const src = SP_HOST_SRC[h.toLowerCase()] || 'unknown';
        const chip = document.createElement('span');
        chip.className = 'sp-host-chip src-' + src;
        chip.innerHTML =
            `<span class="sp-host-src">${src === 'unknown' ? '?' : src.charAt(0).toUpperCase()}</span>` +
            `<span class="sp-host-name">${spEsc(h)}</span>` +
            `<button type="button" class="sp-host-x" aria-label="Remove ${spEsc(h)}">&times;</button>`;
        chip.title = src === 'unknown'
            ? h + ' — not found in inventory or assets'
            : h + ' — from ' + src;
        chip.querySelector('.sp-host-x').addEventListener('click', () => {
            spHosts.splice(i, 1);
            spHostsRender();
        });
        wrap.appendChild(chip);
    });

    document.getElementById('sp_systems').value = spHosts.join('\n');

    const unknown = spHosts.filter(h => !SP_HOST_SRC[h.toLowerCase()]).length;
    document.getElementById('sp_host_count').textContent =
        spHosts.length === 0
            ? 'No systems selected'
            : spHosts.length + (spHosts.length === 1 ? ' system' : ' systems')
              + (unknown ? ` · ${unknown} not in inventory or assets` : '');
}

function spHostAdd() {
    const input = document.getElementById('sp_host_input');
    // Splitting here too, so pasting a block into the box works like the
    // textarea rather than creating one absurd chip.
    let added = 0;
    input.value.split(/[\r\n,;]+/).forEach(n => { if (spHostPush(n)) added++; });
    input.value = '';
    if (added) spHostsRender();
    input.focus();
}

function spHostsInit() {
    document.getElementById('sp_host_add').addEventListener('click', spHostAdd);

    document.getElementById('sp_host_input').addEventListener('keydown', e => {
        // Enter would otherwise submit the whole project form.
        if (e.key === 'Enter') { e.preventDefault(); spHostAdd(); }
    });

    // Typed or pasted straight into the textarea, the chips must catch up.
    document.getElementById('sp_systems').addEventListener('change', e => {
        spHostsSet(e.target.value);
    });

    document.getElementById('sp_host_clear').addEventListener('click', () => {
        spHosts = [];
        spHostsRender();
    });

    document.getElementById('sp_host_to_total').addEventListener('click', () => {
        document.getElementById('sp_total_systems').value = spHosts.length;
    });
}

document.addEventListener('DOMContentLoaded', spHostsInit);

function spOpen(data) {
    const editing = !!data;
    document.getElementById('spTitle').innerText = editing ? 'Edit Project' : 'New Project';
    document.getElementById('sp_id').value = editing ? data.id : '';

    SP_FIELDS.forEach(f => {
        const el = document.getElementById('sp_' + f);
        if (!el) return;
        if (editing) {
            el.value = data[f] ?? '';
        } else if (f === 'total_systems' || f === 'completed_systems') {
            el.value = 0;
        } else if (f === 'priority') {
            el.value = 'Medium';
        } else if (f === 'status') {
            el.value = 'Planning';
        } else if (f === 'health') {
            el.value = 'On Track';
        } else {
            el.value = '';
        }
    });

    spHostsSet(editing ? (data.systems || '') : '');

    const rows = document.getElementById('spMsRows');
    rows.innerHTML = '';

    if (editing) {
        fetch('special_projects.php?action=milestones_json&id=' + encodeURIComponent(data.id))
            .then(r => r.ok ? r.json() : [])
            .then(list => { (list || []).forEach(spAddMs); if (!list || !list.length) spAddMs(); })
            .catch(() => spAddMs());
    } else {
        spAddMs();
    }

    platOpen('spModal');
}

/* Read-only view of a project's scope. Rendered from the row data already
   in the page -- no round-trip, and it works without can_edit. */
function spScope(raw, name) {
    const hosts = String(raw || '').split(/[\r\n,;]+/).map(s => s.trim()).filter(Boolean);
    document.getElementById('spScopeTitle').innerText = 'Systems In Scope — ' + name;

    const body = document.getElementById('spScopeBody');
    if (!hosts.length) {
        body.innerHTML = '<p class="plat-empty">No systems recorded for this project.</p>';
        platOpen('spScopeModal');
        return;
    }

    const rows = hosts.map(h => {
        const src = SP_HOST_SRC[h.toLowerCase()];
        // Local chip classes, not ip.css's .ip-src -- this page only loads
        // platform.css, so those would have rendered unstyled.
        const badge = src === 'inventory'
            ? '<span class="sp-src src-inventory">Inventory</span>'
            : src === 'asset'
                ? '<span class="sp-src src-asset">Asset</span>'
                : '<span class="sp-src src-unknown">Not found</span>';
        // Each page names its own search parameter: inventory.php reads
        // ?q=, asset.php reads ?s_hostname=.
        const link = src === 'inventory'
            ? `<a href="inventory.php?q=${encodeURIComponent(h)}" title="Open in Inventory">&#8599;</a>`
            : src === 'asset'
                ? `<a href="asset.php?s_hostname=${encodeURIComponent(h)}" title="Open in Assets">&#8599;</a>`
                : '';
        return `<tr><td class="plat-primary">${spEsc(h)}</td><td>${badge}</td><td>${link}</td></tr>`;
    }).join('');

    body.innerHTML =
        `<div class="plat-table-wrap"><table class="plat-table">
            <thead><tr><th>Hostname</th><th>Source</th><th></th></tr></thead>
            <tbody>${rows}</tbody>
         </table></div>
         <p class="plat-sub" style="margin-top:8px;">${hosts.length} system${hosts.length === 1 ? '' : 's'} in scope.</p>`;

    platOpen('spScopeModal');
}

function spMilestones(id, name) {
    document.getElementById('spMsTitle').innerText = 'Milestones — ' + name;
    document.getElementById('spMsBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('spMsModal');
    fetch('special_projects.php?action=milestones&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('spMsBody').innerHTML = h; })
        .catch(() => { document.getElementById('spMsBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function spHistory(id) {
    document.getElementById('spHistTitle').innerText = id ? 'Audit History — project #' + id : 'Module Audit History';
    document.getElementById('spHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('spHistModal');
    fetch('special_projects.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('spHistBody').innerHTML = h; })
        .catch(() => { document.getElementById('spHistBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function spDelete(id, name) {
    document.getElementById('spDelId').value = id;
    document.getElementById('spDelName').innerText = name;
    platOpen('spDelModal');
}

/* Values go through innerHTML, so they are escaped. */
function spEsc(v) {
    return String(v ?? '')
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#039;');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
