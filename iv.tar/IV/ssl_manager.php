<?php

require_once __DIR__ . '/config/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
| Authorization. This page had neither a login check nor a permission
| check -- it fell back to a 'System' username and rendered for anyone.
*/
requireLogin();
requirePermission('ssl_manager', 'can_view');

$page_title = 'SSL / TLS Certificate Manager';

$current_user = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? $_SESSION['name']
    ?? $_SESSION['user']['name']
    ?? 'System';

$current_role = strtolower(
    $_SESSION['user_role']
    ?? $_SESSION['role']
    ?? $_SESSION['user']['role']
    ?? 'user'
);

/*
|--------------------------------------------------------------------------
| SSL / TLS CERTIFICATE MANAGER
|--------------------------------------------------------------------------
|
| This page does NOT store:
|
|   - Private keys
|   - Certificates
|   - CSRs
|   - Passwords
|
| Generated material is held in PHP memory for the current request,
| returned to the browser, and can then be downloaded as text files.
|
| No ZipArchive is required.
|
|--------------------------------------------------------------------------
*/

if (!extension_loaded('openssl')) {
    die('PHP OpenSSL extension is required.');
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}

function jsonResponse(
    $success,
    $message = '',
    $extra = []
) {
    while (ob_get_level()) {
        ob_end_clean();
    }

    header(
        'Content-Type: application/json; charset=utf-8'
    );

    header(
        'Cache-Control: no-store, no-cache, must-revalidate, max-age=0'
    );

    header('Pragma: no-cache');

    echo json_encode(
        array_merge(
            [
                'success' => $success,
                'message' => $message
            ],
            $extra
        ),
        JSON_UNESCAPED_SLASHES
    );

    exit;
}

function opensslErrors()
{
    $errors = [];

    while (
        ($error = openssl_error_string()) !== false
    ) {
        $errors[] = $error;
    }

    return $errors;
}

function opensslErrorText()
{
    $errors = opensslErrors();

    return $errors
        ? implode("\n", $errors)
        : 'Unknown OpenSSL error.';
}

function cleanPem($pem)
{
    return trim(
        str_replace(
            ["\r\n", "\r"],
            "\n",
            trim((string)$pem)
        )
    );
}

function validPem($pem)
{
    return preg_match(
        '/-----BEGIN [A-Z0-9 ]+-----/',
        (string)$pem
    );
}

/*
|--------------------------------------------------------------------------
| Build safe filename
|--------------------------------------------------------------------------
*/

function safeFilename($filename)
{
    return preg_replace(
        '/[^A-Za-z0-9._-]/',
        '_',
        (string)$filename
    );
}

/*
|--------------------------------------------------------------------------
| Direct text download
|--------------------------------------------------------------------------
*/

function downloadText(
    $filename,
    $content,
    $contentType = 'application/x-pem-file'
) {
    while (ob_get_level()) {
        ob_end_clean();
    }

    $filename = safeFilename($filename);

    header(
        'Content-Type: ' . $contentType
    );

    header(
        'Content-Disposition: attachment; filename="' .
        $filename .
        '"'
    );

    header(
        'Content-Length: ' .
        strlen($content)
    );

    header(
        'Cache-Control: no-store, no-cache, must-revalidate, max-age=0'
    );

    header('Pragma: no-cache');

    echo $content;

    exit;
}

/*
|--------------------------------------------------------------------------
| Binary download
|--------------------------------------------------------------------------
*/

function downloadBinary(
    $filename,
    $content,
    $contentType
) {
    while (ob_get_level()) {
        ob_end_clean();
    }

    $filename = safeFilename($filename);

    header(
        'Content-Type: ' .
        $contentType
    );

    header(
        'Content-Disposition: attachment; filename="' .
        $filename .
        '"'
    );

    header(
        'Content-Length: ' .
        strlen($content)
    );

    header(
        'Cache-Control: no-store, no-cache, must-revalidate, max-age=0'
    );

    header('Pragma: no-cache');

    echo $content;

    exit;
}

/*
|--------------------------------------------------------------------------
| Temporary OpenSSL configuration
|--------------------------------------------------------------------------
*/

function createOpenSSLConfig(
    $sanLines = [],
    $isCA = false
) {
    $sanLines = array_values(
        array_filter($sanLines)
    );

    $sanBlock = '';

    if ($sanLines) {

        $sanBlock .= "\n[alt_names]\n";

        $dns = 1;
        $ip = 1;
        $email = 1;
        $uri = 1;

        foreach ($sanLines as $san) {

            $parts = explode(
                '|',
                $san,
                2
            );

            if (count($parts) !== 2) {
                continue;
            }

            $type = strtoupper(
                trim($parts[0])
            );

            $value = trim(
                $parts[1]
            );

            if ($value === '') {
                continue;
            }

            /*
            |--------------------------------------------------------------------------
            | Prevent OpenSSL configuration injection
            |--------------------------------------------------------------------------
            */

            $value = str_replace(
                [
                    "\r",
                    "\n"
                ],
                '',
                $value
            );

            if ($type === 'DNS') {

                $sanBlock .=
                    "DNS.{$dns} = {$value}\n";

                $dns++;
            }

            if ($type === 'IP') {

                $sanBlock .=
                    "IP.{$ip} = {$value}\n";

                $ip++;
            }

            if ($type === 'EMAIL') {

                $sanBlock .=
                    "email.{$email} = {$value}\n";

                $email++;
            }

            if ($type === 'URI') {

                $sanBlock .=
                    "URI.{$uri} = {$value}\n";

                $uri++;
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | Certificate extensions
    |--------------------------------------------------------------------------
    */

    if ($isCA) {

        $extensions = <<<CONF
basicConstraints = critical,CA:true
keyUsage = critical,keyCertSign,cRLSign
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid:always,issuer
CONF;

    } else {

        $extensions = <<<CONF
basicConstraints = critical,CA:false
keyUsage = critical,digitalSignature,keyEncipherment
extendedKeyUsage = serverAuth,clientAuth
subjectKeyIdentifier = hash
authorityKeyIdentifier = keyid,issuer
CONF;

        if ($sanLines) {

            $extensions .=
                "\nsubjectAltName = @alt_names\n";
        }
    }

    /*
    |--------------------------------------------------------------------------
    | OpenSSL config
    |--------------------------------------------------------------------------
    */

    $config = <<<CONF
[req]
default_bits = 2048
prompt = no
default_md = sha256
distinguished_name = dn
req_extensions = req_ext
x509_extensions = v3_ext

[dn]
C = XX
ST = State
L = City
O = Organization
OU = IT
CN = localhost

[req_ext]
CONF;

    if ($sanLines) {

        $config .=
            "subjectAltName = @alt_names\n";
    }

    $config .= "\n[v3_ext]\n";

    $config .=
        $extensions;

    $config .= "\n";

    $config .=
        $sanBlock;

    $tmp = tempnam(
        sys_get_temp_dir(),
        'ssl_cfg_'
    );

    if ($tmp === false) {

        throw new RuntimeException(
            'Unable to create temporary OpenSSL configuration.'
        );
    }

    if (
        file_put_contents(
            $tmp,
            $config
        ) === false
    ) {

        @unlink($tmp);

        throw new RuntimeException(
            'Unable to write temporary OpenSSL configuration.'
        );
    }

    return $tmp;
}

/*
|--------------------------------------------------------------------------
| Build certificate subject
|--------------------------------------------------------------------------
*/

function buildSubject()
{
    $subject = [];

    $fields = [
        'C' => 'country',
        'ST' => 'state',
        'L' => 'locality',
        'O' => 'organization',
        'OU' => 'organizational_unit',
        'emailAddress' => 'email',
        'CN' => 'common_name'
    ];

    foreach (
        $fields as $opensslName => $postName
    ) {

        $value = trim(
            $_POST[$postName] ?? ''
        );

        if ($value !== '') {

            /*
            |--------------------------------------------------------------------------
            | Prevent subject field newline injection
            |--------------------------------------------------------------------------
            */

            $value = str_replace(
                ["\r", "\n"],
                '',
                $value
            );

            $subject[$opensslName] =
                $value;
        }
    }

    if (empty($subject['CN'])) {

        throw new RuntimeException(
            'Common Name is required.'
        );
    }

    return $subject;
}

/*
|--------------------------------------------------------------------------
| SAN parser
|--------------------------------------------------------------------------
*/

function getSanList()
{
    $result = [];

    $types =
        $_POST['san_type'] ?? [];

    $values =
        $_POST['san_value'] ?? [];

    if (!is_array($types)) {
        return [];
    }

    foreach (
        $types as $i => $type
    ) {

        $type = strtoupper(
            trim($type)
        );

        $value = trim(
            $values[$i] ?? ''
        );

        if ($value === '') {
            continue;
        }

        if (
            !in_array(
                $type,
                [
                    'DNS',
                    'IP',
                    'EMAIL',
                    'URI'
                ],
                true
            )
        ) {

            continue;
        }

        /*
        |--------------------------------------------------------------------------
        | SAN validation
        |--------------------------------------------------------------------------
        */

        if (
            $type === 'IP' &&
            !filter_var(
                $value,
                FILTER_VALIDATE_IP
            )
        ) {

            throw new RuntimeException(
                "Invalid IP SAN: {$value}"
            );
        }

        if (
            $type === 'EMAIL' &&
            !filter_var(
                $value,
                FILTER_VALIDATE_EMAIL
            )
        ) {

            throw new RuntimeException(
                "Invalid email SAN: {$value}"
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Basic DNS validation
        |--------------------------------------------------------------------------
        */

        if ($type === 'DNS') {

            if (
                strlen($value) > 253 ||
                preg_match(
                    '/[\r\n\s]/',
                    $value
                )
            ) {

                throw new RuntimeException(
                    "Invalid DNS SAN: {$value}"
                );
            }
        }

        /*
        |--------------------------------------------------------------------------
        | URI basic validation
        |--------------------------------------------------------------------------
        */

        if ($type === 'URI') {

            if (
                preg_match(
                    '/[\r\n]/',
                    $value
                )
            ) {

                throw new RuntimeException(
                    "Invalid URI SAN: {$value}"
                );
            }
        }

        $result[] =
            $type . '|' . $value;
    }

    return $result;
}

/*
|--------------------------------------------------------------------------
| Generate RSA key
|--------------------------------------------------------------------------
*/

function generateRSAKey($bits)
{
    $bits = (int)$bits;

    if (
        !in_array(
            $bits,
            [
                2048,
                3072,
                4096
            ],
            true
        )
    ) {

        throw new RuntimeException(
            'Invalid RSA key size.'
        );
    }

    $key = openssl_pkey_new(
        [
            'private_key_type' =>
                OPENSSL_KEYTYPE_RSA,

            'private_key_bits' =>
                $bits
        ]
    );

    if ($key === false) {

        throw new RuntimeException(
            opensslErrorText()
        );
    }

    return $key;
}

/*
|--------------------------------------------------------------------------
| Export private key
|--------------------------------------------------------------------------
*/

function exportPrivateKey(
    $key,
    $password = ''
) {
    $output = '';

    if ($password !== '') {

        if (
            !openssl_pkey_export(
                $key,
                $output,
                $password,
                [
                    'digest_alg' =>
                        'sha256'
                ]
            )
        ) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

    } else {

        if (
            !openssl_pkey_export(
                $key,
                $output,
                null
            )
        ) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }
    }

    return $output;
}

/*
|--------------------------------------------------------------------------
| Generate CSR
|--------------------------------------------------------------------------
*/

function generateCSR(
    $subject,
    $key,
    $sanLines
) {
    $config =
        createOpenSSLConfig(
            $sanLines
        );

    try {

        $csr = openssl_csr_new(
            $subject,
            $key,
            [
                'digest_alg' =>
                    'sha256',

                'config' =>
                    $config,

                'req_extensions' =>
                    'req_ext'
            ]
        );

        if ($csr === false) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

        $csrPem = '';

        if (
            !openssl_csr_export(
                $csr,
                $csrPem
            )
        ) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

        return [
            'csr' => $csr,
            'pem' => $csrPem
        ];

    } finally {

        @unlink($config);
    }
}

/*
|--------------------------------------------------------------------------
| Generate self-signed certificate
|--------------------------------------------------------------------------
*/

function generateSelfSignedCertificate(
    $subject,
    $key,
    $sanLines,
    $days
) {
    $days = max(
        1,
        min(
            8250,
            (int)$days
        )
    );

    $config =
        createOpenSSLConfig(
            $sanLines
        );

    try {

        $csr = openssl_csr_new(
            $subject,
            $key,
            [
                'digest_alg' =>
                    'sha256',

                'config' =>
                    $config,

                'req_extensions' =>
                    'req_ext'
            ]
        );

        if ($csr === false) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

        $cert = openssl_csr_sign(
            $csr,
            null,
            $key,
            $days,
            [
                'digest_alg' =>
                    'sha256',

                'config' =>
                    $config,

                'x509_extensions' =>
                    'v3_ext'
            ],
            random_int(
                100000,
                2147483647
            )
        );

        if ($cert === false) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

        $certPem = '';

        if (
            !openssl_x509_export(
                $cert,
                $certPem
            )
        ) {

            throw new RuntimeException(
                opensslErrorText()
            );
        }

        return [
            'certificate' =>
                $cert,

            'pem' =>
                $certPem
        ];

    } finally {

        @unlink($config);
    }
}

/*
|--------------------------------------------------------------------------
| Read uploaded/pasted PEM
|--------------------------------------------------------------------------
*/

function getInputText(
    $textareaName,
    $fileName
) {
    $text = trim(
        $_POST[$textareaName] ?? ''
    );

    if ($text !== '') {
        return $text;
    }

    if (
        isset($_FILES[$fileName]) &&
        isset($_FILES[$fileName]['tmp_name']) &&
        is_uploaded_file(
            $_FILES[$fileName]['tmp_name']
        )
    ) {

        $text = file_get_contents(
            $_FILES[$fileName]['tmp_name']
        );

        if ($text !== false) {
            return trim($text);
        }
    }

    return '';
}

/*
|--------------------------------------------------------------------------
| Certificate decoder
|--------------------------------------------------------------------------
*/

function decodeCertificate($pem)
{
    $pem = cleanPem($pem);

    $cert =
        @openssl_x509_read($pem);

    if ($cert === false) {

        throw new RuntimeException(
            'Invalid certificate.' .
            "\n" .
            opensslErrorText()
        );
    }

    $parsed =
        openssl_x509_parse(
            $cert,
            false
        );

    if ($parsed === false) {

        throw new RuntimeException(
            'Unable to parse certificate.'
        );
    }

    $publicKey =
        @openssl_pkey_get_public(
            $cert
        );

    $keyDetails =
        $publicKey
            ? openssl_pkey_get_details(
                $publicKey
            )
            : false;

    $fingerprint =
        openssl_x509_fingerprint(
            $cert,
            'sha256'
        );

    $result = [

        'subject' =>
            $parsed['subject'] ?? [],

        'issuer' =>
            $parsed['issuer'] ?? [],

        'serial' =>
            $parsed['serialNumberHex']
                ?? (
                    $parsed['serialNumber']
                    ?? ''
                ),

        'valid_from' =>
            isset(
                $parsed['validFrom_time_t']
            )
                ? date(
                    'Y-m-d H:i:s T',
                    $parsed[
                        'validFrom_time_t'
                    ]
                )
                : '',

        'valid_to' =>
            isset(
                $parsed['validTo_time_t']
            )
                ? date(
                    'Y-m-d H:i:s T',
                    $parsed[
                        'validTo_time_t'
                    ]
                )
                : '',

        'signature_algorithm' =>
            $parsed['signatureTypeSN']
                ?? (
                    $parsed[
                        'signatureTypeLN'
                    ]
                    ?? ''
                ),

        'fingerprint_sha256' =>
            $fingerprint,

        'extensions' =>
            $parsed['extensions']
            ?? [],

        'key_type' =>
            '',

        'key_bits' =>
            '',

        'key_details' =>
            $keyDetails ?: []
    ];

    if ($keyDetails) {

        if (
            ($keyDetails['type'] ?? null)
            === OPENSSL_KEYTYPE_RSA
        ) {

            $result['key_type'] =
                'RSA';

        } elseif (
            ($keyDetails['type'] ?? null)
            === OPENSSL_KEYTYPE_EC
        ) {

            $result['key_type'] =
                'EC';

        } elseif (
            ($keyDetails['type'] ?? null)
            === OPENSSL_KEYTYPE_DSA
        ) {

            $result['key_type'] =
                'DSA';

        } else {

            $result['key_type'] =
                'Unknown';
        }

        $result['key_bits'] =
            $keyDetails['bits'] ?? '';
    }

    return $result;
}

/*
|--------------------------------------------------------------------------
| CSR decoder
|--------------------------------------------------------------------------
*/

function decodeCSR($pem)
{
    $pem = cleanPem($pem);

    $subject =
        @openssl_csr_get_subject(
            $pem
        );

    if ($subject === false) {

        throw new RuntimeException(
            'Invalid CSR.' .
            "\n" .
            opensslErrorText()
        );
    }

    $public =
        @openssl_csr_get_public_key(
            $pem
        );

    $details =
        $public
            ? openssl_pkey_get_details(
                $public
            )
            : false;

    $csrPem = '';

    if (
        !openssl_csr_export(
            $pem,
            $csrPem
        )
    ) {

        $csrPem = $pem;
    }

    return [

        'subject' =>
            $subject,

        'key_type' =>
            $details
                ? (
                    ($details['type'] ?? null)
                    === OPENSSL_KEYTYPE_RSA

                    ? 'RSA'

                    : (
                        ($details['type'] ?? null)
                        === OPENSSL_KEYTYPE_EC

                        ? 'EC'

                        : 'Other'
                    )
                )
                : '',

        'key_bits' =>
            $details['bits']
            ?? '',

        'public_key' =>
            $details['key']
            ?? '',

        'pem' =>
            $csrPem
    ];
}

/*
|--------------------------------------------------------------------------
| Private key inspection
|--------------------------------------------------------------------------
*/

function inspectPrivateKey(
    $pem,
    $password = ''
) {
    $pem = cleanPem($pem);

    $keyInput =
        $password !== ''
            ? [
                $pem,
                $password
            ]
            : $pem;

    $key =
        @openssl_pkey_get_private(
            $keyInput
        );

    if ($key === false) {

        throw new RuntimeException(
            'Unable to read private key. ' .
            'If the key is encrypted, enter its password.'
        );
    }

    $details =
        openssl_pkey_get_details(
            $key
        );

    if (!$details) {

        throw new RuntimeException(
            'Unable to read private key details.'
        );
    }

    $type = 'Unknown';

    if (
        ($details['type'] ?? null)
        === OPENSSL_KEYTYPE_RSA
    ) {

        $type = 'RSA';

    } elseif (
        ($details['type'] ?? null)
        === OPENSSL_KEYTYPE_EC
    ) {

        $type = 'EC';

    } elseif (
        ($details['type'] ?? null)
        === OPENSSL_KEYTYPE_DSA
    ) {

        $type = 'DSA';
    }

    return [

        'key' =>
            $key,

        'type' =>
            $type,

        'bits' =>
            $details['bits']
            ?? '',

        'details' =>
            $details
    ];
}

/*
|--------------------------------------------------------------------------
| Public key fingerprint from key
|--------------------------------------------------------------------------
*/

function publicKeyFingerprintFromKey(
    $key
) {
    $details =
        openssl_pkey_get_details(
            $key
        );

    if (
        !$details ||
        empty($details['key'])
    ) {

        throw new RuntimeException(
            'Unable to obtain public key.'
        );
    }

    $publicKey =
        preg_replace(
            '/-----BEGIN PUBLIC KEY-----|-----END PUBLIC KEY-----/',
            '',
            $details['key']
        );

    $publicKey =
        preg_replace(
            '/\s+/',
            '',
            $publicKey
        );

    return hash(
        'sha256',
        $publicKey
    );
}

/*
|--------------------------------------------------------------------------
| Public key fingerprint from certificate
|--------------------------------------------------------------------------
*/

function publicKeyFingerprintFromCertificate(
    $cert
) {
    $key =
        openssl_pkey_get_public(
            $cert
        );

    if (!$key) {

        throw new RuntimeException(
            'Unable to obtain certificate public key.'
        );
    }

    return publicKeyFingerprintFromKey(
        $key
    );
}

/*
|--------------------------------------------------------------------------
| Public key fingerprint from CSR
|--------------------------------------------------------------------------
*/

function publicKeyFingerprintFromCSR(
    $csrPem
) {
    $key =
        openssl_csr_get_public_key(
            $csrPem
        );

    if (!$key) {

        throw new RuntimeException(
            'Unable to obtain CSR public key.'
        );
    }

    return publicKeyFingerprintFromKey(
        $key
    );
}

/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
) {

    $action =
        $_POST['action'] ?? '';

    try {

        /*
        |--------------------------------------------------------------------------
        | Generate standalone RSA key
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'generate_key'
        ) {

            $bits =
                (int)(
                    $_POST['key_bits']
                    ?? 2048
                );

            $password =
                $_POST['key_password']
                ?? '';

            $key =
                generateRSAKey(
                    $bits
                );

            $privatePem =
                exportPrivateKey(
                    $key,
                    $password
                );

            downloadText(
                'private-key-rsa-' .
                $bits .
                '.key.pem',
                $privatePem
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Generate CSR + private key
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'generate_csr'
        ) {

            $bits =
                (int)(
                    $_POST['key_bits']
                    ?? 2048
                );

            $password =
                $_POST['key_password']
                ?? '';

            $subject =
                buildSubject();

            $sanLines =
                getSanList();

            $key =
                generateRSAKey(
                    $bits
                );

            $csrResult =
                generateCSR(
                    $subject,
                    $key,
                    $sanLines
                );

            $privatePem =
                exportPrivateKey(
                    $key,
                    $password
                );

            $base =
                safeFilename(
                    $subject['CN']
                );

            jsonResponse(
                true,
                'CSR and private key generated.',
                [
                    'data' => [

                        'type' =>
                            'csr',

                        'common_name' =>
                            $subject['CN'],

                        'private_key' => [

                            'filename' =>
                                $base .
                                '.key.pem',

                            'content' =>
                                $privatePem
                        ],

                        'csr' => [

                            'filename' =>
                                $base .
                                '.csr.pem',

                            'content' =>
                                $csrResult['pem']
                        ]
                    ]
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Generate self-signed certificate + private key
        |--------------------------------------------------------------------------
        */

        if (
            $action ===
            'generate_self_signed'
        ) {

            $bits =
                (int)(
                    $_POST['key_bits']
                    ?? 2048
                );

            $days =
                (int)(
                    $_POST['days']
                    ?? 365
                );

            $password =
                $_POST['key_password']
                ?? '';

            $subject =
                buildSubject();

            $sanLines =
                getSanList();

            $key =
                generateRSAKey(
                    $bits
                );

            $certResult =
                generateSelfSignedCertificate(
                    $subject,
                    $key,
                    $sanLines,
                    $days
                );

            $privatePem =
                exportPrivateKey(
                    $key,
                    $password
                );

            $base =
                safeFilename(
                    $subject['CN']
                );

            jsonResponse(
                true,
                'Self-signed certificate and private key generated.',
                [
                    'data' => [

                        'type' =>
                            'self_signed',

                        'common_name' =>
                            $subject['CN'],

                        'validity_days' =>
                            $days,

                        'private_key' => [

                            'filename' =>
                                $base .
                                '.key.pem',

                            'content' =>
                                $privatePem
                        ],

                        'certificate' => [

                            'filename' =>
                                $base .
                                '.crt.pem',

                            'content' =>
                                $certResult['pem']
                        ]
                    ]
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Decode certificate
        |--------------------------------------------------------------------------
        */

        if (
            $action ===
            'decode_certificate'
        ) {

            $pem =
                getInputText(
                    'certificate_text',
                    'certificate_file'
                );

            if ($pem === '') {

                throw new RuntimeException(
                    'Please paste or upload a certificate.'
                );
            }

            $result =
                decodeCertificate(
                    $pem
                );

            jsonResponse(
                true,
                'Certificate decoded.',
                [
                    'data' =>
                        $result
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Decode CSR
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'decode_csr'
        ) {

            $pem =
                getInputText(
                    'csr_text',
                    'csr_file'
                );

            if ($pem === '') {

                throw new RuntimeException(
                    'Please paste or upload a CSR.'
                );
            }

            $result =
                decodeCSR(
                    $pem
                );

            jsonResponse(
                true,
                'CSR decoded.',
                [
                    'data' =>
                        $result
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Inspect private key
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'inspect_key'
        ) {

            $pem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $password =
                $_POST['key_password']
                ?? '';

            if ($pem === '') {

                throw new RuntimeException(
                    'Please paste or upload a private key.'
                );
            }

            $result =
                inspectPrivateKey(
                    $pem,
                    $password
                );

            jsonResponse(
                true,
                'Private key decoded.',
                [
                    'data' => [

                        'type' =>
                            $result['type'],

                        'bits' =>
                            $result['bits']
                    ]
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Decrypt private key
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'decrypt_key'
        ) {

            $pem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $password =
                $_POST['key_password']
                ?? '';

            if ($pem === '') {

                throw new RuntimeException(
                    'Please provide an encrypted private key.'
                );
            }

            if ($password === '') {

                throw new RuntimeException(
                    'Private-key password is required.'
                );
            }

            $result =
                inspectPrivateKey(
                    $pem,
                    $password
                );

            $decrypted =
                exportPrivateKey(
                    $result['key'],
                    ''
                );

            downloadText(
                'decrypted-private-key.pem',
                $decrypted
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Re-encrypt private key
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'encrypt_key'
        ) {

            $pem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $oldPassword =
                $_POST['old_password']
                ?? '';

            $newPassword =
                $_POST['new_password']
                ?? '';

            if ($pem === '') {

                throw new RuntimeException(
                    'Please provide a private key.'
                );
            }

            if ($newPassword === '') {

                throw new RuntimeException(
                    'New password is required.'
                );
            }

            $result =
                inspectPrivateKey(
                    $pem,
                    $oldPassword
                );

            $encrypted =
                exportPrivateKey(
                    $result['key'],
                    $newPassword
                );

            downloadText(
                'encrypted-private-key.pem',
                $encrypted
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Certificate / Key match
        |--------------------------------------------------------------------------
        */

        if (
            $action ===
            'match_certificate_key'
        ) {

            $certPem =
                getInputText(
                    'certificate_text',
                    'certificate_file'
                );

            $keyPem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $keyPassword =
                $_POST['key_password']
                ?? '';

            if (
                $certPem === '' ||
                $keyPem === ''
            ) {

                throw new RuntimeException(
                    'Both certificate and private key are required.'
                );
            }

            $cert =
                openssl_x509_read(
                    cleanPem($certPem)
                );

            if (!$cert) {

                throw new RuntimeException(
                    'Invalid certificate.'
                );
            }

            $keyResult =
                inspectPrivateKey(
                    $keyPem,
                    $keyPassword
                );

            $certFp =
                publicKeyFingerprintFromCertificate(
                    $cert
                );

            $keyFp =
                publicKeyFingerprintFromKey(
                    $keyResult['key']
                );

            $match =
                hash_equals(
                    $certFp,
                    $keyFp
                );

            jsonResponse(
                true,
                $match
                    ? 'Certificate and private key MATCH.'
                    : 'Certificate and private key DO NOT MATCH.',
                [
                    'data' => [

                        'match' =>
                            $match,

                        'certificate_public_key_sha256' =>
                            $certFp,

                        'private_key_public_key_sha256' =>
                            $keyFp
                    ]
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | CSR / Key match
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'match_csr_key'
        ) {

            $csrPem =
                getInputText(
                    'csr_text',
                    'csr_file'
                );

            $keyPem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $keyPassword =
                $_POST['key_password']
                ?? '';

            if (
                $csrPem === '' ||
                $keyPem === ''
            ) {

                throw new RuntimeException(
                    'Both CSR and private key are required.'
                );
            }

            $keyResult =
                inspectPrivateKey(
                    $keyPem,
                    $keyPassword
                );

            $csrFp =
                publicKeyFingerprintFromCSR(
                    cleanPem($csrPem)
                );

            $keyFp =
                publicKeyFingerprintFromKey(
                    $keyResult['key']
                );

            $match =
                hash_equals(
                    $csrFp,
                    $keyFp
                );

            jsonResponse(
                true,
                $match
                    ? 'CSR and private key MATCH.'
                    : 'CSR and private key DO NOT MATCH.',
                [
                    'data' => [

                        'match' =>
                            $match,

                        'csr_public_key_sha256' =>
                            $csrFp,

                        'private_key_public_key_sha256' =>
                            $keyFp
                    ]
                ]
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Generate PFX / PKCS#12
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'generate_pfx'
        ) {

            $certPem =
                getInputText(
                    'certificate_text',
                    'certificate_file'
                );

            $keyPem =
                getInputText(
                    'key_text',
                    'key_file'
                );

            $chainPem =
                trim(
                    $_POST['chain_text']
                    ?? ''
                );

            $keyPassword =
                $_POST['key_password']
                ?? '';

            $pfxPassword =
                $_POST['pfx_password']
                ?? '';

            $friendlyName =
                trim(
                    $_POST['friendly_name']
                    ?? 'SSL Certificate'
                );

            if (
                $certPem === '' ||
                $keyPem === ''
            ) {

                throw new RuntimeException(
                    'Certificate and private key are required.'
                );
            }

            if ($pfxPassword === '') {

                throw new RuntimeException(
                    'PFX password is required.'
                );
            }

            $cert =
                openssl_x509_read(
                    cleanPem($certPem)
                );

            if (!$cert) {

                throw new RuntimeException(
                    'Invalid certificate.'
                );
            }

            $keyResult =
                inspectPrivateKey(
                    $keyPem,
                    $keyPassword
                );

            /*
            |--------------------------------------------------------------------------
            | Verify certificate/key match before PFX
            |--------------------------------------------------------------------------
            */

            $certFp =
                publicKeyFingerprintFromCertificate(
                    $cert
                );

            $keyFp =
                publicKeyFingerprintFromKey(
                    $keyResult['key']
                );

            if (
                !hash_equals(
                    $certFp,
                    $keyFp
                )
            ) {

                throw new RuntimeException(
                    'Certificate and private key do not match.'
                );
            }

            $options = [

                'friendly_name' =>
                    $friendlyName
            ];

            /*
            |--------------------------------------------------------------------------
            | Optional chain
            |--------------------------------------------------------------------------
            */

            if ($chainPem !== '') {

                $chainCerts = [];

                preg_match_all(
                    '/-----BEGIN CERTIFICATE-----.*?-----END CERTIFICATE-----/s',
                    $chainPem,
                    $matches
                );

                foreach (
                    $matches[0] ?? []
                    as $chain
                ) {

                    $chainCert =
                        @openssl_x509_read(
                            $chain
                        );

                    if ($chainCert) {

                        $chainCerts[] =
                            $chainCert;
                    }
                }

                if ($chainCerts) {

                    $options['extracerts'] =
                        $chainCerts;
                }
            }

            $pfx = '';

            if (
                !openssl_pkcs12_export(
                    $cert,
                    $pfx,
                    $keyResult['key'],
                    $pfxPassword,
                    $options
                )
            ) {

                throw new RuntimeException(
                    opensslErrorText()
                );
            }

            downloadBinary(
                'certificate-bundle.pfx',
                $pfx,
                'application/x-pkcs12'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Download report
        |--------------------------------------------------------------------------
        */

        if (
            $action === 'download_report'
        ) {

            $report =
                $_POST['report']
                ?? '';

            if ($report === '') {

                throw new RuntimeException(
                    'Report is empty.'
                );
            }

            downloadText(
                'ssl-certificate-report.txt',
                $report,
                'text/plain; charset=utf-8'
            );
        }

        /*
        |--------------------------------------------------------------------------
        | Unknown action
        |--------------------------------------------------------------------------
        */

        if ($action !== '') {

            jsonResponse(
                false,
                'Unknown action.'
            );
        }

    } catch (Throwable $e) {

        /*
        |--------------------------------------------------------------------------
        | AJAX actions return JSON errors
        |--------------------------------------------------------------------------
        */

        $jsonActions = [

            'generate_csr',

            'generate_self_signed',

            'decode_certificate',

            'decode_csr',

            'inspect_key',

            'match_certificate_key',

            'match_csr_key'
        ];

        if (
            in_array(
                $action,
                $jsonActions,
                true
            )
        ) {

            jsonResponse(
                false,
                $e->getMessage()
            );
        }

        die(
            '<pre style="' .
            'font-family:monospace;' .
            'padding:30px;' .
            'color:#b91c1c;' .
            'white-space:pre-wrap;">' .
            h($e->getMessage()) .
            '</pre>'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Layout
|--------------------------------------------------------------------------
*/

require_once __DIR__ .
    '/includes/header.php';

require_once __DIR__ .
    '/includes/sidebar.php';

?>

<style>

.ssl-page {
    position: fixed;
    left: 250px;
    right: 0;
    top: var(--header-height, 60px);
    bottom: 0;

    display: flex;
    flex-direction: column;

    background: var(--bg-main);

    overflow: hidden;

    transition: .3s ease;
}

body.sidebar-collapsed .ssl-page {
    left: 72px;
}

.ssl-topbar {
    min-height: 64px;
    height: 64px;

    background: var(--bg-content);

    border-bottom: 1px solid var(--border-color);

    display: flex;
    align-items: center;
    justify-content: space-between;

    padding: 0 22px;
}

.ssl-title {
    font-size: 18px;
    font-weight: 750;
    color: var(--text-primary);
}

.ssl-subtitle {
    color: var(--text-muted);
    font-size: 11px;
    margin-top: 3px;
}

.ssl-tabs {
    display: flex;
    gap: 5px;

    padding: 12px 18px 0;

    background: var(--bg-content);

    border-bottom: 1px solid var(--border-color);

    overflow-x: auto;
}

.ssl-tab {
    border: 0;
    background: transparent;

    padding: 11px 15px;

    border-radius: 8px 8px 0 0;

    font-family: inherit;
    font-size: 12px;
    font-weight: 700;

    color: var(--text-secondary);

    cursor: pointer;

    white-space: nowrap;
}

.ssl-tab:hover {
    background: var(--hover-bg);
}

.ssl-tab.active {
    color: #2563EB;
    background: #EFF6FF;
}

[data-theme="dark"] .ssl-tab.active {
    color: #93C5FD;
    background: rgba(37,99,235,.22);
}

.ssl-content {
    flex: 1;
    min-height: 0;

    overflow: auto;

    padding: 20px;
}

.ssl-panel {
    display: none;

    max-width: 1250px;

    margin: 0 auto;
}

.ssl-panel.active {
    display: block;
}

.ssl-grid {
    display: grid;

    grid-template-columns:
        repeat(2, minmax(0, 1fr));

    gap: 16px;
}

.ssl-card {
    background: var(--bg-content);

    border: 1px solid var(--border-color);

    border-radius: 12px;

    padding: 18px;

    box-shadow:
        0 2px 10px
        rgba(15,23,42,.04);
}

.ssl-card.full {
    grid-column: 1 / -1;
}

.ssl-card h3 {
    margin: 0 0 4px;

    font-size: 14px;

    color: var(--text-primary);
}

.ssl-card-desc {
    color: var(--text-muted);

    font-size: 11px;

    margin-bottom: 16px;
}

.ssl-row {
    display: grid;

    grid-template-columns:
        repeat(2, minmax(0,1fr));

    gap: 10px;
}

.ssl-row-3 {
    display: grid;

    grid-template-columns:
        repeat(3, minmax(0,1fr));

    gap: 10px;
}

.ssl-field {
    margin-bottom: 12px;
}

.ssl-field label {
    display: block;

    margin-bottom: 5px;

    font-size: 10.5px;

    text-transform: uppercase;

    letter-spacing: .04em;

    color: var(--text-secondary);

    font-weight: 750;
}

.ssl-field input,
.ssl-field select,
.ssl-field textarea {
    width: 100%;

    box-sizing: border-box;

    border: 1px solid var(--border-color);

    background: var(--hover-bg);

    border-radius: 8px;

    padding: 9px 10px;

    font-family: inherit;

    font-size: 12px;

    color: var(--text-primary);
}

.ssl-field textarea {
    min-height: 210px;

    resize: vertical;

    font-family:
        Consolas,
        Monaco,
        monospace;

    font-size: 11px;
}

.ssl-field input:focus,
.ssl-field select:focus,
.ssl-field textarea:focus {
    outline: none;

    background: var(--bg-content);

    border-color: #2563EB;

    box-shadow:
        0 0 0 3px
        rgba(37,99,235,.10);
}

.ssl-btn {
    border: 1px solid var(--border-color);

    background: var(--bg-content);

    border-radius: 8px;

    padding: 9px 13px;

    font-family: inherit;

    font-size: 12px;

    font-weight: 700;

    color: var(--text-primary);

    cursor: pointer;
}

.ssl-btn:hover {
    background: var(--hover-bg);
}

.ssl-btn-primary {
    background: #2563EB;

    border-color: #2563EB;

    color: #fff;
}

.ssl-btn-primary:hover {
    background: #1D4ED8;
}

.ssl-btn-success {
    background: #10B981;

    border-color: #10B981;

    color: #fff;
}

.ssl-btn-success:hover {
    background: #059669;
}

.ssl-btn-danger {
    background: #EF4444;

    border-color: #EF4444;

    color: #fff;
}

.ssl-btn-danger:hover {
    background: #DC2626;
}

.ssl-actions {
    display: flex;

    flex-wrap: wrap;

    gap: 7px;

    margin-top: 10px;
}

.san-list {
    display: flex;

    flex-direction: column;

    gap: 7px;
}

.san-row {
    display: grid;

    grid-template-columns:
        100px minmax(0,1fr) auto;

    gap: 7px;
}

.san-row select,
.san-row input {
    border: 1px solid var(--border-color);

    border-radius: 8px;

    padding: 8px;

    background: var(--hover-bg);

    font-family: inherit;

    font-size: 12px;
}

.san-remove {
    border: 1px solid #FECACA;

    background: #FEF2F2;

    color: #DC2626;

    border-radius: 7px;

    cursor: pointer;

    padding: 0 10px;
}

[data-theme="dark"] .san-remove {
    border-color: rgba(239,68,68,.35);
    background: rgba(239,68,68,.15);
    color: #FCA5A5;
}

.ssl-result {
    margin-top: 14px;

    display: none;

    background: #0F172A;

    color: #E2E8F0;

    border-radius: 10px;

    padding: 15px;

    overflow: auto;
}

.ssl-result pre {
    margin: 0;

    white-space: pre-wrap;

    word-break: break-word;

    font-family:
        Consolas,
        Monaco,
        monospace;

    font-size: 11px;

    line-height: 1.6;
}

.ssl-alert {
    border-radius: 9px;

    padding: 11px 13px;

    margin-bottom: 14px;

    font-size: 12px;
}

.ssl-alert-info {
    background: #EFF6FF;

    color: #1D4ED8;

    border: 1px solid #BFDBFE;
}

.ssl-alert-warning {
    background: #FFFBEB;

    color: #92400E;

    border: 1px solid #FDE68A;
}

[data-theme="dark"] .ssl-alert-info {
    background: rgba(37,99,235,.15);
    color: #93C5FD;
    border-color: rgba(59,130,246,.35);
}

[data-theme="dark"] .ssl-alert-warning {
    background: rgba(217,119,6,.15);
    color: #FBBF24;
    border-color: rgba(251,191,36,.35);
}

.ssl-file {
    border: 1px dashed #CBD5E1 !important;

    background: var(--bg-content) !important;
}

/*
|--------------------------------------------------------------------------
| Generated file display
|--------------------------------------------------------------------------
*/

.ssl-generated {
    display: none;

    margin-top: 16px;

    border: 1px solid #D1D5DB;

    border-radius: 12px;

    background: var(--bg-content);

    overflow: hidden;
}

.ssl-generated-header {
    padding: 12px 15px;

    background: var(--hover-bg);

    border-bottom: 1px solid var(--border-color);

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 10px;
}

.ssl-generated-title {
    font-size: 13px;

    font-weight: 750;

    color: var(--text-primary);
}

.ssl-generated-subtitle {
    color: var(--text-secondary);

    font-size: 11px;

    margin-top: 3px;
}

.ssl-generated-file {
    border-bottom: 1px solid var(--border-color);
}

.ssl-generated-file:last-child {
    border-bottom: 0;
}

.ssl-generated-file-header {
    padding: 10px 14px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 10px;

    background: var(--hover-bg);
}

.ssl-generated-file-name {
    font-size: 11px;

    font-weight: 750;

    color: var(--text-primary);

    font-family:
        Consolas,
        Monaco,
        monospace;

    word-break: break-all;
}

.ssl-generated-actions {
    display: flex;

    gap: 6px;

    flex-wrap: wrap;

    flex-shrink: 0;
}

.ssl-generated-file textarea {
    display: block;

    width: 100%;

    min-height: 280px;

    box-sizing: border-box;

    border: 0;

    border-top: 1px solid var(--border-light);

    padding: 14px;

    resize: vertical;

    background: #0F172A;

    color: #E2E8F0;

    font-family:
        Consolas,
        Monaco,
        monospace;

    font-size: 11px;

    line-height: 1.55;

    outline: none;
}

.ssl-status {
    position: fixed;

    right: 22px;

    bottom: 22px;

    background: #111827;

    color: #fff;

    padding: 10px 14px;

    border-radius: 8px;

    font-size: 11px;

    display: none;

    z-index: 9999;
}

@media(max-width:1000px) {

    .ssl-page {
        left: 72px;
    }

    .ssl-grid {
        grid-template-columns: 1fr;
    }

    .ssl-card.full {
        grid-column: auto;
    }

    .ssl-row,
    .ssl-row-3 {
        grid-template-columns: 1fr;
    }
}

@media(max-width:650px) {

    .ssl-page {
        left: 0;
    }

    .ssl-content {
        padding: 12px;
    }

    .san-row {
        grid-template-columns:
            90px minmax(0,1fr) auto;
    }

    .ssl-generated-file-header {
        align-items: flex-start;

        flex-direction: column;
    }

}

</style>

<div class="ssl-page">

    <!-- ==========================================================
         TOP BAR
    =========================================================== -->

    <div class="ssl-topbar">

        <div>

            <div class="ssl-title">
                SSL / TLS Certificate Manager
            </div>

            <div class="ssl-subtitle">

                Offline certificate,
                CSR, RSA key and
                PKCS#12 utility
                —
                <?= h($current_user); ?>

            </div>

        </div>

    </div>

    <!-- ==========================================================
         TABS
    =========================================================== -->

    <div class="ssl-tabs">

        <button
            class="ssl-tab active"
            type="button"
            onclick="showTab('generate', this)"
        >
            Generate
        </button>

        <button
            class="ssl-tab"
            type="button"
            onclick="showTab('decode', this)"
        >
            Decode
        </button>

        <button
            class="ssl-tab"
            type="button"
            onclick="showTab('keys', this)"
        >
            Private Keys
        </button>

        <button
            class="ssl-tab"
            type="button"
            onclick="showTab('match', this)"
        >
            Match
        </button>

        <button
            class="ssl-tab"
            type="button"
            onclick="showTab('pfx', this)"
        >
            PFX / PKCS#12
        </button>

    </div>

    <div class="ssl-content">

        <!-- ======================================================
             GENERATE
        ======================================================= -->

        <div
            class="ssl-panel active"
            id="tab-generate"
        >

            <div class="ssl-alert ssl-alert-info">

                Everything generated here is processed locally
                by PHP/OpenSSL.

                Nothing is stored in your database.

                CSR and certificate generation displays both
                resulting files directly on this page.

            </div>

            <div class="ssl-grid">

                <!-- ==================================================
                     RSA PRIVATE KEY
                =================================================== -->

                <div class="ssl-card">

                    <h3>
                        RSA Private Key
                    </h3>

                    <div class="ssl-card-desc">
                        Generate a standalone RSA private key.
                    </div>

                    <form method="post">

                        <input
                            type="hidden"
                            name="action"
                            value="generate_key"
                        >

                        <div class="ssl-field">

                            <label>
                                Key Size
                            </label>

                            <select name="key_bits">

                                <option value="2048">
                                    RSA 2048
                                </option>

                                <option value="3072">
                                    RSA 3072
                                </option>

                                <option value="4096">
                                    RSA 4096
                                </option>

                            </select>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Optional Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                                autocomplete="new-password"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="submit"
                                class="ssl-btn ssl-btn-primary"
                            >
                                Generate RSA Key
                            </button>

                        </div>

                    </form>

                </div>

                <!-- ==================================================
                     CSR
                =================================================== -->

                <div class="ssl-card">

                    <h3>
                        Generate CSR
                    </h3>

                    <div class="ssl-card-desc">

                        Generate an RSA private key and
                        certificate signing request with SANs.

                    </div>

                    <form
                        id="generateCsrForm"
                    >

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    Common Name *
                                </label>

                                <input
                                    name="common_name"
                                    required
                                    placeholder="server.example.com"
                                >

                            </div>

                            <div class="ssl-field">

                                <label>
                                    Organization
                                </label>

                                <input
                                    name="organization"
                                    placeholder="Example Company"
                                >

                            </div>

                        </div>

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    Organizational Unit
                                </label>

                                <input
                                    name="organizational_unit"
                                    placeholder="IT"
                                >

                            </div>

                            <div class="ssl-field">

                                <label>
                                    Country
                                </label>

                                <input
                                    name="country"
                                    maxlength="2"
                                    placeholder="SA"
                                >

                            </div>

                        </div>

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    State / Province
                                </label>

                                <input name="state">

                            </div>

                            <div class="ssl-field">

                                <label>
                                    Locality / City
                                </label>

                                <input name="locality">

                            </div>

                        </div>

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    Email
                                </label>

                                <input
                                    name="email"
                                    type="email"
                                >

                            </div>

                            <div class="ssl-field">

                                <label>
                                    RSA Size
                                </label>

                                <select name="key_bits">

                                    <option value="2048">
                                        2048
                                    </option>

                                    <option value="3072">
                                        3072
                                    </option>

                                    <option value="4096">
                                        4096
                                    </option>

                                </select>

                            </div>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                                autocomplete="new-password"
                            >

                        </div>

                        <!-- SAN -->

                        <div class="ssl-field">

                            <label>
                                Subject Alternative Names
                            </label>

                            <div
                                class="san-list"
                                id="csrSanList"
                            >

                                <div class="san-row">

                                    <select name="san_type[]">

                                        <option value="DNS">
                                            DNS
                                        </option>

                                        <option value="IP">
                                            IP
                                        </option>

                                        <option value="EMAIL">
                                            Email
                                        </option>

                                        <option value="URI">
                                            URI
                                        </option>

                                    </select>

                                    <input
                                        name="san_value[]"
                                        placeholder="server.example.com"
                                    >

                                    <button
                                        type="button"
                                        class="san-remove"
                                        onclick="removeSan(this)"
                                    >
                                        ×
                                    </button>

                                </div>

                            </div>

                            <div class="ssl-actions">

                                <button
                                    type="button"
                                    class="ssl-btn"
                                    onclick="addSan('csrSanList')"
                                >
                                    + Add SAN
                                </button>

                            </div>

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="generateCSR()"
                            >
                                Generate CSR + Key
                            </button>

                        </div>

                    </form>

                    <!-- GENERATED CSR FILES -->

                    <div
                        id="csrGenerated"
                        class="ssl-generated"
                    >

                        <div class="ssl-generated-header">

                            <div>

                                <div class="ssl-generated-title">
                                    CSR + Private Key Generated
                                </div>

                                <div class="ssl-generated-subtitle">

                                    Nothing was saved.
                                    Both files are shown below.

                                </div>

                            </div>

                        </div>

                        <div id="csrGeneratedFiles"></div>

                    </div>

                </div>

                <!-- ==================================================
                     SELF SIGNED
                =================================================== -->

                <div class="ssl-card">

                    <h3>
                        Self-Signed Certificate
                    </h3>

                    <div class="ssl-card-desc">

                        Generate a self-signed certificate
                        and matching RSA private key.

                    </div>

                    <form
                        id="selfSignedForm"
                    >

                        <div class="ssl-field">

                            <label>
                                Common Name *
                            </label>

                            <input
                                name="common_name"
                                required
                                placeholder="server.example.com"
                            >

                        </div>

                        <div class="ssl-row-3">

                            <div class="ssl-field">

                                <label>
                                    Organization
                                </label>

                                <input name="organization">

                            </div>

                            <div class="ssl-field">

                                <label>
                                    Country
                                </label>

                                <input
                                    name="country"
                                    maxlength="2"
                                    placeholder="SA"
                                >

                            </div>

                            <div class="ssl-field">

                                <label>
                                    RSA Size
                                </label>

                                <select name="key_bits">

                                    <option value="2048">
                                        2048
                                    </option>

                                    <option value="3072">
                                        3072
                                    </option>

                                    <option value="4096">
                                        4096
                                    </option>

                                </select>

                            </div>

                        </div>

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    Validity Days
                                </label>

                                <input
                                    type="number"
                                    name="days"
                                    value="365"
                                    min="1"
                                    max="8250"
                                >

                            </div>

                            <div class="ssl-field">

                                <label>
                                    Private Key Password
                                </label>

                                <input
                                    type="password"
                                    name="key_password"
                                    autocomplete="new-password"
                                >

                            </div>

                        </div>

                        <!-- SAN -->

                        <div class="ssl-field">

                            <label>
                                Subject Alternative Names
                            </label>

                            <div
                                class="san-list"
                                id="selfSanList"
                            >

                                <div class="san-row">

                                    <select name="san_type[]">

                                        <option value="DNS">
                                            DNS
                                        </option>

                                        <option value="IP">
                                            IP
                                        </option>

                                        <option value="EMAIL">
                                            Email
                                        </option>

                                        <option value="URI">
                                            URI
                                        </option>

                                    </select>

                                    <input
                                        name="san_value[]"
                                        placeholder="server.example.com"
                                    >

                                    <button
                                        type="button"
                                        class="san-remove"
                                        onclick="removeSan(this)"
                                    >
                                        ×
                                    </button>

                                </div>

                            </div>

                            <div class="ssl-actions">

                                <button
                                    type="button"
                                    class="ssl-btn"
                                    onclick="addSan('selfSanList')"
                                >
                                    + Add SAN
                                </button>

                            </div>

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-success"
                                onclick="generateSelfSigned()"
                            >
                                Generate Self-Signed Certificate
                            </button>

                        </div>

                    </form>

                    <!-- GENERATED SELF SIGNED FILES -->

                    <div
                        id="selfSignedGenerated"
                        class="ssl-generated"
                    >

                        <div class="ssl-generated-header">

                            <div>

                                <div class="ssl-generated-title">
                                    Self-Signed Certificate + Private Key Generated
                                </div>

                                <div class="ssl-generated-subtitle">

                                    Nothing was saved.
                                    Both files are shown below.

                                </div>

                            </div>

                        </div>

                        <div
                            id="selfSignedGeneratedFiles"
                        ></div>

                    </div>

                </div>

            </div>

        </div>

        <!-- ======================================================
             DECODE
        ======================================================= -->

        <div
            class="ssl-panel"
            id="tab-decode"
        >

            <div class="ssl-grid">

                <!-- Certificate -->

                <div class="ssl-card">

                    <h3>
                        Certificate Decoder
                    </h3>

                    <div class="ssl-card-desc">

                        Inspect certificate metadata,
                        SANs, extensions, fingerprint,
                        issuer and validity.

                    </div>

                    <form
                        id="certificateDecodeForm"
                    >

                        <div class="ssl-field">

                            <label>
                                Certificate PEM
                            </label>

                            <textarea
                                name="certificate_text"
                                placeholder="-----BEGIN CERTIFICATE-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Or Upload Certificate
                            </label>

                            <input
                                class="ssl-file"
                                type="file"
                                name="certificate_file"
                                accept=".crt,.cer,.pem"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="decodeCertificate()"
                            >
                                Decode Certificate
                            </button>

                        </div>

                    </form>

                    <div
                        id="certificateResult"
                        class="ssl-result"
                    >
                        <pre></pre>
                    </div>

                </div>

                <!-- CSR -->

                <div class="ssl-card">

                    <h3>
                        CSR Decoder
                    </h3>

                    <div class="ssl-card-desc">

                        Inspect CSR subject and
                        public-key information.

                    </div>

                    <form
                        id="csrDecodeForm"
                    >

                        <div class="ssl-field">

                            <label>
                                CSR PEM
                            </label>

                            <textarea
                                name="csr_text"
                                placeholder="-----BEGIN CERTIFICATE REQUEST-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Or Upload CSR
                            </label>

                            <input
                                class="ssl-file"
                                type="file"
                                name="csr_file"
                                accept=".csr,.pem"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="decodeCSR()"
                            >
                                Decode CSR
                            </button>

                        </div>

                    </form>

                    <div
                        id="csrResult"
                        class="ssl-result"
                    >
                        <pre></pre>
                    </div>

                </div>

            </div>

        </div>

        <!-- ======================================================
             PRIVATE KEYS
        ======================================================= -->

        <div
            class="ssl-panel"
            id="tab-keys"
        >

            <div class="ssl-grid">

                <!-- Inspector -->

                <div class="ssl-card">

                    <h3>
                        Private Key Inspector
                    </h3>

                    <div class="ssl-card-desc">

                        Inspect private key type and size.

                    </div>

                    <form
                        id="keyInspectForm"
                    >

                        <div class="ssl-field">

                            <label>
                                Private Key
                            </label>

                            <textarea
                                name="key_text"
                                placeholder="-----BEGIN PRIVATE KEY-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Or Upload Key
                            </label>

                            <input
                                class="ssl-file"
                                type="file"
                                name="key_file"
                                accept=".key,.pem"
                            >

                        </div>

                        <div class="ssl-field">

                            <label>
                                Password if encrypted
                            </label>

                            <input
                                type="password"
                                name="key_password"
                                autocomplete="new-password"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="inspectKey()"
                            >
                                Inspect Key
                            </button>

                        </div>

                    </form>

                    <div
                        id="keyResult"
                        class="ssl-result"
                    >
                        <pre></pre>
                    </div>

                </div>

                <!-- Decrypt -->

                <div class="ssl-card">

                    <h3>
                        Decrypt Private Key
                    </h3>

                    <div class="ssl-card-desc">

                        Unlock an encrypted PEM private key
                        and download an unencrypted PEM copy.

                    </div>

                    <form method="post">

                        <input
                            type="hidden"
                            name="action"
                            value="decrypt_key"
                        >

                        <div class="ssl-field">

                            <label>
                                Encrypted Private Key
                            </label>

                            <textarea
                                name="key_text"
                                placeholder="-----BEGIN ENCRYPTED PRIVATE KEY-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                                autocomplete="new-password"
                                required
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="submit"
                                class="ssl-btn ssl-btn-danger"
                            >
                                Decrypt & Download
                            </button>

                        </div>

                    </form>

                </div>

                <!-- Re-encrypt -->

                <div class="ssl-card full">

                    <h3>
                        Change Private Key Password
                    </h3>

                    <div class="ssl-card-desc">

                        Change an encrypted private-key password
                        without storing the key.

                    </div>

                    <form method="post">

                        <input
                            type="hidden"
                            name="action"
                            value="encrypt_key"
                        >

                        <div class="ssl-row">

                            <div class="ssl-field">

                                <label>
                                    Private Key PEM
                                </label>

                                <textarea
                                    name="key_text"
                                    placeholder="-----BEGIN PRIVATE KEY-----"
                                ></textarea>

                            </div>

                            <div>

                                <div class="ssl-field">

                                    <label>
                                        Old Password
                                    </label>

                                    <input
                                        type="password"
                                        name="old_password"
                                        autocomplete="new-password"
                                    >

                                </div>

                                <div class="ssl-field">

                                    <label>
                                        New Password
                                    </label>

                                    <input
                                        type="password"
                                        name="new_password"
                                        required
                                        autocomplete="new-password"
                                    >

                                </div>

                                <button
                                    type="submit"
                                    class="ssl-btn ssl-btn-primary"
                                >
                                    Re-encrypt & Download
                                </button>

                            </div>

                        </div>

                    </form>

                </div>

            </div>

        </div>

        <!-- ======================================================
             MATCH
        ======================================================= -->

        <div
            class="ssl-panel"
            id="tab-match"
        >

            <div class="ssl-grid">

                <!-- Certificate / Key -->

                <div class="ssl-card">

                    <h3>
                        Certificate ↔ Private Key
                    </h3>

                    <div class="ssl-card-desc">

                        Verify whether the certificate belongs
                        to the private key.

                    </div>

                    <form
                        id="certKeyMatchForm"
                    >

                        <div class="ssl-field">

                            <label>
                                Certificate
                            </label>

                            <textarea
                                name="certificate_text"
                                placeholder="-----BEGIN CERTIFICATE-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key
                            </label>

                            <textarea
                                name="key_text"
                                placeholder="-----BEGIN PRIVATE KEY-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="matchCertificateKey()"
                            >
                                Check Match
                            </button>

                        </div>

                    </form>

                    <div
                        id="certKeyResult"
                        class="ssl-result"
                    >
                        <pre></pre>
                    </div>

                </div>

                <!-- CSR / Key -->

                <div class="ssl-card">

                    <h3>
                        CSR ↔ Private Key
                    </h3>

                    <div class="ssl-card-desc">

                        Verify whether the CSR was generated
                        from this private key.

                    </div>

                    <form
                        id="csrKeyMatchForm"
                    >

                        <div class="ssl-field">

                            <label>
                                CSR
                            </label>

                            <textarea
                                name="csr_text"
                                placeholder="-----BEGIN CERTIFICATE REQUEST-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key
                            </label>

                            <textarea
                                name="key_text"
                                placeholder="-----BEGIN PRIVATE KEY-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                            >

                        </div>

                        <div class="ssl-actions">

                            <button
                                type="button"
                                class="ssl-btn ssl-btn-primary"
                                onclick="matchCSRKey()"
                            >
                                Check Match
                            </button>

                        </div>

                    </form>

                    <div
                        id="csrKeyResult"
                        class="ssl-result"
                    >
                        <pre></pre>
                    </div>

                </div>

            </div>

        </div>

        <!-- ======================================================
             PFX
        ======================================================= -->

        <div
            class="ssl-panel"
            id="tab-pfx"
        >

            <div class="ssl-card">

                <h3>
                    PKCS#12 / PFX Generator
                </h3>

                <div class="ssl-card-desc">

                    Create a .pfx/.p12 bundle containing
                    a certificate, private key and optional
                    certificate chain.

                </div>

                <div class="ssl-alert ssl-alert-warning">

                    The PFX password protects the resulting
                    bundle. Keep the password secure.

                </div>

                <form method="post">

                    <input
                        type="hidden"
                        name="action"
                        value="generate_pfx"
                    >

                    <div class="ssl-row">

                        <div class="ssl-field">

                            <label>
                                Certificate PEM
                            </label>

                            <textarea
                                name="certificate_text"
                                placeholder="-----BEGIN CERTIFICATE-----"
                            ></textarea>

                        </div>

                        <div class="ssl-field">

                            <label>
                                Private Key PEM
                            </label>

                            <textarea
                                name="key_text"
                                placeholder="-----BEGIN PRIVATE KEY-----"
                            ></textarea>

                        </div>

                    </div>

                    <div class="ssl-row">

                        <div class="ssl-field">

                            <label>
                                Private Key Password
                            </label>

                            <input
                                type="password"
                                name="key_password"
                            >

                        </div>

                        <div class="ssl-field">

                            <label>
                                PFX Password *
                            </label>

                            <input
                                type="password"
                                name="pfx_password"
                                required
                                autocomplete="new-password"
                            >

                        </div>

                    </div>

                    <div class="ssl-field">

                        <label>
                            Friendly Name
                        </label>

                        <input
                            name="friendly_name"
                            value="SSL Certificate"
                        >

                    </div>

                    <div class="ssl-field">

                        <label>
                            Optional Certificate Chain
                        </label>

                        <textarea
                            name="chain_text"
                            placeholder="Paste intermediate/root certificates here"
                        ></textarea>

                    </div>

                    <div class="ssl-actions">

                        <button
                            type="submit"
                            class="ssl-btn ssl-btn-primary"
                        >
                            Generate PFX / P12
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

<div
    id="sslStatus"
    class="ssl-status"
>
    Ready
</div>

<script>

/*
|--------------------------------------------------------------------------
| Tabs
|--------------------------------------------------------------------------
*/

function showTab(tab, button)
{
    document
        .querySelectorAll('.ssl-panel')
        .forEach(function(el) {

            el.classList.remove(
                'active'
            );

        });

    document
        .querySelectorAll('.ssl-tab')
        .forEach(function(el) {

            el.classList.remove(
                'active'
            );

        });

    const panel =
        document.getElementById(
            'tab-' + tab
        );

    if (panel) {

        panel.classList.add(
            'active'
        );
    }

    if (button) {

        button.classList.add(
            'active'
        );
    }
}

/*
|--------------------------------------------------------------------------
| SAN
|--------------------------------------------------------------------------
*/

function addSan(containerId)
{
    const container =
        document.getElementById(
            containerId
        );

    if (!container) {
        return;
    }

    const row =
        document.createElement(
            'div'
        );

    row.className =
        'san-row';

    row.innerHTML = `
        <select name="san_type[]">
            <option value="DNS">DNS</option>
            <option value="IP">IP</option>
            <option value="EMAIL">Email</option>
            <option value="URI">URI</option>
        </select>

        <input
            name="san_value[]"
            placeholder="server.example.com"
        >

        <button
            type="button"
            class="san-remove"
            onclick="removeSan(this)"
        >
            ×
        </button>
    `;

    container.appendChild(
        row
    );
}

function removeSan(button)
{
    const row =
        button.closest(
            '.san-row'
        );

    if (!row) {
        return;
    }

    const parent =
        row.parentElement;

    if (
        parent.children.length <= 1
    ) {

        const input =
            row.querySelector(
                'input'
            );

        if (input) {
            input.value = '';
        }

        return;
    }

    row.remove();
}

/*
|--------------------------------------------------------------------------
| Status
|--------------------------------------------------------------------------
*/

function showStatus(text)
{
    const el =
        document.getElementById(
            'sslStatus'
        );

    if (!el) {
        return;
    }

    el.textContent =
        text;

    el.style.display =
        'block';

    setTimeout(
        function() {

            el.style.display =
                'none';

        },
        2500
    );
}

/*
|--------------------------------------------------------------------------
| AJAX POST
|--------------------------------------------------------------------------
*/

async function postForm(
    form,
    action
) {

    const data =
        new FormData(
            form
        );

    data.append(
        'action',
        action
    );

    const response =
        await fetch(
            window.location.href,
            {
                method: 'POST',
                body: data,
                cache: 'no-store'
            }
        );

    const text =
        await response.text();

    let result;

    try {

        result =
            JSON.parse(
                text
            );

    } catch (error) {

        throw new Error(
            text ||
            'Server returned an invalid response.'
        );
    }

    return result;
}

/*
|--------------------------------------------------------------------------
| Generic JSON result
|--------------------------------------------------------------------------
*/

function printResult(
    elementId,
    data
) {

    const box =
        document.getElementById(
            elementId
        );

    if (!box) {
        return;
    }

    box.style.display =
        'block';

    box.querySelector(
        'pre'
    ).textContent =
        JSON.stringify(
            data,
            null,
            2
        );
}

/*
|--------------------------------------------------------------------------
| Generate CSR
|--------------------------------------------------------------------------
*/

async function generateCSR()
{
    const form =
        document.getElementById(
            'generateCsrForm'
        );

    if (!form) {
        return;
    }

    if (
        !form.checkValidity()
    ) {

        form.reportValidity();

        return;
    }

    showStatus(
        'Generating CSR and RSA key...'
    );

    try {

        const result =
            await postForm(
                form,
                'generate_csr'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        renderGeneratedFiles(
            'csrGenerated',
            'csrGeneratedFiles',
            [
                result.data.private_key,
                result.data.csr
            ]
        );

        showStatus(
            'CSR and key generated.'
        );

    } catch (error) {

        alert(
            error.message
        );

    }
}

/*
|--------------------------------------------------------------------------
| Generate Self Signed
|--------------------------------------------------------------------------
*/

async function generateSelfSigned()
{
    const form =
        document.getElementById(
            'selfSignedForm'
        );

    if (!form) {
        return;
    }

    if (
        !form.checkValidity()
    ) {

        form.reportValidity();

        return;
    }

    showStatus(
        'Generating self-signed certificate...'
    );

    try {

        const result =
            await postForm(
                form,
                'generate_self_signed'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        renderGeneratedFiles(
            'selfSignedGenerated',
            'selfSignedGeneratedFiles',
            [
                result.data.private_key,
                result.data.certificate
            ]
        );

        showStatus(
            'Certificate and key generated.'
        );

    } catch (error) {

        alert(
            error.message
        );
    }
}

/*
|--------------------------------------------------------------------------
| Render generated files
|--------------------------------------------------------------------------
*/

function renderGeneratedFiles(
    containerId,
    filesContainerId,
    files
) {

    const container =
        document.getElementById(
            containerId
        );

    const filesContainer =
        document.getElementById(
            filesContainerId
        );

    if (
        !container ||
        !filesContainer
    ) {

        return;
    }

    filesContainer.innerHTML =
        '';

    files.forEach(
        function(file) {

            if (
                !file ||
                !file.content
            ) {

                return;
            }

            const wrapper =
                document.createElement(
                    'div'
                );

            wrapper.className =
                'ssl-generated-file';

            /*
            |--------------------------------------------------------------------------
            | Header
            |--------------------------------------------------------------------------
            */

            const header =
                document.createElement(
                    'div'
                );

            header.className =
                'ssl-generated-file-header';

            /*
            |--------------------------------------------------------------------------
            | Filename
            |--------------------------------------------------------------------------
            */

            const filename =
                document.createElement(
                    'div'
                );

            filename.className =
                'ssl-generated-file-name';

            filename.textContent =
                file.filename;

            /*
            |--------------------------------------------------------------------------
            | Actions
            |--------------------------------------------------------------------------
            */

            const actions =
                document.createElement(
                    'div'
                );

            actions.className =
                'ssl-generated-actions';

            /*
            |--------------------------------------------------------------------------
            | Copy
            |--------------------------------------------------------------------------
            */

            const copyButton =
                document.createElement(
                    'button'
                );

            copyButton.type =
                'button';

            copyButton.className =
                'ssl-btn';

            copyButton.textContent =
                'Copy';

            copyButton.onclick =
                function() {

                    copyText(
                        file.content
                    );

                    showStatus(
                        file.filename +
                        ' copied.'
                    );
                };

            /*
            |--------------------------------------------------------------------------
            | Download
            |--------------------------------------------------------------------------
            */

            const downloadButton =
                document.createElement(
                    'button'
                );

            downloadButton.type =
                'button';

            downloadButton.className =
                'ssl-btn ssl-btn-primary';

            downloadButton.textContent =
                'Download';

            downloadButton.onclick =
                function() {

                    downloadGeneratedFile(
                        file.filename,
                        file.content
                    );
                };

            actions.appendChild(
                copyButton
            );

            actions.appendChild(
                downloadButton
            );

            header.appendChild(
                filename
            );

            header.appendChild(
                actions
            );

            /*
            |--------------------------------------------------------------------------
            | PEM text
            |--------------------------------------------------------------------------
            */

            const textarea =
                document.createElement(
                    'textarea'
                );

            textarea.readOnly =
                true;

            textarea.value =
                file.content;

            textarea.spellcheck =
                false;

            textarea.onclick =
                function() {

                    this.select();
                };

            wrapper.appendChild(
                header
            );

            wrapper.appendChild(
                textarea
            );

            filesContainer.appendChild(
                wrapper
            );
        }
    );

    container.style.display =
        'block';

    container.scrollIntoView(
        {
            behavior: 'smooth',
            block: 'nearest'
        }
    );
}

/*
|--------------------------------------------------------------------------
| Copy generated text
|--------------------------------------------------------------------------
*/

function copyText(text)
{
    if (
        navigator.clipboard &&
        window.isSecureContext
    ) {

        navigator.clipboard.writeText(
            text
        );

        return;
    }

    const textarea =
        document.createElement(
            'textarea'
        );

    textarea.value =
        text;

    textarea.style.position =
        'fixed';

    textarea.style.left =
        '-9999px';

    document.body.appendChild(
        textarea
    );

    textarea.select();

    try {

        document.execCommand(
            'copy'
        );

    } catch (e) {

        /*
        |--------------------------------------------------------------------------
        | Clipboard fallback failure
        |--------------------------------------------------------------------------
        */
    }

    textarea.remove();
}

/*
|--------------------------------------------------------------------------
| Browser download
|--------------------------------------------------------------------------
*/

function downloadGeneratedFile(
    filename,
    content
) {

    const blob =
        new Blob(
            [content],
            {
                type:
                    'application/x-pem-file;charset=utf-8'
            }
        );

    const url =
        URL.createObjectURL(
            blob
        );

    const link =
        document.createElement(
            'a'
        );

    link.href =
        url;

    link.download =
        filename;

    document.body.appendChild(
        link
    );

    link.click();

    link.remove();

    setTimeout(
        function() {

            URL.revokeObjectURL(
                url
            );

        },
        1000
    );
}

/*
|--------------------------------------------------------------------------
| Certificate decoder
|--------------------------------------------------------------------------
*/

async function decodeCertificate()
{
    const form =
        document.getElementById(
            'certificateDecodeForm'
        );

    showStatus(
        'Decoding certificate...'
    );

    try {

        const result =
            await postForm(
                form,
                'decode_certificate'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        printResult(
            'certificateResult',
            result.data
        );

    } catch (error) {

        alert(
            error.message
        );

    } finally {

        showStatus(
            'Ready'
        );
    }
}

/*
|--------------------------------------------------------------------------
| CSR decoder
|--------------------------------------------------------------------------
*/

async function decodeCSR()
{
    const form =
        document.getElementById(
            'csrDecodeForm'
        );

    showStatus(
        'Decoding CSR...'
    );

    try {

        const result =
            await postForm(
                form,
                'decode_csr'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        printResult(
            'csrResult',
            result.data
        );

    } catch (error) {

        alert(
            error.message
        );

    } finally {

        showStatus(
            'Ready'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Key inspector
|--------------------------------------------------------------------------
*/

async function inspectKey()
{
    const form =
        document.getElementById(
            'keyInspectForm'
        );

    showStatus(
        'Inspecting key...'
    );

    try {

        const result =
            await postForm(
                form,
                'inspect_key'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        printResult(
            'keyResult',
            result.data
        );

    } catch (error) {

        alert(
            error.message
        );

    } finally {

        showStatus(
            'Ready'
        );
    }
}

/*
|--------------------------------------------------------------------------
| Certificate / Key match
|--------------------------------------------------------------------------
*/

async function matchCertificateKey()
{
    const form =
        document.getElementById(
            'certKeyMatchForm'
        );

    showStatus(
        'Checking certificate/key...'
    );

    try {

        const result =
            await postForm(
                form,
                'match_certificate_key'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        printResult(
            'certKeyResult',
            result.data
        );

    } catch (error) {

        alert(
            error.message
        );

    } finally {

        showStatus(
            'Ready'
        );
    }
}

/*
|--------------------------------------------------------------------------
| CSR / Key match
|--------------------------------------------------------------------------
*/

async function matchCSRKey()
{
    const form =
        document.getElementById(
            'csrKeyMatchForm'
        );

    showStatus(
        'Checking CSR/key...'
    );

    try {

        const result =
            await postForm(
                form,
                'match_csr_key'
            );

        if (!result.success) {

            alert(
                result.message
            );

            return;
        }

        printResult(
            'csrKeyResult',
            result.data
        );

    } catch (error) {

        alert(
            error.message
        );

    } finally {

        showStatus(
            'Ready'
        );
    }
}

</script>

<?php

require_once __DIR__ .
    '/includes/footer.php';

?>