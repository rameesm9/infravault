<?php
session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('known_issues', 'can_view');


function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function kidIcon(string $name, string $class = 'kidi'): string
{
    $paths = [
        'alert'       => '<path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>',
        'plus'        => '<path d="M12 5v14M5 12h14"/>',
        'list'        => '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
        'folder'      => '<path d="M4 20h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-9.5L9 4H4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1Z"/>',
        'clock'       => '<circle cx="12" cy="12" r="9"/><polyline points="12 7 12 12 16 14"/>',
        'user'        => '<path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'history'     => '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/><path d="M12 7v5l3 2"/>',
        'edit'        => '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14.5 7.5 3 3"/>',
    ];
    $body = $paths[$name] ?? $paths['alert'];
    return '<svg class="' . h($class) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}

$current_user_id = (int) $_SESSION['user_id'];
$user_role = trim($_SESSION['role'] ?? '');

$userStmt = $pdo->prepare("SELECT first_name, team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_first_name = $userRecord['first_name'] ?? ($_SESSION['first_name'] ?? 'there');
$user_team = $userRecord['team'] ?? '';
$is_admin = strtolower($user_role) === 'admin';

$canView = hasRolePermission($pdo, $user_role, 'known_issue', 'can_view');
$canCreate = hasRolePermission($pdo, $user_role, 'known_issue', 'can_edit');
$canAudit = hasRolePermission($pdo, $user_role, 'known_issue', 'can_audit');

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view Known Issues.');
}

// Same visibility rule as known-issues.php's list: own issues, public issues,
// team issues matching the user's team, or multi-team issues the user's team
// is shared into. Admins/auditors bypass it and see everything.
$canSeeAll = $is_admin || $canAudit;
if ($canSeeAll) {
    $visWhere = '1=1';
    $visParams = [];
} else {
    $visWhere = "(
        owner_id = ?
        OR team_scoped_visibility = 'public'
        OR (team_scoped_visibility = 'team' AND owner_team = ?)
        OR (team_scoped_visibility = 'teams' AND id IN (
            SELECT issue_id FROM known_issue_teams WHERE team_name = ?
        ))
    )";
    $visParams = [$current_user_id, $user_team, $user_team];
}

$stats = [];
$totalStmt = $pdo->prepare("SELECT COUNT(*) FROM known_issues WHERE $visWhere");
$totalStmt->execute($visParams);
$stats['total'] = (int) $totalStmt->fetchColumn();

$statusStmt = $pdo->prepare("SELECT status, COUNT(*) c FROM known_issues WHERE $visWhere GROUP BY status");
$statusStmt->execute($visParams);
$statusCounts = $statusStmt->fetchAll(PDO::FETCH_KEY_PAIR);
$stats['open'] = (int) ($statusCounts['Open'] ?? 0);
$stats['in_progress'] = (int) ($statusCounts['In Progress'] ?? 0);
$stats['resolved'] = (int) ($statusCounts['Resolved'] ?? 0) + (int) ($statusCounts['Closed'] ?? 0);

$criticalStmt = $pdo->prepare("SELECT COUNT(*) FROM known_issues WHERE $visWhere AND severity = 'Critical'");
$criticalStmt->execute($visParams);
$stats['critical'] = (int) $criticalStmt->fetchColumn();

$myStmt = $pdo->prepare("SELECT COUNT(*) FROM known_issues WHERE owner_id = ?");
$myStmt->execute([$current_user_id]);
$stats['mine'] = (int) $myStmt->fetchColumn();

$updatedStmt = $pdo->prepare("SELECT COUNT(*) FROM known_issues WHERE $visWhere AND updated_at >= datetime('now', '-7 days')");
$updatedStmt->execute($visParams);
$stats['recently_updated'] = (int) $updatedStmt->fetchColumn();

$catStmt = $pdo->prepare("
    SELECT category, COUNT(*) c
    FROM known_issues
    WHERE $visWhere AND category IS NOT NULL AND TRIM(category) != ''
    GROUP BY category ORDER BY c DESC LIMIT 8
");
$catStmt->execute($visParams);
$stats['by_category'] = $catStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$recentStmt = $pdo->prepare("
    SELECT id, issue_number, title, severity, status, created_at
    FROM known_issues WHERE $visWhere ORDER BY created_at DESC LIMIT 6
");
$recentStmt->execute($visParams);
$stats['recent_issues'] = $recentStmt->fetchAll(PDO::FETCH_ASSOC);

$stats['recent_actions'] = [];
if ($canAudit) {
    $stats['recent_actions'] = $pdo->query("
        SELECT a.action, a.user_name, a.action_date, ki.id AS issue_id, ki.issue_number, ki.title
        FROM known_issue_audit a
        JOIN known_issues ki ON ki.id = a.issue_id
        ORDER BY a.action_date DESC
        LIMIT 8
    ")->fetchAll(PDO::FETCH_ASSOC);
}

$severityColor = [
    'Critical' => '#dc2626',
    'High'     => '#ea580c',
    'Medium'   => '#f59e0b',
    'Low'      => '#10b981',
];

$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

$page_title = "Known Issues Dashboard | InfraVault";
require 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/known-issues.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <!-- HERO -->
    <div class="kidash-hero">
        <div class="kidash-hero-text">
            <span class="kidash-eyebrow"><?php echo kidIcon('alert', 'kidi kidi-sm'); ?> Known Issues</span>
            <h1><?php echo $greeting; ?>, <?php echo h($user_first_name); ?>.</h1>
            <p>
                A shared log of recurring problems, their workarounds, and how they were resolved
                &mdash; so nobody has to re-diagnose the same issue twice.
                <?php if ($stats['open'] > 0): ?>
                    <strong><?php echo $stats['open']; ?> issue<?php echo $stats['open'] === 1 ? '' : 's'; ?></strong> currently open.
                <?php endif; ?>
            </p>
            <div class="kidash-hero-actions">
                <?php if ($canCreate): ?>
                    <a href="known-issues.php?action=create" class="kidash-btn kidash-btn-primary">
                        <?php echo kidIcon('plus'); ?> New Issue
                    </a>
                <?php endif; ?>
                <a href="known-issues.php" class="kidash-btn kidash-btn-ghost">
                    Browse Issues <?php echo kidIcon('arrow-right', 'kidi kidi-sm'); ?>
                </a>
            </div>
        </div>
        <div class="kidash-hero-icon"><?php echo kidIcon('alert', 'kidi kidi-hero'); ?></div>
    </div>

    <!-- KPI CARDS (known-issues.css) -->
    <div class="known-stats">
        <div class="known-stat-card">
            <span>Total Issues</span>
            <strong><?php echo $stats['total']; ?></strong>
        </div>
        <div class="known-stat-card open">
            <span>Open</span>
            <strong><?php echo $stats['open']; ?></strong>
        </div>
        <div class="known-stat-card investigating">
            <span>In Progress</span>
            <strong><?php echo $stats['in_progress']; ?></strong>
        </div>
        <div class="known-stat-card resolved">
            <span>Resolved / Closed</span>
            <strong><?php echo $stats['resolved']; ?></strong>
        </div>
        <div class="known-stat-card workaround">
            <span>Critical Severity</span>
            <strong><?php echo $stats['critical']; ?></strong>
        </div>
    </div>

    <div class="kidash-columns">

        <!-- LEFT COLUMN -->
        <div class="kidash-col-main">

            <?php if (!empty($stats['by_category'])): ?>
            <div class="kidash-panel">
                <div class="kidash-panel-head">
                    <?php echo kidIcon('folder', 'kidi kidi-sm'); ?>
                    <h2>Issues by Category</h2>
                </div>
                <div class="kidash-panel-body">
                    <?php
                    $catTotal = max(1, array_sum($stats['by_category']));
                    $catPalette = ['#2563eb', '#7c3aed', '#0d9488', '#d97706', '#dc2626', '#4338ca', '#0369a1', '#059669'];
                    $i = 0;
                    foreach ($stats['by_category'] as $cat => $count):
                        $pct = round(($count / $catTotal) * 100);
                        $color = $catPalette[$i % count($catPalette)];
                        $i++;
                    ?>
                        <div class="kidash-bar-row">
                            <div class="kidash-bar-label">
                                <span><?php echo h($cat); ?></span>
                                <strong><?php echo (int) $count; ?></strong>
                            </div>
                            <div class="kidash-bar-track">
                                <div class="kidash-bar-fill" style="width: <?php echo $pct; ?>%; background: <?php echo $color; ?>;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <div class="kidash-panel">
                <div class="kidash-panel-head">
                    <?php echo kidIcon('list', 'kidi kidi-sm'); ?>
                    <h2>Recent Issues</h2>
                </div>
                <div class="kidash-panel-body kidash-issue-list">
                    <?php if (empty($stats['recent_issues'])): ?>
                        <p class="muted">No issues logged yet.</p>
                    <?php else: ?>
                        <?php foreach ($stats['recent_issues'] as $issue): ?>
                            <a href="known-issues.php?action=view&id=<?php echo (int) $issue['id']; ?>" class="kidash-issue-item">
                                <span class="kidash-issue-dot" style="background: <?php echo $severityColor[$issue['severity']] ?? '#94a3b8'; ?>;"></span>
                                <span class="kidash-issue-body">
                                    <strong><?php echo h(substr($issue['title'], 0, 60)); ?></strong>
                                    <small><?php echo h($issue['issue_number']); ?> &middot; <?php echo h($issue['status']); ?> &middot; <?php echo date('M d, Y', strtotime($issue['created_at'])); ?></small>
                                </span>
                                <?php echo kidIcon('arrow-right', 'kidi kidi-sm'); ?>
                            </a>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>

        </div>

        <!-- RIGHT COLUMN -->
        <div class="kidash-col-side">

            <div class="kidash-panel">
                <div class="kidash-panel-head">
                    <h2>Quick Actions</h2>
                </div>
                <div class="kidash-panel-body kidash-actions-list">
                    <?php if ($canCreate): ?>
                        <a href="known-issues.php?action=create" class="kidash-action-item">
                            <span class="kidash-action-icon blue"><?php echo kidIcon('plus'); ?></span>
                            <span>
                                <strong>New Issue</strong>
                                <small>Log a new known issue</small>
                            </span>
                            <?php echo kidIcon('arrow-right', 'kidi kidi-sm'); ?>
                        </a>
                    <?php endif; ?>

                    <a href="known-issues.php" class="kidash-action-item">
                        <span class="kidash-action-icon violet"><?php echo kidIcon('list'); ?></span>
                        <span>
                            <strong>Browse All Issues</strong>
                            <small>Search and filter the full log</small>
                        </span>
                        <?php echo kidIcon('arrow-right', 'kidi kidi-sm'); ?>
                    </a>

                    <div class="kidash-action-item" style="cursor:default;">
                        <span class="kidash-action-icon teal"><?php echo kidIcon('user'); ?></span>
                        <span>
                            <strong><?php echo $stats['mine']; ?> issue<?php echo $stats['mine'] === 1 ? '' : 's'; ?></strong>
                            <small>Owned by you</small>
                        </span>
                    </div>

                    <div class="kidash-action-item" style="cursor:default;">
                        <span class="kidash-action-icon amber"><?php echo kidIcon('clock'); ?></span>
                        <span>
                            <strong><?php echo $stats['recently_updated']; ?> updated</strong>
                            <small>In the last 7 days</small>
                        </span>
                    </div>
                </div>
            </div>

            <?php if ($canAudit && !empty($stats['recent_actions'])): ?>
            <div class="kidash-panel">
                <div class="kidash-panel-head">
                    <?php echo kidIcon('history', 'kidi kidi-sm'); ?>
                    <h2>Recent Activity</h2>
                </div>
                <div class="kidash-panel-body kidash-timeline">
                    <?php foreach ($stats['recent_actions'] as $entry): ?>
                        <div class="kidash-timeline-item">
                            <span class="kidash-timeline-icon"><?php echo kidIcon('edit', 'kidi kidi-sm'); ?></span>
                            <div>
                                <div>
                                    <a href="known-issues.php?action=view&id=<?php echo (int) $entry['issue_id']; ?>"><?php echo h(substr($entry['title'], 0, 30)); ?></a>
                                    <span class="kidash-timeline-action"><?php echo h(ucwords(str_replace('_', ' ', strtolower($entry['action'])))); ?></span>
                                </div>
                                <small><?php echo h($entry['user_name']); ?> &middot; <?php echo date('M d, H:i', strtotime($entry['action_date'])); ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<style>
.kidi { width: 20px; height: 20px; display: inline-block; flex-shrink: 0; }
.kidi-sm { width: 16px; height: 16px; }
.kidi-hero { width: 120px; height: 120px; opacity: .15; stroke-width: 1; }

.kidash-hero {
    background: linear-gradient(135deg, #3f0d0d 0%, #b91c1c 100%);
    border-radius: 20px;
    padding: 36px 40px;
    margin-bottom: 24px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    position: relative;
    overflow: hidden;
}

.kidash-hero-text { max-width: 640px; z-index: 1; }

.kidash-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,.14);
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12.5px;
    font-weight: 600;
    letter-spacing: .02em;
    margin-bottom: 14px;
    color: #fca5a5;
}

.kidash-hero h1 { font-size: 30px; font-weight: 700; margin: 0 0 10px; color: #fff; }
.kidash-hero p { color: #fee2e2; font-size: 14.5px; line-height: 1.6; margin: 0 0 22px; }

.kidash-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }

.kidash-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 20px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    transition: .15s ease;
    border: 1px solid transparent;
}

.kidash-btn-primary { background: #dc2626; color: #fff; }
.kidash-btn-primary:hover { background: #b91c1c; }

.kidash-btn-ghost { background: rgba(255,255,255,.1); color: #fff; border-color: rgba(255,255,255,.25); }
.kidash-btn-ghost:hover { background: rgba(255,255,255,.18); }

.kidash-hero-icon { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); }

.kidash-columns {
    display: grid;
    grid-template-columns: 1.6fr 1fr;
    gap: 20px;
    align-items: start;
}

.kidash-panel {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
}

.kidash-panel-head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 18px 20px 0;
    color: var(--text-secondary);
}

.kidash-panel-head h2 { font-size: 15.5px; font-weight: 700; color: var(--text-primary); margin: 0; }

.kidash-panel-body { padding: 16px 20px 20px; }

.kidash-bar-row { margin-bottom: 14px; }
.kidash-bar-row:last-child { margin-bottom: 0; }

.kidash-bar-label {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 6px;
}

.kidash-bar-track { background: var(--hover-bg); border-radius: 8px; height: 8px; overflow: hidden; }
.kidash-bar-fill { height: 100%; border-radius: 8px; }

.kidash-issue-list { display: flex; flex-direction: column; gap: 4px; }

.kidash-issue-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 8px;
    border-radius: 8px;
    text-decoration: none;
    color: inherit;
}

.kidash-issue-item:hover { background: var(--hover-bg); }

.kidash-issue-dot { width: 9px; height: 9px; border-radius: 50%; flex-shrink: 0; }

.kidash-issue-body { flex: 1; min-width: 0; display: flex; flex-direction: column; }
.kidash-issue-body strong { font-size: 13.5px; color: var(--text-primary); }
.kidash-issue-body small { font-size: 12px; color: var(--text-muted); margin-top: 2px; }
.kidash-issue-item .kidi-sm { color: var(--text-muted); }

.kidash-actions-list { display: flex; flex-direction: column; gap: 10px; }

.kidash-action-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    text-decoration: none;
    color: inherit;
    border: 1px solid var(--border-color);
    transition: .15s ease;
}

a.kidash-action-item:hover { background: var(--hover-bg); border-color: var(--text-muted); }

.kidash-action-icon {
    width: 36px; height: 36px;
    border-radius: 9px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

.kidash-action-icon.blue { background: #dbeafe; color: #1d4ed8; }
.kidash-action-icon.violet { background: #ede9fe; color: #6d28d9; }
.kidash-action-icon.teal { background: #ccfbf1; color: #0f766e; }
.kidash-action-icon.amber { background: #fef3c7; color: #b45309; }

.kidash-action-item span:nth-child(2) { flex: 1; display: flex; flex-direction: column; }
.kidash-action-item strong { font-size: 13.5px; color: var(--text-primary); }
.kidash-action-item small { font-size: 12px; color: var(--text-muted); }
.kidash-action-item .kidi-sm { color: var(--text-muted); }

.kidash-timeline-item {
    display: flex;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border-light);
}

.kidash-timeline-item:last-child { border-bottom: none; padding-bottom: 0; }

.kidash-timeline-icon {
    width: 30px; height: 30px;
    border-radius: 50%;
    background: #fee2e2;
    color: #b91c1c;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

.kidash-timeline-item a { color: #dc2626; text-decoration: none; font-weight: 700; font-size: 13px; }
.kidash-timeline-action { font-size: 12.5px; color: var(--text-secondary); margin-left: 6px; }
.kidash-timeline-item small { color: var(--text-muted); font-size: 11.5px; }

@media (max-width: 900px) {
    .kidash-hero { flex-direction: column; align-items: flex-start; }
    .kidash-hero-icon { display: none; }
    .kidash-columns { grid-template-columns: 1fr; }
}
</style>

<?php require 'includes/footer.php'; ?>
