<?php
/**
 * Production / DR mapping -- which production component fails over to
 * what, how it replicates, and when it was last actually tested.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('dr_mapping', 'can_view');

$canEdit   = can('dr_mapping', 'can_edit');
$canDelete = can('dr_mapping', 'can_delete');
$canExport = can('dr_mapping', 'can_export');
$canAudit  = can('dr_mapping', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const DR_MODULE = 'dr_mapping';

$componentTypes  = ['Application', 'Web', 'Database', 'Load Balancer', 'Storage', 'Middleware', 'Batch', 'Integration'];
$replicationType = ['Data Guard', 'GoldenGate', 'Storage Replication', 'SRM', 'Backup / Restore', 'rsync', 'Application-level', 'None'];
$failoverTypes   = ['Manual', 'Semi-automatic', 'Automatic'];
$criticalities   = ['Tier 1', 'Tier 2', 'Tier 3', 'Tier 4'];
$testResults     = ['Passed', 'Passed with issues', 'Failed', 'Not tested'];
$replStatuses    = ['In Sync', 'Lagging', 'Broken', 'Not Configured'];
$statuses        = ['Active', 'Degraded', 'Decommissioned'];

$drFields = [
    'application'           => 'Application',
    'project'               => 'Project',
    'component_type'        => 'Component Type',
    'criticality'           => 'Criticality',
    'prod_site'             => 'Prod Site',
    'dr_site'               => 'DR Site',
    'prod_hostname'         => 'Prod Host',
    'dr_hostname'           => 'DR Host',
    'replication_type'      => 'Replication Type',
    'replication_status'    => 'Replication Status',
    'failover_type'         => 'Failover Type',
    'rpo_minutes'           => 'RPO (min)',
    'rto_minutes'           => 'RTO (min)',
    'last_dr_test'          => 'Last DR Test',
    'dr_test_result'        => 'Last Test Result',
    'next_dr_test'          => 'Next DR Test',
    'runbook_link'          => 'Runbook',
    'technical_owner'       => 'Technical Owner',
    'technical_owner_email' => 'Owner Email',
    'status'                => 'Status',
    'notes'                 => 'Notes',
];


/* ---------------- AJAX ---------------- */

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('dr_mapping', 'can_audit');
    echo platformHistoryHtml($pdo, DR_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}


/* ---------------- FILTERS ---------------- */

$q       = trim((string) ($_GET['q'] ?? ''));
$fType   = trim((string) ($_GET['f_type'] ?? ''));
$fCrit   = trim((string) ($_GET['f_crit'] ?? ''));
$fRepl   = trim((string) ($_GET['f_repl'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(application LIKE ? OR project LIKE ? OR prod_hostname LIKE ? OR dr_hostname LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fType !== '') { $where[] = 'component_type = ?';   $params[] = $fType; }
if ($fCrit !== '') { $where[] = 'criticality = ?';      $params[] = $fCrit; }
if ($fRepl !== '') { $where[] = 'replication_status = ?'; $params[] = $fRepl; }

$whereSql = implode(' AND ', $where);

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('dr_mapping', 'can_export');
    platformExportCsv($pdo, 'dr_mappings', $drFields, $whereSql, $params, 'dr_mapping');
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('dr_mapping', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);
        $data = [];
        foreach (array_keys($drFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        // Empty stays NULL rather than 0, so "not set" and "zero minutes"
        // remain distinguishable.
        $data['rpo_minutes'] = $data['rpo_minutes'] === '' ? null : (int) $data['rpo_minutes'];
        $data['rto_minutes'] = $data['rto_minutes'] === '' ? null : (int) $data['rto_minutes'];

        if ($data['application'] === '') {
            $err = 'Application is required.';
        } else {
            try {
                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM dr_mappings WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $pdo->prepare("UPDATE dr_mappings SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($data), $username, $id]);

                    platformLog($pdo, DR_MODULE, $id, 'UPDATED', $username,
                        "Updated mapping: {$data['application']}\n" . platformDiff($old, $data, $drFields));
                    $msg = 'Mapping updated.';
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $pdo->prepare("INSERT INTO dr_mappings ($cols, created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    platformLog($pdo, DR_MODULE, $id, 'CREATED', $username, "Created mapping: {$data['application']}");
                    $msg = 'Mapping added.';
                }
            } catch (Throwable $e) {
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('dr_mapping', 'can_delete');
        $id = (int) ($_POST['id'] ?? 0);

        $n = $pdo->prepare("SELECT application FROM dr_mappings WHERE id = ?");
        $n->execute([$id]);
        $name = (string) ($n->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM dr_mappings WHERE id = ?")->execute([$id]);
        platformLog($pdo, DR_MODULE, $id, 'DELETED', $username, "Deleted mapping: {$name}");
        $msg = 'Mapping deleted.';
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("SELECT * FROM dr_mappings WHERE $whereSql ORDER BY application, component_type");
$stmt->execute($params);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = count($rows);
$inSync = $broken = $tier1 = $overdue = 0;
$today = date('Y-m-d');

foreach ($rows as $r) {
    if ((string) $r['replication_status'] === 'In Sync') { $inSync++; }
    if ((string) $r['replication_status'] === 'Broken')  { $broken++; }
    if ((string) $r['criticality'] === 'Tier 1')         { $tier1++; }
    if (!empty($r['next_dr_test']) && $r['next_dr_test'] < $today) { $overdue++; }
}

$hostnames = platformHostnames($pdo);

$page_title = 'Production / DR Mapping | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">⇄</div>
            <div>
                <h1>Production / DR Mapping</h1>
                <p>What fails over to what, how it replicates, and when it was last actually tested.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="drOpen()">+ Add Mapping</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_type=<?= urlencode($fType) ?>&amp;f_crit=<?= urlencode($fCrit) ?>&amp;f_repl=<?= urlencode($fRepl) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="drHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $total ?></b><span>Mappings</span></div>
        <div class="plat-stat tone-ok"><b><?= $inSync ?></b><span>In Sync</span></div>
        <div class="plat-stat tone-crit"><b><?= $broken ?></b><span>Broken</span></div>
        <div class="plat-stat"><b><?= $tier1 ?></b><span>Tier 1</span></div>
        <div class="plat-stat tone-warn"><b><?= $overdue ?></b><span>DR Test Overdue</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search &amp; Filters</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Application, project, hostname…">
                </div>
                <div class="plat-field">
                    <label>Component</label>
                    <select name="f_type">
                        <option value="">All</option>
                        <?php foreach ($componentTypes as $t): ?><option value="<?= plat_h($t) ?>" <?= $fType === $t ? 'selected' : '' ?>><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Criticality</label>
                    <select name="f_crit">
                        <option value="">All</option>
                        <?php foreach ($criticalities as $c): ?><option value="<?= plat_h($c) ?>" <?= $fCrit === $c ? 'selected' : '' ?>><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Replication</label>
                    <select name="f_repl">
                        <option value="">All</option>
                        <?php foreach ($replStatuses as $s): ?><option value="<?= plat_h($s) ?>" <?= $fRepl === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="dr_mapping.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Mappings</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $total ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Application</th><th>Component</th><th>Production</th><th>DR</th>
                        <th>Replication</th><th>RPO / RTO</th><th>Last Test</th><th>Criticality</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$rows): ?>
                    <tr><td colspan="9"><p class="plat-empty">No DR mappings recorded yet.</p></td></tr>
                <?php else: foreach ($rows as $r): ?>
                    <?php
                        $testOverdue = !empty($r['next_dr_test']) && $r['next_dr_test'] < $today;
                        $resultTone  = match ((string) $r['dr_test_result']) {
                            'Passed'             => 'ok',
                            'Passed with issues' => 'warn',
                            'Failed'             => 'crit',
                            default              => 'neutral',
                        };
                    ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($r['application']) ?></span>
                            <span class="plat-sub"><?= plat_h($r['project'] ?: '—') ?></span>
                        </td>
                        <td><span class="plat-pill neutral"><?= plat_h($r['component_type'] ?: '—') ?></span></td>
                        <td>
                            <span class="plat-chip"><?= plat_h($r['prod_hostname'] ?: '—') ?></span>
                            <span class="plat-sub"><?= plat_h($r['prod_site']) ?></span>
                        </td>
                        <td>
                            <span class="plat-chip"><?= plat_h($r['dr_hostname'] ?: '—') ?></span>
                            <span class="plat-sub"><?= plat_h($r['dr_site']) ?></span>
                        </td>
                        <td>
                            <?= plat_h($r['replication_type'] ?: '—') ?>
                            <?php if ($r['replication_status']): ?>
                                <span class="plat-sub">
                                    <span class="plat-pill <?= platformStatusClass((string) $r['replication_status'] === 'In Sync' ? 'active' : ((string) $r['replication_status'] === 'Broken' ? 'failed' : 'warning')) ?>">
                                        <?= plat_h($r['replication_status']) ?>
                                    </span>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= $r['rpo_minutes'] !== null ? (int) $r['rpo_minutes'] . 'm' : '—' ?>
                            /
                            <?= $r['rto_minutes'] !== null ? (int) $r['rto_minutes'] . 'm' : '—' ?>
                        </td>
                        <td>
                            <?= plat_h($r['last_dr_test'] ?: '—') ?>
                            <?php if ($r['dr_test_result']): ?>
                                <span class="plat-sub"><span class="plat-pill <?= $resultTone ?>"><?= plat_h($r['dr_test_result']) ?></span></span>
                            <?php endif; ?>
                            <?php if ($testOverdue): ?>
                                <span class="plat-sub"><span class="plat-pill crit">Next due <?= plat_h($r['next_dr_test']) ?></span></span>
                            <?php endif; ?>
                        </td>
                        <td><span class="plat-pill <?= (string) $r['criticality'] === 'Tier 1' ? 'crit' : 'neutral' ?>"><?= plat_h($r['criticality'] ?: '—') ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='drOpen(<?= json_encode($r, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History"
                                        onclick="drHistory(<?= (int) $r['id'] ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="drDelete(<?= (int) $r['id'] ?>, '<?= plat_h(addslashes($r['application'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="plat-modal" id="drModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="drTitle">Add Mapping</h2>
            <button type="button" class="plat-close" onclick="platClose('drModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">One row per component that has a DR counterpart.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="dr_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Application *</label><input type="text" name="application" id="dr_application" required></div>
                <div class="plat-field"><label>Project</label><input type="text" name="project" id="dr_project"></div>
                <div class="plat-field"><label>Component Type</label>
                    <select name="component_type" id="dr_component_type">
                        <option value="">—</option>
                        <?php foreach ($componentTypes as $t): ?><option value="<?= plat_h($t) ?>"><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-section-title">Sites &amp; hosts</div>
                <div class="plat-field"><label>Prod Site</label><input type="text" name="prod_site" id="dr_prod_site"></div>
                <div class="plat-field"><label>Prod Host</label><input list="platHostnames" name="prod_hostname" id="dr_prod_hostname"></div>
                <div class="plat-field"><label>Criticality</label>
                    <select name="criticality" id="dr_criticality">
                        <option value="">—</option>
                        <?php foreach ($criticalities as $c): ?><option value="<?= plat_h($c) ?>"><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>DR Site</label><input type="text" name="dr_site" id="dr_dr_site"></div>
                <div class="plat-field"><label>DR Host</label><input list="platHostnames" name="dr_hostname" id="dr_dr_hostname"></div>
                <div class="plat-field"><label>Status</label>
                    <select name="status" id="dr_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-section-title">Replication &amp; objectives</div>
                <div class="plat-field"><label>Replication Type</label>
                    <select name="replication_type" id="dr_replication_type">
                        <option value="">—</option>
                        <?php foreach ($replicationType as $t): ?><option value="<?= plat_h($t) ?>"><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Replication Status</label>
                    <select name="replication_status" id="dr_replication_status">
                        <option value="">—</option>
                        <?php foreach ($replStatuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Failover Type</label>
                    <select name="failover_type" id="dr_failover_type">
                        <option value="">—</option>
                        <?php foreach ($failoverTypes as $f): ?><option value="<?= plat_h($f) ?>"><?= plat_h($f) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>RPO (minutes)</label><input type="number" name="rpo_minutes" id="dr_rpo_minutes" min="0" placeholder="blank = not set"></div>
                <div class="plat-field"><label>RTO (minutes)</label><input type="number" name="rto_minutes" id="dr_rto_minutes" min="0" placeholder="blank = not set"></div>
                <div class="plat-field"><label>Runbook Link</label><input type="text" name="runbook_link" id="dr_runbook_link"></div>

                <div class="plat-section-title">DR testing</div>
                <div class="plat-field"><label>Last DR Test</label><input type="date" name="last_dr_test" id="dr_last_dr_test"></div>
                <div class="plat-field"><label>Last Test Result</label>
                    <select name="dr_test_result" id="dr_dr_test_result">
                        <option value="">—</option>
                        <?php foreach ($testResults as $t): ?><option value="<?= plat_h($t) ?>"><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Next DR Test</label><input type="date" name="next_dr_test" id="dr_next_dr_test"></div>

                <div class="plat-section-title">Ownership</div>
                <div class="plat-field"><label>Technical Owner</label><input type="text" name="technical_owner" id="dr_technical_owner"></div>
                <div class="plat-field"><label>Owner Email</label><input type="email" name="technical_owner_email" id="dr_technical_owner_email"></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="dr_notes" rows="2"></textarea></div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('drModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Mapping</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="drHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="drHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('drHistModal')">&times;</button></div>
        <div id="drHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="drDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete mapping</h2>
            <button type="button" class="plat-close" onclick="platClose('drDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete the DR mapping for <strong id="drDelName"></strong>?</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="drDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('drDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<script>
const DR_FIELDS = <?= json_encode(array_keys($drFields)) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function drOpen(data) {
    const editing = !!data;
    document.getElementById('drTitle').innerText = editing ? 'Edit Mapping' : 'Add Mapping';
    document.getElementById('dr_id').value = editing ? data.id : '';

    DR_FIELDS.forEach(f => {
        const el = document.getElementById('dr_' + f);
        if (!el) return;
        el.value = editing ? (data[f] ?? '') : '';
    });

    platOpen('drModal');
}

function drHistory(id) {
    document.getElementById('drHistTitle').innerText = id ? 'Audit History — mapping #' + id : 'Module Audit History';
    document.getElementById('drHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('drHistModal');
    fetch('dr_mapping.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('drHistBody').innerHTML = h; })
        .catch(() => { document.getElementById('drHistBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function drDelete(id, name) {
    document.getElementById('drDelId').value = id;
    document.getElementById('drDelName').innerText = name;
    platOpen('drDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
