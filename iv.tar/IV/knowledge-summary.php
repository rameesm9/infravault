<?php
session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('knowledge', 'can_view');


function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/**
 * Small local icon set for this dashboard -- matches the inline-SVG,
 * stroke-based style already used across the app rather than pulling in
 * an icon font/library. Deliberately duplicated per-dashboard file
 * (see sop-summary.php) rather than shared, since each is self-contained.
 */
function kbIcon(string $name, string $class = 'kdi'): string
{
    $paths = [
        'book'        => '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
        'user-doc'    => '<path d="M9 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V11"/><path d="M9 2v5a2 2 0 0 0 2 2h5"/><circle cx="17" cy="6" r="3"/>',
        'edit'        => '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14.5 7.5 3 3"/>',
        'message'     => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
        'paperclip'   => '<path d="M21.44 11.05 12.25 20.24a5.5 5.5 0 0 1-7.78-7.78l9.19-9.19a3.67 3.67 0 0 1 5.19 5.19l-9.2 9.19a1.83 1.83 0 0 1-2.59-2.59l8.49-8.48"/>',
        'trend'       => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'plus'        => '<path d="M12 5v14M5 12h14"/>',
        'folder'      => '<path d="M4 20h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-9.5L9 4H4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1Z"/>',
        'award'       => '<circle cx="12" cy="8" r="6"/><path d="M8.2 13.6 6 22l6-3 6 3-2.2-8.4"/>',
        'library'     => '<path d="M3 3h4v18H3z"/><path d="M9 3h4v18H9z"/><path d="M16 3.5 20 5v16l-4-1.5Z"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'history'     => '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/><path d="M12 7v5l3 2"/>',
        'chat-dots'   => '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/><path d="M8 11.5h.01M12 11.5h.01M16 11.5h.01"/>',
    ];
    $body = $paths[$name] ?? $paths['book'];
    return '<svg class="' . h($class) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}

$current_user_id = (int)$_SESSION['user_id'];
$user_role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($user_role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

$userStmt = $pdo->prepare("SELECT first_name, team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';
$user_first_name = $userRecord['first_name'] ?? ($_SESSION['first_name'] ?? 'there');

$canView = hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_view');
$canCreate = hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_edit');
$canAudit = hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_audit');

if (!$is_admin && !$canView) {
    http_response_code(403);
    exit('You do not have permission to view Knowledge Base.');
}

$visibilityWhere = "
    created_by = ?
    OR (visibility = 'public')
    OR (visibility = 'team' AND owner_team = ?)
    OR (visibility = 'teams' AND id IN (SELECT kb_id FROM knowledge_base_teams WHERE team_name = ?))
";
$visibilityParams = [$current_user_id, $user_team, $user_team];

$stats = [];

$visibleStmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge_base WHERE $visibilityWhere");
$visibleStmt->execute($visibilityParams);
$stats['total_visible'] = (int) $visibleStmt->fetchColumn();

$scopeWhere = ($is_admin || $canAudit) ? '1=1' : $visibilityWhere;
$scopeParams = ($is_admin || $canAudit) ? [] : $visibilityParams;

$categoryStmt = $pdo->prepare("
    SELECT category, COUNT(*) as count
    FROM knowledge_base WHERE $scopeWhere
    GROUP BY category ORDER BY count DESC LIMIT 10
");
$categoryStmt->execute($scopeParams);
$stats['by_category'] = $categoryStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$myStmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge_base WHERE created_by = ?");
$myStmt->execute([$current_user_id]);
$stats['my_articles'] = (int) $myStmt->fetchColumn();

if ($canCreate) {
    $editableStmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge_base WHERE $visibilityWhere");
    $editableStmt->execute($visibilityParams);
    $stats['editable'] = (int) $editableStmt->fetchColumn();
} else {
    $stats['editable'] = $stats['my_articles'];
}

// A subquery scoped to knowledge_base alone (rather than splicing
// $visibilityWhere's bare, single-table-only column names into a join)
// keeps "id"/"created_by" etc. unambiguous no matter what this is joined
// against below.
$accessibleKbSubquery = ($is_admin || $canAudit)
    ? null
    : "kb_id IN (SELECT id FROM knowledge_base WHERE $visibilityWhere)";

$commentCountStmt = $pdo->prepare("
    SELECT COUNT(*) FROM knowledge_base_comments
    WHERE " . ($accessibleKbSubquery ?? '1=1')
);
$commentCountStmt->execute($accessibleKbSubquery ? $visibilityParams : []);
$stats['total_comments'] = (int) $commentCountStmt->fetchColumn();

$attachmentCountStmt = $pdo->prepare("
    SELECT COUNT(*) FROM knowledge_base_attachments
    WHERE " . ($accessibleKbSubquery ?? '1=1')
);
$attachmentCountStmt->execute($accessibleKbSubquery ? $visibilityParams : []);
$stats['total_attachments'] = (int) $attachmentCountStmt->fetchColumn();

$recentUpdatedStmt = $pdo->prepare("
    SELECT COUNT(*) FROM knowledge_base WHERE $scopeWhere AND updated_at >= datetime('now', '-7 days')
");
$recentUpdatedStmt->execute($scopeParams);
$stats['recently_updated'] = (int) $recentUpdatedStmt->fetchColumn();

$stats['top_contributors'] = [];
if ($is_admin || $canAudit) {
    $contributorsStmt = $pdo->query("
        SELECT
            created_by,
            -- COALESCE wraps the whole subquery: a created_by with no matching
            -- users row (deleted user, or NULL created_by) makes the subquery
            -- itself NULL, which the inner COALESCE can never catch.
            COALESCE(
                (SELECT COALESCE(first_name || ' ' || last_name, ncgr_id) FROM users WHERE id = knowledge_base.created_by),
                'Unknown'
            ) as author_name,
            COUNT(*) as article_count
        FROM knowledge_base
        GROUP BY created_by
        ORDER BY article_count DESC
        LIMIT 5
    ");
    $stats['top_contributors'] = $contributorsStmt->fetchAll(PDO::FETCH_ASSOC);
}

$stats['recent_actions'] = [];
if ($canAudit) {
    $recentStmt = $pdo->query("
        SELECT ka.action, ka.user_name, ka.action_date, kb.id as kb_id, kb.title
        FROM knowledge_base_audit ka
        JOIN knowledge_base kb ON ka.kb_id = kb.id
        ORDER BY ka.action_date DESC
        LIMIT 8
    ");
    $stats['recent_actions'] = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
}

$stats['recent_comments'] = [];
$commentsStmt = $pdo->prepare("
    SELECT
        kbc.comment_text, kbc.created_at, kb.id as kb_id, kb.title,
        COALESCE(
            (SELECT COALESCE(first_name || ' ' || last_name, ncgr_id) FROM users WHERE id = kbc.commented_by),
            'Unknown'
        ) as commenter
    FROM knowledge_base_comments kbc
    JOIN knowledge_base kb ON kbc.kb_id = kb.id
    WHERE " . ($accessibleKbSubquery ? "kbc.$accessibleKbSubquery" : '1=1') . "
    ORDER BY kbc.created_at DESC
    LIMIT 6
");
$commentsStmt->execute($accessibleKbSubquery ? $visibilityParams : []);
$stats['recent_comments'] = $commentsStmt->fetchAll(PDO::FETCH_ASSOC);

$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

$actionIcons = [
    'created' => 'plus',
    'edited' => 'edit',
    'updated' => 'edit',
    'deleted' => 'edit',
    'visibility_changed' => 'folder',
    'comment_added' => 'message',
];

$page_title = "Knowledge Base Dashboard | InfraVault";
require 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/dashboard.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <!-- HERO -->
    <div class="kbdash-hero">
        <div class="kbdash-hero-text">
            <span class="kbdash-eyebrow"><?php echo kbIcon('library', 'kdi kdi-sm'); ?> Knowledge Base</span>
            <h1><?php echo $greeting; ?>, <?php echo h($user_first_name); ?>.</h1>
            <p>
                A shared home for troubleshooting notes, commands, and infrastructure documentation your
                team writes down once and reuses forever &mdash; searchable, commentable, and shareable by team.
                <?php if ($stats['total_comments'] > 0): ?>
                    <strong><?php echo $stats['total_comments']; ?> comment<?php echo $stats['total_comments'] === 1 ? '' : 's'; ?></strong>
                    have been added across the articles you can see.
                <?php endif; ?>
            </p>
            <div class="kbdash-hero-actions">
                <?php if ($canCreate): ?>
                    <a href="knowledge.php?action=create" class="kbdash-btn kbdash-btn-primary">
                        <?php echo kbIcon('plus'); ?> New Article
                    </a>
                <?php endif; ?>
                <a href="knowledge.php" class="kbdash-btn kbdash-btn-ghost">
                    Browse Articles <?php echo kbIcon('arrow-right', 'kdi kdi-sm'); ?>
                </a>
            </div>
        </div>
        <div class="kbdash-hero-icon"><?php echo kbIcon('book', 'kdi kdi-hero'); ?></div>
    </div>

    <!-- KPI CARDS -->
    <div class="kbdash-kpi-grid">
        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon blue"><?php echo kbIcon('book'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['total_visible']; ?></div>
                <div class="kbdash-kpi-label">Accessible to You</div>
            </div>
        </div>

        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon violet"><?php echo kbIcon('user-doc'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['my_articles']; ?></div>
                <div class="kbdash-kpi-label">Written by You</div>
            </div>
        </div>

        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon teal"><?php echo kbIcon('edit'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['editable']; ?></div>
                <div class="kbdash-kpi-label">You Can Edit</div>
            </div>
        </div>

        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon amber"><?php echo kbIcon('message'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['total_comments']; ?></div>
                <div class="kbdash-kpi-label">Comments</div>
            </div>
        </div>

        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon indigo"><?php echo kbIcon('paperclip'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['total_attachments']; ?></div>
                <div class="kbdash-kpi-label">Attachments</div>
            </div>
        </div>

        <div class="kbdash-kpi">
            <div class="kbdash-kpi-icon green"><?php echo kbIcon('trend'); ?></div>
            <div>
                <div class="kbdash-kpi-value"><?php echo $stats['recently_updated']; ?></div>
                <div class="kbdash-kpi-label">Updated (7 days)</div>
            </div>
        </div>
    </div>

    <div class="kbdash-columns">

        <!-- LEFT COLUMN -->
        <div class="kbdash-col-main">

            <?php if (!empty($stats['by_category'])): ?>
            <div class="kbdash-panel">
                <div class="kbdash-panel-head">
                    <?php echo kbIcon('folder', 'kdi kdi-sm'); ?>
                    <h2>Articles by Category</h2>
                </div>
                <div class="kbdash-panel-body">
                    <?php
                    $catTotal = max(1, array_sum($stats['by_category']));
                    $catPalette = ['#2563eb', '#7c3aed', '#0d9488', '#d97706', '#dc2626', '#4338ca', '#0369a1', '#059669', '#c2410c', '#475569'];
                    $i = 0;
                    foreach ($stats['by_category'] as $cat => $count):
                        $pct = round(($count / $catTotal) * 100);
                        $color = $catPalette[$i % count($catPalette)];
                        $i++;
                    ?>
                        <div class="kbdash-bar-row">
                            <div class="kbdash-bar-label">
                                <span><?php echo h($cat); ?></span>
                                <strong><?php echo (int)$count; ?></strong>
                            </div>
                            <div class="kbdash-bar-track">
                                <div class="kbdash-bar-fill" style="width: <?php echo $pct; ?>%; background: <?php echo $color; ?>;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($stats['top_contributors'])): ?>
            <div class="kbdash-panel">
                <div class="kbdash-panel-head">
                    <?php echo kbIcon('award', 'kdi kdi-sm'); ?>
                    <h2>Top Contributors</h2>
                </div>
                <div class="kbdash-panel-body">
                    <?php foreach ($stats['top_contributors'] as $i => $author):
                        $authorName = trim((string) ($author['author_name'] ?? '')) ?: 'Unknown';
                    ?>
                        <div class="kbdash-leader-row">
                            <span class="kbdash-leader-rank">#<?php echo $i + 1; ?></span>
                            <span class="kbdash-leader-avatar"><?php echo h(strtoupper(substr($authorName, 0, 1))); ?></span>
                            <span class="kbdash-leader-name"><?php echo h($authorName); ?></span>
                            <span class="kbdash-leader-count"><?php echo (int)$author['article_count']; ?> articles</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($stats['recent_comments'])): ?>
            <div class="kbdash-panel">
                <div class="kbdash-panel-head">
                    <?php echo kbIcon('chat-dots', 'kdi kdi-sm'); ?>
                    <h2>Recent Comments</h2>
                </div>
                <div class="kbdash-panel-body kbdash-comment-list">
                    <?php foreach ($stats['recent_comments'] as $comment):
                        $commenter = trim((string) ($comment['commenter'] ?? '')) ?: 'Unknown';
                        $commentTitle = (string) ($comment['title'] ?? '(untitled)');
                        $commentText = (string) ($comment['comment_text'] ?? '');
                        $commentTime = strtotime((string) ($comment['created_at'] ?? ''));
                    ?>
                        <div class="kbdash-comment-item">
                            <span class="kbdash-leader-avatar sm"><?php echo h(strtoupper(substr($commenter, 0, 1))); ?></span>
                            <div class="kbdash-comment-body">
                                <div>
                                    <strong><?php echo h($commenter); ?></strong>
                                    <span class="kbdash-comment-on">on <a href="knowledge.php?action=view&id=<?php echo (int)$comment['kb_id']; ?>"><?php echo h(substr($commentTitle, 0, 40)); ?></a></span>
                                </div>
                                <p><?php echo h(substr($commentText, 0, 120)); ?><?php echo strlen($commentText) > 120 ? '…' : ''; ?></p>
                                <small><?php echo $commentTime ? date('M d, H:i', $commentTime) : '&mdash;'; ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <!-- RIGHT COLUMN -->
        <div class="kbdash-col-side">

            <div class="kbdash-panel">
                <div class="kbdash-panel-head">
                    <h2>Quick Actions</h2>
                </div>
                <div class="kbdash-panel-body kbdash-actions-list">
                    <?php if ($canCreate): ?>
                        <a href="knowledge.php?action=create" class="kbdash-action-item">
                            <span class="kbdash-action-icon blue"><?php echo kbIcon('plus'); ?></span>
                            <span>
                                <strong>New Article</strong>
                                <small>Write a new knowledge entry</small>
                            </span>
                            <?php echo kbIcon('arrow-right', 'kdi kdi-sm'); ?>
                        </a>
                    <?php endif; ?>

                    <a href="knowledge.php" class="kbdash-action-item">
                        <span class="kbdash-action-icon violet"><?php echo kbIcon('library'); ?></span>
                        <span>
                            <strong>Browse All Articles</strong>
                            <small>Search and read the full library</small>
                        </span>
                        <?php echo kbIcon('arrow-right', 'kdi kdi-sm'); ?>
                    </a>
                </div>
            </div>

            <?php if ($canAudit && !empty($stats['recent_actions'])): ?>
            <div class="kbdash-panel">
                <div class="kbdash-panel-head">
                    <?php echo kbIcon('history', 'kdi kdi-sm'); ?>
                    <h2>Recent Activity</h2>
                </div>
                <div class="kbdash-panel-body kbdash-timeline">
                    <?php foreach ($stats['recent_actions'] as $action):
                        $actionName = strtolower(trim((string) ($action['action'] ?? '')));
                        $iconName = $actionIcons[$actionName] ?? 'edit';
                        $actionTitle = (string) ($action['title'] ?? '(untitled)');
                        $actionTime = strtotime((string) ($action['action_date'] ?? ''));
                    ?>
                        <div class="kbdash-timeline-item">
                            <span class="kbdash-timeline-icon"><?php echo kbIcon($iconName, 'kdi kdi-sm'); ?></span>
                            <div>
                                <div>
                                    <a href="knowledge.php?action=view&id=<?php echo (int)$action['kb_id']; ?>"><?php echo h(substr($actionTitle, 0, 30)); ?></a>
                                    <span class="kbdash-timeline-action"><?php echo h(ucwords(str_replace('_', ' ', $actionName))); ?></span>
                                </div>
                                <small><?php echo h($action['user_name'] ?? 'Unknown'); ?> &middot; <?php echo $actionTime ? date('M d, H:i', $actionTime) : '&mdash;'; ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<style>
.kdi { width: 20px; height: 20px; display: inline-block; flex-shrink: 0; }
.kdi-sm { width: 16px; height: 16px; }
.kdi-hero { width: 120px; height: 120px; opacity: .15; stroke-width: 1; }

.kbdash-hero {
    background: linear-gradient(135deg, #052e2b 0%, #0f766e 100%);
    border-radius: 20px;
    padding: 36px 40px;
    margin-bottom: 24px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    position: relative;
    overflow: hidden;
}

.kbdash-hero-text { max-width: 640px; z-index: 1; }

.kbdash-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,.14);
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12.5px;
    font-weight: 600;
    letter-spacing: .02em;
    margin-bottom: 14px;
    color: #5eead4;
}

.kbdash-hero h1 { font-size: 30px; font-weight: 700; margin: 0 0 10px; color: #fff; }
.kbdash-hero p { color: #d1fae5; font-size: 14.5px; line-height: 1.6; margin: 0 0 22px; }

.kbdash-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }

.kbdash-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 20px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    transition: .15s ease;
    border: 1px solid transparent;
}

.kbdash-btn-primary { background: #0d9488; color: #fff; }
.kbdash-btn-primary:hover { background: #0f766e; }

.kbdash-btn-ghost { background: rgba(255,255,255,.1); color: #fff; border-color: rgba(255,255,255,.25); }
.kbdash-btn-ghost:hover { background: rgba(255,255,255,.18); }

.kbdash-hero-icon { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); }

.kbdash-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(190px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.kbdash-kpi {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 18px;
    display: flex;
    align-items: center;
    gap: 14px;
    box-shadow: var(--shadow-sm);
}

.kbdash-kpi-icon {
    width: 42px; height: 42px;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

/* Icon tiles keep a tinted plate in both themes, but the tint has to invert:
   a pastel plate that reads as "soft accent" on white reads as a glaring
   white chip on a dark card. Dark mode therefore darkens the plate and
   lightens the glyph rather than reusing the light values. */
.kbdash-kpi-icon.blue { background: #dbeafe; color: #1d4ed8; }
.kbdash-kpi-icon.violet { background: #ede9fe; color: #6d28d9; }
.kbdash-kpi-icon.teal { background: #ccfbf1; color: #0f766e; }
.kbdash-kpi-icon.indigo { background: #e0e7ff; color: #4338ca; }
.kbdash-kpi-icon.green { background: #dcfce7; color: #166534; }
.kbdash-kpi-icon.amber { background: #fef3c7; color: #b45309; }

[data-theme="dark"] .kbdash-kpi-icon.blue { background: #1b2740; color: #7ba6ff; }
[data-theme="dark"] .kbdash-kpi-icon.violet { background: #262244; color: #b49bff; }
[data-theme="dark"] .kbdash-kpi-icon.teal { background: #123536; color: #5eead4; }
[data-theme="dark"] .kbdash-kpi-icon.indigo { background: #1f2348; color: #a5b4fc; }
[data-theme="dark"] .kbdash-kpi-icon.green { background: #12301f; color: #6ee7a8; }
[data-theme="dark"] .kbdash-kpi-icon.amber { background: #3a2a12; color: #fcd34d; }

.kbdash-kpi-value { font-size: 24px; font-weight: 700; color: var(--text-primary); line-height: 1.1; }
.kbdash-kpi-label { font-size: 12.5px; color: var(--text-secondary); font-weight: 600; margin-top: 3px; }

.kbdash-columns {
    display: grid;
    grid-template-columns: 1.6fr 1fr;
    gap: 20px;
    align-items: start;
}

.kbdash-panel {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
}

.kbdash-panel-head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 18px 20px 0;
    color: var(--text-secondary);
}

.kbdash-panel-head h2 { font-size: 15.5px; font-weight: 700; color: var(--text-primary); margin: 0; }

.kbdash-panel-body { padding: 16px 20px 20px; }

.kbdash-bar-row { margin-bottom: 14px; }
.kbdash-bar-row:last-child { margin-bottom: 0; }

.kbdash-bar-label {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 6px;
}

.kbdash-bar-track { background: var(--border-light); border-radius: 8px; height: 8px; overflow: hidden; }
.kbdash-bar-fill { height: 100%; border-radius: 8px; }

.kbdash-leader-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border-light);
}

.kbdash-leader-row:last-child { border-bottom: none; padding-bottom: 0; }

.kbdash-leader-rank { font-size: 12px; font-weight: 700; color: var(--text-muted); width: 22px; }

.kbdash-leader-avatar {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: #f0fdfa;
    color: #0f766e;
    display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 13px;
    flex-shrink: 0;
}

[data-theme="dark"] .kbdash-leader-avatar { background: #123536; color: #5eead4; }

.kbdash-leader-avatar.sm { width: 28px; height: 28px; font-size: 12px; }

.kbdash-leader-name { flex: 1; font-weight: 600; color: var(--text-primary); font-size: 13.5px; }
.kbdash-leader-count { font-size: 12.5px; color: var(--text-secondary); font-weight: 600; }

.kbdash-comment-list { display: flex; flex-direction: column; gap: 14px; }

.kbdash-comment-item { display: flex; gap: 10px; }

.kbdash-comment-body { flex: 1; min-width: 0; }
.kbdash-comment-body strong { font-size: 13px; color: var(--text-primary); }
.kbdash-comment-on { font-size: 12px; color: var(--text-secondary); }
.kbdash-comment-on a { color: #0d9488; text-decoration: none; font-weight: 600; }
.kbdash-comment-body p { margin: 4px 0; font-size: 13px; color: var(--text-secondary); line-height: 1.5; }
.kbdash-comment-body small { color: var(--text-muted); font-size: 11.5px; }

/* The teal link colour is the KB module's accent; #0d9488 is too dark to sit
   on --bg-content once that token flips, so dark mode takes the 400 step. */
[data-theme="dark"] .kbdash-comment-on a,
[data-theme="dark"] .kbdash-timeline-item a { color: #2dd4bf; }

.kbdash-actions-list { display: flex; flex-direction: column; gap: 10px; }

.kbdash-action-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    text-decoration: none;
    color: inherit;
    border: 1px solid var(--border-color);
    transition: .15s ease;
}

.kbdash-action-item:hover { background: var(--hover-bg); border-color: var(--text-muted); }

.kbdash-action-icon {
    width: 36px; height: 36px;
    border-radius: 9px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

.kbdash-action-icon.blue { background: #dbeafe; color: #1d4ed8; }
.kbdash-action-icon.violet { background: #ede9fe; color: #6d28d9; }

[data-theme="dark"] .kbdash-action-icon.blue { background: #1b2740; color: #7ba6ff; }
[data-theme="dark"] .kbdash-action-icon.violet { background: #262244; color: #b49bff; }

.kbdash-action-item span:nth-child(2) { flex: 1; display: flex; flex-direction: column; }
.kbdash-action-item strong { font-size: 13.5px; color: var(--text-primary); }
.kbdash-action-item small { font-size: 12px; color: var(--text-secondary); }
.kbdash-action-item .kdi-sm { color: var(--text-muted); }

.kbdash-timeline-item {
    display: flex;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border-light);
}

.kbdash-timeline-item:last-child { border-bottom: none; padding-bottom: 0; }

.kbdash-timeline-icon {
    width: 30px; height: 30px;
    border-radius: 50%;
    background: #f0fdfa;
    color: #0f766e;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

[data-theme="dark"] .kbdash-timeline-icon { background: #123536; color: #5eead4; }

.kbdash-timeline-item a { color: #0d9488; text-decoration: none; font-weight: 700; font-size: 13px; }
.kbdash-timeline-action { font-size: 12.5px; color: var(--text-secondary); margin-left: 6px; }
.kbdash-timeline-item small { color: var(--text-muted); font-size: 11.5px; }

@media (max-width: 900px) {
    .kbdash-hero { flex-direction: column; align-items: flex-start; }
    .kbdash-hero-icon { display: none; }
    .kbdash-columns { grid-template-columns: 1fr; }
}
</style>

<?php require 'includes/footer.php'; ?>
