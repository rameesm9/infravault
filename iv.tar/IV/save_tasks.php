<?>
<?php
// save_tasks.php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('dashboard', 'can_view');


$role = trim($_SESSION['role'] ?? '');
$username = ($_SESSION['first_name'] ?? 'User') . ' (' . ($_SESSION['ncgr_id'] ?? '') . ')';
$decommission_id = $_GET['decommission_id'] ?? null;
$editable = ($role === 'Admin' || $role === 'Edit');

if ($decommission_id && $_SERVER['REQUEST_METHOD'] === 'POST' && $editable) {
    $task_status = $_POST['task_status'] ?? [];
    $task_req = $_POST['task_req'] ?? [];

    $stmt = $pdo->prepare("SELECT id FROM decommission_tasks WHERE decommission_id = ? ORDER BY id ASC");
    $stmt->execute([$decommission_id]);
    $tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($tasks as $t) {
        $tid = $t['id'];
        $status = isset($task_status[$tid]) ? 'Completed' : 'Pending';
        $req_no = trim($task_req[$tid] ?? '');

        $up_stmt = $pdo->prepare("UPDATE decommission_tasks SET status = ?, req_no = ? WHERE id = ? AND decommission_id = ?");
        $up_stmt->execute([$status, $req_no, $tid, $decommission_id]);
    }

    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
    $h_stmt->execute([$decommission_id, $username, "Updated checklist tasks progress"]);

    echo "Success";
} else {
    http_response_code(403);
    echo "Forbidden";
}
