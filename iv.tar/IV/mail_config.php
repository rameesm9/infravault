<?php

/*
|--------------------------------------------------------------------------
| SMTP Configuration
|--------------------------------------------------------------------------
| Fill in your organization's SMTP relay details below. This file is
| loaded by patching.php and patch_reminder_cron.php via SmtpMailer.
|
| encryption:
|   ''    — plain, unencrypted (internal relay on port 25, common on a
|            trusted internal network)
|   'tls' — STARTTLS on port 587 (most common for authenticated relays)
|   'ssl' — implicit TLS on port 465
|
| If your internal relay doesn't require authentication, just leave
| username/password blank.
|--------------------------------------------------------------------------
*/

return [
    'host'        => 'smtp.yourcompany.local',
    'port'        => 587,
    'encryption'  => 'tls',
    'username'    => '',
    'password'    => '',
    'from_email'  => 'infravault@yourcompany.local',
    'from_name'   => 'InfraVault Patching',
    'timeout'     => 15,
];
