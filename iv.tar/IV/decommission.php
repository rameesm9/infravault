<?php
// decommission.php
session_start();
require 'config/db.php';
require_once 'includes/pagination-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
|
| Permissions table:
|
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
| This page's key is 'decommission' (registered in permission.php as
| "Asset Decommission").
|
*/

function decommissionHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'decommission', $permission);
}


$canView   = decommissionHasPermission($pdo, $role, 'can_view');
$canEdit   = decommissionHasPermission($pdo, $role, 'can_edit');
$canDelete = decommissionHasPermission($pdo, $role, 'can_delete');
$canExport = decommissionHasPermission($pdo, $role, 'can_export');
$canImport = decommissionHasPermission($pdo, $role, 'can_import');
$canAudit  = decommissionHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
|
| Must happen before any header/sidebar output or AJAX handler below.
| Previously this page had NO view check at all -- any logged-in user
| could load it regardless of their role's can_view setting.
|
*/

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}


$msg = "";
$error = "";

$default_tasks = [
    ["name" => "CRQ Raised and Approved (it Must be CR).", "has_req" => false],
    ["name" => "System Owner approval attached.", "has_req" => false],
    ["name" => "Taken a full server backup as per the defined retention policy.", "has_req" => true],
    ["name" => "Removed NFS exports (if applicable) and inform Storage team to remove from ACL (tick if no NFS).", "has_req" => true],
    ["name" => "Raised ticket with the Splunk team to remove monitoring alerts.", "has_req" => true],
    ["name" => "Removed from the maintenance calendar for the decommission activity.", "has_req" => false],
    ["name" => "Deleted CMDB records", "has_req" => true],
    ["name" => "Informed SecOps team to remove the rules.", "has_req" => true],
    ["name" => "Security tools removed such as SEP, XDR.", "has_req" => true],
    ["name" => "Powered off the server.", "has_req" => false],
    ["name" => "Rename the server by appending '_tbd' in the Vcenter", "has_req" => false],
    ["name" => "server powered off for 1–2 weeks to identify any dependency or accessibility issues.", "has_req" => false],
    ["name" => "Released the Production and Management IP addresses and remove the DNS entries.", "has_req" => false],
    ["name" => "Removed the iLO and Virtual Connect (VC) configuration.", "has_req" => false],
    ["name" => "Removed the server from IPA.", "has_req" => false],
    ["name" => "Removed the server from Satellite", "has_req" => false],
    ["name" => "Deleted the server.", "has_req" => true],
    ["name" => "Updated all relevant tracking documents (Patch Calendar, Decommission Tracker, Inventory, etc.).", "has_req" => false],
    ["name" => "Closed the Change Request (CR).", "has_req" => false],
    ["name" => "Updated the server status in the Ramp-Down/Decommission list.", "has_req" => false]
];

$upload_dir = __DIR__ . '/uploads/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

// Maps a free-text server state / support level to a CSS badge modifier class.
function decom_state_class($state) {
    $state = strtolower(trim($state ?? ''));
    if (strpos($state, 'decommission') !== false) return 'state-decommissioned';
    if (strpos($state, 'to be') !== false) return 'state-pending';
    if (strpos($state, 'off') !== false) return 'state-off';
    if (strpos($state, 'on') !== false) return 'state-on';
    return '';
}

function decom_support_class($level) {
    $level = strtolower(trim($level ?? ''));
    if ($level === 'production') return 'support-prod';
    if (in_array($level, ['pre-prod', 'preprod', 'dr'])) return 'support-preprod';
    if (in_array($level, ['sit', 'test', 'poc'])) return 'support-test';
    if (in_array($level, ['development', 'sandbox'])) return 'support-dev';
    return 'support-other';
}

// Export CSV
if (isset($_GET['action']) && $_GET['action'] === 'export') {

    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export decommission records.');
    }

    // Build WHERE clause with same filters as main page
    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_hostname = trim($_GET['s_hostname'] ?? '');
    $s_project = trim($_GET['s_project'] ?? '');
    $s_support = trim($_GET['s_support'] ?? '');
    $s_tag = trim($_GET['s_tag'] ?? '');
    $s_serial = trim($_GET['s_serial'] ?? '');
    $s_reason = trim($_GET['s_reason'] ?? '');

    if (!empty($keyword)) {
        $export_where_clauses[] = "(hostname LIKE ? OR project LIKE ? OR ip_address LIKE ? OR application_name LIKE ?)";
        array_push($export_params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
    }
    if (!empty($s_hostname)) {
        $export_where_clauses[] = "hostname LIKE ?";
        $export_params[] = "%$s_hostname%";
    }
    if (!empty($s_project)) {
        $export_where_clauses[] = "project LIKE ?";
        $export_params[] = "%$s_project%";
    }
    if (!empty($s_support)) {
        $export_where_clauses[] = "support_level = ?";
        $export_params[] = "$s_support";
    }
    if (!empty($s_tag)) {
        $export_where_clauses[] = "server_state LIKE ?";
        $export_params[] = "%$s_tag%";
    }
    if (!empty($s_serial)) {
        $export_where_clauses[] = "additional_ips LIKE ?";
        $export_params[] = "%$s_serial%";
    }
    if (!empty($s_reason)) {
        $export_where_clauses[] = "application_name LIKE ?";
        $export_params[] = "%$s_reason%";
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=decommission_export_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Hostname', 'Server State', 'Support Level', 'Project', 'Application Name', 'IP Address', 'Additional IPs', 'Start Date', 'End Date', 'Attachment', 'Created By', 'Created At']);

    $stmt = $pdo->prepare("SELECT hostname, server_state, support_level, project, application_name, ip_address, additional_ips, decommission_start_date, decommission_end_date, attachment, created_by, created_at FROM decommission WHERE $export_where_sql ORDER BY hostname ASC");
    $stmt->execute($export_params);

    while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
        fputcsv($output, [
            $row['hostname'], $row['server_state'], $row['support_level'],
            $row['project'], $row['application_name'], $row['ip_address'], $row['additional_ips'],
            $row['decommission_start_date'], $row['decommission_end_date'], $row['attachment'] ?? '',
            $row['created_by'], $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

// AJAX Inventory Details (only meaningful to someone who can actually create/edit a record)
if (isset($_GET['action']) && $_GET['action'] === 'get_inventory_details') {

    if (!$canEdit) {
        http_response_code(403);
        echo json_encode(['success' => false]);
        exit;
    }

    $hname = $_GET['hostname'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM inventory WHERE hostname = ? LIMIT 1");
    $stmt->execute([$hname]);
    $inv = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($inv) {
        echo json_encode([
            'success' => true,
            'project' => $inv['project'] ?? $inv['project_name'] ?? '',
            'support_level' => $inv['support_level'] ?? $inv['environment'] ?? 'Production',
            'application_name' => $inv['application_name'] ?? $inv['app_name'] ?? '',
            'ip_address' => $inv['ip_address'] ?? $inv['ip'] ?? '',
            'additional_ips' => $inv['additional_ips'] ?? '',
            'server_state' => $inv['server_state'] ?? $inv['status'] ?? 'Active'
        ]);
    } else {
        echo json_encode(['success' => false]);
    }
    exit;
}

// Global History AJAX
if (isset($_GET['action']) && $_GET['action'] === 'get_history') {

    if (!$canAudit) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
        exit;
    }

    $record_id = isset($_GET['record_id']) ? (int)$_GET['record_id'] : null;

    if ($record_id) {
        $stmt = $pdo->prepare("SELECT * FROM decommission_history WHERE decommission_id = ? ORDER BY timestamp DESC");
        $stmt->execute([$record_id]);
    } else {
        $stmt = $pdo->query("SELECT * FROM decommission_history ORDER BY timestamp DESC");
    }

    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<div class="table-wrap"><table class="data-table">';
        echo '<thead><tr><th>Action</th><th>Performed By</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $log) {
            $action_class = 'action-updated';
            if ($log['action_type'] === 'CREATED') $action_class = 'action-created';
            if ($log['action_type'] === 'DELETED') $action_class = 'action-deleted';

            echo '<tr>';
            echo '<td><span class="action-badge ' . $action_class . '">' . htmlspecialchars($log['action_type']) . '</span></td>';
            echo '<td>' . htmlspecialchars($log['performed_by']) . '</td>';
            echo '<td>' . htmlspecialchars($log['details']) . '</td>';
            echo '<td>' . htmlspecialchars($log['timestamp']) . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table></div>';
    } else {
        echo '<p class="empty-state">No audit history records found.</p>';
    }
    exit;
}

// Handle Form Submissions (Create, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action_type = $_POST['form_action'] ?? '';

    if ($action_type === 'save') {

        if (!$canEdit) {
            http_response_code(403);
            $error = "You do not have permission to create or edit decommission records.";
        } else {

            $id = $_POST['id'] ?? '';
            $hostname = trim($_POST['hostname']);
            $server_state = trim($_POST['server_state']);
            $support_level = $_POST['support_level'];
            $project = trim($_POST['project']);
            $application_name = trim($_POST['application_name']);
            $ip_address = trim($_POST['ip_address']);
            $additional_ips = trim($_POST['additional_ips']);
            $decommission_start_date = $_POST['decommission_start_date'];
            $decommission_end_date = !empty($_POST['decommission_end_date']) ? $_POST['decommission_end_date'] : null;

            // Handle existing attachments list if editing
            $existing_attachments = [];
            if (!empty($_POST['existing_attachment'])) {
                $existing_attachments = array_filter(explode(',', $_POST['existing_attachment']));
            }

            // Handle multiple file uploads
            $uploaded_files = $existing_attachments;
            if (isset($_FILES['attachment_files']) && !empty($_FILES['attachment_files']['name'][0])) {
                $file_count = count($_FILES['attachment_files']['name']);

                // Comprehensive Office formats + CSV, PDFs, Archives, and standard documents
                $allowed_exts = [
                    'pdf', 'doc', 'docx', 'dot', 'dotx', 'docm', 'dotm',
                    'xls', 'xlsx', 'xlt', 'xltx', 'xlsm', 'xltm', 'xlsb', 'xla', 'xlam',
                    'ppt', 'pptx', 'pot', 'potx', 'pptm', 'potm', 'pps', 'ppsx', 'ppsm',
                    'msg', 'eml', 'pst', 'ost',
                    'vsd', 'vsdx', 'vss', 'vst', 'vstm', 'vstx',
                    'accdb', 'mdb', 'csv',
                    'png', 'jpg', 'jpeg', 'gif', 'txt', 'zip', 'rar', '7z', 'tar', 'gz'
                ];

                for ($i = 0; $i < $file_count; $i++) {
                    if ($_FILES['attachment_files']['error'][$i] === UPLOAD_ERR_OK) {
                        $file_tmp = $_FILES['attachment_files']['tmp_name'][$i];
                        $file_orig = basename($_FILES['attachment_files']['name'][$i]);
                        $file_ext = strtolower(pathinfo($file_orig, PATHINFO_EXTENSION));

                        if (in_array($file_ext, $allowed_exts)) {
                            $new_filename = time() . '_' . $i . '_' . preg_replace("/[^a-zA-Z0-9\._-]/", "_", $file_orig);
                            if (move_uploaded_file($file_tmp, $upload_dir . $new_filename)) {
                                $uploaded_files[] = $new_filename;
                            }
                        } else {
                            $error = "One or more files have an unsupported extension.";
                        }
                    }
                }
            }

            $attachment_name_string = !empty($uploaded_files) ? implode(',', array_unique($uploaded_files)) : '';

            if (empty($hostname)) {
                $error = "Hostname is a required field.";
            } else if (empty($error)) {
                $inv_up = $pdo->prepare("UPDATE inventory SET server_state = ? WHERE hostname = ?");
                $inv_up->execute([$server_state, $hostname]);

                if (empty($id)) {
                    $stmt = $pdo->prepare("INSERT INTO decommission (hostname, server_state, support_level, project, application_name, ip_address, additional_ips, decommission_start_date, decommission_end_date, attachment, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    $stmt->execute([$hostname, $server_state, $support_level, $project, $application_name, $ip_address, $additional_ips, $decommission_start_date, $decommission_end_date, $attachment_name_string, $username]);
                    $new_id = $pdo->lastInsertId();

                    foreach ($default_tasks as $t) {
                        $t_stmt = $pdo->prepare("INSERT INTO decommission_tasks (decommission_id, task_name, status, req_no) VALUES (?, ?, 'Pending', '')");
                        $t_stmt->execute([$new_id, $t['name']]);
                    }

                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                    $h_stmt->execute([$new_id, $username, "Created decommission record for hostname: $hostname"]);
                    $msg = "Decommission entry created successfully.";
                } else {
                    $stmt = $pdo->prepare("UPDATE decommission SET hostname=?, server_state=?, support_level=?, project=?, application_name=?, ip_address=?, additional_ips=?, decommission_start_date=?, decommission_end_date=?, attachment=?, updated_by=?, updated_at=CURRENT_TIMESTAMP WHERE id=?");
                    $stmt->execute([$hostname, $server_state, $support_level, $project, $application_name, $ip_address, $additional_ips, $decommission_start_date, $decommission_end_date, $attachment_name_string, $username, $id]);

                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'UPDATED', ?, ?)");
                    $h_stmt->execute([$id, $username, "Updated decommission record for hostname: $hostname"]);
                    $msg = "Decommission entry updated successfully.";
                }
            }
        }
    }

    if ($action_type === 'delete') {

        if (!$canDelete) {
            http_response_code(403);
            $error = "You do not have permission to delete decommission records.";
        } else {
            $id = $_POST['id'];
            $p_stmt = $pdo->prepare("SELECT hostname FROM decommission WHERE id = ?");
            $p_stmt->execute([$id]);
            $row = $p_stmt->fetch(PDO::FETCH_ASSOC);
            $hname = $row ? $row['hostname'] : 'Unknown';

            $stmt = $pdo->prepare("DELETE FROM decommission WHERE id = ?");
            $stmt->execute([$id]);

            $t_stmt = $pdo->prepare("DELETE FROM decommission_tasks WHERE decommission_id = ?");
            $t_stmt->execute([$id]);

            $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'DELETED', ?, ?)");
            $h_stmt->execute([$id, $username, "Deleted decommission record for hostname: $hname"]);
            $msg = "Decommission entry deleted successfully.";
        }
    }
}

// Pagination & Search
$limit = resolveUserPageSize($pdo, (int) $_SESSION['user_id']);

$page = isset($_GET['page'])
    ? max(1, (int)$_GET['page'])
    : 1;

$start = ($page - 1) * $limit;

$keyword = trim($_GET['keyword'] ?? '');
$s_hostname = trim($_GET['s_hostname'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_support = trim($_GET['s_support'] ?? '');
$s_tag = trim($_GET['s_tag'] ?? '');
$s_serial = trim($_GET['s_serial'] ?? '');
$s_reason = trim($_GET['s_reason'] ?? '');

$where_clauses = ["1=1"];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(hostname LIKE ? OR project LIKE ? OR ip_address LIKE ? OR application_name LIKE ?)";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_hostname)) {
    $where_clauses[] = "hostname LIKE ?";
    $params[] = "%$s_hostname%";
}
if (!empty($s_project)) {
    $where_clauses[] = "project LIKE ?";
    $params[] = "%$s_project%";
}
if (!empty($s_support)) {
    $where_clauses[] = "support_level = ?";
    $params[] = "$s_support";
}
if (!empty($s_tag)) {
    $where_clauses[] = "server_state LIKE ?";
    $params[] = "%$s_tag%";
}
if (!empty($s_serial)) {
    $where_clauses[] = "additional_ips LIKE ?";
    $params[] = "%$s_serial%";
}
if (!empty($s_reason)) {
    $where_clauses[] = "application_name LIKE ?";
    $params[] = "%$s_reason%";
}

$where_sql = implode(" AND ", $where_clauses);

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM decommission WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_records / $limit));

// Correct page if out of range
if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

// Sorting - validate and apply
$sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

$valid_sort_columns = ['id', 'hostname', 'project', 'server_state', 'support_level', 'application_name', 'ip_address', 'decommission_start_date', 'decommission_end_date', 'created_at'];
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'id';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'DESC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

$data_stmt = $pdo->prepare("SELECT * FROM decommission WHERE $where_sql ORDER BY `$sort_by` $sort_dir LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hidden fields so the page-size selector preserves the current
// search/filter/sort state instead of resetting it.
$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_hostname' => $s_hostname,
    's_project' => $s_project,
    's_support' => $s_support,
    's_tag' => $s_tag,
    's_serial' => $s_serial,
    's_reason' => $s_reason,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
] as $fk => $fv) {
    if ($fv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
    }
}

$inventory_list = [];
try {
    $inv_stmt = $pdo->query("SELECT DISTINCT hostname FROM inventory ORDER BY hostname ASC");
    $inventory_list = $inv_stmt->fetchAll(PDO::FETCH_COLUMN);
} catch (Exception $e) {}

$support_levels = ['Production', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox', 'DR', 'POC'];

// Used by includes/header.php for the <title> tag
$page_title = "Decommission Registry | InfraVault";

require 'includes/header.php';
?>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/decommission.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <div class="dashboard-header">
        <div>
            <h1>Server Decommission Management</h1>
            <p>Track servers going through the decommission process, from CR approval to final cleanup.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="btn btn-success" onclick="openCreateModal()">+ Add Record</button>
            <?php endif; ?>
            <?php if ($canImport): ?>
                <button type="button" class="btn btn-info" onclick="openImportModal()">Import CSV</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_hostname !== '') $export_params['s_hostname'] = $s_hostname;
                if ($s_project !== '') $export_params['s_project'] = $s_project;
                if ($s_support !== '') $export_params['s_support'] = $s_support;
                if ($s_tag !== '') $export_params['s_tag'] = $s_tag;
                if ($s_serial !== '') $export_params['s_serial'] = $s_serial;
                if ($s_reason !== '') $export_params['s_reason'] = $s_reason;
                $export_url = 'decommission.php?' . http_build_query($export_params);
                ?>
                <a href="<?= htmlspecialchars($export_url) ?>" class="btn btn-info">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="btn btn-warning" onclick="openGlobalHistoryModal()">⏱ History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="alert alert-warning mb-4">
        <strong>🔔 Important:</strong> Server decommissioning must always be performed through an approved Change Request (CR). Make sure all stakeholders are approved and alert removed.
    </div>

    <!-- Search Panel -->
    <div class="panel">
        <div
            class="panel-header"
            style="margin-bottom:14px;"
        >
            <h3
                class="panel-title"
                style="margin:0;"
            >
                Search &amp; Filters
            </h3>
            <span
                style="
                    cursor:pointer;
                    color:#2563EB;
                    font-size:13px;
                    font-weight:600;
                "
                onclick="toggleAdvancedSearch()"
            >
                Search Multiple Values &#9662;
            </span>
        </div>

        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">
        <form
            method="GET"
            action="decommission.php"
            style="
                display:flex;
                gap:10px;
                flex-wrap:wrap;
            "
        >
            <input
                type="text"
                name="keyword"
                class="form-control"
                style="max-width:320px;"
                placeholder="Search hostname, project, IP, app..."
                value="<?php
                echo htmlspecialchars(
                    $keyword,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>"
            >
            <button
                type="submit"
                class="btn btn-primary"
            >
                Search
            </button>
            <?php if (
                $keyword !== '' ||
                $s_hostname !== '' ||
                $s_project !== '' ||
                $s_support !== '' ||
                $s_tag !== '' ||
                $s_serial !== '' ||
                $s_reason !== ''
            ): ?>
                <a
                    href="decommission.php"
                    class="btn"
                >
                    Clear
                </a>
            <?php endif; ?>
        </form>

        <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
        </div>

        <div
            id="advancedSearchPanel"
            style="
                display:<?php
                echo (
                    $s_hostname !== '' ||
                    $s_project !== '' ||
                    $s_support !== '' ||
                    $s_tag !== '' ||
                    $s_serial !== '' ||
                    $s_reason !== ''
                )
                    ? 'block'
                    : 'none';
                ?>;
                margin-top:18px;
                padding:20px;
                background:var(--hover-bg);
                border-radius:10px;
                border:1px solid #E5E7EB;
            "
        >
            <form
                method="GET"
                action="decommission.php"
                style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;"
            >
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Hostname</label>
                    <input type="text" name="s_hostname" class="form-control" placeholder="Hostname..." value="<?= htmlspecialchars($s_hostname, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Project</label>
                    <input type="text" name="s_project" class="form-control" placeholder="Project..." value="<?= htmlspecialchars($s_project, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Support Level</label>
                    <select name="s_support" class="form-control">
                        <option value="">All Levels</option>
                        <?php foreach ($support_levels as $level): ?>
                            <option value="<?= htmlspecialchars($level, ENT_QUOTES, 'UTF-8') ?>" <?= $s_support === $level ? 'selected' : '' ?>><?= htmlspecialchars($level, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Server State</label>
                    <input type="text" name="s_tag" class="form-control" placeholder="State..." value="<?= htmlspecialchars($s_tag, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Additional IPs</label>
                    <input type="text" name="s_serial" class="form-control" placeholder="IPs..." value="<?= htmlspecialchars($s_serial, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Application/Reason</label>
                    <input type="text" name="s_reason" class="form-control" placeholder="App/Reason..." value="<?= htmlspecialchars($s_reason, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- BUTTONS -->
                <div style="grid-column: 1/-1; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; min-width: 120px;">
                        🔍 Apply Filters
                    </button>
                    <a href="decommission.php" class="btn" style="flex: 1; min-width: 120px; text-align: center;">
                        ↺ Reset
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Data Table Panel -->
    <div class="panel" style="padding:0;">
        <div style="padding:22px 22px 0;">
            <div class="panel-header" style="margin-bottom:0;">
                <span class="panel-title" style="margin-bottom:0;">Decommission Records</span>
                <span style="color:#64748B;font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
        </div>

        <div class="table-wrap">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>
                            <a href="decommission.php?sort_by=hostname&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Hostname
                                <?php if ($sort_by === 'hostname'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=project&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Project
                                <?php if ($sort_by === 'project'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=server_state&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Server State
                                <?php if ($sort_by === 'server_state'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=support_level&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Support Level
                                <?php if ($sort_by === 'support_level'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=application_name&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                App Name
                                <?php if ($sort_by === 'application_name'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=ip_address&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                IP Address
                                <?php if ($sort_by === 'ip_address'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>
                            <a href="decommission.php?sort_by=decommission_start_date&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                Timeline
                                <?php if ($sort_by === 'decommission_start_date'): ?>
                                    <span style="color: #2563EB;">
                                        <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                        </th>
                        <th>Attachments</th>
                        <th style="text-align: center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($records) > 0): ?>
                        <?php foreach ($records as $r): ?>
                        <tr>
                            <td class="cell-primary"><?php echo htmlspecialchars($r['hostname']); ?></td>
                            <td><?php echo htmlspecialchars($r['project']); ?></td>
                            <td><span class="badge-state <?php echo decom_state_class($r['server_state']); ?>"><?php echo htmlspecialchars($r['server_state']); ?></span></td>
                            <td><span class="badge-support <?php echo decom_support_class($r['support_level']); ?>"><?php echo htmlspecialchars($r['support_level']); ?></span></td>
                            <td><?php echo htmlspecialchars($r['application_name']); ?></td>
                            <td><?php echo htmlspecialchars($r['ip_address']); ?></td>
                            <td><small><?php echo htmlspecialchars($r['decommission_start_date'] ?? 'N/A'); ?><?php if(!empty($r['decommission_end_date'])) echo ' to ' . htmlspecialchars($r['decommission_end_date']); ?></small></td>
                            <td>
                                <?php if (!empty($r['attachment'])): ?>
                                    <?php
                                        $files = explode(',', $r['attachment']);
                                        foreach ($files as $idx => $file):
                                            $file = trim($file);
                                            if(empty($file)) continue;
                                    ?>
                                        <a href="uploads/<?php echo htmlspecialchars($file); ?>" target="_blank" class="btn btn-sm btn-outline-info mb-1">📎 File <?php echo ($idx + 1); ?></a>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <span class="text-muted small">None</span>
                                <?php endif; ?>
                            </td>
                            <td style="text-align: center; white-space: nowrap;">
                                <div class="row-actions">
                                    <button type="button" class="btn btn-sm btn-secondary btn-icon" title="View Tasks" aria-label="View Tasks" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars($r['hostname']); ?>', false)">👁</button>
                                    <?php if ($canEdit): ?>
                                        <button type="button" class="btn btn-sm btn-info btn-icon" title="Edit Tasks" aria-label="Edit Tasks" onclick="openTaskModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars($r['hostname']); ?>', true)">✏️</button>
                                        <button type="button" class="btn btn-sm btn-primary btn-icon" title="Edit" aria-label="Edit" onclick='openEditModal(<?php echo json_encode($r); ?>)'>✎</button>
                                    <?php endif; ?>
                                    <?php if ($canDelete): ?>
                                        <button type="button" class="btn btn-sm btn-danger btn-icon" title="Delete" aria-label="Delete" onclick="openDeleteModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars(addslashes($r['hostname'])); ?>')">🗑</button>
                                    <?php endif; ?>
                                    <?php if ($canAudit): ?>
                                        <button type="button" class="btn btn-sm btn-warning btn-icon" title="Audit History" aria-label="Audit History" onclick="openRowHistoryModal(<?php echo $r['id']; ?>, '<?php echo htmlspecialchars($r['hostname']); ?>')">⏱</button>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="9"><p class="empty-state">No decommission records found.</p></td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <?= ivPager($page, $total_pages, [
            'keyword'    => $keyword,
            's_hostname' => $s_hostname,
            's_project'  => $s_project,
            's_support'  => $s_support,
            's_tag'      => $s_tag,
            's_serial'   => $s_serial,
            's_reason'   => $s_reason,
            'sort_by'    => $sort_by,
            'sort_dir'   => $sort_dir,
        ], ['base' => 'decommission.php', 'total_records' => $total_records ?? null, 'per_page' => $limit ?? null]) ?>
    </div>

</div>

<!-- Modals -->
<div class="modal fade" id="recordModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle">New Decommission Entry</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form method="POST" action="decommission.php" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="form_action" value="save">
                    <input type="hidden" name="id" id="rec_id">
                    <input type="hidden" name="existing_attachment" id="rec_existing_attachment">
                    <div class="row g-3">
                        <div class="col-md-6" id="hostnameSearchContainer">
                            <label class="form-label">Search/Select Hostname from Inventory *</label>
                            <select name="hostname" id="rec_hostname_select" class="form-control" onchange="fetchInventoryData(this.value)">
                                <option value="">-- Choose Hostname --</option>
                                <?php foreach ($inventory_list as $inv_host): ?>
                                    <option value="<?php echo htmlspecialchars($inv_host); ?>"><?php echo htmlspecialchars($inv_host); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-6" id="hostnameDisplayContainer" style="display:none;">
                            <label class="form-label">Hostname *</label>
                            <input type="text" name="hostname" id="rec_hostname_input" class="form-control" readonly>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Server State</label>
                            <select class="form-select" name="server_state" id="server_state" required>
                                <option value="">Select Server State...</option>
                                <option value="powered on">Powered On / Active</option>
                                <option value="powered off">Powered Off</option>
                                <option value="to be decomm">To Be Decommissioned</option>
                                <option value="decommissioned">Decommissioned</option>
                            </select>
                        </div>
                        <div class="col-md-6"><label class="form-label">Project Name</label><input type="text" name="project" id="rec_project" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Support Level</label><input type="text" name="support_level" id="rec_support_level" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Application Name</label><input type="text" name="application_name" id="rec_application_name" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">IP Address</label><input type="text" name="ip_address" id="rec_ip_address" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Additional IPs</label><input type="text" name="additional_ips" id="rec_additional_ips" class="form-control"></div>
                        <div class="col-md-6"><label class="form-label">Decommission Start Date *</label><input type="date" name="decommission_start_date" id="rec_start_date" class="form-control" required></div>
                        <div class="col-md-6"><label class="form-label">Decommission End Date</label><input type="date" name="decommission_end_date" id="rec_end_date" class="form-control"></div>
                        <div class="col-md-12">
                            <label class="form-label">Attachment Documents (Microsoft Office files, CSV, PDFs, Images, Archives allowed)</label>
                            <input type="file" name="attachment_files[]" class="form-control" multiple>
                            <div id="fileHelpBlock" class="form-text"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Record</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Task Modal Container -->
<div class="modal fade" id="taskModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header bg-dark text-white">
                <h5 class="modal-title"><span id="taskModalTitleMode">Checklist Tasks</span>: <span id="taskModalHostname" class="text-warning"></span></h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="taskModalBody">
                <p class="task-loading">Loading checklist tasks...</p>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content text-center">
            <div class="modal-header"><h5 class="modal-title">Confirm Deletion</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body"><p>Are you sure you want to delete decommission record for hostname: <strong id="del_hostname"></strong>?</p></div>
            <div class="modal-footer justify-content-center">
                <form method="POST" action="decommission.php">
                    <input type="hidden" name="form_action" value="delete">
                    <input type="hidden" name="id" id="del_id">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-danger">Yes, Delete</button>
                </form>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="globalHistoryModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title">Module Audit History</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body" id="globalHistoryContent" style="max-height: 60vh; overflow-y: auto;"><p class="task-loading">Loading audit trails...</p></div>
        </div>
    </div>
</div>

<!-- Import CSV Modal -->
<div class="modal fade" id="importModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Import Decommission CSV</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="decommission-import.php" method="POST" enctype="multipart/form-data">
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="csv_file" class="form-label">CSV File</label>
                        <input type="file" class="form-control" id="csv_file" name="csv_file" accept=".csv" required>
                    </div>
                    <div class="mb-3">
                        <p><strong>CSV Format:</strong></p>
                        <code style="display: block; background: #f5f5f5; padding: 10px; border-radius: 4px; overflow-x: auto;">
hostname,server_state,support_level,project,application_name,ip_address,additional_ips,decommission_start_date,decommission_end_date
                        </code>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Upload</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="assets/js/bootstrap.bundle.min.js"></script>
<script>
    function fetchInventoryData(hostname) {
        if (!hostname) { clearInventoryFields(); return; }
        fetch('decommission.php?action=get_inventory_details&hostname=' + encodeURIComponent(hostname))
            .then(res => res.json())
            .then(data => {
                if (data.success) {
                    document.getElementById('rec_project').value = data.project || '';
                    document.getElementById('rec_support_level').value = data.support_level || '';
                    document.getElementById('server_state').value = data.server_state || '';
                    document.getElementById('rec_application_name').value = data.application_name || '';
                    document.getElementById('rec_ip_address').value = data.ip_address || '';
                    document.getElementById('rec_additional_ips').value = data.additional_ips || '';
                } else { clearInventoryFields(); }
            }).catch(() => clearInventoryFields());
    }

    function clearInventoryFields() {
        ['rec_project', 'rec_support_level', 'server_state', 'rec_application_name', 'rec_ip_address', 'rec_additional_ips'].forEach(id => document.getElementById(id).value = '');
    }

    function openCreateModal() {
        document.getElementById('modalTitle').innerText = 'New Decommission Entry';
        document.getElementById('rec_id').value = '';
        document.getElementById('rec_existing_attachment').value = '';
        document.getElementById('fileHelpBlock').innerHTML = '';
        document.getElementById('hostnameSearchContainer').style.display = 'block';
        document.getElementById('hostnameDisplayContainer').style.display = 'none';
        document.getElementById('rec_hostname_select').value = '';
        document.getElementById('rec_hostname_select').required = true;
        document.getElementById('rec_hostname_select').setAttribute('name', 'hostname');
        document.getElementById('rec_hostname_input').removeAttribute('name');
        clearInventoryFields();
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openEditModal(data) {
        document.getElementById('modalTitle').innerText = 'Update Decommission Entry';
        document.getElementById('rec_id').value = data.id;
        document.getElementById('hostnameSearchContainer').style.display = 'none';
        document.getElementById('hostnameDisplayContainer').style.display = 'block';
        document.getElementById('rec_hostname_select').removeAttribute('name');
        document.getElementById('rec_hostname_input').setAttribute('name', 'hostname');
        document.getElementById('rec_hostname_input').value = data.hostname;
        document.getElementById('server_state').value = data.server_state || '';
        document.getElementById('rec_support_level').value = data.support_level || '';
        document.getElementById('rec_project').value = data.project || '';
        document.getElementById('rec_application_name').value = data.application_name || '';
        document.getElementById('rec_ip_address').value = data.ip_address || '';
        document.getElementById('rec_additional_ips').value = data.additional_ips || '';
        document.getElementById('rec_start_date').value = data.decommission_start_date || '';
        document.getElementById('rec_end_date').value = data.decommission_end_date || '';
        document.getElementById('rec_existing_attachment').value = data.attachment || '';

        let fileListHtml = 'No files currently attached.';
        if (data.attachment) {
            let files = data.attachment.split(',');
            fileListHtml = 'Current files: ';
            files.forEach((f, idx) => {
                fileListHtml += `<br><a href="uploads/${f.trim()}" target="_blank">File ${idx + 1} (${f.trim()})</a>`;
            });
        }
        document.getElementById('fileHelpBlock').innerHTML = fileListHtml;
        new bootstrap.Modal(document.getElementById('recordModal')).show();
    }

    function openDeleteModal(id, hostname) {
        document.getElementById('del_id').value = id;
        document.getElementById('del_hostname').innerText = hostname;
        new bootstrap.Modal(document.getElementById('deleteModal')).show();
    }

    function openTaskModal(decommissionId, hostname, isEditable) {
        document.getElementById('taskModalHostname').innerText = hostname;
        document.getElementById('taskModalTitleMode').innerText = isEditable ? 'Modify Checklist Tasks' : 'View Checklist Tasks';
        document.getElementById('taskModalBody').innerHTML = '<p class="task-loading">Loading checklist tasks...</p>';

        fetch('tasks.php?decommission_id=' + decommissionId + '&edit=' + (isEditable ? 1 : 0))
            .then(res => res.text())
            .then(html => { document.getElementById('taskModalBody').innerHTML = html; })
            .catch(() => { document.getElementById('taskModalBody').innerHTML = '<p class="task-error">Failed to load tasks.</p>'; });

        new bootstrap.Modal(document.getElementById('taskModal')).show();
    }

    function submitTaskForm(event, decommissionId) {
        event.preventDefault();
        const form = document.getElementById('inlineTaskForm');
        const formData = new FormData(form);

        fetch('tasks.php', {
            method: 'POST',
            body: formData
        })
        .then(res => res.text())
        .then(html => {
            document.getElementById('taskModalBody').innerHTML = html;
        })
        .catch(() => {
            alert('Failed to save task progress.');
        });
    }

    function openGlobalHistoryModal() {
        new bootstrap.Modal(document.getElementById('globalHistoryModal')).show();
        document.getElementById('globalHistoryContent').innerHTML = '<p class="task-loading">Loading audit history...</p>';
        fetch('decommission.php?action=get_history')
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="task-error">Failed to load audit history.</p>'; });
    }

    function openRowHistoryModal(recordId, hostname) {
        new bootstrap.Modal(document.getElementById('globalHistoryModal')).show();
        document.getElementById('globalHistoryContent').innerHTML = '<p class="task-loading">Loading audit history...</p>';
        fetch(`decommission.php?action=get_history&record_id=${recordId}`)
            .then(res => res.text())
            .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
            .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p class="task-error">Failed to load audit history.</p>'; });
    }

    function openImportModal() {
        new bootstrap.Modal(document.getElementById('importModal')).show();
    }

    function closeImportModal() {
        const modal = bootstrap.Modal.getInstance(document.getElementById('importModal'));
        if (modal) modal.hide();
    }

    function toggleAdvancedSearch() {
        const panel = document.getElementById('advancedSearchPanel');
        if (panel.style.display === 'none') {
            panel.style.display = 'block';
        } else {
            panel.style.display = 'none';
        }
    }
</script>

<?php require 'includes/footer.php'; ?>