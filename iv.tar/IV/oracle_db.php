<?php
/**
 * Oracle database estate -- standalone, RAC and Data Guard.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('oracle_db', 'can_view');

$canEdit   = can('oracle_db', 'can_edit');
$canDelete = can('oracle_db', 'can_delete');
$canExport = can('oracle_db', 'can_export');
$canAudit  = can('oracle_db', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const ORA_MODULE = 'oracle_db';

$deployTypes  = ['Standalone', 'RAC', 'RAC One Node', 'Data Guard Primary', 'Data Guard Standby'];
$versions     = ['23ai', '21c', '19c', '18c', '12.2', '12.1', '11.2'];
$editions     = ['Enterprise', 'Standard', 'Standard Edition 2', 'Express'];
$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development'];
$storageTypes = ['ASM', 'Filesystem', 'ACFS', 'Exadata', 'NFS'];
$archModes    = ['ARCHIVELOG', 'NOARCHIVELOG'];
$dgRoles      = ['None', 'Primary', 'Physical Standby', 'Logical Standby', 'Snapshot Standby'];
$statuses     = ['Active', 'Degraded', 'Maintenance', 'Decommissioned'];
$nodeRoles    = ['Node 1', 'Node 2', 'Node 3', 'Node 4', 'Primary', 'Standby'];

$oraFields = [
    'db_name'               => 'DB Name',
    'db_unique_name'        => 'DB Unique Name',
    'oracle_sid'            => 'SID',
    'deployment_type'       => 'Deployment',
    'oracle_version'        => 'Version',
    'edition'               => 'Edition',
    'patch_level'           => 'Patch Level',
    'environment'           => 'Environment',
    'project'               => 'Project',
    'application'           => 'Application',
    'support_level'         => 'Support Level',
    'managed_by'            => 'Managed By',
    'cluster_name'          => 'Cluster Name',
    'scan_name'             => 'SCAN Name',
    'scan_ips'              => 'SCAN IPs',
    'listener_port'         => 'Listener Port',
    'storage_type'          => 'Storage Type',
    'asm_diskgroups'        => 'ASM Diskgroups',
    'size_gb'               => 'Size (GB)',
    'character_set'         => 'Character Set',
    'archivelog_mode'       => 'Archivelog Mode',
    'dataguard_role'        => 'Data Guard Role',
    'dataguard_peer'        => 'Data Guard Peer',
    'backup_tool'           => 'Backup Tool',
    'backup_schedule'       => 'Backup Schedule',
    'last_backup_date'      => 'Last Backup',
    'technical_owner'       => 'Technical Owner',
    'technical_owner_email' => 'Owner Email',
    'dba_owner'             => 'DBA Owner',
    'status'                => 'Status',
    'notes'                 => 'Notes',
];


/* ---------------- AJAX ---------------- */

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('oracle_db', 'can_audit');
    echo platformHistoryHtml($pdo, ORA_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}

if (($_GET['action'] ?? '') === 'nodes_json') {
    header('Content-Type: application/json; charset=utf-8');
    $stmt = $pdo->prepare("SELECT hostname, instance_name, node_role, vip_address, status
                           FROM oracle_db_nodes WHERE db_id = ? ORDER BY node_role, hostname");
    $stmt->execute([(int) ($_GET['id'] ?? 0)]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if (($_GET['action'] ?? '') === 'nodes') {
    $stmt = $pdo->prepare("SELECT * FROM oracle_db_nodes WHERE db_id = ? ORDER BY node_role, hostname");
    $stmt->execute([(int) ($_GET['id'] ?? 0)]);
    $nodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$nodes) { echo '<p class="plat-empty">No nodes recorded for this database.</p>'; exit; }

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>Hostname</th><th>Instance</th><th>Role</th><th>VIP</th><th>Status</th></tr></thead><tbody>';
    foreach ($nodes as $n) {
        echo '<tr><td class="plat-primary">' . plat_h($n['hostname']) . '</td>'
           . '<td>' . plat_h($n['instance_name'] ?: '—') . '</td>'
           . '<td><span class="plat-pill neutral">' . plat_h($n['node_role']) . '</span></td>'
           . '<td>' . plat_h($n['vip_address'] ?: '—') . '</td>'
           . '<td><span class="plat-pill ' . platformStatusClass($n['status']) . '">' . plat_h($n['status']) . '</span></td></tr>';
    }
    echo '</tbody></table></div>';
    exit;
}


/* ---------------- FILTERS ---------------- */

$q        = trim((string) ($_GET['q'] ?? ''));
$fDeploy  = trim((string) ($_GET['f_deploy'] ?? ''));
$fEnv     = trim((string) ($_GET['f_env'] ?? ''));
$fVersion = trim((string) ($_GET['f_version'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(db_name LIKE ? OR db_unique_name LIKE ? OR oracle_sid LIKE ? OR application LIKE ? OR cluster_name LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fDeploy !== '')  { $where[] = 'deployment_type = ?'; $params[] = $fDeploy; }
if ($fEnv !== '')     { $where[] = 'environment = ?';     $params[] = $fEnv; }
if ($fVersion !== '') { $where[] = 'oracle_version = ?';  $params[] = $fVersion; }

$whereSql = implode(' AND ', $where);

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('oracle_db', 'can_export');
    platformExportCsv($pdo, 'oracle_databases', $oraFields, $whereSql, $params, 'oracle_databases');
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('oracle_db', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);
        $data = [];
        foreach (array_keys($oraFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }
        $data['size_gb'] = (float) $data['size_gb'];

        if ($data['db_name'] === '') {
            $err = 'Database name is required.';
        } else {
            try {
                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM oracle_databases WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $pdo->prepare("UPDATE oracle_databases SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($data), $username, $id]);

                    platformLog($pdo, ORA_MODULE, $id, 'UPDATED', $username,
                        "Updated database: {$data['db_name']}\n" . platformDiff($old, $data, $oraFields));
                    $msg = 'Database updated.';
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $pdo->prepare("INSERT INTO oracle_databases ($cols, created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    platformLog($pdo, ORA_MODULE, $id, 'CREATED', $username, "Created database: {$data['db_name']}");
                    $msg = 'Database added.';
                }

                $pdo->prepare("DELETE FROM oracle_db_nodes WHERE db_id = ?")->execute([$id]);

                $hosts = $_POST['node_hostname'] ?? [];
                $insts = $_POST['node_instance'] ?? [];
                $roles = $_POST['node_role'] ?? [];
                $vips  = $_POST['node_vip'] ?? [];
                $stats = $_POST['node_status'] ?? [];

                $ins = $pdo->prepare("
                    INSERT OR IGNORE INTO oracle_db_nodes
                        (db_id, hostname, instance_name, node_role, vip_address, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                foreach ($hosts as $i => $h) {
                    $h = trim((string) $h);
                    if ($h === '') { continue; }
                    $ins->execute([
                        $id, $h,
                        trim((string) ($insts[$i] ?? '')),
                        trim((string) ($roles[$i] ?? 'Node 1')),
                        trim((string) ($vips[$i] ?? '')),
                        trim((string) ($stats[$i] ?? 'Up')),
                    ]);
                }
            } catch (Throwable $e) {
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('oracle_db', 'can_delete');
        $id = (int) ($_POST['id'] ?? 0);

        $n = $pdo->prepare("SELECT db_name FROM oracle_databases WHERE id = ?");
        $n->execute([$id]);
        $name = (string) ($n->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM oracle_databases WHERE id = ?")->execute([$id]);
        platformLog($pdo, ORA_MODULE, $id, 'DELETED', $username, "Deleted database: {$name}");
        $msg = 'Database deleted.';
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("SELECT * FROM oracle_databases WHERE $whereSql ORDER BY db_name");
$stmt->execute($params);
$dbs = $stmt->fetchAll(PDO::FETCH_ASSOC);

$nodeCounts = [];
foreach ($pdo->query("SELECT db_id, COUNT(*) c FROM oracle_db_nodes GROUP BY db_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $nodeCounts[(int) $r['db_id']] = (int) $r['c'];
}

$totalDbs = count($dbs);
$racCount = $dgCount = $prodCount = 0;
$totalSize = 0.0;

foreach ($dbs as $d) {
    if (stripos((string) $d['deployment_type'], 'RAC') !== false) { $racCount++; }
    if (!in_array((string) $d['dataguard_role'], ['', 'None'], true)) { $dgCount++; }
    if (strcasecmp((string) $d['environment'], 'Production') === 0) { $prodCount++; }
    $totalSize += (float) $d['size_gb'];
}

$hostnames = platformHostnames($pdo);

$page_title = 'Oracle Databases | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🗄</div>
            <div>
                <h1>Oracle Databases</h1>
                <p>Standalone, RAC and Data Guard databases, with their nodes, storage and backup posture.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="oraOpen()">+ Add Database</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_deploy=<?= urlencode($fDeploy) ?>&amp;f_env=<?= urlencode($fEnv) ?>&amp;f_version=<?= urlencode($fVersion) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="oraHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $totalDbs ?></b><span>Databases</span></div>
        <div class="plat-stat tone-ok"><b><?= $prodCount ?></b><span>Production</span></div>
        <div class="plat-stat"><b><?= $racCount ?></b><span>RAC</span></div>
        <div class="plat-stat tone-warn"><b><?= $dgCount ?></b><span>Data Guard</span></div>
        <div class="plat-stat"><b><?= number_format($totalSize, 1) ?></b><span>Total GB</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search &amp; Filters</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="DB name, SID, application, cluster…">
                </div>
                <div class="plat-field">
                    <label>Deployment</label>
                    <select name="f_deploy">
                        <option value="">All</option>
                        <?php foreach ($deployTypes as $d): ?><option value="<?= plat_h($d) ?>" <?= $fDeploy === $d ? 'selected' : '' ?>><?= plat_h($d) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Environment</label>
                    <select name="f_env">
                        <option value="">All</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>" <?= $fEnv === $e ? 'selected' : '' ?>><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Version</label>
                    <select name="f_version">
                        <option value="">All</option>
                        <?php foreach ($versions as $v): ?><option value="<?= plat_h($v) ?>" <?= $fVersion === $v ? 'selected' : '' ?>><?= plat_h($v) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="oracle_db.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Databases</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $totalDbs ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Database</th><th>Deployment</th><th>Version</th><th>Environment</th>
                        <th>Nodes</th><th>Storage</th><th>Data Guard</th><th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$dbs): ?>
                    <tr><td colspan="9"><p class="plat-empty">No databases recorded yet.</p></td></tr>
                <?php else: foreach ($dbs as $d): ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($d['db_name']) ?></span>
                            <span class="plat-sub"><?= plat_h($d['application'] ?: $d['project'] ?: '—') ?></span>
                        </td>
                        <td>
                            <span class="plat-pill <?= stripos((string) $d['deployment_type'], 'RAC') !== false ? 'warn' : 'neutral' ?>">
                                <?= plat_h($d['deployment_type']) ?>
                            </span>
                            <?php if ($d['cluster_name']): ?><span class="plat-sub"><?= plat_h($d['cluster_name']) ?></span><?php endif; ?>
                        </td>
                        <td><?= plat_h($d['oracle_version'] ?: '—') ?><span class="plat-sub"><?= plat_h($d['edition']) ?></span></td>
                        <td><span class="plat-pill neutral"><?= plat_h($d['environment'] ?: '—') ?></span></td>
                        <td><?= (int) ($nodeCounts[(int) $d['id']] ?? 0) ?></td>
                        <td><?= number_format((float) $d['size_gb'], 1) ?> GB<span class="plat-sub"><?= plat_h($d['storage_type']) ?></span></td>
                        <td>
                            <?php $dg = (string) $d['dataguard_role']; ?>
                            <?php if ($dg !== '' && $dg !== 'None'): ?>
                                <span class="plat-pill warn"><?= plat_h($dg) ?></span>
                                <span class="plat-sub"><?= plat_h($d['dataguard_peer']) ?></span>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td><span class="plat-pill <?= platformStatusClass((string) $d['status']) ?>"><?= plat_h($d['status']) ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <button type="button" class="plat-icon-btn plat-icon-view" title="Nodes"
                                    onclick="oraNodes(<?= (int) $d['id'] ?>, '<?= plat_h(addslashes($d['db_name'])) ?>')">🖧</button>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='oraOpen(<?= json_encode($d, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History"
                                        onclick="oraHistory(<?= (int) $d['id'] ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="oraDelete(<?= (int) $d['id'] ?>, '<?= plat_h(addslashes($d['db_name'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="plat-modal" id="oraModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="oraTitle">Add Database</h2>
            <button type="button" class="plat-close" onclick="platClose('oraModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">A standalone database has one node; RAC and Data Guard have several.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="ora_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>DB Name *</label><input type="text" name="db_name" id="ora_db_name" required></div>
                <div class="plat-field"><label>DB Unique Name</label><input type="text" name="db_unique_name" id="ora_db_unique_name"></div>
                <div class="plat-field"><label>SID</label><input type="text" name="oracle_sid" id="ora_oracle_sid"></div>

                <div class="plat-field"><label>Deployment</label>
                    <select name="deployment_type" id="ora_deployment_type">
                        <?php foreach ($deployTypes as $d): ?><option value="<?= plat_h($d) ?>"><?= plat_h($d) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Version</label>
                    <select name="oracle_version" id="ora_oracle_version">
                        <option value="">—</option>
                        <?php foreach ($versions as $v): ?><option value="<?= plat_h($v) ?>"><?= plat_h($v) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Edition</label>
                    <select name="edition" id="ora_edition">
                        <option value="">—</option>
                        <?php foreach ($editions as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Patch Level / PSU</label><input type="text" name="patch_level" id="ora_patch_level"></div>
                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="ora_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Status</label>
                    <select name="status" id="ora_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Project</label><input type="text" name="project" id="ora_project"></div>
                <div class="plat-field"><label>Application</label><input type="text" name="application" id="ora_application"></div>
                <div class="plat-field"><label>Support Level</label><input type="text" name="support_level" id="ora_support_level"></div>

                <div class="plat-section-title">Cluster &amp; connectivity</div>
                <div class="plat-field"><label>Cluster Name (GI)</label><input type="text" name="cluster_name" id="ora_cluster_name"></div>
                <div class="plat-field"><label>SCAN Name</label><input type="text" name="scan_name" id="ora_scan_name"></div>
                <div class="plat-field"><label>SCAN IPs</label><input type="text" name="scan_ips" id="ora_scan_ips" placeholder="comma separated"></div>
                <div class="plat-field"><label>Listener Port</label><input type="text" name="listener_port" id="ora_listener_port" placeholder="1521"></div>
                <div class="plat-field"><label>Managed By</label><input type="text" name="managed_by" id="ora_managed_by"></div>
                <div class="plat-field"><label>Character Set</label><input type="text" name="character_set" id="ora_character_set" placeholder="AL32UTF8"></div>

                <div class="plat-section-title">Storage &amp; protection</div>
                <div class="plat-field"><label>Storage Type</label>
                    <select name="storage_type" id="ora_storage_type">
                        <option value="">—</option>
                        <?php foreach ($storageTypes as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>ASM Diskgroups</label><input type="text" name="asm_diskgroups" id="ora_asm_diskgroups" placeholder="+DATA, +FRA"></div>
                <div class="plat-field"><label>Size (GB)</label><input type="number" step="0.1" name="size_gb" id="ora_size_gb" value="0" min="0"></div>
                <div class="plat-field"><label>Archivelog Mode</label>
                    <select name="archivelog_mode" id="ora_archivelog_mode">
                        <option value="">—</option>
                        <?php foreach ($archModes as $a): ?><option value="<?= plat_h($a) ?>"><?= plat_h($a) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Data Guard Role</label>
                    <select name="dataguard_role" id="ora_dataguard_role">
                        <?php foreach ($dgRoles as $r): ?><option value="<?= plat_h($r) ?>"><?= plat_h($r) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Data Guard Peer</label><input type="text" name="dataguard_peer" id="ora_dataguard_peer"></div>

                <div class="plat-section-title">Backup &amp; ownership</div>
                <div class="plat-field"><label>Backup Tool</label><input type="text" name="backup_tool" id="ora_backup_tool" placeholder="RMAN / Commvault"></div>
                <div class="plat-field"><label>Backup Schedule</label><input type="text" name="backup_schedule" id="ora_backup_schedule"></div>
                <div class="plat-field"><label>Last Backup</label><input type="date" name="last_backup_date" id="ora_last_backup_date"></div>
                <div class="plat-field"><label>Technical Owner</label><input type="text" name="technical_owner" id="ora_technical_owner"></div>
                <div class="plat-field"><label>Owner Email</label><input type="email" name="technical_owner_email" id="ora_technical_owner_email"></div>
                <div class="plat-field"><label>DBA Owner</label><input type="text" name="dba_owner" id="ora_dba_owner"></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="ora_notes" rows="2"></textarea></div>

                <div class="plat-section-title">Nodes</div>
                <div class="full">
                    <div id="oraNodeRows"></div>
                    <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="oraAddNode()">+ Add node</button>
                </div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('oraModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Database</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="oraNodesModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="oraNodesTitle">Nodes</h2>
            <button type="button" class="plat-close" onclick="platClose('oraNodesModal')">&times;</button></div>
        <div id="oraNodesBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="oraHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="oraHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('oraHistModal')">&times;</button></div>
        <div id="oraHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="oraDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete database</h2>
            <button type="button" class="plat-close" onclick="platClose('oraDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete <strong id="oraDelName"></strong> and its node records? This cannot be undone.</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="oraDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('oraDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<script>
const ORA_ROLES  = <?= json_encode($nodeRoles) ?>;
const ORA_FIELDS = <?= json_encode(array_keys($oraFields)) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function oraNodeRow(n) {
    n = n || {};
    const roles = ORA_ROLES.map(r => `<option value="${r}" ${n.node_role === r ? 'selected' : ''}>${r}</option>`).join('');
    const row = document.createElement('div');
    row.className = 'plat-filters';
    row.style.marginBottom = '8px';
    row.innerHTML =
        `<div class="plat-field"><input list="platHostnames" name="node_hostname[]" placeholder="hostname" value="${n.hostname || ''}"></div>
         <div class="plat-field"><input name="node_instance[]" placeholder="instance" style="min-width:120px" value="${n.instance_name || ''}"></div>
         <div class="plat-field"><select name="node_role[]">${roles}</select></div>
         <div class="plat-field"><input name="node_vip[]" placeholder="VIP" style="min-width:120px" value="${n.vip_address || ''}"></div>
         <div class="plat-field"><input name="node_status[]" placeholder="Up" style="min-width:100px" value="${n.status || 'Up'}"></div>
         <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="this.parentNode.remove()">Remove</button>`;
    return row;
}

function oraAddNode(n) { document.getElementById('oraNodeRows').appendChild(oraNodeRow(n)); }

function oraOpen(data) {
    const editing = !!data;
    document.getElementById('oraTitle').innerText = editing ? 'Edit Database' : 'Add Database';
    document.getElementById('ora_id').value = editing ? data.id : '';

    ORA_FIELDS.forEach(f => {
        const el = document.getElementById('ora_' + f);
        if (!el) return;
        el.value = editing ? (data[f] ?? '') : (el.type === 'number' ? 0 : '');
    });

    document.getElementById('oraNodeRows').innerHTML = '';

    if (editing) {
        fetch('oracle_db.php?action=nodes_json&id=' + encodeURIComponent(data.id))
            .then(r => r.ok ? r.json() : [])
            .then(list => { (list || []).forEach(oraAddNode); if (!list || !list.length) oraAddNode(); })
            .catch(() => oraAddNode());
    } else {
        oraAddNode();
    }

    platOpen('oraModal');
}

function oraNodes(id, name) {
    document.getElementById('oraNodesTitle').innerText = 'Nodes — ' + name;
    document.getElementById('oraNodesBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('oraNodesModal');
    fetch('oracle_db.php?action=nodes&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('oraNodesBody').innerHTML = h; })
        .catch(() => { document.getElementById('oraNodesBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function oraHistory(id) {
    document.getElementById('oraHistTitle').innerText = id ? 'Audit History — database #' + id : 'Module Audit History';
    document.getElementById('oraHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('oraHistModal');
    fetch('oracle_db.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('oraHistBody').innerHTML = h; })
        .catch(() => { document.getElementById('oraHistBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function oraDelete(id, name) {
    document.getElementById('oraDelId').value = id;
    document.getElementById('oraDelName').innerText = name;
    platOpen('oraDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
