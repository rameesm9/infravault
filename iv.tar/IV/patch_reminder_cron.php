<?php

// patch_reminder_cron.php
//
// Run this once a day via cron / Task Scheduler / a Podman systemd timer.
// It is NOT meant to be opened in a browser — it has no session/auth
// check because it's a command-line script.
//
// Example crontab (runs daily at 07:00):
//   0 7 * * * /usr/bin/php /var/www/html/patch_reminder_cron.php >> /var/log/infravault_patch_reminders.log 2>&1
//
// Example Podman/systemd timer: create a oneshot service that runs
//   php /var/www/html/patch_reminder_cron.php
// and a matching .timer unit set to OnCalendar=*-*-* 07:00:00.

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script may only be run from the command line.\n");
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/patching_db.php';
require_once __DIR__ . '/includes/mail-helpers.php';

registerMailModule($pdo, 'patch_reminder', 'Patch Reminder Notifications');

if (!isMailModuleEnabled($pdo, 'patch_reminder')) {
    echo "InfraVault patch reminder run — " . date('Y-m-d H:i:s') . "\n";
    echo "Patch reminder mail is disabled (globally or for this module) in Settings. Nothing to do.\n";
    exit(0);
}

$targetDate = date('Y-m-d', strtotime('+7 days'));

echo "InfraVault patch reminder run — " . date('Y-m-d H:i:s') . "\n";
echo "Looking for schedules due on {$targetDate} (7 days from today)...\n";

$stmt = $pdo->prepare("
    SELECT ps.*, u.first_name, u.last_name, u.email
    FROM patch_schedules ps
    LEFT JOIN users u ON u.id = ps.assigned_to
    WHERE ps.scheduled_date = ?
      AND ps.reminder_sent_at IS NULL
      AND ps.status NOT IN ('Completed', 'N/A', 'Excluded')
      AND ps.assigned_to IS NOT NULL
");
$stmt->execute([$targetDate]);
$rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

if (!$rows) {
    echo "Nothing due. Done.\n";
    exit(0);
}

$sent = 0;
$failed = 0;

foreach ($rows as $row) {

    if (empty($row['email'])) {
        echo "[SKIP] Schedule #{$row['id']} ({$row['project']}/{$row['application']}) — assigned user has no email address.\n";
        continue;
    }

    $assigneeName = trim($row['first_name'] . ' ' . $row['last_name']);

    $subject = "Patch Reminder: {$row['project']} / {$row['application']} — due {$row['scheduled_date']}";

    $html = '<p>Hi ' . htmlspecialchars($assigneeName, ENT_QUOTES, 'UTF-8') . ',</p>'
        . '<p>This is a reminder that the patching activity below is scheduled for '
        . '<strong>' . htmlspecialchars($row['scheduled_date'], ENT_QUOTES, 'UTF-8') . '</strong> — one week from today.</p>'
        . '<table cellpadding="6" style="border-collapse:collapse;">'
        . '<tr><td><strong>Project</strong></td><td>' . htmlspecialchars($row['project'], ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td><strong>Application</strong></td><td>' . htmlspecialchars($row['application'], ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td><strong>Support Level</strong></td><td>' . htmlspecialchars($row['support_level'], ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td><strong>Cycle</strong></td><td>Q' . (int) $row['quarter'] . ' ' . (int) $row['year'] . '</td></tr>'
        . '<tr><td><strong>CR</strong></td><td>' . htmlspecialchars($row['cr'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '<tr><td><strong>Current Status</strong></td><td>' . htmlspecialchars($row['status'], ENT_QUOTES, 'UTF-8') . '</td></tr>'
        . '</table>'
        . '<p>Please review the assignment in InfraVault and keep the status up to date as you progress.</p>';

    $result = sendAppMail($pdo, 'patch_reminder', $row['email'], $assigneeName, $subject, $html);

    if ($result['success']) {

        $pdo->prepare("UPDATE patch_schedules SET reminder_sent_at = CURRENT_TIMESTAMP WHERE id = ?")
            ->execute([$row['id']]);

        echo "[OK]   Reminder sent to {$row['email']} for schedule #{$row['id']} ({$row['project']}/{$row['application']}).\n";
        $sent++;

    } else {

        echo "[FAIL] Schedule #{$row['id']} ({$row['project']}/{$row['application']}) — {$result['message']}\n";
        $failed++;
    }
}

echo "Done. {$sent} sent, {$failed} failed, " . count($rows) . " total considered.\n";

exit($failed > 0 ? 1 : 0);
