<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Active Directory Server
    |--------------------------------------------------------------------------
    */

    'host' => 'dc01.company.local',

    /*
    | Use LDAPS.
    | 636 = LDAP over SSL/TLS
    */

    'port' => 636,

    /*
    | Your AD domain
    */

    'domain' => 'company.local',

    /*
    | Base DN
    */

    'base_dn' => 'DC=company,DC=local',

    /*
    | Optional service account used to search AD.
    |
    | IMPORTANT:
    | Do not use Domain Admin here.
    */

    'bind_user' => 'svc_infravault@company.local',

    'bind_password' => 'CHANGE_THIS_PASSWORD',

];

