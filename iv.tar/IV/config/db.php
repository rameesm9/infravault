<?php

// ============================================================
// APPLICATION TIMEZONE
// ============================================================
//
// Every date/time value entered through the UI (reminder date+time,
// SOP review dates, etc.) is stored as a naive "wall clock" string with
// no timezone attached -- there's no timezone conversion anywhere in
// this app. That only produces correct results if PHP's own default
// timezone matches the timezone users actually intend those times to
// be in. Left unset, PHP defaults to UTC, which silently shifts every
// scheduled time (e.g. reminder emails) by however many hours separate
// UTC from the real timezone.
//
// APP_TIMEZONE lets a container deployment override this (Podman --env)
// without touching code; defaults to Asia/Riyadh to match this
// organization's .gov.sa domains configured elsewhere in the app.
//
date_default_timezone_set(getenv('APP_TIMEZONE') ?: 'Asia/Riyadh');


// ============================================================
// DATABASE CONNECTION
// ============================================================
//
// config/ is otherwise all code (schema/*.php, ldap.php) baked into the
// container image -- APP_DB_PATH lets a container deployment point the
// one actual piece of data in this directory at a separate mounted
// volume instead, without having to mount a volume over the whole
// config/ directory (which would hide the schema files the volume
// doesn't know about). Defaults to the original path, so plain/local
// usage is unaffected.
//
// Loaded before anything else can call a string function: without
// ext-mbstring an unguarded mb_* call is a fatal, and a fatal part-way
// down a page truncates the render before the footer -- which drops
// sidebar.js and makes the whole navigation appear broken.
require_once __DIR__ . '/../includes/mb-compat.php';


$db_file = getenv('APP_DB_PATH') ?: (__DIR__ . '/infravault.db');

try {

    $pdo = new PDO('sqlite:' . $db_file);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // WAL lets one process write while others read without blocking --
    // matters once the web container and the reminder daemon container
    // (reminder_notification_daemon.php) both open this same SQLite file
    // concurrently from a shared volume. Harmless for a single-container
    // / single-process deployment too, so this is set unconditionally.
    $pdo->exec('PRAGMA journal_mode = WAL');
    $pdo->exec('PRAGMA busy_timeout = 5000');

} catch (PDOException $e) {

    die(
        "Database connection failed: " .
        $e->getMessage()
    );
}


// ============================================================
// SCHEMA MODULES
// ============================================================
//
// Each file below creates (or upgrades) the tables for one
// application module. They all share the $pdo connection
// opened above. Order matters only where a module seeds data
// into a table created by an earlier module (e.g. license
// warranty seeds into permissions/pages).
//

// The modules themselves live in config/schema-bootstrap.php. They are only
// executed when something about them has actually changed: every one of them
// is written to be idempotent (CREATE TABLE IF NOT EXISTS, INSERT OR IGNORE),
// so after the first run they do ~200 statements of no-op work. Measured,
// that was ~180 ms of every ~200 ms page request.
//
// The guard fails open: any problem reading or writing the marker runs the
// full bootstrap, so the worst case is the old behaviour rather than a
// missing table. Set APP_FORCE_SCHEMA=1 to re-run it unconditionally, which
// is the escape hatch if a table is ever dropped by hand.

require_once __DIR__ . '/schema-bootstrap.php';

$schemaSignature = schemaSignature();
$schemaNeedsRun  = true;

if (getenv('APP_FORCE_SCHEMA') !== '1') {
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS schema_state (k TEXT PRIMARY KEY, v TEXT NOT NULL)");

        $stmt = $pdo->prepare("SELECT v FROM schema_state WHERE k = 'signature'");
        $stmt->execute();

        $schemaNeedsRun = ($stmt->fetchColumn() !== $schemaSignature);
    } catch (Throwable $e) {
        error_log('Schema signature check failed, running full bootstrap: ' . $e->getMessage());
        $schemaNeedsRun = true;
    }
}

if ($schemaNeedsRun) {
    runAllSchemaModules($pdo);

    try {
        // Two requests racing here both run the same idempotent modules and
        // write the same signature, so the race is harmless.
        $pdo->prepare("
            INSERT INTO schema_state (k, v) VALUES ('signature', ?)
            ON CONFLICT(k) DO UPDATE SET v = excluded.v
        ")->execute([$schemaSignature]);
    } catch (Throwable $e) {
        // Not fatal: the schema is applied, the marker just did not stick,
        // so the next request pays the full cost again.
        error_log('Could not record schema signature: ' . $e->getMessage());
    }
}

// ============================================================
// DATABASE READY
// ============================================================


// ============================================================
// SECURITY BOOTSTRAP
// ============================================================
//
// Deliberately wired here rather than into includes/header.php: this file
// is required by 65 of the application's 70 pages, and always before any
// output, which is what response headers and session cookie flags need.
// header.php is only reached by the 30 pages that render a full layout,
// so AJAX endpoints, CSV exports and action handlers would have been left
// unprotected.
//
// securityBootstrap() no-ops under CLI, so the reminder daemon and the two
// cron scripts are unaffected.

require_once __DIR__ . '/../includes/security.php';
securityBootstrap($pdo);


// ============================================================
// AUTHORIZATION
// ============================================================
//
// Loaded here so can() / requireLogin() / requirePermission() are
// available to every page without each one remembering to include it --
// the same reason the security bootstrap lives here.

require_once __DIR__ . '/../includes/authz.php';


// ============================================================
// TEAM REGISTRY HELPERS
// ============================================================
//
// Loaded here for the same reason: signup.php requires nothing but this
// file, and it needs to render the team dropdown from the registry
// rather than from its own hardcoded (and already drifted) copy.

require_once __DIR__ . '/../includes/team-helpers.php';
