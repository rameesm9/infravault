<?php
/**
 * Teams registry.
 *
 * Until now there was no such thing as a team record. The team list was
 * a hardcoded PHP array duplicated in users.php (twice) and signup.php,
 * while everything that needed to *read* the list (permission-helpers'
 * getAllTeams(), reminders' getUniqueTeams()) derived it from
 * SELECT DISTINCT team FROM users instead.
 *
 * That had two consequences worth naming, because this table exists to
 * fix them:
 *
 *   - The three hardcoded copies had already drifted. signup.php offers
 *     "AD and Exchage" where users.php offers "AD and Exchange", so a
 *     user who self-registered landed in a team that the admin screen
 *     could not select, and silently got moved out of it on the next
 *     save.
 *
 *   - A team with no members did not exist at all, so it could not be
 *     created ahead of the people joining it.
 *
 * Team membership stays denormalised on users.team (a name, not an id).
 * Changing that is a much larger migration touching every module that
 * scopes visibility by team name; this table is the registry of valid
 * names, and users.team continues to hold the chosen name.
 */

function runTeamsSchema(PDO $pdo): void
{
    /*
    | Whether the table predates this call, checked BEFORE the CREATE
    | below makes the question unanswerable.
    |
    | This gate is what makes deletion stick. db.php is included by every
    | page, so this function runs on every single request. Seeding the
    | defaults unconditionally meant a deleted team was re-inserted on
    | the very next page load: the DELETE succeeded, the success message
    | was shown, and the team was back before the user could see it gone.
    |
    | Defaults are a first-run convenience, not a set of rows the
    | application insists on owning. Once the table exists, its contents
    | belong to whoever manages teams in users.php.
    */
    $teams_table_existed = (bool) $pdo->query("
        SELECT 1
        FROM sqlite_master
        WHERE type = 'table' AND name = 'teams'
    ")->fetchColumn();

    /*
    | COLLATE NOCASE on the unique name: 'Cloud' and 'cloud' are the same
    | team to every human who will use this screen, and letting both
    | exist would split that team's visibility scoping in two.
    */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            team_name TEXT NOT NULL COLLATE NOCASE UNIQUE,
            description TEXT,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    if ($teams_table_existed) {
        return;
    }

    try {

        $insert = $pdo->prepare("
            INSERT OR IGNORE INTO teams (team_name, created_by)
            VALUES (?, ?)
        ");

        /*
        | The list previously hardcoded in users.php. Seeded rather than
        | left to the backfill below so a fresh install still offers the
        | standard teams before anyone has signed up.
        |
        | Seeded exactly once, on the request that creates the table --
        | see the guard above.
        */
        $default_teams = [
            'AD and Exchange',
            'Backup and Storage',
            'Cloud',
            'Database',
            'DR',
            'Linux and Containers',
            'Others',
            'PAM',
            'Windows',
        ];

        foreach ($default_teams as $team_name) {
            $insert->execute([$team_name, 'system']);
        }

        /*
        | Backfill every team name already in use. Without this, an
        | existing user whose team is not one of the nine defaults (the
        | seeded admin's 'Linux', or anything typed through the old
        | signup form) would point at a team the registry does not list,
        | and the admin dropdown would reassign them on the next save.
        */
        $in_use = $pdo->query("
            SELECT DISTINCT TRIM(team)
            FROM users
            WHERE team IS NOT NULL AND TRIM(team) != ''
        ")->fetchAll(PDO::FETCH_COLUMN);

        foreach ($in_use as $team_name) {
            $insert->execute([$team_name, 'migrated']);
        }

    } catch (Throwable $e) {
        error_log('Unable to seed teams table: ' . $e->getMessage());
    }
}
