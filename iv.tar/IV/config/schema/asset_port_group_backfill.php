<?php

require_once __DIR__ . '/../../includes/ip-helpers.php';

/**
 * One-time backfill: assets saved before VLAN/Port Group became derived
 * fields (see asset.php's "save" handler and includes/ip-helpers.php's
 * ipFindRangeForAddress()) still have whatever was typed in manually, or
 * nothing at all, even when their IP Address actually falls inside a
 * range that ip.php already has on file. Going forward every save
 * recomputes both fields automatically; this just catches up the rows
 * that existed before that logic did.
 *
 * Runs once. Guarded by a one-row marker table rather than re-scanning
 * every asset row on every request -- must run after config/schema/ip.php
 * (ip_ranges) and config/schema/assets.php (asset.port_group) have both
 * already created their tables/columns.
 */

function runAssetPortGroupBackfill(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS asset_port_group_backfill_marker (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            completed_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $alreadyDone = (int) $pdo->query("
        SELECT COUNT(*) FROM asset_port_group_backfill_marker
    ")->fetchColumn();

    if ($alreadyDone > 0) {
        return;
    }

    try {
        $rows = $pdo->query("
            SELECT id, ip_address
            FROM asset
            WHERE ip_address IS NOT NULL AND TRIM(ip_address) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);

        $update = $pdo->prepare("UPDATE asset SET vlan = ?, port_group = ? WHERE id = ?");

        foreach ($rows as $row) {

            $match = ipFindRangeForAddress($pdo, $row['ip_address']);

            // Blank rather than skip when nothing matches -- a stale
            // manually-typed value with no current range backing it is
            // exactly the "disagrees with ip.php" state this exists to
            // eliminate.
            $update->execute([
                $match['vlan'] ?? '',
                $match['portgroup'] ?? '',
                $row['id'],
            ]);
        }

        $pdo->exec("INSERT INTO asset_port_group_backfill_marker DEFAULT VALUES");

    } catch (Throwable $e) {
        error_log('Asset VLAN/Port Group backfill failed: ' . $e->getMessage());
    }
}
