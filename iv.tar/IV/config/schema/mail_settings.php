<?php
/**
 * Centralized SMTP / mail settings.
 *
 * Replaces the old pattern of a hardcoded mail_config.php file (which also
 * had a broken path -- patching.php and patch_reminder_cron.php required
 * config/mail_config.php, a file that never existed; only mail_config.php
 * at the project root did, so patch reminder emails were fatal-erroring).
 *
 * Storing this in the database instead of a source file means it's editable
 * from the Settings UI at runtime and persists via whatever volume the
 * config/infravault.db file is already mounted on in the container --
 * no image rebuild or file edit inside the container needed.
 *
 * Sensitive values can still be overridden by environment variables at
 * read-time (see includes/mail-helpers.php), which is the more idiomatic
 * way to inject secrets into a Podman/container deployment.
 */

function runMailSettingsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS mail_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            is_enabled INTEGER NOT NULL DEFAULT 0,
            smtp_host TEXT NOT NULL DEFAULT '',
            smtp_port INTEGER NOT NULL DEFAULT 587,
            smtp_encryption TEXT NOT NULL DEFAULT 'tls',
            smtp_username TEXT NOT NULL DEFAULT '',
            smtp_password TEXT NOT NULL DEFAULT '',
            from_email TEXT NOT NULL DEFAULT '',
            from_name TEXT NOT NULL DEFAULT 'InfraVault',
            smtp_timeout INTEGER NOT NULL DEFAULT 15,
            updated_by TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Singleton row -- the settings form always edits id=1.
    $pdo->exec("INSERT OR IGNORE INTO mail_settings (id) VALUES (1)");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS mail_module_toggles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            module_key TEXT UNIQUE NOT NULL,
            module_label TEXT NOT NULL,
            is_enabled INTEGER NOT NULL DEFAULT 0
        )
    ");

    // Register the one module that currently sends mail. Other modules can
    // call registerMailModule() (includes/mail-helpers.php) to add their
    // own toggle the first time they run, without touching this file.
    $pdo->prepare("
        INSERT OR IGNORE INTO mail_module_toggles (module_key, module_label)
        VALUES ('patch_reminder', 'Patch Reminder Notifications')
    ")->execute();
}
