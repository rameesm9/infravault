<?php

/**
 * The SOP export document template: one running header and one running
 * footer, shared by every SOP the module exports to Word.
 *
 * Both bands are modelled the way a Word header actually works -- three
 * cells (left, centre, right) laid out on tab stops -- plus one optional
 * logo per band, placed in whichever cell the Admin chooses. The cells hold
 * plain text with {tokens}, never HTML: an earlier contenteditable version
 * lost the caret whenever the file picker opened, so the logo silently
 * failed to insert, and it gave no dependable way to align anything.
 *
 * Single-row settings table, following ldap_settings / mail_settings /
 * security_settings. Runs after team-permissions-migration.php, which
 * defines addColumnIfMissing() and columnExists().
 */

function runSopDocumentSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sop_document_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            show_page_numbers INTEGER NOT NULL DEFAULT 1,
            updated_by TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Singleton row -- the editor always writes id=1.
    $pdo->exec("INSERT OR IGNORE INTO sop_document_settings (id) VALUES (1)");

    // Every cell carries its own text and its own optional logo, so a band
    // can show (say) the company mark on the left and an accreditation mark
    // on the right at the same time.
    foreach (['header', 'footer'] as $band) {
        foreach (['left', 'center', 'right'] as $cell) {
            addColumnIfMissing($pdo, 'sop_document_settings', "{$band}_{$cell}", "TEXT NOT NULL DEFAULT ''");
            addColumnIfMissing($pdo, 'sop_document_settings', "{$band}_{$cell}_logo", "TEXT NOT NULL DEFAULT ''");
            addColumnIfMissing($pdo, 'sop_document_settings', "{$band}_{$cell}_logo_height", "INTEGER NOT NULL DEFAULT 40");
        }
    }

    /*
    | Move the earlier one-logo-per-band setting into the cell its position
    | named, then drop the three columns it used.
    */
    foreach (['header', 'footer'] as $band) {
        if (!columnExists($pdo, 'sop_document_settings', $band . '_logo')) {
            continue;
        }

        $row = $pdo->query("
            SELECT {$band}_logo AS logo,
                   {$band}_logo_position AS position,
                   {$band}_logo_height AS height
            FROM sop_document_settings WHERE id = 1
        ")->fetch(PDO::FETCH_ASSOC);

        if ($row && trim((string)$row['logo']) !== '') {
            $cell = in_array($row['position'], ['left', 'center', 'right'], true) ? $row['position'] : 'left';
            $height = (int)$row['height'] ?: 40;

            $pdo->prepare("
                UPDATE sop_document_settings
                SET {$band}_{$cell}_logo = ?, {$band}_{$cell}_logo_height = ?
                WHERE id = 1 AND {$band}_{$cell}_logo = ''
            ")->execute([$row['logo'], $height]);
        }

        foreach (['_logo', '_logo_position', '_logo_height'] as $suffix) {
            try {
                $pdo->exec("ALTER TABLE sop_document_settings DROP COLUMN " . $band . $suffix);
            } catch (Throwable $e) {
                // Older SQLite: harmless, nothing reads it.
            }
        }
    }

    /*
    | Carry across the short-lived rich-text version of the bands: its text
    | becomes the left cell, so nothing an Admin already typed is lost.
    | Then drop the old columns (SQLite 3.35+; left in place on anything
    | older, where nothing reads them).
    */
    foreach (['header', 'footer'] as $band) {
        $legacy = $band . '_html';

        if (!columnExists($pdo, 'sop_document_settings', $legacy)) {
            continue;
        }

        $row = $pdo->query("SELECT $legacy AS html, {$band}_left AS cell FROM sop_document_settings WHERE id = 1")
            ->fetch(PDO::FETCH_ASSOC);

        if ($row && trim((string)$row['cell']) === '' && trim((string)$row['html']) !== '') {
            $text = trim(html_entity_decode(strip_tags((string)$row['html']), ENT_QUOTES, 'UTF-8'));

            if ($text !== '') {
                $pdo->prepare("UPDATE sop_document_settings SET {$band}_left = ? WHERE id = 1")
                    ->execute([$text]);
            }
        }

        try {
            $pdo->exec("ALTER TABLE sop_document_settings DROP COLUMN $legacy");
        } catch (Throwable $e) {
            // Older SQLite: harmless, nothing reads it.
        }
    }

    /*
    | The bands were briefly per-SOP columns before that. Removed here for
    | the same reason.
    */
    foreach (['doc_header', 'doc_footer'] as $retired) {
        if (columnExists($pdo, 'sops', $retired)) {
            try {
                $pdo->exec("ALTER TABLE sops DROP COLUMN $retired");
            } catch (Throwable $e) {
                // Left in place; nothing reads it.
            }
        }
    }
}
