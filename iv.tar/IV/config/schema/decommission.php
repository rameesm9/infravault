<?php

// ============================================================
// DECOMMISSION
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL,

        server_state TEXT,

        support_level TEXT,

        project TEXT,

        application_name TEXT,

        ip_address TEXT,

        additional_ips TEXT,

        decommission_start_date TEXT,

        decommission_end_date TEXT,

        created_by TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT,

        updated_at DATETIME
    )
");


// ============================================================
// DECOMMISSION TASKS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_tasks (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        decommission_id INTEGER,

        task_name TEXT NOT NULL,

        status TEXT DEFAULT 'Pending',

        remarks TEXT
    )
");


// ============================================================
// DECOMMISSION HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS decommission_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        decommission_id INTEGER,

        action_type TEXT,

        performed_by TEXT,

        details TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// SAFE DECOMMISSION TASK COLUMN UPGRADES
// ============================================================

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN status TEXT DEFAULT 'Pending'
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN remarks TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission_tasks
        ADD COLUMN req_no TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}

try {

    $pdo->exec("
        ALTER TABLE decommission
        ADD COLUMN attachment TEXT
    ");

} catch (PDOException $e) {

    // Column already exists.

}
