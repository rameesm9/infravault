<?php

// ============================================================
// IP ADDRESS MANAGEMENT
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS ip_ranges (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        ip_range TEXT NOT NULL,

        vlan TEXT,

        subnet TEXT,

        subnet_mask TEXT,

        gateway TEXT,

        network_address TEXT,

        portgroup TEXT,

        cidr TEXT,

        usable_range TEXT,

        broadcast TEXT,

        total_hosts INTEGER DEFAULT 0,

        usable_hosts INTEGER DEFAULT 0,

        environment TEXT,

        project TEXT,

        project_code TEXT,

        comments TEXT,

        created_by TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT,

        updated_at DATETIME
    )
");


// ============================================================
// SAFE IP COLUMN UPGRADES
// ============================================================

$ip_columns = [
    "subnet_mask TEXT",
    "network_address TEXT",
    "project_code TEXT",
    "updated_by TEXT",
    "updated_at DATETIME"
];

foreach ($ip_columns as $column) {

    try {

        $pdo->exec(
            "ALTER TABLE ip_ranges ADD COLUMN " . $column
        );

    } catch (PDOException $e) {

        // Column already exists.

    }
}


// ============================================================
// IP RANGE HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS ip_ranges_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        ip_range_id INTEGER NOT NULL,

        action_type TEXT NOT NULL,

        old_data TEXT,

        new_data TEXT,

        performed_by TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// IP COLUMN PREFERENCES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS ip_column_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER NOT NULL,

        columns TEXT NOT NULL,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
