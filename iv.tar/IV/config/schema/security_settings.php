<?php
/**
 * Security settings and login attempt tracking.
 *
 * Only the *tunables* live here. Controls that must not be switchable at
 * runtime -- CSRF verification, the security response headers, session
 * cookie flags, server-side authorization -- are enforced unconditionally
 * in includes/security.php and the per-page permission checks. A database
 * toggle that can disable a defence is itself a vulnerability: anyone who
 * reaches Settings could turn the protection off, and a bad save would
 * silently drop it application-wide.
 *
 * The one deliberate exception is CSP mode, because a Content-Security-
 * Policy genuinely does need a report-only rollout period on an app that
 * still uses inline event handlers.
 */

function runSecuritySchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS security_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),

            -- Sessions
            idle_timeout_minutes INTEGER NOT NULL DEFAULT 30,
            absolute_timeout_hours INTEGER NOT NULL DEFAULT 12,

            -- Login lockout
            lockout_enabled INTEGER NOT NULL DEFAULT 1,
            lockout_threshold INTEGER NOT NULL DEFAULT 5,
            lockout_window_minutes INTEGER NOT NULL DEFAULT 15,
            lockout_duration_minutes INTEGER NOT NULL DEFAULT 15,

            -- Password policy (local accounts only; LDAP accounts are
            -- governed by the directory's own policy and never validated here)
            password_min_length INTEGER NOT NULL DEFAULT 12,
            password_require_upper INTEGER NOT NULL DEFAULT 1,
            password_require_lower INTEGER NOT NULL DEFAULT 1,
            password_require_number INTEGER NOT NULL DEFAULT 1,
            password_require_symbol INTEGER NOT NULL DEFAULT 0,

            -- Content-Security-Policy: 'off' | 'report-only' | 'enforce'
            csp_mode TEXT NOT NULL DEFAULT 'report-only',

            updated_by TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Singleton row -- the settings form always edits id = 1.
    $pdo->exec("INSERT OR IGNORE INTO security_settings (id) VALUES (1)");

    /*
     * Login attempt log. Backs the lockout check and doubles as the
     * brute-force audit trail -- successful logins are recorded too, so
     * "failed x5 then succeeded" is visible rather than just disappearing.
     *
     * attempted_at is a Unix epoch INTEGER, not a DATETIME. SQLite's
     * CURRENT_TIMESTAMP is UTC while this application runs PHP in
     * Asia/Riyadh (see APP_TIMEZONE in config/db.php); comparing the two
     * would shift every lockout window by the UTC offset. An epoch has no
     * timezone to disagree about.
     */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS login_attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            identifier TEXT NOT NULL,
            ip_address TEXT NOT NULL DEFAULT '',
            success INTEGER NOT NULL DEFAULT 0,
            attempted_at INTEGER NOT NULL,
            user_agent TEXT NOT NULL DEFAULT ''
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_login_attempts_identifier
        ON login_attempts(identifier, attempted_at)
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_login_attempts_ip
        ON login_attempts(ip_address, attempted_at)
    ");

    /*
     * Columns added after this table first shipped go here, for the same
     * reason config/schema/inventory.php carries a migration block:
     * CREATE TABLE IF NOT EXISTS is a no-op on an existing table.
     */
    $required = [
        'idle_timeout_minutes'     => 'INTEGER NOT NULL DEFAULT 30',
        'absolute_timeout_hours'   => 'INTEGER NOT NULL DEFAULT 12',
        'lockout_enabled'          => 'INTEGER NOT NULL DEFAULT 1',
        'lockout_threshold'        => 'INTEGER NOT NULL DEFAULT 5',
        'lockout_window_minutes'   => 'INTEGER NOT NULL DEFAULT 15',
        'lockout_duration_minutes' => 'INTEGER NOT NULL DEFAULT 15',
        'password_min_length'      => 'INTEGER NOT NULL DEFAULT 12',
        'password_require_upper'   => 'INTEGER NOT NULL DEFAULT 1',
        'password_require_lower'   => 'INTEGER NOT NULL DEFAULT 1',
        'password_require_number'  => 'INTEGER NOT NULL DEFAULT 1',
        'password_require_symbol'  => 'INTEGER NOT NULL DEFAULT 0',
        'csp_mode'                 => "TEXT NOT NULL DEFAULT 'report-only'",
    ];

    try {
        $existing = [];
        foreach ($pdo->query('PRAGMA table_info(security_settings)')->fetchAll(PDO::FETCH_ASSOC) as $col) {
            $existing[] = $col['name'];
        }

        foreach ($required as $name => $definition) {
            if (!in_array($name, $existing, true)) {
                $pdo->exec("ALTER TABLE security_settings ADD COLUMN {$name} {$definition}");
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to migrate security_settings: ' . $e->getMessage());
    }
}
