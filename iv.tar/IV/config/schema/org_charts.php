<?php
/**
 * Org & Escalation Charts.
 *
 * Four chart shapes share one storage model rather than getting a table
 * each, because three of the four are the same thing structurally -- an
 * ordered list of nodes, optionally parented:
 *
 *   hierarchy   a tree            (parent_id used)
 *   escalation  an ordered ladder (parent_id unused, tier_level ordered)
 *   cycle       an ordered ring   (parent_id unused, node_order ordered)
 *   raci        a grid            (nodes are the ROLE columns)
 *
 * RACI is the one that needs a second axis, so its activity rows live in
 * org_chart_raci_rows. The letters for a row are stored as a JSON array
 * indexed by the role's ordinal position within the chart, not by node id:
 * the editor rewrites every node on each save (rows are freely reordered,
 * renamed and deleted, so there is no stable client-side identity), which
 * would invalidate stored ids. Ordinals survive that rewrite because the
 * roles and the grid are posted together in one payload.
 *
 * Audit history is NOT given its own table here -- it goes to the shared
 * platform_history table with module = 'org_charts', via platformLog() in
 * includes/platform-helpers.php.
 */

function runOrgChartsSchema(PDO $pdo): void
{
    /*
    |--------------------------------------------------------------------------
    | CHARTS
    |--------------------------------------------------------------------------
    |
    | A chart is a published document: it has a version, an owner, a date it
    | takes effect and a date it should be reviewed. An escalation matrix
    | nobody has re-read in two years is worse than none, so the review date
    | is a first-class column rather than a line in the notes.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS org_charts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,
            chart_type TEXT NOT NULL DEFAULT 'hierarchy',
            template_key TEXT,

            description TEXT,
            owner_team TEXT,
            scope TEXT,

            status TEXT NOT NULL DEFAULT 'Draft',
            version TEXT,
            effective_date DATE,
            review_date DATE,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | NODES
    |--------------------------------------------------------------------------
    |
    | One wide table rather than four narrow ones. The columns that only
    | apply to one shape (respond_within, duration, tier_level) are simply
    | left empty by the others -- cheaper and far easier to render from than
    | four schemas that would each need their own editor, export and diff.
    |
    | People are free text on purpose: charts routinely name vendors, duty
    | rotas and roles that nobody currently holds, none of which exist as
    | rows in `users`.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS org_chart_nodes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chart_id INTEGER NOT NULL,

            parent_id INTEGER,
            node_order INTEGER NOT NULL DEFAULT 0,

            label TEXT NOT NULL,
            person_name TEXT,
            job_title TEXT,
            contact_email TEXT,
            contact_phone TEXT,
            contact_alt TEXT,

            tier_level INTEGER,
            respond_within TEXT,
            resolve_within TEXT,
            coverage TEXT,
            duration TEXT,

            node_notes TEXT,
            accent TEXT NOT NULL DEFAULT 'slate',

            FOREIGN KEY (chart_id) REFERENCES org_charts(id) ON DELETE CASCADE
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | RACI ACTIVITY ROWS
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS org_chart_raci_rows (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            chart_id INTEGER NOT NULL,

            activity TEXT NOT NULL,
            row_order INTEGER NOT NULL DEFAULT 0,

            -- JSON array of 'R' | 'A' | 'C' | 'I' | '', indexed by the role
            -- node's ordinal position in this chart.
            assignments TEXT NOT NULL DEFAULT '[]',
            notes TEXT,

            FOREIGN KEY (chart_id) REFERENCES org_charts(id) ON DELETE CASCADE
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_org_chart_nodes ON org_chart_nodes(chart_id, node_order, id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_org_chart_nodes_parent ON org_chart_nodes(parent_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_org_chart_raci ON org_chart_raci_rows(chart_id, row_order, id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_org_charts_type ON org_charts(chart_type, status)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    |
    | Same shape as platform.php: authzCan() denies any page key with no
    | row, so registering the key here is what makes the page appear in
    | Manage Permissions -- and what stops the gate failing open.
    */

    try {
        $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)")
            ->execute(['org_charts', 'Org & Escalation Charts']);

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'org_charts', 1, 1, 1, 1, 1, 1)
        ");

        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'org_charts', 0, 0, 0, 0, 0, 0)
        ");

        foreach ($roles as $role) {
            if (strtolower(trim((string) $role)) === 'admin') {
                $grantAll->execute([$role]);
            } else {
                $denyAll->execute([$role]);
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register Org Charts page permissions: ' . $e->getMessage());
    }
}
