<?php

// ============================================================
// DIAGRAMS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS diagrams (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        name TEXT NOT NULL,

        description TEXT DEFAULT '',

        diagram_data TEXT NOT NULL,

        created_by TEXT DEFAULT '',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT DEFAULT '',

        updated_at DATETIME

    )
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_diagrams_name
    ON diagrams(name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_diagrams_created_by
    ON diagrams(created_by)
");


// ============================================================
// DIAGRAM DOCUMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS diagram_documents (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        diagram_data TEXT NOT NULL,
        created_by TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT DEFAULT '',
        updated_at DATETIME
    )
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_diagram_docs_created_by
    ON diagram_documents(created_by)
");
