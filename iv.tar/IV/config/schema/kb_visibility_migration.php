<?php
/**
 * Fixes a real production bug: knowledge_base.visibility was created (long
 * before the team-sharing work in config/schema/team-permissions-migration.php)
 * with CHECK (visibility IN ('Private', 'Public')). SQLite's ALTER TABLE
 * cannot modify or drop an existing CHECK constraint, so when the app
 * started writing the new lowercase 'public'/'team'/'teams' values, every
 * single knowledge_base save started failing with:
 *   SQLSTATE[23000]: CHECK constraint failed: visibility IN ('Private', 'Public')
 *
 * The only way to change a CHECK constraint in SQLite is to rebuild the
 * table: rename it, create a new one with the corrected definition, copy
 * the data across (translating old values to new ones), then drop the old
 * table. This runs that rebuild, and is a no-op once done (it checks the
 * table's stored CREATE statement before touching anything).
 *
 * Old -> new value mapping:
 *   'Public'  -> 'public'   (same meaning, just re-cased)
 *   'Private' -> 'team'     (kept scoped down: owner_team stays NULL for
 *                            these rows, so nothing but the author + Admin
 *                            can see them -- the closest match to the old
 *                            "visible only to you and Admin" behavior;
 *                            nobody's visibility silently widens)
 *
 * No CHECK constraint on the rebuilt column -- sops.visibility and
 * known_issues.team_scoped_visibility don't have one either, and the app
 * layer already validates the value set in knowledge.php. A stale DB-level
 * constraint duplicating that is exactly what caused this bug.
 */

function runKbVisibilityMigration(PDO $pdo): void
{
    $tableSql = $pdo->query("
        SELECT sql FROM sqlite_master WHERE type='table' AND name='knowledge_base'
    ")->fetchColumn();

    if ($tableSql === false || strpos($tableSql, "CHECK (visibility IN ('Private', 'Public'))") === false) {
        return; // Already migrated, or a fresh install that never had the old constraint.
    }

    try {
        $pdo->exec('BEGIN TRANSACTION');

        $pdo->exec("ALTER TABLE knowledge_base RENAME TO knowledge_base_pre_visibility_fix");

        $pdo->exec("
            CREATE TABLE knowledge_base (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kb_number TEXT NOT NULL UNIQUE,
                title TEXT NOT NULL,
                category TEXT NOT NULL,
                description TEXT,
                visibility TEXT NOT NULL DEFAULT 'public',
                content_html TEXT,
                created_by INTEGER NOT NULL,
                updated_by INTEGER,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                version TEXT DEFAULT '1.0',
                owner_team TEXT DEFAULT NULL,
                FOREIGN KEY (created_by) REFERENCES users(id),
                FOREIGN KEY (updated_by) REFERENCES users(id)
            )
        ");

        /*
         * version and owner_team are read only if the old table actually has
         * them. A database created fresh by config/schema/knowledge_base.php
         * gets the old CHECK constraint (so this migration triggers) but no
         * version column -- selecting it unconditionally made every brand-new
         * installation die here, part-way through the schema bootstrap, with
         * "no such column: version" and only ~60% of its tables created.
         */
        $old = $pdo->query("PRAGMA table_info(knowledge_base_pre_visibility_fix)")
                   ->fetchAll(PDO::FETCH_COLUMN, 1);

        $versionExpr = in_array('version', $old, true) ? 'version' : "'1.0'";
        $ownerExpr   = in_array('owner_team', $old, true) ? 'owner_team' : 'NULL';

        $pdo->exec("
            INSERT INTO knowledge_base
                (id, kb_number, title, category, description, visibility,
                 content_html, created_by, updated_by, created_at, updated_at,
                 version, owner_team)
            SELECT
                id, kb_number, title, category, description,
                CASE WHEN LOWER(visibility) = 'public' THEN 'public' ELSE 'team' END,
                content_html, created_by, updated_by, created_at, updated_at,
                $versionExpr, $ownerExpr
            FROM knowledge_base_pre_visibility_fix
        ");

        $pdo->exec("DROP TABLE knowledge_base_pre_visibility_fix");

        // Recreate the indexes config/schema/knowledge_base.php defines --
        // dropping/renaming the table doesn't carry them over.
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_visibility ON knowledge_base(visibility)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_created_by ON knowledge_base(created_by)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_category ON knowledge_base(category)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_updated_at ON knowledge_base(updated_at)");

        $pdo->exec('COMMIT');
    } catch (Throwable $e) {
        $pdo->exec('ROLLBACK');
        error_log('knowledge_base visibility constraint migration failed: ' . $e->getMessage());
        throw $e;
    }
}
