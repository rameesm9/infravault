<?php
/**
 * LDAPS authentication settings.
 *
 * Singleton settings row (same pattern as mail_settings) editable from the
 * Settings page, plus the one column added to users: auth_source, which
 * tells the login flow whether to verify a user's password locally
 * (password_verify against the stored hash) or by binding live to LDAP.
 *
 * LDAP-sourced accounts still go through the existing pending-approval
 * flow in users.php unchanged -- is_approved=0 on first LDAP login, an
 * admin picks their role/team and approves them exactly like a local
 * signup.php registration, no changes needed there.
 */

function runLdapSettingsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS ldap_settings (
            id INTEGER PRIMARY KEY CHECK (id = 1),
            is_enabled INTEGER NOT NULL DEFAULT 0,
            host TEXT NOT NULL DEFAULT '',
            port INTEGER NOT NULL DEFAULT 636,
            encryption TEXT NOT NULL DEFAULT 'ldaps',
            base_dn TEXT NOT NULL DEFAULT '',
            bind_dn TEXT NOT NULL DEFAULT '',
            bind_password TEXT NOT NULL DEFAULT '',
            ca_cert TEXT NOT NULL DEFAULT '',
            verify_certificate INTEGER NOT NULL DEFAULT 1,
            user_search_filter TEXT NOT NULL DEFAULT '(sAMAccountName=%s)',
            default_role TEXT NOT NULL DEFAULT 'Read-only',
            updated_by TEXT,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $pdo->exec("INSERT OR IGNORE INTO ldap_settings (id) VALUES (1)");

    // 'local' for every existing account -- password_verify() keeps working
    // exactly as before for all of them. Only new LDAP-authenticated
    // accounts (created going forward) get auth_source='ldap'.
    addColumnIfMissing($pdo, 'users', 'auth_source', "TEXT NOT NULL DEFAULT 'local'");
}
