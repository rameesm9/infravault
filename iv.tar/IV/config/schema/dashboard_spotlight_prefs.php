<?php

// ============================================================
// DASHBOARD "FOR YOU" SPOTLIGHT -- PER-USER CUSTOMIZATION
// ============================================================
//
// Lets each user reorder or dismiss individual cards in the dashboard's
// personal notification spotlight (home.php). item_key identifies a
// specific underlying record (e.g. "reminder_14", "assigned_10") so a
// dismissal only ever hides that one item, never a whole category --
// a brand new reminder next week gets its own key and shows normally.
//
// Dismissing here never deletes or alters the underlying communication/
// reminder/sticky note; it only hides that card from this one user's
// dashboard.

function runDashboardSpotlightPrefsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS dashboard_spotlight_prefs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            user_id INTEGER NOT NULL,
            item_key TEXT NOT NULL,

            sort_order INTEGER,
            dismissed INTEGER NOT NULL DEFAULT 0,

            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

            UNIQUE(user_id, item_key)
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_dashboard_spotlight_prefs_user
        ON dashboard_spotlight_prefs(user_id)
    ");
}
