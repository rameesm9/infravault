<?php
/**
 * Audit trail for the Exception Register (patch.php), matching the same
 * action-log pattern already used for SOP/Knowledge Base (sop_audit /
 * knowledge_base_audit): who did what and when, distinct from
 * patch_exception_revisions (which stores full content snapshots, not a
 * simple action log).
 *
 * Also adds users.list_page_size -- a single per-user pagination
 * preference (15/20/30) reused across every paginated table in the app,
 * rather than a separate setting per page.
 */

function runPatchExceptionAuditSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS patch_exception_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exception_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            performed_by_id INTEGER,
            user_name TEXT NOT NULL,
            action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            details TEXT,
            FOREIGN KEY (exception_id) REFERENCES patch_exceptions(id)
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_patch_exception_audit_exception_id ON patch_exception_audit(exception_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_patch_exception_audit_date ON patch_exception_audit(action_date)");

    addColumnIfMissing($pdo, 'users', 'list_page_size', 'INTEGER NOT NULL DEFAULT 15');
}
