<?php

// ============================================================
// ASSET INVENTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS asset (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        asset_name TEXT NOT NULL,
        asset_type TEXT NOT NULL,

        manufacturer TEXT,
        model TEXT,
        serial_number TEXT,
        service_tag TEXT,
        hostname TEXT,
        ip_address TEXT,

        location TEXT,
        site TEXT,
        region TEXT,
        room TEXT,
        row TEXT,
        rack TEXT,

        cpu_model TEXT,
        cpu_count TEXT,
        total_cores TEXT,
        memory_gb TEXT,
        internal_storage TEXT,
        number_of_nics TEXT,
        hba_details TEXT,
        gpu_details TEXT,

        vlan TEXT,
        port_group TEXT,

        purchase_date TEXT,
        vendor TEXT,

        warranty_start_date TEXT,
        warranty_expiry_date TEXT,

        support_vendor TEXT,

        status TEXT,

        end_of_life TEXT,

        remarks TEXT,

        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT,
        updated_at DATETIME
    )
");


// ============================================================
// SAFE ASSET COLUMN UPGRADES
// ============================================================
//
// CREATE TABLE IF NOT EXISTS above is a no-op once the table exists, so
// a column added after a deployment went live has to be ALTERed in
// separately -- same reasoning as inventory.php's column migration.

try {

    $asset_existing_columns = [];

    foreach (
        $pdo->query('PRAGMA table_info(asset)')->fetchAll(PDO::FETCH_ASSOC)
        as $asset_column
    ) {
        $asset_existing_columns[] = $asset_column['name'];
    }

    if (!in_array('port_group', $asset_existing_columns, true)) {
        $pdo->exec("ALTER TABLE asset ADD COLUMN port_group TEXT");
    }

} catch (Throwable $e) {

    error_log('Unable to migrate asset columns: ' . $e->getMessage());
}


// ============================================================
// ASSET HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS asset_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        asset_id INTEGER,

        action_type TEXT,

        performed_by TEXT,

        details TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
