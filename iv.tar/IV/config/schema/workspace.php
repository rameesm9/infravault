<?php
/**
 * Team Workspace: the on-call rota and the leave register.
 *
 * Both modules publish at the same four scopes as SOPs, KB articles,
 * known issues and quick links -- private / team / teams / public --
 * and reuse includes/permission-helpers.php for sharing, filtering and
 * audit. That is why the table names here are not free choices:
 * getSharedTeams() and saveItemSharing() derive the junction key as
 * "{$module}_id", so module 'oncall' must own oncall_teams.oncall_id
 * and module 'leave' must own leave_teams.leave_id.
 *
 * One deliberate difference from quick links: the person fields are
 * SNAPSHOTS, not joins. A shift records the NCGR ID and email that were
 * true when it was scheduled, and a leave entry does the same. Joining
 * live to users would rewrite history the moment somebody's address
 * changes or their account is removed -- and "who actually held the
 * pager that night" is the one question an on-call log exists to answer.
 * user_id is kept alongside so the current profile is still reachable.
 */

function runWorkspaceSchema(PDO $pdo): void
{
    /*
    |--------------------------------------------------------------------------
    | ON-CALL SHIFTS
    |--------------------------------------------------------------------------
    |
    | One row per shift, not one row per person: a dated range with a
    | primary and a secondary is what a rota actually is, and it is what
    | lets the page answer "who is on call right now" and "who is on next
    | week" from the same table.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS oncall_shifts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            shift_label TEXT,
            rota_team TEXT,

            starts_at DATETIME NOT NULL,
            ends_at DATETIME NOT NULL,

            /* Primary -- snapshot at scheduling time, see file header. */
            primary_user_id INTEGER,
            primary_name TEXT,
            primary_ncgr_id TEXT,
            primary_email TEXT,
            primary_phone TEXT,

            /* Secondary / backup. Optional: not every rota runs two deep. */
            secondary_user_id INTEGER,
            secondary_name TEXT,
            secondary_ncgr_id TEXT,
            secondary_email TEXT,
            secondary_phone TEXT,

            escalation_to TEXT,
            handover_notes TEXT,

            /*
             * Publication scope, same vocabulary as quick_links:
             *   private  only its author (and Admin)
             *   team     owner_team
             *   teams    the teams listed in oncall_teams
             *   public   anyone whose role grants oncall.can_view
             */
            visibility TEXT NOT NULL DEFAULT 'public',
            owner_team TEXT DEFAULT NULL,

            created_by_id INTEGER,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS oncall_teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            oncall_id INTEGER NOT NULL,
            team_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(oncall_id) REFERENCES oncall_shifts(id) ON DELETE CASCADE,
            UNIQUE(oncall_id, team_name)
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS oncall_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            oncall_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            performed_by_id INTEGER,
            user_name TEXT NOT NULL,
            action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            details TEXT
        )
    ");

    /* "Who is on now" and "what is coming up" are both range scans. */
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_window ON oncall_shifts(starts_at, ends_at)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_team ON oncall_shifts(rota_team)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_vis ON oncall_shifts(visibility)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_owner ON oncall_shifts(owner_team)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_teams ON oncall_teams(oncall_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_teams_name ON oncall_teams(team_name)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_oncall_audit ON oncall_audit(oncall_id, action_date)");


    /*
    |--------------------------------------------------------------------------
    | LEAVE ENTRIES
    |--------------------------------------------------------------------------
    |
    | Dates are stored as plain DATE strings (YYYY-MM-DD) to match every
    | other date in this application, which has no timezone conversion
    | anywhere. A leave day is a calendar day, not an instant.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS leave_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            /* Whose leave this is -- snapshot, see file header. */
            user_id INTEGER,
            person_name TEXT,
            ncgr_id TEXT,
            email TEXT,
            person_team TEXT,

            leave_type TEXT NOT NULL DEFAULT 'Annual',
            status TEXT NOT NULL DEFAULT 'Planned',

            start_date DATE NOT NULL,
            end_date DATE NOT NULL,

            /*
             * A half day is a flag rather than a fractional day count:
             * the register is read by people planning cover, and \"half
             * day on the 3rd\" is the useful form of that fact.
             */
            is_half_day INTEGER NOT NULL DEFAULT 0,

            reason TEXT,

            /*
             * Who covers the work, one contact per line, and optional.
             *
             * A list rather than a single name because cover is usually
             * shared -- two people, or one per system -- and a single
             * delegate field forces that into a comma-jammed string that
             * nothing can then read back apart. Each line is parsed as
             * \"Name <email>\", \"Name, email\", a name alone, or a bare
             * address.
             *
             * Feeds the out-of-office message, which names all of them.
             */
            cover_contacts TEXT,

            /*
             * The generated OOO text is stored rather than rebuilt on
             * demand: people edit it after generating, and an exported
             * register has to carry the wording that was actually used.
             */
            ooo_message TEXT,

            notes TEXT,

            visibility TEXT NOT NULL DEFAULT 'public',
            owner_team TEXT DEFAULT NULL,

            created_by_id INTEGER,
            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS leave_teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            leave_id INTEGER NOT NULL,
            team_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(leave_id) REFERENCES leave_entries(id) ON DELETE CASCADE,
            UNIQUE(leave_id, team_name)
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS leave_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            leave_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            performed_by_id INTEGER,
            user_name TEXT NOT NULL,
            action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            details TEXT
        )
    ");

    /*
    |--------------------------------------------------------------------------
    | COVER CONTACTS MIGRATION
    |--------------------------------------------------------------------------
    |
    | "Covered by" started as a single delegate_name / delegate_email pair.
    | CREATE TABLE IF NOT EXISTS above is a no-op once the table exists, so a
    | database created before cover_contacts existed needs the column ALTERed
    | in and the old pair folded into it -- otherwise every leave entry
    | recorded so far silently loses its cover contact.
    |
    | The two legacy columns are left in place rather than dropped. Nothing
    | reads them any more, and DROP COLUMN would make this irreversible for
    | the sake of tidiness.
    */

    try {
        $leaveCols = array_column(
            $pdo->query("PRAGMA table_info(leave_entries)")->fetchAll(PDO::FETCH_ASSOC),
            'name'
        );

        if (!in_array('cover_contacts', $leaveCols, true)) {

            $pdo->exec("ALTER TABLE leave_entries ADD COLUMN cover_contacts TEXT");

            if (in_array('delegate_name', $leaveCols, true)) {
                // "Name <email>" is the form the new field round-trips.
                $pdo->exec("
                    UPDATE leave_entries
                    SET cover_contacts = TRIM(
                        COALESCE(delegate_name, '')
                        || CASE
                               WHEN COALESCE(delegate_email, '') = '' THEN ''
                               ELSE ' <' || delegate_email || '>'
                           END
                    )
                    WHERE COALESCE(cover_contacts, '') = ''
                ");
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to migrate leave cover contacts: ' . $e->getMessage());
    }

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_window ON leave_entries(start_date, end_date)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_person ON leave_entries(user_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_status ON leave_entries(status)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_vis ON leave_entries(visibility)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_owner ON leave_entries(owner_team)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_teams ON leave_teams(leave_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_teams_name ON leave_teams(team_name)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_leave_audit ON leave_audit(leave_id, action_date)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    |
    | Separate keys, following the utilities module: an on-call rota is
    | operational scheduling, while the leave register carries reasons for
    | absence. Granting sight of one must not imply the other.
    |
    | Admin gets everything; every other role starts denied and is opened
    | up deliberately in Manage Permissions. INSERT OR IGNORE means a role
    | whose permissions an administrator has already tuned is never reset
    | by a later page load.
    */

    $newPages = [
        'oncall' => 'On-Call Tracker',
        'leave'  => 'Leave Tracker',
    ];

    try {
        $registerPage = $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)");
        foreach ($newPages as $key => $name) {
            $registerPage->execute([$key, $name]);
        }

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 1, 1, 1, 1, 1, 1)
        ");
        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 0, 0, 0, 0, 0, 0)
        ");

        foreach (array_keys($newPages) as $key) {
            foreach ($roles as $role) {
                if (strtolower(trim((string) $role)) === 'admin') {
                    $grantAll->execute([$role, $key]);
                } else {
                    $denyAll->execute([$role, $key]);
                }
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register workspace page permissions: ' . $e->getMessage());
    }
}
