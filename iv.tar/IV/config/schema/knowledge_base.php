<?php

// ============================================================
// KNOWLEDGE BASE
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_number TEXT NOT NULL UNIQUE,

        title TEXT NOT NULL,

        category TEXT NOT NULL,

        description TEXT,

        visibility TEXT NOT NULL DEFAULT 'Private'
            CHECK (visibility IN ('Private', 'Public')),

        content_html TEXT,

        created_by INTEGER NOT NULL,

        updated_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (created_by)
            REFERENCES users(id),

        FOREIGN KEY (updated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_visibility
    ON knowledge_base(visibility)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_created_by
    ON knowledge_base(created_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_category
    ON knowledge_base(category)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_updated_at
    ON knowledge_base(updated_at)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_attachments_kb_id
    ON knowledge_base_attachments(kb_id)
");


// ============================================================
// KNOWLEDGE BASE REVISION HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS knowledge_base_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        kb_id INTEGER NOT NULL,

        version TEXT NOT NULL DEFAULT '1.0',

        title TEXT,

        content_html TEXT,

        changed_by INTEGER,

        change_summary TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (kb_id)
            REFERENCES knowledge_base(id)
            ON DELETE CASCADE,

        FOREIGN KEY (changed_by)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWLEDGE BASE REVISION INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_kb_id
    ON knowledge_base_revisions(kb_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_changed_by
    ON knowledge_base_revisions(changed_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_kb_revisions_created_at
    ON knowledge_base_revisions(created_at)
");
