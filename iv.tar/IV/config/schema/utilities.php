<?php
/**
 * Utilities: ticket tracking, the credential vault, and quick links.
 */

function runUtilitiesSchema(PDO $pdo): void
{
    /*
    |--------------------------------------------------------------------------
    | TICKETS
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS tickets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            ticket_number TEXT NOT NULL,
            title TEXT,
            description TEXT,

            ticket_date DATE,
            due_date DATE,
            closed_date DATE,

            status TEXT NOT NULL DEFAULT 'Open',
            priority TEXT NOT NULL DEFAULT 'Medium',
            category TEXT,
            ticket_system TEXT,

            project TEXT,
            application TEXT,
            hostname TEXT,

            requester TEXT,
            assigned_to TEXT,

            external_link TEXT,
            resolution TEXT,
            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_tickets_number ON tickets(ticket_number)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status, ticket_date)");


    /*
    |--------------------------------------------------------------------------
    | CREDENTIAL VAULT
    |--------------------------------------------------------------------------
    |
    | The secret is stored as AES-256-GCM ciphertext with its own random
    | IV and authentication tag. Three things follow from that choice:
    |
    |  - The key lives in the APP_VAULT_KEY environment variable, never in
    |    this database. If the key were stored here, a copy of the .db file
    |    would contain both the lock and its key, and the encryption would
    |    be decoration.
    |
    |  - GCM is authenticated, so a row edited directly in the database
    |    fails to decrypt rather than silently returning altered bytes.
    |
    |  - key_version is recorded per row so keys can be rotated later
    |    without having to re-encrypt everything in one step.
    |
    | Notes are encrypted with the same scheme: "the password is in the
    | notes field" is a very common way for a vault to leak.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS vault_entries (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,
            username TEXT,

            secret_ct TEXT NOT NULL,
            secret_iv TEXT NOT NULL,
            secret_tag TEXT NOT NULL,

            notes_ct TEXT,
            notes_iv TEXT,
            notes_tag TEXT,

            key_version INTEGER NOT NULL DEFAULT 1,

            category TEXT,
            environment TEXT,
            project TEXT,
            hostname TEXT,
            url TEXT,

            owner_team TEXT,
            rotated_at DATE,
            expires_at DATE,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    /*
    | Every reveal and every copy is recorded. A vault whose reads are not
    | logged cannot answer the only question that matters after an
    | incident: who had this credential, and when did they take it.
    */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS vault_access_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            entry_id INTEGER,
            entry_title TEXT,
            action TEXT NOT NULL,
            performed_by TEXT,
            ip_address TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_vault_log ON vault_access_log(entry_id, timestamp)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_vault_log_user ON vault_access_log(performed_by, timestamp)");


    /*
    |--------------------------------------------------------------------------
    | QUICK LINKS
    |--------------------------------------------------------------------------
    |
    | Bookmarks for the consoles, dashboards and portals a team reaches for
    | daily -- vCenter, the patching server, the ticket system, a vendor
    | support portal. Shared rather than per-user on purpose: the point is
    | that a new joiner finds the same links the rest of the team uses.
    |
    | No credentials here. A link that needs a password pairs with a
    | vault_entries row, which is what vault_entries.url is for.
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS quick_links (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            title TEXT NOT NULL,
            url TEXT NOT NULL,
            description TEXT,

            category TEXT,
            environment TEXT,
            tags TEXT,

            /*
             * Publication scope, using the same four-value vocabulary and
             * the same helpers as SOPs, KB articles and known issues
             * (includes/permission-helpers.php):
             *
             *   private  visible only to its author (and Admin)
             *   team     visible to owner_team
             *   teams    visible to the teams listed in quick_link_teams
             *   public   visible to anyone whose role grants links.can_view
             *
             * 'private' is new here: the older modules never had an
             * \"only me\" level, so permission-helpers gained that branch
             * alongside this table.
             */
            visibility TEXT NOT NULL DEFAULT 'public',
            owner_team TEXT DEFAULT NULL,

            /*
             * Ownership needs the numeric user id: getItemAccessLevel()
             * compares it against the session's user_id. created_by keeps
             * the display name, which is what the listing renders.
             */
            created_by_id INTEGER,

            /*
             * Pinned links sort to the top of every view. This is the
             * manual stand-in for usage ranking: counting clicks would
             * mean a write on every navigation, and a read-only user
             * cannot be given write access just to follow a bookmark.
             */
            is_pinned INTEGER NOT NULL DEFAULT 0,
            sort_order INTEGER NOT NULL DEFAULT 0,

            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    /* Multi-team sharing, mirroring sop_teams / knowledge_base_teams. */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS quick_link_teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quick_link_id INTEGER NOT NULL,
            team_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(quick_link_id) REFERENCES quick_links(id) ON DELETE CASCADE,
            UNIQUE(quick_link_id, team_name)
        )
    ");

    /* Audit trail, mirroring sop_audit / knowledge_base_audit. */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS quick_link_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            quick_link_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            performed_by_id INTEGER,
            user_name TEXT NOT NULL,
            action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
            details TEXT
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_links_cat ON quick_links(category, sort_order)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_links_pinned ON quick_links(is_pinned, title)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_links_visibility ON quick_links(visibility)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_links_owner_team ON quick_links(owner_team)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_link_teams ON quick_link_teams(quick_link_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_link_teams_name ON quick_link_teams(team_name)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_link_audit ON quick_link_audit(quick_link_id, action_date)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    |
    | Separate keys on purpose. Ticket tracking is ordinary operational
    | data; the vault holds credentials. Granting someone tickets must not
    | imply granting them passwords, so they cannot share a page key.
    */

    $newPages = [
        'ticket' => 'Ticket Tracking',
        'vault'  => 'Password Vault',
        'links'  => 'Quick Links',
    ];

    try {
        $registerPage = $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)");
        foreach ($newPages as $key => $name) {
            $registerPage->execute([$key, $name]);
        }

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 1, 1, 1, 1, 1, 1)
        ");
        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, ?, 0, 0, 0, 0, 0, 0)
        ");

        foreach (array_keys($newPages) as $key) {
            foreach ($roles as $role) {
                if (strtolower(trim((string) $role)) === 'admin') {
                    $grantAll->execute([$role, $key]);
                } else {
                    $denyAll->execute([$role, $key]);
                }
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register utilities page permissions: ' . $e->getMessage());
    }
}
