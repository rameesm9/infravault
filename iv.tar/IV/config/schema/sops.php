<?php

// ============================================================
// SOPS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sops (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sop_number TEXT NOT NULL UNIQUE,
        title TEXT NOT NULL,
        category TEXT NOT NULL,
        description TEXT,
        criticality TEXT DEFAULT 'Medium',
        owner_id INTEGER NOT NULL,
        reviewer_id INTEGER,
        version TEXT DEFAULT '1.0',
        status TEXT DEFAULT 'Draft',
        content_html TEXT,
        prerequisites_html TEXT,
        validation_html TEXT,
        rollback_html TEXT,
        escalation_html TEXT,
        review_comment TEXT,
        rejection_reason TEXT,
        review_date DATE,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        submitted_at DATETIME,
        reviewed_at DATETIME,
        published_at DATETIME,
        FOREIGN KEY (owner_id) REFERENCES users(id),
        FOREIGN KEY (reviewer_id) REFERENCES users(id)
    )
");


// ============================================================
// SOP REVISIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sop_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sop_id INTEGER NOT NULL,

        version TEXT NOT NULL,

        title TEXT NOT NULL,

        content_html TEXT,

        changed_by INTEGER NOT NULL,

        change_summary TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (sop_id) REFERENCES sops(id),

        FOREIGN KEY (changed_by) REFERENCES users(id)
    )
");


// ============================================================
// SOP ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sop_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        sop_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (sop_id) REFERENCES sops(id),

        FOREIGN KEY (uploaded_by) REFERENCES users(id)
    )
");
