<?php

// ============================================================
// KNOWN ISSUES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issues (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_number TEXT UNIQUE NOT NULL,

        title TEXT NOT NULL,

        description TEXT,

        category TEXT,

        severity TEXT DEFAULT 'Medium',

        status TEXT DEFAULT 'Open',

        owner_id INTEGER NOT NULL,

        affected_team TEXT,

        affected_system TEXT,

        environment TEXT,

        symptoms_html TEXT,

        cause_html TEXT,

        workaround_html TEXT,

        resolution_html TEXT,

        notes_html TEXT,

        visibility TEXT DEFAULT 'Private',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        resolved_at DATETIME,

        FOREIGN KEY (owner_id)
            REFERENCES users(id)
    )
");


// ============================================================
// KNOWN ISSUE ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS known_issue_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        issue_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,

        stored_name TEXT NOT NULL,

        file_path TEXT NOT NULL,

        mime_type TEXT,

        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (issue_id)
            REFERENCES known_issues(id),

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");
