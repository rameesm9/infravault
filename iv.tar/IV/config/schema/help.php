<?php

// ============================================================
// HELP ARTICLES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS help_articles (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        menu_name TEXT NOT NULL,

        title TEXT NOT NULL,

        content TEXT NOT NULL,

        suggestions TEXT,

        comments TEXT,

        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP,

        is_active INTEGER DEFAULT 1
    )
");
