<?php

// ============================================================
// ROLE PERMISSIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS permissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        role TEXT NOT NULL,

        page_key TEXT NOT NULL,

        can_view INTEGER DEFAULT 0,

        can_edit INTEGER DEFAULT 0,

        can_delete INTEGER DEFAULT 0,

        can_export INTEGER DEFAULT 0,

        can_import INTEGER DEFAULT 0,

        can_audit INTEGER DEFAULT 0,

        UNIQUE (role, page_key)
    )
");


// ============================================================
// PAGES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS pages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        page_key TEXT UNIQUE NOT NULL,
        page_name TEXT NOT NULL
    )
");

$pdo->exec("
    INSERT OR IGNORE INTO pages (page_key, page_name)
    VALUES ('asset', 'Asset')
");
