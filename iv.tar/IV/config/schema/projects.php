<?php
/**
 * Special Projects -- tracked infrastructure programmes such as an OS
 * major upgrade, a database upgrade, an OpenShift version jump or an
 * LDAP-to-LDAPS conversion.
 *
 * Distinct from the ticket tracker: a ticket is one request with one
 * outcome, whereas these run for months, cross many systems and move
 * through phases. That is why milestones are a child table rather than a
 * free-text field -- "where are we with the RHEL upgrade" is a question
 * about phases, and it cannot be answered by a status column alone.
 */

function runProjectsSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS special_projects (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            project_name TEXT NOT NULL,
            project_code TEXT,
            category TEXT,
            description TEXT,
            objective TEXT,

            status TEXT NOT NULL DEFAULT 'Planning',
            priority TEXT NOT NULL DEFAULT 'Medium',
            health TEXT NOT NULL DEFAULT 'On Track',

            start_date DATE,
            target_date DATE,
            completed_date DATE,

            /*
             * Scope as a simple pair of counters: these programmes are
             * measured as \"X of Y systems done\", and that headline number
             * is what gets reported upwards.
             */
            total_systems INTEGER NOT NULL DEFAULT 0,
            completed_systems INTEGER NOT NULL DEFAULT 0,

            /*
             * Which systems, as a newline-separated hostname list picked
             * from inventory and the asset register. Deliberately names
             * rather than ids: a host can be decommissioned out of
             * inventory while the project record still needs to show it
             * was in scope, and a foreign key would either block that
             * delete or silently erase the history.
             */
            systems TEXT,

            /*
             * Manual override for progress. Left NULL, the page derives
             * progress from milestones or from the system counters; some
             * programmes are better judged by their lead than by counting.
             */
            progress_percent INTEGER,

            environment TEXT,
            affected_projects TEXT,
            technology TEXT,

            project_lead TEXT,
            lead_email TEXT,
            team TEXT,
            sponsor TEXT,

            change_reference TEXT,
            risks TEXT,
            blockers TEXT,
            notes TEXT,

            created_by TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_by TEXT,
            updated_at DATETIME
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS project_milestones (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            project_id INTEGER NOT NULL,
            milestone_name TEXT NOT NULL,
            target_date DATE,
            completed_date DATE,
            status TEXT NOT NULL DEFAULT 'Pending',
            owner TEXT,
            notes TEXT,
            milestone_order INTEGER NOT NULL DEFAULT 0,
            FOREIGN KEY (project_id) REFERENCES special_projects(id) ON DELETE CASCADE
        )
    ");

    /*
     * Added after the table shipped, so existing databases need it grafted
     * on. SQLite has no ADD COLUMN IF NOT EXISTS, hence the probe.
     */
    $have = $pdo->query("PRAGMA table_info(special_projects)")->fetchAll(PDO::FETCH_COLUMN, 1);
    if (!in_array('systems', $have, true)) {
        $pdo->exec("ALTER TABLE special_projects ADD COLUMN systems TEXT");
    }

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_projects_status ON special_projects(status, target_date)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_project_milestones ON project_milestones(project_id, milestone_order)");


    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    */

    try {
        $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)")
            ->execute(['special_projects', 'Special Projects']);

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'special_projects', 1, 1, 1, 1, 1, 1)
        ");
        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'special_projects', 0, 0, 0, 0, 0, 0)
        ");

        foreach ($roles as $role) {
            if (strtolower(trim((string) $role)) === 'admin') {
                $grantAll->execute([$role]);
            } else {
                $denyAll->execute([$role]);
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register special_projects permissions: ' . $e->getMessage());
    }
}
