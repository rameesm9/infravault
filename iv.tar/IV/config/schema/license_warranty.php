<?php

// ============================================================
// LICENSE / WARRANTY / EOL REGISTER
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS license_warranty (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        product_name TEXT NOT NULL,
        product_type TEXT DEFAULT '',
        manufacturer TEXT DEFAULT '',
        product_version TEXT DEFAULT '',

        license_type TEXT DEFAULT '',
        license_key TEXT DEFAULT '',
        license_quantity TEXT DEFAULT '',

        vendor TEXT DEFAULT '',
        support_vendor TEXT DEFAULT '',
        agreement_number TEXT DEFAULT '',

        purchase_date TEXT,
        license_start_date TEXT,
        license_expiry_date TEXT,

        warranty_start_date TEXT,
        warranty_expiry_date TEXT,

        support_start_date TEXT,
        support_expiry_date TEXT,

        eos_date TEXT,
        eol_date TEXT,

        renewal_required TEXT DEFAULT 'No',
        renewal_date TEXT,

        owner_name TEXT DEFAULT '',
        owner_email TEXT DEFAULT '',
        team TEXT DEFAULT '',

        status TEXT DEFAULT 'Active',

        notes TEXT DEFAULT '',

        created_by TEXT DEFAULT '',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT DEFAULT '',
        updated_at DATETIME

    )
");


// ============================================================
// INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_product
    ON license_warranty(product_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_vendor
    ON license_warranty(vendor)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_expiry
    ON license_warranty(license_expiry_date)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_warranty_expiry
    ON license_warranty(warranty_expiry_date)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_support_expiry
    ON license_warranty(support_expiry_date)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_eos
    ON license_warranty(eos_date)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_eol
    ON license_warranty(eol_date)
");

$pdo->exec("
    CREATE INDEX  IF NOT EXISTS idx_license_renewal
    ON license_warranty(renewal_date)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_status
    ON license_warranty(status)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_owner
    ON license_warranty(owner_name)
");


/*
|--------------------------------------------------------------------------
| LICENSE / WARRANTY HISTORY
|--------------------------------------------------------------------------
|
| SQLite-compatible history table.
|
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS license_warranty_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        license_warranty_id INTEGER NULL,

        action TEXT NOT NULL,

        changed_by TEXT NOT NULL,

        changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,

        old_values TEXT NULL,

        new_values TEXT NULL
    )
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_warranty_history_record
    ON license_warranty_history (license_warranty_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_warranty_history_date
    ON license_warranty_history (changed_at)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_warranty_history_user
    ON license_warranty_history (changed_by)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_license_warranty_history_action
    ON license_warranty_history (action)
");


// ============================================================
// PAGE + DEFAULT PERMISSIONS
// ============================================================

$pdo->exec("
    INSERT OR IGNORE INTO pages (page_key, page_name)
    VALUES ('license_warranty', 'License, Warranty & EOL')
");

$pdo->exec("
    INSERT OR IGNORE INTO permissions (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
    VALUES ('admin', 'license_warranty', 1, 1, 1, 1, 1, 1)
");
