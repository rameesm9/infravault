<?php

/*
|--------------------------------------------------------------------------
| Compliance Platforms
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_platforms (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_key TEXT NOT NULL UNIQUE,

    platform_name TEXT NOT NULL,

    category TEXT NOT NULL DEFAULT 'Red Hat',

    description TEXT DEFAULT '',

    framework TEXT DEFAULT 'CIS',

    benchmark_name TEXT DEFAULT '',

    benchmark_version TEXT DEFAULT '',

    is_active INTEGER NOT NULL DEFAULT 1,

    sort_order INTEGER NOT NULL DEFAULT 0,

    created_by INTEGER,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
)
");

/*
|--------------------------------------------------------------------------
| Compliance Controls
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_controls (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_id INTEGER NOT NULL,

    control_number TEXT NOT NULL,

    title TEXT NOT NULL,

    description TEXT DEFAULT '',

    section_name TEXT DEFAULT '',

    level TEXT DEFAULT 'Level 1',

    severity TEXT DEFAULT 'Medium',

    control_type TEXT DEFAULT 'Configuration',

    value_type TEXT DEFAULT 'Text',

    cis_value TEXT DEFAULT '',

    ncgr_value TEXT DEFAULT '',

    unit TEXT DEFAULT '',

    remediation TEXT DEFAULT '',

    audit_procedure TEXT DEFAULT '',

    source_reference TEXT DEFAULT '',

    cis_version TEXT DEFAULT '',

    is_custom INTEGER NOT NULL DEFAULT 0,

    is_enabled INTEGER NOT NULL DEFAULT 1,

    sort_order INTEGER NOT NULL DEFAULT 0,

    created_by INTEGER,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    updated_by INTEGER,

    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (platform_id)
        REFERENCES compliance_platforms(id)
        ON DELETE CASCADE,

    FOREIGN KEY (created_by)
        REFERENCES users(id),

    FOREIGN KEY (updated_by)
        REFERENCES users(id),

    UNIQUE(platform_id, control_number)
)
");

/*
|--------------------------------------------------------------------------
| Compliance Audit
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE TABLE IF NOT EXISTS compliance_audit (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    platform_id INTEGER,

    control_id INTEGER,

    action TEXT NOT NULL,

    performed_by TEXT NOT NULL,

    old_value TEXT,

    new_value TEXT,

    details TEXT,

    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (platform_id)
        REFERENCES compliance_platforms(id)
        ON DELETE SET NULL,

    FOREIGN KEY (control_id)
        REFERENCES compliance_controls(id)
        ON DELETE SET NULL
)
");

/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_platform_category
ON compliance_platforms(category)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_platform
ON compliance_controls(platform_id)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_severity
ON compliance_controls(severity)
");

$pdo->exec("
CREATE INDEX IF NOT EXISTS
idx_compliance_controls_enabled
ON compliance_controls(is_enabled)
");

/*
|--------------------------------------------------------------------------
| Default Platforms
|--------------------------------------------------------------------------
|
| One and only one record for each platform.
|
*/

$platforms = [

    [
        'rhel',
        'RHEL',
        'Red Hat',
        'Red Hat Enterprise Linux security compliance.',
        'CIS',
        'CIS Red Hat Enterprise Linux 9 Benchmark',
        '2.0.0',
        10
    ],

    [
        'openshift',
        'OpenShift',
        'Red Hat',
        'Red Hat OpenShift Container Platform security compliance.',
        'CIS',
        'CIS Red Hat OpenShift Container Platform Benchmark',
        '1.9.0',
        20
    ],

    [
        'ipa',
        'IPA',
        'Red Hat',
        'Identity Management / FreeIPA security policy.',
        'NCGR / Custom',
        '',
        '',
        30
    ],

    [
        'satellite',
        'Satellite',
        'Red Hat',
        'Red Hat Satellite security policy.',
        'NCGR / Custom',
        '',
        '',
        40
    ],

    [
        'kubernetes',
        'Kubernetes',
        'Red Hat',
        'Kubernetes cluster security compliance.',
        'CIS',
        'CIS Kubernetes Benchmark',
        '2.0.1',
        50
    ]
];

$stmt = $pdo->prepare("
    INSERT OR IGNORE INTO compliance_platforms
    (
        platform_key,
        platform_name,
        category,
        description,
        framework,
        benchmark_name,
        benchmark_version,
        sort_order
    )
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
");

foreach ($platforms as $platform) {

    $stmt->execute($platform);
}

/*
|--------------------------------------------------------------------------
| Helper
|--------------------------------------------------------------------------
*/

function compliance_platform_id(PDO $pdo, string $key): ?int
{
    $stmt = $pdo->prepare("
        SELECT id
        FROM compliance_platforms
        WHERE platform_key = ?
        LIMIT 1
    ");

    $stmt->execute([$key]);

    $id = $stmt->fetchColumn();

    return $id ? (int)$id : null;
}

/*
|--------------------------------------------------------------------------
| Seed Controls
|--------------------------------------------------------------------------
|
| These are baseline examples / commonly used controls.
|
| The application supports importing the complete benchmark data
| from your authorized CIS benchmark source rather than embedding
| the complete copyrighted benchmark text into the application.
|
|--------------------------------------------------------------------------
*/

$seedControls = [

    /*
    |--------------------------------------------------------------------------
    | RHEL
    |--------------------------------------------------------------------------
    */

    [
        'rhel',
        '5.4.1',
        'Ensure password expiration is configured',
        'Configure maximum password age according to security policy.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '90',
        '30',
        'Days'
    ],

    [
        'rhel',
        '5.4.2',
        'Ensure minimum password age is configured',
        'Configure minimum password age to prevent rapid password cycling.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '1',
        '1',
        'Days'
    ],

    [
        'rhel',
        '5.4.3',
        'Ensure password expiration warning is configured',
        'Configure the password expiration warning period.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '7',
        '7',
        'Days'
    ],

    [
        'rhel',
        '5.4.4',
        'Ensure inactive password lock is configured',
        'Configure inactive accounts according to security policy.',
        'User Accounts and Environment',
        'Level 1',
        'Medium',
        'Configuration',
        'Number',
        '30',
        '15',
        'Days'
    ],

    [
        'rhel',
        '5.3.1',
        'Ensure SSH root login is disabled',
        'Direct SSH login using the root account should be disabled.',
        'SSH Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '5.3.2',
        'Ensure SSH empty passwords are disabled',
        'SSH must not allow authentication using empty passwords.',
        'SSH Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '5.3.3',
        'Ensure SSH X11 forwarding is disabled',
        'Disable X11 forwarding unless explicitly required.',
        'SSH Server',
        'Level 1',
        'Medium',
        'Configuration',
        'Boolean',
        'Disabled',
        'Disabled',
        ''
    ],

    [
        'rhel',
        '1.1.1',
        'Ensure filesystem configuration is secure',
        'Ensure required filesystem configuration follows the approved security baseline.',
        'Filesystem Configuration',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    /*
    |--------------------------------------------------------------------------
    | OpenShift
    |--------------------------------------------------------------------------
    */

    [
        'openshift',
        '1.1.1',
        'Ensure authentication configuration is secured',
        'Ensure cluster authentication configuration follows the approved security baseline.',
        'Control Plane Configuration',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '1.2.1',
        'Ensure API server access is restricted',
        'Restrict access to the OpenShift API server to authorized sources.',
        'API Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '1.3.1',
        'Ensure audit logging is enabled',
        'Cluster audit logging must be enabled and retained according to policy.',
        'Logging',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'openshift',
        '5.1.1',
        'Ensure RBAC is configured securely',
        'Use role based access controls and least privilege.',
        'RBAC',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    /*
    |--------------------------------------------------------------------------
    | Kubernetes
    |--------------------------------------------------------------------------
    */

    [
        'kubernetes',
        '1.1.1',
        'Ensure API server authentication is configured securely',
        'Ensure API server authentication mechanisms follow the security baseline.',
        'API Server',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '1.2.1',
        'Ensure audit logging is enabled',
        'Ensure Kubernetes audit logging is enabled and retained.',
        'Logging',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '5.1.1',
        'Ensure RBAC is configured',
        'Use RBAC and least privilege for Kubernetes resources.',
        'RBAC',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Enabled',
        'Enabled',
        ''
    ],

    [
        'kubernetes',
        '5.2.1',
        'Ensure privileged containers are restricted',
        'Restrict privileged container execution.',
        'Pod Security',
        'Level 1',
        'High',
        'Configuration',
        'Boolean',
        'Restricted',
        'Restricted',
        ''
    ]
];

/*
|--------------------------------------------------------------------------
| Insert Seed Controls
|--------------------------------------------------------------------------
*/

$stmtControl = $pdo->prepare("
    INSERT OR IGNORE INTO compliance_controls
    (
        platform_id,
        control_number,
        title,
        description,
        section_name,
        level,
        severity,
        control_type,
        value_type,
        cis_value,
        ncgr_value,
        unit,
        cis_version
    )
    VALUES
    (
        ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
        (
            SELECT benchmark_version
            FROM compliance_platforms
            WHERE id = ?
        )
    )
");

foreach ($seedControls as $control) {

    $platformKey = $control[0];

    $platformId = compliance_platform_id(
        $pdo,
        $platformKey
    );

    if (!$platformId) {
        continue;
    }

    $stmtControl->execute([
        $platformId,
        $control[1],
        $control[2],
        $control[3],
        $control[4],
        $control[5],
        $control[6],
        $control[7],
        $control[8],
        $control[9],
        $control[10],
        $control[11],
        $platformId
    ]);
}
