<?php
/**
 * Team-scoped visibility for handovers.
 *
 * A handover record names the outgoing and incoming owner and often
 * carries open issues, risks and pending actions -- detail that belongs to
 * the teams involved rather than to everyone who can open the page. This
 * adds the same three publication scopes the rest of the app uses:
 *
 *   team    visible to owner_team
 *   teams   visible to the teams listed in handover_teams
 *   public  visible to anyone whose role grants handover.can_view
 *
 * Existing rows default to 'public', which is exactly how they behaved
 * before this column existed -- a migration must never quietly hide data
 * someone could already see.
 *
 * Deliberately no 'private' level here, unlike quick_links: a handover is
 * an agreement between two owners, so a record only its author can see
 * would defeat its purpose.
 */

function runHandoverVisibilitySchema(PDO $pdo): void
{
    $cols = $pdo->query("PRAGMA table_info(handovers)")->fetchAll(PDO::FETCH_COLUMN, 1);

    if (!$cols) {
        // handovers.php has not created the table yet this request.
        return;
    }

    if (!in_array('visibility', $cols, true)) {
        $pdo->exec("ALTER TABLE handovers ADD COLUMN visibility TEXT NOT NULL DEFAULT 'public'");
    }

    if (!in_array('owner_team', $cols, true)) {
        $pdo->exec("ALTER TABLE handovers ADD COLUMN owner_team TEXT DEFAULT NULL");
    }

    /* Multi-team sharing, mirroring sop_teams / quick_link_teams. */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS handover_teams (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            handover_id INTEGER NOT NULL,
            team_name TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(handover_id, team_name)
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_handover_visibility ON handovers(visibility)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_handover_owner_team ON handovers(owner_team)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_handover_teams ON handover_teams(handover_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_handover_teams_name ON handover_teams(team_name)");
}
