<?php
/**
 * Presentation & Document Designer: permanent saved decks.
 *
 * The designer itself is client-side (templates, preview and file
 * generation all run in the browser), but "keep it saved permanently"
 * needs real server-side storage -- this is the one table that adds. A
 * deck (a named, ordered set of slides/pages plus its header/footer
 * config and accent theme) is stored as a single JSON blob in `data`
 * rather than normalized into rows: the per-template field shape is
 * fully dynamic (see assets/js/presentation-designer.js's PD_TEMPLATES),
 * so a JSON document is the natural fit and avoids a schema migration
 * every time a template's fields change.
 *
 * One row per (user, deck_type, name): saving again under the same name
 * overwrites in place, matching ordinary "Save" behaviour.
 */

function runPresentationDesignerDecksSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS presentation_designer_decks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            deck_type TEXT NOT NULL,
            name TEXT NOT NULL,
            data TEXT NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, deck_type, name)
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_pd_decks_user_type_updated ON presentation_designer_decks(user_id, deck_type, updated_at)");
}
