<?php

// ============================================================
// REMINDERS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS reminders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER NOT NULL,

        title TEXT NOT NULL,

        message TEXT NOT NULL,

        reminder_date DATETIME NOT NULL,

        visibility TEXT DEFAULT 'public',

        additional_emails TEXT,

        status TEXT DEFAULT 'pending',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// Migrate existing 'all' visibility to 'public'
try {
    $pdo->exec("UPDATE reminders SET visibility='public' WHERE visibility='all'");
} catch (Exception $e) {
    // Table might be empty or already migrated
}


// ============================================================
// REMINDER TEAM SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS reminder_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reminder_id INTEGER NOT NULL,
        team_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE,
        UNIQUE(reminder_id, team_name)
    )
");


// ============================================================
// REMINDER USER SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS reminder_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reminder_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE,
        UNIQUE(reminder_id, user_id)
    )
");


// ============================================================
// STICKY NOTES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sticky_notes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        user_id INTEGER NOT NULL,

        content TEXT NOT NULL,

        visibility TEXT DEFAULT 'public',

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// Migrate existing 'all' visibility to 'public'
try {
    $pdo->exec("UPDATE sticky_notes SET visibility='public' WHERE visibility='all'");
} catch (Exception $e) {
    // Table might be empty or already migrated
}


// ============================================================
// STICKY NOTE TEAM SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sticky_note_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sticky_note_id INTEGER NOT NULL,
        team_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sticky_note_id) REFERENCES sticky_notes(id) ON DELETE CASCADE,
        UNIQUE(sticky_note_id, team_name)
    )
");


// ============================================================
// STICKY NOTE USER SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sticky_note_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sticky_note_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(sticky_note_id) REFERENCES sticky_notes(id) ON DELETE CASCADE,
        UNIQUE(sticky_note_id, user_id)
    )
");


// ============================================================
// REMINDER AUDIT TRAIL
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS reminder_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        reminder_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        performed_by_id INTEGER,
        user_name TEXT NOT NULL,
        action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        details TEXT,
        FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE
    )
");


// ============================================================
// STICKY NOTE AUDIT TRAIL
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS sticky_note_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sticky_note_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        performed_by_id INTEGER,
        user_name TEXT NOT NULL,
        action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        details TEXT,
        FOREIGN KEY(sticky_note_id) REFERENCES sticky_notes(id) ON DELETE CASCADE
    )
");
