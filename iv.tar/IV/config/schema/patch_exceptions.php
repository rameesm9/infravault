<?php

// ============================================================
// PATCH EXCEPTIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exceptions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        reference_no TEXT UNIQUE NOT NULL,

        title TEXT NOT NULL,
        exception_type TEXT NOT NULL DEFAULT 'Patch Exception',
        version TEXT NOT NULL DEFAULT '1.0',

        short_description TEXT DEFAULT '',
        system_name TEXT DEFAULT '',
        application_name TEXT DEFAULT '',

        current_version TEXT DEFAULT '',
        target_version TEXT DEFAULT '',

        reason TEXT DEFAULT '',
        risk_description TEXT DEFAULT '',
        mitigation TEXT DEFAULT '',

        owner_id INTEGER NOT NULL,
        team TEXT DEFAULT '',

        visibility TEXT NOT NULL DEFAULT 'Private',

        start_date DATE,
        expiry_date DATE,

        status TEXT NOT NULL DEFAULT 'Draft',

        requested_by INTEGER NOT NULL,

        approved_by INTEGER,
        approved_at DATETIME,

        rejection_reason TEXT DEFAULT '',
        review_comment TEXT DEFAULT '',

        additional_details TEXT DEFAULT '',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (owner_id) REFERENCES users(id),
        FOREIGN KEY (requested_by) REFERENCES users(id),
        FOREIGN KEY (approved_by) REFERENCES users(id)
    )
");


// ============================================================
// PATCH EXCEPTION ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exception_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        exception_id INTEGER NOT NULL,

        original_name TEXT NOT NULL,
        stored_name TEXT NOT NULL,
        file_path TEXT NOT NULL,

        mime_type TEXT DEFAULT 'application/octet-stream',
        file_size INTEGER DEFAULT 0,

        uploaded_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (exception_id)
            REFERENCES patch_exceptions(id)
            ON DELETE CASCADE,

        FOREIGN KEY (uploaded_by)
            REFERENCES users(id)
    )
");


// ============================================================
// PATCH EXCEPTION REVISIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_exception_revisions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        exception_id INTEGER NOT NULL,

        version TEXT NOT NULL DEFAULT '1.0',

        title TEXT NOT NULL,
        exception_type TEXT NOT NULL,

        short_description TEXT DEFAULT '',
        system_name TEXT DEFAULT '',
        application_name TEXT DEFAULT '',

        current_version TEXT DEFAULT '',
        target_version TEXT DEFAULT '',

        reason TEXT DEFAULT '',
        risk_description TEXT DEFAULT '',
        mitigation TEXT DEFAULT '',

        owner_id INTEGER,
        team TEXT DEFAULT '',

        visibility TEXT DEFAULT 'Private',

        start_date DATE,
        expiry_date DATE,

        status TEXT DEFAULT 'Draft',

        additional_details TEXT DEFAULT '',

        changed_by INTEGER NOT NULL,

        change_summary TEXT DEFAULT '',

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (exception_id)
            REFERENCES patch_exceptions(id)
            ON DELETE CASCADE,

        FOREIGN KEY (changed_by)
            REFERENCES users(id)
    )
");
