<?php

// ============================================================
// HANDOVERS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS handovers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        project_name TEXT NOT NULL,

        project_id TEXT,

        current_owner TEXT NOT NULL,

        new_owner TEXT NOT NULL,

        handover_date TEXT,

        handover_status TEXT,

        reason_for_handover TEXT,

        project_phase TEXT,

        documentation_status TEXT,

        open_issues TEXT,

        pending_actions TEXT,

        risks TEXT,

        dependencies TEXT,

        kt_completed TEXT,

        training_completed TEXT,

        access_transferred TEXT,

        stakeholder_signoff TEXT,

        client_notified TEXT,

        warranty_period TEXT,

        notes TEXT,

        user_id INTEGER NOT NULL,

        last_updated DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// HANDOVER ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS handover_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        handover_id INTEGER NOT NULL,

        filename TEXT NOT NULL,

        filepath TEXT NOT NULL,

        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (handover_id)
            REFERENCES handovers(id)
            ON DELETE CASCADE
    )
");
