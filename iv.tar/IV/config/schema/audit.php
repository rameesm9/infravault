<?php

// ============================================================
// AUDIT HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS audit_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        module TEXT NOT NULL,

        record_id INTEGER NOT NULL,

        action TEXT NOT NULL,

        performed_by TEXT NOT NULL,

        details TEXT,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
