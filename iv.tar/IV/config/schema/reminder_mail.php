<?php
/**
 * Email notifications for Reminders & Notes.
 *
 * Adds reminder_sent_at (tracks whether the due-reminder email has already
 * gone out, so reminder_notification_cron.php doesn't resend on every run)
 * and registers the module in the centralized mail_module_toggles table
 * built in config/schema/mail_settings.php, so it shows up automatically
 * on the Settings page without any changes needed there.
 *
 * Requires config/schema/team-permissions-migration.php (addColumnIfMissing)
 * and config/schema/mail_settings.php (mail_module_toggles table) to have
 * already run -- db.php requires this file after both.
 */

function runReminderMailSchema(PDO $pdo): void
{
    addColumnIfMissing($pdo, 'reminders', 'reminder_sent_at', 'DATETIME DEFAULT NULL');

    $pdo->prepare("
        INSERT OR IGNORE INTO mail_module_toggles (module_key, module_label)
        VALUES ('reminder_notifications', 'Reminders & Notes Email Notifications')
    ")->execute();
}
