<?php
/**
 * Team-Based Permissions, Audit Trails, and Sharing Migration
 *
 * Adds support for:
 * - Team-scoped visibility for SOPs, Knowledge Base, Known Issues
 * - Multi-team sharing via junction tables
 * - Comprehensive audit trail logging
 * - Comments on KB and Known Issues articles
 *
 * Safe migration: All existing records default to 'public' visibility,
 * maintaining full backward compatibility.
 *
 * Note: SQLite does not support "ALTER TABLE ... ADD COLUMN IF NOT EXISTS".
 * columnExists() checks PRAGMA table_info() first so this migration can be
 * re-run safely on every request without erroring on already-migrated columns.
 */

function columnExists(PDO $pdo, string $table, string $column): bool
{
    $stmt = $pdo->query("PRAGMA table_info(" . $table . ")");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($columns as $col) {
        if (strcasecmp($col['name'], $column) === 0) {
            return true;
        }
    }

    return false;
}

function addColumnIfMissing(PDO $pdo, string $table, string $column, string $definition): void
{
    if (!columnExists($pdo, $table, $column)) {
        $pdo->exec("ALTER TABLE $table ADD COLUMN $column $definition");
    }
}

function runTeamPermissionsMigration($pdo): void
{
    try {
        $pdo->beginTransaction();

        // ============================================
        // SOPs Module
        // ============================================

        addColumnIfMissing($pdo, 'sops', 'visibility', "TEXT DEFAULT 'public'");
        addColumnIfMissing($pdo, 'sops', 'owner_team', "TEXT DEFAULT NULL");

        // SOP to Teams junction table (for multi-team visibility)
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS sop_teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sop_id INTEGER NOT NULL,
                team_name TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(sop_id) REFERENCES sops(id) ON DELETE CASCADE,
                UNIQUE(sop_id, team_name)
            )
        ");

        // SOP audit trail
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS sop_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                sop_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                performed_by_id INTEGER,
                user_name TEXT NOT NULL,
                action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                details TEXT,
                FOREIGN KEY(sop_id) REFERENCES sops(id) ON DELETE CASCADE
            )
        ");

        // Indexes for SOP module
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_audit_sop_id ON sop_audit(sop_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_audit_action ON sop_audit(action)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_audit_date ON sop_audit(action_date)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_teams_sop_id ON sop_teams(sop_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_teams_team ON sop_teams(team_name)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_visibility ON sops(visibility)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sop_owner_team ON sops(owner_team)");

        // ============================================
        // Knowledge Base Module
        // ============================================

        addColumnIfMissing($pdo, 'knowledge_base', 'visibility', "TEXT DEFAULT 'public'");
        addColumnIfMissing($pdo, 'knowledge_base', 'owner_team', "TEXT DEFAULT NULL");

        // Knowledge Base to Teams junction table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS knowledge_base_teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kb_id INTEGER NOT NULL,
                team_name TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(kb_id) REFERENCES knowledge_base(id) ON DELETE CASCADE,
                UNIQUE(kb_id, team_name)
            )
        ");

        // KB audit trail
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS knowledge_base_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kb_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                performed_by_id INTEGER,
                user_name TEXT NOT NULL,
                action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                details TEXT,
                FOREIGN KEY(kb_id) REFERENCES knowledge_base(id) ON DELETE CASCADE
            )
        ");

        // KB comments
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS knowledge_base_comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                kb_id INTEGER NOT NULL,
                comment_text TEXT NOT NULL,
                commented_by INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(kb_id) REFERENCES knowledge_base(id) ON DELETE CASCADE,
                FOREIGN KEY(commented_by) REFERENCES users(id) ON DELETE SET NULL
            )
        ");

        // Indexes for KB module
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_audit_id ON knowledge_base_audit(kb_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_audit_action ON knowledge_base_audit(action)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_audit_date ON knowledge_base_audit(action_date)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_teams_kb_id ON knowledge_base_teams(kb_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_teams_team ON knowledge_base_teams(team_name)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_comments_kb_id ON knowledge_base_comments(kb_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_comments_author ON knowledge_base_comments(commented_by)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_visibility ON knowledge_base(visibility)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_kb_owner_team ON knowledge_base(owner_team)");

        // ============================================
        // Known Issues Module
        // ============================================

        addColumnIfMissing($pdo, 'known_issues', 'team_scoped_visibility', "TEXT DEFAULT 'public'");
        addColumnIfMissing($pdo, 'known_issues', 'owner_team', "TEXT DEFAULT NULL");

        // Known Issues to Teams junction table
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS known_issue_teams (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                issue_id INTEGER NOT NULL,
                team_name TEXT NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(issue_id) REFERENCES known_issues(id) ON DELETE CASCADE,
                UNIQUE(issue_id, team_name)
            )
        ");

        // Known Issues audit trail
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS known_issue_audit (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                issue_id INTEGER NOT NULL,
                action TEXT NOT NULL,
                performed_by_id INTEGER,
                user_name TEXT NOT NULL,
                action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
                details TEXT,
                FOREIGN KEY(issue_id) REFERENCES known_issues(id) ON DELETE CASCADE
            )
        ");

        // Known Issues comments
        $pdo->exec("
            CREATE TABLE IF NOT EXISTS known_issue_comments (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                issue_id INTEGER NOT NULL,
                comment_text TEXT NOT NULL,
                commented_by INTEGER NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(issue_id) REFERENCES known_issues(id) ON DELETE CASCADE,
                FOREIGN KEY(commented_by) REFERENCES users(id) ON DELETE SET NULL
            )
        ");

        // Indexes for Known Issues module
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_audit_id ON known_issue_audit(issue_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_audit_action ON known_issue_audit(action)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_audit_date ON known_issue_audit(action_date)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_teams_issue_id ON known_issue_teams(issue_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_teams_team ON known_issue_teams(team_name)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_comments_issue_id ON known_issue_comments(issue_id)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_comments_author ON known_issue_comments(commented_by)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_visibility ON known_issues(team_scoped_visibility)");
        $pdo->exec("CREATE INDEX IF NOT EXISTS idx_known_issue_owner_team ON known_issues(owner_team)");

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Team permissions migration failed: ' . $e->getMessage());
        throw $e;
    }
}
