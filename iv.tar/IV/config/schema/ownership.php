<?php

// ============================================================
// OWNERSHIP INVENTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS ownership (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project TEXT NOT NULL,
        support_level TEXT NOT NULL,
        technical_owner TEXT NOT NULL,
        technical_owner_email TEXT NOT NULL,
        team_dl TEXT NOT NULL,
        technical_manager TEXT NOT NULL,
        technical_manager_email TEXT NOT NULL,
        sdm_name TEXT NOT NULL,
        sdm_email TEXT NOT NULL,
        ncgr_owner TEXT NOT NULL,
        ncgr_owner_email TEXT NOT NULL,
        notes TEXT,
        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_by TEXT,
        updated_at DATETIME
    )
");


// ============================================================
// OWNERSHIP HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS ownership_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        ownership_id INTEGER,

        action_type TEXT,

        performed_by TEXT,

        details TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");
