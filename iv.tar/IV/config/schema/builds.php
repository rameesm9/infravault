<?php

// ============================================================
// BUILDS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS builds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        build_no TEXT NOT NULL,

        project TEXT NOT NULL,

        status TEXT NOT NULL,

        build_by INTEGER NOT NULL,

        supported_by TEXT,

        build_from TEXT,

        user_id INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// BUILD ATTACHMENTS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS build_attachments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        build_id INTEGER NOT NULL,

        filename TEXT NOT NULL,

        filepath TEXT NOT NULL,

        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (build_id)
            REFERENCES builds(id)
            ON DELETE CASCADE
    )
");
