<?php
/**
 * Self-service password reset.
 *
 * Backs forgot-password.php (issues a temporary password by email) and
 * change-password.php (the forced rotation that follows it).
 *
 * Two things are stored:
 *
 *  - users.must_change_password -- set when a temporary password is issued,
 *    cleared when the user chooses their own. securityEnforcePasswordChange()
 *    in includes/security.php reads the session copy of this on every request,
 *    so a password that was mailed in plaintext stops being usable for
 *    anything except setting a new one.
 *
 *  - password_reset_requests -- every attempt, successful or not. It is both
 *    the rate limiter (a reset form with no throttle is a free mail relay
 *    aimed at whoever's address is guessed) and the only audit trail there is:
 *    the page deliberately shows the same message whether or not an account
 *    matched, so this table is where an admin finds out what actually
 *    happened, including a reset that failed because SMTP was down.
 *
 * Runs after mail_settings.php in config/schema-bootstrap.php, because it
 * seeds a row into mail_module_toggles that that file creates.
 */

function runPasswordResetSchema(PDO $pdo): void
{
    // addColumnIfMissing() comes from schema/team-permissions-migration.php,
    // which schema-bootstrap.php requires well before this file.
    addColumnIfMissing($pdo, 'users', 'must_change_password', 'INTEGER NOT NULL DEFAULT 0');

    /*
     * requested_at is a Unix epoch INTEGER for the same reason
     * login_attempts.attempted_at is: SQLite's CURRENT_TIMESTAMP is UTC while
     * this application runs PHP in Asia/Riyadh (APP_TIMEZONE in config/db.php),
     * and comparing the two would shift every rate-limit window by the offset.
     */
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS password_reset_requests (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            identifier TEXT NOT NULL DEFAULT '',
            ip_address TEXT NOT NULL DEFAULT '',
            outcome TEXT NOT NULL DEFAULT '',
            detail TEXT NOT NULL DEFAULT '',
            requested_at INTEGER NOT NULL,
            user_agent TEXT NOT NULL DEFAULT ''
        )
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_password_reset_identifier
        ON password_reset_requests(identifier, requested_at)
    ");

    $pdo->exec("
        CREATE INDEX IF NOT EXISTS idx_password_reset_ip
        ON password_reset_requests(ip_address, requested_at)
    ");

    /*
     * Seeded here rather than left to registerMailModule() alone so the
     * toggle is visible in Settings -> Mail from the first page load, instead
     * of only appearing after someone has already tried to reset a password
     * (and had it silently skipped because the module defaults to off).
     */
    $pdo->prepare("
        INSERT OR IGNORE INTO mail_module_toggles (module_key, module_label)
        VALUES ('password_reset', 'Password Reset Emails')
    ")->execute();
}
