<?php
/**
 * Presentation & Document Designer: template gallery for enterprise
 * PPTX/DOCX exports.
 *
 * No tables -- the tool is entirely client-side (templates, live preview
 * and file generation all run in the browser via the vendored PptxGenJS /
 * docx.js bundles under assets/js/vendor/, with no server-side storage of
 * designs). This file only registers the page key, same pattern as
 * runPlatformSchema()/runUidGidSchema().
 */

function runPresentationDesignerSchema(PDO $pdo): void
{
    try {
        $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)")
            ->execute(['presentation_designer', 'Presentation & Document Designer']);

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'presentation_designer', 1, 1, 1, 1, 1, 1)
        ");

        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'presentation_designer', 0, 0, 0, 0, 0, 0)
        ");

        foreach ($roles as $role) {
            if (strtolower(trim((string) $role)) === 'admin') {
                $grantAll->execute([$role]);
            } else {
                $denyAll->execute([$role]);
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register Presentation Designer page permissions: ' . $e->getMessage());
    }
}
