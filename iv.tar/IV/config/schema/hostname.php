<?php

// ============================================================
// HOSTNAME GENERATOR
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_generators (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL UNIQUE,

        environment TEXT NOT NULL,

        platform TEXT NOT NULL,

        os_code TEXT NOT NULL,

        host_type TEXT NOT NULL,

        project_name TEXT NOT NULL,

        application_name TEXT NOT NULL,

        sequence_number INTEGER NOT NULL,

        generated_by INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (generated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// HOSTNAME RESERVATIONS
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_reservations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL UNIQUE,

        platform_key TEXT NOT NULL,

        platform_code TEXT NOT NULL,

        environment_key TEXT NOT NULL,

        environment_code TEXT NOT NULL,

        os_key TEXT NOT NULL,

        os_code TEXT NOT NULL,

        physical_virtual TEXT NOT NULL,

        project_name TEXT DEFAULT '',

        project_code TEXT DEFAULT '',

        project_abbreviation TEXT DEFAULT '',

        application_name TEXT DEFAULT '',

        application_abbreviation TEXT DEFAULT '',

        node_number INTEGER DEFAULT 1,

        status TEXT NOT NULL DEFAULT 'Reserved',

        generated_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (generated_by)
            REFERENCES users(id)
    )
");


// ============================================================
// HOSTNAME RESERVATION INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_project
    ON hostname_reservations(project_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_project_code
    ON hostname_reservations(project_code)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_application
    ON hostname_reservations(application_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_status
    ON hostname_reservations(status)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_hostname_res_generated_by
    ON hostname_reservations(generated_by)
");


// ============================================================
// HOSTNAME GENERATOR CODES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS hostname_generator_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        category TEXT NOT NULL,

        code_key TEXT NOT NULL,

        code_value TEXT NOT NULL,

        is_admin_only INTEGER NOT NULL DEFAULT 1,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        UNIQUE(category, code_key),

        UNIQUE(category, code_value)
    )
");


// ============================================================
// DEFAULT HOSTNAME CODES
// ============================================================
//
// Platform = exactly 3 characters
// Environment = exactly 1 character
// OS = exactly 1 character
//

$hostname_codes = [

    // --------------------------------------------------------
    // PLATFORM
    // --------------------------------------------------------

    ['platform', 'production', 'RY1'],
    ['platform', 'dr',         'DC2'],
    ['platform', 'gcp',        'GCP'],
    ['platform', 'nutanix',    'NTX'],
    ['platform', 'ugrp',       'UGR'],


    // --------------------------------------------------------
    // ENVIRONMENT
    // --------------------------------------------------------

    ['environment', 'production', 'P'],
    ['environment', 'dr',         'D'],
    ['environment', 'sandbox',    'S'],
    ['environment', 'poc',        'O'],
    ['environment', 'dev',        'V'],
    ['environment', 'test',       'T'],
    ['environment', 'management', 'M'],
    ['environment', 'preprod',    'R'],


    // --------------------------------------------------------
    // OPERATING SYSTEM
    // --------------------------------------------------------

    ['os', 'windows',    'W'],
    ['os', 'redhat',     'R'],
    ['os', 'coreos',     'C'],
    ['os', 'appliance',  'A'],
    ['os', 'rockylinux', 'K'],
    ['os', 'esxi',       'E']
];


// ============================================================
// INSERT DEFAULT HOSTNAME CODES
// ============================================================

$stmt_hostname_codes = $pdo->prepare("
    INSERT OR IGNORE INTO hostname_generator_codes
    (
        category,
        code_key,
        code_value,
        is_admin_only
    )
    VALUES
    (
        ?,
        ?,
        ?,
        1
    )
");

foreach ($hostname_codes as $code) {

    $stmt_hostname_codes->execute([
        $code[0],
        $code[1],
        $code[2]
    ]);

}
