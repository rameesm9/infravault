<?php

// ============================================================
// MY DATA
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS my_data (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        title TEXT NOT NULL,

        short_description TEXT,

        additional_details TEXT,

        visibility TEXT NOT NULL DEFAULT 'private',

        team_name TEXT,

        shared_user_id INTEGER,

        file_original_name TEXT,

        file_stored_name TEXT,

        file_path TEXT,

        file_mime TEXT,

        file_size INTEGER DEFAULT 0,

        owner_id INTEGER NOT NULL,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");

// Migrate visibility values to new format
try {
    $pdo->exec("UPDATE my_data SET visibility='public' WHERE LOWER(visibility)='public'");
    $pdo->exec("UPDATE my_data SET visibility='private' WHERE LOWER(visibility)='private'");
} catch (Exception $e) {
    // Table might be empty or already migrated
}


// ============================================================
// MY DATA TEAM SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS mydata_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mydata_id INTEGER NOT NULL,
        team_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(mydata_id) REFERENCES my_data(id) ON DELETE CASCADE,
        UNIQUE(mydata_id, team_name)
    )
");


// ============================================================
// MY DATA USER SHARING
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS mydata_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mydata_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(mydata_id) REFERENCES my_data(id) ON DELETE CASCADE,
        UNIQUE(mydata_id, user_id)
    )
");


// ============================================================
// MY DATA INDEXES
// ============================================================

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_owner
    ON my_data(owner_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_visibility
    ON my_data(visibility)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_team
    ON my_data(team_name)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_my_data_shared_user
    ON my_data(shared_user_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_mydata_teams_mydata
    ON mydata_teams(mydata_id)
");

$pdo->exec("
    CREATE INDEX IF NOT EXISTS idx_mydata_users_mydata
    ON mydata_users(mydata_id)
");


// ============================================================
// MY DATA AUDIT TRAIL
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS mydata_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mydata_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        performed_by_id INTEGER,
        user_name TEXT NOT NULL,
        action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        details TEXT,
        FOREIGN KEY(mydata_id) REFERENCES my_data(id) ON DELETE CASCADE
    )
");
