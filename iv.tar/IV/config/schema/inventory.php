<?php

// ============================================================
// SERVER INVENTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS inventory (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        hostname TEXT NOT NULL,
        ip_address TEXT NOT NULL,
        additional_ips TEXT,

        os_family TEXT,
        os_version TEXT,
        kernel_version TEXT,

        cpu TEXT,
        memory TEXT,

        support_level TEXT,
        server_state TEXT,

        domain TEXT,
        joined_in TEXT,

        role TEXT,

        cluster_name TEXT,
        managed_by TEXT,
        cluster_type TEXT,

        project TEXT,
        application TEXT,

        technical_owner TEXT,
        technical_owner_email TEXT,

        team_dl TEXT,

        technical_manager TEXT,
        technical_manager_email TEXT,

        sdm_name TEXT,
        sdm_email TEXT,

        ncgr_owner TEXT,
        ncgr_owner_email TEXT,

        server_type TEXT,
        appliance TEXT,

        port_group TEXT,
        vlan TEXT,

        location TEXT,

        criticality TEXT,

        project_code TEXT,

        commissioned_date TEXT,

        host_type TEXT,
        hw_model TEXT,

        esxi_cluster TEXT,

        vendor TEXT,

        dmz TEXT,

        db_type TEXT,

        live TEXT,
        eol TEXT,

        -- Governance flags, stored as the strings 'yes' / 'no' to match
        -- the other yes/no fields on this table (grc is read that way by
        -- grc_schedule.php: LOWER(TRIM(grc)) = 'yes').
        grc TEXT,
        ugrp TEXT,

        backup TEXT,
        monitoring TEXT,
        infra TEXT,

        edit_comments TEXT,

        created_by TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_by TEXT,
        updated_at DATETIME
    )
");


// ============================================================
// INVENTORY COLUMN MIGRATION
// ============================================================
//
// CREATE TABLE IF NOT EXISTS above is a no-op once the table exists,
// so columns added after a deployment went live have to be ALTERed in
// separately. Without this, an existing database silently lacks the
// column and every inventory INSERT/UPDATE fails with "no such column".
//
// This is how 'grc' came to exist only in deployed databases and not in
// the schema file -- a fresh install (a new container, for instance)
// would not have had it at all.
//
// Add new inventory columns here as well as to the CREATE TABLE above.

$inventory_required_columns = [
    'grc'  => 'TEXT',
    'ugrp' => 'TEXT',
];

try {

    $inventory_existing_columns = [];

    foreach (
        $pdo->query('PRAGMA table_info(inventory)')->fetchAll(PDO::FETCH_ASSOC)
        as $inventory_column
    ) {
        $inventory_existing_columns[] = $inventory_column['name'];
    }

    foreach ($inventory_required_columns as $column_name => $column_type) {

        if (!in_array($column_name, $inventory_existing_columns, true)) {

            $pdo->exec(
                "ALTER TABLE inventory ADD COLUMN {$column_name} {$column_type}"
            );
        }
    }

} catch (Throwable $e) {

    // Never stop database initialization over this -- log and continue,
    // consistent with the hostname index handling below.
    error_log(
        'Unable to migrate inventory columns: ' . $e->getMessage()
    );
}


// ============================================================
// INVENTORY HISTORY
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS inventory_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,

        inventory_id INTEGER,

        action_type TEXT,

        performed_by TEXT,

        details TEXT,

        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
    )
");


// ============================================================
// INVENTORY COLUMN PREFERENCES
// ============================================================

$pdo->exec("
    CREATE TABLE IF NOT EXISTS inventory_column_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        column_key TEXT NOT NULL,
        is_visible INTEGER NOT NULL DEFAULT 1,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, column_key)
    )
");


// ============================================================
// INVENTORY HOSTNAME UNIQUE INDEX
// ============================================================
//
// This prevents duplicate hostnames in inventory.
//
// If the existing inventory table contains duplicate hostnames,
// SQLite will reject this index. Clean duplicates first if needed.
//

try {

    $pdo->exec("
        CREATE UNIQUE INDEX IF NOT EXISTS
        idx_inventory_hostname_unique
        ON inventory(hostname)
    ");

} catch (PDOException $e) {

    // Existing duplicate hostnames can prevent this index.
    // Do not stop database initialization.

}
