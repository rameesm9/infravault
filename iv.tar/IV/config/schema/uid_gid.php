<?php
/**
 * UID/GID Tracking: per-server RHEL account registry.
 *
 * One row per (hostname, username) pair -- the same account name can
 * exist on multiple servers with different UID/GID values, which is
 * exactly the kind of drift this module exists to catch. Hostname is
 * sourced from the inventory table (a <select>, not free text) so
 * records stay tied to a real, known server.
 */

function runUidGidSchema(PDO $pdo): void
{
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS uid_gid_accounts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,

            hostname TEXT NOT NULL,
            username TEXT NOT NULL,

            uid INTEGER,
            gid INTEGER,
            gecos TEXT,
            home_directory TEXT,
            login_shell TEXT,

            account_type TEXT NOT NULL DEFAULT 'Named User',
            application TEXT,
            status TEXT NOT NULL DEFAULT 'Active',

            change_request TEXT,
            requested_by TEXT,
            approved_by TEXT,

            notes TEXT,

            created_by INTEGER,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    // Ownership-confirmation evidence (approval email, signed CR form, etc).
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS uid_gid_attachments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id INTEGER NOT NULL,
            filename TEXT,
            filepath TEXT,
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (record_id) REFERENCES uid_gid_accounts(id) ON DELETE CASCADE
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS uid_gid_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            record_id INTEGER,
            action_type TEXT NOT NULL,
            performed_by TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");

    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_uid_gid_hostname ON uid_gid_accounts(hostname)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_uid_gid_username ON uid_gid_accounts(username)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_uid_gid_attachments ON uid_gid_attachments(record_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_uid_gid_history ON uid_gid_history(record_id, timestamp)");

    /*
    |--------------------------------------------------------------------------
    | PERMISSION REGISTRATION
    |--------------------------------------------------------------------------
    |
    | Same pattern as runPlatformSchema(): register the page key so Manage
    | Permissions lists it, grant Admin all six verbs immediately, and give
    | every other role an explicit all-zero row -- authzCan() denies on a
    | missing row anyway, but an explicit row is what makes the permission
    | screen show the truth instead of a blank/unregistered page.
    */

    try {
        $pdo->prepare("INSERT OR IGNORE INTO pages (page_key, page_name) VALUES (?, ?)")
            ->execute(['uid_gid', 'UID/GID Tracking']);

        $roles = $pdo->query("SELECT role_name FROM roles")->fetchAll(PDO::FETCH_COLUMN);

        $grantAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'uid_gid', 1, 1, 1, 1, 1, 1)
        ");

        $denyAll = $pdo->prepare("
            INSERT OR IGNORE INTO permissions
                (role, page_key, can_view, can_edit, can_delete, can_export, can_import, can_audit)
            VALUES (?, 'uid_gid', 0, 0, 0, 0, 0, 0)
        ");

        foreach ($roles as $role) {
            if (strtolower(trim((string) $role)) === 'admin') {
                $grantAll->execute([$role]);
            } else {
                $denyAll->execute([$role]);
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to register UID/GID Tracking page permissions: ' . $e->getMessage());
    }
}
