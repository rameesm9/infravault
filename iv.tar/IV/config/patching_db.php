<?php

/*
|--------------------------------------------------------------------------
| Patching Schedule Database
|--------------------------------------------------------------------------
|
| Uses the application's existing SQLite connection from config/db.php.
|
| Features:
|
| - Patch schedule management
| - Project + Support Level assignment
| - Optional Application
| - Per-server selection
| - Per-server assignee
| - Existing installation migration
|
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/db.php';


/*
|--------------------------------------------------------------------------
| Validate PDO
|--------------------------------------------------------------------------
*/

if (!isset($pdo) || !($pdo instanceof PDO)) {

    throw new RuntimeException(
        'Database connection $pdo is not available from config/db.php.'
    );
}


$pdo->setAttribute(
    PDO::ATTR_ERRMODE,
    PDO::ERRMODE_EXCEPTION
);


/*
|--------------------------------------------------------------------------
| Enable foreign keys
|--------------------------------------------------------------------------
*/

$pdo->exec(
    'PRAGMA foreign_keys = ON'
);


/*
|--------------------------------------------------------------------------
| Main patch schedule table
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_schedules (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        year INTEGER NOT NULL,

        quarter INTEGER NOT NULL,

        project TEXT NOT NULL,

        application TEXT NOT NULL DEFAULT '',

        support_level TEXT DEFAULT '',

        assigned_to INTEGER,

        cr TEXT DEFAULT '',

        status TEXT NOT NULL DEFAULT 'Assigned',

        scheduled_date DATE,

        notes TEXT DEFAULT '',

        reminder_sent_at DATETIME,

        created_by INTEGER,

        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (assigned_to)
            REFERENCES users(id)
            ON DELETE SET NULL,

        FOREIGN KEY (created_by)
            REFERENCES users(id)
            ON DELETE SET NULL
    )
");


/*
|--------------------------------------------------------------------------
| Per-server patch tracking table
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE TABLE IF NOT EXISTS patch_schedule_servers (

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        schedule_id INTEGER NOT NULL,

        hostname TEXT NOT NULL,

        selected INTEGER NOT NULL DEFAULT 0,

        assigned_to INTEGER,

        patch_date DATE,

        status TEXT DEFAULT '',

        comment TEXT DEFAULT '',

        cr TEXT DEFAULT '',

        -- Quarterly patch tracking fields.
        --
        -- These are the per-host values the hostname-level CSV round trip
        -- reads and writes. Everything the patching module can derive from
        -- inventory or license_warranty is deliberately NOT stored here --
        -- it is looked up live at export time so this table can never hold
        -- a stale copy of inventory master data.
        --
        -- last_kernel_patch is the exception, and is meant to be stale: it
        -- is a frozen snapshot of inventory.kernel_version taken when the
        -- host first enters a quarter, so the kernel version from before
        -- that quarter patch survives inventory being updated afterwards.
        -- Nothing may overwrite it once set.

        -- new_os_version / new_kernel_version are what the host was moved
        -- TO by this quarter patch. They are promoted into inventory as the
        -- current values once the row is marked Completed; until then
        -- inventory still reflects the pre-patch state.

        new_os_version TEXT DEFAULT '',

        new_kernel_version TEXT DEFAULT '',

        applied_patch TEXT DEFAULT '',

        applied_patch_release_date TEXT,

        patch_level TEXT DEFAULT '',

        latest_available_patch TEXT DEFAULT '',

        last_kernel_patch TEXT DEFAULT '',

        kernel_patch_n_level TEXT DEFAULT '',

        downtime_required TEXT DEFAULT '',

        updated_by INTEGER,

        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,

        FOREIGN KEY (schedule_id)
            REFERENCES patch_schedules(id)
            ON DELETE CASCADE,

        FOREIGN KEY (assigned_to)
            REFERENCES users(id)
            ON DELETE SET NULL,

        FOREIGN KEY (updated_by)
            REFERENCES users(id)
            ON DELETE SET NULL,

        UNIQUE(schedule_id, hostname)
    )
");


/*
|--------------------------------------------------------------------------
| Check existing patch_schedule_servers columns
|--------------------------------------------------------------------------
*/

$columns = [];

$columnStmt = $pdo->query(
    'PRAGMA table_info(patch_schedule_servers)'
);

foreach (
    $columnStmt->fetchAll(PDO::FETCH_ASSOC)
    as $column
) {

    if (
        isset($column['name']) &&
        $column['name'] !== ''
    ) {

        $columns[$column['name']] = true;
    }
}


/*
|--------------------------------------------------------------------------
| Add selected column if missing
|--------------------------------------------------------------------------
*/

if (!isset($columns['selected'])) {

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN selected INTEGER NOT NULL DEFAULT 0
    ");


    /*
    | Existing rows were already part of an assignment,
    | so mark them selected.
    */

    $pdo->exec("
        UPDATE patch_schedule_servers
        SET selected = 1
        WHERE selected = 0
    ");
}


/*
|--------------------------------------------------------------------------
| Add assigned_to column if missing
|--------------------------------------------------------------------------
*/

if (!isset($columns['assigned_to'])) {

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN assigned_to INTEGER
        REFERENCES users(id)
        ON DELETE SET NULL
    ");
}


/*
|--------------------------------------------------------------------------
| Add quarterly patch tracking columns if missing
|--------------------------------------------------------------------------
|
| CREATE TABLE IF NOT EXISTS above is a no-op once the table exists, so
| columns added after a deployment went live have to be ALTERed in here
| as well. Add new columns in BOTH places.
|
*/

$patchTrackingColumns = [
    'new_os_version'             => "TEXT DEFAULT ''",
    'new_kernel_version'         => "TEXT DEFAULT ''",
    'applied_patch'              => "TEXT DEFAULT ''",
    'applied_patch_release_date' => 'TEXT',
    'patch_level'                => "TEXT DEFAULT ''",
    'latest_available_patch'     => "TEXT DEFAULT ''",
    'last_kernel_patch'          => "TEXT DEFAULT ''",
    'kernel_patch_n_level'       => "TEXT DEFAULT ''",
    'downtime_required'          => "TEXT DEFAULT ''",
];

foreach ($patchTrackingColumns as $trackingColumn => $trackingType) {

    if (isset($columns[$trackingColumn])) {
        continue;
    }

    $pdo->exec("
        ALTER TABLE patch_schedule_servers
        ADD COLUMN {$trackingColumn} {$trackingType}
    ");
}


/*
|--------------------------------------------------------------------------
| Backfill last_kernel_patch for rows that predate the column
|--------------------------------------------------------------------------
|
| A snapshot taken now is not the true "kernel before this quarter's
| patch" for a host that was already patched, but it is far better than
| a permanently blank column: the value is frozen from here on, so every
| future quarter records a correct one. Only rows with no snapshot are
| touched, so this cannot overwrite a real one on a later run.
|
*/

if (!isset($columns['last_kernel_patch'])) {

    $pdo->exec("
        UPDATE patch_schedule_servers
        SET last_kernel_patch = COALESCE(
            (
                SELECT i.kernel_version
                FROM inventory i
                WHERE i.hostname = patch_schedule_servers.hostname
            ),
            ''
        )
        WHERE last_kernel_patch IS NULL OR last_kernel_patch = ''
    ");
}


/*
|--------------------------------------------------------------------------
| Make sure patch_schedules.application exists
|--------------------------------------------------------------------------
*/

$scheduleColumns = [];

$scheduleColumnStmt = $pdo->query(
    'PRAGMA table_info(patch_schedules)'
);

foreach (
    $scheduleColumnStmt->fetchAll(PDO::FETCH_ASSOC)
    as $column
) {

    if (
        isset($column['name']) &&
        $column['name'] !== ''
    ) {

        $scheduleColumns[$column['name']] = true;
    }
}


/*
|--------------------------------------------------------------------------
| Existing database migration:
|
| Add application if it doesn't exist.
|--------------------------------------------------------------------------
*/

if (!isset($scheduleColumns['application'])) {

    $pdo->exec("
        ALTER TABLE patch_schedules
        ADD COLUMN application TEXT NOT NULL DEFAULT ''
    ");
}


/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_year_quarter
    ON patch_schedules(year, quarter)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_assigned
    ON patch_schedules(assigned_to)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_project
    ON patch_schedules(project, application)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedules_reminder
    ON patch_schedules(
        scheduled_date,
        reminder_sent_at
    )
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_schedule
    ON patch_schedule_servers(schedule_id)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_assigned
    ON patch_schedule_servers(assigned_to)
");


$pdo->exec("
    CREATE INDEX IF NOT EXISTS
    idx_patch_schedule_servers_selected
    ON patch_schedule_servers(
        schedule_id,
        selected
    )
");


/*
|--------------------------------------------------------------------------
| Done
|--------------------------------------------------------------------------
*/


/*
|--------------------------------------------------------------------------
| SHARED PATCHING HELPERS
|--------------------------------------------------------------------------
|
| These live here rather than in patching.php because patch_servers.php
| and patch_export.php need them too, and neither can include the
| patching page without running it. They all require this one already.
*/

function logPatchHistory(PDO $pdo, ?int $scheduleId, string $actionType, string $performedBy, string $details): void
{
    try {
        $stmt = $pdo->prepare("INSERT INTO patch_schedule_history (schedule_id, action_type, performed_by, details) VALUES (?, ?, ?, ?)");
        $stmt->execute([$scheduleId, $actionType, $performedBy, $details]);
    } catch (Throwable $e) {
        error_log('Unable to log patch schedule history: ' . $e->getMessage());
    }
}

function patchingCsvHeaders(int $quarter, array $quarterRanges): array
{
    $range = $quarterRanges[$quarter] ?? '';

    return [
        'Hostname',
        'IP',
        'Project',
        'Criticality',
        'Support Group',
        'Environment',
        'Technical Owner',
        'Application Owner',
        'OS Type',
        'OS Version',
        'Applied Patch',
        'Applied Patch Release Date',
        'Patch Level (N, N-1, N-2)',
        'Product Release Premier Support End Date',
        'Latest Available Patch Details (N)',
        'Last Kernel Patch',
        'Applied Kernel Patch',
        'Kernel Patch N Level',
        'Patch Planned Time Q' . $quarter . ($range !== '' ? ' (' . $range . ')' : ''),
        'Q' . $quarter . ' Change Number',
        'Q' . $quarter . ' Status',
        'Downtime Required',
        'Note',
        'Last Update',
        'Assignee',
    ];
}

/*
| Product support end date, sourced from license_warranty.
|
| Keyed on a squashed product name + version so "Red Hat Enterprise Linux"
| / "RHEL 8.6" style spelling differences between the two modules do not
| silently produce a blank column. Two fallbacks are kept, each narrower
| than a wildcard match:
|
|   name + major version  -- license_warranty tracks "8", inventory "8.6"
|   name only             -- a licence row that covers every version
*/
function patchingSupportEndDates(PDO $pdo): array
{
    $map = [];

    try {
        $rows = $pdo->query("
            SELECT product_name, product_version, support_expiry_date
            FROM license_warranty
            WHERE support_expiry_date IS NOT NULL
              AND TRIM(support_expiry_date) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('Unable to read license_warranty support dates: ' . $e->getMessage());
        return [];
    }

    $squash = function ($value) {
        return preg_replace('/[^a-z0-9.]+/', '', strtolower(trim((string) $value)));
    };

    foreach ($rows as $row) {
        $name = $squash($row['product_name'] ?? '');

        if ($name === '') {
            continue;
        }

        $version = $squash($row['product_version'] ?? '');
        $expiry = trim((string) $row['support_expiry_date']);

        /*
         * First writer wins rather than last, so a specific row is not
         * clobbered by a later duplicate entry for the same product.
         */
        foreach ([$name . '|' . $version, $name . '|'] as $key) {
            if (!isset($map[$key])) {
                $map[$key] = $expiry;
            }
        }
    }

    return $map;
}

function patchingLookupSupportEndDate(array $map, ?string $osType, ?string $osVersion): string
{
    $squash = function ($value) {
        return preg_replace('/[^a-z0-9.]+/', '', strtolower(trim((string) $value)));
    };

    $name = $squash($osType);

    if ($name === '') {
        return '';
    }

    $version = $squash($osVersion);
    $major = strpos($version, '.') !== false
        ? substr($version, 0, strpos($version, '.'))
        : $version;

    foreach ([$version, $major, ''] as $candidate) {
        if (isset($map[$name . '|' . $candidate])) {
            return $map[$name . '|' . $candidate];
        }
    }

    return '';
}


/*
|--------------------------------------------------------------------------
| Done
|--------------------------------------------------------------------------
*/

return true;
