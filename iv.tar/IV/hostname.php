<?php

require_once 'config/db.php';
require_once 'includes/pagination-helpers.php';


/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| AUTHORIZATION
|--------------------------------------------------------------------------
*/

requirePermission('hostname', 'can_view');


$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(
    trim($_SESSION['role'] ?? '')
);

$is_admin = in_array(
    $role,
    [
        'admin',
        'administrator',
        'super admin',
        'superadmin'
    ],
    true
);


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['hostname_csrf'])) {
    $_SESSION['hostname_csrf'] =
        bin2hex(random_bytes(32));
}

$csrf_token =
    $_SESSION['hostname_csrf'];


/*
|--------------------------------------------------------------------------
| HELPERS
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function redirect_hostname(): void
{
    header('Location: hostname.php');
    exit;
}


function check_hostname_csrf(): void
{
    $token =
        $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['hostname_csrf']) ||
        !hash_equals(
            $_SESSION['hostname_csrf'],
            $token
        )
    ) {
        http_response_code(403);

        exit(
            'Invalid security token.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| NORMALIZE CODE
|--------------------------------------------------------------------------
*/

function normalize_code(
    string $value,
    int $length = 3
): string {

    $value = strtoupper(
        trim($value)
    );

    $value = preg_replace(
        '/[^A-Z0-9]/',
        '',
        $value
    );

    return substr(
        $value,
        0,
        $length
    );
}


/*
|--------------------------------------------------------------------------
| GENERATE ABBREVIATION
|--------------------------------------------------------------------------
|
| Customer Billing Platform
| -> CBP
|
| Application
| -> APP
|
*/

function generate_abbreviation(
    string $name,
    int $length = 3
): string {

    $name = trim($name);

    if ($name === '') {
        return '';
    }

    $words = preg_split(
        '/\s+/',
        $name
    );

    $letters = '';

    foreach ($words as $word) {

        $word = preg_replace(
            '/[^A-Za-z0-9]/',
            '',
            $word
        );

        if ($word !== '') {

            $letters .= strtoupper(
                substr(
                    $word,
                    0,
                    1
                )
            );
        }

        if (
            strlen($letters) >= $length
        ) {
            break;
        }
    }


    /*
    |--------------------------------------------------------------------------
    | Fill remaining characters
    |--------------------------------------------------------------------------
    |
    | Duplicate characters are allowed.
    |
    | Application
    | -> APP
    |
    */

    if (
        strlen($letters) < $length
    ) {

        $compact = strtoupper(
            preg_replace(
                '/[^A-Za-z0-9]/',
                '',
                $name
            )
        );

        for (
            $i = 0;
            $i < strlen($compact);
            $i++
        ) {

            $letters .= $compact[$i];

            if (
                strlen($letters) >= $length
            ) {
                break;
            }
        }
    }

    return substr(
        $letters,
        0,
        $length
    );
}


/*
|--------------------------------------------------------------------------
| LOAD CODES
|--------------------------------------------------------------------------
*/

function load_hostname_codes(
    PDO $pdo,
    string $category
): array {

    $stmt = $pdo->prepare("
        SELECT
            id,
            code_key,
            code_value,
            is_admin_only
        FROM hostname_generator_codes
        WHERE category = ?
        ORDER BY id ASC
    ");

    $stmt->execute([
        $category
    ]);

    return $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );
}


$platform_codes =
    load_hostname_codes(
        $pdo,
        'platform'
    );

$environment_codes =
    load_hostname_codes(
        $pdo,
        'environment'
    );

$os_codes =
    load_hostname_codes(
        $pdo,
        'os'
    );


/*
|--------------------------------------------------------------------------
| FIND CODE
|--------------------------------------------------------------------------
*/

function find_code(
    array $codes,
    string $key
): ?array {

    foreach ($codes as $code) {

        if (
            $code['code_key'] === $key
        ) {
            return $code;
        }
    }

    return null;
}


/*
|--------------------------------------------------------------------------
| HOSTNAME EXISTS
|--------------------------------------------------------------------------
*/

function hostname_exists(
    PDO $pdo,
    string $hostname,
    ?int $exclude_reservation_id = null
): bool {

    /*
    |--------------------------------------------------------------------------
    | Inventory
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT 1
        FROM inventory
        WHERE hostname = ?
        LIMIT 1
    ");

    $stmt->execute([
        $hostname
    ]);

    if ($stmt->fetchColumn()) {
        return true;
    }


    /*
    |--------------------------------------------------------------------------
    | Reservations
    |--------------------------------------------------------------------------
    */

    if (
        $exclude_reservation_id !== null
    ) {

        $stmt = $pdo->prepare("
            SELECT 1
            FROM hostname_reservations
            WHERE hostname = ?
              AND id != ?
            LIMIT 1
        ");

        $stmt->execute([
            $hostname,
            $exclude_reservation_id
        ]);

    } else {

        $stmt = $pdo->prepare("
            SELECT 1
            FROM hostname_reservations
            WHERE hostname = ?
            LIMIT 1
        ");

        $stmt->execute([
            $hostname
        ]);
    }

    return (bool) $stmt->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| BUILD HOSTNAME
|--------------------------------------------------------------------------
*/

function build_hostname(
    string $platform,
    string $environment,
    string $os,
    string $physical_virtual,
    string $project,
    string $component,
    int $node,
    int $node_length
): string {

    $platform =
        normalize_code(
            $platform,
            3
        );

    $environment =
        normalize_code(
            $environment,
            1
        );

    $os =
        normalize_code(
            $os,
            1
        );

    $physical_virtual =
        normalize_code(
            $physical_virtual,
            1
        );

    $project =
        normalize_code(
            $project,
            3
        );

    $component =
        strtoupper(
            preg_replace(
                '/[^A-Z0-9]/',
                '',
                $component
            )
        );

    $node =
        max(
            1,
            $node
        );

    $node_code =
        str_pad(
            (string) $node,
            $node_length,
            '0',
            STR_PAD_LEFT
        );

    $hostname =
        $platform .
        $environment .
        $os .
        $physical_virtual .
        $project .
        $component .
        $node_code;


    if (
        strlen($hostname) > 23
    ) {

        throw new RuntimeException(
            'Generated hostname exceeds 23 characters.'
        );
    }


    if (
        !preg_match(
            '/^[A-Z0-9]+$/',
            $hostname
        )
    ) {

        throw new RuntimeException(
            'Generated hostname contains invalid characters.'
        );
    }


    return $hostname;
}


/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['hostname_success']
    ?? '';

$error_msg =
    $_SESSION['hostname_error']
    ?? '';

unset(
    $_SESSION['hostname_success'],
    $_SESSION['hostname_error']
);


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
) {

    check_hostname_csrf();

    $form_action =
        $_POST['form_action']
        ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE RESERVATIONS
    |--------------------------------------------------------------------------
    */

    if (
        $form_action === 'save_reservations'
    ) {

        try {

            /*
            |--------------------------------------------------------------------------
            | BASIC FIELDS
            |--------------------------------------------------------------------------
            */

            $platform_key =
                trim(
                    $_POST['platform_key']
                    ?? ''
                );

            $environment_key =
                trim(
                    $_POST['environment_key']
                    ?? ''
                );

            $os_key =
                trim(
                    $_POST['os_key']
                    ?? ''
                );

            $physical_virtual =
                trim(
                    $_POST['physical_virtual']
                    ?? ''
                );


            /*
            |--------------------------------------------------------------------------
            | PROJECT
            |--------------------------------------------------------------------------
            */

            $project_name =
                trim(
                    $_POST['project_name']
                    ?? ''
                );

            $project_code =
                trim(
                    $_POST['project_code']
                    ?? ''
                );

            $project_abbreviation =
                normalize_code(
                    $_POST[
                        'project_abbreviation'
                    ]
                    ?? '',
                    3
                );


            /*
            |--------------------------------------------------------------------------
            | APPLICATION
            |--------------------------------------------------------------------------
            */

            $application_name =
                trim(
                    $_POST['application_name']
                    ?? ''
                );

            $application_abbreviation =
                normalize_code(
                    $_POST[
                        'application_abbreviation'
                    ]
                    ?? '',
                    3
                );


            /*
            |--------------------------------------------------------------------------
            | COUNTS
            |--------------------------------------------------------------------------
            */

            $app_count =
                max(
                    1,
                    min(
                        99,
                        (int) (
                            $_POST[
                                'app_count'
                            ]
                            ?? 1
                        )
                    )
                );

            $db_count =
                max(
                    0,
                    min(
                        99,
                        (int) (
                            $_POST[
                                'db_count'
                            ]
                            ?? 0
                        )
                    )
                );

            $web_count =
                max(
                    0,
                    min(
                        99,
                        (int) (
                            $_POST[
                                'web_count'
                            ]
                            ?? 0
                        )
                    )
                );


            /*
            |--------------------------------------------------------------------------
            | STARTING NODES
            |--------------------------------------------------------------------------
            */

            $starting_app_node =
                max(
                    1,
                    (int) (
                        $_POST[
                            'starting_app_node'
                        ]
                        ?? 1
                    )
                );

            $starting_db_node =
                max(
                    1,
                    (int) (
                        $_POST[
                            'starting_db_node'
                        ]
                        ?? 1
                    )
                );

            $starting_web_node =
                max(
                    1,
                    (int) (
                        $_POST[
                            'starting_web_node'
                        ]
                        ?? 1
                    )
                );


            /*
            |--------------------------------------------------------------------------
            | COMPONENT ABBREVIATIONS
            |--------------------------------------------------------------------------
            */

            $db_abbreviation =
                normalize_code(
                    $_POST[
                        'db_abbreviation'
                    ]
                    ?? 'DB',
                    3
                );

            $web_abbreviation =
                normalize_code(
                    $_POST[
                        'web_abbreviation'
                    ]
                    ?? 'WEB',
                    3
                );


            /*
            |--------------------------------------------------------------------------
            | FIND CODES
            |--------------------------------------------------------------------------
            */

            $platform =
                find_code(
                    $platform_codes,
                    $platform_key
                );

            $environment =
                find_code(
                    $environment_codes,
                    $environment_key
                );

            $os =
                find_code(
                    $os_codes,
                    $os_key
                );


            if (
                !$platform ||
                !$environment ||
                !$os
            ) {

                throw new RuntimeException(
                    'Invalid hostname code selection.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | PHYSICAL / VIRTUAL
            |--------------------------------------------------------------------------
            */

            if (
                !in_array(
                    $physical_virtual,
                    ['P', 'V'],
                    true
                )
            ) {

                throw new RuntimeException(
                    'Please select Physical or Virtual.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | PROJECT ABBREVIATION
            |--------------------------------------------------------------------------
            */

            if (
                strlen(
                    $project_abbreviation
                ) !== 3
            ) {

                throw new RuntimeException(
                    'Project abbreviation must contain exactly 3 characters.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | APPLICATION ABBREVIATION
            |--------------------------------------------------------------------------
            */

            if (
                strlen(
                    $application_abbreviation
                ) !== 3
            ) {

                throw new RuntimeException(
                    'Application abbreviation must contain exactly 3 characters.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | DB VALIDATION
            |--------------------------------------------------------------------------
            */

            if (
                $db_count > 0 &&
                (
                    strlen($db_abbreviation) < 2 ||
                    strlen($db_abbreviation) > 3
                )
            ) {

                throw new RuntimeException(
                    'DB abbreviation must contain 2 or 3 characters.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | WEB VALIDATION
            |--------------------------------------------------------------------------
            */

            if (
                $web_count > 0 &&
                strlen($web_abbreviation) !== 3
            ) {

                throw new RuntimeException(
                    'WEB abbreviation must contain exactly 3 characters.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | NODE VALIDATION
            |--------------------------------------------------------------------------
            */

            if (
                $starting_app_node +
                $app_count -
                1 > 99
            ) {

                throw new RuntimeException(
                    'APP node number cannot exceed 99.'
                );
            }


            if (
                $db_count > 0 &&
                $starting_db_node +
                $db_count -
                1 > 999
            ) {

                throw new RuntimeException(
                    'DB node number cannot exceed 999.'
                );
            }


            if (
                $web_count > 0 &&
                $starting_web_node +
                $web_count -
                1 > 99
            ) {

                throw new RuntimeException(
                    'WEB node number cannot exceed 99.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | TOTAL LIMIT
            |--------------------------------------------------------------------------
            */

            $total_hostnames =
                $app_count +
                $db_count +
                $web_count;

            if (
                $total_hostnames > 100
            ) {

                throw new RuntimeException(
                    'Maximum 100 hostnames per generation.'
                );
            }


            /*
            |--------------------------------------------------------------------------
            | BUILD HOSTNAME LIST SERVER-SIDE
            |--------------------------------------------------------------------------
            */

            $generated_hostnames = [];


            /*
            |--------------------------------------------------------------------------
            | APP
            |--------------------------------------------------------------------------
            */

            for (
                $i = 0;
                $i < $app_count;
                $i++
            ) {

                $node =
                    $starting_app_node + $i;

                $hostname =
                    build_hostname(
                        $platform['code_value'],
                        $environment['code_value'],
                        $os['code_value'],
                        $physical_virtual,
                        $project_abbreviation,
                        $application_abbreviation,
                        $node,
                        2
                    );

                $generated_hostnames[] = [
                    'hostname' =>
                        $hostname,

                    'type' =>
                        'APP',

                    'node' =>
                        $node
                ];
            }


            /*
            |--------------------------------------------------------------------------
            | DB
            |--------------------------------------------------------------------------
            */

            for (
                $i = 0;
                $i < $db_count;
                $i++
            ) {

                $node =
                    $starting_db_node + $i;

                $hostname =
                    build_hostname(
                        $platform['code_value'],
                        $environment['code_value'],
                        $os['code_value'],
                        $physical_virtual,
                        $project_abbreviation,
                        $db_abbreviation,
                        $node,
                        3
                    );

                $generated_hostnames[] = [
                    'hostname' =>
                        $hostname,

                    'type' =>
                        'DB',

                    'node' =>
                        $node
                ];
            }


            /*
            |--------------------------------------------------------------------------
            | WEB
            |--------------------------------------------------------------------------
            */

            for (
                $i = 0;
                $i < $web_count;
                $i++
            ) {

                $node =
                    $starting_web_node + $i;

                $hostname =
                    build_hostname(
                        $platform['code_value'],
                        $environment['code_value'],
                        $os['code_value'],
                        $physical_virtual,
                        $project_abbreviation,
                        $web_abbreviation,
                        $node,
                        2
                    );

                $generated_hostnames[] = [
                    'hostname' =>
                        $hostname,

                    'type' =>
                        'WEB',

                    'node' =>
                        $node
                ];
            }


            /*
            |--------------------------------------------------------------------------
            | TRANSACTION
            |--------------------------------------------------------------------------
            */

            $pdo->beginTransaction();


            $stmt = $pdo->prepare("
                INSERT INTO hostname_reservations
                (
                    hostname,

                    platform_key,
                    platform_code,

                    environment_key,
                    environment_code,

                    os_key,
                    os_code,

                    physical_virtual,

                    project_name,
                    project_code,
                    project_abbreviation,

                    application_name,
                    application_abbreviation,

                    node_number,

                    status,
                    generated_by,

                    created_at,
                    updated_at
                )
                VALUES
                (
                    ?,
                    ?, ?,
                    ?, ?,
                    ?, ?,
                    ?,
                    ?, ?, ?,
                    ?, ?,
                    ?,
                    'Reserved',
                    ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");


            $saved = 0;

            $seen_hostnames = [];


            foreach (
                $generated_hostnames
                as $generated
            ) {

                $hostname =
                    $generated['hostname'];

                $type =
                    $generated['type'];

                $node =
                    $generated['node'];


                /*
                |--------------------------------------------------------------------------
                | PREVENT DUPLICATES
                |--------------------------------------------------------------------------
                */

                if (
                    isset(
                        $seen_hostnames[
                            $hostname
                        ]
                    )
                ) {
                    continue;
                }

                $seen_hostnames[
                    $hostname
                ] = true;


                /*
                |--------------------------------------------------------------------------
                | CHECK EXISTING
                |--------------------------------------------------------------------------
                */

                if (
                    hostname_exists(
                        $pdo,
                        $hostname
                    )
                ) {
                    continue;
                }


                /*
                |--------------------------------------------------------------------------
                | RECORD APPLICATION DETAILS
                |--------------------------------------------------------------------------
                */

                if (
                    $type === 'DB'
                ) {

                    $record_application_name =
                        'Database';

                    $record_application_abbreviation =
                        $db_abbreviation;

                } elseif (
                    $type === 'WEB'
                ) {

                    $record_application_name =
                        'Web';

                    $record_application_abbreviation =
                        $web_abbreviation;

                } else {

                    $record_application_name =
                        $application_name;

                    $record_application_abbreviation =
                        $application_abbreviation;
                }


                try {

                    $stmt->execute([

                        $hostname,

                        $platform['code_key'],
                        $platform['code_value'],

                        $environment['code_key'],
                        $environment['code_value'],

                        $os['code_key'],
                        $os['code_value'],

                        $physical_virtual,

                        $project_name,
                        $project_code,
                        $project_abbreviation,

                        $record_application_name,
                        $record_application_abbreviation,

                        $node,

                        $current_user_id
                    ]);

                    $saved++;

                } catch (
                    PDOException $e
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | Ignore unique collisions
                    |--------------------------------------------------------------------------
                    */

                    $message =
                        strtolower(
                            $e->getMessage()
                        );

                    if (
                        strpos(
                            $message,
                            'unique'
                        ) !== false
                    ) {
                        continue;
                    }

                    throw $e;
                }
            }


            $pdo->commit();


            if (
                $saved > 0
            ) {

                $_SESSION['hostname_success'] =
                    $saved .
                    ' hostname(s) reserved successfully.';

            } else {

                $_SESSION['hostname_error'] =
                    'No hostname was saved. All generated hostnames already exist.';
            }

        } catch (
            Throwable $e
        ) {

            if (
                $pdo->inTransaction()
            ) {
                $pdo->rollBack();
            }

            $_SESSION['hostname_error'] =
                'Unable to save hostnames: ' .
                $e->getMessage();
        }


        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE RESERVATION
    |--------------------------------------------------------------------------
    */

    if (
        $form_action === 'delete_reservation'
    ) {

        $id =
            (int) (
                $_POST[
                    'reservation_id'
                ]
                ?? 0
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_reservations
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $reservation =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            !$reservation
        ) {

            $_SESSION['hostname_error'] =
                'Reservation not found.';

            redirect_hostname();
        }


        if (
            !$is_admin &&
            (int)
                $reservation[
                    'generated_by'
                ] !== $current_user_id
        ) {

            http_response_code(403);

            exit(
                'You do not have permission to delete this reservation.'
            );
        }


        $stmt = $pdo->prepare("
            DELETE FROM hostname_reservations
            WHERE id = ?
        ");

        $stmt->execute([
            $id
        ]);


        $_SESSION['hostname_success'] =
            'Hostname reservation deleted.';

        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | UPDATE RESERVATION
    |--------------------------------------------------------------------------
    */

    if (
        $form_action === 'update_reservation'
    ) {

        $id =
            (int) (
                $_POST[
                    'reservation_id'
                ]
                ?? 0
            );


        $project_name =
            trim(
                $_POST[
                    'project_name'
                ]
                ?? ''
            );

        $project_code =
            trim(
                $_POST[
                    'project_code'
                ]
                ?? ''
            );

        $application_name =
            trim(
                $_POST[
                    'application_name'
                ]
                ?? ''
            );


        $project_abbreviation =
            normalize_code(
                $_POST[
                    'project_abbreviation'
                ]
                ?? '',
                3
            );


        $application_abbreviation =
            normalize_code(
                $_POST[
                    'application_abbreviation'
                ]
                ?? '',
                3
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_reservations
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $reservation =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            !$reservation
        ) {

            $_SESSION['hostname_error'] =
                'Reservation not found.';

            redirect_hostname();
        }


        if (
            !$is_admin &&
            (int)
                $reservation[
                    'generated_by'
                ] !== $current_user_id
        ) {

            http_response_code(403);

            exit(
                'You do not have permission to edit this reservation.'
            );
        }


        if (
            strlen(
                $project_abbreviation
            ) !== 3 ||
            strlen(
                $application_abbreviation
            ) !== 3
        ) {

            $_SESSION['hostname_error'] =
                'Project and application abbreviations must be exactly 3 characters.';

            redirect_hostname();
        }


        /*
        |--------------------------------------------------------------------------
        | DETERMINE COMPONENT TYPE
        |--------------------------------------------------------------------------
        */

        $original_application_name =
            strtolower(
                trim(
                    $reservation[
                        'application_name'
                    ] ?? ''
                )
            );


        if (
            $original_application_name ===
            'database'
        ) {

            $component =
                $application_abbreviation;

            $node_length = 3;

        } elseif (
            $original_application_name ===
            'web'
        ) {

            $component =
                $application_abbreviation;

            $node_length = 2;

        } else {

            $component =
                $application_abbreviation;

            $node_length = 2;
        }


        /*
        |--------------------------------------------------------------------------
        | REBUILD HOSTNAME
        |--------------------------------------------------------------------------
        */

        try {

            $new_hostname =
                build_hostname(

                    $reservation[
                        'platform_code'
                    ],

                    $reservation[
                        'environment_code'
                    ],

                    $reservation[
                        'os_code'
                    ],

                    $reservation[
                        'physical_virtual'
                    ],

                    $project_abbreviation,

                    $component,

                    (int)
                        $reservation[
                            'node_number'
                        ],

                    $node_length
                );

        } catch (
            Throwable $e
        ) {

            $_SESSION['hostname_error'] =
                $e->getMessage();

            redirect_hostname();
        }


        /*
        |--------------------------------------------------------------------------
        | CHECK NEW HOSTNAME
        |--------------------------------------------------------------------------
        */

        if (
            hostname_exists(
                $pdo,
                $new_hostname,
                $id
            )
        ) {

            $_SESSION['hostname_error'] =
                'The new hostname already exists in inventory or another reservation.';

            redirect_hostname();
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            UPDATE hostname_reservations

            SET
                hostname = ?,

                project_name = ?,
                project_code = ?,
                project_abbreviation = ?,

                application_name = ?,
                application_abbreviation = ?,

                updated_at = CURRENT_TIMESTAMP

            WHERE id = ?
        ");

        $stmt->execute([

            $new_hostname,

            $project_name,
            $project_code,
            $project_abbreviation,

            $application_name,
            $application_abbreviation,

            $id
        ]);


        $_SESSION['hostname_success'] =
            'Hostname reservation updated.';

        redirect_hostname();
    }


    /*
    |--------------------------------------------------------------------------
    | ADMIN CODE UPDATE
    |--------------------------------------------------------------------------
    */

    if (
        $form_action === 'update_code'
    ) {

        if (
            !$is_admin
        ) {

            http_response_code(403);

            exit(
                'Administrator privileges required.'
            );
        }


        $id =
            (int) (
                $_POST[
                    'code_id'
                ]
                ?? 0
            );


        $new_value =
            strtoupper(
                trim(
                    $_POST[
                        'code_value'
                    ]
                    ?? ''
                )
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM hostname_generator_codes
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);

        $code =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (
            !$code
        ) {

            $_SESSION['hostname_error'] =
                'Code not found.';

            redirect_hostname();
        }


        $required_length =
            $code['category'] === 'platform'
                ? 3
                : 1;


        $new_value =
            normalize_code(
                $new_value,
                $required_length
            );


        if (
            strlen(
                $new_value
            ) !== $required_length
        ) {

            $_SESSION['hostname_error'] =
                ucfirst(
                    $code['category']
                )
                .
                ' code must contain exactly '
                .
                $required_length
                .
                ' character(s).';

            redirect_hostname();
        }


        try {

            $stmt = $pdo->prepare("
                UPDATE hostname_generator_codes

                SET
                    code_value = ?,
                    updated_at = CURRENT_TIMESTAMP

                WHERE id = ?
            ");

            $stmt->execute([
                $new_value,
                $id
            ]);


            $_SESSION['hostname_success'] =
                'Hostname code updated.';

        } catch (
            PDOException $e
        ) {

            $_SESSION['hostname_error'] =
                'That code is already being used.';
        }


        redirect_hostname();
    }
}


/*
|--------------------------------------------------------------------------
| PROJECT SUGGESTIONS
|--------------------------------------------------------------------------
*/

$project_suggestions = $pdo->query("
    SELECT
        project_name,
        project_code,
        project_abbreviation
    FROM hostname_reservations
    WHERE project_name IS NOT NULL
      AND TRIM(project_name) <> ''
    GROUP BY
        project_name,
        project_code,
        project_abbreviation
    ORDER BY project_name
")->fetchAll(
    PDO::FETCH_ASSOC
);


/*
|--------------------------------------------------------------------------
| APPLICATION SUGGESTIONS
|--------------------------------------------------------------------------
*/

$application_suggestions = $pdo->query("
    SELECT
        application_name,
        application_abbreviation
    FROM hostname_reservations
    WHERE application_name IS NOT NULL
      AND TRIM(application_name) <> ''
    GROUP BY
        application_name,
        application_abbreviation
    ORDER BY application_name
")->fetchAll(
    PDO::FETCH_ASSOC
);


/*
|--------------------------------------------------------------------------
| SAVED RESERVATIONS
|--------------------------------------------------------------------------
*/

$hostname_sort_columns = [
    'hostname' =>
        'r.hostname',

    'project_name' =>
        'r.project_name',

    'application_name' =>
        'r.application_name',

    'status' =>
        'r.status',

    'created_at' =>
        'r.created_at',
];


$sort_by =
    $_GET['sort_by']
    ?? 'created_at';


if (
    !array_key_exists(
        $sort_by,
        $hostname_sort_columns
    )
) {
    $sort_by = 'created_at';
}


$sort_order =
    (
        strtoupper(
            $_GET['sort_order']
            ?? 'DESC'
        ) === 'ASC'
    )
        ? 'ASC'
        : 'DESC';


$order_column =
    $hostname_sort_columns[
        $sort_by
    ];


$keyword =
    trim(
        $_GET['keyword']
        ?? ''
    );


$reservation_where =
    '1=1';

$reservation_params = [];


if (
    $keyword !== ''
) {

    $reservation_where = "
        (
            r.hostname LIKE ?
            OR r.project_name LIKE ?
            OR r.project_code LIKE ?
            OR r.application_name LIKE ?
            OR r.status LIKE ?
        )
    ";

    $w =
        "%$keyword%";

    $reservation_params = [
        $w,
        $w,
        $w,
        $w,
        $w
    ];
}


$count_stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM hostname_reservations r
    WHERE $reservation_where
");

$count_stmt->execute(
    $reservation_params
);

$filtered_total =
    (int)
        $count_stmt->fetchColumn();


$page_size =
    resolveUserPageSize(
        $pdo,
        $current_user_id
    );


$current_page =
    max(
        1,
        (int) (
            $_GET['page']
            ?? 1
        )
    );


$total_pages =
    max(
        1,
        (int)
            ceil(
                $filtered_total /
                $page_size
            )
    );


if (
    $current_page > $total_pages
) {
    $current_page =
        $total_pages;
}


$offset =
    (
        $current_page - 1
    ) * $page_size;


$stmt = $pdo->prepare("
    SELECT
        r.*,

        u.first_name,
        u.last_name,
        u.email

    FROM hostname_reservations r

    LEFT JOIN users u
        ON u.id = r.generated_by

    WHERE $reservation_where

    ORDER BY
        $order_column $sort_order,
        r.id DESC

    LIMIT $page_size
    OFFSET $offset
");


$stmt->execute(
    $reservation_params
);


$reservations =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| PAGINATION PARAMETERS
|--------------------------------------------------------------------------
*/

$reservation_query_params =
    array_filter(
        [
            'keyword' =>
                $keyword,

            'sort_by' =>
                $sort_by,

            'sort_order' =>
                $sort_order,
        ],
        static fn($v) =>
            $v !== ''
    );


$reservation_hidden_fields =
    '';

foreach (
    $reservation_query_params
    as $fk => $fv
) {

    $reservation_hidden_fields .=
        '<input type="hidden" name="' .
        h($fk) .
        '" value="' .
        h($fv) .
        '">';
}


/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

$page_title =
    'Hostname Generator';


require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<style>

.hostname-page {
    padding-bottom:50px;
}

.hostname-header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:25px;
}

.hostname-header h1 {
    margin:0;
}

.hostname-header p {
    color:var(--text-secondary);
    margin:5px 0 0;
}

.hostname-card {
    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:12px;
    padding:24px;
    margin-bottom:22px;
}

.hostname-card h2 {
    margin-top:0;
    margin-bottom:18px;
}

.hostname-grid {
    display:grid;
    grid-template-columns:
        repeat(3,minmax(0,1fr));
    gap:18px;
}

.hostname-field {
    display:flex;
    flex-direction:column;
    gap:7px;
}

.hostname-field.full {
    grid-column:1/-1;
}

.hostname-field label {
    font-weight:600;
    font-size:14px;
}

.hostname-field input,
.hostname-field select {
    width:100%;
    box-sizing:border-box;
    border:1px solid #d1d5db;
    border-radius:7px;
    padding:10px 12px;
    font:inherit;
}

.hostname-field small {
    color:var(--text-secondary);
}

.hostname-subsection {
    border:1px solid var(--border-color);
    border-radius:10px;
    padding:18px;
    background:var(--hover-bg);
}

.hostname-subsection h3 {
    margin-top:0;
    margin-bottom:15px;
    font-size:16px;
}

.hostname-preview {
    margin-top:20px;
    background:#0f172a;
    color:#fff;
    border-radius:10px;
    padding:20px;
}

.hostname-preview-title {
    color:var(--text-muted);
    font-size:12px;
    text-transform:uppercase;
    margin-bottom:10px;
}

.hostname-preview-toolbar {
    display:flex;
    justify-content:flex-end;
    margin-bottom:10px;
}

.hostname-preview-list {
    display:flex;
    flex-direction:column;
    gap:8px;
    font-family:monospace;
    font-size:17px;
    font-weight:bold;
}

.hostname-preview-item {
    display:flex;
    align-items:center;
    gap:15px;
    padding:10px 12px;
    background:#1e293b;
    border-radius:6px;
}

.hostname-preview-item .hostname-text {
    flex:1;
}

.hostname-preview-item.available {
    color:#86efac;
}

.hostname-preview-item.exists {
    color:#fca5a5;
}

.hostname-preview-item.invalid {
    color:#fbbf24;
}

.hostname-component {
    color:#93c5fd;
    font-size:12px;
    margin-left:auto;
}

.hostname-copy-btn {
    border:1px solid #475569;
    background:#334155;
    color:#fff;
    border-radius:5px;
    padding:5px 9px;
    cursor:pointer;
    font-size:12px;
    font-weight:600;
}

.hostname-copy-btn:hover {
    background:#475569;
}

.hostname-copy-btn.copied {
    background:#059669;
    border-color:#059669;
}

.hostname-actions {
    display:flex;
    justify-content:flex-end;
    gap:10px;
    margin-top:20px;
}

.hostname-btn {
    border:0;
    border-radius:7px;
    padding:10px 16px;
    cursor:pointer;
    font-weight:600;
}

.hostname-btn-primary {
    background:#2563eb;
    color:#fff;
}

.hostname-btn-secondary {
    background:var(--border-color);
    color:var(--text-primary);
}

.hostname-btn-danger {
    background:#dc2626;
    color:#fff;
}

.hostname-btn-success {
    background:#059669;
    color:#fff;
}

.hostname-table-wrap {
    overflow-x:auto;
}

.hostname-table {
    width:100%;
    border-collapse:collapse;
}

.hostname-table th,
.hostname-table td {
    padding:11px;
    border-bottom:1px solid var(--border-color);
    text-align:left;
    vertical-align:middle;
}

.hostname-table th {
    font-size:12px;
    color:var(--text-secondary);
    text-transform:uppercase;
}

.hostname-value {
    font-family:monospace;
    font-weight:bold;
    color:#2563eb;
    white-space:nowrap;
}

.hostname-status {
    display:inline-block;
    padding:5px 9px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
    background:#ecfdf5;
    color:#047857;
}

.hostname-row-actions {
    display:flex;
    gap:8px;
    align-items:center;
}

.hostname-row-actions button {
    border:0;
    background:none;
    cursor:pointer;
    color:#2563eb;
    padding:0;
}

.hostname-row-actions .delete {
    color:#dc2626;
}

.hostname-row-actions .copy {
    color:#059669;
}

.hostname-alert {
    padding:12px 15px;
    border-radius:8px;
    margin-bottom:20px;
}

.hostname-alert.success {
    background:#ecfdf5;
    color:#047857;
    border:1px solid #a7f3d0;
}

.hostname-alert.error {
    background:#fef2f2;
    color:#b91c1c;
    border:1px solid #fecaca;
}

.hostname-code-table {
    width:100%;
    border-collapse:collapse;
}

.hostname-code-table th,
.hostname-code-table td {
    padding:10px;
    border-bottom:1px solid var(--border-color);
    text-align:left;
}

.hostname-code-input {
    width:90px;
    text-align:center;
    font-family:monospace;
    font-weight:bold;
    text-transform:uppercase;
    border:1px solid #d1d5db;
    border-radius:6px;
    padding:7px;
}

.hostname-section-title {
    margin-top:30px;
    margin-bottom:12px;
    font-size:18px;
}

.pagination {
    display:flex;
    justify-content:center;
    gap:6px;
    margin-top:20px;
    flex-wrap:wrap;
}

.edit-modal {
    display:none;
    position:fixed;
    inset:0;
    background:rgba(0,0,0,.55);
    z-index:9999;
    padding:30px;
    overflow:auto;
}

.edit-modal-content {
    background:var(--bg-content);
    max-width:650px;
    margin:50px auto;
    border-radius:12px;
    padding:25px;
}

@media(max-width:1000px) {

    .hostname-grid {
        grid-template-columns:
            repeat(2,minmax(0,1fr));
    }
}

@media(max-width:700px) {

    .hostname-grid {
        grid-template-columns:1fr;
    }

    .hostname-header {
        flex-direction:column;
        align-items:stretch;
    }

    .hostname-actions {
        flex-direction:column;
    }

    .hostname-btn {
        width:100%;
    }

    .hostname-preview-item {
        flex-wrap:wrap;
    }

    .hostname-component {
        margin-left:0;
    }

}

[data-theme="dark"] .hostname-field input,
[data-theme="dark"] .hostname-field select,
[data-theme="dark"] .hostname-code-input {
    background:var(--input-bg);
    color:var(--text-primary);
    border-color:var(--input-border);
}

[data-theme="dark"] .hostname-field input::placeholder {
    color:var(--text-muted);
}

[data-theme="dark"] .hostname-status {
    background:rgba(16,185,129,.15);
    color:#6EE7B7;
}

[data-theme="dark"] .hostname-alert.success {
    background:rgba(16,185,129,.12);
    color:#6EE7B7;
    border-color:rgba(16,185,129,.35);
}

[data-theme="dark"] .hostname-alert.error {
    background:rgba(239,68,68,.12);
    color:#FCA5A5;
    border-color:rgba(239,68,68,.35);
}

</style>


<div class="content hostname-page">


<?php if ($success_msg): ?>

    <div class="hostname-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="hostname-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<div class="hostname-header">

    <div>

        <h1>
            Hostname Generator
        </h1>

        <p>
            Generate, validate, copy and reserve infrastructure hostnames.
        </p>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| GENERATOR
|--------------------------------------------------------------------------
-->

<div class="hostname-card">

    <h2>
        Generate Hostnames
    </h2>


    <form
        id="hostnameGeneratorForm"
        method="POST"
        action="hostname.php"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= h($csrf_token) ?>"
        >

        <input
            type="hidden"
            name="form_action"
            value="save_reservations"
        >


        <div class="hostname-grid">


            <!-- PLATFORM -->

            <div class="hostname-field">

                <label>
                    Platform *
                </label>

                <select
                    id="platform_key"
                    name="platform_key"
                    required
                >

                    <option value="">
                        Select Platform
                    </option>

                    <?php foreach (
                        $platform_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >
                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>
                            —
                            <?= h(
                                $code['code_value']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

                <small>
                    Platform code is exactly 3 characters.
                </small>

            </div>


            <!-- ENVIRONMENT -->

            <div class="hostname-field">

                <label>
                    Environment *
                </label>

                <select
                    id="environment_key"
                    name="environment_key"
                    required
                >

                    <option value="">
                        Select Environment
                    </option>

                    <?php foreach (
                        $environment_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >
                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>
                            —
                            <?= h(
                                $code['code_value']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- OS -->

            <div class="hostname-field">

                <label>
                    Operating System *
                </label>

                <select
                    id="os_key"
                    name="os_key"
                    required
                >

                    <option value="">
                        Select OS
                    </option>

                    <?php foreach (
                        $os_codes
                        as $code
                    ): ?>

                        <option
                            value="<?= h(
                                $code['code_key']
                            ) ?>"
                        >
                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>
                            —
                            <?= h(
                                $code['code_value']
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <!-- TYPE -->

            <div class="hostname-field">

                <label>
                    Infrastructure Type *
                </label>

                <select
                    id="physical_virtual"
                    name="physical_virtual"
                    required
                >

                    <option value="">
                        Select
                    </option>

                    <option value="P">
                        Physical — P
                    </option>

                    <option value="V">
                        Virtual — V
                    </option>

                </select>

            </div>


            <!-- PROJECT NAME -->

            <div class="hostname-field">

                <label>
                    Project Name
                </label>

                <input
                    type="text"
                    id="project_name"
                    name="project_name"
                    list="projectSuggestions"
                    placeholder="Full project name"
                >

                <datalist id="projectSuggestions">

                    <?php foreach (
                        $project_suggestions
                        as $project
                    ): ?>

                        <option
                            value="<?= h(
                                $project[
                                    'project_name'
                                ]
                            ) ?>"
                        >

                    <?php endforeach; ?>

                </datalist>

            </div>


            <!-- PROJECT CODE -->

            <div class="hostname-field">

                <label>
                    Project Code
                </label>

                <input
                    type="text"
                    id="project_code"
                    name="project_code"
                    placeholder="Separate project code"
                >

                <small>
                    Stored separately from hostname abbreviation.
                </small>

            </div>


            <!-- PROJECT ABBREVIATION -->

            <div class="hostname-field">

                <label>
                    Project Abbreviation *
                </label>

                <input
                    type="text"
                    id="project_abbreviation"
                    name="project_abbreviation"
                    maxlength="3"
                    minlength="3"
                    pattern="[A-Za-z0-9]{3}"
                    required
                    placeholder="ABC"
                >

                <small>
                    Automatically generated from Project Name.
                </small>

            </div>

        </div>


        <!--
        |--------------------------------------------------------------------------
        | APPLICATION
        |--------------------------------------------------------------------------
        -->

        <div
            class="hostname-subsection"
            style="margin-top:22px;"
        >

            <h3>
                Application
            </h3>

            <div class="hostname-grid">


                <div class="hostname-field">

                    <label>
                        Application Name
                    </label>

                    <input
                        type="text"
                        id="application_name"
                        name="application_name"
                        list="applicationSuggestions"
                        placeholder="Application"
                    >

                    <datalist id="applicationSuggestions">

                        <?php foreach (
                            $application_suggestions
                            as $application
                        ): ?>

                            <option
                                value="<?= h(
                                    $application[
                                        'application_name'
                                    ]
                                ) ?>"
                            >

                        <?php endforeach; ?>

                    </datalist>

                </div>


                <div class="hostname-field">

                    <label>
                        Application Abbreviation *
                    </label>

                    <input
                        type="text"
                        id="application_abbreviation"
                        name="application_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        value="APP"
                        required
                    >

                    <small>
                        Automatically generated from Application Name.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        Number of APP
                    </label>

                    <input
                        type="number"
                        id="app_count"
                        name="app_count"
                        min="1"
                        max="99"
                        value="1"
                    >

                    <small>
                        Number of APP hostnames.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        Starting APP Node
                    </label>

                    <input
                        type="number"
                        id="starting_app_node"
                        name="starting_app_node"
                        min="1"
                        max="99"
                        value="1"
                    >

                    <small>
                        2 digits: 01, 02, 03...
                    </small>

                </div>

            </div>

        </div>


        <!--
        |--------------------------------------------------------------------------
        | DATABASE
        |--------------------------------------------------------------------------
        -->

        <div
            class="hostname-subsection"
            style="margin-top:18px;"
        >

            <h3>
                Database
            </h3>

            <div class="hostname-grid">


                <div class="hostname-field">

                    <label>
                        Number of DB
                    </label>

                    <input
                        type="number"
                        id="db_count"
                        name="db_count"
                        min="0"
                        max="99"
                        value="0"
                    >

                    <small>
                        Enter 0 if no database hostnames are required.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        DB Abbreviation
                    </label>

                    <input
                        type="text"
                        id="db_abbreviation"
                        name="db_abbreviation"
                        maxlength="3"
                        minlength="2"
                        pattern="[A-Za-z0-9]{2,3}"
                        value="DB"
                    >

                    <small>
                        Default: DB.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        Starting DB Node
                    </label>

                    <input
                        type="number"
                        id="starting_db_node"
                        name="starting_db_node"
                        min="1"
                        max="999"
                        value="1"
                    >

                    <small>
                        3 digits: 001, 002, 003...
                    </small>

                </div>

            </div>

        </div>


        <!--
        |--------------------------------------------------------------------------
        | WEB
        |--------------------------------------------------------------------------
        -->

        <div
            class="hostname-subsection"
            style="margin-top:18px;"
        >

            <h3>
                Web
            </h3>

            <div class="hostname-grid">


                <div class="hostname-field">

                    <label>
                        Number of WEB
                    </label>

                    <input
                        type="number"
                        id="web_count"
                        name="web_count"
                        min="0"
                        max="99"
                        value="0"
                    >

                    <small>
                        Enter 0 if no web hostnames are required.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        WEB Abbreviation
                    </label>

                    <input
                        type="text"
                        id="web_abbreviation"
                        name="web_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        value="WEB"
                    >

                    <small>
                        Default: WEB.
                    </small>

                </div>


                <div class="hostname-field">

                    <label>
                        Starting WEB Node
                    </label>

                    <input
                        type="number"
                        id="starting_web_node"
                        name="starting_web_node"
                        min="1"
                        max="99"
                        value="1"
                    >

                    <small>
                        2 digits: 01, 02, 03...
                    </small>

                </div>

            </div>

        </div>


        <!--
        |--------------------------------------------------------------------------
        | PREVIEW
        |--------------------------------------------------------------------------
        -->

        <div class="hostname-preview">

            <div class="hostname-preview-title">
                Generated Preview
            </div>

            <div
                class="hostname-preview-toolbar"
            >

                <button
                    type="button"
                    class="hostname-copy-btn"
                    id="copyAllButton"
                    style="display:none;"
                >
                    Copy All
                </button>

            </div>

            <div
                id="hostnamePreview"
                class="hostname-preview-list"
            >

                <div>
                    Select the required options.
                </div>

            </div>

        </div>


        <div class="hostname-actions">

            <button
                type="button"
                class="hostname-btn hostname-btn-secondary"
                id="generateButton"
            >
                Generate
            </button>

            <button
                type="button"
                class="hostname-btn hostname-btn-success"
                id="saveButton"
            >
                Save Reservations
            </button>

        </div>

    </form>

</div>


<!--
|--------------------------------------------------------------------------
| SAVED RESERVATIONS
|--------------------------------------------------------------------------
-->

<div class="hostname-card">

    <div
        style="
            display:flex;
            justify-content:space-between;
            align-items:center;
            flex-wrap:wrap;
            gap:10px;
        "
    >

        <h2>
            Reserved Hostnames
        </h2>

        <div
            style="
                display:flex;
                gap:8px;
                flex-wrap:wrap;
                align-items:center;
            "
        >

            <form
                method="GET"
                action="hostname.php"
                style="
                    display:flex;
                    gap:8px;
                "
            >

                <input
                    type="hidden"
                    name="sort_by"
                    value="<?= h($sort_by) ?>"
                >

                <input
                    type="hidden"
                    name="sort_order"
                    value="<?= h($sort_order) ?>"
                >

                <input
                    type="text"
                    name="keyword"
                    placeholder="Search hostname, project, application..."
                    value="<?= h($keyword) ?>"
                >

                <button
                    type="submit"
                    class="hostname-btn hostname-btn-secondary"
                >
                    Search
                </button>

            </form>


            <?php if ($keyword !== ''): ?>

                <a
                    href="hostname.php"
                    class="hostname-btn hostname-btn-secondary"
                >
                    Clear
                </a>

            <?php endif; ?>


            <?= pageSizeSelectorHtml(
                $page_size,
                $reservation_hidden_fields
            ) ?>

        </div>

    </div>


    <div class="hostname-table-wrap">

        <table class="hostname-table">

            <thead>

                <tr>

                    <th>Hostname</th>
                    <th>Platform</th>
                    <th>Environment</th>
                    <th>OS</th>
                    <th>Type</th>
                    <th>Project</th>
                    <th>Project Code</th>
                    <th>Application</th>
                    <th>Node</th>
                    <th>Status</th>
                    <th>Reserved By</th>
                    <th>Actions</th>

                </tr>

            </thead>

            <tbody>

            <?php if (!$reservations): ?>

                <tr>

                    <td
                        colspan="12"
                        style="
                            text-align:center;
                            padding:35px;
                        "
                    >

                        <?= $keyword !== ''
                            ? 'No hostname reservations match your search.'
                            : 'No hostname reservations yet.'
                        ?>

                    </td>

                </tr>

            <?php endif; ?>


            <?php foreach (
                $reservations
                as $reservation
            ): ?>

                <tr>

                    <td>

                        <span class="hostname-value">

                            <?= h(
                                $reservation[
                                    'hostname'
                                ]
                            ) ?>

                        </span>

                    </td>


                    <td>
                        <?= h(
                            $reservation[
                                'platform_code'
                            ]
                        ) ?>
                    </td>


                    <td>
                        <?= h(
                            $reservation[
                                'environment_code'
                            ]
                        ) ?>
                    </td>


                    <td>
                        <?= h(
                            $reservation[
                                'os_code'
                            ]
                        ) ?>
                    </td>


                    <td>
                        <?= h(
                            $reservation[
                                'physical_virtual'
                            ]
                        ) ?>
                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'project_name'
                            ] ?: '—'
                        ) ?>

                        <?php if (
                            $reservation[
                                'project_abbreviation'
                            ]
                        ): ?>

                            <br>

                            <small>

                                <?= h(
                                    $reservation[
                                        'project_abbreviation'
                                    ]
                                ) ?>

                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'project_code'
                            ] ?: '—'
                        ) ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'application_name'
                            ] ?: '—'
                        ) ?>

                        <?php if (
                            $reservation[
                                'application_abbreviation'
                            ]
                        ): ?>

                            <br>

                            <small>

                                <?= h(
                                    $reservation[
                                        'application_abbreviation'
                                    ]
                                ) ?>

                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        <?= h(
                            $reservation[
                                'node_number'
                            ]
                        ) ?>

                    </td>


                    <td>

                        <span
                            class="hostname-status"
                        >
                            <?= h(
                                $reservation[
                                    'status'
                                ]
                            ) ?>
                        </span>

                    </td>


                    <td>

                        <?= h(
                            trim(
                                ($reservation[
                                    'first_name'
                                ] ?? '')
                                . ' '
                                . ($reservation[
                                    'last_name'
                                ] ?? '')
                            )
                        ) ?>

                    </td>


                    <td>

                        <div
                            class="hostname-row-actions"
                        >

                            <button
                                type="button"
                                class="copy"
                                onclick="copyHostname(
                                    <?= htmlspecialchars(
                                        json_encode(
                                            $reservation[
                                                'hostname'
                                            ]
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>,
                                    this
                                )"
                            >
                                Copy
                            </button>


                            <?php if (
                                $is_admin ||
                                (int)
                                    $reservation[
                                        'generated_by'
                                    ] === $current_user_id
                            ): ?>

                                <button
                                    type="button"
                                    onclick='editReservation(
                                        <?= json_encode(
                                            $reservation,
                                            JSON_HEX_TAG |
                                            JSON_HEX_APOS |
                                            JSON_HEX_QUOT |
                                            JSON_HEX_AMP
                                        ) ?>
                                    )'
                                >
                                    Edit
                                </button>


                                <form
                                    method="POST"
                                    action="hostname.php"
                                    style="display:inline;"
                                    onsubmit="return confirm('Delete this hostname reservation?');"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h(
                                            $csrf_token
                                        ) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="form_action"
                                        value="delete_reservation"
                                    >

                                    <input
                                        type="hidden"
                                        name="reservation_id"
                                        value="<?= (int)
                                            $reservation['id']
                                        ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="delete"
                                    >
                                        Delete
                                    </button>

                                </form>

                            <?php endif; ?>

                        </div>

                    </td>

                </tr>

            <?php endforeach; ?>

            </tbody>

        </table>

    </div>


    <?php if (
        $total_pages > 1
    ): ?>

        <div class="pagination">

            <?php for (
                $p = 1;
                $p <= $total_pages;
                $p++
            ): ?>

                <a
                    href="hostname.php?<?= h(
                        http_build_query(
                            array_merge(
                                $reservation_query_params,
                                [
                                    'page' => $p
                                ]
                            )
                        )
                    ) ?>"
                    class="hostname-btn hostname-btn-secondary"
                    style="<?=
                        $p === $current_page
                            ? 'background:#2563eb;color:#fff;'
                            : ''
                    ?>"
                >
                    <?= $p ?>
                </a>

            <?php endfor; ?>

        </div>

    <?php endif; ?>


    <div
        style="
            text-align:center;
            color:var(--text-muted);
            font-size:12.5px;
            margin-top:10px;
        "
    >

        Showing
        <?= count($reservations) ?>
        of
        <?= $filtered_total ?>
        reservation<?= $filtered_total === 1 ? '' : 's' ?>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| ADMIN CODE MANAGEMENT
|--------------------------------------------------------------------------
-->

<?php if ($is_admin): ?>

<div class="hostname-card">

    <h2>
        Hostname Code Administration
    </h2>

    <p>
        Only administrators can modify these codes.
        Platform codes must be exactly 3 characters.
        Environment and OS codes must be exactly 1 character.
    </p>


    <?php
    $admin_code_sections = [
        [
            'title' => 'Platform Codes',
            'codes' => $platform_codes,
            'length' => 3
        ],
        [
            'title' => 'Environment Codes',
            'codes' => $environment_codes,
            'length' => 1
        ],
        [
            'title' => 'Operating System Codes',
            'codes' => $os_codes,
            'length' => 1
        ]
    ];
    ?>


    <?php foreach (
        $admin_code_sections
        as $section
    ): ?>

        <h3 class="hostname-section-title">
            <?= h($section['title']) ?>
        </h3>

        <div class="hostname-table-wrap">

            <table class="hostname-code-table">

                <thead>

                    <tr>
                        <th>Name</th>
                        <th>Code</th>
                        <th>Action</th>
                    </tr>

                </thead>

                <tbody>

                <?php foreach (
                    $section['codes']
                    as $code
                ): ?>

                    <tr>

                        <td>
                            <?= h(
                                ucwords(
                                    str_replace(
                                        '_',
                                        ' ',
                                        $code['code_key']
                                    )
                                )
                            ) ?>
                        </td>

                        <td>

                            <form
                                method="POST"
                                action="hostname.php"
                                style="
                                    display:flex;
                                    gap:8px;
                                "
                            >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= h(
                                        $csrf_token
                                    ) ?>"
                                >

                                <input
                                    type="hidden"
                                    name="form_action"
                                    value="update_code"
                                >

                                <input
                                    type="hidden"
                                    name="code_id"
                                    value="<?= (int)
                                        $code['id']
                                    ?>"
                                >

                                <input
                                    class="hostname-code-input"
                                    type="text"
                                    name="code_value"
                                    maxlength="<?= $section['length'] ?>"
                                    minlength="<?= $section['length'] ?>"
                                    pattern="[A-Za-z0-9]{<?= $section['length'] ?>}"
                                    value="<?= h(
                                        $code['code_value']
                                    ) ?>"
                                    required
                                >

                                <button
                                    type="submit"
                                    class="hostname-btn hostname-btn-primary"
                                >
                                    Save
                                </button>

                            </form>

                        </td>

                        <td>
                            Admin only
                        </td>

                    </tr>

                <?php endforeach; ?>

                </tbody>

            </table>

        </div>

    <?php endforeach; ?>

</div>

<?php endif; ?>


</div>


<!--
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
-->

<div
    id="editModal"
    class="edit-modal"
>

    <div class="edit-modal-content">

        <h2>
            Edit Hostname Reservation
        </h2>


        <form
            method="POST"
            action="hostname.php"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h(
                    $csrf_token
                ) ?>"
            >

            <input
                type="hidden"
                name="form_action"
                value="update_reservation"
            >

            <input
                type="hidden"
                name="reservation_id"
                id="edit_reservation_id"
            >


            <div class="hostname-grid">

                <div class="hostname-field full">

                    <label>
                        Hostname
                    </label>

                    <input
                        type="text"
                        id="edit_hostname"
                        readonly
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Name
                    </label>

                    <input
                        type="text"
                        name="project_name"
                        id="edit_project_name"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Code
                    </label>

                    <input
                        type="text"
                        name="project_code"
                        id="edit_project_code"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Project Abbreviation
                    </label>

                    <input
                        type="text"
                        name="project_abbreviation"
                        id="edit_project_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        required
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Application Name
                    </label>

                    <input
                        type="text"
                        name="application_name"
                        id="edit_application_name"
                    >

                </div>


                <div class="hostname-field">

                    <label>
                        Application Abbreviation
                    </label>

                    <input
                        type="text"
                        name="application_abbreviation"
                        id="edit_application_abbreviation"
                        maxlength="3"
                        minlength="3"
                        pattern="[A-Za-z0-9]{3}"
                        required
                    >

                </div>

            </div>


            <div class="hostname-actions">

                <button
                    type="button"
                    class="hostname-btn hostname-btn-secondary"
                    onclick="closeEditModal()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="hostname-btn hostname-btn-primary"
                >
                    Save Changes
                </button>

            </div>

        </form>

    </div>

</div>


<script>

/*
|--------------------------------------------------------------------------
| CODE DATA
|--------------------------------------------------------------------------
*/

const platformCodes =
    <?= json_encode(
        $platform_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;


const environmentCodes =
    <?= json_encode(
        $environment_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;


const osCodes =
    <?= json_encode(
        $os_codes,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;


/*
|--------------------------------------------------------------------------
| ELEMENTS
|--------------------------------------------------------------------------
*/

const platformSelect =
    document.getElementById(
        'platform_key'
    );

const environmentSelect =
    document.getElementById(
        'environment_key'
    );

const osSelect =
    document.getElementById(
        'os_key'
    );

const physicalVirtual =
    document.getElementById(
        'physical_virtual'
    );

const projectName =
    document.getElementById(
        'project_name'
    );

const projectAbbreviation =
    document.getElementById(
        'project_abbreviation'
    );

const applicationName =
    document.getElementById(
        'application_name'
    );

const applicationAbbreviation =
    document.getElementById(
        'application_abbreviation'
    );

const appCount =
    document.getElementById(
        'app_count'
    );

const startingAppNode =
    document.getElementById(
        'starting_app_node'
    );

const dbCount =
    document.getElementById(
        'db_count'
    );

const dbAbbreviation =
    document.getElementById(
        'db_abbreviation'
    );

const startingDbNode =
    document.getElementById(
        'starting_db_node'
    );

const webCount =
    document.getElementById(
        'web_count'
    );

const webAbbreviation =
    document.getElementById(
        'web_abbreviation'
    );

const startingWebNode =
    document.getElementById(
        'starting_web_node'
    );

const preview =
    document.getElementById(
        'hostnamePreview'
    );

const copyAllButton =
    document.getElementById(
        'copyAllButton'
    );


/*
|--------------------------------------------------------------------------
| GENERATED HOSTNAME ARRAY
|--------------------------------------------------------------------------
*/

let generatedHostnameList = [];


/*
|--------------------------------------------------------------------------
| MANUAL ABBREVIATION FLAGS
|--------------------------------------------------------------------------
*/

let projectAbbreviationManual =
    false;

let applicationAbbreviationManual =
    false;


/*
|--------------------------------------------------------------------------
| NORMALIZE CLIENT CODE
|--------------------------------------------------------------------------
*/

function normalizeClientCode(
    value,
    maxLength
) {

    return value
        .toUpperCase()
        .replace(
            /[^A-Z0-9]/g,
            ''
        )
        .substring(
            0,
            maxLength
        );
}


/*
|--------------------------------------------------------------------------
| PROJECT ABBREVIATION
|--------------------------------------------------------------------------
*/

projectAbbreviation.addEventListener(
    'input',
    function() {

        projectAbbreviationManual =
            true;

        this.value =
            normalizeClientCode(
                this.value,
                3
            );

        generatePreview();
    }
);


projectName.addEventListener(
    'input',
    function() {

        if (
            !projectAbbreviationManual
        ) {

            this.value =
                this.value;

            const generated =
                makeAbbreviation(
                    this.value
                );

            projectAbbreviation.value =
                generated;
        }

        generatePreview();
    }
);


/*
|--------------------------------------------------------------------------
| APPLICATION ABBREVIATION
|--------------------------------------------------------------------------
*/

applicationAbbreviation.addEventListener(
    'input',
    function() {

        applicationAbbreviationManual =
            true;

        this.value =
            normalizeClientCode(
                this.value,
                3
            );

        generatePreview();
    }
);


applicationName.addEventListener(
    'input',
    function() {

        if (
            !applicationAbbreviationManual
        ) {

            const generated =
                makeAbbreviation(
                    this.value
                );

            applicationAbbreviation.value =
                generated || 'APP';
        }

        generatePreview();
    }
);


/*
|--------------------------------------------------------------------------
| GENERATE ABBREVIATION
|--------------------------------------------------------------------------
*/

function makeAbbreviation(
    name
) {

    name =
        name.trim();

    if (
        !name
    ) {
        return '';
    }


    const words =
        name
            .split(/\s+/)
            .filter(Boolean);


    let result = '';


    words.forEach(
        function(word) {

            if (
                result.length >= 3
            ) {
                return;
            }

            word =
                word.replace(
                    /[^A-Za-z0-9]/g,
                    ''
                );

            if (word) {

                result +=
                    word
                        .charAt(0)
                        .toUpperCase();
            }
        }
    );


    const compact =
        name
            .replace(
                /[^A-Za-z0-9]/g,
                ''
            )
            .toUpperCase();


    for (
        let i = 0;
        i < compact.length &&
        result.length < 3;
        i++
    ) {

        result +=
            compact.charAt(i);
    }


    return result.substring(
        0,
        3
    );
}


/*
|--------------------------------------------------------------------------
| GET CODE
|--------------------------------------------------------------------------
*/

function getCode(
    collection,
    key
) {

    return collection.find(
        function(item) {

            return (
                item.code_key === key
            );
        }
    );
}


/*
|--------------------------------------------------------------------------
| BUILD CLIENT HOSTNAME
|--------------------------------------------------------------------------
*/

function buildClientHostname(
    platform,
    environment,
    os,
    pv,
    project,
    component,
    node,
    nodeLength
) {

    return (
        platform +
        environment +
        os +
        pv +
        project +
        component +
        String(node)
            .padStart(
                nodeLength,
                '0'
            )
    ).toUpperCase();
}


/*
|--------------------------------------------------------------------------
| COPY HOSTNAME
|--------------------------------------------------------------------------
*/

async function copyHostname(
    hostname,
    button = null
) {

    try {

        if (
            navigator.clipboard &&
            window.isSecureContext
        ) {

            await navigator.clipboard.writeText(
                hostname
            );

        } else {

            const textarea =
                document.createElement(
                    'textarea'
                );

            textarea.value =
                hostname;

            textarea.style.position =
                'fixed';

            textarea.style.left =
                '-9999px';

            document.body.appendChild(
                textarea
            );

            textarea.select();

            document.execCommand(
                'copy'
            );

            textarea.remove();
        }


        if (button) {

            const originalText =
                button.textContent;

            button.textContent =
                'Copied!';

            button.classList.add(
                'copied'
            );

            setTimeout(
                function() {

                    button.textContent =
                        originalText;

                    button.classList.remove(
                        'copied'
                    );

                },
                1200
            );
        }

    } catch (
        error
    ) {

        alert(
            'Unable to copy hostname.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| COPY ALL
|--------------------------------------------------------------------------
*/

copyAllButton.addEventListener(
    'click',
    async function() {

        if (
            !generatedHostnameList.length
        ) {
            return;
        }

        const text =
            generatedHostnameList.join(
                '\n'
            );

        try {

            if (
                navigator.clipboard &&
                window.isSecureContext
            ) {

                await navigator.clipboard.writeText(
                    text
                );

            } else {

                const textarea =
                    document.createElement(
                        'textarea'
                    );

                textarea.value =
                    text;

                textarea.style.position =
                    'fixed';

                textarea.style.left =
                    '-9999px';

                document.body.appendChild(
                    textarea
                );

                textarea.select();

                document.execCommand(
                    'copy'
                );

                textarea.remove();
            }


            const originalText =
                this.textContent;

            this.textContent =
                'Copied All!';

            this.classList.add(
                'copied'
            );

            setTimeout(
                () => {

                    this.textContent =
                        originalText;

                    this.classList.remove(
                        'copied'
                    );

                },
                1200
            );

        } catch (
            error
        ) {

            alert(
                'Unable to copy hostnames.'
            );
        }
    }
);


/*
|--------------------------------------------------------------------------
| ADD PREVIEW ROW
|--------------------------------------------------------------------------
*/

function addPreviewRow(
    hostname,
    component,
    node,
    nodeLength,
    type
) {

    generatedHostnameList.push(
        hostname
    );


    const row =
        document.createElement(
            'div'
        );

    row.className =
        'hostname-preview-item available';


    const hostnameSpan =
        document.createElement(
            'span'
        );

    hostnameSpan.className =
        'hostname-text';

    hostnameSpan.textContent =
        hostname;


    const info =
        document.createElement(
            'span'
        );

    info.className =
        'hostname-component';

    info.textContent =
        type +
        ' / ' +
        component +
        String(node)
            .padStart(
                nodeLength,
                '0'
            );


    const copyButton =
        document.createElement(
            'button'
        );

    copyButton.type =
        'button';

    copyButton.className =
        'hostname-copy-btn';

    copyButton.textContent =
        'Copy';


    copyButton.addEventListener(
        'click',
        function() {

            copyHostname(
                hostname,
                copyButton
            );
        }
    );


    row.appendChild(
        hostnameSpan
    );

    row.appendChild(
        info
    );

    row.appendChild(
        copyButton
    );


    preview.appendChild(
        row
    );
}


/*
|--------------------------------------------------------------------------
| GENERATE PREVIEW
|--------------------------------------------------------------------------
*/

function generatePreview() {

    preview.innerHTML = '';

    generatedHostnameList = [];

    copyAllButton.style.display =
        'none';


    const platform =
        getCode(
            platformCodes,
            platformSelect.value
        );

    const environment =
        getCode(
            environmentCodes,
            environmentSelect.value
        );

    const os =
        getCode(
            osCodes,
            osSelect.value
        );


    const pv =
        physicalVirtual.value;


    const project =
        projectAbbreviation.value
            .toUpperCase();


    const app =
        applicationAbbreviation.value
            .toUpperCase();


    const db =
        dbAbbreviation.value
            .toUpperCase();


    const web =
        webAbbreviation.value
            .toUpperCase();


    const appTotal =
        Math.max(
            1,
            parseInt(
                appCount.value
            ) || 1
        );


    const appStart =
        Math.max(
            1,
            parseInt(
                startingAppNode.value
            ) || 1
        );


    const dbStart =
        Math.max(
            1,
            parseInt(
                startingDbNode.value
            ) || 1
        );


    const webStart =
        Math.max(
            1,
            parseInt(
                startingWebNode.value
            ) || 1
        );


    const dbTotal =
        Math.max(
            0,
            parseInt(
                dbCount.value
            ) || 0
        );


    const webTotal =
        Math.max(
            0,
            parseInt(
                webCount.value
            ) || 0
        );


    /*
    |--------------------------------------------------------------------------
    | REQUIRED FIELDS
    |--------------------------------------------------------------------------
    */

    if (
        !platform ||
        !environment ||
        !os ||
        !pv ||
        project.length !== 3 ||
        app.length !== 3
    ) {

        preview.innerHTML =
            '<div>Select Platform, Environment, OS, Type, Project Abbreviation and Application Abbreviation.</div>';

        return;
    }


    /*
    |--------------------------------------------------------------------------
    | TOTAL
    |--------------------------------------------------------------------------
    */

    const total =
        appTotal +
        dbTotal +
        webTotal;


    if (
        total > 100
    ) {

        preview.innerHTML =
            '<div style="color:#fca5a5;">Maximum 100 hostnames per generation.</div>';

        return;
    }


    /*
    |--------------------------------------------------------------------------
    | APP
    |--------------------------------------------------------------------------
    */

    if (
        appStart +
        appTotal -
        1 > 99
    ) {

        preview.innerHTML =
            '<div style="color:#fca5a5;">APP node number cannot exceed 99.</div>';

        return;
    }


    for (
        let i = 0;
        i < appTotal;
        i++
    ) {

        const node =
            appStart + i;

        const hostname =
            buildClientHostname(
                platform.code_value,
                environment.code_value,
                os.code_value,
                pv,
                project,
                app,
                node,
                2
            );

        addPreviewRow(
            hostname,
            app,
            node,
            2,
            'APP'
        );
    }


    /*
    |--------------------------------------------------------------------------
    | DB
    |--------------------------------------------------------------------------
    */

    if (
        dbTotal > 0
    ) {

        if (
            db.length < 2 ||
            db.length > 3
        ) {

            preview.innerHTML =
                '<div style="color:#fca5a5;">DB abbreviation must contain 2 or 3 characters.</div>';

            generatedHostnameList = [];

            return;
        }


        if (
            dbStart +
            dbTotal -
            1 > 999
        ) {

            preview.innerHTML =
                '<div style="color:#fca5a5;">DB node number cannot exceed 999.</div>';

            generatedHostnameList = [];

            return;
        }


        for (
            let i = 0;
            i < dbTotal;
            i++
        ) {

            const node =
                dbStart + i;

            const hostname =
                buildClientHostname(
                    platform.code_value,
                    environment.code_value,
                    os.code_value,
                    pv,
                    project,
                    db,
                    node,
                    3
                );

            addPreviewRow(
                hostname,
                db,
                node,
                3,
                'DB'
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | WEB
    |--------------------------------------------------------------------------
    */

    if (
        webTotal > 0
    ) {

        if (
            web.length !== 3
        ) {

            preview.innerHTML =
                '<div style="color:#fca5a5;">WEB abbreviation must contain exactly 3 characters.</div>';

            generatedHostnameList = [];

            return;
        }


        if (
            webStart +
            webTotal -
            1 > 99
        ) {

            preview.innerHTML =
                '<div style="color:#fca5a5;">WEB node number cannot exceed 99.</div>';

            generatedHostnameList = [];

            return;
        }


        for (
            let i = 0;
            i < webTotal;
            i++
        ) {

            const node =
                webStart + i;

            const hostname =
                buildClientHostname(
                    platform.code_value,
                    environment.code_value,
                    os.code_value,
                    pv,
                    project,
                    web,
                    node,
                    2
                );

            addPreviewRow(
                hostname,
                web,
                node,
                2,
                'WEB'
            );
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SHOW COPY ALL
    |--------------------------------------------------------------------------
    */

    if (
        generatedHostnameList.length
    ) {

        copyAllButton.style.display =
            'inline-block';
    }
}


/*
|--------------------------------------------------------------------------
| GENERATE BUTTON
|--------------------------------------------------------------------------
*/

document
    .getElementById(
        'generateButton'
    )
    .addEventListener(
        'click',
        generatePreview
    );


/*
|--------------------------------------------------------------------------
| SAVE BUTTON
|--------------------------------------------------------------------------
*/

document
    .getElementById(
        'saveButton'
    )
    .addEventListener(
        'click',
        function() {

            generatePreview();


            if (
                !generatedHostnameList.length
            ) {

                alert(
                    'Please complete the required fields and generate at least one hostname.'
                );

                return;
            }


            if (
                projectAbbreviation.value.length !== 3
            ) {

                alert(
                    'Project abbreviation must be exactly 3 characters.'
                );

                return;
            }


            if (
                applicationAbbreviation.value.length !== 3
            ) {

                alert(
                    'Application abbreviation must be exactly 3 characters.'
                );

                return;
            }


            const dbTotal =
                parseInt(
                    dbCount.value
                ) || 0;


            if (
                dbTotal > 0 &&
                (
                    dbAbbreviation.value.length < 2 ||
                    dbAbbreviation.value.length > 3
                )
            ) {

                alert(
                    'DB abbreviation must contain 2 or 3 characters.'
                );

                return;
            }


            const webTotal =
                parseInt(
                    webCount.value
                ) || 0;


            if (
                webTotal > 0 &&
                webAbbreviation.value.length !== 3
            ) {

                alert(
                    'WEB abbreviation must be exactly 3 characters.'
                );

                return;
            }


            if (
                generatedHostnameList.length > 100
            ) {

                alert(
                    'Maximum 100 hostnames per generation.'
                );

                return;
            }


            if (
                !confirm(
                    'Save all generated hostnames as reservations?'
                )
            ) {
                return;
            }


            document
                .getElementById(
                    'hostnameGeneratorForm'
                )
                .submit();
        }
    );


/*
|--------------------------------------------------------------------------
| LIVE PREVIEW
|--------------------------------------------------------------------------
*/

[
    platformSelect,
    environmentSelect,
    osSelect,
    physicalVirtual,
    projectName,
    projectAbbreviation,
    applicationName,
    applicationAbbreviation,
    appCount,
    startingAppNode,
    dbCount,
    dbAbbreviation,
    startingDbNode,
    webCount,
    webAbbreviation,
    startingWebNode
]
.forEach(
    function(element) {

        element.addEventListener(
            'change',
            generatePreview
        );

        element.addEventListener(
            'input',
            generatePreview
        );
    }
);


/*
|--------------------------------------------------------------------------
| EDIT RESERVATION
|--------------------------------------------------------------------------
*/

function editReservation(
    reservation
) {

    document
        .getElementById(
            'edit_reservation_id'
        )
        .value =
        reservation.id;


    document
        .getElementById(
            'edit_hostname'
        )
        .value =
        reservation.hostname;


    document
        .getElementById(
            'edit_project_name'
        )
        .value =
        reservation.project_name || '';


    document
        .getElementById(
            'edit_project_code'
        )
        .value =
        reservation.project_code || '';


    document
        .getElementById(
            'edit_project_abbreviation'
        )
        .value =
        reservation.project_abbreviation || '';


    document
        .getElementById(
            'edit_application_name'
        )
        .value =
        reservation.application_name || '';


    document
        .getElementById(
            'edit_application_abbreviation'
        )
        .value =
        reservation.application_abbreviation || '';


    document
        .getElementById(
            'editModal'
        )
        .style.display =
        'block';
}


function closeEditModal() {

    document
        .getElementById(
            'editModal'
        )
        .style.display =
        'none';
}


/*
|--------------------------------------------------------------------------
| CLOSE MODAL ON BACKDROP
|--------------------------------------------------------------------------
*/

document
    .getElementById(
        'editModal'
    )
    .addEventListener(
        'click',
        function(event) {

            if (
                event.target === this
            ) {

                closeEditModal();
            }
        }
    );


/*
|--------------------------------------------------------------------------
| ESCAPE KEY
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'keydown',
    function(event) {

        if (
            event.key === 'Escape'
        ) {

            closeEditModal();
        }
    }
);


/*
|--------------------------------------------------------------------------
| INITIAL PREVIEW
|--------------------------------------------------------------------------
*/

generatePreview();

</script>


<?php

require_once 'includes/footer.php';

?>
