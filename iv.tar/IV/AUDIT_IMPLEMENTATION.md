# Audit/History Tracking Implementation

## Overview
Comprehensive audit/history tracking has been implemented for four key modules:
- **Reminders** (reminders.php)
- **Sticky Notes** (reminders.php)
- **Communications/Notifications** (notification.php)
- **My Data** (mydata.php)

## Database Schema Changes

### New Audit Tables Created

#### 1. reminder_audit
```sql
CREATE TABLE reminder_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    reminder_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    performed_by_id INTEGER,
    user_name TEXT NOT NULL,
    action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY(reminder_id) REFERENCES reminders(id) ON DELETE CASCADE
)
```

#### 2. sticky_note_audit
```sql
CREATE TABLE sticky_note_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sticky_note_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    performed_by_id INTEGER,
    user_name TEXT NOT NULL,
    action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY(sticky_note_id) REFERENCES sticky_notes(id) ON DELETE CASCADE
)
```

#### 3. communication_audit
```sql
CREATE TABLE communication_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    communication_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    performed_by_id INTEGER,
    user_name TEXT NOT NULL,
    action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY(communication_id) REFERENCES communications(id) ON DELETE CASCADE
)
```

#### 4. mydata_audit
```sql
CREATE TABLE mydata_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    mydata_id INTEGER NOT NULL,
    action TEXT NOT NULL,
    performed_by_id INTEGER,
    user_name TEXT NOT NULL,
    action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    details TEXT,
    FOREIGN KEY(mydata_id) REFERENCES my_data(id) ON DELETE CASCADE
)
```

## Tracked Actions

### Reminders Module
- **CREATED** - When a new reminder is created
- **UPDATED** - When a reminder is modified (title, message, date, visibility, etc.)
- **DELETED** - When a reminder is deleted
- **VISIBILITY_CHANGED** - When visibility settings change (future enhancement)

### Sticky Notes Module
- **CREATED** - When a new sticky note is created
- **UPDATED** - When a sticky note content or visibility is modified
- **DELETED** - When a sticky note is deleted

### Communications Module
- **CREATED** - When a new communication/note is created
- **UPDATED** - When a communication is modified
- **STATUS_CHANGED** - When a communication status changes (e.g., marked as Completed)
- **DELETED** - When a communication is deleted

### My Data Module
- **CREATED** - When new data is shared/created
- **UPDATED** - When data is modified (title, description, visibility, etc.)
- **DELETED** - When data is deleted

## Implementation Details

### Files Modified

1. **config/schema/reminders.php**
   - Added reminder_audit and sticky_note_audit tables

2. **config/schema/communications.php**
   - Added communication_audit table

3. **config/schema/mydata.php**
   - Added mydata_audit table

4. **includes/audit_helpers.php** (NEW)
   - Central location for all audit-related helper functions
   - Functions: logReminderAudit(), logStickyNoteAudit(), logCommunicationAudit(), logMydataAudit()
   - Functions: getReminderAuditHistory(), getStickyNoteAuditHistory(), getCommunicationAuditHistory(), getMydataAuditHistory()
   - Function: canAudit() - checks if user has audit permission
   - Function: formatAuditEntry() - formats audit entries for display

5. **reminders.php**
   - Added audit logging to save_reminder, edit_reminder, delete_reminder actions
   - Added audit logging to save_note, delete_note actions
   - Added AJAX endpoint for fetching audit history
   - Added History buttons (⏱) to reminder rows and sticky note cards (visible only with can_audit permission)
   - Added audit history modal dialog

6. **notification.php**
   - Added audit logging to create, update, complete, and delete actions
   - Added AJAX endpoint for fetching audit history

7. **mydata.php**
   - Added audit logging to save_data and delete_data actions
   - Added AJAX endpoint for fetching audit history

## Permission System

### Integration with Existing Permissions
The implementation uses the existing `can_audit` permission in the permissions table:

```sql
SELECT can_audit FROM permissions 
WHERE role = ? AND page_key = ?
```

### How It Works
- **Admins**: Always have audit access (no permission check needed)
- **Other Users**: Must have `can_audit` permission set to 1 for the specific module
- Module keys: `reminder`, `sticky_note`, `communication`, `mydata`

### Setting Permissions
To grant audit access to a role, insert/update the permissions table:

```sql
INSERT INTO permissions (role, page_key, can_audit) 
VALUES ('Manager', 'reminder', 1);
```

## UI Components

### History Button
- Located in action columns for reminders and sticky notes
- Shows as "⏱ History" button
- Only visible to users with `can_audit` permission for that module
- Clicking opens the audit history modal

### Audit History Modal
- Displays in a centered modal dialog
- Shows table with columns:
  - **Action**: The action performed (CREATED, UPDATED, DELETED, etc.)
  - **Performed By**: Name of the user who performed the action
  - **Date/Time**: Formatted date and time of the action
  - **Details**: Additional context (e.g., field values that were changed)
- Entries sorted by date (newest first)
- Close button (✕) and click outside to close

## API Endpoints

### Reminders Module
```
POST /reminders.php
action=get_audit_history
type=reminder|sticky_note
id={id}
```

### Communications Module
```
POST /notification.php
action=get_audit_history
id={id}
```

### My Data Module
```
POST /mydata.php
form_action=get_audit_history
data_id={id}
```

## Audit Entry Format

Each audit entry captures:
- **record_id**: ID of the reminder/note/communication/mydata record
- **action**: Type of action (CREATED, UPDATED, DELETED, STATUS_CHANGED)
- **performed_by_id**: Database ID of the user who performed the action
- **user_name**: Display name of the user (first_name or email fallback)
- **action_date**: Timestamp when the action occurred
- **details**: Optional additional context (e.g., what was changed, field values)

## Audit Log Entry Examples

```
John Smith CREATED on 2026-08-25 at 14:30:00 (Title: Server Maintenance)
Jane Doe UPDATED on 2026-08-25 at 15:45:00 (Title: Weekly Status Report)
Admin DELETED on 2026-08-25 at 16:20:00 (Reminder ID: 42)
Bob Wilson STATUS_CHANGED on 2026-08-25 at 17:10:00 (Status changed to Completed)
```

## Features & Security

### Data Protection
- Audit entries cannot be modified (only records are audited, not changes to audit logs)
- Deleted records can still be tracked via their audit history
- Foreign key cascades ensure audit records are cleaned up when main records are deleted

### Privacy
- History visibility is controlled by `can_audit` permission
- Users without permission cannot see history buttons or access audit data
- Each module has independent permission control

### Performance
- Audit logging is non-blocking (errors logged silently, don't break main operation)
- Query optimization through proper indexes
- Efficient JSON responses for AJAX calls

## Testing the Implementation

### Manual Testing Steps

1. **Create a Reminder/Note/Communication/Data item**
   - Verify "CREATED" entry appears in audit history
   - Check user_name and details are correct

2. **Edit the item**
   - Verify "UPDATED" entry appears
   - Check that details show what was changed

3. **Delete the item**
   - Verify "DELETED" entry appears
   - Item may be gone but audit trail remains

4. **Check Permissions**
   - Test as user without can_audit permission
   - History button should not appear
   - Attempting to access via API should return permission error

5. **Status Changes** (Communications only)
   - Mark task as completed
   - Verify "STATUS_CHANGED" entry in audit log

## Future Enhancements

1. **Content Diffing**: Track what specifically changed (field-level changes)
2. **Bulk Operations**: Log bulk audit operations
3. **Export**: Export audit logs to CSV/Excel
4. **Filtering**: Filter audit history by date range, action type, user
5. **Retention Policy**: Automatic cleanup of old audit entries
6. **Real-time Updates**: Live audit feed for admin dashboard
7. **Visibility Changes**: Separate logging for visibility permission changes

## Troubleshooting

### Issue: History buttons not showing
**Solution**: Check that user has `can_audit` permission for that module in the permissions table

### Issue: Audit entries not being logged
**Solution**: 
1. Verify audit tables were created (check database schema)
2. Check PHP error logs for any audit logging errors
3. Ensure config/db.php is loaded before audit_helpers.php

### Issue: Permission denied when viewing history
**Solution**: User needs explicit `can_audit=1` permission for the module (admins are exempt)

## Database Indexes (Recommended)

For optimal performance with large audit tables, consider adding indexes:

```sql
CREATE INDEX idx_reminder_audit_reminder_id ON reminder_audit(reminder_id);
CREATE INDEX idx_reminder_audit_date ON reminder_audit(action_date DESC);
CREATE INDEX idx_sticky_note_audit_note_id ON sticky_note_audit(sticky_note_id);
CREATE INDEX idx_sticky_note_audit_date ON sticky_note_audit(action_date DESC);
CREATE INDEX idx_communication_audit_comm_id ON communication_audit(communication_id);
CREATE INDEX idx_communication_audit_date ON communication_audit(action_date DESC);
CREATE INDEX idx_mydata_audit_data_id ON mydata_audit(mydata_id);
CREATE INDEX idx_mydata_audit_date ON mydata_audit(action_date DESC);
```

## Maintenance

### Audit Log Retention
Currently, audit logs are kept indefinitely. If storage becomes a concern, implement a retention policy:

```php
// Delete audit entries older than 1 year (example)
$pdo->exec("DELETE FROM reminder_audit WHERE action_date < datetime('now', '-1 year')");
```

### Database Optimization
Periodically run VACUUM on the database to reclaim space:

```php
$pdo->exec("VACUUM");
```
