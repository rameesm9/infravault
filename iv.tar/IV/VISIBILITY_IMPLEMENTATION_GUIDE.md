# Granular Visibility Implementation Guide

## Quick Reference

### Visibility Types
| Type | Description | Storage |
|------|-------------|---------|
| private | Only owner | No join table entries |
| public | Everyone | No join table entries |
| team | Selected teams | {table}_teams join table |
| user | Selected users | {table}_users join table |

## Step-by-Step Implementation for Other Modules

### Phase 1: Database Schema Updates

#### 1.1 Update the main table
Add visibility column if not present:
```sql
ALTER TABLE your_table ADD COLUMN visibility TEXT DEFAULT 'private';
```

#### 1.2 Create join tables
```php
// In config/schema/your_schema.php

$pdo->exec("
    CREATE TABLE IF NOT EXISTS your_table_teams (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        your_table_id INTEGER NOT NULL,
        team_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(your_table_id) REFERENCES your_table(id) ON DELETE CASCADE,
        UNIQUE(your_table_id, team_name)
    )
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS your_table_users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        your_table_id INTEGER NOT NULL,
        user_id INTEGER NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY(your_table_id) REFERENCES your_table(id) ON DELETE CASCADE,
        UNIQUE(your_table_id, user_id)
    )
");
```

### Phase 2: Backend Helper Functions (in your_module.php)

```php
// Add these functions to your module

function canViewRecord($record, $current_user_id, $current_user_team, $role, $pdo)
{
    if(strtolower($role) === 'admin') return true;
    if((int)$record['user_id'] === (int)$current_user_id) return true;
    
    $visibility = strtolower($record['visibility'] ?? 'private');
    
    if($visibility === 'public') return true;
    if($visibility === 'private') return false;
    
    if($visibility === 'team' && !empty($current_user_team)) {
        $stmt = $pdo->prepare("
            SELECT 1 FROM your_table_teams 
            WHERE your_table_id=? AND team_name=? LIMIT 1
        ");
        $stmt->execute([$record['id'], $current_user_team]);
        if($stmt->fetch()) return true;
    }
    
    if($visibility === 'user') {
        $stmt = $pdo->prepare("
            SELECT 1 FROM your_table_users 
            WHERE your_table_id=? AND user_id=? LIMIT 1
        ");
        $stmt->execute([$record['id'], $current_user_id]);
        if($stmt->fetch()) return true;
    }
    
    return false;
}

function getUniqueTeams($pdo)
{
    $stmt = $pdo->query("
        SELECT DISTINCT team FROM users 
        WHERE team IS NOT NULL AND team != '' 
        ORDER BY team ASC
    ");
    return $stmt->fetchAll(PDO::FETCH_COLUMN);
}

function getAllUsers($pdo)
{
    $stmt = $pdo->query("
        SELECT id, first_name, last_name, email FROM users 
        ORDER BY first_name, last_name ASC
    ");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getVisibilityDisplay($visibility, $id, $type, $pdo)
{
    $visibility = strtolower($visibility);
    
    if($visibility === 'public') {
        return '<span class="status-all">Everyone</span>';
    }
    if($visibility === 'private') {
        return '<span class="status-private">Private</span>';
    }
    if($visibility === 'team') {
        $stmt = $pdo->prepare("
            SELECT GROUP_CONCAT(team_name, ', ') as teams 
            FROM your_table_teams WHERE your_table_id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $teams = $result['teams'] ?? '';
        return '<span class="status-team" title="' . htmlspecialchars($teams) . '">Team (' . count(explode(',', $teams)) . ')</span>';
    }
    if($visibility === 'user') {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) as count FROM your_table_users WHERE your_table_id = ?
        ");
        $stmt->execute([$id]);
        $result = $stmt->fetch(PDO::FETCH_ASSOC);
        $count = $result['count'] ?? 0;
        return '<span class="status-user">Users (' . $count . ')</span>';
    }
    
    return '<span class="status-private">Unknown</span>';
}
```

### Phase 3: POST Handler Updates

#### 3.1 Create/Save Handler
```php
if($action === 'save_record'){
    // ... validation code ...
    
    $visibility = $_POST['visibility'] ?? 'private';
    $selected_teams = $_POST['teams'] ?? [];
    $selected_users = $_POST['users'] ?? [];
    
    if(!is_array($selected_teams)) $selected_teams = [];
    if(!is_array($selected_users)) $selected_users = [];
    
    try{
        $pdo->beginTransaction();
        
        // Insert main record
        $stmt = $pdo->prepare("
            INSERT INTO your_table (user_id, name, visibility) 
            VALUES(?, ?, ?)
        ");
        $stmt->execute([$current_user_id, $name, $visibility]);
        $record_id = $pdo->lastInsertId();
        
        // Save team associations
        if($visibility === 'team' && !empty($selected_teams)) {
            $team_stmt = $pdo->prepare("
                INSERT INTO your_table_teams (your_table_id, team_name) 
                VALUES (?, ?)
            ");
            foreach($selected_teams as $team) {
                $team = trim($team);
                if(!empty($team)) {
                    $team_stmt->execute([$record_id, $team]);
                }
            }
        }
        
        // Save user associations
        if($visibility === 'user' && !empty($selected_users)) {
            $user_stmt = $pdo->prepare("
                INSERT INTO your_table_users (your_table_id, user_id) 
                VALUES (?, ?)
            ");
            foreach($selected_users as $user_id) {
                $user_id = (int)$user_id;
                if($user_id > 0) {
                    $user_stmt->execute([$record_id, $user_id]);
                }
            }
        }
        
        $pdo->commit();
        // ... success handling ...
    }
    catch(Exception $e){
        if($pdo->inTransaction()) $pdo->rollBack();
        // ... error handling ...
    }
}
```

#### 3.2 Update Handler
```php
if($action === 'edit_record'){
    $record_id = (int)$_POST['record_id'];
    $visibility = $_POST['visibility'] ?? 'private';
    $selected_teams = $_POST['teams'] ?? [];
    $selected_users = $_POST['users'] ?? [];
    
    try{
        $pdo->beginTransaction();
        
        // Update main record
        $stmt = $pdo->prepare("
            UPDATE your_table SET visibility=?, name=? 
            WHERE id=? AND (user_id=? OR LOWER(?)='admin')
        ");
        $stmt->execute([$visibility, $name, $record_id, $current_user_id, $role]);
        
        // Clear existing associations
        $pdo->prepare("DELETE FROM your_table_teams WHERE your_table_id=?")->execute([$record_id]);
        $pdo->prepare("DELETE FROM your_table_users WHERE your_table_id=?")->execute([$record_id]);
        
        // Save new associations (same as create handler)
        // ... team saving code ...
        // ... user saving code ...
        
        $pdo->commit();
    }
    catch(Exception $e){
        if($pdo->inTransaction()) $pdo->rollBack();
    }
}
```

#### 3.3 Delete Handler
```php
if($action === 'delete_record'){
    $record_id = (int)$_POST['record_id'];
    
    try{
        $pdo->beginTransaction();
        
        $stmt = $pdo->prepare("
            DELETE FROM your_table 
            WHERE id=? AND (user_id=? OR LOWER(?)='admin')
        ");
        $stmt->execute([$record_id, $current_user_id, $role]);
        
        // Delete associations (or rely on cascade)
        $pdo->prepare("DELETE FROM your_table_teams WHERE your_table_id=?")->execute([$record_id]);
        $pdo->prepare("DELETE FROM your_table_users WHERE your_table_id=?")->execute([$record_id]);
        
        $pdo->commit();
    }
    catch(Exception $e){
        if($pdo->inTransaction()) $pdo->rollBack();
    }
}
```

### Phase 4: SELECT Query Updates

#### 4.1 Fetch Records
```php
// Fetch all records (no filtering in SQL)
$stmt = $pdo->query("
    SELECT r.*, u.first_name, u.email 
    FROM your_table r
    LEFT JOIN users u ON r.user_id = u.id
    ORDER BY r.created_at DESC
");

$all_records = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter in PHP using helper function
$records = array_filter($all_records, function($record) 
    use ($current_user_id, $current_user_team, $role, $pdo) {
    return canViewRecord($record, $current_user_id, $current_user_team, $role, $pdo);
});
```

#### 4.2 Load for Edit
```php
if(isset($_GET['edit'])){
    $stmt = $pdo->prepare("SELECT * FROM your_table WHERE id=?");
    $stmt->execute([$_GET['edit']]);
    $edit_record = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if($edit_record) {
        // Load associated teams
        $team_stmt = $pdo->prepare("SELECT team_name FROM your_table_teams WHERE your_table_id=?");
        $team_stmt->execute([$edit_record['id']]);
        $edit_teams = $team_stmt->fetchAll(PDO::FETCH_COLUMN);
        
        // Load associated users
        $user_stmt = $pdo->prepare("SELECT user_id FROM your_table_users WHERE your_table_id=?");
        $user_stmt->execute([$edit_record['id']]);
        $edit_users = $user_stmt->fetchAll(PDO::FETCH_COLUMN);
    }
}
```

### Phase 5: UI Updates

#### 5.1 Add Visibility Selector
Replace any existing visibility dropdown with:
```html
<div class="form-group">
    <label>Visibility</label>
    <div style="margin-top: 10px;">
        <div style="margin-bottom: 8px;">
            <label>
                <input type="radio" name="visibility" value="private" 
                    <?=!$edit_record || $edit_record['visibility']=='private' ? 'checked' : ''?>>
                Private (only me)
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label>
                <input type="radio" name="visibility" value="public"
                    <?=$edit_record && $edit_record['visibility']=='public' ? 'checked' : ''?>>
                Public (everyone)
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label>
                <input type="radio" name="visibility" value="team"
                    <?=$edit_record && $edit_record['visibility']=='team' ? 'checked' : ''?>>
                Team
            </label>
        </div>
        <div style="margin-bottom: 8px;">
            <label>
                <input type="radio" name="visibility" value="user"
                    <?=$edit_record && $edit_record['visibility']=='user' ? 'checked' : ''?>>
                Specific Users
            </label>
        </div>
    </div>
</div>

<?php
$teams = getUniqueTeams($pdo);
$users = getAllUsers($pdo);
?>

<div id="team-selector" style="display: none;">
    <label>Select Teams</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;">
        <?php foreach($teams as $team): ?>
        <label><input type="checkbox" name="teams[]" value="<?=htmlspecialchars($team)?>"
            <?=isset($edit_teams) && in_array($team, $edit_teams) ? 'checked' : ''?>>
            <?=htmlspecialchars($team)?></label><br>
        <?php endforeach; ?>
    </div>
</div>

<div id="user-selector" style="display: none;">
    <label>Select Users</label>
    <div style="max-height: 200px; overflow-y: auto; border: 1px solid #ccc; padding: 10px;">
        <?php foreach($users as $user): ?>
        <label><input type="checkbox" name="users[]" value="<?=(int)$user['id']?>"
            <?=isset($edit_users) && in_array($user['id'], $edit_users) ? 'checked' : ''?>>
            <?=htmlspecialchars($user['first_name'] . ' ' . $user['last_name'])?></label><br>
        <?php endforeach; ?>
    </div>
</div>
```

#### 5.2 Add JavaScript for Toggle
```javascript
document.querySelectorAll('input[name="visibility"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('team-selector').style.display = 
            this.value === 'team' ? 'block' : 'none';
        document.getElementById('user-selector').style.display = 
            this.value === 'user' ? 'block' : 'none';
    });
});

// Initialize visibility on page load
if(document.querySelector('input[name="visibility"]:checked')) {
    let selected = document.querySelector('input[name="visibility"]:checked').value;
    document.getElementById('team-selector').style.display = 
        selected === 'team' ? 'block' : 'none';
    document.getElementById('user-selector').style.display = 
        selected === 'user' ? 'block' : 'none';
}
```

#### 5.3 Update Display in Tables
```php
// Replace old visibility display logic with:
Visibility: <?=getVisibilityDisplay($record['visibility'], $record['id'], 'your_type', $pdo)?>
```

### Phase 6: CSS Updates

Add to your module's CSS file:
```css
.status-all {
    background: #dcfce7;
    color: #166534;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.status-private {
    background: #fee2e2;
    color: #991b1b;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.status-team {
    background: #dbeafe;
    color: #1e40af;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}

.status-user {
    background: #fce7f3;
    color: #831843;
    padding: 5px 10px;
    border-radius: 20px;
    font-size: 12px;
}
```

## MyData.php Special Considerations

MyData already has legacy visibility logic (Private/Public/Team/Person). To upgrade:

1. Keep existing Person/Team model for backward compatibility
2. Add join tables for future granular sharing
3. Gradually migrate from old model to new join table model
4. Map: Person → user visibility, Team → team visibility

## Notification.php Integration

Communications table now supports new visibility model:
1. Add visibility column to communications table (done in schema)
2. Implement same helper functions
3. Update display logic to show visibility status
4. Add team/user sharing UI to communication creation/edit forms

## Best Practices

1. **Always use transactions** when modifying related tables
2. **Validate team names** against users table
3. **Validate user IDs** and check is_approved status
4. **Use prepared statements** to prevent SQL injection
5. **Cascade deletes** to ensure join tables are cleaned up
6. **Filter in PHP** for complex visibility logic
7. **Index join tables** for query performance
8. **Preserve order** when filtering (use array_filter, not WHERE)

## Performance Optimization

For large datasets, consider:
1. Moving filter logic to SQL with complex JOINs
2. Adding composite indexes: (owner_id, visibility) or (visibility, team_name)
3. Caching team list in session
4. Denormalizing frequently accessed data

## Troubleshooting

| Issue | Solution |
|-------|----------|
| Records disappearing after update | Ensure team/user selections are being passed in POST |
| Team selector not showing | Check if teams.php is passing selected team in session |
| Cascade delete not working | Use PRAGMA foreign_keys=ON in SQLite |
| Performance issues | Add indexes to join tables and owner_id column |

