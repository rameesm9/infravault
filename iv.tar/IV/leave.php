<?php
/**
 * Leave Tracker -- the team's absence register, and the place the
 * out-of-office wording is written.
 *
 * Each entry is published at one of four scopes using the same
 * vocabulary and helpers as quick links, SOPs and KB articles: private
 * ("only me"), team, teams (several), or public. Every create, edit,
 * delete and re-scope is written to leave_audit.
 *
 * Two things differ deliberately from links.php, which this otherwise
 * follows closely:
 *
 *  1. Modify/delete is restricted to the entry's author and Admin, at
 *     every scope -- not to anyone holding can_edit. Somebody else's
 *     absence is not a record a colleague should be able to rewrite.
 *
 *  2. The person's contact details are SNAPSHOTS taken from the portal
 *     user at entry time, not a live join. See
 *     config/schema/workspace.php for why.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/permission-helpers.php';

requireLogin();
requirePermission('leave', 'can_view');

$canEdit   = can('leave', 'can_edit');
$canDelete = can('leave', 'can_delete');
$canExport = can('leave', 'can_export');
$canAudit  = can('leave', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));
$userId   = (int) ($_SESSION['user_id'] ?? 0);
$role     = trim((string) ($_SESSION['role'] ?? ''));
$isAdmin  = strtolower($role) === 'admin';

$teamStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$teamStmt->execute([$userId]);
$userTeam = (string) ($teamStmt->fetchColumn() ?: '');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const LV_MODULE = 'leave';

$visibilities = [
    'private' => 'Only me',
    'team'    => 'My team',
    'teams'   => 'Multiple teams',
    'public'  => 'Public',
];

$leaveTypes = [
    'Annual', 'Sick', 'Casual', 'Emergency', 'Compensatory Off',
    'Work From Home', 'Business Travel', 'Training', 'Public Holiday',
    'Unpaid', 'Other',
];

$leaveStatuses = ['Planned', 'Approved', 'Taken', 'Cancelled', 'Rejected'];

$allTeams = getTeamNames($pdo);

$portalUsers = $pdo->query("
    SELECT id, ncgr_id, first_name, last_name, email, team
    FROM users
    WHERE is_approved = 1
    ORDER BY first_name COLLATE NOCASE, last_name COLLATE NOCASE
")->fetchAll(PDO::FETCH_ASSOC);

$portalById = [];
foreach ($portalUsers as $pu) {
    $portalById[(int) $pu['id']] = [
        'name'    => trim($pu['first_name'] . ' ' . $pu['last_name']),
        'ncgr_id' => (string) $pu['ncgr_id'],
        'email'   => (string) $pu['email'],
        'team'    => (string) ($pu['team'] ?? ''),
    ];
}

$lvFields = [
    'person_name'    => 'Person',
    'ncgr_id'        => 'NCGR ID',
    'email'          => 'Email',
    'person_team'    => 'Team',
    'leave_type'     => 'Leave Type',
    'status'         => 'Status',
    'start_date'     => 'From',
    'end_date'       => 'To',
    'reason'         => 'Reason',
    'cover_contacts' => 'Covered By',
    'ooo_message'    => 'Out of Office Message',
    'notes'          => 'Notes',
];


/* ---------------- HELPERS ---------------- */

/**
 * Calendar days covered, inclusive of both ends.
 *
 * Deliberately calendar days rather than working days: this application
 * has no holiday calendar and no per-country weekend definition, and a
 * "working days" figure derived from a guess at either would be wrong in
 * a way nobody could see. A half day is reported as such instead.
 */
function lvDayCount(string $start, string $end, bool $halfDay): string
{
    $a = strtotime($start);
    $b = strtotime($end);

    if ($a === false || $b === false || $b < $a) {
        return '—';
    }

    $days = (int) floor(($b - $a) / 86400) + 1;

    if ($halfDay && $days === 1) {
        return 'Half day';
    }

    return $days . ' ' . ($days === 1 ? 'day' : 'days');
}

/**
 * Parses the "Covered by" box into contacts, one per line.
 *
 * Cover is usually shared -- two people, or one per system -- so this is
 * a list rather than a single delegate. Each line is accepted in
 * whichever of these forms the writer reaches for:
 *

 *
 * Blank lines are dropped, and the whole field is optional.
 *
 * @return array<int, array{name:string, email:string}>
 */
function lvParseCover(?string $raw): array
{
    $contacts = [];

    foreach (preg_split('/[\r\n]+/', (string) $raw) ?: [] as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        $name  = $line;
        $email = '';

        if (preg_match('/^(.*?)[\s,;\-]*[<(]\s*([^\s<>()]+@[^\s<>()]+?)\s*[>)]$/', $line, $m)) {
            // Name <addr> / Name (addr)
            $name  = trim($m[1]);
            $email = $m[2];
        } elseif (preg_match('/^(.*?)[\s,;]+([^\s,;]+@[^\s,;]+)$/', $line, $m)) {
            // Name, addr / Name addr
            $name  = trim($m[1]);
            $email = $m[2];
        } elseif (str_contains($line, '@') && !str_contains($line, ' ')) {
            // A bare address on its own line.
            $name  = '';
            $email = $line;
        }

        if ($name === '' && $email === '') {
            continue;
        }

        $contacts[] = ['name' => $name, 'email' => $email];
    }

    return $contacts;
}

/** "Name (addr)", or whichever half was given. */
function lvCoverLabel(array $c): string
{
    if ($c['name'] !== '' && $c['email'] !== '') {
        return $c['name'] . ' (' . $c['email'] . ')';
    }

    return $c['name'] !== '' ? $c['name'] : $c['email'];
}

/**
 * Builds the out-of-office wording from the entry.
 *
 * Generated server-side as well as in the browser so that the text is
 * never only as good as whatever the client sent: the stored message is
 * what gets exported, and an entry saved with JavaScript disabled still
 * carries a usable one.
 */
function lvBuildOoo(array $d): string
{
    $from = $d['start_date'] !== '' ? date('d M Y', (int) strtotime($d['start_date'])) : '';
    $to   = $d['end_date']   !== '' ? date('d M Y', (int) strtotime($d['end_date']))   : '';

    $returns = $d['end_date'] !== ''
        ? date('d M Y', (int) strtotime($d['end_date'] . ' +1 day'))
        : '';

    $lines = [];
    $lines[] = 'Thank you for your email.';
    $lines[] = '';

    if ($from !== '' && $to !== '') {
        $lines[] = $from === $to
            ? "I am out of the office on {$from}."
            : "I am out of the office from {$from} to {$to}.";
    } else {
        $lines[] = 'I am currently out of the office.';
    }

    if ($returns !== '') {
        $lines[] = "I will be back at work on {$returns} and will reply to your message then.";
    }

    $lines[] = '';

    // Names everyone listed: "contact A (a@x), B (b@x) or C (c@x)."
    $parts = array_map('lvCoverLabel', lvParseCover($d['cover_contacts'] ?? ''));

    if (!$parts) {
        $lines[] = 'For anything urgent in the meantime, please contact my team.';
    } elseif (count($parts) === 1) {
        $lines[] = "For anything urgent in the meantime, please contact {$parts[0]}.";
    } else {
        $last = array_pop($parts);
        $lines[] = 'For anything urgent in the meantime, please contact '
            . implode(', ', $parts) . ' or ' . $last . '.';
    }

    $lines[] = '';
    $lines[] = 'Kind regards,';
    $lines[] = trim((string) $d['person_name']);

    return implode("\n", $lines);
}


/* ---------------- VISIBILITY ---------------- */

/**
 * Rows this user may see.
 *
 * Filtered in SQL rather than fetched-then-discarded: a private leave
 * entry carries a reason for absence and must never reach a browser with
 * no right to it.
 */
function lvVisibleWhere(bool $isAdmin, int $userId, string $userTeam): array
{
    if ($isAdmin) {
        return ['1=1', []];
    }

    $sql = "(
        e.visibility = 'public'
        OR e.created_by_id = ?
        OR e.user_id = ?
        OR (e.visibility = 'team'  AND e.owner_team <> '' AND e.owner_team = ?)
        OR (e.visibility = 'teams' AND EXISTS (
                SELECT 1 FROM leave_teams t
                WHERE t.leave_id = e.id AND t.team_name = ?
        ))
    )";

    // e.user_id is in there so a person always sees their own leave, even
    // when somebody else recorded it at a scope that excludes them.
    return [$sql, [$userId, $userId, $userTeam, $userTeam]];
}

function lvLoadVisible(PDO $pdo, int $id, bool $isAdmin, int $userId, string $userTeam): ?array
{
    [$visSql, $visParams] = lvVisibleWhere($isAdmin, $userId, $userTeam);

    $stmt = $pdo->prepare("SELECT e.* FROM leave_entries e WHERE e.id = ? AND $visSql");
    $stmt->execute([$id, ...$visParams]);

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/**
 * Author-or-Admin only, at every scope.
 *
 * The person the leave is about counts as an owner too: if a manager
 * files leave on your behalf, you can still correct or withdraw it.
 */
function lvCanModify(array $entry, bool $isAdmin, int $userId): bool
{
    return $isAdmin
        || (int) $entry['created_by_id'] === $userId
        || ((int) $entry['user_id'] !== 0 && (int) $entry['user_id'] === $userId);
}


/* ---------------- AJAX: AUDIT ---------------- */

if (($_GET['action'] ?? '') === 'audit') {
    requirePermission('leave', 'can_audit');

    $id = (int) ($_GET['id'] ?? 0);

    [$visSql, $visParams] = lvVisibleWhere($isAdmin, $userId, $userTeam);

    if ($id > 0) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM leave_entries e WHERE e.id = ? AND $visSql");
        $chk->execute([$id, ...$visParams]);

        if (!$chk->fetchColumn()) {
            http_response_code(403);
            exit('<p class="plat-empty">You do not have access to this entry.</p>');
        }

        $rows  = getItemAuditTrail($pdo, LV_MODULE, $id);
        $empty = 'No audit entries for this leave record yet.';
    } else {
        if ($isAdmin) {
            $sql  = "SELECT a.* FROM leave_audit a ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = [];
        } else {
            $sql  = "SELECT a.* FROM leave_audit a
                     JOIN leave_entries e ON e.id = a.leave_id
                     WHERE $visSql
                     ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = $visParams;
        }

        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $rows  = $st->fetchAll(PDO::FETCH_ASSOC);
        $empty = 'No audit entries recorded yet.';
    }

    if (!$rows) {
        echo '<p class="plat-empty">' . $empty . '</p>';
        exit;
    }

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>When</th><th>Action</th><th>By</th><th>Details</th>'
       . '</tr></thead><tbody>';

    foreach ($rows as $r) {
        $detail = '';
        if (!empty($r['details'])) {
            $decoded = json_decode((string) $r['details'], true);
            $detail = is_array($decoded)
                ? implode('<br>', array_map(
                    fn($k, $v) => '<strong>' . plat_h($k) . ':</strong> ' . plat_h(is_scalar($v) ? (string) $v : json_encode($v)),
                    array_keys($decoded),
                    $decoded
                ))
                : plat_h((string) $r['details']);
        }

        echo '<tr>'
           . '<td>' . plat_h($r['action_date'] ?? '') . '</td>'
           . '<td><span class="plat-pill neutral">' . plat_h($r['action'] ?? '') . '</span></td>'
           . '<td>' . plat_h($r['user_name'] ?? '') . '</td>'
           . '<td>' . ($detail ?: '—') . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/* ---------------- FILTERS ---------------- */

$q       = trim((string) ($_GET['q'] ?? ''));
$fType   = trim((string) ($_GET['f_type'] ?? ''));
$fStatus = trim((string) ($_GET['f_status'] ?? ''));
$fVis    = trim((string) ($_GET['f_vis'] ?? ''));
$fWhen   = trim((string) ($_GET['f_when'] ?? ''));

$today = date('Y-m-d');

[$visSql, $visParams] = lvVisibleWhere($isAdmin, $userId, $userTeam);

$where  = [$visSql];
$params = $visParams;

if ($q !== '') {
    $where[] = '(e.person_name LIKE ? OR e.ncgr_id LIKE ? OR e.reason LIKE ? OR e.cover_contacts LIKE ? OR e.person_team LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fType   !== '') { $where[] = 'e.leave_type = ?'; $params[] = $fType; }
if ($fStatus !== '') { $where[] = 'e.status = ?';     $params[] = $fStatus; }
if ($fVis    !== '') { $where[] = 'e.visibility = ?'; $params[] = $fVis; }

if ($fWhen === 'current') {
    $where[] = 'e.start_date <= ? AND e.end_date >= ?';
    array_push($params, $today, $today);
} elseif ($fWhen === 'upcoming') {
    $where[] = 'e.start_date > ?';
    $params[] = $today;
} elseif ($fWhen === 'past') {
    $where[] = 'e.end_date < ?';
    $params[] = $today;
}

$whereSql = implode(' AND ', $where);


/* ---------------- EXPORT ---------------- */

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('leave', 'can_export');

    $stmt = $pdo->prepare("SELECT e.* FROM leave_entries e WHERE $whereSql ORDER BY e.start_date DESC");
    $stmt->execute($params);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="leave_register_' . date('Ymd_His') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, [...array_values($lvFields), 'Half Day', 'Duration', 'Visibility', 'Shared Teams', 'Recorded By', 'Recorded At']);

    foreach ($stmt as $r) {
        $shared = $r['visibility'] === 'teams'
            ? implode(' | ', getSharedTeams($pdo, LV_MODULE, (int) $r['id']))
            : '';

        fputcsv($out, [
            ...array_map(fn($c) => $r[$c] ?? '', array_keys($lvFields)),
            $r['is_half_day'] ? 'Yes' : 'No',
            lvDayCount((string) $r['start_date'], (string) $r['end_date'], (bool) $r['is_half_day']),
            $r['visibility'],
            $shared,
            $r['created_by'],
            $r['created_at'],
        ]);
    }

    fclose($out);
    exit;
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('leave', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);

        $data = [];
        foreach (array_keys($lvFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        /*
         * Identity is re-derived server-side from the chosen user id
         * rather than trusted from the posted fields, which the form
         * fills in with JavaScript purely for the operator's benefit.
         */
        $personUserId = (int) ($_POST['user_id'] ?? 0);

        if (isset($portalById[$personUserId])) {
            $data['person_name'] = $portalById[$personUserId]['name'];
            $data['ncgr_id']     = $portalById[$personUserId]['ncgr_id'];
            $data['email']       = $portalById[$personUserId]['email'];
            $data['person_team'] = $portalById[$personUserId]['team'];
        } else {
            $personUserId = 0;
        }

        if (!in_array($data['leave_type'], $leaveTypes, true)) {
            $data['leave_type'] = 'Annual';
        }
        if (!in_array($data['status'], $leaveStatuses, true)) {
            $data['status'] = 'Planned';
        }

        $isHalfDay = !empty($_POST['is_half_day']) ? 1 : 0;

        $visibility = (string) ($_POST['visibility'] ?? 'public');
        if (!isset($visibilities[$visibility])) {
            $visibility = 'public';
        }

        $sharedTeams = array_values(array_filter(array_map(
            'trim',
            (array) ($_POST['shared_teams'] ?? [])
        ), fn($t) => $t !== ''));

        $sharedTeams = array_values(array_intersect($sharedTeams, $allTeams));

        $data['owner_team'] = $visibility === 'team' ? $userTeam : '';

        // Regenerated when the user left it blank, so an entry saved
        // without JavaScript still carries usable wording.
        if ($data['ooo_message'] === '') {
            $data['ooo_message'] = lvBuildOoo($data);
        }

        if ($personUserId === 0) {
            $err = 'Choose whose leave this is from the portal users.';
        } elseif ($data['start_date'] === '' || $data['end_date'] === '') {
            $err = 'Leave needs both a start and an end date.';
        } elseif ($data['end_date'] < $data['start_date']) {
            $err = 'The leave ends before it starts — check the dates.';
        } elseif ($visibility === 'team' && $userTeam === '') {
            $err = 'You are not assigned to a team, so "My team" cannot be used. Ask an administrator to set your team.';
        } elseif ($visibility === 'teams' && !$sharedTeams) {
            $err = 'Choose at least one team to share with.';
        } else {
            try {
                $pdo->beginTransaction();

                $cols = [...array_keys($data), 'is_half_day', 'user_id'];
                $vals = [...array_values($data), $isHalfDay, $personUserId];

                if ($id > 0) {
                    $old = lvLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

                    // Same message whether the entry is missing or merely
                    // out of scope -- distinguishing them would confirm
                    // that a given id exists to someone who cannot see it.
                    if (!$old || !lvCanModify($old, $isAdmin, $userId)) {
                        throw new RuntimeException('That leave entry does not exist, or you cannot edit it.');
                    }

                    $set = implode(', ', array_map(fn($c) => "$c = ?", $cols));
                    $pdo->prepare("
                        UPDATE leave_entries
                        SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ")->execute([...$vals, $username, $id]);

                    $action  = 'UPDATED';
                    $details = ['Person' => $data['person_name']];

                    if ((string) $old['status'] !== $data['status']) {
                        $details['Status'] = $old['status'] . ' → ' . $data['status'];
                    }
                    if ((string) $old['start_date'] !== $data['start_date'] || (string) $old['end_date'] !== $data['end_date']) {
                        $details['Dates'] = $old['start_date'] . '–' . $old['end_date']
                            . ' → ' . $data['start_date'] . '–' . $data['end_date'];
                    }
                    if ((string) $old['visibility'] !== $visibility) {
                        $details['Visibility'] =
                            ($visibilities[$old['visibility']] ?? $old['visibility'])
                            . ' → ' . $visibilities[$visibility];
                    }
                } else {
                    $colSql = implode(', ', $cols);
                    $ph     = implode(', ', array_fill(0, count($cols), '?'));

                    $pdo->prepare("
                        INSERT INTO leave_entries ($colSql, visibility, created_by, created_by_id)
                        VALUES ($ph, ?, ?, ?)
                    ")->execute([...$vals, $visibility, $username, $userId]);

                    $id      = (int) $pdo->lastInsertId();
                    $action  = 'CREATED';
                    $details = [
                        'Person'     => $data['person_name'],
                        'Type'       => $data['leave_type'],
                        'Dates'      => $data['start_date'] . ' → ' . $data['end_date'],
                        'Visibility' => $visibilities[$visibility],
                    ];
                }

                $pdo->commit();

                // saveItemSharing opens its own transaction, so it runs
                // after the commit rather than nested inside it. Its return
                // value is checked: an unreported failure would leave the
                // entry at its previous scope while the user is told the
                // save succeeded -- which for a private entry means it
                // stays readable by people it was just hidden from.
                if (!saveItemSharing($pdo, LV_MODULE, $id, $visibility, $sharedTeams)) {
                    throw new RuntimeException(
                        'the entry was saved but its visibility could not be applied; it still has its previous scope'
                    );
                }

                if ($visibility === 'teams' && $sharedTeams) {
                    $details['Shared with'] = implode(', ', $sharedTeams);
                }

                logItemAction($pdo, LV_MODULE, $id, $action, $userId, $username, $details);
                $msg = $action === 'CREATED' ? 'Leave recorded.' : 'Leave updated.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('leave', 'can_delete');

        $id    = (int) ($_POST['id'] ?? 0);
        $entry = lvLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

        if (!$entry || !lvCanModify($entry, $isAdmin, $userId)) {
            $err = 'That leave entry does not exist, or you cannot delete it.';
        } else {
            // Foreign keys are off app-wide, so ON DELETE CASCADE on
            // leave_teams does not fire -- clear the children here.
            $pdo->prepare("DELETE FROM leave_teams WHERE leave_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM leave_entries WHERE id = ?")->execute([$id]);

            logItemAction($pdo, LV_MODULE, $id, 'DELETED', $userId, $username, [
                'Person' => $entry['person_name'],
                'Dates'  => $entry['start_date'] . ' → ' . $entry['end_date'],
            ]);
            $msg = 'Leave entry deleted.';
        }
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("SELECT e.* FROM leave_entries e WHERE $whereSql ORDER BY e.start_date DESC, e.id DESC");
$stmt->execute($params);
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Shared-team lists for every visible row, in one query rather than N. */
$sharedByEntry = [];
if ($entries) {
    $ids = array_column($entries, 'id');
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $ts  = $pdo->prepare("SELECT leave_id, team_name FROM leave_teams WHERE leave_id IN ($in) ORDER BY team_name");
    $ts->execute($ids);
    foreach ($ts as $r) {
        $sharedByEntry[(int) $r['leave_id']][] = $r['team_name'];
    }
}

$outNow   = array_values(array_filter($entries, fn($e) => $e['start_date'] <= $today && $e['end_date'] >= $today
                                                          && !in_array($e['status'], ['Cancelled', 'Rejected'], true)));
$upcoming = array_values(array_filter($entries, fn($e) => $e['start_date'] > $today
                                                          && !in_array($e['status'], ['Cancelled', 'Rejected'], true)));

$page_title = 'Leave Tracker | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/platform.css">
<link rel="stylesheet" href="assets/css/workspace.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🌴</div>
            <div>
                <h1>Leave Tracker</h1>
                <p>Who is away, when, who is covering — and the out-of-office wording to go with it.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="lvOpen(null)">+ Record Leave</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn plat-btn-light" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_type=<?= urlencode($fType) ?>&amp;f_status=<?= urlencode($fStatus) ?>&amp;f_vis=<?= urlencode($fVis) ?>&amp;f_when=<?= urlencode($fWhen) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="lvAudit(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat tone-warn"><b><?= count($outNow) ?></b><span>Away today</span></div>
        <div class="plat-stat"><b><?= count($upcoming) ?></b><span>Upcoming</span></div>
        <div class="plat-stat"><b><?= count($entries) ?></b><span>Visible to you</span></div>
    </div>

    <form method="get" class="plat-filters" style="margin-bottom:18px;">
        <div class="plat-field">
            <label>Search</label>
            <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Name, NCGR ID, cover…" style="min-width:200px;">
        </div>
        <div class="plat-field">
            <label>Type</label>
            <select name="f_type">
                <option value="">All</option>
                <?php foreach ($leaveTypes as $t): ?>
                    <option value="<?= plat_h($t) ?>" <?= $fType === $t ? 'selected' : '' ?>><?= plat_h($t) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="plat-field">
            <label>Status</label>
            <select name="f_status">
                <option value="">All</option>
                <?php foreach ($leaveStatuses as $s): ?>
                    <option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="plat-field">
            <label>When</label>
            <select name="f_when">
                <option value="">All</option>
                <option value="current"  <?= $fWhen === 'current'  ? 'selected' : '' ?>>Away today</option>
                <option value="upcoming" <?= $fWhen === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                <option value="past"     <?= $fWhen === 'past'     ? 'selected' : '' ?>>Past</option>
            </select>
        </div>
        <div class="plat-field">
            <label>Visibility</label>
            <select name="f_vis">
                <option value="">All</option>
                <?php foreach ($visibilities as $k => $v): ?>
                    <option value="<?= plat_h($k) ?>" <?= $fVis === $k ? 'selected' : '' ?>><?= plat_h($v) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="plat-btn plat-btn-primary">Filter</button>
        <a class="plat-btn plat-btn-light" href="leave.php">Reset</a>
    </form>

    <?php if (!$entries): ?>
        <p class="plat-empty">No leave records match. <?= $canEdit ? 'Add the first one with “Record Leave”.' : '' ?></p>
    <?php else: ?>

    <div class="plat-table-wrap">
        <table class="plat-table lv-table">
            <thead>
                <tr>
                    <th>Person</th>
                    <th>Type</th>
                    <th>Dates</th>
                    <th>Duration</th>
                    <th>Status</th>
                    <th>Covered by</th>
                    <th>Visibility</th>
                    <th class="lv-act">Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($entries as $e): ?>
                <?php
                $id     = (int) $e['id'];
                $vis    = (string) $e['visibility'];
                $shared = $sharedByEntry[$id] ?? [];
                $modify = lvCanModify($e, $isAdmin, $userId);
                $away   = $e['start_date'] <= $today && $e['end_date'] >= $today
                          && !in_array($e['status'], ['Cancelled', 'Rejected'], true);
                ?>
                <tr class="<?= $away ? 'lv-away' : '' ?>">
                    <td>
                        <div class="lv-person"><?= plat_h($e['person_name']) ?></div>
                        <div class="lv-sub"><?= plat_h($e['ncgr_id']) ?><?= $e['person_team'] ? ' · ' . plat_h($e['person_team']) : '' ?></div>
                    </td>
                    <td><span class="plat-pill neutral"><?= plat_h($e['leave_type']) ?></span></td>
                    <td>
                        <?= plat_h($e['start_date']) ?><?php if ($e['end_date'] !== $e['start_date']): ?> → <?= plat_h($e['end_date']) ?><?php endif; ?>
                        <?php if ($away): ?><div class="lv-away-flag">Away today</div><?php endif; ?>
                    </td>
                    <td><?= plat_h(lvDayCount((string) $e['start_date'], (string) $e['end_date'], (bool) $e['is_half_day'])) ?></td>
                    <td><span class="lv-status st-<?= plat_h(strtolower(str_replace(' ', '-', $e['status']))) ?>"><?= plat_h($e['status']) ?></span></td>
                    <td>
                        <?php $cover = lvParseCover($e['cover_contacts'] ?? ''); ?>
                        <?php if (!$cover): ?>
                            —
                        <?php else: ?>
                            <?php foreach ($cover as $c): ?>
                                <div class="lv-cover">
                                    <?= plat_h($c['name'] ?: $c['email']) ?>
                                    <?php if ($c['name'] !== '' && $c['email'] !== ''): ?>
                                        <span class="lv-sub"><?= plat_h($c['email']) ?></span>
                                    <?php endif; ?>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </td>
                    <td>
                        <span class="ws-vis vis-<?= plat_h($vis) ?>" title="<?= $vis === 'teams'
                            ? 'Shared with: ' . plat_h(implode(', ', $shared))
                            : ($vis === 'team' ? 'Team: ' . plat_h($e['owner_team']) : plat_h($visibilities[$vis] ?? $vis)) ?>">
                            <?= plat_h($visibilities[$vis] ?? $vis) ?>
                            <?php if ($vis === 'teams' && $shared): ?> (<?= count($shared) ?>)<?php endif; ?>
                        </span>
                    </td>
                    <td class="lv-act">
                        <button type="button" class="plat-icon-btn plat-icon-view" title="Out-of-office message"
                            onclick='lvShowOoo(<?= json_encode($e["ooo_message"] ?? "", JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✉</button>
                        <?php if ($modify): ?>
                            <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                onclick='lvOpen(<?= json_encode($e + ["shared_teams" => $shared], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                        <?php endif; ?>
                        <?php if ($canAudit): ?>
                            <button type="button" class="plat-icon-btn plat-icon-hist" title="Audit trail"
                                onclick="lvAudit(<?= $id ?>)">⏱</button>
                        <?php endif; ?>
                        <?php if ($canDelete && $modify): ?>
                            <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                onclick='lvDelete(<?= $id ?>, <?= json_encode($e["person_name"] . " (" . $e["start_date"] . ")", JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>🗑</button>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <?php endif; ?>

</div>


<?php if ($canEdit): ?>
<div class="plat-modal" id="lvModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="lvTitle">Record Leave</h2>
            <button type="button" class="plat-close" onclick="platClose('lvModal')">&times;</button>
        </div>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="lv_id">

            <div class="plat-form-grid cols-2">

                <div class="plat-field full"><label>Whose leave *</label>
                    <select name="user_id" id="lv_user_id" required onchange="lvFillPerson()">
                        <option value="">— select a user —</option>
                        <?php foreach ($portalUsers as $pu): ?>
                            <option value="<?= (int) $pu['id'] ?>">
                                <?= plat_h(trim($pu['first_name'] . ' ' . $pu['last_name'])) ?>
                                (<?= plat_h($pu['ncgr_id']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="ws-hint">NCGR ID and email fill in automatically and are re-checked on save.</span>
                </div>

                <div class="plat-field"><label>NCGR ID</label>
                    <input type="text" id="lv_ncgr_id" readonly class="ws-readonly"></div>

                <div class="plat-field"><label>Email</label>
                    <input type="text" id="lv_email" readonly class="ws-readonly"></div>

                <div class="plat-field"><label>Leave type *</label>
                    <select name="leave_type" id="lv_leave_type" onchange="lvRegenOoo()">
                        <?php foreach ($leaveTypes as $t): ?><option value="<?= plat_h($t) ?>"><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Status</label>
                    <select name="status" id="lv_status">
                        <?php foreach ($leaveStatuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>From *</label>
                    <input type="date" name="start_date" id="lv_start_date" required onchange="lvRegenOoo()"></div>

                <div class="plat-field"><label>To *</label>
                    <input type="date" name="end_date" id="lv_end_date" required onchange="lvRegenOoo()"></div>

                <div class="plat-field full">
                    <label class="ws-check">
                        <input type="checkbox" name="is_half_day" id="lv_is_half_day" value="1">
                        <span>Half day</span>
                    </label>
                </div>

                <div class="plat-field full"><label>Reason</label>
                    <input type="text" name="reason" id="lv_reason" placeholder="Optional"></div>

                <div class="plat-section-title">Cover</div>

                <div class="plat-field full">
                    <div class="lv-ooo-bar">
                        <label style="margin:0;">Covered by <span class="ws-optional">optional</span></label>
                        <?php if ($portalUsers): ?>
                            <select class="lv-add-cover" onchange="lvAddCover(this)">
                                <option value="">+ add a portal user…</option>
                                <?php foreach ($portalUsers as $pu): ?>
                                    <option value="<?= (int) $pu['id'] ?>">
                                        <?= plat_h(trim($pu['first_name'] . ' ' . $pu['last_name'])) ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        <?php endif; ?>
                    </div>
                    <textarea name="cover_contacts" id="lv_cover_contacts" rows="3"
                              placeholder="One person per line, e.g.&#10;Ramees &lt;example@example.gov.sa&gt;&#10;Sreenivasulu &lt;example.1@example.gov.sa&gt;"
                              onchange="lvRegenOoo()" oninput="lvRegenOoo()"></textarea>
                    <span class="ws-hint">One contact per line — leave blank if nobody is covering. Accepts
                        <code>Name &lt;email&gt;</code>, <code>Name, email</code>, a name alone, or a bare address.
                        Everyone listed is named in the out-of-office message.</span>
                </div>

                <div class="plat-section-title">Out of office</div>

                <div class="plat-field full">
                    <div class="lv-ooo-bar">
                        <label style="margin:0;">Message</label>
                        <div>
                            <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="lvRegenOoo(true)">Regenerate</button>
                            <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="lvCopyOoo(this)">Copy</button>
                        </div>
                    </div>
                    <textarea name="ooo_message" id="lv_ooo_message" rows="9" class="lv-ooo"></textarea>
                    <span class="ws-hint">Regenerates from the dates and cover contact until you edit it by hand. Left empty, it is generated on save.</span>
                </div>

                <div class="plat-section-title">Publish to</div>

                <div class="plat-field full">
                    <div class="ws-vis-opts">
                        <?php foreach ($visibilities as $k => $label): ?>
                            <label class="ws-vis-opt">
                                <input type="radio" name="visibility" value="<?= plat_h($k) ?>"
                                       <?= $k === 'team' ? 'checked' : '' ?> onchange="lvVisChanged()">
                                <span><?= plat_h($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <span class="ws-hint" id="lv_vis_hint"></span>
                </div>

                <div class="plat-field full" id="lv_teams_wrap" style="display:none;">
                    <label>Share with teams</label>
                    <div class="ws-team-list">
                        <?php foreach ($allTeams as $t): ?>
                            <label class="ws-team">
                                <input type="checkbox" name="shared_teams[]" value="<?= plat_h($t) ?>">
                                <span><?= plat_h($t) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="plat-field full"><label>Notes</label>
                    <textarea name="notes" id="lv_notes" rows="2"></textarea></div>

            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('lvModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-primary">Save Leave</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="lvDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete Leave Entry</h2>
            <button type="button" class="plat-close" onclick="platClose('lvDelModal')">&times;</button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="lvDelId">
            <p>Delete the leave entry for <strong id="lvDelName"></strong>? The audit trail is kept.</p>
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('lvDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="plat-modal" id="lvOooModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Out of Office Message</h2>
            <button type="button" class="plat-close" onclick="platClose('lvOooModal')">&times;</button></div>
        <textarea id="lvOooView" class="lv-ooo" rows="10" readonly></textarea>
        <div class="plat-modal-foot">
            <button type="button" class="plat-btn plat-btn-light" onclick="lvCopyView(this)">Copy</button>
            <button type="button" class="plat-btn plat-btn-primary" onclick="platClose('lvOooModal')">Close</button>
        </div>
    </div>
</div>

<div class="plat-modal" id="lvAuditModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="lvAuditTitle">Audit Trail</h2>
            <button type="button" class="plat-close" onclick="platClose('lvAuditModal')">&times;</button></div>
        <div id="lvAuditBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<script>
const LV_USERS = <?= json_encode($portalById, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG) ?>;

const LV_VIS_HINT = {
    private: 'Only you (and an administrator) can see this entry.',
    team:    'Everyone in your team can see this entry.',
    teams:   'Only the teams you tick below can see this entry.',
    public:  'Everyone who can open this page can see this entry.'
};

/* Modal show/hide. Defined per page across this codebase -- there is no
   shared platform.js, and platform.css only supplies the .show rule. */
function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

/* True once the user has typed in the message themselves, after which
   changing a date no longer overwrites their wording. */
let lvOooTouched = false;

function lvFillPerson() {
    const sel = document.getElementById('lv_user_id');
    const u   = LV_USERS[sel.value];

    document.getElementById('lv_ncgr_id').value = u ? u.ncgr_id : '';
    document.getElementById('lv_email').value   = u ? u.email   : '';

    lvRegenOoo();
}

function lvFmtDate(iso) {
    if (!iso) return '';
    const d = new Date(iso + 'T00:00:00');
    if (isNaN(d)) return iso;
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function lvNextDay(iso) {
    if (!iso) return '';
    const d = new Date(iso + 'T00:00:00');
    if (isNaN(d)) return '';
    d.setDate(d.getDate() + 1);
    return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

/*
 * Mirrors lvParseCover() in PHP -- one contact per line, in any of the
 * forms that function accepts. Returns display labels only, which is all
 * the message needs.
 */
function lvCoverLabels() {
    const box = document.getElementById('lv_cover_contacts');
    if (!box) return [];

    return box.value.split(/[\r\n]+/).map(line => {
        line = line.trim();
        if (!line) return '';

        let m = line.match(/^(.*?)[\s,;\-]*[<(]\s*([^\s<>()]+@[^\s<>()]+?)\s*[>)]$/);
        if (!m) m = line.match(/^(.*?)[\s,;]+([^\s,;]+@[^\s,;]+)$/);

        if (m) {
            const name = m[1].trim();
            return name ? `${name} (${m[2]})` : m[2];
        }

        return line;
    }).filter(Boolean);
}

/* Appends a chosen portal user as a new line, ready-formatted. */
function lvAddCover(sel) {
    const u = LV_USERS[sel.value];
    sel.value = '';
    if (!u) return;

    const box  = document.getElementById('lv_cover_contacts');
    const line = u.email ? `${u.name} <${u.email}>` : u.name;

    // Don't add the same person twice.
    if (box.value.split(/[\r\n]+/).some(l => l.trim() === line)) return;

    box.value = box.value.trim() === '' ? line : box.value.replace(/\s*$/, '') + '\n' + line;
    lvRegenOoo();
}

/*
 * Mirrors lvBuildOoo() in PHP. Both exist on purpose: this one gives
 * live feedback as the dates are picked, and the server one guarantees
 * an entry saved with an empty box still carries usable wording.
 */
function lvBuildOoo() {
    const sel  = document.getElementById('lv_user_id');
    const u    = LV_USERS[sel.value];
    const from = lvFmtDate(document.getElementById('lv_start_date').value);
    const to   = lvFmtDate(document.getElementById('lv_end_date').value);
    const back = lvNextDay(document.getElementById('lv_end_date').value);

    const lines = ['Thank you for your email.', ''];

    if (from && to) {
        lines.push(from === to
            ? `I am out of the office on ${from}.`
            : `I am out of the office from ${from} to ${to}.`);
    } else {
        lines.push('I am currently out of the office.');
    }

    if (back) {
        lines.push(`I will be back at work on ${back} and will reply to your message then.`);
    }

    lines.push('');

    const cover = lvCoverLabels();

    if (cover.length === 0) {
        lines.push('For anything urgent in the meantime, please contact my team.');
    } else if (cover.length === 1) {
        lines.push(`For anything urgent in the meantime, please contact ${cover[0]}.`);
    } else {
        const last = cover[cover.length - 1];
        lines.push('For anything urgent in the meantime, please contact '
            + cover.slice(0, -1).join(', ') + ' or ' + last + '.');
    }

    lines.push('', 'Kind regards,', u ? u.name : '');

    return lines.join('\n');
}

function lvRegenOoo(force) {
    const box = document.getElementById('lv_ooo_message');
    if (!box) return;

    // Never silently discard wording the user wrote themselves.
    if (lvOooTouched && !force) return;

    box.value = lvBuildOoo();
    if (force) { lvOooTouched = false; }
}

function lvVisChanged() {
    // The editor markup only exists for users with can_edit, but this runs
    // on DOMContentLoaded for everyone -- without the guards a view-only
    // user takes a TypeError on every page load.
    const wrap = document.getElementById('lv_teams_wrap');
    const hint = document.getElementById('lv_vis_hint');
    if (!wrap || !hint) return;

    const el = document.querySelector('input[name="visibility"]:checked');
    const v  = el ? el.value : 'team';

    wrap.style.display = v === 'teams' ? '' : 'none';
    hint.textContent = LV_VIS_HINT[v] || '';
}

function lvOpen(data) {
    const editing = !!data;
    document.getElementById('lvTitle').innerText = editing ? 'Edit Leave' : 'Record Leave';
    document.getElementById('lv_id').value = editing ? data.id : '';

    ['leave_type', 'status', 'start_date', 'end_date', 'reason',
     'cover_contacts', 'ooo_message', 'notes'].forEach(f => {
        const el = document.getElementById('lv_' + f);
        if (el) el.value = editing ? (data[f] ?? '') : '';
    });

    document.getElementById('lv_is_half_day').checked = editing && Number(data.is_half_day) === 1;

    // New entries default to the person filing them, which is the common case.
    document.getElementById('lv_user_id').value = editing
        ? (data.user_id || '')
        : '<?= (int) $userId ?>';

    const sel = document.getElementById('lv_user_id');
    const u   = LV_USERS[sel.value];
    document.getElementById('lv_ncgr_id').value = u ? u.ncgr_id : '';
    document.getElementById('lv_email').value   = u ? u.email   : '';

    // An existing message is the author's; a new entry starts generated.
    lvOooTouched = editing && (data.ooo_message ?? '') !== '';
    if (!lvOooTouched) { lvRegenOoo(true); }

    const vis = editing ? (data.visibility || 'team') : 'team';
    const radio = document.querySelector(`input[name="visibility"][value="${vis}"]`);
    if (radio) radio.checked = true;

    const shared = (editing && Array.isArray(data.shared_teams)) ? data.shared_teams : [];
    document.querySelectorAll('input[name="shared_teams[]"]').forEach(cb => {
        cb.checked = shared.includes(cb.value);
    });

    lvVisChanged();
    platOpen('lvModal');
}

function lvDelete(id, name) {
    document.getElementById('lvDelId').value = id;
    document.getElementById('lvDelName').innerText = name;
    platOpen('lvDelModal');
}

function lvShowOoo(text) {
    document.getElementById('lvOooView').value = text || 'No out-of-office message was saved for this entry.';
    platOpen('lvOooModal');
}

function lvCopyText(text, btn) {
    const done = () => {
        const was = btn.innerHTML;
        btn.innerHTML = 'Copied';
        setTimeout(() => { btn.innerHTML = was; }, 1100);
    };

    // navigator.clipboard needs a secure context; this app is often reached
    // over plain HTTP internally, so fall back rather than silently failing.
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(() => lvCopyFallback(text, done));
    } else {
        lvCopyFallback(text, done);
    }
}

function lvCopyFallback(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { /* nothing else to try */ }
    document.body.removeChild(ta);
}

function lvCopyOoo(btn)  { lvCopyText(document.getElementById('lv_ooo_message').value, btn); }
function lvCopyView(btn) { lvCopyText(document.getElementById('lvOooView').value, btn); }

function lvAudit(id) {
    document.getElementById('lvAuditTitle').innerText =
        id ? 'Audit Trail — entry #' + id : 'Audit Trail — all leave';
    document.getElementById('lvAuditBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('lvAuditModal');
    fetch('leave.php?action=audit&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('lvAuditBody').innerHTML = h; })
        .catch(() => {
            document.getElementById('lvAuditBody').innerHTML = '<p class="plat-empty">Failed to load.</p>';
        });
}

document.addEventListener('DOMContentLoaded', function () {
    lvVisChanged();

    const box = document.getElementById('lv_ooo_message');
    if (box) { box.addEventListener('input', () => { lvOooTouched = true; }); }
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
