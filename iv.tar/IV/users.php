<?php

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/pagination-helpers.php';


/*
|--------------------------------------------------------------------------
| ADMIN ONLY ACCESS
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| Governed by the permissions table under page_key 'users', like every
| other page.
|
| This was previously a hardcoded `trim($_SESSION['role']) !== 'Admin'`
| comparison. That was a second, competing permission model: it ignored
| the permissions table entirely, so granting users.can_view to another
| role in Manage Permissions had no effect at all -- the screen reported
| authority it did not have. Being an exact string match, it also locked
| out any role differing only in case.
|
| The $canView..$canAudit flags below were already being computed from
| the table; they simply were not used for the gate.
*/

requireLogin();
requirePermission('users', 'can_view');


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER (Admin-only page, but check for audit)
|--------------------------------------------------------------------------
*/

function usersHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'users', $permission);
}


$role = trim($_SESSION['role'] ?? '');

$canView   = usersHasPermission($pdo, $role, 'can_view');
$canEdit   = usersHasPermission($pdo, $role, 'can_edit');
$canDelete = usersHasPermission($pdo, $role, 'can_delete');
$canExport = usersHasPermission($pdo, $role, 'can_export');
$canImport = usersHasPermission($pdo, $role, 'can_import');
$canAudit  = usersHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| JSON EXPORT USERS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'export_users') {
    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export user records.');
    }

    $is_approved = (int)($_POST['is_approved'] ?? 1);
    $search_query = trim($_POST['search_query'] ?? '');

    $where_clauses = ['is_approved = ?'];
    $params = [$is_approved];

    if (!empty($search_query)) {
        $where_clauses[] = "(first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR ncgr_id LIKE ?)";
        $search_term = "%$search_query%";
        array_push($params, $search_term, $search_term, $search_term, $search_term);
    }

    $where_sql = implode(" AND ", $where_clauses);

    $stmt = $pdo->prepare("
        SELECT
            first_name,
            last_name,
            email,
            phone,
            ncgr_id,
            team,
            role
        FROM users
        WHERE $where_sql
        ORDER BY first_name ASC, last_name ASC
    ");
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $filename = 'users_export_' . date('Y-m-d_H-i-s') . '.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    fprintf($output = fopen('php://output', 'w'), chr(0xEF) . chr(0xBB) . chr(0xBF));

    fputcsv($output, ['First Name', 'Last Name', 'Email', 'Phone', 'NCGR ID', 'Team', 'Role']);

    foreach ($rows as $row) {
        fputcsv($output, [
            $row['first_name'] ?? '',
            $row['last_name'] ?? '',
            $row['email'] ?? '',
            $row['phone'] ?? '',
            $row['ncgr_id'] ?? '',
            $row['team'] ?? '',
            $row['role'] ?? ''
        ]);
    }

    fclose($output);
    exit;
}


/*
|--------------------------------------------------------------------------
| JSON AUDIT HISTORY
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'get_history') {
    if (!$canAudit) {
        http_response_code(403);
        echo json_encode(['success' => false, 'message' => 'You do not have permission to view audit history.']);
        exit;
    }

    header('Content-Type: application/json; charset=utf-8');

    $user_id = trim($_POST['user_id'] ?? '');

    try {
        if ($user_id === 'all') {
            // Global history
            $stmt = $pdo->query("
                SELECT
                    user_id,
                    action,
                    changes,
                    created_at
                FROM user_action_history
                ORDER BY id DESC
                LIMIT 500
            ");
        } else {
            // Individual user history
            $user_id = (int)$user_id;
            if ($user_id <= 0) {
                echo json_encode(['success' => false, 'message' => 'Invalid user ID.']);
                exit;
            }

            $stmt = $pdo->prepare("
                SELECT
                    id,
                    action,
                    changes,
                    created_at
                FROM user_action_history
                WHERE user_id = ?
                ORDER BY id DESC
                LIMIT 100
            ");

            $stmt->execute([$user_id]);
        }

        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'history' => $history]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| HELPER
|--------------------------------------------------------------------------
*/

function h($value)
{
    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| PRIMARY ADMIN
|--------------------------------------------------------------------------
*/

$primaryAdminNcgr = 'ADMIN001';


/*
|--------------------------------------------------------------------------
| MESSAGES
|--------------------------------------------------------------------------
*/

$msg = '';
$error = '';


/*
|--------------------------------------------------------------------------
| CREATE / REPAIR ROLES TABLE
|--------------------------------------------------------------------------
|
| This makes users.php work even if roles table has not yet been created.
|
*/

try {

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS roles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            role_name TEXT UNIQUE NOT NULL,
            is_system INTEGER NOT NULL DEFAULT 0,
            is_locked INTEGER NOT NULL DEFAULT 0
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | CREATE USER ACTION HISTORY TABLE
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS user_action_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            changes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");


    /*
    |--------------------------------------------------------------------------
    | Check existing columns
    |--------------------------------------------------------------------------
    */

    $roleColumns = [];

    $columns = $pdo->query("
        PRAGMA table_info(roles)
    ")->fetchAll(PDO::FETCH_ASSOC);


    foreach ($columns as $column) {

        $roleColumns[] = $column['name'];

    }


    /*
    |--------------------------------------------------------------------------
    | Add missing is_system
    |--------------------------------------------------------------------------
    */

    if (!in_array('is_system', $roleColumns, true)) {

        $pdo->exec("
            ALTER TABLE roles
            ADD COLUMN is_system INTEGER NOT NULL DEFAULT 0
        ");

    }


    /*
    |--------------------------------------------------------------------------
    | Add missing is_locked
    |--------------------------------------------------------------------------
    */

    if (!in_array('is_locked', $roleColumns, true)) {

        $pdo->exec("
            ALTER TABLE roles
            ADD COLUMN is_locked INTEGER NOT NULL DEFAULT 0
        ");

    }


    /*
    |--------------------------------------------------------------------------
    | Make sure default roles exist
    |--------------------------------------------------------------------------
    */

    $defaultRoles = [

        [
            'Admin',
            1,
            1
        ],

        [
            'Edit',
            1,
            0
        ],

        [
            'Read-only',
            1,
            0
        ]

    ];


    $roleInsert = $pdo->prepare("
        INSERT OR IGNORE INTO roles
        (
            role_name,
            is_system,
            is_locked
        )
        VALUES
        (
            ?,
            ?,
            ?
        )
    ");


    foreach ($defaultRoles as $role) {

        $roleInsert->execute([
            $role[0],
            $role[1],
            $role[2]
        ]);

    }


    /*
    |--------------------------------------------------------------------------
    | Make Admin permanently locked
    |--------------------------------------------------------------------------
    */

    $pdo->exec("
        UPDATE roles
        SET
            is_system = 1,
            is_locked = 1
        WHERE role_name = 'Admin'
    ");


} catch (Throwable $e) {

    die(
        "Unable to initialise roles table: "
        . h($e->getMessage())
    );

}


/*
|--------------------------------------------------------------------------
| LOAD ROLES
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| These are the roles displayed in users.php.
|
| Therefore if you create:
|
| Auditor
| Operator
| Security
| Viewer
|
| in permission.php, they automatically appear here.
|
|--------------------------------------------------------------------------
*/

$roles = $pdo->query("
    SELECT
        id,
        role_name,
        is_system,
        is_locked
    FROM roles
    ORDER BY
        CASE role_name
            WHEN 'Admin' THEN 1
            WHEN 'Edit' THEN 2
            WHEN 'Read-only' THEN 3
            ELSE 4
        END,
        role_name
")->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| ROLE NAMES
|--------------------------------------------------------------------------
*/

$roleNames = [];

foreach ($roles as $role) {

    $roleNames[] = trim(
        $role['role_name']
    );

}


/*
|--------------------------------------------------------------------------
| DEFAULT ROLE
|--------------------------------------------------------------------------
*/

$defaultRole = 'Read-only';

if (!in_array($defaultRole, $roleNames, true)) {

    $defaultRole =
        $roleNames[0] ?? 'Read-only';

}


/*
|--------------------------------------------------------------------------
| HANDLE TEAM ACTIONS
|--------------------------------------------------------------------------
|
| Handled ahead of the user actions below because those require a valid
| user_id and reject the request without one -- a team action has no
| target user.
|
| Note $role is no longer the session role at this point: the LOAD ROLES
| loop above reuses it as its iteration variable. The permission flags
| computed near the top of the file are the ones to check.
|
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    &&
    in_array($_POST['action'] ?? '', ['add_team', 'delete_team'], true)
) {

    $teamAction = trim($_POST['action']);


    /*
    |--------------------------------------------------------------------------
    | ADD TEAM
    |--------------------------------------------------------------------------
    */

    if ($teamAction === 'add_team') {

        if (!$canEdit) {

            http_response_code(403);
            $error = 'You do not have permission to create teams.';

        } else {

            $newTeam = trim($_POST['team_name'] ?? '');

            if ($newTeam === '') {

                $error = 'Team name is required.';

            } elseif (mb_strlen($newTeam) > 60) {

                $error = 'Team name must be 60 characters or fewer.';

            } else {

                try {

                    /*
                    | The UNIQUE index is COLLATE NOCASE, so this check and
                    | the insert agree on what counts as a duplicate. The
                    | explicit lookup exists only to produce a readable
                    | message instead of a constraint violation.
                    */
                    $dupStmt = $pdo->prepare("
                        SELECT team_name
                        FROM teams
                        WHERE team_name = ? COLLATE NOCASE
                    ");
                    $dupStmt->execute([$newTeam]);
                    $duplicate = $dupStmt->fetchColumn();

                    if ($duplicate !== false) {

                        $error =
                            "Team '" . $duplicate . "' already exists.";

                    } else {

                        $insertStmt = $pdo->prepare("
                            INSERT INTO teams (team_name, created_by)
                            VALUES (?, ?)
                        ");

                        $insertStmt->execute([
                            $newTeam,
                            $_SESSION['name'] ?? 'Unknown User'
                        ]);

                        $msg = "Team '{$newTeam}' created.";
                    }

                } catch (Throwable $e) {

                    $error =
                        'Unable to create team: ' . $e->getMessage();
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE TEAM
    |--------------------------------------------------------------------------
    |
    | Refused while the team still has members. users.team stores a name,
    | not a foreign key, so deleting a team in use would not fail loudly --
    | it would leave those users pointing at a team that no longer exists,
    | and the next save through the admin dropdown would silently reassign
    | them. Reassign the members first, then delete.
    |
    */

    elseif ($teamAction === 'delete_team') {

        if (!$canDelete) {

            http_response_code(403);
            $error = 'You do not have permission to delete teams.';

        } else {

            $teamId = (int)($_POST['team_id'] ?? 0);

            try {

                $lookupStmt = $pdo->prepare("
                    SELECT team_name
                    FROM teams
                    WHERE id = ?
                ");
                $lookupStmt->execute([$teamId]);
                $teamName = $lookupStmt->fetchColumn();

                if ($teamName === false) {

                    $error = 'Team not found.';

                } else {

                    $memberCount = countTeamMembers($pdo, $teamName);

                    if ($memberCount > 0) {

                        $error =
                            "Cannot delete '{$teamName}': "
                            . $memberCount . ' '
                            . ($memberCount === 1 ? 'user is' : 'users are')
                            . ' still assigned to it. Move them to another team first.';

                    } else {

                        $pdo->prepare("DELETE FROM teams WHERE id = ?")
                            ->execute([$teamId]);

                        $msg = "Team '{$teamName}' deleted.";
                    }
                }

            } catch (Throwable $e) {

                $error =
                    'Unable to delete team: ' . $e->getMessage();
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| HANDLE POST ACTIONS
|--------------------------------------------------------------------------
*/

elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action =
        trim($_POST['action'] ?? '');

    $targetId =
        (int)($_POST['user_id'] ?? 0);


    /*
    |--------------------------------------------------------------------------
    | Validate target user
    |--------------------------------------------------------------------------
    */

    if ($targetId <= 0) {

        $error = 'Invalid user selected.';

    } else {

        $query = $pdo->prepare("
            SELECT *
            FROM users
            WHERE id = ?
        ");

        $query->execute([
            $targetId
        ]);

        $target =
            $query->fetch(PDO::FETCH_ASSOC);


        if (!$target) {

            $error = 'User not found.';

        } else {


            /*
            |--------------------------------------------------------------------------
            | APPROVE USER
            |--------------------------------------------------------------------------
            */

            if ($action === 'approve') {

                $role =
                    trim($_POST['role'] ?? $defaultRole);

                $team =
                    trim($_POST['team'] ?? '');


                /*
                |--------------------------------------------------------------------------
                | Validate role against roles table
                |--------------------------------------------------------------------------
                */

                if (
                    !in_array(
                        $role,
                        $roleNames,
                        true
                    )
                ) {

                    $role = $defaultRole;

                }


                /*
                |--------------------------------------------------------------------------
                | Protect primary administrator
                |--------------------------------------------------------------------------
                */

                if (
                    $target['ncgr_id']
                    ===
                    $primaryAdminNcgr
                ) {

                    $role = 'Admin';

                    $team = 'Linux';

                }


                try {

                    $stmt = $pdo->prepare("
                        UPDATE users
                        SET
                            is_approved = 1,
                            role = ?,
                            team = ?
                        WHERE id = ?
                    ");


                    $stmt->execute([
                        $role,
                        $team,
                        $targetId
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | AUDIT LOG
                    |--------------------------------------------------------------------------
                    */

                    $historyStmt = $pdo->prepare("
                        INSERT INTO user_action_history
                        (user_id, action, changes, created_at)
                        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ");

                    $historyStmt->execute([
                        $targetId,
                        'Approved',
                        "User approved with role: $role, Team: $team"
                    ]);


                    $msg =
                        "User approved successfully with role '{$role}'.";

                } catch (Throwable $e) {

                    $error =
                        "Unable to approve user: "
                        . $e->getMessage();

                }

            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE USER DETAILS
            |--------------------------------------------------------------------------
            */

            elseif ($action === 'update_details') {

                $role =
                    trim($_POST['role'] ?? $defaultRole);

                $team =
                    trim($_POST['team'] ?? '');

                $phone =
                    trim($_POST['phone'] ?? '');


                /*
                |--------------------------------------------------------------------------
                | Validate selected role
                |--------------------------------------------------------------------------
                */

                if (
                    !in_array(
                        $role,
                        $roleNames,
                        true
                    )
                ) {

                    $error =
                        "Invalid role selected.";

                } else {


                    /*
                    |--------------------------------------------------------------------------
                    | Protect ADMIN001
                    |--------------------------------------------------------------------------
                    */

                    if (
                        $target['ncgr_id']
                        ===
                        $primaryAdminNcgr
                    ) {

                        $role = 'Admin';

                        $team = 'Linux';

                    }


                    try {

                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET
                                role = ?,
                                team = ?,
                                phone = ?
                            WHERE id = ?
                        ");


                        $stmt->execute([
                            $role,
                            $team,
                            $phone,
                            $targetId
                        ]);


                        /*
                        |--------------------------------------------------------------------------
                        | AUDIT LOG
                        |--------------------------------------------------------------------------
                        */

                        $changes = [];
                        if (($target['role'] ?? '') !== $role) {
                            $changes[] = "Role: " . ($target['role'] ?? '-') . " → $role";
                        }
                        if (($target['team'] ?? '') !== $team) {
                            $changes[] = "Team: " . ($target['team'] ?? '-') . " → $team";
                        }
                        if (trim((string) ($target['phone'] ?? '')) !== $phone) {
                            $changes[] = "Phone: " . (trim((string) ($target['phone'] ?? '')) ?: '-') . " → " . ($phone ?: '-');
                        }

                        $historyStmt = $pdo->prepare("
                            INSERT INTO user_action_history
                            (user_id, action, changes, created_at)
                            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                        ");

                        $historyStmt->execute([
                            $targetId,
                            'Updated',
                            implode(", ", $changes)
                        ]);


                        $msg =
                            "User details updated successfully. "
                            . "Role is now '{$role}'.";

                    } catch (Throwable $e) {

                        $error =
                            "Unable to update user: "
                            . $e->getMessage();

                    }

                }

            }


            /*
            |--------------------------------------------------------------------------
            | FORCE PASSWORD RESET
            |--------------------------------------------------------------------------
            */

            elseif (
                $action === 'force_password_change'
            ) {

                try {

                    /*
                    |--------------------------------------------------------------------------
                    | Generate temporary password
                    |--------------------------------------------------------------------------
                    */

                    $newPassword =
                        bin2hex(
                            random_bytes(5)
                        );


                    /*
                    |--------------------------------------------------------------------------
                    | Hash password
                    |--------------------------------------------------------------------------
                    */

                    $passwordHash =
                        password_hash(
                            $newPassword,
                            PASSWORD_DEFAULT
                        );


                    $stmt = $pdo->prepare("
                        UPDATE users
                        SET password = ?
                        WHERE id = ?
                    ");


                    $stmt->execute([
                        $passwordHash,
                        $targetId
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | AUDIT LOG
                    |--------------------------------------------------------------------------
                    */

                    $historyStmt = $pdo->prepare("
                        INSERT INTO user_action_history
                        (user_id, action, changes, created_at)
                        VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ");

                    $historyStmt->execute([
                        $targetId,
                        'Password Reset',
                        'Password reset forced by admin'
                    ]);


                    $msg =
                        "Password reset successfully. "
                        . "Temporary password: "
                        . $newPassword;

                } catch (Throwable $e) {

                    $error =
                        "Unable to reset password: "
                        . $e->getMessage();

                }

            }


            /*
            |--------------------------------------------------------------------------
            | DEACTIVATE USER
            |--------------------------------------------------------------------------
            */

            elseif ($action === 'deactivate') {

                if (
                    $target['ncgr_id']
                    ===
                    $primaryAdminNcgr
                ) {

                    $error =
                        "ADMIN001 cannot be deactivated.";

                } else {

                    try {

                        $stmt = $pdo->prepare("
                            UPDATE users
                            SET is_approved = 0
                            WHERE id = ?
                        ");


                        $stmt->execute([
                            $targetId
                        ]);


                        /*
                        |--------------------------------------------------------------------------
                        | AUDIT LOG
                        |--------------------------------------------------------------------------
                        */

                        $historyStmt = $pdo->prepare("
                            INSERT INTO user_action_history
                            (user_id, action, changes, created_at)
                            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                        ");

                        $historyStmt->execute([
                            $targetId,
                            'Deactivated',
                            'User account deactivated'
                        ]);


                        $msg =
                            "User deactivated successfully.";

                    } catch (Throwable $e) {

                        $error =
                            "Unable to deactivate user: "
                            . $e->getMessage();

                    }

                }

            }


            /*
            |--------------------------------------------------------------------------
            | DELETE USER
            |--------------------------------------------------------------------------
            */

            elseif ($action === 'delete') {

                if (
                    $targetId == $_SESSION['user_id']
                    ||
                    $target['ncgr_id']
                    ===
                    $primaryAdminNcgr
                ) {

                    $error =
                        "Administrator account cannot be deleted.";

                } else {

                    try {

                        /*
                        |--------------------------------------------------------------------------
                        | AUDIT LOG BEFORE DELETE
                        |--------------------------------------------------------------------------
                        */

                        $historyStmt = $pdo->prepare("
                            INSERT INTO user_action_history
                            (user_id, action, changes, created_at)
                            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                        ");

                        $historyStmt->execute([
                            $targetId,
                            'Deleted',
                            "User deleted: " . ($target['first_name'] ?? '') . " " . ($target['last_name'] ?? '')
                        ]);


                        $stmt = $pdo->prepare("
                            DELETE FROM users
                            WHERE id = ?
                        ");


                        $stmt->execute([
                            $targetId
                        ]);


                        $msg =
                            "User deleted successfully.";

                    } catch (Throwable $e) {

                        $error =
                            "Unable to delete user: "
                            . $e->getMessage();

                    }

                }

            }

        }

    }

}


/*
|--------------------------------------------------------------------------
| RELOAD ROLES
|--------------------------------------------------------------------------
|
| In case permission.php created a new role before this page was opened.
|
|--------------------------------------------------------------------------
*/

$roles = $pdo->query("
    SELECT
        id,
        role_name,
        is_system,
        is_locked
    FROM roles
    ORDER BY
        CASE role_name
            WHEN 'Admin' THEN 1
            WHEN 'Edit' THEN 2
            WHEN 'Read-only' THEN 3
            ELSE 4
        END,
        role_name
")->fetchAll(PDO::FETCH_ASSOC);


$roleNames = [];

foreach ($roles as $role) {

    $roleNames[] =
        trim($role['role_name']);

}


/*
|--------------------------------------------------------------------------
| LOAD TEAMS
|--------------------------------------------------------------------------
|
| Read after the team POST handler above so a team just added or deleted
| is reflected on this same render. $teamOptions drives every team
| dropdown on the page; $teamRegistry additionally carries member counts
| and backs the Manage Teams modal.
|
| Loaded once here rather than inside the per-user table loop, where the
| list used to be rebuilt (as a hardcoded array) for every row.
|
*/

$teamRegistry = getTeamsWithMemberCounts($pdo);

$teamOptions = array_map(
    static fn(array $t): string => $t['team_name'],
    $teamRegistry
);


/*
|--------------------------------------------------------------------------
| PAGINATION & SORTING
|--------------------------------------------------------------------------
*/

$page = max(1, (int)($_GET['page'] ?? 1));
$per_page = resolveUserPageSize($pdo, (int) $_SESSION['user_id']);

$sort_by = trim($_GET['sort_by'] ?? 'id');
$sort_order = strtoupper(trim($_GET['sort_order'] ?? 'DESC'));

$allowed_sorts = ['id', 'first_name', 'last_name', 'email', 'ncgr_id', 'team', 'role'];
if (!in_array($sort_by, $allowed_sorts)) {
    $sort_by = 'id';
}

if ($sort_order !== 'ASC' && $sort_order !== 'DESC') {
    $sort_order = 'DESC';
}

$search_query = trim($_GET['search_query'] ?? '');
$search_field = trim($_GET['search_field'] ?? '');
$search_operator = trim($_GET['search_operator'] ?? 'AND');

// Validate search operator
if ($search_operator !== 'AND' && $search_operator !== 'OR') {
    $search_operator = 'AND';
}


/*
|--------------------------------------------------------------------------
| FETCH PENDING USERS
|--------------------------------------------------------------------------
*/

$where_pending = 'WHERE is_approved = 0';
$params_pending = [];

$pending_users = $pdo->query("
    SELECT *
    FROM users
    $where_pending
    ORDER BY $sort_by $sort_order
")->fetchAll(PDO::FETCH_ASSOC);

$pending_total = count($pending_users);


/*
|--------------------------------------------------------------------------
| FETCH APPROVED USERS (WITH PAGINATION)
|--------------------------------------------------------------------------
*/

$where_approved = 'WHERE is_approved = 1';
$params_approved = [];

if (!empty($search_query)) {
    $search_term = "%$search_query%";

    if (!empty($search_field)) {
        $where_approved .= " AND $search_field LIKE ?";
        $params_approved[] = $search_term;
    } else {
        $where_approved .= " AND (
            first_name LIKE ? OR
            last_name LIKE ? OR
            email LIKE ? OR
            ncgr_id LIKE ? OR
            team LIKE ? OR
            role LIKE ?
        )";
        array_push($params_approved, $search_term, $search_term, $search_term, $search_term, $search_term, $search_term);
    }
}

// Get total count for pagination
$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM users $where_approved");
$count_stmt->execute($params_approved);
$total_approved = (int)$count_stmt->fetchColumn();

$total_pages = max(1, ceil($total_approved / $per_page));
if ($page > $total_pages) {
    $page = $total_pages;
}

$offset = ($page - 1) * $per_page;

$stmt = $pdo->prepare("
    SELECT *
    FROM users
    $where_approved
    ORDER BY $sort_by $sort_order
    LIMIT ? OFFSET ?
");

$stmt->execute(array_merge($params_approved, [$per_page, $offset]));
$approved_users = $stmt->fetchAll(PDO::FETCH_ASSOC);


/*
|--------------------------------------------------------------------------
| STATISTICS
|--------------------------------------------------------------------------
*/

$total_users =
    count($approved_users);


$total_pending =
    count($pending_users);


$total_admins =
    $pdo->query("
        SELECT COUNT(*)
        FROM users
        WHERE role = 'Admin'
        AND is_approved = 1
    ")->fetchColumn();


$total_editors =
    $pdo->query("
        SELECT COUNT(*)
        FROM users
        WHERE role = 'Edit'
        AND is_approved = 1
    ")->fetchColumn();


/*
|--------------------------------------------------------------------------
| COMMON LAYOUT
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/header.php';

require_once __DIR__ . '/includes/sidebar.php';

?>


<div class="content">


<style>

/* =========================================================
   PAGE
========================================================= */

.users-container {

    max-width: 1400px;

    margin: 25px auto;

}


/* =========================================================
   PAGE HEADER
========================================================= */

.page-title {

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

    margin-bottom: 25px;

}

.page-title h1 {

    margin: 0;

    color: var(--text-primary);

    font-size: 30px;

}

.page-title p {

    margin: 6px 0 0;

    color: var(--text-secondary);

}


/* =========================================================
   BUTTON
========================================================= */

.permission-btn {

    display: inline-flex;

    align-items: center;

    gap: 8px;

    text-decoration: none;

    background: #2563eb;

    color: #fff;

    padding: 11px 17px;

    border-radius: 8px;

    font-weight: 700;

}

.permission-btn:hover {

    background: #1d4ed8;

    color: #fff;

}


/* =========================================================
   MANAGE TEAMS
========================================================= */

.team-btn-count {

    display: inline-block;

    min-width: 20px;

    padding: 1px 7px;

    border-radius: 999px;

    background: rgba(255, 255, 255, .25);

    font-size: 12px;

    font-weight: 700;

    text-align: center;

}

.team-table {

    width: 100%;

    border-collapse: collapse;

    font-size: 14px;

}

.team-table th {

    text-align: left;

    padding: 9px 10px;

    font-size: 11.5px;

    font-weight: 700;

    letter-spacing: .05em;

    text-transform: uppercase;

    color: var(--text-secondary);

    border-bottom: 1px solid var(--border-color);

}

.team-table td {

    padding: 11px 10px;

    border-bottom: 1px solid var(--border-light);

    color: var(--text-primary);

    vertical-align: middle;

}

.team-table tr:last-child td {

    border-bottom: none;

}

.team-name {

    font-weight: 600;

    color: var(--text-primary);

}

.team-members {

    display: inline-block;

    padding: 2px 9px;

    border-radius: 999px;

    background: var(--hover-bg);

    color: var(--text-secondary);

    font-size: 12px;

    font-weight: 600;

}

.team-members.is-empty {

    background: var(--hover-bg);

    color: var(--text-muted);

}

.team-delete-btn {

    border: 1px solid #fecaca;

    background: #fef2f2;

    color: #b91c1c;

    padding: 6px 12px;

    border-radius: 7px;

    font-size: 12.5px;

    font-weight: 600;

    font-family: inherit;

    cursor: pointer;

}

.team-delete-btn:hover {

    background: #fee2e2;

}

.team-delete-btn:disabled {

    border-color: var(--border-color);

    background: var(--hover-bg);

    color: #cbd5e1;

    cursor: not-allowed;

}


/* =========================================================
   ALERTS
========================================================= */

.alert {

    padding: 14px 17px;

    border-radius: 9px;

    margin-bottom: 20px;

    font-weight: 600;

}

.alert-success {

    background: #dcfce7;

    color: #166534;

    border: 1px solid #bbf7d0;

}

.alert-error {

    background: #fee2e2;

    color: #991b1b;

    border: 1px solid #fecaca;

}


/* =========================================================
   STATISTICS
========================================================= */

.user-stats {

    display: grid;

    grid-template-columns:
        repeat(4, 1fr);

    gap: 18px;

    margin-bottom: 25px;

}

.dashboard-card {

    background: var(--bg-content);

    border: 1px solid var(--border-color);

    border-radius: 12px;

    padding: 22px;

    box-shadow:
        0 4px 15px rgba(0,0,0,.05);

}

.dashboard-card span {

    color: var(--text-secondary);

    font-size: 14px;

    font-weight: 600;

}

.dashboard-card h2 {

    margin: 7px 0 0;

    color: var(--text-primary);

    font-size: 30px;

}


/* =========================================================
   CARD
========================================================= */

.admin-card {

    background: var(--bg-content);

    border: 1px solid var(--border-color);

    border-radius: 12px;

    margin-bottom: 25px;

    overflow: hidden;

    box-shadow:
        0 4px 15px rgba(0,0,0,.05);

}


/* =========================================================
   CARD HEADER
========================================================= */

.card-header {

    padding: 20px 22px;

    border-bottom: 1px solid var(--border-color);

    display: flex;

    justify-content: space-between;

    align-items: center;

    gap: 20px;

}

.card-header h2 {

    margin: 0;

    color: var(--text-primary);

    font-size: 20px;

}

.card-header p {

    margin: 5px 0 0;

    color: var(--text-secondary);

    font-size: 14px;

}


/* =========================================================
   SEARCH
========================================================= */

.search-box {

    max-width: 300px;

}


/* =========================================================
   TABLE
========================================================= */

.table-responsive {

    width: 100%;

    overflow-x: auto;

}

.admin-table {

    width: 100%;

    border-collapse: collapse;

    min-width: 950px;

}

.admin-table th {

    background: var(--hover-bg);

    color: var(--text-secondary);

    font-size: 13px;

    text-transform: uppercase;

    letter-spacing: .03em;

    padding: 14px 16px;

    text-align: left;

    border-bottom: 1px solid var(--border-color);

}

.admin-table td {

    padding: 15px 16px;

    border-bottom: 1px solid var(--border-color);

    vertical-align: middle;

}

.admin-table tbody tr:hover {

    background: var(--hover-bg);

}


/* =========================================================
   USER
========================================================= */

.user-name {

    display: flex;

    flex-direction: column;

    gap: 4px;

}

.user-name strong {

    color: var(--text-primary);

}

.user-name small {

    color: var(--text-secondary);

}


/* =========================================================
   FORM
========================================================= */

.form-control {

    width: 100%;

    padding: 9px 11px;

    border: 1px solid var(--border-color);

    border-radius: 7px;

    background: var(--bg-content);

    color: var(--text-primary);

    box-sizing: border-box;

}

.user-phone-input {

    padding: 5px 8px;

    font-size: 12.5px;

    margin-top: 2px;

}

.form-control:focus {

    outline: none;

    border-color: #2563eb;

    box-shadow:
        0 0 0 3px rgba(37,99,235,.12);

}


/* =========================================================
   BADGES
========================================================= */

.badge {

    display: inline-block;

    padding: 5px 9px;

    border-radius: 6px;

    font-size: 12px;

    font-weight: 700;

}

.badge-admin {

    background: #fee2e2;

    color: #991b1b;

}

.badge-role {

    background: #dbeafe;

    color: #1e40af;

}

.badge-ldap {

    background: #ede9fe;

    color: #5b21b6;

}

.badge-local {

    background: var(--hover-bg);

    color: var(--text-secondary);

}


/* =========================================================
   LOCKED
========================================================= */

.locked-field {

    display: inline-block;

    background: var(--hover-bg);

    color: var(--text-secondary);

    padding: 9px 11px;

    border-radius: 7px;

    font-weight: 600;

}


/* =========================================================
   BUTTONS
========================================================= */

.btn {

    border: 0;

    padding: 9px 13px;

    border-radius: 7px;

    cursor: pointer;

    font-weight: 700;

    white-space: nowrap;

}

.btn-primary {

    background: #2563eb;

    color: #fff;

}

.btn-primary:hover {

    background: #1d4ed8;

}

.btn-purple {

    background: #7c3aed;

    color: #fff;

}

.btn-purple:hover {

    background: #6d28d9;

}

.btn-warning {

    background: #f59e0b;

    color: #fff;

}

.btn-warning:hover {

    background: #d97706;

}

.btn-danger {

    background: #dc2626;

    color: #fff;

}

.btn-danger:hover {

    background: #b91c1c;

}


/* =========================================================
   ACTION BUTTONS
========================================================= */

.action-buttons {

    display: flex;

    gap: 7px;

    flex-wrap: wrap;

}


/* =========================================================
   EMPTY
========================================================= */

.empty-state {

    text-align: center;

    padding: 35px;

    color: var(--text-secondary);

}


/* =========================================================
   MOBILE
========================================================= */

@media(max-width: 900px) {

    .user-stats {

        grid-template-columns:
            repeat(2, 1fr);

    }

    .page-title {

        flex-direction: column;

        align-items: flex-start;

    }

}

@media(max-width: 600px) {

    .user-stats {

        grid-template-columns: 1fr;

    }

    .card-header {

        flex-direction: column;

        align-items: flex-start;

    }

    .search-box {

        max-width: 100%;

    }

}

</style>


<div class="users-container">


<!-- =========================================================
     PAGE HEADER
========================================================= -->

<div class="page-title">

    <div>

        <h1>
            User Management
        </h1>

        <p>
            Manage user accounts, roles and permissions.
        </p>

    </div>


    <div style="display: flex; gap: 10px; flex-wrap: wrap;">

        <a
            href="permission.php"
            class="permission-btn"
        >

            🛡️ Manage Permissions

        </a>


        <?php if ($canEdit || $canDelete): ?>

            <button
                type="button"
                class="permission-btn"
                onclick="showTeamsModal()"
                style="background: #0ea5e9; cursor: pointer;"
            >

                👥 Manage Teams
                <span class="team-btn-count"><?= count($teamRegistry) ?></span>

            </button>

        <?php endif; ?>

        <?php if ($canExport): ?>

            <button
                type="button"
                class="permission-btn"
                onclick="exportApprovedUsers()"
                style="background: #6366f1; cursor: pointer;"
            >

                📥 Export Users

            </button>

        <?php endif; ?>

        <?php if ($canImport): ?>

            <button
                type="button"
                class="permission-btn"
                onclick="showImportModal()"
                style="background: #8b5cf6; cursor: pointer;"
            >

                📤 Import Users

            </button>

        <?php endif; ?>

        <?php if ($canAudit): ?>

            <button
                type="button"
                class="permission-btn"
                onclick="showGlobalHistory()"
                style="background: #ec4899; cursor: pointer;"
            >

                ⏱️ History

            </button>

        <?php endif; ?>

    </div>

</div>


<!-- =========================================================
     MESSAGES
========================================================= -->

<?php if ($msg !== ''): ?>

    <div class="alert alert-success">

        ✓ <?= h($msg) ?>

    </div>

<?php endif; ?>


<?php if ($error !== ''): ?>

    <div class="alert alert-error">

        <strong>Error:</strong>

        <?= h($error) ?>

    </div>

<?php endif; ?>


<!-- =========================================================
     STATISTICS
========================================================= -->

<div class="user-stats">


    <div class="dashboard-card">

        <span>
            Active Users
        </span>

        <h2>
            <?= (int)$total_users ?>
        </h2>

    </div>


    <div class="dashboard-card">

        <span>
            Pending
        </span>

        <h2>
            <?= (int)$total_pending ?>
        </h2>

    </div>


    <div class="dashboard-card">

        <span>
            Admins
        </span>

        <h2>
            <?= (int)$total_admins ?>
        </h2>

    </div>


    <div class="dashboard-card">

        <span>
            Editors
        </span>

        <h2>
            <?= (int)$total_editors ?>
        </h2>

    </div>


</div>


<!-- =========================================================
     PENDING APPROVALS
========================================================= -->

<section class="admin-card">


    <div class="card-header">

        <div>

            <h2>
                Pending Approvals
            </h2>

            <p>
                Approve new users and assign their role.
            </p>

        </div>

    </div>


    <div class="table-responsive">


        <table class="admin-table">


            <thead>

                <tr>

                    <th>
                        User
                    </th>

                    <th>
                        NCGR ID
                    </th>

                    <th>
                        Team
                    </th>

                    <th>
                        Role
                    </th>

                    <th>
                        Action
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php if (empty($pending_users)): ?>

                <tr>

                    <td
                        colspan="5"
                        class="empty-state"
                    >

                        No pending users.

                    </td>

                </tr>

            <?php endif; ?>


            <?php foreach ($pending_users as $user): ?>


                <?php

                $formId =
                    'approve_form_' . (int)$user['id'];

                ?>


                <tr>


                    <!-- USER -->

                    <td>

                        <form
                            id="<?= h($formId) ?>"
                            method="POST"
                            action="users.php"
                        >

                            <input
                                type="hidden"
                                name="user_id"
                                value="<?= (int)$user['id'] ?>"
                            >

                        </form>


                        <div class="user-name">

                            <strong>

                                <?= h(
                                    $user['first_name']
                                    . ' '
                                    . $user['last_name']
                                ) ?>

                            </strong>

                            <?php if (($user['auth_source'] ?? 'local') === 'ldap'): ?>
                                <span class="badge badge-ldap">LDAP</span>
                            <?php else: ?>
                                <span class="badge badge-local">Local</span>
                            <?php endif; ?>


                            <small>

                                <?= h($user['email']) ?>

                            </small>

                        </div>

                    </td>


                    <!-- NCGR -->

                    <td>

                        <?= h($user['ncgr_id']) ?>

                    </td>


                    <!-- TEAM -->

                    <td>

                        <?php if (
                            $user['ncgr_id']
                            ===
                            $primaryAdminNcgr
                        ): ?>

                            <input
                                type="hidden"
                                name="team"
                                value="Linux"
                                form="<?= h($formId) ?>"
                            >

                            <span class="locked-field">

                                Linux 🔒

                            </span>

                        <?php else: ?>

                            <select
                                name="team"
                                class="form-control"
                                form="<?= h($formId) ?>"
                            >

                                <?php
                                /*
                                | A team name held by this user but absent
                                | from the registry is offered anyway, and
                                | flagged. Without it the select would show
                                | some other team as chosen and quietly
                                | reassign the user on the next save.
                                */
                                if (
                                    trim((string)($user['team'] ?? '')) !== ''
                                    &&
                                    !in_array($user['team'], $teamOptions, true)
                                ): ?>

                                    <option value="<?= h($user['team']) ?>" selected>
                                        <?= h($user['team']) ?> (unlisted)
                                    </option>

                                <?php endif; ?>

                                <?php foreach ($teamOptions as $team): ?>

                                    <option
                                        value="<?= h($team) ?>"
                                        <?= $user['team'] === $team
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= h($team) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        <?php endif; ?>

                    </td>


                    <!-- ROLE -->

                    <td>

                        <?php if (
                            $user['ncgr_id']
                            ===
                            $primaryAdminNcgr
                        ): ?>

                            <input
                                type="hidden"
                                name="role"
                                value="Admin"
                                form="<?= h($formId) ?>"
                            >

                            <span class="badge badge-admin">

                                Admin 🔒

                            </span>

                        <?php else: ?>

                            <select
                                name="role"
                                class="form-control"
                                form="<?= h($formId) ?>"
                            >

                                <?php foreach ($roles as $role): ?>

                                    <option
                                        value="<?= h($role['role_name']) ?>"
                                        <?= $user['role'] === $role['role_name']
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= h($role['role_name']) ?>

                                        <?php if (
                                            (int)$role['is_locked'] === 1
                                        ): ?>

                                            🔒

                                        <?php endif; ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        <?php endif; ?>

                    </td>


                    <!-- ACTION -->

                    <td>

                        <div class="action-buttons">


                            <button
                                type="submit"
                                name="action"
                                value="approve"
                                class="btn btn-primary"
                                form="<?= h($formId) ?>"
                            >

                                ✓ Approve

                            </button>


                            <button
                                type="submit"
                                name="action"
                                value="delete"
                                class="btn btn-danger"
                                form="<?= h($formId) ?>"
                                onclick="return confirm('Reject and delete this user?')"
                            >

                                ✕ Reject

                            </button>


                        </div>

                    </td>


                </tr>


            <?php endforeach; ?>


            </tbody>

        </table>

    </div>

</section>


<!-- =========================================================
     ACTIVE USERS
========================================================= -->

<section class="admin-card">


    <div class="card-header">

        <div>

            <h2>
                Active Users
            </h2>

            <p>
                Manage approved accounts and permissions.
            </p>

        </div>

    </div>

    <div style="padding: 15px 22px; border-bottom: 1px solid var(--border-color); display: flex; gap: 15px; flex-wrap: wrap; align-items: center;">

        <input
            type="text"
            id="searchQuery"
            class="form-control"
            placeholder="Search by name, email, NCGR ID..."
            style="flex: 1; min-width: 250px; max-width: 400px;"
            value="<?= h($search_query) ?>"
        >

        <select
            id="searchField"
            class="form-control"
            style="max-width: 200px;"
        >

            <option value="">All Fields</option>
            <option value="first_name" <?= $search_field === 'first_name' ? 'selected' : '' ?>>First Name</option>
            <option value="last_name" <?= $search_field === 'last_name' ? 'selected' : '' ?>>Last Name</option>
            <option value="email" <?= $search_field === 'email' ? 'selected' : '' ?>>Email</option>
            <option value="ncgr_id" <?= $search_field === 'ncgr_id' ? 'selected' : '' ?>>NCGR ID</option>
            <option value="team" <?= $search_field === 'team' ? 'selected' : '' ?>>Team</option>
            <option value="role" <?= $search_field === 'role' ? 'selected' : '' ?>>Role</option>

        </select>

        <select
            id="searchOperator"
            class="form-control"
            style="max-width: 150px;"
        >

            <option value="AND" <?= $search_operator === 'AND' ? 'selected' : '' ?>>AND</option>
            <option value="OR" <?= $search_operator === 'OR' ? 'selected' : '' ?>>OR</option>

        </select>

        <button
            type="button"
            class="btn btn-primary"
            onclick="performSearch()"
            style="white-space: nowrap;"
        >

            🔍 Search

        </button>

        <button
            type="button"
            class="btn"
            onclick="clearSearch()"
            style="white-space: nowrap; background: var(--border-color); color: var(--text-primary);"
        >

            ✕ Clear

        </button>

        <?php
            $users_hidden_fields = '';
            foreach ([
                'sort_by' => $sort_by,
                'sort_order' => $sort_order,
                'search_query' => $search_query,
                'search_field' => $search_field,
                'search_operator' => $search_operator,
            ] as $ufk => $ufv) {
                if ($ufv !== '') {
                    $users_hidden_fields .= '<input type="hidden" name="' . h($ufk) . '" value="' . h($ufv) . '">';
                }
            }
        ?>
        <?= pageSizeSelectorHtml($per_page, $users_hidden_fields) ?>

    </div>


    <div class="table-responsive">


        <table
            class="admin-table"
            id="usersTable"
        >


            <thead>

                <tr>

                    <th style="cursor: pointer;" onclick="sortBy('first_name')">
                        User <?php if ($sort_by === 'first_name'): ?><?= $sort_order === 'ASC' ? '↑' : '↓' ?><?php endif; ?>
                    </th>

                    <th style="cursor: pointer;" onclick="sortBy('ncgr_id')">
                        NCGR ID <?php if ($sort_by === 'ncgr_id'): ?><?= $sort_order === 'ASC' ? '↑' : '↓' ?><?php endif; ?>
                    </th>

                    <th style="cursor: pointer;" onclick="sortBy('team')">
                        Team <?php if ($sort_by === 'team'): ?><?= $sort_order === 'ASC' ? '↑' : '↓' ?><?php endif; ?>
                    </th>

                    <th style="cursor: pointer;" onclick="sortBy('role')">
                        Role <?php if ($sort_by === 'role'): ?><?= $sort_order === 'ASC' ? '↑' : '↓' ?><?php endif; ?>
                    </th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>


            <?php if (empty($approved_users)): ?>

                <tr>

                    <td
                        colspan="5"
                        class="empty-state"
                    >

                        No active users.

                    </td>

                </tr>

            <?php endif; ?>


            <?php foreach ($approved_users as $user): ?>


                <?php

                $formId =
                    'user_form_' . (int)$user['id'];

                ?>


                <tr>


                    <!-- =================================================
                         USER
                    ================================================== -->

                    <td>

                        <form
                            id="<?= h($formId) ?>"
                            method="POST"
                            action="users.php"
                        >

                            <input
                                type="hidden"
                                name="user_id"
                                value="<?= (int)$user['id'] ?>"
                            >

                        </form>


                        <div class="user-name">

                            <strong>

                                <?= h(
                                    $user['first_name']
                                    . ' '
                                    . $user['last_name']
                                ) ?>

                            </strong>

                            <?php if (($user['auth_source'] ?? 'local') === 'ldap'): ?>
                                <span class="badge badge-ldap">LDAP</span>
                            <?php else: ?>
                                <span class="badge badge-local">Local</span>
                            <?php endif; ?>


                            <small>

                                <?= h($user['email']) ?>

                            </small>

                            <input
                                type="tel"
                                name="phone"
                                class="form-control user-phone-input"
                                placeholder="Phone number"
                                value="<?= h($user['phone'] ?? '') ?>"
                                form="<?= h($formId) ?>"
                            >

                        </div>

                    </td>


                    <!-- =================================================
                         NCGR ID
                    ================================================== -->

                    <td>

                        <?= h($user['ncgr_id']) ?>


                        <?php if (
                            $user['ncgr_id']
                            ===
                            $primaryAdminNcgr
                        ): ?>

                            <br>

                            <span class="badge badge-admin">

                                Primary Admin

                            </span>

                        <?php endif; ?>

                    </td>


                    <!-- =================================================
                         TEAM
                    ================================================== -->

                    <td>

                        <?php if (
                            $user['ncgr_id']
                            ===
                            $primaryAdminNcgr
                        ): ?>


                            <input
                                type="hidden"
                                name="team"
                                value="Linux"
                                form="<?= h($formId) ?>"
                            >


                            <span class="locked-field">

                                Linux 🔒

                            </span>


                        <?php else: ?>


                            <select
                                name="team"
                                class="form-control"
                                form="<?= h($formId) ?>"
                            >

                                <?php
                                /* See the note on the approved-users
                                   dropdown above: an unlisted team the
                                   user already holds stays selectable. */
                                if (
                                    trim((string)($user['team'] ?? '')) !== ''
                                    &&
                                    !in_array($user['team'], $teamOptions, true)
                                ): ?>

                                    <option value="<?= h($user['team']) ?>" selected>
                                        <?= h($user['team']) ?> (unlisted)
                                    </option>

                                <?php endif; ?>

                                <?php foreach ($teamOptions as $team): ?>

                                    <option
                                        value="<?= h($team) ?>"
                                        <?= $user['team'] === $team
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= h($team) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>


                        <?php endif; ?>

                    </td>


                    <!-- =================================================
                         ROLE
                    ================================================== -->

                    <td>


                        <?php if (
                            $user['ncgr_id']
                            ===
                            $primaryAdminNcgr
                        ): ?>


                            <input
                                type="hidden"
                                name="role"
                                value="Admin"
                                form="<?= h($formId) ?>"
                            >


                            <span class="badge badge-admin">

                                Admin 🔒

                            </span>


                        <?php else: ?>


                            <select
                                name="role"
                                class="form-control"
                                form="<?= h($formId) ?>"
                            >


                                <?php foreach ($roles as $role): ?>


                                    <option
                                        value="<?= h($role['role_name']) ?>"
                                        <?= $user['role'] === $role['role_name']
                                            ? 'selected'
                                            : '' ?>
                                    >

                                        <?= h($role['role_name']) ?>


                                        <?php if (
                                            (int)$role['is_locked'] === 1
                                        ): ?>

                                            🔒

                                        <?php endif; ?>


                                    </option>


                                <?php endforeach; ?>


                            </select>


                        <?php endif; ?>


                    </td>


                    <!-- =================================================
                         ACTIONS
                    ================================================== -->

                    <td>


                        <div class="action-buttons">


                            <button
                                type="submit"
                                name="action"
                                value="update_details"
                                class="btn btn-primary"
                                form="<?= h($formId) ?>"
                            >

                                ✏️ Update

                            </button>


                            <button
                                type="submit"
                                name="action"
                                value="force_password_change"
                                class="btn btn-purple"
                                form="<?= h($formId) ?>"
                                onclick="return confirm('Reset password for this user?')"
                            >

                                🔑 Reset

                            </button>


                            <?php if ($canAudit): ?>

                                <button
                                    type="button"
                                    class="btn"
                                    onclick="showUserHistory(<?= (int)$user['id'] ?>)"
                                    style="background: #ec4899; color: #fff;"
                                >

                                    ⏱️ Audit

                                </button>

                            <?php endif; ?>


                            <?php if (
                                $user['ncgr_id']
                                !==
                                $primaryAdminNcgr
                            ): ?>


                                <button
                                    type="submit"
                                    name="action"
                                    value="deactivate"
                                    class="btn btn-warning"
                                    form="<?= h($formId) ?>"
                                    onclick="return confirm('Deactivate this user?')"
                                >

                                    ⏸️ Disable

                                </button>


                                <?php if ($canDelete): ?>

                                    <button
                                        type="submit"
                                        name="action"
                                        value="delete"
                                        class="btn btn-danger"
                                        form="<?= h($formId) ?>"
                                        onclick="return confirm('Delete this user permanently?')"
                                    >

                                        🗑️ Delete

                                    </button>

                                <?php endif; ?>


                            <?php endif; ?>


                        </div>


                    </td>


                </tr>


            <?php endforeach; ?>


            </tbody>

        </table>

    </div>

    <?php if ($total_pages > 1): ?>

        <div style="padding: 15px 22px; border-top: 1px solid var(--border-color); display: flex; justify-content: center; gap: 8px; flex-wrap: wrap; align-items: center;">

            <?php if ($page > 1): ?>

                <a
                    href="?page=1&sort_by=<?= h($sort_by) ?>&sort_order=<?= h($sort_order) ?>&page_size=<?= (int)$per_page ?>&search_query=<?= h($search_query) ?>&search_field=<?= h($search_field) ?>&search_operator=<?= h($search_operator) ?>"
                    class="btn"
                    style="background: #2563eb; color: #fff;"
                >

                    ⬅️ First

                </a>

                <a
                    href="?page=<?= (int)($page - 1) ?>&sort_by=<?= h($sort_by) ?>&sort_order=<?= h($sort_order) ?>&page_size=<?= (int)$per_page ?>&search_query=<?= h($search_query) ?>&search_field=<?= h($search_field) ?>&search_operator=<?= h($search_operator) ?>"
                    class="btn"
                    style="background: #2563eb; color: #fff;"
                >

                    ← Prev

                </a>

            <?php endif; ?>

            <span style="color: var(--text-secondary); font-weight: 600;">

                Page <?= (int)$page ?> of <?= (int)$total_pages ?>

            </span>

            <?php if ($page < $total_pages): ?>

                <a
                    href="?page=<?= (int)($page + 1) ?>&sort_by=<?= h($sort_by) ?>&sort_order=<?= h($sort_order) ?>&page_size=<?= (int)$per_page ?>&search_query=<?= h($search_query) ?>&search_field=<?= h($search_field) ?>&search_operator=<?= h($search_operator) ?>"
                    class="btn"
                    style="background: #2563eb; color: #fff;"
                >

                    Next →

                </a>

                <a
                    href="?page=<?= (int)$total_pages ?>&sort_by=<?= h($sort_by) ?>&sort_order=<?= h($sort_order) ?>&page_size=<?= (int)$per_page ?>&search_query=<?= h($search_query) ?>&search_field=<?= h($search_field) ?>&search_operator=<?= h($search_operator) ?>"
                    class="btn"
                    style="background: #2563eb; color: #fff;"
                >

                    Last ➡️

                </a>

            <?php endif; ?>

        </div>

    <?php endif; ?>

</section>


<!-- ==========================================================
     HISTORY MODAL
========================================================= -->

<div
    id="historyModal"
    style="
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,.5);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    "
>

    <div style="background: var(--bg-content); border-radius: 12px; width: 90%; max-width: 700px; max-height: 80vh; overflow-y: auto; padding: 30px; box-shadow: 0 20px 60px rgba(0,0,0,.3);">

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px;">

            <h3 style="margin: 0; color: var(--text-primary); font-size: 20px;">

                ⏱️ User Action History

            </h3>

            <button
                type="button"
                onclick="closeHistoryModal()"
                style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);"
            >

                ✕

            </button>

        </div>

        <div id="historyContent" style="color: var(--text-secondary);">

            Loading...

        </div>

    </div>

</div>


<!-- ==========================================================
     MANAGE TEAMS MODAL
========================================================= -->

<?php if ($canEdit || $canDelete): ?>

<div
    id="teamsModal"
    style="
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,.5);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    "
>

    <div style="background: var(--bg-content); border-radius: 12px; width: 90%; max-width: 620px; max-height: 85vh; overflow-y: auto; padding: 30px; box-shadow: 0 20px 60px rgba(0,0,0,.3);">

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px;">

            <h3 style="margin: 0; color: var(--text-primary); font-size: 20px;">

                👥 Manage Teams

            </h3>

            <button
                type="button"
                onclick="closeTeamsModal()"
                style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);"
            >

                ✕

            </button>

        </div>


        <?php if ($canEdit): ?>

            <form method="POST" style="display: flex; gap: 10px; margin-bottom: 22px;">

                <input type="hidden" name="action" value="add_team">

                <input
                    type="text"
                    name="team_name"
                    class="form-control"
                    placeholder="New team name"
                    maxlength="60"
                    required
                    style="flex: 1;"
                >

                <button type="submit" class="btn btn-primary">

                    + Add Team

                </button>

            </form>

        <?php endif; ?>


        <table class="team-table">

            <thead>

                <tr>

                    <th>Team</th>

                    <th style="width: 110px;">Members</th>

                    <?php if ($canDelete): ?>

                        <th style="width: 100px; text-align: right;">Action</th>

                    <?php endif; ?>

                </tr>

            </thead>

            <tbody>

                <?php if (count($teamRegistry) === 0): ?>

                    <tr>

                        <td colspan="3" style="color: var(--text-muted); padding: 24px 10px;">

                            No teams defined yet.

                        </td>

                    </tr>

                <?php else: ?>

                    <?php foreach ($teamRegistry as $t): ?>

                        <?php $memberCount = (int) $t['member_count']; ?>

                        <tr>

                            <td>

                                <span class="team-name"><?= h($t['team_name']) ?></span>

                            </td>

                            <td>

                                <span class="team-members <?= $memberCount === 0 ? 'is-empty' : '' ?>">

                                    <?= $memberCount ?>

                                </span>

                            </td>

                            <?php if ($canDelete): ?>

                                <td style="text-align: right;">

                                    <?php if ($memberCount > 0): ?>

                                        <?php
                                        /*
                                        | Deleting a team that still has
                                        | members would orphan them:
                                        | users.team holds a name, not a
                                        | foreign key, so nothing would
                                        | fail -- those users would simply
                                        | point at a team that no longer
                                        | exists. The server refuses this
                                        | too; the disabled button just
                                        | makes the reason visible.
                                        */
                                        ?>

                                        <button
                                            type="button"
                                            class="team-delete-btn"
                                            disabled
                                            title="Move its <?= $memberCount ?> member<?= $memberCount === 1 ? '' : 's' ?> to another team first"
                                        >

                                            Delete

                                        </button>

                                    <?php else: ?>

                                        <form
                                            method="POST"
                                            style="display: inline;"
                                            onsubmit="return confirm('Delete the team <?= h(addslashes($t['team_name'])) ?>?');"
                                        >

                                            <input type="hidden" name="action" value="delete_team">

                                            <input type="hidden" name="team_id" value="<?= (int) $t['id'] ?>">

                                            <button type="submit" class="team-delete-btn">

                                                Delete

                                            </button>

                                        </form>

                                    <?php endif; ?>

                                </td>

                            <?php endif; ?>

                        </tr>

                    <?php endforeach; ?>

                <?php endif; ?>

            </tbody>

        </table>


        <p style="color: var(--text-secondary); font-size: 12.5px; margin: 18px 0 0; line-height: 1.6;">

            Teams here populate every team dropdown in the application,
            including the sign-up form. A team can only be deleted once no
            users are assigned to it.

        </p>


        <div style="display: flex; justify-content: flex-end; margin-top: 20px;">

            <button
                type="button"
                onclick="closeTeamsModal()"
                class="btn"
                style="background: var(--border-color); color: var(--text-primary);"
            >

                Close

            </button>

        </div>

    </div>

</div>

<?php endif; ?>


<!-- ==========================================================
     IMPORT MODAL
========================================================= -->

<div
    id="importModal"
    style="
        display: none;
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0,0,0,.5);
        z-index: 9999;
        justify-content: center;
        align-items: center;
    "
>

    <div style="background: var(--bg-content); border-radius: 12px; width: 90%; max-width: 600px; padding: 30px; box-shadow: 0 20px 60px rgba(0,0,0,.3);">

        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; border-bottom: 1px solid var(--border-color); padding-bottom: 15px;">

            <h3 style="margin: 0; color: var(--text-primary); font-size: 20px;">

                📤 Import Users

            </h3>

            <button
                type="button"
                onclick="closeImportModal()"
                style="background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary);"
            >

                ✕

            </button>

        </div>

        <form id="importForm" enctype="multipart/form-data">

            <p style="color: var(--text-secondary); margin: 0 0 20px;">

                Upload a CSV file with columns: First Name, Last Name, Email, NCGR ID, Team, Role

            </p>

            <input
                type="file"
                id="csvFile"
                name="csv"
                class="form-control"
                accept=".csv"
                required
                style="margin-bottom: 20px;"
            >

            <div style="display: flex; gap: 10px; justify-content: flex-end;">

                <button
                    type="button"
                    onclick="closeImportModal()"
                    class="btn"
                    style="background: var(--border-color); color: var(--text-primary);"
                >

                    Cancel

                </button>

                <button
                    type="button"
                    onclick="submitImport()"
                    class="btn btn-primary"
                >

                    📤 Import

                </button>

            </div>

        </form>

    </div>

</div>


</div>


</div>


<script>

/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/

function sortBy(field) {
    const currentSort = new URLSearchParams(window.location.search).get('sort_by');
    const currentOrder = new URLSearchParams(window.location.search).get('sort_order');

    let newOrder = 'DESC';
    if (currentSort === field && currentOrder === 'DESC') {
        newOrder = 'ASC';
    }

    const params = new URLSearchParams(window.location.search);
    params.set('sort_by', field);
    params.set('sort_order', newOrder);
    params.set('page', '1');

    window.location.search = params.toString();
}


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

function performSearch() {
    const query = document.getElementById('searchQuery').value;
    const field = document.getElementById('searchField').value;
    const operator = document.getElementById('searchOperator').value;

    const params = new URLSearchParams();
    params.set('search_query', query);
    params.set('search_field', field);
    params.set('search_operator', operator);
    params.set('page', '1');

    window.location.search = params.toString();
}

function clearSearch() {
    window.location.search = '';
}


/*
|--------------------------------------------------------------------------
| EXPORT
|--------------------------------------------------------------------------
*/

function exportApprovedUsers() {
    const params = new URLSearchParams(window.location.search);
    const searchQuery = params.get('search_query') || '';
    const searchField = params.get('search_field') || '';

    const form = document.createElement('form');
    form.method = 'POST';
    form.action = 'users.php';

    form.innerHTML = `
        <input type="hidden" name="action" value="export_users">
        <input type="hidden" name="is_approved" value="1">
        <input type="hidden" name="search_query" value="${searchQuery}">
        <input type="hidden" name="search_field" value="${searchField}">
    `;

    document.body.appendChild(form);
    form.submit();
    document.body.removeChild(form);
}


/*
|--------------------------------------------------------------------------
| MANAGE TEAMS MODAL
|--------------------------------------------------------------------------
|
| Add and delete post back as ordinary forms and reload the page, the
| same way every other write on this screen works -- the team list feeds
| the per-row dropdowns, which have to be re-rendered anyway.
*/

function showTeamsModal() {
    const modal = document.getElementById('teamsModal');
    if (modal) modal.style.display = 'flex';
}

function closeTeamsModal() {
    const modal = document.getElementById('teamsModal');
    if (modal) modal.style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| IMPORT MODAL
|--------------------------------------------------------------------------
*/

function showImportModal() {
    document.getElementById('importModal').style.display = 'flex';
}

function closeImportModal() {
    document.getElementById('importModal').style.display = 'none';
    document.getElementById('csvFile').value = '';
}

function submitImport() {
    const fileInput = document.getElementById('csvFile');
    const file = fileInput.files[0];

    if (!file) {
        alert('Please select a CSV file');
        return;
    }

    const formData = new FormData();
    formData.append('action', 'import_users');
    formData.append('csv', file);

    fetch('users-import.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(html => {
        closeImportModal();
        // Reload page to show updated results
        window.location.reload();
    })
    .catch(error => {
        alert('Import failed: ' + error);
    });
}


/*
|--------------------------------------------------------------------------
| AUDIT HISTORY
|--------------------------------------------------------------------------
*/

function showUserHistory(userId) {
    document.getElementById('historyModal').style.display = 'flex';

    const form = new FormData();
    form.append('action', 'get_history');
    form.append('user_id', userId);

    fetch('users.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.history && data.history.length > 0) {
            let html = '<table style="width: 100%; border-collapse: collapse;">';
            html += '<tr style="background: var(--hover-bg); border-bottom: 1px solid var(--border-color);"><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Action</th><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Changes</th><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Date</th></tr>';

            data.history.forEach(item => {
                html += `<tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 10px; color: var(--text-primary);">${item.action}</td>
                    <td style="padding: 10px; color: var(--text-secondary); font-size: 12px;">${item.changes || '-'}</td>
                    <td style="padding: 10px; color: var(--text-secondary); white-space: nowrap;">${item.created_at}</td>
                </tr>`;
            });

            html += '</table>';
            document.getElementById('historyContent').innerHTML = html;
        } else {
            document.getElementById('historyContent').innerHTML = '<p style="color: var(--text-secondary);">No history found for this user.</p>';
        }
    })
    .catch(error => {
        document.getElementById('historyContent').innerHTML = '<p style="color: #dc2626;">Error loading history: ' + error + '</p>';
    });
}

function showGlobalHistory() {
    document.getElementById('historyModal').style.display = 'flex';

    const form = new FormData();
    form.append('action', 'get_history');
    form.append('user_id', 'all');

    fetch('users.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.json())
    .then(data => {
        if (data.success && data.history && data.history.length > 0) {
            let html = '<table style="width: 100%; border-collapse: collapse;">';
            html += '<tr style="background: var(--hover-bg); border-bottom: 1px solid var(--border-color);"><th style="padding: 10px; text-align: left; color: var(--text-secondary);">User</th><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Action</th><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Changes</th><th style="padding: 10px; text-align: left; color: var(--text-secondary);">Date</th></tr>';

            data.history.forEach(item => {
                html += `<tr style="border-bottom: 1px solid var(--border-color);">
                    <td style="padding: 10px; color: var(--text-primary);">${item.user_id}</td>
                    <td style="padding: 10px; color: var(--text-primary);">${item.action}</td>
                    <td style="padding: 10px; color: var(--text-secondary); font-size: 12px;">${item.changes || '-'}</td>
                    <td style="padding: 10px; color: var(--text-secondary); white-space: nowrap;">${item.created_at}</td>
                </tr>`;
            });

            html += '</table>';
            document.getElementById('historyContent').innerHTML = html;
        } else {
            document.getElementById('historyContent').innerHTML = '<p style="color: var(--text-secondary);">No history found.</p>';
        }
    })
    .catch(error => {
        document.getElementById('historyContent').innerHTML = '<p style="color: #dc2626;">Error loading history: ' + error + '</p>';
    });
}

function closeHistoryModal() {
    document.getElementById('historyModal').style.display = 'none';
}

// Close modal when clicking outside
window.onclick = function(event) {
    const historyModal = document.getElementById('historyModal');
    const importModal = document.getElementById('importModal');
    const teamsModal = document.getElementById('teamsModal');

    if (teamsModal && event.target === teamsModal) {
        teamsModal.style.display = 'none';
    }

    if (event.target === historyModal) {
        historyModal.style.display = 'none';
    }
    if (event.target === importModal) {
        importModal.style.display = 'none';
    }
};

</script>


<?php

require_once __DIR__ . '/includes/footer.php';

?>
