<?php

session_start();
require 'config/db.php';
require_once 'includes/csv-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('known_issues', 'can_view');
requirePermission('known_issues', 'can_import');


$role = $_SESSION['role'] ?? 'User';

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

/* Delegates to the single authorization helper (includes/authz.php). */
function hasPermission(PDO $pdo, string $role, string $permission): bool
{
    return authzCan($pdo, $role, 'known_issues', $permission);
}

$canImport = hasPermission($pdo, $role, 'can_import');

if (!$canImport) {
    die("Permission denied");
}

$message = "";
$errors = [];
$imported = 0;
$skipped = 0;

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {

            // Normalised to column keys, so a file exported from this
            // module ("Issue Number", "Affected System") maps onto the
            // lowercase keys read below instead of importing blank rows.
            $header = csvNormaliseHeader((array) fgetcsv($handle));

            while (($row = fgetcsv($handle)) !== false) {

                $row = array_pad(array_slice($row, 0, count($header)), count($header), '');
                $data = array_combine($header, $row);

                // Extract required fields
                $title = trim($data['title'] ?? '');
                $issue_number = trim($data['issue_number'] ?? '');

                if (!$title) {
                    $skipped++;
                    continue;
                }

                // Auto-generate issue number if not provided
                if (empty($issue_number)) {
                    $stmt = $pdo->query("SELECT issue_number FROM known_issues ORDER BY id DESC LIMIT 1");
                    $last = $stmt->fetchColumn();
                    if (!$last) {
                        $issue_number = 'KI-001';
                    } else {
                        if (preg_match('/(\d+)$/', $last, $matches)) {
                            $number = ((int)$matches[1]) + 1;
                            $issue_number = 'KI-' . str_pad($number, 3, '0', STR_PAD_LEFT);
                        } else {
                            $issue_number = 'KI-001';
                        }
                    }
                }

                // Check for duplicate issue_number
                $stmt = $pdo->prepare("SELECT id FROM known_issues WHERE issue_number = ?");
                $stmt->execute([$issue_number]);

                if ($stmt->fetch()) {
                    $skipped++;
                    continue;
                }

                // Extract optional fields
                $description = trim($data['description'] ?? '');
                $category = trim($data['category'] ?? '');
                $severity = trim($data['severity'] ?? 'Medium');
                $status = trim($data['status'] ?? 'Open');
                $affected_team = trim($data['affected_team'] ?? '');
                $affected_system = trim($data['affected_system'] ?? '');
                $environment = trim($data['environment'] ?? '');
                $owner_id = $_SESSION['user_id'];

                // Insert the record
                $stmt = $pdo->prepare("
                    INSERT INTO known_issues
                    (issue_number, title, description, category, severity, status, owner_id, affected_team, affected_system, environment)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                try {
                    $stmt->execute([
                        $issue_number,
                        $title,
                        $description,
                        $category,
                        $severity,
                        $status,
                        $owner_id,
                        $affected_team,
                        $affected_system,
                        $environment
                    ]);

                    $imported++;
                } catch (Exception $e) {
                    $skipped++;
                }
            }

            fclose($handle);
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Known Issues CSV</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Known Issues CSV</h2>

        <?php if ($imported > 0 || $skipped > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Imported</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped; ?></strong>
                </div>
            </div>
            <p class="text-center" style="margin-top: 20px;">
                <a href="known-issues.php" class="btn btn-primary">Return to Known Issues List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="known-issues.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
