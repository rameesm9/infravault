<?php

require_once 'config/db.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];

$role = trim($_SESSION['role'] ?? '');


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function redirect_grc(): void
{
    header('Location: grc_schedule.php');
    exit;
}


/*
|--------------------------------------------------------------------------
| SELF-CREATING TABLES
|--------------------------------------------------------------------------
|
| Matches the "inventory" table shown to Claude, plus every column
| actually referenced by the INSERT/UPDATE statements below. Guarding
| these with IF NOT EXISTS means this page works even on a database
| that hasn't had the GRC tables created yet, the same defensive
| pattern used elsewhere in InfraVault.
|
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS grc_schedules (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        project TEXT NOT NULL,
        support_level TEXT,
        recurrence_interval_days INTEGER DEFAULT 30,
        scheduled_time TEXT,
        patched_time TEXT,
        next_date TEXT,
        assignee_id INTEGER,
        status TEXT DEFAULT 'Planned',
        new_kernel_version TEXT,
        new_os_version TEXT,
        change_request TEXT,
        comments TEXT,
        attachment_original_name TEXT,
        attachment_stored_name TEXT,
        attachment_path TEXT,
        attachment_mime TEXT,
        attachment_size INTEGER,
        created_by INTEGER,
        updated_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS grc_schedule_hosts (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_id INTEGER NOT NULL,
        inventory_id INTEGER NOT NULL,
        status TEXT DEFAULT 'Planned',
        excluded INTEGER DEFAULT 0,
        comment TEXT,
        patched_time TEXT,
        kernel_version TEXT,
        os_version TEXT,
        change_request TEXT,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(schedule_id, inventory_id)
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS grc_schedule_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_id INTEGER,
        inventory_id INTEGER,
        patched_time TEXT,
        kernel_version TEXT,
        os_version TEXT,
        change_request TEXT,
        status TEXT,
        comments TEXT,
        changed_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS grc_schedule_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        schedule_id INTEGER,
        action TEXT NOT NULL,
        field_name TEXT,
        old_value TEXT,
        new_value TEXT,
        changed_by INTEGER,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize GRC tables: ' . $e->getMessage());
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] =
        bin2hex(random_bytes(32));
}

$csrf_token =
    $_SESSION['csrf_token'];


function check_csrf(): void
{
    $token =
        $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $token
        )
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| GRC Permissions
|--------------------------------------------------------------------------
|
| Permission table:
|
| permissions
| --------------------------------
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
| GRC page key:
|
| grc_schedule
|
*/

function get_grc_permissions(
    PDO $pdo,
    string $role
): array {

    /*
    | Delegates to the single authorization helper (includes/authz.php),
    | keeping this function's array-of-flags shape so the call sites
    | throughout this file are unchanged.
    */

    $permissions = [];

    foreach (AUTHZ_VERBS as $verb) {
        $permissions[$verb] = authzCan($pdo, $role, 'grc_schedule', $verb);
    }

    return $permissions;
}


$grc_permissions =
    get_grc_permissions(
        $pdo,
        $role
    );


$can_view =
    $grc_permissions['can_view'];

$can_edit =
    $grc_permissions['can_edit'];

$can_delete =
    $grc_permissions['can_delete'];

$can_export =
    $grc_permissions['can_export'];

$can_import =
    $grc_permissions['can_import'];

$can_audit =
    $grc_permissions['can_audit'];


/*
|--------------------------------------------------------------------------
| View Permission
|--------------------------------------------------------------------------
*/

if (!$can_view) {

    http_response_code(403);

    exit(
        'You do not have permission to view GRC schedules.'
    );
}


/*
|--------------------------------------------------------------------------
| Permission Helpers
|--------------------------------------------------------------------------
*/

function require_grc_edit(
    bool $can_edit
): void {

    if (!$can_edit) {

        http_response_code(403);

        exit(
            'You do not have permission to perform this action.'
        );
    }
}


function require_grc_delete(
    bool $can_delete
): void {

    if (!$can_delete) {

        http_response_code(403);

        exit(
            'You do not have permission to delete this schedule.'
        );
    }
}


function require_grc_audit(
    bool $can_audit
): void {

    if (!$can_audit) {

        http_response_code(403);

        exit(
            'You do not have permission to view audit history.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| User Name
|--------------------------------------------------------------------------
*/

function get_user_name(
    PDO $pdo,
    int $user_id
): string {

    if ($user_id <= 0) {
        return 'Unknown';
    }

    $stmt = $pdo->prepare("
        SELECT first_name, last_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $user_id
    ]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return 'Unknown';
    }

    return trim(
        ($row['first_name'] ?? '') .
        ' ' .
        ($row['last_name'] ?? '')
    );
}


/*
|--------------------------------------------------------------------------
| Audit
|--------------------------------------------------------------------------
*/

function grc_audit(
    PDO $pdo,
    int $schedule_id,
    string $action,
    ?string $field,
    $old_value,
    $new_value,
    int $user_id
): void {

    $stmt = $pdo->prepare("
        INSERT INTO grc_schedule_audit (
            schedule_id,
            action,
            field_name,
            old_value,
            new_value,
            changed_by
        )
        VALUES (?, ?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $schedule_id,
        $action,
        $field,
        $old_value !== null
            ? (string) $old_value
            : null,
        $new_value !== null
            ? (string) $new_value
            : null,
        $user_id
    ]);
}


/*
|--------------------------------------------------------------------------
| Automatic Next Date
|--------------------------------------------------------------------------
*/

function calculate_next_date(
    ?string $patched_time,
    int $recurrence_days
): ?string {

    if ($recurrence_days < 1) {
        $recurrence_days = 30;
    }

    if (!$patched_time) {
        return null;
    }

    $timestamp =
        strtotime($patched_time);

    if (!$timestamp) {
        return null;
    }

    return date(
        'Y-m-d',
        strtotime(
            '+' . $recurrence_days . ' days',
            $timestamp
        )
    );
}


/*
|--------------------------------------------------------------------------
| Bulk-propagate the schedule's target OS/Kernel version to every
| matching inventory host (project + support_level + grc = 'yes').
| Only the fields actually provided are touched -- an empty new_os or
| new_kernel leaves that column alone rather than blanking it out
| across every matching server.
|--------------------------------------------------------------------------
*/

function bulk_update_inventory_versions(
    PDO $pdo,
    string $project,
    string $support_level,
    string $new_kernel,
    string $new_os
): int {

    if ($new_kernel === '' && $new_os === '') {
        return 0;
    }

    $sets = [];
    $params = [];

    if ($new_kernel !== '') {
        $sets[] = 'kernel_version = ?';
        $params[] = $new_kernel;
    }

    if ($new_os !== '') {
        $sets[] = 'os_version = ?';
        $params[] = $new_os;
    }

    $params[] = $project;
    $params[] = $support_level;

    $sql = "
        UPDATE inventory
        SET " . implode(', ', $sets) . "
        WHERE LOWER(TRIM(grc)) = 'yes'
          AND project = ?
          AND support_level = ?
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);

    return $stmt->rowCount();
}


/*
|--------------------------------------------------------------------------
| Attachment
|--------------------------------------------------------------------------
*/

function process_grc_attachment(
    string $upload_dir,
    array $file
): ?array {

    if (
        !isset($file['error']) ||
        $file['error'] !== UPLOAD_ERR_OK
    ) {
        return null;
    }

    if (
        !isset($file['size']) ||
        $file['size'] > 15 * 1024 * 1024
    ) {
        throw new RuntimeException(
            'Attachment cannot exceed 15 MB.'
        );
    }

    $original =
        basename(
            $file['name'] ?? ''
        );

    $extension =
        strtolower(
            pathinfo(
                $original,
                PATHINFO_EXTENSION
            )
        );

    $allowed_extensions = [
        'pdf',
        'eml',
        'msg',
        'doc',
        'docx',
        'xls',
        'xlsx'
    ];

    if (
        !in_array(
            $extension,
            $allowed_extensions,
            true
        )
    ) {
        throw new RuntimeException(
            'Unsupported attachment type.'
        );
    }

    if (!is_dir($upload_dir)) {

        if (!mkdir(
            $upload_dir,
            0755,
            true
        ) && !is_dir($upload_dir)) {

            throw new RuntimeException(
                'Unable to create attachment directory.'
            );
        }
    }

    $stored =
        bin2hex(
            random_bytes(16)
        ) .
        '.' .
        $extension;

    $destination =
        $upload_dir .
        '/' .
        $stored;

    if (
        !move_uploaded_file(
            $file['tmp_name'],
            $destination
        )
    ) {
        throw new RuntimeException(
            'Unable to save attachment.'
        );
    }

    $mime =
        mime_content_type(
            $destination
        ) ?: 'application/octet-stream';

    return [
        'original_name' =>
            $original,

        'stored_name' =>
            $stored,

        'path' =>
            'uploads/grc/' . $stored,

        'mime' =>
            $mime,

        'size' =>
            filesize($destination)
    ];
}


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['grc_success'] ?? '';

$error_msg =
    $_SESSION['grc_error'] ?? '';

unset(
    $_SESSION['grc_success'],
    $_SESSION['grc_error']
);


/*
|--------------------------------------------------------------------------
| Upload Directory
|--------------------------------------------------------------------------
*/

$upload_dir =
    __DIR__ . '/uploads/grc';


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $form_action =
        $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE SCHEDULE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_grc') {

        require_grc_edit($can_edit);

        $schedule_id =
            (int) ($_POST['schedule_id'] ?? 0);

        $project =
            trim(
                $_POST['project'] ?? ''
            );

        $support_level =
            trim(
                $_POST['support_level'] ?? ''
            );

        $recurrence =
            (int) (
                $_POST['recurrence_interval_days']
                ?? 30
            );

        $scheduled_time =
            trim(
                $_POST['scheduled_time'] ?? ''
            );

        $patched_time =
            trim(
                $_POST['patched_time'] ?? ''
            );

        $assignee_id =
            (int) (
                $_POST['assignee_id'] ?? 0
            );

        $status =
            trim(
                $_POST['status'] ?? 'Planned'
            );

        $new_kernel =
            trim(
                $_POST['new_kernel_version'] ?? ''
            );

        $new_os =
            trim(
                $_POST['new_os_version'] ?? ''
            );

        $change_request =
            trim(
                $_POST['change_request'] ?? ''
            );

        $comments =
            trim(
                $_POST['comments'] ?? ''
            );


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($project === '') {

            $_SESSION['grc_error'] =
                'Project is required.';

            redirect_grc();
        }

        if ($support_level === '') {

            $_SESSION['grc_error'] =
                'Support level is required.';

            redirect_grc();
        }

        if ($recurrence < 1) {
            $recurrence = 30;
        }


        /*
        |--------------------------------------------------------------------------
        | Existing Schedule
        |--------------------------------------------------------------------------
        */

        $existing = null;

        if ($schedule_id > 0) {

            $stmt = $pdo->prepare("
                SELECT *
                FROM grc_schedules
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([
                $schedule_id
            ]);

            $existing =
                $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$existing) {

                $_SESSION['grc_error'] =
                    'Schedule not found.';

                redirect_grc();
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Next Date
        |--------------------------------------------------------------------------
        */

        $next_date = null;

        if ($patched_time !== '') {

            $next_date =
                calculate_next_date(
                    $patched_time,
                    $recurrence
                );

        } elseif (
            $existing &&
            !empty($existing['next_date']) &&
            $recurrence ===
            (int) $existing['recurrence_interval_days']
        ) {

            $next_date =
                $existing['next_date'];

        } elseif (
            $existing &&
            !empty($existing['patched_time'])
        ) {

            $next_date =
                calculate_next_date(
                    $existing['patched_time'],
                    $recurrence
                );
        }


        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($schedule_id === 0) {

            $stmt = $pdo->prepare("
                INSERT INTO grc_schedules (
                    project,
                    support_level,
                    recurrence_interval_days,
                    scheduled_time,
                    patched_time,
                    next_date,
                    assignee_id,
                    status,
                    new_kernel_version,
                    new_os_version,
                    change_request,
                    comments,
                    created_by,
                    updated_by
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
                )
            ");

            $stmt->execute([
                $project,
                $support_level,
                $recurrence,
                $scheduled_time !== ''
                    ? $scheduled_time
                    : null,
                $patched_time !== ''
                    ? $patched_time
                    : null,
                $next_date,
                $assignee_id > 0
                    ? $assignee_id
                    : null,
                $status,
                $new_kernel !== ''
                    ? $new_kernel
                    : null,
                $new_os !== ''
                    ? $new_os
                    : null,
                $change_request !== ''
                    ? $change_request
                    : null,
                $comments !== ''
                    ? $comments
                    : null,
                $current_user_id,
                $current_user_id
            ]);

            $schedule_id =
                (int) $pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | Audit Create
            |--------------------------------------------------------------------------
            */

            if ($can_audit) {

                grc_audit(
                    $pdo,
                    $schedule_id,
                    'CREATE',
                    null,
                    null,
                    'GRC schedule created: ' . $project . ' / ' . $support_level,
                    $current_user_id
                );
            }


            /*
            |--------------------------------------------------------------------------
            | Automatically Add Matching Hosts
            |--------------------------------------------------------------------------
            |
            | Matches BOTH project and support_level. Matching on
            | support_level alone (the previous behavior) pulled in
            | every GRC host at that support level regardless of
            | project, which is why "matching hosts" looked wrong.
            |
            */

            $stmt = $pdo->prepare("
                SELECT id
                FROM inventory
                WHERE LOWER(TRIM(grc)) = 'yes'
                AND project = ?
                AND support_level = ?
            ");

            $stmt->execute([
                $project,
                $support_level
            ]);

            $hosts =
                $stmt->fetchAll(
                    PDO::FETCH_COLUMN
                );

            $host_insert =
                $pdo->prepare("
                    INSERT OR IGNORE INTO grc_schedule_hosts (
                        schedule_id,
                        inventory_id,
                        status
                    )
                    VALUES (?, ?, 'Planned')
                ");

            foreach ($hosts as $inventory_id) {

                $host_insert->execute([
                    $schedule_id,
                    (int) $inventory_id
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | Propagate target OS/Kernel version to every matching host
            |--------------------------------------------------------------------------
            */

            bulk_update_inventory_versions(
                $pdo,
                $project,
                $support_level,
                $new_kernel,
                $new_os
            );


        } else {

            /*
            |--------------------------------------------------------------------------
            | Audit Changes
            |--------------------------------------------------------------------------
            */

            if ($can_audit) {

                $changes = [

                    'project' => [
                        $existing['project'],
                        $project
                    ],

                    'support_level' => [
                        $existing['support_level'],
                        $support_level
                    ],

                    'recurrence_interval_days' => [
                        $existing['recurrence_interval_days'],
                        $recurrence
                    ],

                    'scheduled_time' => [
                        $existing['scheduled_time'],
                        $scheduled_time ?: null
                    ],

                    'patched_time' => [
                        $existing['patched_time'],
                        $patched_time ?: null
                    ],

                    'next_date' => [
                        $existing['next_date'],
                        $next_date
                    ],

                    'assignee_id' => [
                        $existing['assignee_id'],
                        $assignee_id ?: null
                    ],

                    'status' => [
                        $existing['status'],
                        $status
                    ],

                    'new_kernel_version' => [
                        $existing['new_kernel_version'],
                        $new_kernel ?: null
                    ],

                    'new_os_version' => [
                        $existing['new_os_version'],
                        $new_os ?: null
                    ],

                    'change_request' => [
                        $existing['change_request'],
                        $change_request ?: null
                    ],

                    'comments' => [
                        $existing['comments'],
                        $comments ?: null
                    ]
                ];


                foreach (
                    $changes
                    as $field => $values
                ) {

                    if (
                        (string) $values[0]
                        !==
                        (string) $values[1]
                    ) {

                        grc_audit(
                            $pdo,
                            $schedule_id,
                            'UPDATE',
                            $field,
                            $values[0],
                            $values[1],
                            $current_user_id
                        );
                    }
                }
            }


            /*
            |--------------------------------------------------------------------------
            | Update Schedule
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                UPDATE grc_schedules
                SET
                    project = ?,
                    support_level = ?,
                    recurrence_interval_days = ?,
                    scheduled_time = ?,
                    patched_time = ?,
                    next_date = ?,
                    assignee_id = ?,
                    status = ?,
                    new_kernel_version = ?,
                    new_os_version = ?,
                    change_request = ?,
                    comments = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $project,
                $support_level,
                $recurrence,
                $scheduled_time ?: null,
                $patched_time ?: null,
                $next_date,
                $assignee_id ?: null,
                $status,
                $new_kernel ?: null,
                $new_os ?: null,
                $change_request ?: null,
                $comments ?: null,
                $current_user_id,
                $schedule_id
            ]);


            /*
            |--------------------------------------------------------------------------
            | Add Newly Matching Hosts (project + support_level)
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                SELECT id
                FROM inventory
                WHERE LOWER(TRIM(grc)) = 'yes'
                AND project = ?
                AND support_level = ?
            ");

            $stmt->execute([
                $project,
                $support_level
            ]);

            $hosts =
                $stmt->fetchAll(
                    PDO::FETCH_COLUMN
                );

            $host_insert =
                $pdo->prepare("
                    INSERT OR IGNORE INTO grc_schedule_hosts (
                        schedule_id,
                        inventory_id,
                        status
                    )
                    VALUES (?, ?, 'Planned')
                ");

            foreach ($hosts as $inventory_id) {

                $host_insert->execute([
                    $schedule_id,
                    (int) $inventory_id
                ]);
            }


            /*
            |--------------------------------------------------------------------------
            | Propagate target OS/Kernel version to every matching host
            |--------------------------------------------------------------------------
            */

            bulk_update_inventory_versions(
                $pdo,
                $project,
                $support_level,
                $new_kernel,
                $new_os
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Patch History
        |--------------------------------------------------------------------------
        */

        if ($patched_time !== '') {

            $stmt = $pdo->prepare("
                INSERT INTO grc_schedule_history (
                    schedule_id,
                    inventory_id,
                    patched_time,
                    kernel_version,
                    os_version,
                    change_request,
                    status,
                    comments,
                    changed_by
                )
                VALUES (?, NULL, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $schedule_id,
                $patched_time,
                $new_kernel ?: null,
                $new_os ?: null,
                $change_request ?: null,
                $status,
                $comments ?: null,
                $current_user_id
            ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Attachment
        |--------------------------------------------------------------------------
        */

        if (
            isset($_FILES['attachment']) &&
            $_FILES['attachment']['error']
            === UPLOAD_ERR_OK
        ) {

            try {

                $attachment =
                    process_grc_attachment(
                        $upload_dir,
                        $_FILES['attachment']
                    );

                if ($attachment) {

                    $stmt = $pdo->prepare("
                        UPDATE grc_schedules
                        SET
                            attachment_original_name = ?,
                            attachment_stored_name = ?,
                            attachment_path = ?,
                            attachment_mime = ?,
                            attachment_size = ?,
                            updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ");

                    $stmt->execute([
                        $attachment['original_name'],
                        $attachment['stored_name'],
                        $attachment['path'],
                        $attachment['mime'],
                        $attachment['size'],
                        $schedule_id
                    ]);
                }

            } catch (Throwable $e) {

                $_SESSION['grc_error'] =
                    $e->getMessage();

                redirect_grc();
            }
        }


        $_SESSION['grc_success'] =
            'GRC schedule saved successfully.';

        redirect_grc();
    }


    /*
    |--------------------------------------------------------------------------
    | SAVE HOST
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_host') {

        require_grc_edit($can_edit);

        $schedule_id =
            (int) ($_POST['schedule_id'] ?? 0);

        $host_id =
            (int) ($_POST['host_id'] ?? 0);

        $host_status =
            trim(
                $_POST['host_status'] ?? 'Planned'
            );

        $excluded =
            isset($_POST['excluded'])
            ? 1
            : 0;

        $host_comment =
            trim(
                $_POST['host_comment'] ?? ''
            );

        $host_patched_time =
            trim(
                $_POST['host_patched_time'] ?? ''
            );

        $host_kernel =
            trim(
                $_POST['host_kernel_version'] ?? ''
            );

        $host_os =
            trim(
                $_POST['host_os_version'] ?? ''
            );

        $host_crq =
            trim(
                $_POST['host_change_request'] ?? ''
            );


        if (
            $schedule_id <= 0 ||
            $host_id <= 0
        ) {

            $_SESSION['grc_error'] =
                'Invalid host information.';

            redirect_grc();
        }


        /*
        |--------------------------------------------------------------------------
        | Schedule
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM grc_schedules
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $schedule_id
        ]);

        $schedule =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$schedule) {

            $_SESSION['grc_error'] =
                'Schedule not found.';

            redirect_grc();
        }


        /*
        |--------------------------------------------------------------------------
        | Inventory Host
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM inventory
            WHERE id = ?
            AND LOWER(TRIM(grc)) = 'yes'
            LIMIT 1
        ");

        $stmt->execute([
            $host_id
        ]);

        $inventory =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$inventory) {

            $_SESSION['grc_error'] =
                'Host not found.';

            redirect_grc();
        }


        /*
        |--------------------------------------------------------------------------
        | Host History
        |--------------------------------------------------------------------------
        */

        if (
            $host_status === 'Patched' &&
            $host_patched_time !== ''
        ) {

            $stmt = $pdo->prepare("
                INSERT INTO grc_schedule_history (
                    schedule_id,
                    inventory_id,
                    patched_time,
                    kernel_version,
                    os_version,
                    change_request,
                    status,
                    comments,
                    changed_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $schedule_id,
                $host_id,
                $host_patched_time,
                $host_kernel ?: null,
                $host_os ?: null,
                $host_crq ?: null,
                $host_status,
                $host_comment ?: null,
                $current_user_id
            ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Update Inventory
        |--------------------------------------------------------------------------
        */

        if ($host_kernel !== '') {

            $stmt = $pdo->prepare("
                UPDATE inventory
                SET kernel_version = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $host_kernel,
                $host_id
            ]);
        }


        if ($host_os !== '') {

            $stmt = $pdo->prepare("
                UPDATE inventory
                SET os_version = ?
                WHERE id = ?
            ");

            $stmt->execute([
                $host_os,
                $host_id
            ]);
        }


        /*
        |--------------------------------------------------------------------------
        | Update Schedule Host
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            INSERT INTO grc_schedule_hosts (
                schedule_id,
                inventory_id,
                status,
                excluded,
                comment,
                patched_time,
                kernel_version,
                os_version,
                change_request
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)

            ON CONFLICT(schedule_id, inventory_id)
            DO UPDATE SET
                status = excluded.status,
                excluded = excluded.excluded,
                comment = excluded.comment,
                patched_time = excluded.patched_time,
                kernel_version = excluded.kernel_version,
                os_version = excluded.os_version,
                change_request = excluded.change_request,
                updated_at = CURRENT_TIMESTAMP
        ");

        $stmt->execute([
            $schedule_id,
            $host_id,
            $host_status,
            $excluded,
            $host_comment ?: null,
            $host_patched_time ?: null,
            $host_kernel ?: null,
            $host_os ?: null,
            $host_crq ?: null
        ]);


        /*
        |--------------------------------------------------------------------------
        | Update Schedule Patched Information
        |--------------------------------------------------------------------------
        */

        if (
            $host_status === 'Patched' &&
            $host_patched_time !== ''
        ) {

            $next_date =
                calculate_next_date(
                    $host_patched_time,
                    (int)
                    $schedule[
                        'recurrence_interval_days'
                    ]
                );

            $stmt = $pdo->prepare("
                UPDATE grc_schedules
                SET
                    patched_time = ?,
                    next_date = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ");

            $stmt->execute([
                $host_patched_time,
                $next_date,
                $current_user_id,
                $schedule_id
            ]);
        }


        $_SESSION['grc_success'] =
            'Host information saved.';

        redirect_grc();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE SCHEDULE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_grc') {

        require_grc_delete($can_delete);

        $schedule_id =
            (int) ($_POST['schedule_id'] ?? 0);

        if ($schedule_id <= 0) {

            $_SESSION['grc_error'] =
                'Invalid schedule ID.';

            redirect_grc();
        }

        $stmt = $pdo->prepare("
            SELECT *
            FROM grc_schedules
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $schedule_id
        ]);

        $row =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$row) {

            $_SESSION['grc_error'] =
                'Schedule not found.';

            redirect_grc();
        }


        /*
        |--------------------------------------------------------------------------
        | Audit Delete
        |--------------------------------------------------------------------------
        */

        if ($can_audit) {

            grc_audit(
                $pdo,
                $schedule_id,
                'DELETE',
                null,
                'Existing schedule: ' . $row['project'] . ' / ' . $row['support_level'],
                null,
                $current_user_id
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Delete
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM grc_schedules
            WHERE id = ?
        ")->execute([
            $schedule_id
        ]);


        $_SESSION['grc_success'] =
            'GRC schedule deleted.';

        redirect_grc();
    }
}


/*
|--------------------------------------------------------------------------
| Attachment Download
|--------------------------------------------------------------------------
*/

if (
    ($_GET['action'] ?? '') === 'attachment'
) {

    $id =
        (int) ($_GET['id'] ?? 0);

    $stmt = $pdo->prepare("
        SELECT *
        FROM grc_schedules
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $id
    ]);

    $row =
        $stmt->fetch(PDO::FETCH_ASSOC);


    if (
        !$row ||
        empty($row['attachment_path'])
    ) {

        http_response_code(404);

        exit(
            'Attachment not found.'
        );
    }


    $file =
        __DIR__ .
        '/' .
        ltrim(
            $row['attachment_path'],
            '/\\'
        );


    if (!is_file($file)) {

        http_response_code(404);

        exit(
            'File not found.'
        );
    }


    header(
        'Content-Type: ' .
        (
            $row['attachment_mime']
            ?: 'application/octet-stream'
        )
    );

    header(
        'Content-Length: ' .
        filesize($file)
    );

    header(
        'Content-Disposition: attachment; filename="' .
        basename(
            $row['attachment_original_name']
        ) .
        '"'
    );

    header(
        'X-Content-Type-Options: nosniff'
    );

    readfile($file);

    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX - Hosts
|--------------------------------------------------------------------------
*/

if (
    ($_GET['action'] ?? '') === 'hosts'
) {

    header(
        'Content-Type: application/json'
    );

    $id =
        (int) ($_GET['id'] ?? 0);

    if ($id <= 0) {

        echo json_encode([
            'success' => false,
            'message' => 'Invalid schedule ID.'
        ]);

        exit;
    }


    $stmt = $pdo->prepare("
        SELECT
            g.id,
            g.project,
            g.support_level
        FROM grc_schedules g
        WHERE g.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $id
    ]);

    $schedule =
        $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$schedule) {

        echo json_encode([
            'success' => false,
            'message' => 'Schedule not found.'
        ]);

        exit;
    }


    $stmt = $pdo->prepare("
        SELECT

            gh.id AS host_schedule_id,
            gh.schedule_id,
            gh.inventory_id,

            gh.status AS host_status,
            gh.excluded,

            gh.comment AS host_comment,

            gh.patched_time AS host_patched_time,

            gh.kernel_version AS host_kernel_version,
            gh.os_version AS host_os_version,

            gh.change_request AS host_change_request,

            i.hostname,
            i.ip_address,
            i.application,
            i.os_family,
            i.os_version,
            i.kernel_version

        FROM grc_schedule_hosts gh

        INNER JOIN inventory i
            ON i.id = gh.inventory_id

        WHERE gh.schedule_id = ?

        ORDER BY i.hostname
    ");

    $stmt->execute([
        $id
    ]);

    $hosts =
        $stmt->fetchAll(PDO::FETCH_ASSOC);


    echo json_encode([
        'success' => true,
        'schedule' => $schedule,
        'hosts' => $hosts,
        'can_edit' => $can_edit
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX - History (per-host patch execution log)
|--------------------------------------------------------------------------
*/

if (
    ($_GET['action'] ?? '') === 'history'
) {

    header(
        'Content-Type: application/json'
    );

    if (!$can_audit) {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' =>
                'You do not have permission to view audit history.'
        ]);

        exit;
    }


    $id =
        (int) ($_GET['id'] ?? 0);


    if ($id <= 0) {

        echo json_encode([
            'success' => false,
            'message' => 'Invalid schedule ID.'
        ]);

        exit;
    }


    $stmt = $pdo->prepare("
        SELECT
            h.*,

            i.hostname,

            TRIM(
                COALESCE(
                    u.first_name,
                    ''
                ) ||
                ' ' ||
                COALESCE(
                    u.last_name,
                    ''
                )
            ) AS changed_by_name

        FROM grc_schedule_history h

        LEFT JOIN inventory i
            ON i.id = h.inventory_id

        LEFT JOIN users u
            ON u.id = h.changed_by

        WHERE h.schedule_id = ?

        ORDER BY
            h.created_at DESC,
            h.id DESC
    ");

    $stmt->execute([
        $id
    ]);

    $history =
        $stmt->fetchAll(PDO::FETCH_ASSOC);


    echo json_encode([
        'success' => true,
        'history' => $history
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX - Audit Log (page history)
|--------------------------------------------------------------------------
|
| ?action=audit_log            -> full module log across every schedule
| ?action=audit_log&id=<id>    -> just that one schedule's CRUD trail
|
| This is the field-level CREATE/UPDATE/DELETE trail written by
| grc_audit() -- distinct from the "history" endpoint above, which is
| about individual host patch executions, not who-changed-what.
|
*/

if (
    ($_GET['action'] ?? '') === 'audit_log'
) {

    header(
        'Content-Type: application/json'
    );

    if (!$can_audit) {

        http_response_code(403);

        echo json_encode([
            'success' => false,
            'message' =>
                'You do not have permission to view audit history.'
        ]);

        exit;
    }


    $id =
        (int) ($_GET['id'] ?? 0);


    if ($id > 0) {

        $stmt = $pdo->prepare("
            SELECT
                a.*,

                g.project,
                g.support_level,

                TRIM(
                    COALESCE(u.first_name, '') ||
                    ' ' ||
                    COALESCE(u.last_name, '')
                ) AS changed_by_name

            FROM grc_schedule_audit a

            LEFT JOIN grc_schedules g
                ON g.id = a.schedule_id

            LEFT JOIN users u
                ON u.id = a.changed_by

            WHERE a.schedule_id = ?

            ORDER BY
                a.created_at DESC,
                a.id DESC
        ");

        $stmt->execute([
            $id
        ]);

    } else {

        $stmt = $pdo->query("
            SELECT
                a.*,

                g.project,
                g.support_level,

                TRIM(
                    COALESCE(u.first_name, '') ||
                    ' ' ||
                    COALESCE(u.last_name, '')
                ) AS changed_by_name

            FROM grc_schedule_audit a

            LEFT JOIN grc_schedules g
                ON g.id = a.schedule_id

            LEFT JOIN users u
                ON u.id = a.changed_by

            ORDER BY
                a.created_at DESC,
                a.id DESC

            LIMIT 500
        ");
    }


    $logs =
        $stmt->fetchAll(PDO::FETCH_ASSOC);


    echo json_encode([
        'success' => true,
        'logs' => $logs
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| Filters
|--------------------------------------------------------------------------
*/

$project_filter =
    trim(
        $_GET['project'] ?? ''
    );

$support_filter =
    trim(
        $_GET['support_level'] ?? ''
    );

$status_filter =
    trim(
        $_GET['status'] ?? ''
    );

$search =
    trim(
        $_GET['search'] ?? ''
    );


/*
|--------------------------------------------------------------------------
| Projects (sourced from inventory, not from existing schedules --
| otherwise a project with GRC hosts but no schedule yet would never
| show up as an option)
|--------------------------------------------------------------------------
*/

$projects =
    $pdo->query("
        SELECT DISTINCT project
        FROM inventory
        WHERE LOWER(TRIM(grc)) = 'yes'
        AND project IS NOT NULL
        AND project <> ''
        ORDER BY project
    ")->fetchAll(
        PDO::FETCH_COLUMN
    );


/*
|--------------------------------------------------------------------------
| Support Levels (sourced from inventory)
|--------------------------------------------------------------------------
*/

$support_levels =
    $pdo->query("
        SELECT DISTINCT support_level
        FROM inventory
        WHERE LOWER(TRIM(grc)) = 'yes'
        AND support_level IS NOT NULL
        AND support_level <> ''
        ORDER BY support_level
    ")->fetchAll(
        PDO::FETCH_COLUMN
    );


/*
|--------------------------------------------------------------------------
| Project + Support Level combinations (drives the cascading dropdown
| in the New/Edit Schedule modal, so picking a Project only offers the
| Support Levels that actually exist for GRC hosts in that project)
|--------------------------------------------------------------------------
*/

$project_support_combos =
    $pdo->query("
        SELECT DISTINCT project, support_level
        FROM inventory
        WHERE LOWER(TRIM(grc)) = 'yes'
        AND project IS NOT NULL AND project <> ''
        AND support_level IS NOT NULL AND support_level <> ''
        ORDER BY project, support_level
    ")->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| Users
|--------------------------------------------------------------------------
*/

$users =
    $pdo->query("
        SELECT
            id,
            first_name,
            last_name,
            email
        FROM users
        ORDER BY first_name, last_name
    ")->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| Inventory
|--------------------------------------------------------------------------
*/

$inventory_stmt =
    $pdo->query("
        SELECT
            id,
            hostname,
            project,
            support_level,
            ip_address,
            application,
            os_family,
            os_version,
            kernel_version,
            grc
        FROM inventory
        WHERE LOWER(TRIM(grc)) = 'yes'
        ORDER BY hostname
    ");

$inventory_servers =
    $inventory_stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| PAGINATION
|--------------------------------------------------------------------------
*/

$page_selector = resolveUserPageSize($pdo, $current_user_id);
$rows_per_page = $page_selector; // alias: rest of this file's pagination logic uses $rows_per_page

$current_page = max(1, (int) ($_GET['page'] ?? 1));

$offset = ($current_page - 1) * $rows_per_page;


/*
|--------------------------------------------------------------------------
| SORTING
|--------------------------------------------------------------------------
*/

$sort_by = trim($_GET['sort_by'] ?? 'next_date');
$sort_dir = trim($_GET['sort_dir'] ?? 'ASC');

$valid_sort_columns = [
    'project',
    'support_level',
    'status',
    'next_date',
    'scheduled_time',
    'patched_time',
    'recurrence_interval_days'
];

if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'next_date';
}

if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'ASC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';


/*
|--------------------------------------------------------------------------
| Schedule List
|--------------------------------------------------------------------------
*/

$where = [];

$params = [];


if ($project_filter !== '') {

    $where[] =
        'g.project = ?';

    $params[] =
        $project_filter;
}


if ($support_filter !== '') {

    $where[] =
        'g.support_level = ?';

    $params[] =
        $support_filter;
}


if ($status_filter !== '') {

    $where[] =
        'g.status = ?';

    $params[] =
        $status_filter;
}


if ($search !== '') {

    $where[] = "
        (
            g.project LIKE ?
            OR g.support_level LIKE ?
            OR g.change_request LIKE ?
        )
    ";

    $params[] =
        '%' . $search . '%';

    $params[] =
        '%' . $search . '%';

    $params[] =
        '%' . $search . '%';
}


$where_sql =
    $where
        ? 'WHERE ' . implode(
            ' AND ',
            $where
        )
        : '';


// Count total records
$count_sql = "
    SELECT COUNT(*)
    FROM grc_schedules g
    $where_sql
";

$count_stmt = $pdo->prepare($count_sql);
$count_stmt->execute($params);
$total_records = (int) $count_stmt->fetchColumn();
$total_pages = max(1, (int) ceil($total_records / $rows_per_page));

// Correct page if out of range
if ($current_page > $total_pages && $total_records > 0) {
    $current_page = $total_pages;
    $offset = ($current_page - 1) * $rows_per_page;
}


$sql = "
    SELECT
        g.*,

        u.first_name AS assignee_first,
        u.last_name AS assignee_last,

        (
            SELECT COUNT(*)
            FROM grc_schedule_hosts gh
            WHERE gh.schedule_id = g.id
        ) AS host_count,

        (
            SELECT COUNT(*)
            FROM grc_schedule_hosts gh
            WHERE gh.schedule_id = g.id
            AND gh.excluded = 1
        ) AS excluded_count,

        (
            SELECT COUNT(*)
            FROM grc_schedule_hosts gh
            WHERE gh.schedule_id = g.id
            AND gh.status = 'Patched'
        ) AS patched_host_count

    FROM grc_schedules g

    LEFT JOIN users u
        ON u.id = g.assignee_id

    $where_sql

    ORDER BY g.$sort_by $sort_dir

    LIMIT $rows_per_page OFFSET $offset
";


$stmt =
    $pdo->prepare($sql);

$stmt->execute($params);

$schedules =
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$total =
    count($schedules);

$planned = 0;
$scheduled = 0;
$patched = 0;
$overdue = 0;

$today =
    date('Y-m-d');


foreach ($schedules as $row) {

    switch ($row['status']) {

        case 'Planned':
            $planned++;
            break;

        case 'Scheduled':
            $scheduled++;
            break;

        case 'Patched':
            $patched++;
            break;
    }


    if (
        !empty($row['next_date']) &&
        $row['next_date'] < $today &&
        $row['status'] !== 'Patched'
    ) {

        $overdue++;
    }
}


$page_title =
    'GRC Schedule';


/*
|--------------------------------------------------------------------------
| Statuses
|--------------------------------------------------------------------------
*/

$statuses = [
    'Planned',
    'Scheduled',
    'In Progress',
    'Patched',
    'Failed',
    'Skipped',
    'Cancelled'
];


require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>

<link
    rel="stylesheet"
    href="assets/css/grc_schedule.css"
>

<style>
    /* Audit log table -- reuses the .grc-table look, added here since
       the audit log viewer is new. */
    .grc-audit-old { color: #B91C1C; }
    .grc-audit-new { color: #166534; }
</style>

<div class="content grc-content">


<?php if ($success_msg): ?>

    <div class="grc-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="grc-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<!-- HEADER -->

<div class="grc-page-header">

    <div>

        <div class="grc-eyebrow">
            Infrastructure Compliance
        </div>

        <h1>
            GRC Patch Calendar
        </h1>

        <p>
            Track recurring GRC patching schedules,
            hosts, patch history and upcoming dates.
        </p>

    </div>


    <div class="grc-header-actions">

        <?php if ($can_edit): ?>

            <button
                type="button"
                class="grc-btn primary"
                onclick="openGrcModal()"
            >
                + Add Record
            </button>

        <?php endif; ?>


        <?php if ($can_import): ?>

            <a
                href="grc_schedule_import.php"
                class="grc-btn secondary indigo"
            >
                Import CSV
            </a>

        <?php endif; ?>


        <?php if ($can_export): ?>

            <a
                href="grc_schedule_export.php?search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&sort_by=<?= urlencode($sort_by) ?>&sort_dir=<?= urlencode($sort_dir) ?>"
                class="grc-btn secondary indigo"
            >
                Export CSV
            </a>

        <?php endif; ?>


        <?php if ($can_audit): ?>

            <button
                type="button"
                class="grc-btn secondary warning"
                onclick="viewAuditLog()"
            >
                ⏱ History
            </button>

        <?php endif; ?>

    </div>

</div>


<!-- STATS -->

<div class="grc-stats">

    <div class="grc-stat-card">

        <span>
            GRC Hosts
        </span>

        <strong>
            <?= count($inventory_servers) ?>
        </strong>

    </div>


    <div class="grc-stat-card">

        <span>
            Schedules
        </span>

        <strong>
            <?= $total ?>
        </strong>

    </div>


    <div class="grc-stat-card">

        <span>
            Planned
        </span>

        <strong>
            <?= $planned ?>
        </strong>

    </div>


    <div class="grc-stat-card">

        <span>
            Scheduled
        </span>

        <strong>
            <?= $scheduled ?>
        </strong>

    </div>


    <div class="grc-stat-card green">

        <span>
            Patched
        </span>

        <strong>
            <?= $patched ?>
        </strong>

    </div>


    <div class="grc-stat-card red">

        <span>
            Overdue
        </span>

        <strong>
            <?= $overdue ?>
        </strong>

    </div>

</div>


<!-- FILTERS -->

<div class="grc-filter-panel">

    <form
        method="GET"
        action="grc_schedule.php"
    >

        <div class="grc-filter-grid">

            <div>

                <label>
                    Search
                </label>

                <input
                    type="text"
                    name="search"
                    value="<?= h($search) ?>"
                    placeholder="Project, support level, CRQ..."
                >

            </div>


            <div>

                <label>
                    Project
                </label>

                <select name="project">

                    <option value="">
                        All Projects
                    </option>

                    <?php foreach ($projects as $project): ?>

                        <option
                            value="<?= h($project) ?>"
                            <?= $project_filter === $project
                                ? 'selected'
                                : '' ?>
                        >
                            <?= h($project) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div>

                <label>
                    Support Level
                </label>

                <select name="support_level">

                    <option value="">
                        All Support Levels
                    </option>

                    <?php foreach (
                        $support_levels
                        as $level
                    ): ?>

                        <option
                            value="<?= h($level) ?>"
                            <?= $support_filter === $level
                                ? 'selected'
                                : '' ?>
                        >
                            <?= h($level) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div>

                <label>
                    Status
                </label>

                <select name="status">

                    <option value="">
                        All Status
                    </option>

                    <?php foreach ($statuses as $status): ?>

                        <option
                            value="<?= h($status) ?>"
                            <?= $status_filter === $status
                                ? 'selected'
                                : '' ?>
                        >
                            <?= h($status) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="filter-buttons">

                <button
                    type="submit"
                    class="grc-btn primary"
                >
                    Filter
                </button>

                <a
                    href="grc_schedule.php"
                    class="grc-btn secondary"
                >
                    Reset
                </a>

            </div>

        </div>

    </form>

</div>


<!-- SCHEDULE -->

<div class="grc-panel">

    <div class="grc-panel-header">

        <div>

            <h2>
                Patch Calendar
            </h2>

            <span>
                One schedule can contain multiple hosts
            </span>

        </div>

        <div class="grc-result-count">

            <?= $total ?>
            schedule(s)

        </div>

    </div>


    <div class="grc-table-wrapper">

        <table class="grc-table">

            <thead>

                <tr>

                    <th>
                        <a href="grc_schedule.php?sort_by=project&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Project
                            <?php if ($sort_by === 'project'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="grc_schedule.php?sort_by=support_level&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Support
                            <?php if ($sort_by === 'support_level'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>Hosts</th>
                    <th>
                        <a href="grc_schedule.php?sort_by=recurrence_interval_days&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Recurrence
                            <?php if ($sort_by === 'recurrence_interval_days'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="grc_schedule.php?sort_by=scheduled_time&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Scheduled
                            <?php if ($sort_by === 'scheduled_time'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="grc_schedule.php?sort_by=patched_time&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Last Patched
                            <?php if ($sort_by === 'patched_time'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="grc_schedule.php?sort_by=next_date&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Next Patch
                            <?php if ($sort_by === 'next_date'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>Assignee</th>
                    <th>
                        <a href="grc_schedule.php?sort_by=status&sort_dir=<?= h($next_sort_dir) ?>&page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&page_size=<?= $page_selector ?>" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                            Status
                            <?php if ($sort_by === 'status'): ?>
                                <span style="color: #2563EB;">
                                    <?= $sort_dir === 'ASC' ? '↑' : '↓' ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>Actions</th>

                </tr>

            </thead>


            <tbody>


<?php if (!$schedules): ?>

                <tr>

                    <td
                        colspan="10"
                        class="grc-empty"
                    >
                        No GRC schedules found.
                    </td>

                </tr>

<?php endif; ?>


<?php foreach ($schedules as $row): ?>

<?php

$is_overdue =
    !empty($row['next_date']) &&
    $row['next_date'] < $today &&
    $row['status'] !== 'Patched';

?>

                <tr
                    class="<?= $is_overdue
                        ? 'grc-overdue'
                        : '' ?>"
                >

                    <td>

                        <strong>
                            <?= h(
                                $row['project']
                            ) ?>
                        </strong>

                    </td>


                    <td>

                        <span class="grc-support">

                            <?= h(
                                $row['support_level']
                            ) ?>

                        </span>

                    </td>


                    <td>

                        <strong>
                            <?= (int)
                                $row['host_count'] ?>
                        </strong>

                        host(s)

                        <?php if (
                            (int)
                            $row['excluded_count']
                            > 0
                        ): ?>

                            <small>
                                /
                                <?= (int)
                                    $row['excluded_count'] ?>
                                excluded
                            </small>

                        <?php endif; ?>

                    </td>


                    <td>

                        Every
                        <?= (int)
                            $row[
                                'recurrence_interval_days'
                            ] ?>
                        days

                    </td>


                    <td>

                        <?= $row['scheduled_time']
                            ? h(
                                date(
                                    'd M Y H:i',
                                    strtotime(
                                        $row['scheduled_time']
                                    )
                                )
                            )
                            : '<span class="muted">—</span>' ?>

                    </td>


                    <td>

                        <?= $row['patched_time']
                            ? h(
                                date(
                                    'd M Y H:i',
                                    strtotime(
                                        $row['patched_time']
                                    )
                                )
                            )
                            : '<span class="muted">Never</span>' ?>

                    </td>


                    <td>

                        <strong
                            class="<?= $is_overdue
                                ? 'next-overdue'
                                : '' ?>"
                        >

                            <?= $row['next_date']
                                ? h(
                                    date(
                                        'd M Y',
                                        strtotime(
                                            $row['next_date']
                                        )
                                    )
                                )
                                : 'Not patched yet' ?>

                        </strong>

                    </td>


                    <td>

                        <?= h(
                            trim(
                                ($row['assignee_first'] ?? '') .
                                ' ' .
                                ($row['assignee_last'] ?? '')
                            )
                            ?: 'Unassigned'
                        ) ?>

                    </td>


                    <td>

                        <span
                            class="grc-status status-<?= strtolower(
                                str_replace(
                                    ' ',
                                    '-',
                                    $row['status']
                                )
                            ) ?>"
                        >

                            <?= h(
                                $row['status']
                            ) ?>

                        </span>

                    </td>


                    <td>

                        <div class="grc-actions">


                            <button
                                type="button"
                                class="action-view grc-icon-btn"
                                title="View Hosts"
                                aria-label="View Hosts"
                                onclick="viewHosts(<?= (int) $row['id'] ?>)"
                            >
                                👁
                            </button>


                            <?php if ($can_audit): ?>

                                <button
                                    type="button"
                                    class="action-view grc-icon-btn"
                                    title="Patch History"
                                    aria-label="Patch History"
                                    onclick="viewHistory(<?= (int) $row['id'] ?>)"
                                >
                                    ⏱
                                </button>

                                <button
                                    type="button"
                                    class="action-view grc-icon-btn"
                                    title="Audit Log"
                                    aria-label="Audit Log"
                                    onclick="viewAuditLog(<?= (int) $row['id'] ?>)"
                                >
                                    📋
                                </button>

                            <?php endif; ?>


                            <?php if ($can_edit): ?>

                                <button
                                    type="button"
                                    onclick='editGrc(<?= json_encode(
                                        $row,
                                        JSON_HEX_TAG |
                                        JSON_HEX_APOS |
                                        JSON_HEX_QUOT |
                                        JSON_HEX_AMP
                                    ) ?>)'
                                    class="action-edit grc-icon-btn"
                                    title="Edit"
                                    aria-label="Edit"
                                >
                                    ✎
                                </button>

                            <?php endif; ?>


                            <?php if (
                                !empty(
                                    $row['attachment_path']
                                )
                            ): ?>

                                <a
                                    href="grc_schedule.php?action=attachment&id=<?= (int) $row['id'] ?>"
                                    class="action-file grc-icon-btn"
                                    title="Attachment"
                                    aria-label="Attachment"
                                >
                                    📎
                                </a>

                            <?php endif; ?>


                            <?php if ($can_delete): ?>

                                <form
                                    method="POST"
                                    action="grc_schedule.php"
                                    onsubmit="return confirm('Delete this schedule?');"
                                >

                                    <input
                                        type="hidden"
                                        name="csrf_token"
                                        value="<?= h($csrf_token) ?>"
                                    >

                                    <input
                                        type="hidden"
                                        name="form_action"
                                        value="delete_grc"
                                    >

                                    <input
                                        type="hidden"
                                        name="schedule_id"
                                        value="<?= (int) $row['id'] ?>"
                                    >

                                    <button
                                        type="submit"
                                        class="action-delete grc-icon-btn"
                                        title="Delete"
                                        aria-label="Delete"
                                    >
                                        🗑
                                    </button>

                                </form>

                            <?php endif; ?>


                        </div>

                    </td>

                </tr>

<?php endforeach; ?>


            </tbody>

        </table>

    </div>


    <!-- PAGINATION -->

    <div class="grc-pagination">

        <div class="grc-pagination-info">

            Showing <?= $total_records > 0 ? (($current_page - 1) * $rows_per_page + 1) : 0 ?>
            to <?= min($current_page * $rows_per_page, $total_records) ?>
            of <?= $total_records ?> record(s)

        </div>


        <div class="grc-pagination-controls">

            <div class="grc-rows-per-page">

                <?php
                    $grc_hidden_fields = '';
                    foreach ([
                        'search' => $search,
                        'project' => $project_filter,
                        'support_level' => $support_filter,
                        'status' => $status_filter,
                        'sort_by' => $sort_by,
                        'sort_dir' => $sort_dir,
                    ] as $gfk => $gfv) {
                        if ($gfv !== '') {
                            $grc_hidden_fields .= '<input type="hidden" name="' . h($gfk) . '" value="' . h($gfv) . '">';
                        }
                    }
                ?>
                <?= pageSizeSelectorHtml($page_selector, $grc_hidden_fields) ?>

            </div>


            <div class="grc-page-navigation">

                <?php if ($current_page > 1): ?>

                    <a href="grc_schedule.php?page=1&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&sort_by=<?= urlencode($sort_by) ?>&sort_dir=<?= urlencode($sort_dir) ?>&page_size=<?= $page_selector ?>" class="grc-btn secondary">First</a>

                    <a href="grc_schedule.php?page=<?= $current_page - 1 ?>&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&sort_by=<?= urlencode($sort_by) ?>&sort_dir=<?= urlencode($sort_dir) ?>&page_size=<?= $page_selector ?>" class="grc-btn secondary">← Prev</a>

                <?php endif; ?>


                <span class="grc-page-info">Page <?= $current_page ?> of <?= $total_pages ?></span>


                <?php if ($current_page < $total_pages): ?>

                    <a href="grc_schedule.php?page=<?= $current_page + 1 ?>&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&sort_by=<?= urlencode($sort_by) ?>&sort_dir=<?= urlencode($sort_dir) ?>&page_size=<?= $page_selector ?>" class="grc-btn secondary">Next →</a>

                    <a href="grc_schedule.php?page=<?= $total_pages ?>&search=<?= urlencode($search) ?>&project=<?= urlencode($project_filter) ?>&support_level=<?= urlencode($support_filter) ?>&status=<?= urlencode($status_filter) ?>&sort_by=<?= urlencode($sort_by) ?>&sort_dir=<?= urlencode($sort_dir) ?>&page_size=<?= $page_selector ?>" class="grc-btn secondary">Last</a>

                <?php endif; ?>

            </div>

        </div>

    </div>

</div>

</div>


<!-- ====================================================================== -->
<!-- NEW / EDIT SCHEDULE MODAL -->
<!-- ====================================================================== -->

<?php if ($can_edit): ?>

<div
    id="grcModal"
    class="grc-modal"
>

    <div class="grc-modal-box">

        <div class="grc-modal-header">

            <div>

                <h2 id="grcModalTitle">
                    New GRC Schedule
                </h2>

                <span>
                    Project and support level determine the hosts
                    (sourced from Inventory)
                </span>

            </div>

            <button
                type="button"
                onclick="closeGrcModal()"
                class="grc-modal-close"
            >
                ×
            </button>

        </div>


        <form
            method="POST"
            action="grc_schedule.php"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= h($csrf_token) ?>"
            >

            <input
                type="hidden"
                name="form_action"
                value="save_grc"
            >

            <input
                type="hidden"
                name="schedule_id"
                id="schedule_id"
                value="0"
            >


            <div class="grc-modal-body">

                <div class="grc-form-section">

                    <div class="grc-form-section-title">

                        <h3>
                            Schedule
                        </h3>

                        <span>
                            No hostname is required here
                        </span>

                    </div>


                    <div class="grc-form-grid">


                        <div class="grc-field">

                            <label>
                                Project *
                            </label>

                            <select
                                name="project"
                                id="project"
                                required
                                onchange="onGrcProjectChange()"
                            >

                                <option value="">
                                    Select project
                                </option>

                                <?php foreach ($projects as $project): ?>

                                    <option
                                        value="<?= h($project) ?>"
                                    >
                                        <?= h($project) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                            <small>
                                Sourced from Inventory (GRC = Yes hosts).
                            </small>

                        </div>


                        <div class="grc-field">

                            <label>
                                Support Level *
                            </label>

                            <select
                                name="support_level"
                                id="support_level"
                                required
                                onchange="showMatchingHostCount()"
                            >

                                <option value="">
                                    Select a project first
                                </option>

                            </select>

                            <small id="matchingHostText">
                                Select a project and support level.
                            </small>

                        </div>


                        <div class="grc-field">

                            <label>
                                Recurrence
                            </label>

                            <div class="grc-input-with-unit">

                                <input
                                    type="number"
                                    name="recurrence_interval_days"
                                    id="recurrence_interval_days"
                                    min="1"
                                    value="30"
                                    required
                                >

                                <span>
                                    days
                                </span>

                            </div>

                            <small>
                                Next patch date is calculated automatically.
                            </small>

                        </div>


                        <div class="grc-field">

                            <label>
                                Scheduled Time
                            </label>

                            <input
                                type="datetime-local"
                                name="scheduled_time"
                                id="scheduled_time"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Last Patched Time
                            </label>

                            <input
                                type="datetime-local"
                                name="patched_time"
                                id="patched_time"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Next Patch Date
                            </label>

                            <input
                                type="text"
                                id="display_next_date"
                                readonly
                                placeholder="Automatically calculated"
                            >

                        </div>

                    </div>

                </div>


                <div class="grc-form-section">

                    <div class="grc-form-section-title">

                        <h3>
                            Patch Information
                        </h3>

                        <span>
                            Saving this will apply the New OS/Kernel
                            Version below to every matching host in
                            Inventory (project + support level, GRC = Yes)
                        </span>

                    </div>


                    <div class="grc-form-grid">


                        <div class="grc-field">

                            <label>
                                New OS Version
                            </label>

                            <input
                                type="text"
                                name="new_os_version"
                                id="new_os_version"
                                placeholder="Example: RHEL 9.6"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                New Kernel Version
                            </label>

                            <input
                                type="text"
                                name="new_kernel_version"
                                id="new_kernel_version"
                                placeholder="Example: 5.14.0-570.el9"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Change Request / CRQ
                            </label>

                            <input
                                type="text"
                                name="change_request"
                                id="change_request"
                                placeholder="CHG0012345"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Assignee
                            </label>

                            <select
                                name="assignee_id"
                                id="assignee_id"
                            >

                                <option value="">
                                    Unassigned
                                </option>

                                <?php foreach (
                                    $users
                                    as $user
                                ): ?>

                                    <option
                                        value="<?= (int) $user['id'] ?>"
                                    >

                                        <?= h(
                                            trim(
                                                $user['first_name'] .
                                                ' ' .
                                                $user['last_name']
                                            )
                                        ) ?>

                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>


                        <div class="grc-field">

                            <label>
                                Status
                            </label>

                            <select
                                name="status"
                                id="status"
                            >

                                <?php foreach (
                                    $statuses
                                    as $status
                                ): ?>

                                    <option
                                        value="<?= h($status) ?>"
                                    >
                                        <?= h($status) ?>
                                    </option>

                                <?php endforeach; ?>

                            </select>

                        </div>


                        <div class="grc-field full">

                            <label>
                                Comments
                            </label>

                            <textarea
                                name="comments"
                                id="comments"
                                rows="5"
                                placeholder="Patch notes, validation results, exceptions..."
                            ></textarea>

                        </div>


                        <div class="grc-field full">

                            <label>
                                Attachment
                            </label>

                            <input
                                type="file"
                                name="attachment"
                                accept=".pdf,.eml,.msg,.doc,.docx,.xls,.xlsx"
                            >

                            <small>
                                Maximum 15 MB.
                            </small>

                        </div>


                    </div>

                </div>

            </div>


            <div class="grc-modal-footer">

                <button
                    type="button"
                    onclick="closeGrcModal()"
                    class="grc-btn secondary"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="grc-btn primary"
                >
                    Save Schedule
                </button>

            </div>

        </form>

    </div>

</div>

<?php endif; ?>


<!-- ====================================================================== -->
<!-- HOSTS MODAL -->
<!-- ====================================================================== -->

<div
    id="hostsModal"
    class="grc-modal"
>

    <div class="grc-modal-box large">

        <div class="grc-modal-header">

            <div>

                <h2>
                    Schedule Hosts
                </h2>

                <span id="hostsModalSubtitle">
                    Hosts included in this schedule
                </span>

            </div>

            <button
                type="button"
                onclick="closeHostsModal()"
                class="grc-modal-close"
            >
                ×
            </button>

        </div>


        <div
            class="grc-modal-body"
            id="hostsContainer"
        >
            Loading...
        </div>

    </div>

</div>


<!-- ====================================================================== -->
<!-- HISTORY MODAL (per-host patch execution log) -->
<!-- ====================================================================== -->

<?php if ($can_audit): ?>

<div
    id="historyModal"
    class="grc-modal"
>

    <div class="grc-modal-box large">

        <div class="grc-modal-header">

            <div>

                <h2>
                    Patch History
                </h2>

                <span>
                    Previous GRC patch records
                </span>

            </div>

            <button
                type="button"
                onclick="closeHistoryModal()"
                class="grc-modal-close"
            >
                ×
            </button>

        </div>


        <div
            class="grc-modal-body"
            id="historyContainer"
        >
            Loading...
        </div>

    </div>

</div>


<!-- ====================================================================== -->
<!-- AUDIT LOG MODAL (page history -- global or per-schedule) -->
<!-- ====================================================================== -->

<div
    id="auditLogModal"
    class="grc-modal"
>

    <div class="grc-modal-box large">

        <div class="grc-modal-header">

            <div>

                <h2 id="auditLogModalTitle">
                    Audit History
                </h2>

                <span>
                    Who created, updated, or deleted each GRC schedule
                </span>

            </div>

            <button
                type="button"
                onclick="closeAuditLogModal()"
                class="grc-modal-close"
            >
                ×
            </button>

        </div>


        <div
            class="grc-modal-body"
            id="auditLogContainer"
        >
            Loading...
        </div>

    </div>

</div>

<?php endif; ?>


<script>

const grcInventory =
    <?= json_encode(
        $inventory_servers,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;

const grcCombos =
    <?= json_encode(
        $project_support_combos,
        JSON_HEX_TAG |
        JSON_HEX_APOS |
        JSON_HEX_QUOT |
        JSON_HEX_AMP
    ) ?>;

const grcCanEdit =
    <?= $can_edit ? 'true' : 'false' ?>;

const grcCanAudit =
    <?= $can_audit ? 'true' : 'false' ?>;


/*
|--------------------------------------------------------------------------
| Modal
|--------------------------------------------------------------------------
*/

function openGrcModal() {

    if (!grcCanEdit) {
        alert(
            'You do not have permission to perform this action.'
        );
        return;
    }

    const modal =
        document.getElementById('grcModal');

    if (!modal) {
        return;
    }

    modal.classList.add('open');

    document
        .getElementById('grcModalTitle')
        .textContent =
        'New GRC Schedule';

    document
        .getElementById('schedule_id')
        .value = '0';

    document
        .getElementById('project')
        .value = '';

    document
        .getElementById('support_level')
        .innerHTML =
        '<option value="">Select a project first</option>';

    document
        .getElementById('recurrence_interval_days')
        .value = '30';

    document
        .getElementById('scheduled_time')
        .value = '';

    document
        .getElementById('patched_time')
        .value = '';

    document
        .getElementById('display_next_date')
        .value = '';

    document
        .getElementById('new_os_version')
        .value = '';

    document
        .getElementById('new_kernel_version')
        .value = '';

    document
        .getElementById('change_request')
        .value = '';

    document
        .getElementById('comments')
        .value = '';

    document
        .getElementById('assignee_id')
        .value = '';

    document
        .getElementById('status')
        .value = 'Planned';

    showMatchingHostCount();
}


function closeGrcModal() {

    const modal =
        document.getElementById('grcModal');

    if (modal) {
        modal.classList.remove('open');
    }
}


/*
|--------------------------------------------------------------------------
| Project -> Support Level cascade (both sourced from Inventory)
|--------------------------------------------------------------------------
*/

function onGrcProjectChange(preselectSupportLevel) {

    const project =
        document.getElementById('project').value;

    const levelSelect =
        document.getElementById('support_level');

    const levels = [...new Set(
        grcCombos
            .filter(c => c.project === project)
            .map(c => c.support_level)
    )];

    levelSelect.innerHTML =
        '<option value="">Select support level</option>';

    levels.forEach(function (level) {

        const option =
            document.createElement('option');

        option.value = level;
        option.textContent = level;

        levelSelect.appendChild(option);
    });

    if (
        preselectSupportLevel &&
        levels.includes(preselectSupportLevel)
    ) {
        levelSelect.value = preselectSupportLevel;
    }

    showMatchingHostCount();
}


/*
|--------------------------------------------------------------------------
| Matching Hosts (now matches BOTH project and support level, not
| support level alone)
|--------------------------------------------------------------------------
*/

function showMatchingHostCount() {

    const project =
        document
            .getElementById('project')
            .value;

    const level =
        document
            .getElementById('support_level')
            .value;

    const text =
        document
            .getElementById('matchingHostText');

    if (!project || !level) {

        text.textContent =
            'Select a project and support level.';

        return;
    }


    const count =
        grcInventory.filter(
            host =>
                String(host.project || '') === String(project) &&
                String(host.support_level || '') === String(level)
        ).length;


    text.textContent =
        count +
        ' GRC host(s) will automatically be included.';
}


/*
|--------------------------------------------------------------------------
| Edit
|--------------------------------------------------------------------------
*/

function editGrc(row) {

    if (!grcCanEdit) {

        alert(
            'You do not have permission to perform this action.'
        );

        return;
    }

    openGrcModal();

    document
        .getElementById('grcModalTitle')
        .textContent =
        'Edit GRC Schedule';

    document
        .getElementById('schedule_id')
        .value =
        row.id;

    document
        .getElementById('project')
        .value =
        row.project || '';

    onGrcProjectChange(row.support_level || '');

    document
        .getElementById(
            'recurrence_interval_days'
        )
        .value =
        row.recurrence_interval_days || 30;

    document
        .getElementById('scheduled_time')
        .value =
        formatDateTimeLocal(
            row.scheduled_time
        );

    document
        .getElementById('patched_time')
        .value =
        formatDateTimeLocal(
            row.patched_time
        );

    document
        .getElementById('display_next_date')
        .value =
        row.next_date || '';

    document
        .getElementById('new_os_version')
        .value =
        row.new_os_version || '';

    document
        .getElementById('new_kernel_version')
        .value =
        row.new_kernel_version || '';

    document
        .getElementById('change_request')
        .value =
        row.change_request || '';

    document
        .getElementById('comments')
        .value =
        row.comments || '';

    document
        .getElementById('assignee_id')
        .value =
        row.assignee_id || '';

    document
        .getElementById('status')
        .value =
        row.status || 'Planned';
}


/*
|--------------------------------------------------------------------------
| Date
|--------------------------------------------------------------------------
*/

function formatDateTimeLocal(value) {

    if (!value) {
        return '';
    }

    return String(value)
        .replace(' ', 'T')
        .substring(0, 16);
}


/*
|--------------------------------------------------------------------------
| Calculate Next Date
|--------------------------------------------------------------------------
*/

function updateNextDatePreview() {

    const patched =
        document
            .getElementById('patched_time')
            .value;

    const recurrence =
        parseInt(
            document
                .getElementById(
                    'recurrence_interval_days'
                )
                .value,
            10
        ) || 30;


    if (!patched) {

        document
            .getElementById(
                'display_next_date'
            )
            .value = '';

        return;
    }


    const date =
        new Date(patched);

    date.setDate(
        date.getDate() + recurrence
    );


    const year =
        date.getFullYear();

    const month =
        String(
            date.getMonth() + 1
        ).padStart(2, '0');

    const day =
        String(
            date.getDate()
        ).padStart(2, '0');


    document
        .getElementById(
            'display_next_date'
        )
        .value =
        year +
        '-' +
        month +
        '-' +
        day;
}


document
    .getElementById('patched_time')
    ?.addEventListener(
        'change',
        updateNextDatePreview
    );


document
    .getElementById(
        'recurrence_interval_days'
    )
    ?.addEventListener(
        'input',
        updateNextDatePreview
    );


/*
|--------------------------------------------------------------------------
| View Hosts
|--------------------------------------------------------------------------
*/

async function viewHosts(scheduleId) {

    const modal =
        document.getElementById(
            'hostsModal'
        );

    const container =
        document.getElementById(
            'hostsContainer'
        );

    modal.classList.add('open');

    container.innerHTML =
        '<div class="grc-loading">Loading hosts...</div>';


    try {

        const response =
            await fetch(
                'grc_schedule.php?action=hosts&id=' +
                encodeURIComponent(scheduleId)
            );


        const data =
            await response.json();


        if (!data.success) {

            container.innerHTML =
                '<div class="grc-alert error">' +
                escapeHtml(
                    data.message ||
                    'Unable to load hosts.'
                ) +
                '</div>';

            return;
        }


        document
            .getElementById(
                'hostsModalSubtitle'
            )
            .textContent =
            data.schedule.project +
            ' / ' +
            data.schedule.support_level;


        let html = '';


        html +=
            '<div class="grc-host-summary">' +
            '<strong>' +
            data.hosts.length +
            '</strong> host(s)' +
            '</div>';


        html +=
            '<div class="grc-table-wrapper">' +
            '<table class="grc-table">' +
            '<thead>' +
            '<tr>' +
            '<th>Hostname</th>' +
            '<th>IP</th>' +
            '<th>Application</th>' +
            '<th>OS</th>' +
            '<th>Kernel</th>' +
            '<th>Status</th>' +
            '<th>Excluded</th>' +
            '<th>Comment</th>' +
            '<th>Action</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';


        data.hosts.forEach(
            function(host) {

                html += '<tr>';


                html +=
                    '<td><strong>' +
                    escapeHtml(
                        host.hostname
                    ) +
                    '</strong></td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        host.ip_address || ''
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        host.application || ''
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        (
                            host.os_family || ''
                        ) +
                        ' ' +
                        (
                            host.os_version || ''
                        )
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        host.kernel_version || ''
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        host.host_status ||
                        'Planned'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    (
                        Number(
                            host.excluded
                        ) === 1
                            ? 'Yes'
                            : 'No'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        host.host_comment || ''
                    ) +
                    '</td>';


                html += '<td>';

                if (grcCanEdit) {

                    const hostJson =
                        JSON.stringify(host)
                            .replace(
                                /'/g,
                                '&#39;'
                            );

                    html +=
                        '<button ' +
                        'type="button" ' +
                        'class="action-edit" ' +
                        'onclick=\'editHost(' +
                        hostJson +
                        ')\'>' +
                        'Update' +
                        '</button>';
                } else {

                    html +=
                        '<span class="muted">' +
                        'View only' +
                        '</span>';
                }

                html += '</td>';

                html += '</tr>';
            }
        );


        html +=
            '</tbody>' +
            '</table>' +
            '</div>';


        container.innerHTML =
            html;


    } catch (error) {

        container.innerHTML =
            '<div class="grc-alert error">' +
            'Unable to load hosts.' +
            '</div>';
    }
}


function closeHostsModal() {

    document
        .getElementById('hostsModal')
        .classList.remove('open');
}


/*
|--------------------------------------------------------------------------
| Edit Host
|--------------------------------------------------------------------------
*/

function editHost(host) {

    if (!grcCanEdit) {

        alert(
            'You do not have permission to perform this action.'
        );

        return;
    }


    const existing =
        document.getElementById(
            'hostEditModal'
        );

    if (existing) {
        existing.remove();
    }


    const modal =
        document.createElement('div');

    modal.id =
        'hostEditModal';

    modal.className =
        'grc-modal open';


    modal.innerHTML = `

        <div class="grc-modal-box">

            <div class="grc-modal-header">

                <div>

                    <h2>
                        Update Host
                    </h2>

                    <span>
                        ${escapeHtml(
                            host.hostname || ''
                        )}
                    </span>

                </div>

                <button
                    type="button"
                    class="grc-modal-close"
                    onclick="this.closest('.grc-modal').remove()"
                >
                    ×
                </button>

            </div>


            <form
                method="POST"
                action="grc_schedule.php"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h($csrf_token) ?>"
                >

                <input
                    type="hidden"
                    name="form_action"
                    value="save_host"
                >

                <input
                    type="hidden"
                    name="schedule_id"
                    value="${host.schedule_id}"
                >

                <input
                    type="hidden"
                    name="host_id"
                    value="${host.inventory_id}"
                >


                <div class="grc-modal-body">

                    <div class="grc-form-grid">


                        <div class="grc-field full">

                            <label>
                                Hostname
                            </label>

                            <input
                                type="text"
                                readonly
                                value="${escapeHtml(
                                    host.hostname || ''
                                )}"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Status
                            </label>

                            <select
                                name="host_status"
                            >

                                ${[
                                    'Planned',
                                    'Scheduled',
                                    'In Progress',
                                    'Patched',
                                    'Failed',
                                    'Skipped',
                                    'Cancelled'
                                ].map(
                                    status =>
                                    '<option value="' +
                                    escapeHtml(status) +
                                    '"' +
                                    (
                                        status ===
                                        (
                                            host.host_status ||
                                            'Planned'
                                        )
                                            ? ' selected'
                                            : ''
                                    ) +
                                    '>' +
                                    escapeHtml(status) +
                                    '</option>'
                                ).join('')}

                            </select>

                        </div>


                        <div class="grc-field">

                            <label>
                                Patched Time
                            </label>

                            <input
                                type="datetime-local"
                                name="host_patched_time"
                                value="${formatDateTimeLocal(
                                    host.host_patched_time
                                )}"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                New OS Version
                            </label>

                            <input
                                type="text"
                                name="host_os_version"
                                value="${escapeHtml(
                                    host.host_os_version ||
                                    ''
                                )}"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                New Kernel Version
                            </label>

                            <input
                                type="text"
                                name="host_kernel_version"
                                value="${escapeHtml(
                                    host.host_kernel_version ||
                                    ''
                                )}"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                CRQ
                            </label>

                            <input
                                type="text"
                                name="host_change_request"
                                value="${escapeHtml(
                                    host.host_change_request ||
                                    ''
                                )}"
                            >

                        </div>


                        <div class="grc-field">

                            <label>
                                Exclude Host
                            </label>

                            <label
                                style="display:flex;gap:8px;align-items:center;"
                            >

                                <input
                                    type="checkbox"
                                    name="excluded"
                                    value="1"
                                    ${
                                        Number(
                                            host.excluded
                                        ) === 1
                                            ? 'checked'
                                            : ''
                                    }
                                >

                                Excluded from this patch cycle

                            </label>

                        </div>


                        <div class="grc-field full">

                            <label>
                                Host Comment
                            </label>

                            <textarea
                                name="host_comment"
                                rows="5"
                                placeholder="Why was this host excluded? Patch issue? Validation notes?"
                            >${escapeHtml(
                                host.host_comment || ''
                            )}</textarea>

                        </div>


                    </div>

                </div>


                <div class="grc-modal-footer">

                    <button
                        type="button"
                        class="grc-btn secondary"
                        onclick="this.closest('.grc-modal').remove()"
                    >
                        Cancel
                    </button>

                    <button
                        type="submit"
                        class="grc-btn primary"
                    >
                        Save Host
                    </button>

                </div>

            </form>

        </div>
    `;


    document.body.appendChild(
        modal
    );
}


/*
|--------------------------------------------------------------------------
| Patch History (per-host execution log)
|--------------------------------------------------------------------------
*/

async function viewHistory(scheduleId) {

    if (!grcCanAudit) {

        alert(
            'You do not have permission to view audit history.'
        );

        return;
    }


    const modal =
        document.getElementById(
            'historyModal'
        );

    const container =
        document.getElementById(
            'historyContainer'
        );


    if (!modal || !container) {
        return;
    }


    modal.classList.add('open');

    container.innerHTML =
        '<div class="grc-loading">Loading history...</div>';


    try {

        const response =
            await fetch(
                'grc_schedule.php?action=history&id=' +
                encodeURIComponent(scheduleId)
            );


        const data =
            await response.json();


        if (!data.success) {

            container.innerHTML =
                '<div class="grc-alert error">' +
                escapeHtml(
                    data.message ||
                    'Unable to load history.'
                ) +
                '</div>';

            return;
        }


        if (!data.history.length) {

            container.innerHTML =
                '<div class="grc-empty">' +
                'No patch history recorded yet.' +
                '</div>';

            return;
        }


        let html =
            '<div class="grc-table-wrapper">' +
            '<table class="grc-table">' +
            '<thead>' +
            '<tr>' +
            '<th>Date</th>' +
            '<th>Hostname</th>' +
            '<th>Kernel</th>' +
            '<th>OS</th>' +
            '<th>CRQ</th>' +
            '<th>Status</th>' +
            '<th>Notes</th>' +
            '<th>Changed By</th>' +
            '</tr>' +
            '</thead>' +
            '<tbody>';


        data.history.forEach(
            function(item) {

                html += '<tr>';


                html +=
                    '<td>' +
                    escapeHtml(
                        formatDisplayDate(
                            item.patched_time ||
                            item.created_at
                        )
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.hostname ||
                        'Schedule'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.kernel_version ||
                        '—'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.os_version ||
                        '—'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.change_request ||
                        '—'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.status ||
                        '—'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.comments ||
                        '—'
                    ) +
                    '</td>';


                html +=
                    '<td>' +
                    escapeHtml(
                        item.changed_by_name ||
                        'Unknown'
                    ) +
                    '</td>';


                html += '</tr>';
            }
        );


        html +=
            '</tbody>' +
            '</table>' +
            '</div>';


        container.innerHTML =
            html;


    } catch (error) {

        container.innerHTML =
            '<div class="grc-alert error">' +
            'Unable to load history.' +
            '</div>';
    }
}


function closeHistoryModal() {

    const modal =
        document.getElementById(
            'historyModal'
        );

    if (modal) {
        modal.classList.remove('open');
    }
}


/*
|--------------------------------------------------------------------------
| Audit Log (page history -- global or per-schedule field-level trail)
|--------------------------------------------------------------------------
*/

async function viewAuditLog(scheduleId) {

    if (!grcCanAudit) {

        alert(
            'You do not have permission to view audit history.'
        );

        return;
    }

    const modal =
        document.getElementById('auditLogModal');

    const container =
        document.getElementById('auditLogContainer');

    if (!modal || !container) {
        return;
    }

    document
        .getElementById('auditLogModalTitle')
        .textContent = scheduleId
            ? 'Schedule Audit History (#' + scheduleId + ')'
            : 'Module Audit History';

    modal.classList.add('open');

    container.innerHTML =
        '<div class="grc-loading">Loading audit history...</div>';

    const url = scheduleId
        ? 'grc_schedule.php?action=audit_log&id=' + encodeURIComponent(scheduleId)
        : 'grc_schedule.php?action=audit_log';

    try {

        const response = await fetch(url);
        const data = await response.json();

        if (!data.success) {
            container.innerHTML =
                '<div class="grc-alert error">' +
                escapeHtml(data.message || 'Unable to load audit history.') +
                '</div>';
            return;
        }

        if (!data.logs.length) {
            container.innerHTML =
                '<div class="grc-empty">No audit history found.</div>';
            return;
        }

        let html =
            '<div class="grc-table-wrapper">' +
            '<table class="grc-table">' +
            '<thead><tr>' +
            '<th>Date</th>' +
            '<th>Schedule</th>' +
            '<th>Action</th>' +
            '<th>Field</th>' +
            '<th>Old Value</th>' +
            '<th>New Value</th>' +
            '<th>Changed By</th>' +
            '</tr></thead><tbody>';

        data.logs.forEach(function (log) {

            html += '<tr>';
            html += '<td>' + escapeHtml(formatDisplayDate(log.created_at)) + '</td>';
            html += '<td>' + escapeHtml((log.project || '') + (log.support_level ? ' / ' + log.support_level : '')) + '</td>';
            html += '<td>' + escapeHtml(log.action || '') + '</td>';
            html += '<td>' + escapeHtml(log.field_name || '—') + '</td>';
            html += '<td class="grc-audit-old">' + escapeHtml(log.old_value || '—') + '</td>';
            html += '<td class="grc-audit-new">' + escapeHtml(log.new_value || '—') + '</td>';
            html += '<td>' + escapeHtml(log.changed_by_name || 'Unknown') + '</td>';
            html += '</tr>';
        });

        html += '</tbody></table></div>';

        container.innerHTML = html;

    } catch (error) {
        container.innerHTML =
            '<div class="grc-alert error">Unable to load audit history.</div>';
    }
}


function closeAuditLogModal() {

    const modal =
        document.getElementById('auditLogModal');

    if (modal) {
        modal.classList.remove('open');
    }
}


/*
|--------------------------------------------------------------------------
| JavaScript Helpers
|--------------------------------------------------------------------------
*/

function escapeHtml(value) {

    const div =
        document.createElement('div');

    div.textContent =
        value == null
            ? ''
            : String(value);

    return div.innerHTML;
}


function formatDisplayDate(value) {

    if (!value) {
        return '—';
    }

    const date =
        new Date(
            String(value).replace(
                ' ',
                'T'
            )
        );

    if (
        Number.isNaN(
            date.getTime()
        )
    ) {
        return value;
    }

    return date.toLocaleString();
}


/*
|--------------------------------------------------------------------------
| Pagination
|--------------------------------------------------------------------------
*/

/*
|--------------------------------------------------------------------------
| Background Click
|--------------------------------------------------------------------------
*/

document
    .querySelectorAll('.grc-modal')
    .forEach(
        function(modal) {

            modal.addEventListener(
                'click',
                function(event) {

                    if (
                        event.target === this
                    ) {

                        this.classList.remove(
                            'open'
                        );
                    }

                }
            );

        }
    );

</script>


<?php

require_once 'includes/footer.php';

?>