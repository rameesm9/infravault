<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('ip', 'can_view');
requirePermission('ip', 'can_export');



$role=$_SESSION['role'] ?? 'User';



if(
    $role!="Admin" &&
    $role!="Edit"
){

    die("Permission denied");

}

/*
=====================================================
CAPTURE FILTER PARAMETERS
=====================================================
*/

$keyword = trim($_GET['keyword'] ?? "");
$s_ip_range = trim($_GET['s_ip_range'] ?? "");
$s_vlan = trim($_GET['s_vlan'] ?? "");
$s_project = trim($_GET['s_project'] ?? "");
$s_environment = trim($_GET['s_environment'] ?? "");
$s_gateway = trim($_GET['s_gateway'] ?? "");
$s_usable_hosts_min = trim($_GET['s_usable_hosts_min'] ?? "");
$s_usable_hosts_max = trim($_GET['s_usable_hosts_max'] ?? "");

/*
=====================================================
BUILD QUERY WITH FILTERS
=====================================================
*/

$sql = "
SELECT
    ip_range,
    vlan,
    subnet,
    gateway,
    environment,
    project,
    project_code,
    portgroup,
    cidr,
    usable_range,
    broadcast,
    total_hosts,
    usable_hosts,
    comments,
    created_by,
    created_at,
    updated_by,
    updated_at
FROM ip_ranges
WHERE 1=1
";

$params = [];

// General keyword search
if($keyword!=""){
    $sql.="
    AND
    (
    ip_range LIKE ?
    OR vlan LIKE ?
    OR project LIKE ?
    OR gateway LIKE ?
    OR environment LIKE ?
    )
    ";

    $search="%".$keyword."%";
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
}

// Individual field searches
if($s_ip_range!=""){
    $sql.=" AND ip_range LIKE ?";
    $params[]="%" . $s_ip_range . "%";
}

if($s_vlan!=""){
    $sql.=" AND vlan LIKE ?";
    $params[]="%" . $s_vlan . "%";
}

if($s_project!=""){
    $sql.=" AND project LIKE ?";
    $params[]="%" . $s_project . "%";
}

if($s_environment!=""){
    $sql.=" AND environment = ?";
    $params[]=$s_environment;
}

if($s_gateway!=""){
    $sql.=" AND gateway LIKE ?";
    $params[]="%" . $s_gateway . "%";
}

if($s_usable_hosts_min!=""){
    $min_val = (int)$s_usable_hosts_min;
    $sql.=" AND usable_hosts >= ?";
    $params[]=$min_val;
}

if($s_usable_hosts_max!=""){
    $max_val = (int)$s_usable_hosts_max;
    $sql.=" AND usable_hosts <= ?";
    $params[]=$max_val;
}

$sql .= " ORDER BY id DESC";

$stmt=$pdo->prepare($sql);
$stmt->execute($params);

$rows=$stmt->fetchAll(PDO::FETCH_ASSOC);





/*
====================================
CSV HEADER
====================================
*/


$file="ip_ranges_".date("Y-m-d_H-i-s").".csv";



header("Content-Type: text/csv; charset=UTF-8");

header(
"Content-Disposition: attachment; filename=".$file
);



/*
Excel UTF-8 support
*/

echo "\xEF\xBB\xBF";




$output=fopen("php://output","w");




$headers=[

"IP Range",

"VLAN",

"Subnet",

"Gateway",

"Environment",

"Project",

"Project Code",

"Port Group",

"CIDR",

"Usable Range",

"Broadcast",

"Total Hosts",

"Usable Hosts",

"Comments",

"Created By",

"Created Date",

"Updated By",

"Updated Date"

];



fputcsv($output,$headers);





foreach($rows as $row){


fputcsv($output,[

$row['ip_range'],

$row['vlan'],

$row['subnet'],

$row['gateway'],

$row['environment'],

$row['project'],

$row['project_code'],

$row['portgroup'],

$row['cidr'],

$row['usable_range'],

$row['broadcast'],

$row['total_hosts'],

$row['usable_hosts'],

$row['comments'],

$row['created_by'],

$row['created_at'],

$row['updated_by'],

$row['updated_at']

]);


}



fclose($output);

exit;


?>
