<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('ip', 'can_view');



$user_id=$_SESSION['user_id'];



$default_columns=[

"ip_range",
"cidr",
"vlan",
"subnet",
"gateway",
"environment",
"project",
"usable_hosts",
"created_by",
"created_at"

];



$available=[


"ip_range"=>"IP Range",

"cidr"=>"CIDR",

"vlan"=>"VLAN",

"subnet"=>"Subnet",

"gateway"=>"Gateway",

"environment"=>"Environment",

"project"=>"Project",

"portgroup"=>"Port Group",

"usable_range"=>"Usable Range",

"broadcast"=>"Broadcast",

"total_hosts"=>"Total Hosts",

"usable_hosts"=>"Usable Hosts",

"comments"=>"Comments",

"created_by"=>"Created By",

"created_at"=>"Created Date",

"updated_by"=>"Updated By",

"updated_at"=>"Updated Date"


];




/*
===================================
SAVE
===================================
*/


if($_SERVER['REQUEST_METHOD']=="POST"){


if(isset($_POST['reset'])){


    $columns=$default_columns;


}
else{


    $columns=$_POST['columns'] ?? $default_columns;


}




$json=json_encode($columns);



$stmt=$pdo->prepare("

SELECT id

FROM ip_column_preferences

WHERE user_id=?

");

$stmt->execute([$user_id]);





if($stmt->fetch()){



$stmt=$pdo->prepare("

UPDATE ip_column_preferences

SET columns=?,

updated_at=CURRENT_TIMESTAMP

WHERE user_id=?

");


$stmt->execute([

$json,

$user_id

]);



}
else{


$stmt=$pdo->prepare("

INSERT INTO ip_column_preferences

(
user_id,
columns

)

VALUES
(?,?)

");

$stmt->execute([

$user_id,

$json

]);


}




header("Location:ip.php");

exit;


}






/*
===================================
LOAD CURRENT
===================================
*/


$stmt=$pdo->prepare("

SELECT columns

FROM ip_column_preferences

WHERE user_id=?

");


$stmt->execute([$user_id]);



$result=$stmt->fetchColumn();



if($result){

$current=json_decode($result,true);

}
else{

$current=$default_columns;

}




?>



<link rel="stylesheet" href="assets/css/ip.css">



<div class="content">


<div class="ip-page">



<div class="page-header">


<div>

<h1>
Customize IP Table
</h1>


<p>
Select the fields you want to display
</p>


</div>



<a href="ip.php"
class="secondary-btn">

Back

</a>


</div>





<div class="ip-card"
style="padding:30px">





<form method="POST">



<div class="column-grid">



<?php foreach($available as $key=>$label): ?>



<label class="column-option">


<input

type="checkbox"

name="columns[]"

value="<?=$key?>"

<?=in_array($key,$current)?"checked":""?>

>


<span>

<?=$label?>

</span>


</label>



<?php endforeach; ?>



</div>





<br>



<div style="display:flex;gap:10px">



<button class="primary-btn">

Save Columns

</button>




<button

class="secondary-btn"

name="reset"

value="1">

Reset Default

</button>



</div>




</form>



</div>


</div>


</div>



<style>


.column-grid{


display:grid;

grid-template-columns:

repeat(3,1fr);

gap:15px;


}



.column-option{


background:var(--hover-bg, #f8fafc);

border:1px solid var(--border-color, #e5e7eb);

padding:15px;

border-radius:10px;

display:flex;

gap:10px;

align-items:center;

cursor:pointer;

}



.column-option:hover{

background:#eff6ff;

}



@media(max-width:900px){


.column-grid{

grid-template-columns:1fr;

}


}



</style>
