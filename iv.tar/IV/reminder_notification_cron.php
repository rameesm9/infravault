<?php

// reminder_notification_cron.php
//
// One-shot check: run this once via a traditional crontab / systemd
// timer / Task Scheduler entry. It is NOT meant to be opened in a
// browser — it has no session/auth check because it's a command-line
// script.
//
// Reminders carry a specific date AND time (not just a date), so this
// needs to run often to notify close to the time the user actually
// asked for -- e.g. every minute.
//
// Example crontab (every minute):
//   * * * * * /usr/bin/php /var/www/html/reminder_notification_cron.php >> /var/log/infravault_reminders.log 2>&1
//
// If you don't have a cron daemon available (common in a minimal
// container image), use reminder_notification_daemon.php instead --
// it's a self-contained long-running loop that needs no external
// scheduler at all.

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script may only be run from the command line.\n");
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/reminder-mail.php';

echo "InfraVault reminder notification run — " . date('Y-m-d H:i:s') . "\n";

$result = checkAndSendDueReminders($pdo);

foreach ($result['log'] as $line) {
    echo $line . "\n";
}

if ($result['considered'] === 0) {
    echo "Nothing due. Done.\n";
    exit(0);
}

echo "Done. {$result['sent']} reminder(s) fully sent, {$result['failed']} with at least one failed recipient, {$result['considered']} total considered.\n";

exit($result['failed'] > 0 ? 1 : 0);
