<?php
/**
 * LDAP connectivity / authentication test.
 *
 * index.php deliberately collapses every LDAP failure into "User not
 * found." so the login page cannot be used to enumerate directory
 * accounts. That is right for the login page and useless for debugging,
 * so this prints the real reason authenticateAgainstLdap() returned.
 *
 * Run inside the container:
 *
 *   podman exec -it ivportal php /var/www/html/deploy/test-ldap.php USERNAME
 *
 * The password is read from stdin, never from argv -- an argument would
 * be visible to anyone running ps.
 */

chdir(dirname(__DIR__));

require_once 'config/db.php';
require_once 'includes/ldap-helpers.php';

$username = $argv[1] ?? '';
if ($username === '') {
    fwrite(STDERR, "usage: php deploy/test-ldap.php USERNAME\n");
    exit(1);
}

echo "=== 1. environment\n";
printf("  php ldap extension : %s\n", extension_loaded('ldap') ? 'loaded' : '*** MISSING ***');
printf("  database in use    : %s\n", $GLOBALS['db_file'] ?? '(unknown)');

echo "\n=== 2. effective settings (database, with env overrides applied)\n";
$s = getLdapSettingsRow($pdo);
foreach (['is_enabled', 'host', 'port', 'encryption', 'base_dn', 'bind_dn',
          'user_search_filter', 'default_role', 'verify_certificate'] as $k) {
    printf("  %-20s %s\n", $k, ($s[$k] === '' || $s[$k] === null) ? '(empty)' : $s[$k]);
}
printf("  %-20s %s\n", 'bind_password', trim((string) $s['bind_password']) === '' ? '(EMPTY - anonymous bind)' : '(set)');
printf("  %-20s %s\n", 'ca_cert', trim((string) $s['ca_cert']) === '' ? '(none - system trust store only)' : strlen($s['ca_cert']) . ' bytes');

$overrides = getLdapEnvOverrides();
printf("\n  env overrides active: %s\n", $overrides ? implode(', ', $overrides) : 'none (all values come from Settings)');

echo "\n=== 3. can this container reach the directory?\n";
$host = (string) $s['host'];
$port = (int) $s['port'];

$ip = @gethostbyname($host);
printf("  DNS   %s -> %s\n", $host, ($ip === $host) ? '*** DID NOT RESOLVE ***' : $ip);

$t0 = microtime(true);
$sock = @fsockopen(($s['encryption'] === 'ldaps' ? 'ssl://' : 'tcp://') . $host, $port, $errno, $errstr, 10);
if ($sock) {
    printf("  TCP   %s:%d -> open (%.0f ms)\n", $host, $port, (microtime(true) - $t0) * 1000);
    fclose($sock);
} else {
    printf("  TCP   %s:%d -> FAILED: %s (%d)\n", $host, $port, $errstr, $errno);
    echo "        A container cannot reach the DC if podman's network has no\n";
    echo "        route to it, or if the host firewall blocks 636 outbound.\n";
}

echo "\n=== 4. full authentication attempt\n";
echo "  password for {$username}: ";
system('stty -echo 2>/dev/null');
$password = trim((string) fgets(STDIN));
system('stty echo 2>/dev/null');
echo "\n";

$r = authenticateAgainstLdap($pdo, $username, $password);

printf("\n  result : %s\n", $r['success'] ? 'SUCCESS' : 'FAILED');
printf("  reason : %s\n", $r['message'] ?? '(none)');

if ($r['success']) {
    echo "\n  directory attributes returned:\n";
    foreach ($r['attributes'] as $k => $v) { printf("    %-16s %s\n", $k, $v); }

    $st = $pdo->prepare("SELECT ncgr_id, role, is_approved, auth_source FROM users WHERE ncgr_id = ?");
    $st->execute([$r['attributes']['samaccountname']]);
    $u = $st->fetch(PDO::FETCH_ASSOC);

    echo "\n  local users row: " . ($u ? json_encode($u) : 'none yet - first login will create it as pending');
    echo "\n";
    if ($u && (int) $u['is_approved'] !== 1) {
        echo "  NOTE: the account exists but is_approved=0, so login reports\n";
        echo "        \"waiting for administrator approval\". Approve it under Users.\n";
    }
} else {
    echo "\n  what that reason means:\n";
    $m = $r['message'];
    if (str_contains($m, 'not enabled'))            echo "    Settings -> LDAP -> enable, and set a host.\n";
    elseif (str_contains($m, 'initialize'))          echo "    The host/port string is malformed.\n";
    elseif (str_contains($m, 'STARTTLS'))            echo "    TLS negotiation failed - usually the CA cert. Paste your\n"
                                                        . "    internal CA PEM into Settings -> LDAP -> CA certificate,\n"
                                                        . "    or untick 'verify certificate' to confirm that is the cause.\n";
    elseif (str_contains($m, 'Service account'))     echo "    bind_dn / bind_password are wrong, or the account is locked.\n"
                                                        . "    Try the same DN with ldapsearch from the host to confirm.\n";
    elseif (str_contains($m, 'search failed'))       echo "    base_dn is wrong, or the service account cannot read it.\n";
    elseif (str_contains($m, 'not found in directory')) echo "    The bind worked; the filter did not match. Check\n"
                                                        . "    user_search_filter (default (sAMAccountName=%s) is AD-specific)\n"
                                                        . "    and that base_dn contains this user.\n";
    elseif (str_contains($m, 'Invalid username'))    echo "    Everything worked except the user's own password.\n";
    else                                             echo "    (unrecognised - paste this output)\n";
}
