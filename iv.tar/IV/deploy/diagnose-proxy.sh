#!/bin/bash
# Collects everything needed to identify why :443 fails while :8080 works.
# Read-only -- changes nothing. Run on the container host as root.

echo "=========== 1. is SELinux really off?"
command -v getenforce >/dev/null && getenforce || echo "  getenforce not present"
command -v sestatus   >/dev/null && sestatus | head -5
echo "  (Permissive/Disabled here rules SELinux out; Enforcing does not)"

echo
echo "=========== 2. what is listening on 8080?"
ss -lntp 2>/dev/null | grep -E ':8080|:443' || netstat -lntp 2>/dev/null | grep -E ':8080|:443'
echo "  127.0.0.1:8080 = loopback only (correct with a local proxy)"
echo "  0.0.0.0:8080   = reachable from anywhere, bypassing TLS"

echo
echo "=========== 3. can the host itself reach the backend?"
curl -sS -o /dev/null -w '  direct  127.0.0.1:8080/        -> %{http_code}\n' http://127.0.0.1:8080/ 2>&1
curl -sS -o /dev/null -w '  direct  127.0.0.1:8080/index.php -> %{http_code}\n' http://127.0.0.1:8080/index.php 2>&1

echo
echo "=========== 4. through the proxy"
curl -skS -o /dev/null -w '  https   /            -> %{http_code}\n' https://infravault.mof.gov.sa/ 2>&1
curl -skS -o /dev/null -w '  https   /index.php   -> %{http_code}\n' https://infravault.mof.gov.sa/index.php 2>&1
echo
echo "  --- full response headers and body for the failing request:"
curl -skS -D - https://infravault.mof.gov.sa/ 2>&1 | head -40 | sed 's/^/    /'

echo
echo "=========== 5. the decisive artifact: httpd error log"
for f in /etc/httpd/logs/app_error.log /var/log/httpd/app_error.log \
         /etc/httpd/logs/error_log /var/log/httpd/error_log; do
    [ -f "$f" ] && { echo "  --- $f"; tail -25 "$f" | sed 's/^/    /'; }
done

echo
echo "=========== 6. are the proxy modules loaded?"
httpd -M 2>/dev/null | grep -E 'proxy|ssl|headers' | sed 's/^/  /'

echo
echo "=========== 7. httpd config sanity"
httpd -t 2>&1 | sed 's/^/  /'

echo
echo "=========== 8. is the container healthy?"
podman ps --filter name=ivportal --format '  {{.Names}}  {{.Status}}  {{.Ports}}'
podman exec ivportal apachectl -t 2>&1 | sed 's/^/  /'
echo "  --- container access log (does the proxied request even arrive?):"
podman logs ivportal --tail 15 2>&1 | sed 's/^/    /'

echo
echo "=========== 9. firewall (a block shows as refused/timeout, not 403)"
command -v firewall-cmd >/dev/null && firewall-cmd --list-all 2>/dev/null | head -12 | sed 's/^/  /'
