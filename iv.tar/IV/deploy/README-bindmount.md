# Running InfraVault from a host directory

The container normally carries the application inside the image. This
layout instead bind-mounts `/inventory/infravault` over `/var/www/html`,
so the code on the host *is* the running application and a file edit takes
effect on the next request without a rebuild.

Four things change as a result, and all four have bitten this setup:

1. **The image's copy of the app is hidden.** `COPY . .` still runs at
   build time, but the mount covers it. The image only needs to supply
   PHP, its extensions and the Apache config.

2. **`storage/` and `uploads/` fall inside the mount.** The
   `RUN mkdir -p … && chown` in the Containerfile applies to the image's
   directories, which are now hidden, so the host directories have to be
   created and owned correctly by hand.

3. **`.env` and the database land in the document root.** Apache serves
   the document root, and Debian's default configuration only denies
   `^\.ht`. The image now ships `infravault-hardening.conf` to deny
   dotfiles, `*.db`, and the `config/` and `storage/` directories — but
   keeping `.env` outside the mount entirely is better still.

4. **`APP_DB_PATH` must be set explicitly.** Left unset, `config/db.php`
   falls back to `config/infravault.db`, putting the live database in the
   web root.

## Host preparation

```bash
# The application code.
mkdir -p /inventory/infravault
# ... copy the project here (everything except .env) ...

# Data and attachments, kept out of the document root's own tree so a
# backup or rsync of the code cannot sweep the database along with it.
mkdir -p /inventory/infravault-data /inventory/infravault-uploads

# www-data inside the Debian PHP image is uid/gid 33. The web process
# writes the database, its -wal sidecar, and uploaded attachments.
chown -R 33:33 /inventory/infravault-data /inventory/infravault-uploads
chmod 750 /inventory/infravault-data

# The code itself only needs to be readable.
chown -R root:33 /inventory/infravault
chmod -R o-rwx /inventory/infravault
```

## Environment file

Kept outside the mounted directory on purpose — see point 3 above.

```bash
mkdir -p /etc/infravault
cp .env /etc/infravault/infravault.env
chown root:root /etc/infravault/infravault.env
chmod 600 /etc/infravault/infravault.env
```

`APP_DB_PATH` in that file must point at the mounted data directory:

```
APP_DB_PATH=/var/www/html/storage/infravault.db
```

## SELinux

Use `:z` (lowercase) on the mounts, not `:Z`. Lowercase applies a shared
label; uppercase labels the directory for a single container exclusively,
so adding the reminder or patch-reminder service later would relabel the
same directory and break whichever container started first.

## Install

```bash
cp deploy/ivportal.service /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now ivportal
systemctl status ivportal
journalctl -u ivportal -f
```

## Verifying the hardening

From another host, all four of these must return 403:

```bash
curl -sSo /dev/null -w '%{http_code}\n' http://SERVER:8080/.env
curl -sSo /dev/null -w '%{http_code}\n' http://SERVER:8080/config/infravault.db
curl -sSo /dev/null -w '%{http_code}\n' http://SERVER:8080/storage/infravault.db
curl -sSo /dev/null -w '%{http_code}\n' http://SERVER:8080/config/db.php
```

And the application itself must still return 200:

```bash
curl -sSo /dev/null -w '%{http_code}\n' http://SERVER:8080/index.php
```

## Storage caveat

`/inventory` must be a local Linux filesystem. SQLite depends on POSIX
advisory locking, and on filesystems that implement it incompletely —
NFS, CIFS, and the WSL layers — concurrent writers silently lose rows:
measured on this codebase, 4 concurrent writers lost 25% of their commits
while every write reported success and `PRAGMA integrity_check` still
returned `ok`. If `/inventory` is a network mount, move the database
directory (`APP_DB_PATH`) to local disk.
