<?php

session_start();

require 'config/db.php';
require_once 'includes/pagination-helpers.php';
require_once 'includes/ip-helpers.php';
require_once 'includes/search-helpers.php';


/*
|--------------------------------------------------------------------------
| ASSET COLUMNS
|--------------------------------------------------------------------------
|
| Declared up here rather than beside the table markup because three
| things need it and two of them run early: the CSV export's WHERE clause,
| the on-screen list's WHERE clause, and the table header / column
| chooser. Both search paths build their SQL from this map (see
| includes/search-helpers.php), so a column added to the assets table
| becomes searchable and exportable at the same moment.
*/

$asset_columns = [
    'asset_name'           => 'Asset Name',
    'asset_type'           => 'Type',
    'manufacturer'         => 'Manufacturer',
    'model'                => 'Model',
    'serial_number'        => 'Serial Number',
    'service_tag'          => 'Service Tag',
    'hostname'             => 'Hostname',
    'ip_address'           => 'IP Address',
    'location'             => 'Location',
    'site'                 => 'Site',
    'region'               => 'Region',
    'room'                 => 'Room',
    'row'                  => 'Row',
    'rack'                 => 'Rack',
    'cpu_model'            => 'CPU Model',
    'cpu_count'            => 'CPU Count',
    'total_cores'          => 'Total Cores',
    'memory_gb'            => 'Memory (GB)',
    'internal_storage'     => 'Internal Storage',
    'number_of_nics'       => 'NICs',
    'hba_details'          => 'HBA Details',
    'gpu_details'          => 'GPU Details',
    'vlan'                 => 'VLAN',
    'port_group'           => 'Port Group',
    'purchase_date'        => 'Purchase Date',
    'vendor'               => 'Vendor',
    'warranty_start_date'  => 'Warranty Start',
    'warranty_expiry_date' => 'Warranty Expiry',
    'support_vendor'       => 'Support Vendor',
    'status'               => 'Status',
    'end_of_life'          => 'EOL',
    'remarks'              => 'Remarks',
];


/*
|--------------------------------------------------------------------------
| AUTHENTICATION
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}


$role = trim($_SESSION['role'] ?? '');
$userId = (int)($_SESSION['user_id'] ?? 0);

$username = 'Unknown User';

if ($userId > 0) {

    $userStmt = $pdo->prepare("
        SELECT
            first_name,
            last_name,
            ncgr_id
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $userStmt->execute([$userId]);

    $user = $userStmt->fetch(PDO::FETCH_ASSOC);

    if ($user) {

        $firstName = trim($user['first_name'] ?? '');
        $lastName  = trim($user['last_name'] ?? '');
        $ncgrId    = trim($user['ncgr_id'] ?? '');

        $fullName = trim(
            $firstName . ' ' . $lastName
        );

        if (
            $fullName !== '' &&
            $ncgrId !== ''
        ) {

            $username =
                $fullName .
                ' (' .
                $ncgrId .
                ')';

        } elseif ($fullName !== '') {

            $username = $fullName;

        } elseif ($ncgrId !== '') {

            $username = $ncgrId;
        }
    }
}
/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
|
| Permissions table:
|
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
*/

function hasPermission(
    PDO $pdo,
    string $role,
    string $pageKey,
    string $permission
): bool {
    /*
    | Delegates to the single authorization helper (includes/authz.php).
    | The verb whitelist and the "column cannot be a PDO parameter"
    | handling both live there now.
    */
    return authzCan($pdo, $role, $pageKey, $permission);
}


/*
|--------------------------------------------------------------------------
| PAGE KEY
|--------------------------------------------------------------------------
*/

$assetPageKey = 'asset';


/*
|--------------------------------------------------------------------------
| ASSET PERMISSIONS
|--------------------------------------------------------------------------
*/

$canView = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_view'
);

$canEdit = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_edit'
);

$canDelete = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_delete'
);

$canExport = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_export'
);

$canImport = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_import'
);


/*
|--------------------------------------------------------------------------
| AUDIT PERMISSION
|--------------------------------------------------------------------------
|
| IMPORTANT:
|
| Your DB contains can_audit.
|
| Therefore audit history is controlled using:
|
| asset / can_audit
|
| NOT:
|
| asset_history / can_view
|
*/

$canViewHistory = hasPermission(
    $pdo,
    $role,
    $assetPageKey,
    'can_audit'
);


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
*/

if (!$canView) {

    http_response_code(403);

    exit(
        'You do not have permission to view this page.'
    );
}


$msg = '';
$error = '';


/*
|--------------------------------------------------------------------------
| 1. EXPORT CSV
|--------------------------------------------------------------------------
*/

if (
    isset($_GET['action']) &&
    $_GET['action'] === 'export'
) {

    if (!$canExport) {

        http_response_code(403);

        exit(
            'You do not have permission to export asset records.'
        );
    }

    // Build WHERE clause with same filters as main page
    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_name = trim($_GET['s_name'] ?? '');
    $s_type = trim($_GET['s_type'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');
    $s_ip = trim($_GET['s_ip'] ?? '');
    $s_hostname = trim($_GET['s_hostname'] ?? '');
    $s_serial = trim($_GET['s_serial'] ?? '');
    $s_manufacturer = trim($_GET['s_manufacturer'] ?? '');
    $s_model = trim($_GET['s_model'] ?? '');
    $s_location = trim($_GET['s_location'] ?? '');
    $s_site = trim($_GET['s_site'] ?? '');
    $s_cpu_min = trim($_GET['s_cpu_min'] ?? '');
    $s_memory_min = trim($_GET['s_memory_min'] ?? '');
    $s_cores_min = trim($_GET['s_cores_min'] ?? '');
    $s_eol = trim($_GET['s_eol'] ?? '');
    $s_vendor = trim($_GET['s_vendor'] ?? '');

    // Same all-column, multi-value matcher the on-screen list uses, so an
    // export reflects exactly the rows the page was showing.
    if ($keyword !== '') {
        $exportSearch = multiValueSearchClause($keyword, $asset_columns);

        if ($exportSearch !== null) {
            [$exportClause, $exportSearchParams] = $exportSearch;

            $export_where_clauses[] = $exportClause;
            $export_params = array_merge($export_params, $exportSearchParams);
        }
    }

    if ($s_name !== '') {
        $export_where_clauses[] = 'asset_name LIKE ?';
        $export_params[] = '%' . $s_name . '%';
    }

    if ($s_type !== '') {
        $export_where_clauses[] = 'asset_type = ?';
        $export_params[] = $s_type;
    }

    if ($s_status !== '') {
        $export_where_clauses[] = 'status = ?';
        $export_params[] = $s_status;
    }

    if ($s_ip !== '') {
        $export_where_clauses[] = 'ip_address LIKE ?';
        $export_params[] = '%' . $s_ip . '%';
    }

    if ($s_hostname !== '') {
        $export_where_clauses[] = 'hostname LIKE ?';
        $export_params[] = '%' . $s_hostname . '%';
    }

    if ($s_serial !== '') {
        $export_where_clauses[] = 'serial_number LIKE ?';
        $export_params[] = '%' . $s_serial . '%';
    }

    if ($s_manufacturer !== '') {
        $export_where_clauses[] = 'manufacturer LIKE ?';
        $export_params[] = '%' . $s_manufacturer . '%';
    }

    if ($s_model !== '') {
        $export_where_clauses[] = 'model LIKE ?';
        $export_params[] = '%' . $s_model . '%';
    }

    if ($s_location !== '') {
        $export_where_clauses[] = 'location LIKE ?';
        $export_params[] = '%' . $s_location . '%';
    }

    if ($s_site !== '') {
        $export_where_clauses[] = 'site LIKE ?';
        $export_params[] = '%' . $s_site . '%';
    }

    if ($s_cpu_min !== '') {
        $cpu_val = (int) $s_cpu_min;
        $export_where_clauses[] = 'cpu_count >= ?';
        $export_params[] = $cpu_val;
    }

    if ($s_memory_min !== '') {
        $memory_val = (int) $s_memory_min;
        $export_where_clauses[] = 'memory_gb >= ?';
        $export_params[] = $memory_val;
    }

    if ($s_cores_min !== '') {
        $cores_val = (int) $s_cores_min;
        $export_where_clauses[] = 'total_cores >= ?';
        $export_params[] = $cores_val;
    }

    if ($s_eol !== '') {
        $export_where_clauses[] = 'end_of_life = ?';
        $export_params[] = $s_eol;
    }

    if ($s_vendor !== '') {
        $export_where_clauses[] = 'support_vendor LIKE ?';
        $export_params[] = '%' . $s_vendor . '%';
    }

    $export_where_sql = implode(' AND ', $export_where_clauses);

    header(
        'Content-Type: text/csv; charset=utf-8'
    );

    header(
        'Content-Disposition: attachment; filename=asset_export_' .
        date('Y-m-d_H-i-s') .
        '.csv'
    );

    header(
        'Pragma: no-cache'
    );

    header(
        'Expires: 0'
    );


    $output = fopen(
        'php://output',
        'w'
    );


    /*
    |--------------------------------------------------------------------------
    | CSV HEADER
    |--------------------------------------------------------------------------
    */

    fputcsv($output, [

        'Asset Name',
        'Asset Type',
        'Manufacturer',
        'Model',
        'Serial Number',
        'Service Tag',
        'Hostname',
        'IP Address',
        'Location',
        'Site',
        'Region',
        'Room',
        'Row',
        'Rack',
        'CPU Model',
        'CPU Count',
        'Total Cores',
        'Memory (GB)',
        'Internal Storage',
        'Number of NICs',
        'HBA Details',
        'GPU Details',
        'VLAN',
        'Purchase Date',
        'Vendor',
        'Warranty Start Date',
        'Warranty Expiry Date',
        'Support Vendor',
        'Status',
        'End-of-Life',
        'Remarks',
        'Created By',
        'Created At',
        'Port Group'

    ]);


    $stmt = $pdo->prepare("
        SELECT
            asset_name,
            asset_type,
            manufacturer,
            model,
            serial_number,
            service_tag,
            hostname,
            ip_address,
            location,
            site,
            region,
            room,
            `row`,
            rack,
            cpu_model,
            cpu_count,
            total_cores,
            memory_gb,
            internal_storage,
            number_of_nics,
            hba_details,
            gpu_details,
            vlan,
            purchase_date,
            vendor,
            warranty_start_date,
            warranty_expiry_date,
            support_vendor,
            status,
            end_of_life,
            remarks,
            created_by,
            created_at,
            port_group
        FROM asset
        WHERE {$export_where_sql}
        ORDER BY asset_name ASC
    ");

    $stmt->execute($export_params);


    while (
        $row = $stmt->fetch(PDO::FETCH_ASSOC)
    ) {

        fputcsv($output, [

            $row['asset_name'],
            $row['asset_type'],
            $row['manufacturer'],
            $row['model'],
            $row['serial_number'],
            $row['service_tag'],
            $row['hostname'],
            $row['ip_address'],
            $row['location'],
            $row['site'],
            $row['region'],
            $row['room'],
            $row['row'],
            $row['rack'],
            $row['cpu_model'],
            $row['cpu_count'],
            $row['total_cores'],
            $row['memory_gb'],
            $row['internal_storage'],
            $row['number_of_nics'],
            $row['hba_details'],
            $row['gpu_details'],
            $row['vlan'],
            $row['purchase_date'],
            $row['vendor'],
            $row['warranty_start_date'],
            $row['warranty_expiry_date'],
            $row['support_vendor'],
            $row['status'],
            $row['end_of_life'],
            $row['remarks'],
            $row['created_by'],
            $row['created_at'],
            $row['port_group']

        ]);
    }


    fclose($output);

    exit;
}


/*
|--------------------------------------------------------------------------
| 2. GLOBAL AUDIT HISTORY AJAX
|--------------------------------------------------------------------------
*/

if (
    isset($_GET['action']) &&
    $_GET['action'] === 'get_history'
) {

    /*
    |--------------------------------------------------------------------------
    | AUDIT PERMISSION
    |--------------------------------------------------------------------------
    */

    if (!$canViewHistory) {

        http_response_code(403);

        echo '
            <div class="history-error">
                You do not have permission to view audit history.
            </div>
        ';

        exit;
    }


    $historyAssetId = isset($_GET['asset_id']) ? (int)$_GET['asset_id'] : 0;

    if ($historyAssetId > 0) {

        $stmt = $pdo->prepare("
            SELECT
                id,
                asset_id,
                action_type,
                performed_by,
                details,
                timestamp
            FROM asset_history
            WHERE asset_id = ?
            ORDER BY timestamp DESC, id DESC
        ");

        $stmt->execute([$historyAssetId]);

    } else {

        $stmt = $pdo->query("
            SELECT
                id,
                asset_id,
                action_type,
                performed_by,
                details,
                timestamp
            FROM asset_history
            ORDER BY timestamp DESC, id DESC
        ");
    }


    $logs = $stmt->fetchAll(
        PDO::FETCH_ASSOC
    );


    if (count($logs) > 0) {

        echo '<table class="audit-table">';


        echo '
            <thead>
                <tr>
                    <th>Action</th>
                    <th>Asset ID</th>
                    <th>Performed By</th>
                    <th>Details</th>
                    <th>Timestamp</th>
                </tr>
            </thead>
        ';


        echo '<tbody>';


        foreach ($logs as $log) {

            $badge_color =
                'background:var(--border-color);color:var(--text-primary);';


            switch (
                strtoupper(
                    $log['action_type'] ?? ''
                )
            ) {

                case 'CREATED':

                    $badge_color =
                        'background:#dcfce7;color:#166534;';

                    break;


                case 'DELETED':

                    $badge_color =
                        'background:#fee2e2;color:#991b1b;';

                    break;


                case 'UPDATED':

                    $badge_color =
                        'background:#fef9c3;color:#854d0e;';

                    break;


                case 'BULK IMPORT':

                    $badge_color =
                        'background:#dbeafe;color:#1e40af;';

                    break;
            }


            echo '<tr>';


            echo '<td>
                <span
                    class="audit-badge"
                    style="' .
                    htmlspecialchars(
                        $badge_color,
                        ENT_QUOTES,
                        'UTF-8'
                    ) .
                '">'
                    .
                    htmlspecialchars(
                        $log['action_type'] ?? '',
                        ENT_QUOTES,
                        'UTF-8'
                    )
                .
                '</span>
            </td>';


            echo '<td>' .
                htmlspecialchars(
                    $log['asset_id'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) .
                '</td>';


            echo '<td>' .
                htmlspecialchars(
                    $log['performed_by'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) .
                '</td>';


            echo '<td class="audit-details">' .
                nl2br(htmlspecialchars(
                    $log['details'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                )) .
                '</td>';


            echo '<td>' .
                htmlspecialchars(
                    $log['timestamp'] ?? '',
                    ENT_QUOTES,
                    'UTF-8'
                ) .
                '</td>';


            echo '</tr>';
        }


        echo '</tbody>';

        echo '</table>';

    } else {

        echo '
            <p class="empty-state">
                ' . ($historyAssetId > 0 ? 'No audit history found for this asset.' : 'No audit history records found.') . '
            </p>
        ';
    }


    exit;
}


/*
|--------------------------------------------------------------------------
| 2b. LINKED INVENTORY HOSTNAMES (BY ASSET NAME) AJAX
|--------------------------------------------------------------------------
|
| Inventory's "HW Model" field is actually a lookup against this asset's
| Asset Name -- see inventory.php's own "HW Model (Asset Name)" field
| label and its searchHardware()/selectHardware() autocomplete, which
| queries `SELECT ... FROM asset WHERE asset_name = ?`. So the join here
| has to be asset.asset_name = inventory.hw_model, not asset.model (a
| separate column describing the hardware type, e.g. "PowerEdge R740",
| which is not what inventory.hw_model actually stores).
|--------------------------------------------------------------------------
*/

if (
    isset($_GET['action']) &&
    $_GET['action'] === 'get_linked_hostnames'
) {

    if (!$canView) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view this data.</p>';
        exit;
    }

    if (!hasPermission($pdo, $role, 'inventory', 'can_view')) {
        echo '<p class="empty-state">You do not have permission to view Inventory records.</p>';
        exit;
    }

    $assetName = trim($_GET['asset_name'] ?? '');

    if ($assetName === '') {
        echo '<p class="empty-state">This asset has no Asset Name value set, so no hostnames can be matched.</p>';
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT
            hostname, ip_address, os_family, os_version,
            project, application, support_level, server_state, technical_owner
        FROM inventory
        WHERE LOWER(TRIM(hw_model)) = LOWER(TRIM(?))
        ORDER BY hostname ASC
    ");

    $stmt->execute([$assetName]);
    $linkedRows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($linkedRows) > 0) {

        echo '<table class="audit-table">';
        echo '<thead><tr>
            <th>Hostname</th>
            <th>IP Address</th>
            <th>OS</th>
            <th>Project</th>
            <th>Application</th>
            <th>Support Level</th>
            <th>State</th>
            <th>Technical Owner</th>
        </tr></thead>';
        echo '<tbody>';

        foreach ($linkedRows as $r) {

            $os = trim(($r['os_family'] ?? '') . ' ' . ($r['os_version'] ?? ''));

            echo '<tr>';
            echo '<td>' . htmlspecialchars($r['hostname'] ?? '', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['ip_address'] ?? '', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($os !== '' ? $os : '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['project'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['application'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['support_level'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['server_state'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '<td>' . htmlspecialchars($r['technical_owner'] ?: '-', ENT_QUOTES, 'UTF-8') . '</td>';
            echo '</tr>';
        }

        echo '</tbody></table>';

    } else {

        echo '<p class="empty-state">No Inventory hostnames found with HW Model (Asset Name) "'
            . htmlspecialchars($assetName, ENT_QUOTES, 'UTF-8') . '".</p>';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| 2c. VLAN / PORT GROUP LOOKUP (BY IP ADDRESS) AJAX
|--------------------------------------------------------------------------
|
| VLAN and Port Group are not typed in on this form -- they are derived
| from whichever ip.php IP range the asset's IP Address falls inside, so
| they can never drift out of sync with what IP Address Management
| actually has on file for that subnet. This endpoint is what the
| create/edit form calls as the IP Address field is filled in; the save
| handler below (form_action=save) recomputes the same thing server-side
| before writing the row, so the stored value is authoritative even if a
| request never reached this endpoint (JS disabled, etc.).
|--------------------------------------------------------------------------
*/

if (
    isset($_GET['action']) &&
    $_GET['action'] === 'lookup_ip_range'
) {

    header('Content-Type: application/json; charset=utf-8');

    if (!$canView) {
        http_response_code(403);
        echo json_encode(['found' => false, 'error' => 'permission_denied']);
        exit;
    }

    $ip = trim($_GET['ip'] ?? '');
    $match = ipFindRangeForAddress($pdo, $ip);

    if ($match === null) {
        echo json_encode(['found' => false]);
        exit;
    }

    echo json_encode([
        'found'      => true,
        'vlan'       => $match['vlan'] ?? '',
        'port_group' => $match['portgroup'] ?? '',
        'range'      => $match['matched_label'] ?? ($match['ip_range'] ?? ''),
    ]);

    exit;
}


/*
|--------------------------------------------------------------------------
| 3. FORM SUBMISSIONS
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
) {

    $action_type =
        trim(
            $_POST['form_action'] ?? ''
        );


    /*
    |--------------------------------------------------------------------------
    | CREATE / UPDATE
    |--------------------------------------------------------------------------
    */

    if ($action_type === 'save') {

        if (!$canEdit) {

            http_response_code(403);

            $error =
                'You do not have permission to create or edit assets.';

        } else {

            $id =
                trim(
                    $_POST['id'] ?? ''
                );


            $asset_name =
                trim(
                    $_POST['asset_name'] ?? ''
                );

            $asset_type =
                trim(
                    $_POST['asset_type'] ?? ''
                );

            $manufacturer =
                trim(
                    $_POST['manufacturer'] ?? ''
                );

            $model =
                trim(
                    $_POST['model'] ?? ''
                );

            $serial_number =
                trim(
                    $_POST['serial_number'] ?? ''
                );

            $service_tag =
                trim(
                    $_POST['service_tag'] ?? ''
                );

            $hostname =
                trim(
                    $_POST['hostname'] ?? ''
                );

            $ip_address =
                trim(
                    $_POST['ip_address'] ?? ''
                );

            $location =
                trim(
                    $_POST['location'] ?? ''
                );

            $site =
                trim(
                    $_POST['site'] ?? ''
                );

            $region =
                trim(
                    $_POST['region'] ?? ''
                );

            $room =
                trim(
                    $_POST['room'] ?? ''
                );

            $row =
                trim(
                    $_POST['row'] ?? ''
                );

            $rack =
                trim(
                    $_POST['rack'] ?? ''
                );

            $cpu_model =
                trim(
                    $_POST['cpu_model'] ?? ''
                );

            $cpu_count =
                trim(
                    $_POST['cpu_count'] ?? ''
                );

            $total_cores =
                trim(
                    $_POST['total_cores'] ?? ''
                );

            $memory_gb =
                trim(
                    $_POST['memory_gb'] ?? ''
                );

            $internal_storage =
                trim(
                    $_POST['internal_storage'] ?? ''
                );

            $number_of_nics =
                trim(
                    $_POST['number_of_nics'] ?? ''
                );

            $hba_details =
                trim(
                    $_POST['hba_details'] ?? ''
                );

            $gpu_details =
                trim(
                    $_POST['gpu_details'] ?? ''
                );

            $vlan =
                trim(
                    $_POST['vlan'] ?? ''
                );

            $port_group =
                trim(
                    $_POST['port_group'] ?? ''
                );


            /*
            |--------------------------------------------------------------------------
            | VLAN / PORT GROUP: ALWAYS DERIVED FROM IP ADDRESS
            |--------------------------------------------------------------------------
            |
            | Whatever the form submitted for these two is discarded here --
            | they are recomputed from the current ip.php range data, the
            | same lookup the form's own JS calls live. This is what makes
            | the fields authoritative rather than just pre-filled: a
            | disabled-JS submission, an edited/replayed request, or a
            | stale value left over from before the IP was changed can
            | never write down a VLAN/Port Group that disagrees with what
            | IP Address Management says for that address today.
            */

            $ipRangeMatch = ipFindRangeForAddress($pdo, $ip_address);

            $vlan = $ipRangeMatch['vlan'] ?? '';
            $port_group = $ipRangeMatch['portgroup'] ?? '';

            $purchase_date =
                trim(
                    $_POST['purchase_date'] ?? ''
                );

            $vendor =
                trim(
                    $_POST['vendor'] ?? ''
                );

            $warranty_start_date =
                trim(
                    $_POST['warranty_start_date'] ?? ''
                );

            $warranty_expiry_date =
                trim(
                    $_POST['warranty_expiry_date'] ?? ''
                );

            $support_vendor =
                trim(
                    $_POST['support_vendor'] ?? ''
                );

            $status =
                trim(
                    $_POST['status'] ?? ''
                );

            $end_of_life =
                trim(
                    $_POST['end_of_life'] ?? ''
                );

            $remarks =
                trim(
                    $_POST['remarks'] ?? ''
                );


            /*
            |--------------------------------------------------------------------------
            | REQUIRED FIELDS
            |--------------------------------------------------------------------------
            */

            if (
                $asset_name === '' ||
                $asset_type === ''
            ) {

                $error =
                    'Asset Name and Asset Type are required fields.';

            } else {


                /*
                |--------------------------------------------------------------------------
                | CREATE
                |--------------------------------------------------------------------------
                */

                if ($id === '') {

                    $stmt = $pdo->prepare("
                        INSERT INTO asset (
                            asset_name,
                            asset_type,
                            manufacturer,
                            model,
                            serial_number,
                            service_tag,
                            hostname,
                            ip_address,
                            location,
                            site,
                            region,
                            room,
                            `row`,
                            rack,
                            cpu_model,
                            cpu_count,
                            total_cores,
                            memory_gb,
                            internal_storage,
                            number_of_nics,
                            hba_details,
                            gpu_details,
                            vlan,
                            port_group,
                            purchase_date,
                            vendor,
                            warranty_start_date,
                            warranty_expiry_date,
                            support_vendor,
                            status,
                            end_of_life,
                            remarks,
                            created_by
                        )
                        VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?
                        )
                    ");


                    $stmt->execute([

                        $asset_name,
                        $asset_type,
                        $manufacturer,
                        $model,
                        $serial_number,
                        $service_tag,
                        $hostname,
                        $ip_address,
                        $location,
                        $site,
                        $region,
                        $room,
                        $row,
                        $rack,
                        $cpu_model,
                        $cpu_count,
                        $total_cores,
                        $memory_gb,
                        $internal_storage,
                        $number_of_nics,
                        $hba_details,
                        $gpu_details,
                        $vlan,
                        $port_group,
                        $purchase_date,
                        $vendor,
                        $warranty_start_date,
                        $warranty_expiry_date,
                        $support_vendor,
                        $status,
                        $end_of_life,
                        $remarks,
                        $username

                    ]);


                    $new_id =
                        $pdo->lastInsertId();


                    /*
                    |--------------------------------------------------------------------------
                    | AUDIT - CREATED
                    |--------------------------------------------------------------------------
                    */

                    $h_stmt = $pdo->prepare("
                        INSERT INTO asset_history (
                            asset_id,
                            action_type,
                            performed_by,
                            details
                        )
                        VALUES (?, ?, ?, ?)
                    ");


                    $h_stmt->execute([

                        $new_id,
                        'CREATED',
                        $username,
                        'Created asset: ' . $asset_name

                    ]);


                    $msg =
                        'Asset record created successfully.';
                }


                /*
                |--------------------------------------------------------------------------
                | UPDATE
                |--------------------------------------------------------------------------
                */

                else {

                    $checkStmt = $pdo->prepare("
                        SELECT *
                        FROM asset
                        WHERE id = ?
                        LIMIT 1
                    ");


                    $checkStmt->execute([
                        $id
                    ]);


                    $oldRecord =
                        $checkStmt->fetch(
                            PDO::FETCH_ASSOC
                        );


                    if (!$oldRecord) {

                        $error =
                            'The selected asset could not be found.';

                    } else {

                        $stmt = $pdo->prepare("
                            UPDATE asset SET

                                asset_name=?,
                                asset_type=?,
                                manufacturer=?,
                                model=?,
                                serial_number=?,
                                service_tag=?,
                                hostname=?,
                                ip_address=?,
                                location=?,
                                site=?,
                                region=?,
                                room=?,
                                `row`=?,
                                rack=?,
                                cpu_model=?,
                                cpu_count=?,
                                total_cores=?,
                                memory_gb=?,
                                internal_storage=?,
                                number_of_nics=?,
                                hba_details=?,
                                gpu_details=?,
                                vlan=?,
                                port_group=?,
                                purchase_date=?,
                                vendor=?,
                                warranty_start_date=?,
                                warranty_expiry_date=?,
                                support_vendor=?,
                                status=?,
                                end_of_life=?,
                                remarks=?,
                                updated_by=?,
                                updated_at=CURRENT_TIMESTAMP

                            WHERE id=?
                        ");


                        /*
                        |--------------------------------------------------------------------------
                        | Keyed by column so we can diff old vs new value per
                        | field for the audit log below. Order matches the
                        | UPDATE SET clause above (excluding updated_by/id).
                        |--------------------------------------------------------------------------
                        */

                        $newValuesByColumn = [

                            'asset_name' => $asset_name,
                            'asset_type' => $asset_type,
                            'manufacturer' => $manufacturer,
                            'model' => $model,
                            'serial_number' => $serial_number,
                            'service_tag' => $service_tag,
                            'hostname' => $hostname,
                            'ip_address' => $ip_address,
                            'location' => $location,
                            'site' => $site,
                            'region' => $region,
                            'room' => $room,
                            'row' => $row,
                            'rack' => $rack,
                            'cpu_model' => $cpu_model,
                            'cpu_count' => $cpu_count,
                            'total_cores' => $total_cores,
                            'memory_gb' => $memory_gb,
                            'internal_storage' => $internal_storage,
                            'number_of_nics' => $number_of_nics,
                            'hba_details' => $hba_details,
                            'gpu_details' => $gpu_details,
                            'vlan' => $vlan,
                            'port_group' => $port_group,
                            'purchase_date' => $purchase_date,
                            'vendor' => $vendor,
                            'warranty_start_date' => $warranty_start_date,
                            'warranty_expiry_date' => $warranty_expiry_date,
                            'support_vendor' => $support_vendor,
                            'status' => $status,
                            'end_of_life' => $end_of_life,
                            'remarks' => $remarks,

                        ];


                        $values = array_values($newValuesByColumn);
                        $values[] = $username;
                        $values[] = $id;


                        $stmt->execute($values);


                        /*
                        |--------------------------------------------------------------------------
                        | AUDIT - UPDATED (field-level diff)
                        |--------------------------------------------------------------------------
                        |
                        | Only fields whose value actually changed are recorded,
                        | each with its old -> new value, so the per-asset audit
                        | trail shows exactly who changed what.
                        |
                        */

                        $assetFieldLabels = [

                            'asset_name' => 'Asset Name',
                            'asset_type' => 'Asset Type',
                            'manufacturer' => 'Manufacturer',
                            'model' => 'Model',
                            'serial_number' => 'Serial Number',
                            'service_tag' => 'Service Tag',
                            'hostname' => 'Hostname',
                            'ip_address' => 'IP Address',
                            'location' => 'Location',
                            'site' => 'Site',
                            'region' => 'Region',
                            'room' => 'Room',
                            'row' => 'Row',
                            'rack' => 'Rack',
                            'cpu_model' => 'CPU Model',
                            'cpu_count' => 'CPU Count',
                            'total_cores' => 'Total Cores',
                            'memory_gb' => 'Memory (GB)',
                            'internal_storage' => 'Internal Storage',
                            'number_of_nics' => 'Number of NICs',
                            'hba_details' => 'HBA Details',
                            'gpu_details' => 'GPU Details',
                            'vlan' => 'VLAN',
                            'port_group' => 'Port Group',
                            'purchase_date' => 'Purchase Date',
                            'vendor' => 'Vendor',
                            'warranty_start_date' => 'Warranty Start Date',
                            'warranty_expiry_date' => 'Warranty Expiry Date',
                            'support_vendor' => 'Support Vendor',
                            'status' => 'Status',
                            'end_of_life' => 'End-of-Life',
                            'remarks' => 'Remarks',

                        ];


                        $changedFields = [];

                        foreach ($newValuesByColumn as $columnKey => $newVal) {

                            $oldValStr = trim((string)($oldRecord[$columnKey] ?? ''));
                            $newValStr = trim((string)$newVal);

                            if ($oldValStr !== $newValStr) {

                                $fieldLabel = $assetFieldLabels[$columnKey] ?? $columnKey;
                                $oldDisplay = $oldValStr === '' ? '(empty)' : $oldValStr;
                                $newDisplay = $newValStr === '' ? '(empty)' : $newValStr;

                                $changedFields[] = "$fieldLabel: \"$oldDisplay\" -> \"$newDisplay\"";
                            }
                        }


                        $detail_msg = 'Updated asset: ' . $asset_name . "\n";

                        $detail_msg .= (count($changedFields) > 0)
                            ? implode("\n", $changedFields)
                            : 'No field value changes detected.';


                        $h_stmt = $pdo->prepare("
                            INSERT INTO asset_history (
                                asset_id,
                                action_type,
                                performed_by,
                                details
                            )
                            VALUES (?, ?, ?, ?)
                        ");


                        $h_stmt->execute([

                            $id,
                            'UPDATED',
                            $username,
                            $detail_msg

                        ]);


                        $msg =
                            'Asset record updated successfully.';
                    }
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($action_type === 'delete') {

        if (!$canDelete) {

            http_response_code(403);

            $error =
                'You do not have permission to delete assets.';

        } else {

            $id =
                trim(
                    $_POST['id'] ?? ''
                );


            if ($id === '') {

                $error =
                    'Invalid asset ID.';

            } else {

                $p_stmt = $pdo->prepare("
                    SELECT asset_name
                    FROM asset
                    WHERE id = ?
                    LIMIT 1
                ");


                $p_stmt->execute([
                    $id
                ]);


                $asset_row =
                    $p_stmt->fetch(
                        PDO::FETCH_ASSOC
                    );


                if (!$asset_row) {

                    $error =
                        'Asset record not found.';

                } else {

                    $asset_name =
                        $asset_row['asset_name'];


                    /*
                    |--------------------------------------------------------------------------
                    | DELETE
                    |--------------------------------------------------------------------------
                    */

                    $stmt = $pdo->prepare("
                        DELETE FROM asset
                        WHERE id = ?
                    ");


                    $stmt->execute([
                        $id
                    ]);


                    /*
                    |--------------------------------------------------------------------------
                    | AUDIT - DELETED
                    |--------------------------------------------------------------------------
                    */

                    $h_stmt = $pdo->prepare("
                        INSERT INTO asset_history (
                            asset_id,
                            action_type,
                            performed_by,
                            details
                        )
                        VALUES (?, ?, ?, ?)
                    ");


                    $h_stmt->execute([

                        $id,
                        'DELETED',
                        $username,
                        'Deleted asset: ' . $asset_name

                    ]);


                    $msg =
                        'Asset record deleted successfully.';
                }
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CSV BULK IMPORT
    |--------------------------------------------------------------------------
    */

    if ($action_type === 'upload_csv') {

        if (!$canImport) {

            http_response_code(403);

            $error =
                'You do not have permission to import assets.';

        } elseif (
            !isset($_FILES['csv_file']) ||
            $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK
        ) {

            $error =
                'Please upload a valid CSV file.';

        } else {

            $file_tmp =
                $_FILES['csv_file']['tmp_name'];


            if (
                ($handle = fopen(
                    $file_tmp,
                    'r'
                )) !== false
            ) {

                /*
                |--------------------------------------------------------------------------
                | SKIP HEADER
                |--------------------------------------------------------------------------
                */

                fgetcsv(
                    $handle,
                    0,
                    ','
                );


                $count = 0;


                while (
                    (
                        $data = fgetcsv(
                            $handle,
                            0,
                            ','
                        )
                    ) !== false
                ) {

                    /*
                    |--------------------------------------------------------------------------
                    | EXPORT FORMAT
                    |--------------------------------------------------------------------------
                    |
                    | 0  ID
                    | 1  Asset Name
                    | 2  Asset Type
                    | 3  Manufacturer
                    | 4  Model
                    | 5  Serial Number
                    | 6  Service Tag
                    | 7  Hostname
                    | 8  IP Address
                    | 9  Location
                    | 10 Site
                    | 11 Region
                    | 12 Room
                    | 13 Row
                    | 14 Rack
                    | 15 CPU Model
                    | 16 CPU Count
                    | 17 Total Cores
                    | 18 Memory
                    | 19 Internal Storage
                    | 20 NICs
                    | 21 HBA
                    | 22 GPU
                    | 23 VLAN
                    | 24 Purchase Date
                    | 25 Vendor
                    | 26 Warranty Start
                    | 27 Warranty Expiry
                    | 28 Support Vendor
                    | 29 Status
                    | 30 EOL
                    | 31 Remarks
                    | 32 Created By
                    | 33 Created At
                    |
                    */

                    if (
                        count($data) < 32
                    ) {
                        continue;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | REQUIRED CSV DATA
                    |--------------------------------------------------------------------------
                    */

                    $csv_asset_name =
                        trim(
                            $data[1] ?? ''
                        );

                    $csv_asset_type =
                        trim(
                            $data[2] ?? ''
                        );


                    if (
                        $csv_asset_name === '' ||
                        $csv_asset_type === ''
                    ) {
                        continue;
                    }


                    $stmt = $pdo->prepare("
                        INSERT INTO asset (
                            asset_name,
                            asset_type,
                            manufacturer,
                            model,
                            serial_number,
                            service_tag,
                            hostname,
                            ip_address,
                            location,
                            site,
                            region,
                            room,
                            `row`,
                            rack,
                            cpu_model,
                            cpu_count,
                            total_cores,
                            memory_gb,
                            internal_storage,
                            number_of_nics,
                            hba_details,
                            gpu_details,
                            vlan,
                            port_group,
                            purchase_date,
                            vendor,
                            warranty_start_date,
                            warranty_expiry_date,
                            support_vendor,
                            status,
                            end_of_life,
                            remarks,
                            created_by
                        )
                        VALUES (
                            ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                            ?, ?, ?, ?, ?
                        )
                    ");

                    /*
                    | Same rule as the "save" handler: VLAN/Port Group are
                    | derived from the IP Address column (23 in the CSV,
                    | index $data[8]) rather than trusted from the CSV's own
                    | VLAN column, so an import can't write a value that
                    | disagrees with IP Address Management.
                    */
                    $csv_ip_match = ipFindRangeForAddress($pdo, $data[8] ?? '');
                    $csv_vlan = $csv_ip_match['vlan'] ?? '';
                    $csv_port_group = $csv_ip_match['portgroup'] ?? '';

                    $stmt->execute([

                        $data[1] ?? '',
                        $data[2] ?? '',
                        $data[3] ?? '',
                        $data[4] ?? '',
                        $data[5] ?? '',
                        $data[6] ?? '',
                        $data[7] ?? '',
                        $data[8] ?? '',
                        $data[9] ?? '',
                        $data[10] ?? '',
                        $data[11] ?? '',
                        $data[12] ?? '',
                        $data[13] ?? '',
                        $data[14] ?? '',
                        $data[15] ?? '',
                        $data[16] ?? '',
                        $data[17] ?? '',
                        $data[18] ?? '',
                        $data[19] ?? '',
                        $data[20] ?? '',
                        $data[21] ?? '',
                        $data[22] ?? '',
                        $csv_vlan,
                        $csv_port_group,
                        $data[24] ?? '',
                        $data[25] ?? '',
                        $data[26] ?? '',
                        $data[27] ?? '',
                        $data[28] ?? '',
                        $data[29] ?? '',
                        $data[30] ?? '',
                        $data[31] ?? '',
                        $username

                    ]);


                    $new_id =
                        $pdo->lastInsertId();


                    /*
                    |--------------------------------------------------------------------------
                    | AUDIT - BULK IMPORT
                    |--------------------------------------------------------------------------
                    */

                    $h_stmt = $pdo->prepare("
                        INSERT INTO asset_history (
                            asset_id,
                            action_type,
                            performed_by,
                            details
                        )
                        VALUES (?, ?, ?, ?)
                    ");


                    $h_stmt->execute([

                        $new_id,
                        'BULK IMPORT',
                        $username,
                        'Imported via CSV bulk upload'

                    ]);


                    $count++;
                }


                fclose($handle);


                $msg =
                    'Successfully imported ' .
                    $count .
                    ' records from CSV.';

            } else {

                $error =
                    'Failed to read uploaded CSV file.';
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| 4. PAGINATION & SEARCH
|--------------------------------------------------------------------------
*/

$limit = resolveUserPageSize($pdo, $userId);


$page = isset($_GET['page'])
    ? max(
        1,
        (int)$_GET['page']
    )
    : 1;


$start =
    ($page - 1) * $limit;


$keyword =
    trim(
        $_GET['keyword'] ?? ''
    );


$s_name =
    trim(
        $_GET['s_name'] ?? ''
    );


$s_type =
    trim(
        $_GET['s_type'] ?? ''
    );


$s_status =
    trim(
        $_GET['s_status'] ?? ''
    );


$s_ip =
    trim(
        $_GET['s_ip'] ?? ''
    );

$s_hostname = trim($_GET['s_hostname'] ?? '');
$s_serial = trim($_GET['s_serial'] ?? '');
$s_manufacturer = trim($_GET['s_manufacturer'] ?? '');
$s_model = trim($_GET['s_model'] ?? '');
$s_location = trim($_GET['s_location'] ?? '');
$s_site = trim($_GET['s_site'] ?? '');
$s_cpu_min = trim($_GET['s_cpu_min'] ?? '');
$s_memory_min = trim($_GET['s_memory_min'] ?? '');
$s_cores_min = trim($_GET['s_cores_min'] ?? '');
$s_eol = trim($_GET['s_eol'] ?? '');
$s_vendor = trim($_GET['s_vendor'] ?? '');

$where_clauses = [
    '1=1'
];

$params = [];


/*
|--------------------------------------------------------------------------
| GENERAL SEARCH
|--------------------------------------------------------------------------
|
| Matches every column, and accepts several values at once separated by
| commas, semicolons or new lines -- paste a list of serials or hostnames
| and get every matching asset back.
|
| It previously looked at four columns (asset_name, hostname, ip_address,
| serial_number), so searching a rack, a VLAN, a support vendor or a CPU
| model returned nothing at all and looked identical to "no such asset".
*/

if ($keyword !== '') {

    $assetSearch = multiValueSearchClause($keyword, $asset_columns);

    if ($assetSearch !== null) {
        [$assetClause, $assetParams] = $assetSearch;

        $where_clauses[] = $assetClause;
        $params = array_merge($params, $assetParams);
    }
}


/*
|--------------------------------------------------------------------------
| ASSET NAME
|--------------------------------------------------------------------------
*/

if ($s_name !== '') {

    $where_clauses[] =
        'asset_name LIKE ?';

    $params[] =
        '%' . $s_name . '%';
}


/*
|--------------------------------------------------------------------------
| TYPE
|--------------------------------------------------------------------------
*/

if ($s_type !== '') {

    $where_clauses[] =
        'asset_type = ?';

    $params[] =
        $s_type;
}


/*
|--------------------------------------------------------------------------
| STATUS
|--------------------------------------------------------------------------
*/

if ($s_status !== '') {

    $where_clauses[] =
        'status = ?';

    $params[] =
        $s_status;
}


/*
|--------------------------------------------------------------------------
| IP
|--------------------------------------------------------------------------
*/

if ($s_ip !== '') {

    $where_clauses[] =
        'ip_address LIKE ?';

    $params[] =
        '%' . $s_ip . '%';
}


/*
|--------------------------------------------------------------------------
| ENTERPRISE FILTERS
|--------------------------------------------------------------------------
*/

if ($s_hostname !== '') {
    $where_clauses[] = 'hostname LIKE ?';
    $params[] = '%' . $s_hostname . '%';
}

if ($s_serial !== '') {
    $where_clauses[] = 'serial_number LIKE ?';
    $params[] = '%' . $s_serial . '%';
}

if ($s_manufacturer !== '') {
    $where_clauses[] = 'manufacturer LIKE ?';
    $params[] = '%' . $s_manufacturer . '%';
}

if ($s_model !== '') {
    $where_clauses[] = 'model LIKE ?';
    $params[] = '%' . $s_model . '%';
}

if ($s_location !== '') {
    $where_clauses[] = 'location LIKE ?';
    $params[] = '%' . $s_location . '%';
}

if ($s_site !== '') {
    $where_clauses[] = 'site LIKE ?';
    $params[] = '%' . $s_site . '%';
}

if ($s_cpu_min !== '') {
    $cpu_val = (int) $s_cpu_min;
    $where_clauses[] = 'cpu_count >= ?';
    $params[] = $cpu_val;
}

if ($s_memory_min !== '') {
    $memory_val = (int) $s_memory_min;
    $where_clauses[] = 'memory_gb >= ?';
    $params[] = $memory_val;
}

if ($s_cores_min !== '') {
    $cores_val = (int) $s_cores_min;
    $where_clauses[] = 'total_cores >= ?';
    $params[] = $cores_val;
}

if ($s_eol !== '') {
    $where_clauses[] = 'end_of_life = ?';
    $params[] = $s_eol;
}

if ($s_vendor !== '') {
    $where_clauses[] = 'support_vendor LIKE ?';
    $params[] = '%' . $s_vendor . '%';
}


$where_sql =
    implode(
        ' AND ',
        $where_clauses
    );


/*
|--------------------------------------------------------------------------
| COUNT
|--------------------------------------------------------------------------
*/

$total_stmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM asset
    WHERE {$where_sql}
");


$total_stmt->execute(
    $params
);


$total_records =
    (int)$total_stmt->fetchColumn();


$total_pages =
    max(
        1,
        (int)ceil(
            $total_records / $limit
        )
    );


/*
|--------------------------------------------------------------------------
| CORRECT PAGE IF OUT OF RANGE
|--------------------------------------------------------------------------
*/

if (
    $page > $total_pages &&
    $total_records > 0
) {

    $page =
        $total_pages;

    $start =
        ($page - 1) * $limit;
}


/*
|--------------------------------------------------------------------------
| DROPDOWN OPTIONS
|--------------------------------------------------------------------------
*/

$asset_types = [

    'Server',
    'Switch',
    'Storage',
    'Firewall',
    'PDU',
    'UPS',
    'Others'

];


$status_options = [

    'In Service',
    'Standby',
    'Decommissioned'

];


$eol_options = [

    'yes',
    'no'

];


/*
|--------------------------------------------------------------------------
| ASSET COLUMNS
|--------------------------------------------------------------------------
|
| Defined near the top of the file (see ASSET COLUMNS above the search
| section) so the search clauses can be built from it. This block is kept
| only as a pointer; the array itself moved.
*/


$default_visible_columns = [

    'asset_name',
    'asset_type',
    'manufacturer',
    'model',
    'hostname',
    'ip_address',
    'location',
    'status',
    'end_of_life'

];


/*
|--------------------------------------------------------------------------
| SORTING - VALIDATE AND APPLY
|--------------------------------------------------------------------------
*/

$sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

$valid_sort_columns = array_merge(array_keys($asset_columns), ['id', 'created_at']);
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'id';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'DESC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

// Re-fetch with correct sorting
$data_stmt = $pdo->prepare("
    SELECT *
    FROM asset
    WHERE {$where_sql}
    ORDER BY `$sort_by` $sort_dir
    LIMIT {$limit}
    OFFSET {$start}
");

$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

// Hidden fields so the page-size selector preserves the current
// search/filter/sort state instead of resetting it.
$hidden_filter_fields = '';
foreach ([
    'keyword' => $keyword,
    's_name' => $s_name,
    's_type' => $s_type,
    's_status' => $s_status,
    's_ip' => $s_ip,
    's_hostname' => $s_hostname,
    's_serial' => $s_serial,
    's_manufacturer' => $s_manufacturer,
    's_model' => $s_model,
    's_location' => $s_location,
    's_site' => $s_site,
    's_cpu_min' => $s_cpu_min,
    's_memory_min' => $s_memory_min,
    's_cores_min' => $s_cores_min,
    's_eol' => $s_eol,
    's_vendor' => $s_vendor,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
] as $fk => $fv) {
    if ($fv !== '') {
        $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
    }
}


/*
|--------------------------------------------------------------------------
| PAGE TITLE
|--------------------------------------------------------------------------
*/

$page_title =
    'Asset Inventory | InfraVault';


require 'includes/header.php';

?>

<link
    rel="stylesheet"
    href="assets/css/asset.css"
>

<?php require 'includes/sidebar.php'; ?>


<div class="content">


    <!-- ================================================================
         PAGE HEADER
    ================================================================= -->

    <div class="dashboard-header">

        <div>

            <h1>
                Hardware Asset Inventory
            </h1>

            <p>
                Track servers, network hardware, and their lifecycle
                status across sites.
            </p>

        </div>


        <div class="dashboard-actions">


            <?php if ($canEdit): ?>

                <button
                    type="button"
                    class="btn btn-success"
                    onclick="openCreateModal()"
                >
                    <i class="fas fa-plus-circle"></i>
                    Add Asset
                </button>

            <?php endif; ?>


            <?php if ($canExport): ?>

                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_name !== '') $export_params['s_name'] = $s_name;
                if ($s_type !== '') $export_params['s_type'] = $s_type;
                if ($s_status !== '') $export_params['s_status'] = $s_status;
                if ($s_ip !== '') $export_params['s_ip'] = $s_ip;
                if ($s_hostname !== '') $export_params['s_hostname'] = $s_hostname;
                if ($s_serial !== '') $export_params['s_serial'] = $s_serial;
                if ($s_manufacturer !== '') $export_params['s_manufacturer'] = $s_manufacturer;
                if ($s_model !== '') $export_params['s_model'] = $s_model;
                if ($s_location !== '') $export_params['s_location'] = $s_location;
                if ($s_site !== '') $export_params['s_site'] = $s_site;
                if ($s_cpu_min !== '') $export_params['s_cpu_min'] = $s_cpu_min;
                if ($s_memory_min !== '') $export_params['s_memory_min'] = $s_memory_min;
                if ($s_cores_min !== '') $export_params['s_cores_min'] = $s_cores_min;
                if ($s_eol !== '') $export_params['s_eol'] = $s_eol;
                if ($s_vendor !== '') $export_params['s_vendor'] = $s_vendor;
                $export_url = 'asset.php?' . http_build_query($export_params);
                ?>

                <a
                    href="<?= htmlspecialchars($export_url) ?>"
                    class="btn btn-info"
                >
                    <i class="fas fa-file-export"></i>
                    Export CSV
                </a>

            <?php endif; ?>


            <?php if ($canImport): ?>

                <button
                    type="button"
                    class="btn btn-warning"
                    onclick="openUploadModal()"
                >
                    <i class="fas fa-upload"></i>
                    Upload CSV
                </button>

            <?php endif; ?>


            <?php if ($canViewHistory): ?>

                <button
                    type="button"
                    class="btn btn-dark"
                    onclick="openHistoryModal()"
                >
                    <i class="fas fa-history"></i>
                    Audit History
                </button>

            <?php endif; ?>


            <button
                type="button"
                class="btn btn-secondary"
                onclick="openColumnsModal()"
            >
                <i class="fas fa-sliders-h"></i>
                Customize Fields
            </button>

        </div>

    </div>


    <!-- ================================================================
         MESSAGES
    ================================================================= -->

    <?php if ($msg !== ''): ?>

        <div class="alert alert-success">

            <?php
            echo htmlspecialchars(
                $msg,
                ENT_QUOTES,
                'UTF-8'
            );
            ?>

        </div>

    <?php endif; ?>


    <?php if ($error !== ''): ?>

        <div class="alert alert-error">

            <?php
            echo htmlspecialchars(
                $error,
                ENT_QUOTES,
                'UTF-8'
            );
            ?>

        </div>

    <?php endif; ?>


    <!-- ================================================================
         SEARCH
    ================================================================= -->

    <div class="panel">

        <div
            class="panel-header"
            style="margin-bottom:14px;"
        >

            <h3
                class="panel-title"
                style="margin:0;"
            >
                Search &amp; Filters
            </h3>


            <span
                style="
                    cursor:pointer;
                    color:#2563EB;
                    font-size:13px;
                    font-weight:600;
                "
                onclick="toggleAdvancedSearch()"
            >
                Search Multiple Values &#9662;
            </span>

        </div>


        <div style="display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:14px;">

        <form
            method="GET"
            action="asset.php"
            style="
                display:flex;
                gap:10px;
                flex-wrap:wrap;
            "
        >

            <input
                type="text"
                name="keyword"
                class="form-control"
                style="max-width:420px;"
                title="Searches every column. Separate multiple values with commas, semicolons or new lines."
                placeholder="Search any column — separate multiple values with commas"
                value="<?php
                echo htmlspecialchars(
                    $keyword,
                    ENT_QUOTES,
                    'UTF-8'
                );
                ?>"
            >


            <button
                type="submit"
                class="btn btn-primary"
            >
                Search
            </button>


            <?php if (
                $keyword !== '' ||
                $s_name !== '' ||
                $s_type !== '' ||
                $s_status !== '' ||
                $s_ip !== ''
            ): ?>

                <a
                    href="asset.php"
                    class="btn"
                >
                    Clear
                </a>

            <?php endif; ?>

        </form>

        <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>

        </div>


        <div
            id="advancedSearchPanel"
            style="
                display:<?php
                echo (
                    $s_name !== '' ||
                    $s_type !== '' ||
                    $s_status !== '' ||
                    $s_ip !== ''
                )
                    ? 'block'
                    : 'none';
                ?>;
                margin-top:18px;
                padding:20px;
                background:var(--hover-bg);
                border-radius:10px;
                border:1px solid #E5E7EB;
            "
        >

            <form
                method="GET"
                action="asset.php"
                style="display: grid; grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); gap: 16px;"
            >

                <!-- ASSET IDENTIFICATION -->
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Identification</label>
                    <input type="text" name="s_name" class="form-control" placeholder="Asset Name..." value="<?= htmlspecialchars($s_name, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Hostname</label>
                    <input type="text" name="s_hostname" class="form-control" placeholder="Hostname..." value="<?= htmlspecialchars($_GET['s_hostname'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Serial Number</label>
                    <input type="text" name="s_serial" class="form-control" placeholder="Serial Number..." value="<?= htmlspecialchars($_GET['s_serial'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- ASSET CLASSIFICATION -->
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Asset Type</label>
                    <select name="s_type" class="form-control">
                        <option value="">All Types</option>
                        <?php foreach ($asset_types as $t): ?>
                            <option value="<?= htmlspecialchars($t, ENT_QUOTES, 'UTF-8') ?>" <?= $s_type === $t ? 'selected' : '' ?>><?= htmlspecialchars($t, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Manufacturer</label>
                    <input type="text" name="s_manufacturer" class="form-control" placeholder="Manufacturer..." value="<?= htmlspecialchars($_GET['s_manufacturer'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Model</label>
                    <input type="text" name="s_model" class="form-control" placeholder="Model..." value="<?= htmlspecialchars($_GET['s_model'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- NETWORK & LOCATION -->
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">IP Address</label>
                    <input type="text" name="s_ip" class="form-control" placeholder="IP Address..." value="<?= htmlspecialchars($s_ip, ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Location</label>
                    <input type="text" name="s_location" class="form-control" placeholder="Location..." value="<?= htmlspecialchars($_GET['s_location'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Site/Region</label>
                    <input type="text" name="s_site" class="form-control" placeholder="Site..." value="<?= htmlspecialchars($_GET['s_site'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- SPECIFICATIONS -->
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">CPU Count (Min)</label>
                    <input type="number" name="s_cpu_min" class="form-control" placeholder="Min..." value="<?= htmlspecialchars($_GET['s_cpu_min'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Memory GB (Min)</label>
                    <input type="number" name="s_memory_min" class="form-control" placeholder="Min GB..." value="<?= htmlspecialchars($_GET['s_memory_min'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Cores (Min)</label>
                    <input type="number" name="s_cores_min" class="form-control" placeholder="Min..." value="<?= htmlspecialchars($_GET['s_cores_min'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- STATUS & LIFECYCLE -->
                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Status</label>
                    <select name="s_status" class="form-control">
                        <option value="">All Statuses</option>
                        <?php foreach ($status_options as $stat): ?>
                            <option value="<?= htmlspecialchars($stat, ENT_QUOTES, 'UTF-8') ?>" <?= $s_status === $stat ? 'selected' : '' ?>><?= htmlspecialchars($stat, ENT_QUOTES, 'UTF-8') ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">EOL Status</label>
                    <select name="s_eol" class="form-control">
                        <option value="">All</option>
                        <option value="yes" <?= ($_GET['s_eol'] ?? '') === 'yes' ? 'selected' : '' ?>>End of Life</option>
                        <option value="no" <?= ($_GET['s_eol'] ?? '') === 'no' ? 'selected' : '' ?>>Active</option>
                    </select>
                </div>

                <div class="form-group">
                    <label style="font-weight: 700; font-size: 12px; color: #64748B; text-transform: uppercase; display: block; margin-bottom: 8px;">Support Vendor</label>
                    <input type="text" name="s_vendor" class="form-control" placeholder="Vendor..." value="<?= htmlspecialchars($_GET['s_vendor'] ?? '', ENT_QUOTES, 'UTF-8') ?>">
                </div>

                <!-- BUTTONS -->
                <div style="grid-column: 1/-1; display: flex; gap: 10px; flex-wrap: wrap;">
                    <button type="submit" class="btn btn-primary" style="flex: 1; min-width: 120px;">
                        🔍 Apply Filters
                    </button>
                    <a href="asset.php" class="btn" style="flex: 1; min-width: 120px; text-align: center;">
                        ↺ Reset
                    </a>
                </div>

            </form>

        </div>

    </div>


    <!-- ================================================================
         ASSET TABLE
    ================================================================= -->

    <div
        class="panel"
        style="padding:0;"
    >

        <div
            style="
                padding:22px 22px 0;
            "
        >

            <div
                class="panel-header"
                style="margin-bottom:0;"
            >

                <h3
                    class="panel-title"
                    style="margin:0;"
                >
                    Asset Records
                </h3>


                <span
                    style="
                        color:#64748B;
                        font-size:13px;
                    "
                >
                    <?php echo $total_records; ?>
                    total
                </span>

            </div>

        </div>


        <div class="table-wrap">

            <table
                class="data-table"
                id="assetTable"
            >

                <thead>

                    <tr>

                        <?php foreach (
                            $asset_columns
                            as $col_key => $col_label
                        ): ?>

                            <th
                                class="col-th-<?php
                                echo htmlspecialchars(
                                    $col_key,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?> <?php
                                echo in_array(
                                    $col_key,
                                    $default_visible_columns,
                                    true
                                )
                                    ? ''
                                    : 'hidden-col';
                                ?>"
                            >
                                <a href="asset.php?sort_by=<?php echo htmlspecialchars($col_key); ?>&sort_dir=<?php echo $next_sort_dir; ?>&page=1" style="display: flex; align-items: center; gap: 6px; text-decoration: none; color: inherit;">
                                    <?php
                                    echo htmlspecialchars(
                                        $col_label,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                    ?>
                                    <?php if ($sort_by === $col_key): ?>
                                        <span style="color: #2563EB;">
                                            <?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?>
                                        </span>
                                    <?php endif; ?>
                                </a>
                            </th>

                        <?php endforeach; ?>


                        <th style="text-align:right;">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody>

                    <?php if (
                        count($records) > 0
                    ): ?>

                        <?php foreach (
                            $records as $r
                        ): ?>

                            <tr>

                                <?php foreach (
                                    $asset_columns
                                    as $col_key => $col_label
                                ): ?>

                                    <td
                                        class="
                                            col-td-<?php
                                            echo htmlspecialchars(
                                                $col_key,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>
                                            <?php
                                            echo in_array(
                                                $col_key,
                                                $default_visible_columns,
                                                true
                                            )
                                                ? ''
                                                : 'hidden-col';
                                            ?>
                                        "
                                    >

                                        <?php if (
                                            $col_key === 'asset_name'
                                        ): ?>

                                            <span class="cell-primary">

                                                <?php
                                                echo htmlspecialchars(
                                                    $r['asset_name'] ?? '',
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                );
                                                ?>

                                            </span>


                                        <?php elseif (
                                            $col_key === 'asset_type'
                                        ): ?>

                                            <span class="badge">

                                                <?php
                                                echo htmlspecialchars(
                                                    $r['asset_type'] ?? '',
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                );
                                                ?>

                                            </span>


                                        <?php elseif (
                                            $col_key === 'status'
                                        ): ?>

                                            <?php

                                            $statusValue =
                                                $r['status'] ?? '';

                                            $statusClass =
                                                'badge-' .
                                                str_replace(
                                                    ' ',
                                                    '',
                                                    $statusValue
                                                );

                                            ?>

                                            <span
                                                class="badge <?php
                                                echo htmlspecialchars(
                                                    $statusClass,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                );
                                                ?>"
                                            >
                                                <?php
                                                echo htmlspecialchars(
                                                    $statusValue,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                );
                                                ?>
                                            </span>


                                        <?php elseif (
                                            $col_key === 'end_of_life'
                                        ): ?>

                                            <?php if (
                                                strtolower(
                                                    trim(
                                                        $r['end_of_life'] ?? ''
                                                    )
                                                ) === 'yes'
                                            ): ?>

                                                <span class="eol-yes">
                                                    Yes
                                                </span>

                                            <?php else: ?>

                                                <span class="eol-no">

                                                    <?php
                                                    echo htmlspecialchars(
                                                        $r['end_of_life'] ?: 'No',
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    );
                                                    ?>

                                                </span>

                                            <?php endif; ?>


                                        <?php else: ?>

                                            <?php
                                            echo htmlspecialchars(
                                                $r[$col_key] ?? '',
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>

                                        <?php endif; ?>

                                    </td>

                                <?php endforeach; ?>


                                <!-- ACTIONS -->

                                <td
                                    style="
                                        text-align:center;
                                        white-space:nowrap;
                                    "
                                >

                                    <div class="row-actions">


                                        <?php if ($canView): ?>

                                            <button
                                                type="button"
                                                class="btn btn-secondary btn-sm btn-icon"
                                                title="View"
                                                aria-label="View"
                                                onclick='openViewModal(<?php
                                                    echo json_encode(
                                                        $r,
                                                        JSON_HEX_TAG |
                                                        JSON_HEX_APOS |
                                                        JSON_HEX_QUOT |
                                                        JSON_HEX_AMP
                                                    );
                                                ?>)'
                                            >
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
                                                    <circle cx="12" cy="12" r="3"/>
                                                </svg>
                                            </button>

                                        <?php endif; ?>


                                        <?php if ($canViewHistory): ?>

                                            <button
                                                type="button"
                                                class="btn btn-secondary btn-sm btn-icon"
                                                title="View audit history for this asset"
                                                aria-label="History"
                                                onclick='openHistoryModal(<?php echo (int)$r['id']; ?>)'
                                            >
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M3 3v5h5"/>
                                                    <path d="M3.05 13A9 9 0 1 0 6 5.3L3 8"/>
                                                    <path d="M12 7v5l4 2"/>
                                                </svg>
                                            </button>

                                        <?php endif; ?>


                                        <?php if ($canEdit): ?>

                                            <button
                                                type="button"
                                                class="btn btn-primary btn-sm btn-icon"
                                                title="Update"
                                                aria-label="Update"
                                                onclick='openEditModal(<?php
                                                    echo json_encode(
                                                        $r,
                                                        JSON_HEX_TAG |
                                                        JSON_HEX_APOS |
                                                        JSON_HEX_QUOT |
                                                        JSON_HEX_AMP
                                                    );
                                                ?>)'
                                            >
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <path d="M12 20h9"/>
                                                    <path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4Z"/>
                                                </svg>
                                            </button>

                                        <?php endif; ?>


                                        <?php if ($canDelete): ?>

                                            <button
                                                type="button"
                                                class="btn btn-danger btn-sm btn-icon"
                                                title="Delete"
                                                aria-label="Delete"
                                                onclick='openDeleteModal(
                                                    <?php
                                                    echo (int)$r['id'];
                                                    ?>,
                                                    <?php
                                                    echo json_encode(
                                                        $r['asset_name'] ?? '',
                                                        JSON_HEX_TAG |
                                                        JSON_HEX_APOS |
                                                        JSON_HEX_QUOT |
                                                        JSON_HEX_AMP
                                                    );
                                                    ?>
                                                )'
                                            >
                                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                                    <polyline points="3 6 5 6 21 6"/>
                                                    <path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>
                                                    <path d="M10 11v6"/>
                                                    <path d="M14 11v6"/>
                                                    <path d="M9 6V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v2"/>
                                                </svg>
                                            </button>

                                        <?php endif; ?>

                                    </div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>

                            <td
                                colspan="<?php
                                echo count(
                                    $asset_columns
                                ) + 1;
                                ?>"
                            >

                                <p class="empty-state">
                                    No hardware asset records found.
                                </p>

                            </td>

                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>


        <!-- =============================================================
             PAGINATION
        ============================================================== -->

        <?= ivPager($page, $total_pages, [
            'keyword'  => $keyword,
            's_name'   => $s_name,
            's_type'   => $s_type,
            's_status' => $s_status,
            's_ip'     => $s_ip,
        ], ['base' => 'asset.php', 'total_records' => $total_records ?? null, 'per_page' => $limit ?? null]) ?>

    </div>

</div>


<!-- =====================================================================
     CREATE / UPDATE MODAL
====================================================================== -->

<div
    id="recordModal"
    class="modal-overlay"
>

    <div
        class="modal-content"
        style="max-width:900px;"
    >

        <div class="modal-header">

            <h3 id="modalTitle">
                Add Asset Record
            </h3>


            <button
                type="button"
                class="close-modal"
                onclick="closeModal('recordModal')"
            >
                &times;
            </button>

        </div>


        <form
            method="POST"
            action="asset.php"
        >

            <input
                type="hidden"
                name="form_action"
                value="save"
            >


            <input
                type="hidden"
                name="id"
                id="rec_id"
            >


            <div class="form-grid-3">


                <div class="form-group">

                    <label>
                        Asset Name *
                    </label>

                    <input
                        type="text"
                        name="asset_name"
                        id="rec_asset_name"
                        class="form-control"
                        required
                    >

                </div>


                <div class="form-group">

                    <label>
                        Asset Type *
                    </label>

                    <select
                        name="asset_type"
                        id="rec_asset_type"
                        class="form-control"
                        required
                    >

                        <?php foreach (
                            $asset_types as $t
                        ): ?>

                            <option
                                value="<?php
                                echo htmlspecialchars(
                                    $t,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>"
                            >
                                <?php
                                echo htmlspecialchars(
                                    $t,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <?php

                $formFields = [

                    'manufacturer' =>
                        ['Manufacturer', 'text'],

                    'model' =>
                        ['Model', 'text'],

                    'serial_number' =>
                        ['Serial Number', 'text'],

                    'service_tag' =>
                        ['Service Tag', 'text'],

                    'hostname' =>
                        ['Hostname', 'text'],

                    'ip_address' =>
                        ['IP Address', 'text'],

                    'location' =>
                        ['Location', 'text'],

                    'site' =>
                        ['Site', 'text'],

                    'region' =>
                        ['Region', 'text'],

                    'room' =>
                        ['Room', 'text'],

                    'row' =>
                        ['Row', 'text'],

                    'rack' =>
                        ['Rack', 'text'],

                    'cpu_model' =>
                        ['CPU Model', 'text'],

                    'cpu_count' =>
                        ['CPU Count', 'text'],

                    'total_cores' =>
                        ['Total Cores', 'text'],

                    'memory_gb' =>
                        ['Memory (GB)', 'text'],

                    'internal_storage' =>
                        ['Internal Storage', 'text'],

                    'number_of_nics' =>
                        ['Number of NICs', 'text'],

                    'hba_details' =>
                        ['HBA Details', 'text'],

                    'gpu_details' =>
                        ['GPU Details', 'text'],

                    'vlan' =>
                        ['VLAN', 'text', 'readonly'],

                    'port_group' =>
                        ['Port Group', 'text', 'readonly'],

                    'purchase_date' =>
                        ['Purchase Date', 'date'],

                    'vendor' =>
                        ['Vendor', 'text'],

                    'warranty_start_date' =>
                        ['Warranty Start Date', 'date'],

                    'warranty_expiry_date' =>
                        ['Warranty Expiry Date', 'date'],

                    'support_vendor' =>
                        ['Support Vendor', 'text']

                ];


                foreach (
                    $formFields as $field => $fieldInfo
                ):

                ?>

                    <?php $isAutoField = ($fieldInfo[2] ?? '') === 'readonly'; ?>

                    <div class="form-group">

                        <label>
                            <?php
                            echo htmlspecialchars(
                                $fieldInfo[0],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>
                        </label>


                        <input
                            type="<?php
                            echo htmlspecialchars(
                                $fieldInfo[1],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            name="<?php
                            echo htmlspecialchars(
                                $field,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            id="rec_<?php
                            echo htmlspecialchars(
                                $field,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            class="form-control<?php echo $isAutoField ? ' form-control-auto' : ''; ?>"
                            <?php echo $isAutoField ? 'readonly placeholder="Derived from IP Address"' : ''; ?>
                        >

                        <?php if ($isAutoField): ?>
                            <small class="form-hint">
                                Auto-filled from the matching IP range in IP Address Management -- not editable here.
                            </small>
                        <?php endif; ?>

                    </div>

                <?php endforeach; ?>


                <div class="form-group">

                    <label>
                        Status
                    </label>

                    <select
                        name="status"
                        id="rec_status"
                        class="form-control"
                    >

                        <?php foreach (
                            $status_options as $stat
                        ): ?>

                            <option
                                value="<?php
                                echo htmlspecialchars(
                                    $stat,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>"
                            >
                                <?php
                                echo htmlspecialchars(
                                    $stat,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="form-group">

                    <label>
                        End-of-Life (yes/no)
                    </label>

                    <select
                        name="end_of_life"
                        id="rec_end_of_life"
                        class="form-control"
                    >

                        <?php foreach (
                            $eol_options as $eol
                        ): ?>

                            <option
                                value="<?php
                                echo htmlspecialchars(
                                    $eol,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>"
                            >
                                <?php
                                echo htmlspecialchars(
                                    $eol,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>
                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div
                    class="form-group"
                    style="grid-column:1/-1;"
                >

                    <label>
                        Remarks
                    </label>

                    <textarea
                        name="remarks"
                        id="rec_remarks"
                        class="form-control"
                        rows="2"
                    ></textarea>

                </div>

            </div>


            <div class="modal-footer">

                <button
                    type="button"
                    class="btn"
                    onclick="closeModal('recordModal')"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="btn btn-primary"
                >
                    Save Asset
                </button>

            </div>

        </form>

    </div>

</div>


<!-- =====================================================================
     VIEW MODAL
====================================================================== -->

<div
    id="viewModal"
    class="modal-overlay"
>

    <div
        class="modal-content"
        style="max-width:800px;"
    >

        <div class="modal-header">

            <h3>
                Asset Details
            </h3>


            <button
                type="button"
                class="close-modal"
                onclick="closeModal('viewModal')"
            >
                &times;
            </button>

        </div>


        <div class="view-tabs">

            <button
                type="button"
                id="viewTabBtnDetails"
                class="view-tab-btn active"
                onclick="switchViewTab('details')"
            >
                Asset Details
            </button>

            <button
                type="button"
                id="viewTabBtnHostnames"
                class="view-tab-btn"
                onclick="switchViewTab('hostnames')"
            >
                Linked Hostnames
            </button>

        </div>


        <div id="viewTabDetails" class="view-tab-panel">

        <div class="view-grid">

            <?php

            $viewFields = [

                'asset_name' =>
                    'Asset Name',

                'asset_type' =>
                    'Type',

                'manufacturer' =>
                    'Manufacturer',

                'model' =>
                    'Model',

                'serial_number' =>
                    'Serial Number',

                'service_tag' =>
                    'Service Tag',

                'hostname' =>
                    'Hostname',

                'ip_address' =>
                    'IP Address',

                'location' =>
                    'Location',

                'site' =>
                    'Site',

                'region' =>
                    'Region',

                'room' =>
                    'Room',

                'row' =>
                    'Row',

                'rack' =>
                    'Rack',

                'cpu_model' =>
                    'CPU Model',

                'cpu_count' =>
                    'CPU Count',

                'total_cores' =>
                    'Total Cores',

                'memory_gb' =>
                    'Memory (GB)',

                'internal_storage' =>
                    'Internal Storage',

                'number_of_nics' =>
                    'Number of NICs',

                'hba_details' =>
                    'HBA Details',

                'gpu_details' =>
                    'GPU Details',

                'vlan' =>
                    'VLAN',

                'port_group' =>
                    'Port Group',

                'purchase_date' =>
                    'Purchase Date',

                'vendor' =>
                    'Vendor',

                'warranty_start_date' =>
                    'Warranty Start',

                'warranty_expiry_date' =>
                    'Warranty Expiry',

                'support_vendor' =>
                    'Support Vendor',

                'status' =>
                    'Status',

                'end_of_life' =>
                    'End-of-Life',

                'remarks' =>
                    'Remarks'

            ];


            foreach (
                $viewFields as $field => $label
            ):

                $fullClass =
                    $field === 'remarks'
                        ? 'view-item full'
                        : 'view-item';

            ?>

                <div
                    class="<?php echo $fullClass; ?>"
                >

                    <label>
                        <?php
                        echo htmlspecialchars(
                            $label,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </label>


                    <span
                        id="v_<?php
                        echo htmlspecialchars(
                            $field,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>"
                    ></span>

                </div>

            <?php endforeach; ?>

        </div>

        </div>


        <div id="viewTabHostnames" class="view-tab-panel" style="display:none;">

            <div id="linkedHostnamesContainer" class="linked-hostnames-wrap">
                <p class="empty-state">Loading linked hostnames...</p>
            </div>

        </div>


        <div class="modal-footer">

            <button
                type="button"
                class="btn"
                onclick="closeModal('viewModal')"
            >
                Close
            </button>

        </div>

    </div>

</div>


<!-- =====================================================================
     DELETE MODAL
====================================================================== -->

<div
    id="deleteModal"
    class="modal-overlay"
>

    <div
        class="modal-content"
        style="
            max-width:400px;
            text-align:center;
        "
    >

        <div class="modal-header">

            <h3>
                Confirm Deletion
            </h3>


            <button
                type="button"
                class="close-modal"
                onclick="closeModal('deleteModal')"
            >
                &times;
            </button>

        </div>


        <p
            style="
                margin:1rem 0;
                color:#64748B;
            "
        >

            Are you sure you want to delete asset:

            <strong id="del_asset_name"></strong>?

        </p>


        <form
            method="POST"
            action="asset.php"
        >

            <input
                type="hidden"
                name="form_action"
                value="delete"
            >


            <input
                type="hidden"
                name="id"
                id="del_id"
            >


            <div
                class="modal-footer"
                style="justify-content:center;"
            >

                <button
                    type="button"
                    class="btn"
                    onclick="closeModal('deleteModal')"
                >
                    Cancel
                </button>


                <button
                    type="submit"
                    class="btn btn-danger"
                >
                    Yes, Delete
                </button>

            </div>

        </form>

    </div>

</div>


<!-- =====================================================================
     AUDIT HISTORY (global + per-asset, same modal)
====================================================================== -->

<?php if ($canViewHistory): ?>

    <div
        id="globalHistoryModal"
        class="modal-overlay"
    >

        <div
            class="modal-content"
            style="max-width:1000px;"
        >

            <div class="modal-header">

                <h3 id="historyModalTitle">
                    Asset Audit History
                </h3>


                <button
                    type="button"
                    class="close-modal"
                    onclick="closeModal('globalHistoryModal')"
                >
                    &times;
                </button>

            </div>


            <div
                id="globalHistoryContent"
                style="
                    margin-top:1rem;
                    max-height:60vh;
                    overflow-y:auto;
                "
            >

                <p class="empty-state">
                    Loading audit trails...
                </p>

            </div>

        </div>

    </div>

<?php endif; ?>


<!-- =====================================================================
     CSV UPLOAD
====================================================================== -->

<?php if ($canImport): ?>

    <div
        id="uploadModal"
        class="modal-overlay"
    >

        <div
            class="modal-content"
            style="max-width:450px;"
        >

            <div class="modal-header">

                <h3>
                    Bulk Upload via CSV
                </h3>


                <button
                    type="button"
                    class="close-modal"
                    onclick="closeModal('uploadModal')"
                >
                    &times;
                </button>

            </div>


            <form
                method="POST"
                action="asset.php"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="form_action"
                    value="upload_csv"
                >


                <p
                    style="
                        font-size:0.85rem;
                        color:#64748B;
                        margin-bottom:1rem;
                    "
                >
                    Upload a CSV file formatted to match
                    the exported column structure.
                </p>


                <div class="form-group">

                    <input
                        type="file"
                        name="csv_file"
                        accept=".csv,text/csv"
                        class="form-control"
                        required
                    >

                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn"
                        onclick="closeModal('uploadModal')"
                    >
                        Cancel
                    </button>


                    <button
                        type="submit"
                        class="btn btn-primary"
                    >
                        Upload &amp; Import
                    </button>

                </div>

            </form>

        </div>

    </div>

<?php endif; ?>


<!-- =====================================================================
     CUSTOMIZE FIELDS
====================================================================== -->

<div
    id="columnsModal"
    class="modal-overlay"
>

    <div
        class="modal-content"
        style="max-width:550px;"
    >

        <div class="modal-header">

            <h3>
                Customize Visible Fields
            </h3>


            <button
                type="button"
                class="close-modal"
                onclick="closeModal('columnsModal')"
            >
                &times;
            </button>

        </div>


        <div
            style="
                display:grid;
                grid-template-columns:1fr 1fr;
                gap:0.6rem;
                max-height:50vh;
                overflow-y:auto;
                padding-right:0.5rem;
            "
        >

            <?php foreach (
                $asset_columns
                as $col_key => $col_label
            ):

                $is_checked =
                    in_array(
                        $col_key,
                        $default_visible_columns,
                        true
                    )
                        ? 'checked'
                        : '';

            ?>

                <label
                    style="
                        font-size:0.85rem;
                        display:flex;
                        align-items:center;
                        gap:0.4rem;
                    "
                >

                    <input
                        type="checkbox"
                        <?php echo $is_checked; ?>
                        onchange="toggleCol(
                            '<?php
                            echo htmlspecialchars(
                                $col_key,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>',
                            this.checked
                        )"
                    >


                    <?php
                    echo htmlspecialchars(
                        $col_label,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>

                </label>

            <?php endforeach; ?>

        </div>


        <div class="modal-footer">

            <button
                type="button"
                class="btn btn-primary"
                onclick="closeModal('columnsModal')"
            >
                Done
            </button>

        </div>

    </div>

</div>


<!-- =====================================================================
     JAVASCRIPT
====================================================================== -->

<script>

/*
|--------------------------------------------------------------------------
| ADVANCED SEARCH
|--------------------------------------------------------------------------
*/

function toggleAdvancedSearch() {

    const panel =
        document.getElementById(
            'advancedSearchPanel'
        );

    if (!panel) {
        return;
    }

    panel.style.display =
        panel.style.display === 'none'
            ? 'block'
            : 'none';
}


/*
|--------------------------------------------------------------------------
| CREATE MODAL
|--------------------------------------------------------------------------
*/

function openCreateModal() {

    document.getElementById(
        'modalTitle'
    ).innerText =
        'Add Asset Record';


    document.getElementById(
        'rec_id'
    ).value = '';


    document
        .querySelectorAll(
            '#recordModal input[type="text"],' +
            '#recordModal input[type="date"],' +
            '#recordModal textarea'
        )
        .forEach(function (input) {

            input.value = '';

        });


    const type =
        document.getElementById(
            'rec_asset_type'
        );

    if (type) {
        type.selectedIndex = 0;
    }


    const status =
        document.getElementById(
            'rec_status'
        );

    if (status) {
        status.selectedIndex = 0;
    }


    const eol =
        document.getElementById(
            'rec_end_of_life'
        );

    if (eol) {
        eol.value = 'no';
    }


    lookupIpRangeForForm('');


    document.getElementById(
        'recordModal'
    ).style.display = 'flex';
}


/*
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
*/

function openEditModal(data) {

    document.getElementById(
        'modalTitle'
    ).innerText =
        'Update Asset Record';


    document.getElementById(
        'rec_id'
    ).value =
        data.id || '';


    for (
        const key in data
    ) {

        const element =
            document.getElementById(
                'rec_' + key
            );


        if (element) {

            element.value =
                data[key] !== null &&
                data[key] !== undefined
                    ? data[key]
                    : '';

        }
    }


    // Refresh VLAN/Port Group against the current IP range data rather
    // than trusting whatever was stored when this row was last saved --
    // the matching ip.php range may have been edited since then.
    lookupIpRangeForForm(data.ip_address || '');


    document.getElementById(
        'recordModal'
    ).style.display = 'flex';
}


/*
|--------------------------------------------------------------------------
| VLAN / PORT GROUP AUTO-LOOKUP
|--------------------------------------------------------------------------
|
| Mirrors the server-side recompute in the "save" handler: VLAN and Port
| Group are never typed in, they're looked up from whichever ip.php range
| the IP Address falls inside. This just gives immediate feedback in the
| form; the save handler recomputes the same thing again before writing
| the row, so this endpoint being slow/unavailable can't produce a wrong
| stored value, only a stale-looking one until save.
*/

let ipRangeLookupTimer = null;

function lookupIpRangeForForm(ip) {

    const vlanField = document.getElementById('rec_vlan');
    const portGroupField = document.getElementById('rec_port_group');

    if (!vlanField || !portGroupField) {
        return;
    }

    ip = (ip || '').trim();

    if (ip === '') {
        vlanField.value = '';
        portGroupField.value = '';
        vlanField.placeholder = 'Derived from IP Address';
        portGroupField.placeholder = 'Derived from IP Address';
        return;
    }

    vlanField.placeholder = 'Looking up...';
    portGroupField.placeholder = 'Looking up...';

    fetch('asset.php?action=lookup_ip_range&ip=' + encodeURIComponent(ip))
        .then(res => res.json())
        .then(result => {

            if (result.found) {
                vlanField.value = result.vlan || '';
                portGroupField.value = result.port_group || '';
                vlanField.placeholder = 'Derived from IP Address';
                portGroupField.placeholder = 'Derived from IP Address';
            } else {
                vlanField.value = '';
                portGroupField.value = '';
                vlanField.placeholder = 'No matching IP range found';
                portGroupField.placeholder = 'No matching IP range found';
            }
        })
        .catch(() => {
            vlanField.placeholder = 'Lookup failed';
            portGroupField.placeholder = 'Lookup failed';
        });
}

document.addEventListener('DOMContentLoaded', function () {

    const ipField = document.getElementById('rec_ip_address');

    if (!ipField) {
        return;
    }

    ipField.addEventListener('input', function () {
        clearTimeout(ipRangeLookupTimer);
        const value = ipField.value;
        ipRangeLookupTimer = setTimeout(function () {
            lookupIpRangeForForm(value);
        }, 500);
    });
});


/*
|--------------------------------------------------------------------------
| VIEW MODAL
|--------------------------------------------------------------------------
*/

function openViewModal(data) {

    const fields = [

        'asset_name',
        'asset_type',
        'manufacturer',
        'model',
        'serial_number',
        'service_tag',
        'hostname',
        'ip_address',
        'location',
        'site',
        'region',
        'room',
        'row',
        'rack',
        'cpu_model',
        'cpu_count',
        'total_cores',
        'memory_gb',
        'internal_storage',
        'number_of_nics',
        'hba_details',
        'gpu_details',
        'vlan',
        'port_group',
        'purchase_date',
        'vendor',
        'warranty_start_date',
        'warranty_expiry_date',
        'support_vendor',
        'status',
        'end_of_life',
        'remarks'

    ];


    fields.forEach(function (key) {

        const element =
            document.getElementById(
                'v_' + key
            );


        if (!element) {
            return;
        }


        let value = '';


        if (
            data[key] !== null &&
            data[key] !== undefined &&
            data[key] !== ''
        ) {

            value =
                data[key];

        }


        element.textContent =
            value;
    });


    /*
    | VLAN/Port Group as stored can be stale -- they're only recomputed
    | when the record is saved, so a range added or edited in ip.php
    | *after* this asset was last saved would not show here otherwise.
    | Refresh both against the current ip_ranges data, the same lookup
    | the edit form's IP Address field uses.
    */
    refreshViewVlanPortGroup(data.ip_address || '');


    /*
    | Reset to the Details tab every time the modal is opened for a
    | (possibly different) row, and remember this asset's Asset Name so
    | the Linked Hostnames tab knows what to query once clicked --
    | Inventory's "HW Model" field is actually a lookup against Asset
    | Name, not this row's own Model field.
    */
    currentViewAssetName = data.asset_name || '';
    linkedHostnamesLoadedForAsset = null;
    switchViewTab('details');


    document.getElementById(
        'viewModal'
    ).style.display = 'flex';
}

function refreshViewVlanPortGroup(ip) {

    const vlanEl = document.getElementById('v_vlan');
    const portGroupEl = document.getElementById('v_port_group');

    if (!vlanEl || !portGroupEl) {
        return;
    }

    ip = (ip || '').trim();

    if (ip === '') {
        return;
    }

    vlanEl.textContent = 'Looking up...';
    portGroupEl.textContent = 'Looking up...';

    fetch('asset.php?action=lookup_ip_range&ip=' + encodeURIComponent(ip))
        .then(res => res.json())
        .then(result => {
            vlanEl.textContent = result.found ? (result.vlan || '') : '';
            portGroupEl.textContent = result.found ? (result.port_group || '') : '';
        })
        .catch(() => {
            vlanEl.textContent = '';
            portGroupEl.textContent = '';
        });
}


/*
|--------------------------------------------------------------------------
| VIEW MODAL - LINKED HOSTNAMES TAB
|--------------------------------------------------------------------------
|
| Lazy-loaded: the query only runs once the user actually clicks the tab,
| and only once per modal-open (cached in linkedHostnamesLoadedForAsset)
| so flipping back and forth between tabs doesn't re-fetch every time.
*/

let currentViewAssetName = '';
let linkedHostnamesLoadedForAsset = null;

function switchViewTab(tab) {

    const detailsBtn = document.getElementById('viewTabBtnDetails');
    const hostnamesBtn = document.getElementById('viewTabBtnHostnames');
    const detailsPanel = document.getElementById('viewTabDetails');
    const hostnamesPanel = document.getElementById('viewTabHostnames');

    const showHostnames = tab === 'hostnames';

    detailsBtn.classList.toggle('active', !showHostnames);
    hostnamesBtn.classList.toggle('active', showHostnames);
    detailsPanel.style.display = showHostnames ? 'none' : 'block';
    hostnamesPanel.style.display = showHostnames ? 'block' : 'none';

    if (showHostnames && linkedHostnamesLoadedForAsset !== currentViewAssetName) {
        loadLinkedHostnames(currentViewAssetName);
    }
}

function loadLinkedHostnames(assetName) {

    const container = document.getElementById('linkedHostnamesContainer');
    container.innerHTML = '<p class="empty-state">Loading linked hostnames...</p>';

    fetch('asset.php?action=get_linked_hostnames&asset_name=' + encodeURIComponent(assetName || ''))
        .then(res => res.text())
        .then(html => {
            container.innerHTML = html;
            linkedHostnamesLoadedForAsset = assetName;
        })
        .catch(() => {
            container.innerHTML = '<p class="empty-state" style="color:#DC2626;">Failed to load linked hostnames.</p>';
        });
}


/*
|--------------------------------------------------------------------------
| DELETE MODAL
|--------------------------------------------------------------------------
*/

function openDeleteModal(
    id,
    assetName
) {

    document.getElementById(
        'del_id'
    ).value =
        id;


    document.getElementById(
        'del_asset_name'
    ).textContent =
        assetName;


    document.getElementById(
        'deleteModal'
    ).style.display =
        'flex';
}


/*
|--------------------------------------------------------------------------
| UPLOAD MODAL
|--------------------------------------------------------------------------
*/

function openUploadModal() {

    const modal =
        document.getElementById(
            'uploadModal'
        );

    if (modal) {

        modal.style.display =
            'flex';

    }
}


/*
|--------------------------------------------------------------------------
| COLUMNS MODAL
|--------------------------------------------------------------------------
*/

function openColumnsModal() {

    document.getElementById(
        'columnsModal'
    ).style.display =
        'flex';
}


/*
|--------------------------------------------------------------------------
| CLOSE MODAL
|--------------------------------------------------------------------------
*/

function closeModal(modalId) {

    const modal =
        document.getElementById(
            modalId
        );


    if (modal) {

        modal.style.display =
            'none';

    }
}


/*
|--------------------------------------------------------------------------
| COLUMN TOGGLE
|--------------------------------------------------------------------------
*/

function toggleCol(
    colKey,
    show
) {

    document
        .querySelectorAll(
            '.col-th-' +
            colKey +
            ', .col-td-' +
            colKey
        )
        .forEach(function (element) {

            element.classList.toggle(
                'hidden-col',
                !show
            );

        });
}


/*
|--------------------------------------------------------------------------
| AUDIT HISTORY (global + per-asset)
|--------------------------------------------------------------------------
|
| Call with no argument for the full/global history (toolbar button).
| Call with an asset id to scope the history to just that one asset
| (per-row "History" button). Both paths are gated server-side on
| can_audit, and both share the same modal/content elements.
|
*/

function openHistoryModal(assetId) {

    const modal =
        document.getElementById(
            'globalHistoryModal'
        );


    const content =
        document.getElementById(
            'globalHistoryContent'
        );


    const title =
        document.getElementById(
            'historyModalTitle'
        );


    if (
        !modal ||
        !content
    ) {
        return;
    }


    modal.style.display =
        'flex';


    if (title) {

        title.innerText =
            assetId
                ? 'Asset Audit History (Asset #' + assetId + ')'
                : 'Asset Audit History';

    }


    content.innerHTML =
        '<p class="empty-state">' +
        'Loading audit history...' +
        '</p>';


    const url =
        assetId
            ? 'asset.php?action=get_history&asset_id=' + encodeURIComponent(assetId)
            : 'asset.php?action=get_history';


    fetch(
        url,
        {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'X-Requested-With':
                    'XMLHttpRequest'
            }
        }
    )
    .then(function (response) {

        if (!response.ok) {

            throw new Error(
                'HTTP ' +
                response.status
            );

        }


        return response.text();

    })
    .then(function (html) {

        content.innerHTML =
            html;

    })
    .catch(function () {

        content.innerHTML =
            '<p class="empty-state" ' +
            'style="color:#EF4444;">' +
            'Failed to load audit history logs.' +
            '</p>';

    });
}


/*
|--------------------------------------------------------------------------
| CLICK OUTSIDE MODAL
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'click',
    function (event) {

        if (
            event.target.classList.contains(
                'modal-overlay'
            )
        ) {

            event.target.style.display =
                'none';

        }

    }
);


/*
|--------------------------------------------------------------------------
| ESC KEY CLOSES MODAL
|--------------------------------------------------------------------------
*/

document.addEventListener(
    'keydown',
    function (event) {

        if (
            event.key === 'Escape'
        ) {

            document
                .querySelectorAll(
                    '.modal-overlay'
                )
                .forEach(function (modal) {

                    modal.style.display =
                        'none';

                });

        }

    }
);

</script>


<?php

require 'includes/footer.php';

?>