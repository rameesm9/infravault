<?php

session_start();

/*
|--------------------------------------------------------------------------
| ACCESS CONTROL
|--------------------------------------------------------------------------
|
| This page had no login check at all. It called session_start() and went
| straight to including the header and sidebar -- and neither of those
| redirects an anonymous visitor either, so there was no gate anywhere on
| the request path. A request with no session rendered the full dashboard:
| asset and server counts, knowledge base and SOP totals, the inventory
| breakdowns, and the Recent Activity panel, which carries audit detail
| and the names of the users who performed each action.
|
| config/db.php is required first (rather than relying on header.php to
| pull it in) so requireLogin() exists before any output is produced.
*/

require_once __DIR__ . '/config/db.php';

requireLogin();
requirePermission('dashboard', 'can_view');


/*
|--------------------------------------------------------------------------
| Spotlight customization (AJAX) -- reorder / dismiss / reset
|--------------------------------------------------------------------------
|
| Must run before includes/header.php produces any output. Only ever
| touches dashboard_spotlight_prefs for the current user -- never the
| underlying communications/reminders/sticky_notes rows, so "dismiss"
| can't accidentally delete real data.
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['spotlight_action'])) {

    require_once __DIR__ . '/includes/security.php';
    csrfVerifyOrDie();

    header('Content-Type: application/json');

    $spotlight_user_id = (int) ($_SESSION['user_id'] ?? 0);

    if ($spotlight_user_id <= 0) {
        echo json_encode(['success' => false, 'error' => 'Not logged in']);
        exit;
    }

    $spotlight_action = (string) $_POST['spotlight_action'];

    try {

        if ($spotlight_action === 'dismiss') {

            $item_key = trim((string) ($_POST['item_key'] ?? ''));

            if ($item_key !== '') {
                $stmt = $pdo->prepare("
                    INSERT INTO dashboard_spotlight_prefs (user_id, item_key, dismissed, updated_at)
                    VALUES (?, ?, 1, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, item_key)
                    DO UPDATE SET dismissed = 1, updated_at = CURRENT_TIMESTAMP
                ");
                $stmt->execute([$spotlight_user_id, $item_key]);
            }

            echo json_encode(['success' => true]);
            exit;
        }

        if ($spotlight_action === 'reorder') {

            $order = json_decode((string) ($_POST['order'] ?? '[]'), true);

            if (is_array($order)) {
                $stmt = $pdo->prepare("
                    INSERT INTO dashboard_spotlight_prefs (user_id, item_key, sort_order, updated_at)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP)
                    ON CONFLICT(user_id, item_key)
                    DO UPDATE SET sort_order = excluded.sort_order, updated_at = CURRENT_TIMESTAMP
                ");

                foreach (array_values($order) as $index => $key) {
                    $key = trim((string) $key);
                    if ($key !== '') {
                        $stmt->execute([$spotlight_user_id, $key, $index]);
                    }
                }
            }

            echo json_encode(['success' => true]);
            exit;
        }

        if ($spotlight_action === 'reset') {

            $stmt = $pdo->prepare("DELETE FROM dashboard_spotlight_prefs WHERE user_id = ?");
            $stmt->execute([$spotlight_user_id]);

            echo json_encode(['success' => true]);
            exit;
        }

        echo json_encode(['success' => false, 'error' => 'Unknown action']);
        exit;

    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'error' => 'Server error']);
        exit;
    }
}


$page_title = "Dashboard";

include "includes/header.php";

include "includes/sidebar.php";


/*
|--------------------------------------------------------------------------
| DASHBOARD DATA
|--------------------------------------------------------------------------
|
| $pdo, $header_notifications and notif_time_ago() all come from
| includes/header.php (which is included above), so nothing extra
| needs to be required here.
|
*/

function h(?string $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| Assets
|--------------------------------------------------------------------------
*/

$asset_total = (int) $pdo->query(
    "SELECT COUNT(*) FROM asset"
)->fetchColumn();

$asset_status_counts = [];

foreach (
    $pdo->query("SELECT status, COUNT(*) AS c FROM asset GROUP BY status")
        ->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {
    $asset_status_counts[$row['status'] ?: 'Unspecified'] = (int) $row['c'];
}

$asset_in_service = $asset_status_counts['In Service'] ?? 0;

$asset_type_counts = [];

foreach (
    $pdo->query("
        SELECT asset_type, COUNT(*) AS c
        FROM asset
        GROUP BY asset_type
        ORDER BY c DESC
    ")->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {
    $asset_type_counts[$row['asset_type'] ?: 'Unspecified'] = (int) $row['c'];
}


// Asset growth -- real count of assets created per month, last 12 months
$asset_growth_labels = [];
$asset_growth_data = [];

$growth_stmt = $pdo->prepare("
    SELECT COUNT(*) FROM asset
    WHERE strftime('%Y-%m', created_at) = ?
");

for ($i = 11; $i >= 0; $i--) {

    $month_ts = strtotime("-{$i} months", strtotime(date('Y-m-01')));

    $asset_growth_labels[] = date('M', $month_ts);

    $growth_stmt->execute([date('Y-m', $month_ts)]);

    $asset_growth_data[] = (int) $growth_stmt->fetchColumn();
}


/*
|--------------------------------------------------------------------------
| Inventory (Servers)
|--------------------------------------------------------------------------
*/

$inventory_total = (int) $pdo->query(
    "SELECT COUNT(*) FROM inventory"
)->fetchColumn();

$inventory_powered_on = (int) $pdo->query("
    SELECT COUNT(*) FROM inventory
    WHERE LOWER(TRIM(server_state)) = 'powered on'
")->fetchColumn();


/*
|--------------------------------------------------------------------------
| IP Address Management
|--------------------------------------------------------------------------
*/

$ip_total = (int) $pdo->query(
    "SELECT COUNT(*) FROM ip_ranges"
)->fetchColumn();

$ip_usable_sum = (int) $pdo->query(
    "SELECT COALESCE(SUM(usable_hosts), 0) FROM ip_ranges"
)->fetchColumn();


/*
|--------------------------------------------------------------------------
| Notifications summary (reuses the same feed as the header bell)
|--------------------------------------------------------------------------
*/

$comm_count = count($header_notifications['communications']);
$reminder_count = count($header_notifications['reminders']);
$sticky_count = count($header_notifications['sticky_notes']);


/*
|--------------------------------------------------------------------------
| "For You" spotlight -- merges everything actually tied to this user's
| name into one ranked feed: assignments/handovers first (they have a
| specific named owner), then overdue reminders, then team notes, then
| the rest by recency. Rendered at the very top of the page, above the
| KPI cards, per the redesign brief -- this is deliberately a different
| (smaller, ranked, personal) view than the full feed further down.
|--------------------------------------------------------------------------
*/

$spotlight_items = [];

foreach ($header_notifications['assigned_to_me'] as $c) {

    $overdue = !empty($c['target_date']) && $c['target_date'] < date('Y-m-d');

    $meta = trim(($c['note_type'] ?: 'Handover Task'));
    if (!empty($c['target_date'])) {
        $meta .= ' · ' . ($overdue ? 'Overdue since ' : 'Due ') . date('d M', strtotime($c['target_date']));
    }

    $spotlight_items[] = [
        'key'   => 'assigned_' . $c['id'],
        'rank'  => 0,
        'tone'  => $overdue ? 'critical' : 'assigned',
        'icon'  => '🤝',
        'badge' => 'Assigned to You',
        'title' => (string) $c['title'],
        'meta'  => $meta,
        'time'  => (string) ($c['target_date'] ?: $c['created_at']),
        'href'  => 'notification.php',
    ];
}

$assigned_ids = array_column($header_notifications['assigned_to_me'], 'id');

foreach ($header_notifications['reminders'] as $r) {

    $overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s');

    $spotlight_items[] = [
        'key'   => 'reminder_' . $r['id'],
        'rank'  => $overdue ? 1 : 3,
        'tone'  => $overdue ? 'critical' : 'reminder',
        'icon'  => '⏰',
        'badge' => $overdue ? 'Overdue Reminder' : 'Reminder',
        'title' => (string) $r['title'],
        'meta'  => ($overdue ? 'Was due ' : 'Due ') . date('d M, H:i', strtotime($r['reminder_date'])),
        'time'  => (string) $r['reminder_date'],
        'href'  => 'notification.php',
    ];
}

foreach ($header_notifications['communications'] as $c) {

    // Already surfaced above as a personal assignment -- don't show twice.
    if (in_array($c['id'], $assigned_ids, true)) {
        continue;
    }

    $spotlight_items[] = [
        'key'   => 'note_' . $c['id'],
        'rank'  => 2,
        'tone'  => 'note',
        'icon'  => '📌',
        'badge' => 'Team Note',
        'title' => (string) $c['title'],
        'meta'  => ($c['note_type'] ?: 'Announcement') . ' · ' . notif_time_ago($c['created_at']),
        'time'  => (string) $c['created_at'],
        'href'  => 'notification.php',
    ];
}

foreach ($header_notifications['sticky_notes'] as $n) {

    $author = trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team';

    $spotlight_items[] = [
        'key'   => 'sticky_' . $n['id'],
        'rank'  => 4,
        'tone'  => 'sticky',
        'icon'  => '🗒',
        'badge' => 'Sticky Note',
        'title' => infravault_truncate((string) $n['content'], 70),
        'meta'  => $author . ' · ' . notif_time_ago($n['updated_at']),
        'time'  => (string) $n['updated_at'],
        'href'  => 'notification.php',
    ];
}

usort($spotlight_items, function ($a, $b) {
    if ($a['rank'] !== $b['rank']) {
        return $a['rank'] <=> $b['rank'];
    }
    return strcmp($b['time'], $a['time']);
});


/*
|--------------------------------------------------------------------------
| Per-user spotlight customization -- dismissed cards are dropped, cards
| the user has manually dragged keep the position they were dropped in
| (sorted by their stored sort_order, ascending); anything never touched
| falls in afterwards in the default rank/recency order computed above.
| A brand new item (a new reminder, a newly assigned handover) always has
| no stored row yet, so it simply appears in the "untouched" tail rather
| than being hidden or forced to a stale position.
|--------------------------------------------------------------------------
*/

$spotlight_prefs = [];

try {
    $stmt = $pdo->prepare("
        SELECT item_key, sort_order, dismissed
        FROM dashboard_spotlight_prefs
        WHERE user_id = ?
    ");
    $stmt->execute([(int) ($_SESSION['user_id'] ?? 0)]);

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $p) {
        $spotlight_prefs[$p['item_key']] = $p;
    }
} catch (Throwable $e) {
    $spotlight_prefs = [];
}

$spotlight_has_prefs = (bool) $spotlight_prefs;

$spotlight_items = array_values(array_filter(
    $spotlight_items,
    fn($item) => empty($spotlight_prefs[$item['key']]['dismissed'])
));

$spotlight_pinned = [];
$spotlight_unpinned = [];

foreach ($spotlight_items as $item) {
    $pref = $spotlight_prefs[$item['key']] ?? null;
    if ($pref !== null && $pref['sort_order'] !== null) {
        $item['_order'] = (int) $pref['sort_order'];
        $spotlight_pinned[] = $item;
    } else {
        $spotlight_unpinned[] = $item;
    }
}

usort($spotlight_pinned, fn($a, $b) => $a['_order'] <=> $b['_order']);

$spotlight_items = array_merge($spotlight_pinned, $spotlight_unpinned);

$spotlight_total = count($spotlight_items);
$spotlight_items = array_slice($spotlight_items, 0, 6);


/*
|--------------------------------------------------------------------------
| Recent Activity -- merged from the per-module history tables
|--------------------------------------------------------------------------
*/

$history_sources = [
    'asset_history'        => 'Asset',
    'inventory_history'    => 'Inventory',
    'ip_ranges_history'    => 'IP Range',
    'ownership_history'    => 'Ownership',
    'decommission_history' => 'Decommission',
];

$recent_activity = [];

foreach ($history_sources as $table => $label) {

    try {

        $rows = $pdo->query("
            SELECT action_type, performed_by, details, timestamp
            FROM {$table}
            ORDER BY timestamp DESC
            LIMIT 5
        ")->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {

        $rows = [];
    }

    foreach ($rows as $row) {

        // ip_ranges_history stores a raw JSON snapshot in "details" --
        // not readable inline, so summarize instead of dumping it.
        if ($table === 'ip_ranges_history') {
            $text = 'IP range details were updated.';
        } else {
            $text = trim(strtok((string) ($row['details'] ?? ''), "\n"));
        }

        $recent_activity[] = [
            'module'       => $label,
            'action'       => $row['action_type'] ?? '',
            'text'         => $text,
            'performed_by' => trim((string) ($row['performed_by'] ?? '')) ?: 'System',
            'timestamp'    => $row['timestamp'] ?? '',
        ];
    }
}

usort(
    $recent_activity,
    fn($a, $b) => strcmp($b['timestamp'], $a['timestamp'])
);

$recent_activity = array_slice($recent_activity, 0, 8);


$activity_icons = [
    'CREATE'      => '＋',
    'CREATED'     => '＋',
    'UPDATE'      => '✎',
    'UPDATED'     => '✎',
    'DELETE'      => '🗑',
    'DELETED'     => '🗑',
    'BULK IMPORT' => '⇪',
];


/*
|--------------------------------------------------------------------------
| Breakdown helper
|--------------------------------------------------------------------------
|
| Every "X by Y" panel below is the same shape: group a column, count, order
| by count. Wrapped in try/catch so one missing table degrades that panel to
| an empty state instead of fatal-erroring the whole dashboard.
|
| NULLIF(TRIM(col),'') folds empty strings and NULLs into one "Unspecified"
| bucket rather than showing a blank row and an "Unspecified" row separately.
*/

function dashBreakdown(PDO $pdo, string $table, string $column, int $limit = 8): array
{
    try {
        $stmt = $pdo->query("
            SELECT COALESCE(NULLIF(TRIM($column), ''), 'Unspecified') AS label,
                   COUNT(*) AS c
            FROM $table
            GROUP BY label
            ORDER BY c DESC, label ASC
        ");

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        return [];
    }

    // Long tails are rolled into a single "Other" bucket rather than
    // rendered as a run of 1-row entries.
    if (count($rows) > $limit) {
        $head = array_slice($rows, 0, $limit);
        $tailCount = 0;
        foreach (array_slice($rows, $limit) as $r) {
            $tailCount += (int) $r['c'];
        }
        $head[] = ['label' => 'Other (' . (count($rows) - $limit) . ' more)', 'c' => $tailCount];
        $rows = $head;
    }

    return array_map(
        fn($r) => ['label' => (string) $r['label'], 'count' => (int) $r['c']],
        $rows
    );
}

function dashTableExists(PDO $pdo, string $table): bool
{
    try {
        return (bool) $pdo->query(
            "SELECT COUNT(*) FROM sqlite_master WHERE type='table' AND name=" . $pdo->quote($table)
        )->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function dashCount(PDO $pdo, string $sql): int
{
    try {
        return (int) $pdo->query($sql)->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}


/*
|--------------------------------------------------------------------------
| Inventory breakdowns -- OS Family, OS Version, Managed By
|--------------------------------------------------------------------------
*/

$inv_by_os_family = dashBreakdown($pdo, 'inventory', 'os_family');
$inv_by_managed_by = dashBreakdown($pdo, 'inventory', 'managed_by');

/*
| OS version is reported as "family + version". A bare version number ("8")
| does not identify a platform on its own -- RHEL 8 and Ubuntu 8 would
| collapse into the same row -- and the patching scope question this panel
| answers is always asked per platform.
*/
$inv_by_os_version = [];
try {
    $osVersionRows = $pdo->query("
        SELECT COALESCE(NULLIF(TRIM(os_family), ''), 'Unspecified') AS fam,
               COALESCE(NULLIF(TRIM(os_version), ''), 'Unspecified') AS ver,
               COUNT(*) AS c
        FROM inventory
        GROUP BY fam, ver
        ORDER BY c DESC, fam ASC, ver ASC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Capped at 7 + "Other" so the pie chart never needs more distinct
    // slices than the validated 8-hue categorical palette provides.
    $osVersionLimit = 7;
    foreach (array_slice($osVersionRows, 0, $osVersionLimit) as $r) {
        $inv_by_os_version[] = [
            'label' => $r['fam'] . ' ' . $r['ver'],
            'count' => (int) $r['c'],
        ];
    }

    if (count($osVersionRows) > $osVersionLimit) {
        $otherRows = array_slice($osVersionRows, $osVersionLimit);
        $otherCount = array_sum(array_map(fn($r) => (int) $r['c'], $otherRows));
        $inv_by_os_version[] = [
            'label' => 'Other (' . count($otherRows) . ' more)',
            'count' => $otherCount,
        ];
    }
} catch (Throwable $e) {
    $inv_by_os_version = [];
}


/*
|--------------------------------------------------------------------------
| Knowledge Base / SOPs / Known Issues
|--------------------------------------------------------------------------
*/

$kb_total   = dashCount($pdo, "SELECT COUNT(*) FROM knowledge_base");
$kb_by_category = dashBreakdown($pdo, 'knowledge_base', 'category', 6);

$kb_recent = [];
try {
    $kb_recent = $pdo->query("
        SELECT kb_number, title, category, COALESCE(updated_at, created_at) AS ts
        FROM knowledge_base
        ORDER BY ts DESC
        LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    $kb_recent = [];
}

$sop_total = dashCount($pdo, "SELECT COUNT(*) FROM sops");
$sop_published = dashCount($pdo, "SELECT COUNT(*) FROM sops WHERE LOWER(TRIM(status)) = 'published'");
$sop_by_status = dashBreakdown($pdo, 'sops', 'status', 6);

// SOPs whose review date has passed -- the actionable SOP number.
$sop_review_due = dashCount($pdo, "
    SELECT COUNT(*) FROM sops
    WHERE review_date IS NOT NULL
      AND TRIM(review_date) <> ''
      AND date(review_date) <= date('now')
");

$ki_total = dashCount($pdo, "SELECT COUNT(*) FROM known_issues");
$ki_open = dashCount($pdo, "
    SELECT COUNT(*) FROM known_issues
    WHERE LOWER(TRIM(COALESCE(status, ''))) NOT IN ('closed', 'resolved')
");
$ki_by_severity = dashBreakdown($pdo, 'known_issues', 'severity', 6);
$ki_by_status = dashBreakdown($pdo, 'known_issues', 'status', 6);


/*
|--------------------------------------------------------------------------
| Admin tasks
|--------------------------------------------------------------------------
|
| Gated on the same RBAC the rest of the app uses rather than a hardcoded
| role string: whoever may edit the Users page is who may action these.
*/

require_once __DIR__ . '/includes/permission-helpers.php';

$dash_role = trim((string) ($_SESSION['role'] ?? ''));
$dash_is_admin = in_array(strtolower($dash_role), ['admin', 'administrator', 'super admin', 'superadmin'], true);

$canManageUsers = $dash_is_admin;
if (!$canManageUsers) {
    try {
        $canManageUsers = hasRolePermission($pdo, $dash_role, 'users', 'can_edit');
    } catch (Throwable $e) {
        $canManageUsers = false;
    }
}

$pending_users = [];
$pending_user_count = 0;

if ($canManageUsers) {
    try {
        $pending_users = $pdo->query("
            SELECT id, ncgr_id, first_name, last_name, email, role,
                   COALESCE(auth_source, 'local') AS auth_source
            FROM users
            WHERE is_approved = 0
            ORDER BY id DESC
            LIMIT 6
        ")->fetchAll(PDO::FETCH_ASSOC);

        $pending_user_count = dashCount($pdo, "SELECT COUNT(*) FROM users WHERE is_approved = 0");

    } catch (Throwable $e) {
        $pending_users = [];
    }
}

/*
| Other admin-actionable counts, shown alongside pending approvals so the
| panel is a task list rather than a single number.
*/
$admin_tasks = [];

if ($canManageUsers) {

    if ($pending_user_count > 0) {
        $admin_tasks[] = [
            'label' => $pending_user_count . ' user account' . ($pending_user_count === 1 ? '' : 's') . ' awaiting approval',
            'href'  => 'users.php',
            'cta'   => 'Review',
            'tone'  => 'critical',
        ];
    }

    if ($sop_review_due > 0) {
        $admin_tasks[] = [
            'label' => $sop_review_due . ' SOP' . ($sop_review_due === 1 ? '' : 's') . ' past their review date',
            'href'  => 'sop.php',
            'cta'   => 'Open SOPs',
            'tone'  => 'warning',
        ];
    }

    if ($ki_open > 0) {
        $admin_tasks[] = [
            'label' => $ki_open . ' known issue' . ($ki_open === 1 ? '' : 's') . ' still open',
            'href'  => 'known-issues.php',
            'cta'   => 'Open Issues',
            'tone'  => 'warning',
        ];
    }
}


/*
| Severity/status tone mapping. These are STATUS colors -- reserved, and
| never reused as a category color elsewhere on the page.
*/
function dashSeverityTone(string $label): string
{
    $l = strtolower(trim($label));

    if (in_array($l, ['critical', 'p1', 'sev1', 'blocker'], true))      { return 'critical'; }
    if (in_array($l, ['high', 'major', 'p2', 'sev2'], true))            { return 'serious'; }
    if (in_array($l, ['medium', 'moderate', 'p3', 'sev3'], true))       { return 'warning'; }
    if (in_array($l, ['low', 'minor', 'p4', 'sev4', 'trivial'], true))  { return 'good'; }
    if (in_array($l, ['published', 'approved', 'active', 'closed', 'resolved'], true)) { return 'good'; }
    if (in_array($l, ['draft', 'pending', 'in review', 'review', 'submitted'], true))  { return 'warning'; }

    return 'neutral';
}


/**
 * Ranked bar list -- the form used for every "X by Y" breakdown here.
 *
 * A bar list rather than a pie/donut on purpose. These panels answer
 * "how many, and which is biggest", which length answers directly and an
 * angle does not; it stays readable from one row to twenty, needs no
 * legend because every row is labelled, and always shows the exact count
 * alongside the bar.
 *
 * Bars are a single hue. Colour would be encoding nothing here -- the
 * category is already named on the row and the magnitude is the length --
 * so giving each row its own colour would be decoration competing with
 * the status colours used elsewhere on the page. $useTone opts a panel
 * into the reserved status palette, for severity and workflow state where
 * the colour genuinely carries meaning.
 *
 * Bar width is scaled against the largest row, not the total, so a set of
 * small values is still comparable instead of collapsing into slivers.
 * The percentage shown is still of the total.
 */
function dashBarList(array $rows, int $total, bool $useTone = false): void
{
    if (!$rows) {
        echo '<div class="dash-empty">No data recorded yet.</div>';
        return;
    }

    $max = 0;
    foreach ($rows as $r) {
        $max = max($max, (int) $r['count']);
    }
    if ($max <= 0) {
        $max = 1;
    }

    echo '<ul class="dash-bars">';

    foreach ($rows as $r) {

        $count = (int) $r['count'];
        $width = max(2, (int) round(($count / $max) * 100));
        $pct = $total > 0 ? round(($count / $total) * 100) : 0;
        $tone = $useTone ? dashSeverityTone((string) $r['label']) : 'accent';

        echo '<li class="dash-bar-row">';

        echo '<span class="dash-bar-label" title="' . h($r['label']) . '">'
           . h($r['label']) . '</span>';

        echo '<span class="dash-bar-track">'
           . '<span class="dash-bar-fill tone-' . h($tone) . '" style="width:' . $width . '%"></span>'
           . '</span>';

        echo '<span class="dash-bar-value">' . number_format($count)
           . '<small>' . $pct . '%</small></span>';

        echo '</li>';
    }

    echo '</ul>';
}

?>


<main class="content">


<div class="dashboard-header">


    <div>

        <h1>
            Welcome back, <?= h($_SESSION['name'] ?? 'Admin'); ?> 👋
        </h1>


        <p>
            Here is your IT infrastructure overview
        </p>

    </div>



    <div class="dashboard-actions">

        <a href="asset.php" class="dash-action-link">
            <button type="button">
                View Assets
            </button>
        </a>


        <a href="inventory.php" class="dash-action-link">
            <button type="button">
                View Inventory
            </button>
        </a>

    </div>


</div>


<!-- FOR YOU SPOTLIGHT -->

<input type="hidden" id="spotlightCsrfToken" value="<?= h(csrfToken()) ?>">

<div class="spotlight-section">

    <div class="spotlight-head">
     
        <?php if ($spotlight_total > 0): ?>
            <span class="spotlight-count">
                <?= $spotlight_total ?> item<?= $spotlight_total === 1 ? '' : 's' ?> need<?= $spotlight_total === 1 ? 's' : '' ?> your attention
            </span>
        <?php endif; ?>

        <?php if ($spotlight_has_prefs): ?>
            <button type="button" class="spotlight-reset" id="spotlightReset" title="Restore default order and un-dismiss everything">
                ↺ Reset arrangement
            </button>
        <?php endif; ?>

        <a class="spotlight-viewall" href="notification.php">View all &rarr;</a>
    </div>

    <?php if (!$spotlight_items): ?>

        <div class="spotlight-empty">
            <span class="spotlight-empty-icon">✅</span>
            <div>
                <strong>You're all caught up</strong>
                <p>No assignments, handovers, reminders, or notes need your attention right now.</p>
            </div>
        </div>

    <?php else: ?>

        <p class="spotlight-hint">Drag <span class="spotlight-hint-icon">⠿</span> to rearrange, or <span class="spotlight-hint-icon">×</span> to dismiss a card -- just for you, it won't affect anyone else.</p>

        <div class="spotlight-grid" id="spotlightGrid">
            <?php foreach ($spotlight_items as $item): ?>
                <div class="spotlight-card tone-<?= h($item['tone']) ?>" draggable="true" data-key="<?= h($item['key']) ?>">

                    <div class="spotlight-controls">
                        <span class="spotlight-drag" title="Drag to reorder">⠿</span>
                        <button type="button" class="spotlight-dismiss" data-key="<?= h($item['key']) ?>" title="Dismiss this card">×</button>
                    </div>

                    <?php if (in_array($item['tone'], ['critical', 'assigned'], true)): ?>
                        <span class="spotlight-pulse"></span>
                    <?php endif; ?>

                    <a class="spotlight-link" href="<?= h($item['href']) ?>" draggable="false">
                        <span class="spotlight-icon"><?= $item['icon'] ?></span>
                        <span class="spotlight-badge"><?= h($item['badge']) ?></span>
                        <strong class="spotlight-title"><?= h($item['title']) ?></strong>
                        <span class="spotlight-meta"><?= h($item['meta']) ?></span>
                    </a>

                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($spotlight_total > count($spotlight_items)): ?>
            <a class="spotlight-more" href="notification.php">
                +<?= $spotlight_total - count($spotlight_items) ?> more waiting &rarr;
            </a>
        <?php endif; ?>

    <?php endif; ?>

</div>


<!-- KPI CARDS -->

<div class="stats-grid">


<div class="dashboard-card">

<div class="card-icon blue">
🖥
</div>

<div>

<span>
Total Assets
</span>

<h2>
<?= number_format($asset_total) ?>
</h2>

<p>
<?= number_format($asset_in_service) ?> In Service
</p>

</div>

</div>



<div class="dashboard-card">

<div class="card-icon green">
🗄
</div>

<div>

<span>
Servers (Inventory)
</span>

<h2>
<?= number_format($inventory_total) ?>
</h2>

<p>
<?= number_format($inventory_powered_on) ?> Powered On
</p>

</div>

</div>



<div class="dashboard-card">

<div class="card-icon orange">
🌐
</div>

<div>

<span>
IP Ranges
</span>

<h2>
<?= number_format($ip_total) ?>
</h2>

<p>
<?= number_format($ip_usable_sum) ?> Usable IPs
</p>

</div>

</div>



<div class="dashboard-card">

<div class="card-icon red">
🔔
</div>

<div>

<span>
Open Notifications
</span>

<h2>
<?= number_format($header_notifications['badge_count']) ?>
</h2>

<p>
<?= $comm_count ?> team notes &middot; <?= $reminder_count ?> reminders
</p>

</div>

</div>



</div>


<!-- KNOWLEDGE / SOP / ISSUES KPI ROW -->

<div class="stats-grid">

    <div class="dashboard-card">
        <div class="card-icon blue">📘</div>
        <div>
            <span>Knowledge Base</span>
            <h2><?= number_format($kb_total) ?></h2>
            <p><?= count($kb_by_category) ?> categor<?= count($kb_by_category) === 1 ? 'y' : 'ies' ?></p>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-icon green">📋</div>
        <div>
            <span>SOPs</span>
            <h2><?= number_format($sop_total) ?></h2>
            <p><?= number_format($sop_published) ?> published<?= $sop_review_due > 0 ? ' · ' . number_format($sop_review_due) . ' review due' : '' ?></p>
        </div>
    </div>

    <div class="dashboard-card">
        <div class="card-icon orange">⚠</div>
        <div>
            <span>Known Issues</span>
            <h2><?= number_format($ki_open) ?></h2>
            <p><?= number_format($ki_total) ?> total recorded</p>
        </div>
    </div>

    <?php if ($canManageUsers): ?>
        <div class="dashboard-card<?= $pending_user_count > 0 ? ' dash-card-attention' : '' ?>">
            <div class="card-icon red">👤</div>
            <div>
                <span>Pending Approvals</span>
                <h2><?= number_format($pending_user_count) ?></h2>
                <p><?= $pending_user_count > 0 ? 'Awaiting your review' : 'Nothing to action' ?></p>
            </div>
        </div>
    <?php else: ?>
        <div class="dashboard-card">
            <div class="card-icon red">🗂</div>
            <div>
                <span>Servers by OS</span>
                <h2><?= number_format(count($inv_by_os_version)) ?></h2>
                <p>distinct OS builds</p>
            </div>
        </div>
    <?php endif; ?>

</div>


<?php if ($canManageUsers): ?>
<!-- ADMIN TASKS -->

<div class="dashboard-row">

<div class="dashboard-panel large">

    <div class="panel-header">
        <h3>Admin Tasks</h3>
        <span><a href="users.php">Manage users</a></span>
    </div>

    <?php if (!$admin_tasks): ?>

        <div class="dash-empty">Nothing needs your attention right now.</div>

    <?php else: ?>

        <ul class="dash-task-list">
            <?php foreach ($admin_tasks as $task): ?>
                <li class="dash-task">
                    <span class="dash-task-dot tone-<?= h($task['tone']) ?>"></span>
                    <span class="dash-task-label"><?= h($task['label']) ?></span>
                    <a class="dash-task-cta" href="<?= h($task['href']) ?>"><?= h($task['cta']) ?> &rarr;</a>
                </li>
            <?php endforeach; ?>
        </ul>

    <?php endif; ?>

</div>


<div class="dashboard-panel">

    <div class="panel-header">
        <h3>Pending User Approvals</h3>
        <?php if ($pending_user_count > count($pending_users)): ?>
            <span><?= number_format($pending_user_count) ?> total</span>
        <?php endif; ?>
    </div>

    <?php if (!$pending_users): ?>

        <div class="dash-empty">No accounts are waiting for approval.</div>

    <?php else: ?>

        <ul class="dash-approval-list">
            <?php foreach ($pending_users as $pu): ?>
                <?php $puName = trim(($pu['first_name'] ?? '') . ' ' . ($pu['last_name'] ?? '')); ?>
                <li class="dash-approval">
                    <div class="dash-approval-main">
                        <strong><?= h($puName !== '' ? $puName : ($pu['ncgr_id'] ?? 'Unknown')) ?></strong>
                        <span class="dash-approval-meta">
                            <?= h($pu['ncgr_id'] ?? '') ?>
                            <?= !empty($pu['email']) ? ' · ' . h($pu['email']) : '' ?>
                        </span>
                    </div>
                    <span class="dash-source-tag tone-<?= strtolower($pu['auth_source']) === 'ldap' ? 'info' : 'neutral' ?>">
                        <?= strtolower($pu['auth_source']) === 'ldap' ? 'Directory' : 'Local' ?>
                    </span>
                </li>
            <?php endforeach; ?>
        </ul>

        <a class="dash-panel-cta" href="users.php">Review all approvals &rarr;</a>

    <?php endif; ?>

</div>

</div>
<?php endif; ?>


<!-- INVENTORY BREAKDOWN -->

<div class="dashboard-row dash-row-3">

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Servers by OS Family</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <?php dashBarList($inv_by_os_family, $inventory_total); ?>
</div>

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Servers by OS Version</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <div class="chart-container">
        <?php if ($inv_by_os_version): ?>
            <canvas id="osVersionChart"></canvas>
        <?php else: ?>
            <div class="dash-empty">No inventory recorded yet.</div>
        <?php endif; ?>
    </div>
</div>

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Servers by Managed By</h3>
        <span><?= number_format($inventory_total) ?> total</span>
    </div>
    <?php dashBarList($inv_by_managed_by, $inventory_total); ?>
</div>

</div>


<!-- KB / SOP / KNOWN ISSUES BREAKDOWN -->

<div class="dashboard-row dash-row-3">

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Knowledge Base by Category</h3>
        <span><a href="knowledge.php">View all</a></span>
    </div>
    <?php dashBarList($kb_by_category, $kb_total); ?>
</div>

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>SOPs by Status</h3>
        <span><a href="sop.php">View all</a></span>
    </div>
    <?php dashBarList($sop_by_status, $sop_total, true); ?>
</div>

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Known Issues by Severity</h3>
        <span><a href="known-issues.php">View all</a></span>
    </div>
    <?php dashBarList($ki_by_severity, $ki_total, true); ?>
</div>

</div>


<!-- RECENTLY UPDATED KB -->

<?php if ($kb_recent): ?>
<div class="dashboard-row">

<div class="dashboard-panel large">
    <div class="panel-header">
        <h3>Recently Updated Knowledge Base Articles</h3>
        <span><a href="knowledge.php">View all</a></span>
    </div>

    <ul class="dash-kb-list">
        <?php foreach ($kb_recent as $kb): ?>
            <li class="dash-kb-item">
                <span class="dash-kb-num"><?= h($kb['kb_number'] ?: '—') ?></span>
                <span class="dash-kb-title"><?= h($kb['title']) ?></span>
                <span class="dash-kb-meta">
                    <?= h($kb['category'] ?: 'Uncategorized') ?>
                    <?= !empty($kb['ts']) ? ' · ' . notif_time_ago($kb['ts']) : '' ?>
                </span>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<div class="dashboard-panel">
    <div class="panel-header">
        <h3>Known Issues by Status</h3>
    </div>
    <?php dashBarList($ki_by_status, $ki_total, true); ?>
</div>

</div>
<?php endif; ?>


<!-- CHART ROW -->

<div class="dashboard-row">


<div class="dashboard-panel large">


<div class="panel-header">

<h3>
Asset Growth
</h3>

<span>
Last 12 Months
</span>

</div>


<div class="chart-container">

<canvas id="assetChart"></canvas>

</div>


</div>



<div class="dashboard-panel">


<div class="panel-header">

<h3>
Asset Types
</h3>

</div>


<div class="chart-container">

<?php if ($asset_type_counts): ?>
    <canvas id="typeChart"></canvas>
<?php else: ?>
    <div class="dash-empty">No assets recorded yet.</div>
<?php endif; ?>

</div>


</div>



</div>


<!-- LOWER ROW -->

<div class="dashboard-row">


<div class="dashboard-panel">


<div class="panel-header">

<h3>
Notifications &amp; Team Updates
</h3>

<span>
<a href="notification.php">View all</a>
</span>

</div>


<?php if (!$comm_count && !$reminder_count && !$sticky_count): ?>

    <div class="dash-empty">
        No open notifications, reminders, or sticky notes.
    </div>

<?php else: ?>

    <ul class="dash-notif-list">

        <?php foreach ($header_notifications['communications'] as $c): ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot priority-<?= h(strtolower($c['priority'] ?? 'normal')) ?>"></span>

                <div>
                    <strong><?= h($c['title']) ?></strong>
                    <span class="dash-notif-meta">
                        Team Note &middot; <?= h($c['note_type'] ?? 'Announcement') ?>
                        &middot; <?= notif_time_ago($c['created_at']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['reminders'] as $r): ?>

            <?php $is_overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s'); ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot <?= $is_overdue ? 'priority-critical' : 'priority-normal' ?>"></span>

                <div>
                    <strong><?= h($r['title']) ?></strong>
                    <span class="dash-notif-meta">
                        Reminder &middot;
                        <?= $is_overdue ? 'Overdue' : 'Due' ?>
                        <?= h(date('d M, H:i', strtotime($r['reminder_date']))) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>


        <?php foreach ($header_notifications['sticky_notes'] as $n): ?>

            <li class="dash-notif-item">

                <span class="dash-notif-dot priority-note"></span>

                <div>
                    <strong><?= h(infravault_truncate($n['content'], 60)) ?></strong>
                    <span class="dash-notif-meta">
                        Sticky Note &middot;
                        <?= h(trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team') ?>
                        &middot; <?= notif_time_ago($n['updated_at']) ?>
                    </span>
                </div>

            </li>

        <?php endforeach; ?>

    </ul>

<?php endif; ?>


</div>



<div class="dashboard-panel">


<h3>
Recent Activity
</h3>


<?php if (!$recent_activity): ?>

    <div class="dash-empty">
        No recent activity recorded yet.
    </div>

<?php else: ?>

    <ul class="activity">

        <?php foreach ($recent_activity as $a): ?>

            <li>

                <span class="activity-icon">
                    <?= $activity_icons[$a['action']] ?? '•' ?>
                </span>

                <span>
                    <strong><?= h($a['module']) ?>:</strong>
                    <?= h($a['text']) ?: h($a['action']) ?>
                    <span class="activity-meta">
                        &mdash; <?= h($a['performed_by']) ?>, <?= notif_time_ago($a['timestamp']) ?>
                    </span>
                </span>

            </li>

        <?php endforeach; ?>

    </ul>

<?php endif; ?>


</div>



</div>


</main>



<?php

include "includes/footer.php";

?>



<script src="assets/js/chart.min.js"></script>


<script>


const assetChart =
document.getElementById('assetChart');


if(assetChart){


new Chart(
assetChart,
{

type:'line',

data:{


labels: <?= json_encode($asset_growth_labels) ?>,


datasets:[{

label:"Assets Created",

data: <?= json_encode($asset_growth_data) ?>,


borderColor:"#4F46E5",

backgroundColor:
"rgba(79,70,229,.1)",


fill:true,

tension:.4,

stepped:false


}]


},

options:{


responsive:true,

maintainAspectRatio:false,

scales:{
    y:{
        beginAtZero:true,
        ticks:{ precision:0 }
    }
}


}

});

}



const osVersionChart =
document.getElementById('osVersionChart');


if(osVersionChart){


new Chart(
osVersionChart,
{

type:'doughnut',

data:{

labels: <?= json_encode(array_column($inv_by_os_version, 'label')) ?>,

datasets:[{

data: <?= json_encode(array_column($inv_by_os_version, 'count')) ?>,

backgroundColor:[
"#2a78d6",
"#eb6834",
"#1baf7a",
"#eda100",
"#e87ba4",
"#008300",
"#4a3aa7",
"#e34948"
],

borderWidth:2,
borderColor: getComputedStyle(document.body).getPropertyValue('--bg-content') || '#ffffff'

}]

},

options:{

responsive:true,
maintainAspectRatio:false,
cutout:'62%',

plugins:{
    legend:{
        position:'bottom',
        labels:{
            boxWidth:10,
            padding:10,
            font:{ size:11 },
            color: getComputedStyle(document.body).getPropertyValue('--text-secondary').trim() || '#64748B'
        }
    }
}

}

});

}



const typeChart =
document.getElementById('typeChart');


if(typeChart){


new Chart(

typeChart,

{

type:'doughnut',

data:{


labels: <?= json_encode(array_keys($asset_type_counts)) ?>,


datasets:[{

data: <?= json_encode(array_values($asset_type_counts)) ?>,


backgroundColor:[

"#4F46E5",
"#10B981",
"#F59E0B",
"#EF4444",
"#0EA5E9",
"#94A3B8"

]


}]


},

options:{


responsive:true,

maintainAspectRatio:false


}


}

);


}



</script>


<script>

/*
|--------------------------------------------------------------------------
| Spotlight customization -- drag to reorder, click to dismiss, both
| persisted per-user via home.php's own spotlight_action AJAX handler.
| Never touches the underlying reminder/note/sticky-note rows -- only
| this user's row in dashboard_spotlight_prefs.
|--------------------------------------------------------------------------
*/

(function () {

    const grid = document.getElementById('spotlightGrid');
    if (!grid) {
        return;
    }

    const csrfTokenEl = document.getElementById('spotlightCsrfToken');
    const csrfToken = csrfTokenEl ? csrfTokenEl.value : '';

    function postSpotlight(fields) {
        const body = new URLSearchParams({ csrf_token: csrfToken, ...fields });
        return fetch(window.location.pathname, {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
            body: body.toString()
        }).then(r => r.json()).catch(() => ({ success: false }));
    }

    function currentOrder() {
        return Array.from(grid.querySelectorAll('.spotlight-card')).map(el => el.dataset.key);
    }

    function saveOrder() {
        postSpotlight({
            spotlight_action: 'reorder',
            order: JSON.stringify(currentOrder())
        });
    }

    let draggedEl = null;

    grid.querySelectorAll('.spotlight-card').forEach(card => {

        card.addEventListener('dragstart', () => {
            draggedEl = card;
            card.classList.add('spotlight-dragging');
        });

        card.addEventListener('dragend', () => {
            card.classList.remove('spotlight-dragging');
            draggedEl = null;
            saveOrder();
        });

        card.addEventListener('dragover', (e) => {
            e.preventDefault();
            if (!draggedEl || draggedEl === card) {
                return;
            }
            const rect = card.getBoundingClientRect();
            const before = (e.clientX - rect.left) < (rect.width / 2);
            grid.insertBefore(draggedEl, before ? card : card.nextSibling);
        });
    });

    grid.addEventListener('click', (e) => {

        const btn = e.target.closest('.spotlight-dismiss');
        if (!btn) {
            return;
        }

        e.preventDefault();
        e.stopPropagation();

        const card = btn.closest('.spotlight-card');
        const key = btn.dataset.key;

        btn.disabled = true;

        postSpotlight({ spotlight_action: 'dismiss', item_key: key }).then(res => {
            if (res && res.success) {
                // Reload rather than just remove the DOM node -- a dismissed
                // card can make room for one of the "+N more waiting" items
                // to appear, and only the server knows what that is.
                window.location.reload();
            } else {
                btn.disabled = false;
            }
        });
    });

    const resetBtn = document.getElementById('spotlightReset');
    if (resetBtn) {
        resetBtn.addEventListener('click', () => {
            resetBtn.disabled = true;
            postSpotlight({ spotlight_action: 'reset' }).then(() => {
                window.location.reload();
            });
        });
    }

})();

</script>


<style>

.panel-header span a {
    color: #2563EB;
    text-decoration: none;
    font-weight: 600;
}

.panel-header span a:hover {
    text-decoration: underline;
}

.dash-empty {
    padding: 30px 10px;
    text-align: center;
    color: #94A3B8;
    font-size: 13.5px;
}

.dash-action-link {
    text-decoration: none;
}

.dash-notif-list {
    list-style: none;
    margin: 4px 0 0;
    padding: 0;
    max-height: 320px;
    overflow-y: auto;
}

.dash-notif-item {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 11px 4px;
    border-bottom: 1px solid #F1F5F9;
}

.dash-notif-item:last-child {
    border-bottom: none;
}

.dash-notif-item strong {
    display: block;
    font-size: 13.5px;
    color: var(--text-primary);
    font-weight: 600;
}

.dash-notif-meta {
    display: block;
    margin-top: 2px;
    font-size: 11.5px;
    color: #94A3B8;
}

.dash-notif-dot {
    flex: 0 0 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    margin-top: 5px;
    background: #94A3B8;
}

.dash-notif-dot.priority-critical { background: #EF4444; }
.dash-notif-dot.priority-high { background: #F59E0B; }
.dash-notif-dot.priority-normal { background: #2563EB; }
.dash-notif-dot.priority-note { background: #10B981; }

.activity-icon {
    display: inline-block;
    width: 18px;
    color: #94A3B8;
}

.activity-meta {
    color: #94A3B8;
    font-size: 12.5px;
}


/* =====================================================
   DASHBOARD BREAKDOWNS
   -----------------------------------------------------
   Chart colours below were validated with the data-viz
   six checks (OKLCH lightness band, chroma floor, CVD
   separation under protan/deutan, normal-vision floor,
   contrast vs surface) against both the light (#ffffff)
   and dark (#1b2230) panel surfaces. The app's previous
   chart palette failed two of them -- #94A3B8 sat below
   the chroma floor and was only dE 11.8 from #0EA5E9,
   under the 15 normal-vision floor -- so these steps are
   used here instead of reusing it.
   ===================================================== */

.dash-row-3 {
    display: grid;
    grid-template-columns: repeat(3, minmax(0, 1fr));
    gap: 18px;
}

@media (max-width: 1100px) {
    .dash-row-3 { grid-template-columns: repeat(2, minmax(0, 1fr)); }
}

@media (max-width: 720px) {
    .dash-row-3 { grid-template-columns: minmax(0, 1fr); }
}

/* --- ranked bar list --- */

.dash-bars {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.dash-bar-row {
    display: grid;
    grid-template-columns: minmax(0, 8.5rem) 1fr auto;
    align-items: center;
    gap: 10px;
}

.dash-bar-label {
    font-size: 12.5px;
    color: var(--text-secondary, #64748B);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.dash-bar-track {
    position: relative;
    height: 8px;
    border-radius: 999px;
    background: var(--border-light, #F1F5F9);
    overflow: hidden;
}

.dash-bar-fill {
    display: block;
    height: 100%;
    border-radius: 999px;
    min-width: 3px;
}

/* Single hue: length carries the magnitude, not colour. */
.dash-bar-fill.tone-accent   { background: #4338CA; }

/* Reserved status colours -- severity and workflow state only. */
.dash-bar-fill.tone-critical { background: #B42318; }
.dash-bar-fill.tone-serious  { background: #C2410C; }
.dash-bar-fill.tone-warning  { background: #B45309; }
.dash-bar-fill.tone-good     { background: #0D9488; }
.dash-bar-fill.tone-neutral  { background: #0369A1; }

[data-theme="dark"] .dash-bar-fill.tone-accent   { background: #6366F1; }
[data-theme="dark"] .dash-bar-fill.tone-critical { background: #F43F5E; }
[data-theme="dark"] .dash-bar-fill.tone-serious  { background: #FB7185; }
[data-theme="dark"] .dash-bar-fill.tone-warning  { background: #D97706; }
[data-theme="dark"] .dash-bar-fill.tone-good     { background: #0D9488; }
[data-theme="dark"] .dash-bar-fill.tone-neutral  { background: #0284C7; }

.dash-bar-value {
    font-size: 13px;
    font-weight: 600;
    color: var(--text-primary, #1E293B);
    font-variant-numeric: tabular-nums;
    text-align: right;
    min-width: 4.5rem;
}

.dash-bar-value small {
    display: inline-block;
    margin-left: 6px;
    font-weight: 500;
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
}

/* --- admin tasks --- */

.dash-card-attention {
    box-shadow: inset 3px 0 0 #B42318;
}

.dash-task-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
}

.dash-task {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-task:last-child { border-bottom: none; }

.dash-task-dot {
    flex: 0 0 8px;
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: #94A3B8;
}

.dash-task-dot.tone-critical { background: #B42318; }
.dash-task-dot.tone-warning  { background: #B45309; }
.dash-task-dot.tone-good     { background: #0D9488; }

.dash-task-label {
    flex: 1;
    font-size: 13.5px;
    color: var(--text-primary, #1E293B);
}

.dash-task-cta,
.dash-panel-cta {
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
    white-space: nowrap;
}

.dash-task-cta:hover,
.dash-panel-cta:hover { text-decoration: underline; }

.dash-panel-cta {
    display: inline-block;
    margin-top: 12px;
}

/* --- pending approvals --- */

.dash-approval-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
    max-height: 260px;
    overflow-y: auto;
}

.dash-approval {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 10px;
    padding: 10px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-approval:last-child { border-bottom: none; }

.dash-approval-main { min-width: 0; }

.dash-approval-main strong {
    display: block;
    font-size: 13.5px;
    font-weight: 600;
    color: var(--text-primary, #1E293B);
}

.dash-approval-meta {
    display: block;
    margin-top: 2px;
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
    white-space: nowrap;
    overflow: hidden;
    text-overflow: ellipsis;
}

.dash-source-tag {
    flex-shrink: 0;
    font-size: 11px;
    font-weight: 700;
    padding: 3px 9px;
    border-radius: 999px;
    background: var(--hover-bg, #F1F5F9);
    color: var(--text-secondary, #64748B);
}

.dash-source-tag.tone-info {
    background: #EFF6FF;
    color: #1D4ED8;
}

[data-theme="dark"] .dash-source-tag.tone-info {
    background: #1B2740;
    color: #7BA6FF;
}

/* --- recent KB list --- */

.dash-kb-list {
    list-style: none;
    margin: 6px 0 0;
    padding: 0;
}

.dash-kb-item {
    display: grid;
    grid-template-columns: auto 1fr auto;
    align-items: center;
    gap: 12px;
    padding: 11px 4px;
    border-bottom: 1px solid var(--border-light, #F1F5F9);
}

.dash-kb-item:last-child { border-bottom: none; }

.dash-kb-num {
    font-size: 11.5px;
    font-weight: 700;
    color: #4338CA;
    background: #EEF2FF;
    padding: 3px 8px;
    border-radius: 6px;
    white-space: nowrap;
}

[data-theme="dark"] .dash-kb-num {
    background: #1B2740;
    color: #818CF8;
}

.dash-kb-title {
    font-size: 13.5px;
    color: var(--text-primary, #1E293B);
    font-weight: 600;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.dash-kb-meta {
    font-size: 11.5px;
    color: var(--text-muted, #94A3B8);
    white-space: nowrap;
}


/* =====================================================
   FOR YOU SPOTLIGHT
   ----------------------------------------------------
   The personalized feed sits above the KPI cards on
   purpose -- it answers "what needs me by name" before
   the page gets into fleet-wide numbers. Tone colors are
   deliberately soft gradients (not the saturated status
   palette used for severity/workflow elsewhere) so six
   cards side by side read as inviting, not alarming --
   urgency is carried by the pulse dot and badge text
   instead of raw color intensity.
   ===================================================== */

.spotlight-section {
    margin-bottom: 22px;
}

.spotlight-head {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 10px;
    margin-bottom: 12px;
}

.spotlight-head h2 {
    margin: 0;
    font-size: 19px;
    font-weight: 700;
    color: var(--text-primary, #1E293B);
}

.spotlight-count {
    font-size: 12px;
    font-weight: 600;
    color: #B45309;
    background: #FFFBEB;
    border: 1px solid #FDE68A;
    padding: 4px 11px;
    border-radius: 999px;
}

[data-theme="dark"] .spotlight-count {
    color: #FBBF24;
    background: #3A2A10;
    border-color: #5A4212;
}

.spotlight-viewall {
    margin-left: auto;
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
    white-space: nowrap;
}

.spotlight-viewall:hover {
    text-decoration: underline;
}

.spotlight-reset {
    background: none;
    border: 1px solid var(--border-light, #E2E8F0);
    color: var(--text-secondary, #64748B);
    font-size: 11.5px;
    font-weight: 600;
    padding: 4px 11px;
    border-radius: 999px;
    cursor: pointer;
}

.spotlight-reset:hover {
    background: var(--hover-bg, #F1F5F9);
    color: var(--text-primary, #1E293B);
}

[data-theme="dark"] .spotlight-reset {
    border-color: #334155;
}

.spotlight-hint {
    margin: -2px 0 10px;
    font-size: 11.5px;
    color: var(--text-secondary, #64748B);
}

.spotlight-hint-icon {
    font-weight: 700;
}

.spotlight-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(230px, 1fr));
    gap: 14px;
}

.spotlight-card {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 34px 16px 14px;
    border-radius: 14px;
    border: 1px solid transparent;
    overflow: hidden;
    transition: transform .15s ease, box-shadow .15s ease, opacity .15s ease;
}

.spotlight-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 26px rgba(15, 23, 42, .14);
}

.spotlight-card.spotlight-dragging {
    opacity: .4;
}

.spotlight-controls {
    position: absolute;
    top: 10px;
    right: 10px;
    display: flex;
    align-items: center;
    gap: 6px;
}

.spotlight-drag {
    cursor: grab;
    font-size: 14px;
    line-height: 1;
    padding: 2px;
    color: var(--text-secondary, #64748B);
    opacity: .6;
}

.spotlight-drag:active {
    cursor: grabbing;
}

.spotlight-dismiss {
    width: 18px;
    height: 18px;
    padding: 0;
    border: none;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 13px;
    line-height: 1;
    background: rgba(15, 23, 42, .08);
    color: var(--text-secondary, #64748B);
    cursor: pointer;
}

.spotlight-dismiss:hover {
    background: rgba(220, 38, 38, .15);
    color: #B42318;
}

[data-theme="dark"] .spotlight-dismiss {
    background: rgba(255, 255, 255, .08);
}

[data-theme="dark"] .spotlight-dismiss:hover {
    background: rgba(248, 113, 113, .2);
    color: #FCA5A5;
}

.spotlight-link {
    display: flex;
    flex-direction: column;
    gap: 5px;
    text-decoration: none;
    color: inherit;
}

.spotlight-icon {
    font-size: 20px;
    line-height: 1;
}

.spotlight-badge {
    font-size: 10.5px;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: .04em;
}

.spotlight-title {
    font-size: 14px;
    font-weight: 700;
    color: var(--text-primary, #1E293B);
    line-height: 1.35;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
}

.spotlight-meta {
    font-size: 11.5px;
    color: var(--text-secondary, #64748B);
}

.spotlight-pulse {
    position: absolute;
    top: 13px;
    left: 14px;
    width: 9px;
    height: 9px;
    border-radius: 50%;
    background: #EF4444;
    animation: spotlightPulse 1.8s infinite;
}

@keyframes spotlightPulse {
    0%   { box-shadow: 0 0 0 0 rgba(239, 68, 68, .55); }
    70%  { box-shadow: 0 0 0 8px rgba(239, 68, 68, 0); }
    100% { box-shadow: 0 0 0 0 rgba(239, 68, 68, 0); }
}

/* tones */

.spotlight-card.tone-assigned {
    background: linear-gradient(135deg, #EEF2FF, #E0E7FF);
    border-color: #C7D2FE;
}
.spotlight-card.tone-assigned .spotlight-badge { color: #4338CA; }

.spotlight-card.tone-critical {
    background: linear-gradient(135deg, #FEF2F2, #FEE2E2);
    border-color: #FECACA;
}
.spotlight-card.tone-critical .spotlight-badge { color: #B42318; }

.spotlight-card.tone-note {
    background: linear-gradient(135deg, #EFF6FF, #DBEAFE);
    border-color: #BFDBFE;
}
.spotlight-card.tone-note .spotlight-badge { color: #1D4ED8; }

.spotlight-card.tone-reminder {
    background: linear-gradient(135deg, #FFFBEB, #FEF3C7);
    border-color: #FDE68A;
}
.spotlight-card.tone-reminder .spotlight-badge { color: #B45309; }

.spotlight-card.tone-sticky {
    background: linear-gradient(135deg, #ECFDF5, #D1FAE5);
    border-color: #A7F3D0;
}
.spotlight-card.tone-sticky .spotlight-badge { color: #047857; }

[data-theme="dark"] .spotlight-card.tone-assigned {
    background: linear-gradient(135deg, #1E1B4B, #241F5C);
    border-color: #3730A3;
}
[data-theme="dark"] .spotlight-card.tone-assigned .spotlight-badge { color: #A5B4FC; }

[data-theme="dark"] .spotlight-card.tone-critical {
    background: linear-gradient(135deg, #3A1414, #451A1A);
    border-color: #7F1D1D;
}
[data-theme="dark"] .spotlight-card.tone-critical .spotlight-badge { color: #FCA5A5; }

[data-theme="dark"] .spotlight-card.tone-note {
    background: linear-gradient(135deg, #16213A, #1B2740);
    border-color: #2C4373;
}
[data-theme="dark"] .spotlight-card.tone-note .spotlight-badge { color: #93C5FD; }

[data-theme="dark"] .spotlight-card.tone-reminder {
    background: linear-gradient(135deg, #3A2A10, #43310F);
    border-color: #5A4212;
}
[data-theme="dark"] .spotlight-card.tone-reminder .spotlight-badge { color: #FCD34D; }

[data-theme="dark"] .spotlight-card.tone-sticky {
    background: linear-gradient(135deg, #0F2E24, #123626);
    border-color: #1F5C42;
}
[data-theme="dark"] .spotlight-card.tone-sticky .spotlight-badge { color: #6EE7B7; }

.spotlight-more {
    display: inline-block;
    margin-top: 10px;
    font-size: 12.5px;
    font-weight: 600;
    color: #2563EB;
    text-decoration: none;
}

.spotlight-more:hover {
    text-decoration: underline;
}

.spotlight-empty {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 18px 20px;
    border-radius: 14px;
    background: linear-gradient(135deg, #ECFDF5, #F0FDF4);
    border: 1px solid #A7F3D0;
}

[data-theme="dark"] .spotlight-empty {
    background: linear-gradient(135deg, #0F2E24, #0D2A1F);
    border-color: #1F5C42;
}

.spotlight-empty-icon {
    font-size: 26px;
    line-height: 1;
}

.spotlight-empty strong {
    display: block;
    font-size: 14px;
    color: var(--text-primary, #1E293B);
}

.spotlight-empty p {
    margin: 3px 0 0;
    font-size: 12.5px;
    color: var(--text-secondary, #64748B);
}

</style>
