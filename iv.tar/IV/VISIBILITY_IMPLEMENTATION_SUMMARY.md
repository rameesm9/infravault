# Granular Visibility/Sharing Controls Implementation Summary

## Overview
Implemented granular visibility and sharing controls for reminders, sticky notes, communications (notifications), and mydata. Replaced simple "all/private" visibility with 4 new types: private, public, team, and user.

## Database Schema Changes

### 1. **config/schema/reminders.php**
- **Reminders Table**: Changed default visibility from 'all' to 'public'
  - Added migration: `UPDATE reminders SET visibility='public' WHERE visibility='all'`
- **Sticky Notes Table**: Changed default visibility from 'all' to 'public'
  - Added migration: `UPDATE sticky_notes SET visibility='public' WHERE visibility='all'`

#### New Join Tables for Reminders:
- `reminder_teams (id, reminder_id, team_name, created_at)`
  - Foreign key: reminder_id → reminders(id) ON DELETE CASCADE
  - Unique constraint: (reminder_id, team_name)
- `reminder_users (id, reminder_id, user_id, created_at)`
  - Foreign key: reminder_id → reminders(id) ON DELETE CASCADE
  - Unique constraint: (reminder_id, user_id)

#### New Join Tables for Sticky Notes:
- `sticky_note_teams (id, sticky_note_id, team_name, created_at)`
  - Foreign key: sticky_note_id → sticky_notes(id) ON DELETE CASCADE
  - Unique constraint: (sticky_note_id, team_name)
- `sticky_note_users (id, sticky_note_id, user_id, created_at)`
  - Foreign key: sticky_note_id → sticky_notes(id) ON DELETE CASCADE
  - Unique constraint: (sticky_note_id, user_id)

### 2. **config/schema/communications.php**
- **Communications Table**: Added `visibility TEXT DEFAULT 'public'` column
- **New Join Tables**:
  - `communication_teams (id, communication_id, team_name, created_at)`
  - `communication_users (id, communication_id, user_id, created_at)`

### 3. **config/schema/mydata.php**
- **My Data Table**: Updated default visibility to 'private'
- **New Join Tables**:
  - `mydata_teams (id, mydata_id, team_name, created_at)`
  - `mydata_users (id, mydata_id, user_id, created_at)`
- **New Indexes**: Added indexes on mydata_teams and mydata_users tables

## Visibility Types

### 1. **Private** (value: 'private')
- Only the owner can view
- No associated teams or users in join tables

### 2. **Public** (value: 'public')
- Everyone can view
- Backward compatible with old 'all' visibility
- Automatically migrated from 'all' to 'public'

### 3. **Team** (value: 'team')
- Only members of selected teams can view
- Teams stored in reminder_teams/sticky_note_teams/communication_teams/mydata_teams
- Multiple teams can be selected for a single record

### 4. **User** (value: 'user')
- Only selected individual users can view
- Users stored in reminder_users/sticky_note_users/communication_users/mydata_users
- Multiple users can be selected for a single record

## Code Changes - reminders.php

### New Helper Functions:

1. **canViewReminder($reminder, $current_user_id, $current_user_team, $role, $pdo)**
   - Checks if current user can view a reminder based on visibility settings
   - Returns true if: admin OR owner OR public OR (team member) OR (in shared users)

2. **canViewNote($note, $current_user_id, $current_user_team, $role, $pdo)**
   - Same logic as canViewReminder but for sticky notes

3. **getUniqueTeams($pdo)**
   - Fetches all unique team names from users table
   - Used for populating team selector

4. **getAllUsers($pdo)**
   - Fetches all users with id, first_name, last_name, email
   - Used for populating user selector

5. **getVisibilityDisplay($visibility, $id, $type, $pdo)**
   - Formats visibility status for display in tables/lists
   - Shows team count and user count for team/user visibility types

### Updated POST Handlers:

#### save_reminder
- Reads new radio button values for visibility
- Collects reminder_teams[] and reminder_users[] arrays
- Creates reminder record
- Saves team associations to reminder_teams
- Saves user associations to reminder_users

#### edit_reminder
- Loads selected teams and users for editing
- Clears old team/user associations before saving
- Saves new team/user associations

#### delete_reminder
- Deletes associated team/user records (cascading)

#### save_note (Sticky Notes)
- Same pattern as save_reminder but for sticky notes
- Uses sticky_note_teams and sticky_note_users tables
- Handles note_teams[] and note_users[] arrays

#### delete_note
- Deletes associated team/user records

### Updated SELECT Queries:

#### FETCH STICKY NOTES
- Fetches all sticky notes (no WHERE clause filtering)
- Filters using PHP array_filter() with canViewNote() function
- Preserves order by updated_at DESC

#### FETCH REMINDERS
- Fetches all reminders (no WHERE clause filtering)
- Filters using PHP array_filter() with canViewReminder() function
- Preserves order by reminder_date ASC

#### EDIT REMINDER LOAD
- Loads reminder record
- Loads associated teams from reminder_teams
- Loads associated users from reminder_users

### UI Updates:

#### Reminder Visibility Control (reminders.php form):
Replaced dropdown with radio buttons:
- Private (only me)
- Public (everyone)
- Team
- Specific Users

Dynamic selectors that appear/disappear based on selection:
- Team selector (checkboxes) - shows all unique teams from users table
- User selector (checkboxes) - shows all approved users with full name and email

#### Sticky Note Visibility Control:
Replaced dropdown with radio buttons (same as reminders)
- Private (only me)
- Public (everyone)
- Team
- Specific Users

Same dynamic selectors as reminder form

### Visibility Display in Tables:

Updated visibility badges in table views:
- status-all: Everyone (green badge) - for public records
- status-private: Private (red badge) - for private records
- status-team: Team (blue badge) - shows "Team (X)" indicating number of shared teams
- status-user: Users (pink badge) - shows "Users (X)" indicating number of shared users

### JavaScript Enhancements:

1. **Radio Button Change Listeners**
   - Listener on visibility radio buttons
   - Shows/hides team and user selectors based on selection
   - Applied to both reminder form and sticky note form

2. **Form Data Collection**
   - saveNote() collects checked teams and users
   - Appends to FormData as arrays: note_teams[], note_users[]
   - Sends to server for processing

3. **EditNote Function**
   - Updated to set radio button value based on visibility type
   - Triggers change event to show/hide appropriate selectors

## Backward Compatibility

### Migration Strategy:
1. **Reminders Table**: Old 'all' values automatically migrated to 'public'
2. **Sticky Notes Table**: Old 'all' values automatically migrated to 'public'
3. **Existing private entries**: Remain unchanged (treated as private visibility)
4. **Empty join tables**: Don't create records for records without team/user visibility

### Behavior:
- Records without team/user visibility don't have entries in join tables
- Queries handle missing join table entries gracefully
- Admin users can always view/edit all records

## CSS Additions (assets/css/reminders-enterprise.css)

Added new status badge classes:
- `.status-team`: Blue badge for team-shared records
- `.status-user`: Pink badge for user-shared records

## Security Notes

1. **Authorization**: Only owners and admins can edit records
2. **Visibility Filtering**: Applied on both database (future optimization) and PHP levels
3. **Team/User Validation**: Teams must exist in users table; users must be approved
4. **SQL Injection Prevention**: Prepared statements used throughout
5. **CSRF Protection**: Compatible with existing CSRF token system

## Implementation Notes

### Teams Source:
- Teams are pulled from the users table (team column)
- All unique team values are offered as sharing options
- Users must be assigned to a team for team sharing to work

### Users Source:
- All approved users from the users table can be shared with
- User selector shows full name and email for clarity

### Join Table Design:
- Separate tables for teams and users (follows normalization)
- Composite unique constraints prevent duplicates
- Cascade delete ensures cleanup when main records are deleted
- Indexes added for query optimization

## Future Enhancements

1. **MyData Integration**: Update mydata.php to use new join tables while maintaining backward compatibility with existing Person/Team model
2. **Communication/Notification Enhancement**: Full integration of new visibility model in notification.php
3. **Audit Logging**: Track visibility changes for compliance
4. **Bulk Operations**: Allow changing visibility for multiple records at once
5. **Query Optimization**: Implement database-level filtering using complex JOINs instead of PHP filtering

## Testing Checklist

- [ ] Create reminder with private visibility
- [ ] Create reminder with public visibility  
- [ ] Create reminder with team visibility (select multiple teams)
- [ ] Create reminder with user visibility (select multiple users)
- [ ] Edit reminder and change visibility type
- [ ] Verify non-owner users see only visible records
- [ ] Verify admins see all records
- [ ] Delete reminder and verify join table entries are removed
- [ ] Test sticky note visibility with all four types
- [ ] Verify migration: old 'all' values converted to 'public'
- [ ] Test with multiple teams and users
- [ ] Verify visibility badges display correctly in tables
