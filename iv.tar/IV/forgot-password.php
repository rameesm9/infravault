<?php

/*
| No session_start() here, for the same reason index.php does not have one:
| config/db.php runs securityBootstrap(), which starts the session with the
| hardened cookie parameters. Starting it first would issue the cookie before
| those could be applied.
|
| This page is deliberately reachable without signing in -- it exists for
| people who cannot. It is protected instead by CSRF verification, a rate
| limit keyed on both the submitted NCGR ID and the client address, and by
| never revealing whether an account matched.
*/

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/password-reset-helpers.php';

// Adds the Settings -> Mail toggle for this feature if it is not there yet,
// the same way patching.php registers its own. Cheap (INSERT OR IGNORE) and
// makes the page self-sufficient on a database that predates it.
registerMailModule($pdo, PASSWORD_RESET_MAIL_MODULE, 'Password Reset Emails');

$notice     = '';
$noticeType = '';           // 'info' | 'error'
$ncgr_id    = '';
$email      = '';

/*
| Every attempt is written to password_reset_requests regardless of outcome,
| for an admin to read back.
*/
const PASSWORD_RESET_SUCCESS_NOTICE =
    'A temporary password has been sent to your email address. It can take a '
    . 'few minutes to arrive — check your junk folder before trying again.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    csrfVerifyOrDie();

    $ncgr_id = trim($_POST['ncgr_id'] ?? '');
    $email   = trim($_POST['email'] ?? '');

    // Opportunistic housekeeping, as pruneLoginAttempts() does on the login
    // page -- keeps the table bounded in a deployment with no cron.
    prunePasswordResetRequests($pdo);

    if ($ncgr_id === '' || $email === '') {

        $notice     = 'Enter both your NCGR ID and the email address on your account.';
        $noticeType = 'error';

    } elseif (passwordResetIsRateLimited($pdo, $ncgr_id)) {

        /*
        | Not an enumeration leak: this response depends only on how many
        | requests have been made, never on whether the account exists.
        */
        recordPasswordResetRequest($pdo, $ncgr_id, 'rate_limited');

        $notice     = 'Too many password reset requests. Please wait 15 minutes before trying again.';
        $noticeType = 'error';

    } else {

        $stmt = $pdo->prepare("
            SELECT id, ncgr_id, first_name, last_name, email, is_approved,
                   COALESCE(auth_source, 'local') AS auth_source
            FROM users
            WHERE ncgr_id = ?
            LIMIT 1
        ");

        $stmt->execute([$ncgr_id]);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$user) {

            recordPasswordResetRequest($pdo, $ncgr_id, 'no_match');

            $notice     = 'No InfraVault account was found with that NCGR ID.';
            $noticeType = 'error';

        } elseif (strcasecmp(trim((string) $user['email']), $email) !== 0) {

            recordPasswordResetRequest($pdo, $ncgr_id, 'no_match');

            $notice     = 'That email address does not match the one on file for this NCGR ID.';
            $noticeType = 'error';

        } elseif ((int) $user['is_approved'] !== 1) {

            /*
            | A pending account has no password worth resetting -- it cannot
            | sign in until an admin approves it, so mailing one would only
            | be confusing.
            */
            recordPasswordResetRequest($pdo, $ncgr_id, 'not_approved');

            $notice     = 'This account has not been approved yet. Contact your administrator.';
            $noticeType = 'error';

        } elseif ($user['auth_source'] === 'ldap') {

            /*
            | Directory accounts are verified by binding to LDAP on every
            | login; the local password column holds an unusable placeholder
            | (see index.php). Overwriting it would change nothing about how
            | this person signs in, so the reset is refused -- their password
            | is reset wherever the directory is managed.
            */
            recordPasswordResetRequest($pdo, $ncgr_id, 'ldap_account');

            $notice     = 'This account signs in through your organization directory. Reset your password there instead.';
            $noticeType = 'error';

        } else {

            $result = issueTemporaryPassword($pdo, $user);

            if ($result['success']) {

                recordPasswordResetRequest($pdo, $ncgr_id, 'sent');

                $notice     = PASSWORD_RESET_SUCCESS_NOTICE;
                $noticeType = 'info';

                // Only clear the form on an actual success -- an error above
                // should leave what was typed so it can be corrected.
                $ncgr_id = '';
                $email   = '';

            } else {

                /*
                | The mail may or may not have gone out, but the account's
                | password was NOT changed either way (issueTemporaryPassword
                | only writes the new hash after a successful send). Saying
                | "check your email" here would send the user off to wait for
                | a login that will never work, so this is the one failure
                | that has to be visible rather than folded into the generic
                | notice. This row's `detail` column, and the error log, have
                | the real reason (SMTP down, module disabled, DB error, ...).
                */
                recordPasswordResetRequest($pdo, $ncgr_id, 'mail_failed', $result['message']);
                error_log('Password reset failed for ' . $ncgr_id . ': ' . $result['message']);

                $notice     = 'We could not complete your password reset due to a system error. Please contact your administrator.';
                $noticeType = 'error';
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password | InfraVault</title>
<link rel="icon" href="assets/images/infravault-logo.svg">

<style>

@font-face {
    font-family: Inter;
    src: url("assets/webfonts/Inter-Regular.woff2") format("woff2");
    font-weight: 400 700;
}

:root {
    --navy-950: #020617;
    --accent: #22D3EE;
    --accent-2: #2563EB;
    --indigo: #4F46E5;
    --ink: #0F172A;
    --muted: #64748B;
    --border: #E2E8F0;
    --danger-bg: #FEF2F2;
    --danger-border: #FECACA;
    --danger-ink: #991B1B;
    --info-bg: #EFF6FF;
    --info-border: #BFDBFE;
    --info-ink: #1D4ED8;
}

* {
    box-sizing: border-box;
}

html, body {
    height: 100%;
}

body {
    margin: 0;
    min-height: 100vh;
    background: var(--navy-950);
    font-family: Inter, "Segoe UI", Arial, sans-serif;
    color: var(--ink);
    position: relative;
    overflow-x: hidden;
}

/* Same treatment as the login page, minus the rack skyline: this is a
   detour off that screen and should read as the same product, but it does
   not need to carry the full hero. */
.backdrop {
    position: fixed;
    inset: 0;
    z-index: 0;
}

.backdrop svg {
    width: 100%;
    height: 100%;
    display: block;
}

.page {
    position: relative;
    z-index: 1;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 56px 20px 40px;
}

.lockup {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 34px;
}

.lockup img {
    width: 30px;
    height: 30px;
}

.lockup span {
    font-size: 15px;
    font-weight: 800;
    letter-spacing: .02em;
    color: #F1F5F9;
}

.card-wrap {
    position: relative;
    width: 100%;
    max-width: 430px;
}

.badge {
    position: absolute;
    top: -30px;
    left: 50%;
    transform: translateX(-50%);
    width: 60px;
    height: 60px;
    border-radius: 50%;
    background: linear-gradient(135deg, var(--accent-2), var(--accent));
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: 0 12px 30px rgba(34, 211, 238, .35), 0 0 0 6px rgba(255, 255, 255, .06);
    z-index: 2;
}

.badge svg {
    width: 26px;
    height: 26px;
    color: #fff;
}

.card {
    position: relative;
    background: rgba(255, 255, 255, .78);
    backdrop-filter: blur(24px) saturate(180%);
    -webkit-backdrop-filter: blur(24px) saturate(180%);
    border: 1px solid rgba(255, 255, 255, .6);
    border-radius: 28px;
    padding: 52px 40px 36px;
    box-shadow: 0 25px 70px rgba(2, 6, 23, .45), inset 0 1px 0 rgba(255, 255, 255, .6);
    text-align: center;
}

.card h2 {
    font-size: 25px;
    font-weight: 800;
    margin: 0 0 6px;
    letter-spacing: -.01em;
}

.card-sub {
    color: var(--muted);
    font-size: 13.5px;
    margin: 0;
}

.banner {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 10px;
    margin: 18px 0 4px;
    font-size: 13px;
    line-height: 1.5;
    text-align: left;
    border: 1px solid transparent;
}

.banner svg {
    flex-shrink: 0;
    width: 16px;
    height: 16px;
    margin-top: 1px;
}

.banner.error {
    background: var(--danger-bg);
    border-color: var(--danger-border);
    color: var(--danger-ink);
}

.banner.info {
    background: var(--info-bg);
    border-color: var(--info-border);
    color: var(--info-ink);
}

form {
    margin-top: 14px;
    text-align: left;
}

.field {
    margin-top: 16px;
}

.field label {
    display: block;
    margin-bottom: 7px;
    font-size: 12.5px;
    font-weight: 700;
    color: #334155;
}

.field-input {
    position: relative;
    display: flex;
    align-items: center;
}

.field-input svg.leading-icon {
    position: absolute;
    left: 15px;
    width: 16px;
    height: 16px;
    color: #94A3B8;
    pointer-events: none;
}

.field input {
    width: 100%;
    padding: 12px 14px 12px 42px;
    border-radius: 999px;
    border: 1px solid rgba(15, 23, 42, .12);
    background: rgba(255, 255, 255, .7);
    font-size: 14px;
    font-family: inherit;
    color: var(--ink);
    transition: .15s;
}

.field input:focus {
    outline: none;
    border-color: var(--accent-2);
    background: rgba(255, 255, 255, .95);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .14);
}

.field-hint {
    margin: 7px 0 0 16px;
    font-size: 12px;
    color: var(--muted);
}

button.submit {
    width: 100%;
    margin-top: 26px;
    padding: 14px;
    border: none;
    border-radius: 999px;
    background: linear-gradient(135deg, var(--accent-2), var(--indigo));
    color: #fff;
    font-size: 14.5px;
    font-weight: 700;
    cursor: pointer;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 9px;
    transition: filter .15s, transform .1s;
}

button.submit:hover {
    filter: brightness(1.08);
}

button.submit:active {
    transform: translateY(1px);
}

button.submit[disabled] {
    opacity: .75;
    cursor: not-allowed;
}

.spinner {
    width: 15px;
    height: 15px;
    border-radius: 50%;
    border: 2px solid rgba(255, 255, 255, .4);
    border-top-color: #fff;
    animation: spin .7s linear infinite;
    display: none;
}

button.submit.loading .spinner {
    display: inline-block;
}

@keyframes spin {
    to { transform: rotate(360deg); }
}

.divider {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 24px 0 18px;
    color: #94A3B8;
    font-size: 11.5px;
    text-transform: uppercase;
    letter-spacing: .05em;
}

.divider::before,
.divider::after {
    content: "";
    flex: 1;
    height: 1px;
    background: var(--border);
}

.back-link a {
    display: block;
    padding: 12px;
    border-radius: 999px;
    border: 1px solid var(--border);
    color: #334155;
    text-decoration: none;
    font-weight: 700;
    font-size: 13.5px;
    transition: .15s;
}

.back-link a:hover {
    background: #F8FAFC;
    border-color: #CBD5E1;
}

.page-footer {
    margin-top: 26px;
    text-align: center;
    font-size: 11.5px;
    color: rgba(148, 163, 184, .6);
}

@media (max-width: 480px) {
    .card {
        padding: 46px 26px 30px;
    }
}

</style>

</head>
<body>

<div class="backdrop" aria-hidden="true">
    <svg viewBox="0 0 1600 900" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">

        <defs>
            <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stop-color="#020617"/>
                <stop offset="55%" stop-color="#0B1220"/>
                <stop offset="100%" stop-color="#0F172A"/>
            </linearGradient>

            <pattern id="floorGrid" width="64" height="64" patternUnits="userSpaceOnUse">
                <path d="M64 0H0V64" fill="none" stroke="#FFFFFF" stroke-opacity="0.045"/>
            </pattern>

            <filter id="blurBlob" x="-60%" y="-60%" width="220%" height="220%">
                <feGaussianBlur stdDeviation="75"/>
            </filter>
        </defs>

        <rect width="1600" height="900" fill="url(#bgGrad)"/>
        <rect width="1600" height="900" fill="url(#floorGrid)"/>

        <circle cx="230" cy="170" r="230" fill="#22D3EE" opacity="0.28" filter="url(#blurBlob)"/>
        <circle cx="1370" cy="740" r="290" fill="#4F46E5" opacity="0.32" filter="url(#blurBlob)"/>
        <circle cx="1250" cy="160" r="160" fill="#2563EB" opacity="0.18" filter="url(#blurBlob)"/>

    </svg>
</div>

<div class="page">

    <div class="lockup">
        <img src="assets/images/infravault-logo.svg" alt="InfraVault">
        <span>InfraVault</span>
    </div>

    <div class="card-wrap">

        <div class="badge">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="4" y="11" width="16" height="9" rx="2"/>
                <path d="M8 11V8a4 4 0 0 1 7.5-2"/>
            </svg>
        </div>

        <div class="card">

            <h2>Reset your password</h2>
            <p class="card-sub">We'll email you a temporary password</p>

            <?php if ($notice): ?>

                <div class="banner <?= $noticeType === 'error' ? 'error' : 'info' ?>">
                    <?php if ($noticeType === 'error'): ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="9"/>
                            <line x1="12" y1="8" x2="12" y2="13"/>
                            <line x1="12" y1="16" x2="12" y2="16"/>
                        </svg>
                    <?php else: ?>
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M4 5h16v14H4z"/>
                            <path d="m4 6 8 6 8-6"/>
                        </svg>
                    <?php endif; ?>
                    <span><?= htmlspecialchars($notice, ENT_QUOTES, 'UTF-8') ?></span>
                </div>

            <?php endif; ?>

            <form method="POST" id="resetForm">

                <?= csrfField() ?>

                <div class="field">
                    <label for="ncgr_id">NCGR ID</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                            <circle cx="12" cy="7" r="4"/>
                        </svg>
                        <input
                            type="text"
                            id="ncgr_id"
                            name="ncgr_id"
                            autocomplete="username"
                            value="<?= htmlspecialchars($ncgr_id, ENT_QUOTES, 'UTF-8') ?>"
                            required
                            autofocus
                        >
                    </div>
                </div>

                <div class="field">
                    <label for="email">Email Address</label>
                    <div class="field-input">
                        <svg class="leading-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <rect x="3" y="5" width="18" height="14" rx="2"/>
                            <path d="m3 7 9 6 9-6"/>
                        </svg>
                        <input
                            type="email"
                            id="email"
                            name="email"
                            autocomplete="email"
                            value="<?= htmlspecialchars($email, ENT_QUOTES, 'UTF-8') ?>"
                            required
                        >
                    </div>
                    <p class="field-hint">Must be the address registered on your account.</p>
                </div>

                <button type="submit" class="submit" id="submitBtn">
                    <span class="spinner"></span>
                    <span>Send Temporary Password</span>
                </button>

            </form>

            <div class="divider">or</div>

            <div class="back-link">
                <a href="index.php">Back to Sign In</a>
            </div>

        </div>

    </div>

    <div class="page-footer">
        &copy; <?= date('Y') ?> InfraVault &middot; Internal Enterprise Platform &middot; All access is logged
    </div>

</div>

<script>
(function () {
    const form = document.getElementById('resetForm');
    const submitBtn = document.getElementById('submitBtn');

    form.addEventListener('submit', function () {
        submitBtn.classList.add('loading');
        submitBtn.setAttribute('disabled', 'disabled');
    });
})();
</script>

</body>
</html>
