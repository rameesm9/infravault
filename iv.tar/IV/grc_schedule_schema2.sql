DROP TABLE IF EXISTS grc_schedule_hosts;
DROP TABLE IF EXISTS grc_schedule_history;
DROP TABLE IF EXISTS grc_schedule_audit;
DROP TABLE IF EXISTS grc_schedules;

CREATE TABLE grc_schedules (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project TEXT NOT NULL,
    support_level TEXT NOT NULL,

    recurrence_interval_days INTEGER NOT NULL DEFAULT 30,

    scheduled_time TEXT NULL,
    patched_time TEXT NULL,
    next_date TEXT NULL,

    assignee_id INTEGER NULL,

    status TEXT NOT NULL DEFAULT 'Planned',

    new_kernel_version TEXT NULL,
    new_os_version TEXT NULL,

    change_request TEXT NULL,

    comments TEXT NULL,

    attachment_original_name TEXT NULL,
    attachment_stored_name TEXT NULL,
    attachment_path TEXT NULL,
    attachment_mime TEXT NULL,
    attachment_size INTEGER NULL,

    created_by INTEGER NULL,
    updated_by INTEGER NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_grc_project
ON grc_schedules(project);

CREATE INDEX idx_grc_support
ON grc_schedules(support_level);

CREATE INDEX idx_grc_assignee
ON grc_schedules(assignee_id);

CREATE INDEX idx_grc_status
ON grc_schedules(status);

CREATE INDEX idx_grc_next_date
ON grc_schedules(next_date);


CREATE TABLE grc_schedule_hosts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,
    inventory_id INTEGER NOT NULL,

    status TEXT NOT NULL DEFAULT 'Planned',

    excluded INTEGER NOT NULL DEFAULT 0,

    comment TEXT NULL,

    patched_time TEXT NULL,

    kernel_version TEXT NULL,
    os_version TEXT NULL,

    change_request TEXT NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    UNIQUE(schedule_id, inventory_id),

    FOREIGN KEY(schedule_id)
        REFERENCES grc_schedules(id)
        ON DELETE CASCADE
);

CREATE INDEX idx_grc_hosts_schedule
ON grc_schedule_hosts(schedule_id);

CREATE INDEX idx_grc_hosts_inventory
ON grc_schedule_hosts(inventory_id);

CREATE INDEX idx_grc_hosts_status
ON grc_schedule_hosts(status);


CREATE TABLE grc_schedule_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,
    inventory_id INTEGER NULL,

    patched_time TEXT NULL,

    kernel_version TEXT NULL,
    os_version TEXT NULL,

    change_request TEXT NULL,

    status TEXT NULL,

    comments TEXT NULL,

    changed_by INTEGER NULL,

    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY(schedule_id)
        REFERENCES grc_schedules(id)
        ON DELETE CASCADE
);

CREATE INDEX idx_grc_history_schedule
ON grc_schedule_history(schedule_id);

CREATE INDEX idx_grc_history_inventory
ON grc_schedule_history(inventory_id);

CREATE INDEX idx_grc_history_date
ON grc_schedule_history(created_at);


CREATE TABLE grc_schedule_audit (
    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,

    action TEXT NOT NULL,

    field_name TEXT NULL,

    old_value TEXT NULL,
    new_value TEXT NULL,

    changed_by INTEGER NULL,

    changed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_grc_audit_schedule
ON grc_schedule_audit(schedule_id);

CREATE INDEX idx_grc_audit_date
ON grc_schedule_audit(changed_at);
