<?php

require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('patch', 'can_view');


$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);

$userTeamStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userTeamStmt->execute([$current_user_id]);
$current_user_team = (string) ($userTeamStmt->fetchColumn() ?: '');

/*
|--------------------------------------------------------------------------
| Role Permissions (page_key 'patch' -- already registered in
| permission.php as "Exception Register")
|--------------------------------------------------------------------------
*/

$canView   = hasRolePermission($pdo, $role, 'patch', 'can_view');
$canEdit   = hasRolePermission($pdo, $role, 'patch', 'can_edit');
$canDelete = hasRolePermission($pdo, $role, 'patch', 'can_delete');
$canExport = hasRolePermission($pdo, $role, 'patch', 'can_export');
$canImport = hasRolePermission($pdo, $role, 'patch', 'can_import');
$canAudit  = hasRolePermission($pdo, $role, 'patch', 'can_audit');

if (!$is_admin && !$canView) {
    http_response_code(403);
    exit('You do not have permission to view the Exception Register.');
}

$current_user_name = $_SESSION['name'] ?? 'Unknown User';


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


function redirect_patch($id = null): void
{
    if ($id !== null) {
        header(
            'Location: patch.php?view=' . (int) $id
        );
    } else {
        header('Location: patch.php');
    }

    exit;
}


function log_exception_audit(
    PDO $pdo,
    int $exception_id,
    string $action,
    int $user_id,
    string $user_name,
    string $details = ''
): void {
    try {
        $pdo->prepare("
            INSERT INTO patch_exception_audit
                (exception_id, action, performed_by_id, user_name, details, action_date)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ")->execute([$exception_id, strtoupper($action), $user_id, $user_name, $details]);
    } catch (Throwable $e) {
        error_log('Unable to log exception audit entry: ' . $e->getMessage());
    }
}


function exception_sort_link(string $column, string $label, string $current_sort, string $current_order, array $baseParams): string
{
    $nextOrder = ($current_sort === $column && $current_order === 'ASC') ? 'DESC' : 'ASC';
    $params = array_merge($baseParams, ['sort_by' => $column, 'sort_order' => $nextOrder]);
    $arrow = $current_sort === $column ? ($current_order === 'ASC' ? ' &#9650;' : ' &#9660;') : '';

    return '<a href="patch.php?' . htmlspecialchars(http_build_query($params), ENT_QUOTES, 'UTF-8')
        . '" style="color:inherit;text-decoration:none;">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . $arrow . '</a>';
}


function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $token
        )
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| Generate Reference
|--------------------------------------------------------------------------
*/

function generate_exception_number(PDO $pdo): string
{
    $stmt = $pdo->query("
        SELECT reference_no
        FROM patch_exceptions
        ORDER BY id DESC
        LIMIT 1
    ");

    $last = $stmt->fetchColumn();

    if (!$last) {
        return 'EXC-001';
    }

    if (preg_match('/(\d+)$/', $last, $matches)) {

        $number =
            ((int) $matches[1]) + 1;

        return 'EXC-' .
            str_pad(
                $number,
                3,
                '0',
                STR_PAD_LEFT
            );
    }

    return 'EXC-001';
}


/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

/**
 * The existing visibility rule (Private/Team/Public), independent of
 * role permissions -- shared by view/edit/delete checks below so there's
 * one place that defines what "can see this record" means.
 */
function exception_visibility_match(
    array $row,
    int $user_id,
    string $user_team
): bool {
    if (($row['visibility'] ?? 'Private') === 'Public') {
        return true;
    }

    if (
        ($row['visibility'] ?? 'Private') === 'Private' &&
        ((int) $row['owner_id'] === $user_id || (int) $row['requested_by'] === $user_id)
    ) {
        return true;
    }

    if (
        ($row['visibility'] ?? '') === 'Team' &&
        $user_team !== '' &&
        $user_team === ($row['team'] ?? '')
    ) {
        return true;
    }

    return false;
}

function can_view_exception(
    PDO $pdo,
    array $row,
    int $user_id,
    string $user_team,
    string $role,
    bool $is_admin
): bool {
    if ($is_admin) {
        return true;
    }

    if (!hasRolePermission($pdo, $role, 'patch', 'can_view')) {
        return false;
    }

    return exception_visibility_match($row, $user_id, $user_team);
}

function can_edit_exception(
    PDO $pdo,
    array $row,
    int $user_id,
    string $user_team,
    string $role,
    bool $is_admin
): bool {
    if ($is_admin) {
        return true;
    }

    if (!hasRolePermission($pdo, $role, 'patch', 'can_edit')) {
        return false;
    }

    $is_owner =
        (int) $row['owner_id'] === $user_id ||
        (int) $row['requested_by'] === $user_id;

    return $is_owner || exception_visibility_match($row, $user_id, $user_team);
}


function can_delete_exception(
    PDO $pdo,
    array $row,
    int $user_id,
    string $user_team,
    string $role,
    bool $is_admin
): bool {
    if ($is_admin) {
        return true;
    }

    if (!hasRolePermission($pdo, $role, 'patch', 'can_delete')) {
        return false;
    }

    return
        (int) $row['owner_id'] === $user_id ||
        (int) $row['requested_by'] === $user_id;
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

function process_exception_attachments(
    PDO $pdo,
    string $upload_dir,
    int $exception_id,
    int $user_id
): void {

    if (
        empty($_FILES['attachments']) ||
        empty($_FILES['attachments']['name'][0])
    ) {
        return;
    }


    if (!is_dir($upload_dir)) {

        if (!mkdir(
            $upload_dir,
            0755,
            true
        ) && !is_dir($upload_dir)) {
            return;
        }
    }


    $allowed = [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'csv',
        'ppt',
        'pptx',
        'txt',
        'png',
        'jpg',
        'jpeg',
        'gif',
        'webp',
        'zip'
    ];


    $count =
        count($_FILES['attachments']['name']);


    for ($i = 0; $i < $count; $i++) {

        if (
            !isset(
                $_FILES['attachments']['error'][$i]
            ) ||
            $_FILES['attachments']['error'][$i]
                !== UPLOAD_ERR_OK
        ) {
            continue;
        }


        $original =
            basename(
                $_FILES['attachments']['name'][$i]
            );


        $extension =
            strtolower(
                pathinfo(
                    $original,
                    PATHINFO_EXTENSION
                )
            );


        if (!in_array(
            $extension,
            $allowed,
            true
        )) {
            continue;
        }


        $safe_original =
            preg_replace(
                '/[^a-zA-Z0-9._-]/',
                '_',
                $original
            );


        $stored =
            bin2hex(random_bytes(12))
            . '_'
            . $safe_original;


        $destination =
            $upload_dir . '/' . $stored;


        if (
            move_uploaded_file(
                $_FILES['attachments']['tmp_name'][$i],
                $destination
            )
        ) {

            $relative =
                'uploads/patch/' . $stored;


            $mime =
                function_exists('mime_content_type')
                    ? (
                        mime_content_type($destination)
                        ?: 'application/octet-stream'
                    )
                    : 'application/octet-stream';


            $file_size =
                is_file($destination)
                    ? filesize($destination)
                    : 0;


            $stmt = $pdo->prepare("
                INSERT INTO patch_exception_attachments
                (
                    exception_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size,
                    uploaded_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");


            $stmt->execute([
                $exception_id,
                $original,
                $stored,
                $relative,
                $mime,
                $file_size,
                $user_id
            ]);
        }
    }
}


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['patch_success'] ?? '';

$error_msg =
    $_SESSION['patch_error'] ?? '';

unset(
    $_SESSION['patch_success'],
    $_SESSION['patch_error']
);


$upload_dir =
    __DIR__ . '/uploads/patch';


/*
|--------------------------------------------------------------------------
| ACTION
|--------------------------------------------------------------------------
*/

$action =
    $_GET['action'] ?? 'list';

if (isset($_GET['view'])) {
    $action = 'view';
}


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $form_action =
        $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE EXCEPTION
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'save_exception') {

        $id =
            (int) ($_POST['exception_id'] ?? 0);


        $title =
            trim($_POST['title'] ?? '');


        $exception_type =
            trim($_POST['exception_type'] ?? '');


        $short_description =
            trim($_POST['short_description'] ?? '');


        $system_name =
            trim($_POST['system_name'] ?? '');


        $application_name =
            trim($_POST['application_name'] ?? '');


        $current_version =
            trim($_POST['current_version'] ?? '');


        $target_version =
            trim($_POST['target_version'] ?? '');


        $reason =
            trim($_POST['reason'] ?? '');


        $risk_description =
            trim($_POST['risk_description'] ?? '');


        $mitigation =
            trim($_POST['mitigation'] ?? '');


        $additional_details =
            trim($_POST['additional_details'] ?? '');


        $visibility =
            trim(
                $_POST['visibility']
                ?? 'Private'
            );


        $start_date =
            trim($_POST['start_date'] ?? '');


        $expiry_date =
            trim($_POST['expiry_date'] ?? '');


        $team =
            trim($_POST['team'] ?? '');


        $after_save =
            $_POST['after_save'] ?? '';


        /*
        |--------------------------------------------------------------------------
        | Validation
        |--------------------------------------------------------------------------
        */

        if ($title === '') {

            $_SESSION['patch_error'] =
                'Title is required.';

            redirect_patch(
                $id ?: null
            );
        }


        if (!in_array(
            $exception_type,
            [
                'Patch Exception',
                'Upgrade Exception',
                'Control Fix Exception'
            ],
            true
        )) {

            $_SESSION['patch_error'] =
                'Invalid exception type.';

            redirect_patch(
                $id ?: null
            );
        }


        if (!in_array(
            $visibility,
            [
                'Private',
                'Team',
                'Public'
            ],
            true
        )) {

            $visibility =
                'Private';
        }


        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($id === 0) {

            $reference_no =
                generate_exception_number(
                    $pdo
                );


            /*
            | New records always start at 1.0
            */

            $version =
                '1.0';


            $owner_id =
                $current_user_id;


            /*
            | Admin can select owner
            */

            if ($is_admin) {

                $posted_owner =
                    (int) (
                        $_POST['owner_id']
                        ?? 0
                    );

                if ($posted_owner > 0) {
                    $owner_id =
                        $posted_owner;
                }
            }


            /*
            | Status
            */

            $status =
                $after_save === 'submit'
                    ? 'Pending Review'
                    : 'Draft';


            /*
            |--------------------------------------------------------------------------
            | Insert Main Exception
            |--------------------------------------------------------------------------
            */

            $stmt = $pdo->prepare("
                INSERT INTO patch_exceptions
                (
                    reference_no,
                    title,
                    exception_type,
                    version,
                    short_description,
                    system_name,
                    application_name,
                    current_version,
                    target_version,
                    reason,
                    risk_description,
                    mitigation,
                    owner_id,
                    team,
                    visibility,
                    start_date,
                    expiry_date,
                    status,
                    requested_by,
                    additional_details,
                    created_at,
                    updated_at
                )
                VALUES
                (
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    ?, ?, ?, ?,
                    CURRENT_TIMESTAMP,
                    CURRENT_TIMESTAMP
                )
            ");


            $stmt->execute([
                $reference_no,
                $title,
                $exception_type,
                $version,
                $short_description,
                $system_name,
                $application_name,
                $current_version,
                $target_version,
                $reason,
                $risk_description,
                $mitigation,
                $owner_id,
                $team,
                $visibility,
                $start_date ?: null,
                $expiry_date ?: null,
                $status,
                $current_user_id,
                $additional_details
            ]);


            /*
            |--------------------------------------------------------------------------
            | Get New ID
            |--------------------------------------------------------------------------
            */

            $id =
                (int) $pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | Initial Revision
            |--------------------------------------------------------------------------
            */

            $revision = $pdo->prepare("
                INSERT INTO patch_exception_revisions
                (
                    exception_id,
                    version,
                    title,
                    exception_type,
                    short_description,
                    system_name,
                    application_name,
                    current_version,
                    target_version,
                    reason,
                    risk_description,
                    mitigation,
                    owner_id,
                    team,
                    visibility,
                    start_date,
                    expiry_date,
                    status,
                    additional_details,
                    changed_by,
                    change_summary
                )
                VALUES
                (
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?,
                    ?, ?, ?, ?, ?, ?
                )
            ");


            $revision->execute([
                $id,
                $version,
                $title,
                $exception_type,
                $short_description,
                $system_name,
                $application_name,
                $current_version,
                $target_version,
                $reason,
                $risk_description,
                $mitigation,
                $owner_id,
                $team,
                $visibility,
                $start_date ?: null,
                $expiry_date ?: null,
                $status,
                $additional_details,
                $current_user_id,
                'Initial exception created'
            ]);


            /*
            |--------------------------------------------------------------------------
            | Attachments
            |--------------------------------------------------------------------------
            */

            process_exception_attachments(
                $pdo,
                $upload_dir,
                $id,
                $current_user_id
            );

            log_exception_audit(
                $pdo,
                $id,
                'CREATED',
                $current_user_id,
                $current_user_name,
                "Created exception: $title (status: $status)"
            );


            /*
            |--------------------------------------------------------------------------
            | Success
            |--------------------------------------------------------------------------
            */

            $_SESSION['patch_success'] =
                $status === 'Pending Review'
                    ? 'Exception created and submitted for Admin review.'
                    : 'Exception created successfully.';


            redirect_patch($id);
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE EXISTING EXCEPTION
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $id
        ]);


        $existing =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$existing) {

            $_SESSION['patch_error'] =
                'Exception not found.';

            redirect_patch();
        }


        /*
        |--------------------------------------------------------------------------
        | Permission
        |--------------------------------------------------------------------------
        */

        if (!can_edit_exception(
            $pdo,
            $existing,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Determine Next Revision Version
        |--------------------------------------------------------------------------
        */

        $revision_stmt = $pdo->prepare("
            SELECT version
            FROM patch_exception_revisions
            WHERE exception_id = ?
            ORDER BY id DESC
            LIMIT 1
        ");

        $revision_stmt->execute([
            $id
        ]);


        $old_version =
            $revision_stmt->fetchColumn();


        if (!$old_version) {

            $old_version =
                $existing['version']
                ?? '1.0';
        }


        $version_parts =
            explode(
                '.',
                $old_version
            );


        $major =
            (int) (
                $version_parts[0]
                ?? 1
            );


        $minor =
            (int) (
                $version_parts[1]
                ?? 0
            );


        $new_version =
            $major .
            '.' .
            ($minor + 1);


        /*
        |--------------------------------------------------------------------------
        | Determine Status
        |--------------------------------------------------------------------------
        */

        $status =
            $after_save === 'submit'
                ? 'Pending Review'
                : 'Draft';


        /*
        |--------------------------------------------------------------------------
        | Owner
        |--------------------------------------------------------------------------
        */

        $owner_id =
            (int) $existing['owner_id'];


        if ($is_admin) {

            $posted_owner =
                (int) (
                    $_POST['owner_id']
                    ?? 0
                );

            if ($posted_owner > 0) {
                $owner_id =
                    $posted_owner;
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Update Main Exception
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            UPDATE patch_exceptions
            SET
                title = ?,
                exception_type = ?,
                version = ?,
                short_description = ?,
                system_name = ?,
                application_name = ?,
                current_version = ?,
                target_version = ?,
                reason = ?,
                risk_description = ?,
                mitigation = ?,
                owner_id = ?,
                team = ?,
                visibility = ?,
                start_date = ?,
                expiry_date = ?,
                status = ?,
                rejection_reason = NULL,
                review_comment = '',
                additional_details = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");


        $stmt->execute([
            $title,
            $exception_type,
            $new_version,
            $short_description,
            $system_name,
            $application_name,
            $current_version,
            $target_version,
            $reason,
            $risk_description,
            $mitigation,
            $owner_id,
            $team,
            $visibility,
            $start_date ?: null,
            $expiry_date ?: null,
            $status,
            $additional_details,
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Create Revision
        |--------------------------------------------------------------------------
        */

        $revision = $pdo->prepare("
            INSERT INTO patch_exception_revisions
            (
                exception_id,
                version,
                title,
                exception_type,
                short_description,
                system_name,
                application_name,
                current_version,
                target_version,
                reason,
                risk_description,
                mitigation,
                owner_id,
                team,
                visibility,
                start_date,
                expiry_date,
                status,
                additional_details,
                changed_by,
                change_summary
            )
            VALUES
            (
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?,
                ?, ?, ?, ?, ?, ?
            )
        ");


        $revision->execute([
            $id,
            $new_version,
            $title,
            $exception_type,
            $short_description,
            $system_name,
            $application_name,
            $current_version,
            $target_version,
            $reason,
            $risk_description,
            $mitigation,
            $owner_id,
            $team,
            $visibility,
            $start_date ?: null,
            $expiry_date ?: null,
            $status,
            $additional_details,
            $current_user_id,
            'Exception updated'
        ]);


        /*
        |--------------------------------------------------------------------------
        | Attachments
        |--------------------------------------------------------------------------
        */

        process_exception_attachments(
            $pdo,
            $upload_dir,
            $id,
            $current_user_id
        );

        log_exception_audit(
            $pdo,
            $id,
            'EDITED',
            $current_user_id,
            $current_user_name,
            "Updated exception: $title (version $new_version, status: $status)"
        );


        /*
        |--------------------------------------------------------------------------
        | Success
        |--------------------------------------------------------------------------
        */

        $_SESSION['patch_success'] =
            $status === 'Pending Review'
                ? 'Exception updated and submitted for Admin review.'
                : 'Exception updated successfully.';


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | SUBMIT FOR REVIEW
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'submit_review') {

        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);


        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$row) {

            $_SESSION['patch_error'] =
                'Exception not found.';

            redirect_patch();
        }


        if (!can_edit_exception(
            $pdo,
            $row,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }


        $stmt = $pdo->prepare("
            UPDATE patch_exceptions
            SET
                status = 'Pending Review',
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);

        log_exception_audit(
            $pdo,
            $id,
            'SUBMITTED',
            $current_user_id,
            $current_user_name,
            'Submitted for Admin review'
        );

        $_SESSION['patch_success'] =
            'Exception submitted for Admin review.';


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | ADMIN REVIEW
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'review_exception') {

        if (!$is_admin) {

            http_response_code(403);

            exit(
                'Admin privileges required.'
            );
        }


        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $decision =
            $_POST['decision']
            ?? '';


        $comment =
            trim(
                $_POST['review_comment']
                ?? ''
            );


        /*
        |--------------------------------------------------------------------------
        | APPROVE
        |--------------------------------------------------------------------------
        */

        if ($decision === 'approve') {

            $stmt = $pdo->prepare("
                UPDATE patch_exceptions
                SET
                    status = 'Approved',
                    approved_by = ?,
                    approved_at = CURRENT_TIMESTAMP,
                    review_comment = ?,
                    rejection_reason = NULL,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");


            $stmt->execute([
                $current_user_id,
                $comment,
                $id
            ]);

            log_exception_audit(
                $pdo,
                $id,
                'APPROVED',
                $current_user_id,
                $current_user_name,
                $comment !== '' ? "Approved: $comment" : 'Approved'
            );

            $_SESSION['patch_success'] =
                'Exception approved successfully.';
        }


        /*
        |--------------------------------------------------------------------------
        | REJECT
        |--------------------------------------------------------------------------
        */

        elseif ($decision === 'reject') {

            if ($comment === '') {

                $_SESSION['patch_error'] =
                    'Please provide a rejection reason.';

                redirect_patch($id);
            }


            $stmt = $pdo->prepare("
                UPDATE patch_exceptions
                SET
                    status = 'Rejected',
                    review_comment = ?,
                    rejection_reason = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
                  AND status = 'Pending Review'
            ");


            $stmt->execute([
                $comment,
                $comment,
                $id
            ]);

            log_exception_audit(
                $pdo,
                $id,
                'REJECTED',
                $current_user_id,
                $current_user_name,
                "Rejected: $comment"
            );

            $_SESSION['patch_success'] =
                'Exception rejected.';
        }


        redirect_patch($id);
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($form_action === 'delete_exception') {

        $id =
            (int) (
                $_POST['exception_id']
                ?? 0
            );


        $stmt = $pdo->prepare("
            SELECT *
            FROM patch_exceptions
            WHERE id = ?
        ");


        $stmt->execute([
            $id
        ]);


        $row =
            $stmt->fetch(
                PDO::FETCH_ASSOC
            );


        if (!$row) {
            redirect_patch();
        }


        if (!can_delete_exception(
            $pdo,
            $row,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'Permission denied.'
            );
        }

        // Logged before the DELETE below so the reference/title are still
        // available -- the audit row itself isn't cascade-removed (no
        // enforced FK on this connection, see config/db.php).
        log_exception_audit(
            $pdo,
            $id,
            'DELETED',
            $current_user_id,
            $current_user_name,
            'Deleted exception: ' . ($row['reference_no'] ?? '') . ' - ' . ($row['title'] ?? '')
        );


        /*
        |--------------------------------------------------------------------------
        | Delete Physical Files
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT file_path
            FROM patch_exception_attachments
            WHERE exception_id = ?
        ");


        $stmt->execute([
            $id
        ]);


        foreach (
            $stmt->fetchAll(
                PDO::FETCH_ASSOC
            ) as $file
        ) {

            $path =
                __DIR__ . '/' .
                ltrim(
                    $file['file_path'],
                    '/\\'
                );


            if (is_file($path)) {
                @unlink($path);
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Delete Attachments
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exception_attachments
            WHERE exception_id = ?
        ")->execute([
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Delete Revisions
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exception_revisions
            WHERE exception_id = ?
        ")->execute([
            $id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Delete Exception
        |--------------------------------------------------------------------------
        */

        $pdo->prepare("
            DELETE FROM patch_exceptions
            WHERE id = ?
        ")->execute([
            $id
        ]);


        $_SESSION['patch_success'] =
            'Exception deleted successfully.';


        redirect_patch();
    }
}


/*
|--------------------------------------------------------------------------
| File Download
|--------------------------------------------------------------------------
*/

if ($action === 'file') {

    $id =
        (int) (
            $_GET['id']
            ?? 0
        );


    $stmt = $pdo->prepare("
        SELECT *
        FROM patch_exception_attachments
        WHERE id = ?
    ");


    $stmt->execute([
        $id
    ]);


    $file =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$file) {

        http_response_code(404);

        exit(
            'File not found.'
        );
    }


    $path =
        __DIR__ . '/' .
        ltrim(
            $file['file_path'],
            '/\\'
        );


    if (!is_file($path)) {

        http_response_code(404);

        exit(
            'File not found.'
        );
    }


    header(
        'Content-Type: ' .
        (
            $file['mime_type']
            ?: 'application/octet-stream'
        )
    );


    header(
        'Content-Length: ' .
        filesize($path)
    );


    header(
        'Content-Disposition: attachment; filename="' .
        basename(
            $file['original_name']
        ) .
        '"'
    );


    header(
        'X-Content-Type-Options: nosniff'
    );


    readfile($path);

    exit;
}


/*
|--------------------------------------------------------------------------
| Shared list filter -- one place building the WHERE clause so the CSV
| export always matches exactly what's currently searched/visible on the
| list page, instead of two copies of this logic drifting apart.
|--------------------------------------------------------------------------
*/

function build_exception_filter(
    int $user_id,
    string $user_team,
    bool $is_admin,
    string $keyword,
    string $advanced_search
): array {
    $where = [];
    $params = [];

    if (!$is_admin) {
        $where[] = "(
            e.visibility = 'Public'
            OR (e.visibility = 'Private' AND (e.owner_id = ? OR e.requested_by = ?))
            OR (e.visibility = 'Team' AND e.team = ?)
        )";
        array_push($params, $user_id, $user_id, $user_team);
    }

    if ($advanced_search !== '') {
        $tokens = array_filter(array_map('trim', preg_split('/[\r\n,;]+/', $advanced_search)));
        $clauses = [];
        foreach ($tokens as $token) {
            if ($token === '') {
                continue;
            }
            $clauses[] = "(e.reference_no LIKE ? OR e.title LIKE ? OR e.system_name LIKE ? OR e.application_name LIKE ? OR e.team LIKE ?)";
            $w = "%$token%";
            array_push($params, $w, $w, $w, $w, $w);
        }
        if ($clauses) {
            $where[] = '(' . implode(' OR ', $clauses) . ')';
        }
    } elseif ($keyword !== '') {
        $where[] = "(e.reference_no LIKE ? OR e.title LIKE ? OR e.system_name LIKE ? OR e.application_name LIKE ? OR e.team LIKE ?)";
        $w = "%$keyword%";
        array_push($params, $w, $w, $w, $w, $w);
    }

    return [$where ? implode(' AND ', $where) : '1=1', $params];
}

$exception_sort_columns = [
    'reference_no' => 'e.reference_no',
    'title' => 'e.title',
    'exception_type' => 'e.exception_type',
    'system_name' => 'e.system_name',
    'team' => 'e.team',
    'expiry_date' => 'e.expiry_date',
    'status' => 'e.status',
    'updated_at' => 'e.updated_at',
];

$sort_by = $_GET['sort_by'] ?? 'updated_at';
if (!array_key_exists($sort_by, $exception_sort_columns)) {
    $sort_by = 'updated_at';
}
$sort_order = (strtoupper($_GET['sort_order'] ?? 'DESC') === 'ASC') ? 'ASC' : 'DESC';

$keyword = trim($_GET['keyword'] ?? '');
$advanced_search = trim($_GET['advanced_search'] ?? '');


/*
|--------------------------------------------------------------------------
| CSV Export -- mirrors whatever is currently searched (same filter
| function the list page uses), so exporting only ever exports the
| filtered/searched result set, never the whole register. No id column.
|--------------------------------------------------------------------------
*/

if ($action === 'export') {

    if (!$is_admin && !$canExport) {
        http_response_code(403);
        exit('You do not have permission to export the Exception Register.');
    }

    [$exportWhere, $exportParams] = build_exception_filter(
        $current_user_id,
        $current_user_team,
        $is_admin,
        $keyword,
        $advanced_search
    );

    $orderColumn = $exception_sort_columns[$sort_by];

    $stmt = $pdo->prepare("
        SELECT
            e.reference_no, e.title, e.exception_type, e.version, e.short_description,
            e.system_name, e.application_name, e.current_version, e.target_version,
            e.reason, e.risk_description, e.mitigation, e.team, e.visibility,
            e.start_date, e.expiry_date, e.status, e.additional_details,
            e.created_at, e.updated_at,
            owner.first_name AS owner_first, owner.last_name AS owner_last,
            creator.first_name AS creator_first, creator.last_name AS creator_last
        FROM patch_exceptions e
        LEFT JOIN users owner ON owner.id = e.owner_id
        LEFT JOIN users creator ON creator.id = e.requested_by
        WHERE $exportWhere
        ORDER BY $orderColumn $sort_order
    ");
    $stmt->execute($exportParams);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=exception_register_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');

    $header = [
        'Reference', 'Title', 'Type', 'Version', 'Short Description',
        'System', 'Application', 'Current Version', 'Target Version',
        'Reason', 'Risk Description', 'Mitigation', 'Team', 'Visibility',
        'Start Date', 'Expiry Date', 'Status', 'Additional Details',
        'Owner', 'Requested By', 'Created At', 'Updated At',
    ];
    fputcsv($output, $header);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['reference_no'], $row['title'], $row['exception_type'], $row['version'], $row['short_description'],
            $row['system_name'], $row['application_name'], $row['current_version'], $row['target_version'],
            $row['reason'], $row['risk_description'], $row['mitigation'], $row['team'], $row['visibility'],
            $row['start_date'], $row['expiry_date'], $row['status'], $row['additional_details'],
            trim(($row['owner_first'] ?? '') . ' ' . ($row['owner_last'] ?? '')),
            trim(($row['creator_first'] ?? '') . ' ' . ($row['creator_last'] ?? '')),
            $row['created_at'], $row['updated_at'],
        ]);
    }

    fclose($output);
    exit;
}


/*
|--------------------------------------------------------------------------
| Audit History (AJAX) -- action=get_history for the whole register
| (page audit), action=get_history&exception_id=N for one record (line
| audit). Mirrors the same pattern already used in inventory.php.
|--------------------------------------------------------------------------
*/

if ($action === 'get_history') {

    if (!$is_admin && !$canAudit) {
        http_response_code(403);
        echo '<p class="empty-state">You do not have permission to view audit history.</p>';
        exit;
    }

    $historyExceptionId = isset($_GET['exception_id']) ? (int) $_GET['exception_id'] : 0;

    try {
        if ($historyExceptionId > 0) {
            $histStmt = $pdo->prepare("
                SELECT * FROM patch_exception_audit WHERE exception_id = ? ORDER BY action_date DESC
            ");
            $histStmt->execute([$historyExceptionId]);
        } else {
            $histStmt = $pdo->query("
                SELECT a.*, e.reference_no
                FROM patch_exception_audit a
                LEFT JOIN patch_exceptions e ON e.id = a.exception_id
                ORDER BY a.action_date DESC
                LIMIT 200
            ");
        }
        $logs = $histStmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('Unable to load exception audit history: ' . $e->getMessage());
        $logs = [];
    }

    if (count($logs) > 0) {
        echo '<table class="audit-table"><thead><tr>';
        if ($historyExceptionId === 0) {
            echo '<th>Reference</th>';
        }
        echo '<th>Action</th><th>User</th><th>Details</th><th>Timestamp</th></tr></thead><tbody>';
        foreach ($logs as $l) {
            echo '<tr>';
            if ($historyExceptionId === 0) {
                echo '<td>' . h($l['reference_no'] ?? '') . '</td>';
            }
            $detailsHtml = nl2br(h((string) ($l['details'] ?? '')));
            echo '<td><strong>' . h($l['action'] ?? '') . '</strong></td>';
            echo '<td>' . h($l['user_name'] ?? '') . '</td>';
            echo '<td class="audit-details">' . $detailsHtml . '</td>';
            echo '<td>' . h($l['action_date'] ?? '') . '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p class="empty-state">' . ($historyExceptionId > 0 ? 'No history recorded for this exception.' : 'No audit history recorded yet.') . '</p>';
    }
    exit;
}


/*
|--------------------------------------------------------------------------
| Load Selected Exception
|--------------------------------------------------------------------------
*/

$exception = null;


if (
    $action === 'view' ||
    $action === 'edit'
) {

    $id =
        (int) (
            $_GET['view']
            ?? $_GET['id']
            ?? 0
        );


    $stmt = $pdo->prepare("
        SELECT
            e.*,

            owner.first_name AS owner_first,
            owner.last_name AS owner_last,
            owner.email AS owner_email,

            creator.first_name AS creator_first,
            creator.last_name AS creator_last,

            approver.first_name AS approver_first,
            approver.last_name AS approver_last

        FROM patch_exceptions e

        LEFT JOIN users owner
            ON owner.id = e.owner_id

        LEFT JOIN users creator
            ON creator.id = e.requested_by

        LEFT JOIN users approver
            ON approver.id = e.approved_by

        WHERE e.id = ?

        LIMIT 1
    ");


    $stmt->execute([
        $id
    ]);


    $exception =
        $stmt->fetch(
            PDO::FETCH_ASSOC
        );


    if (!$exception) {

        $_SESSION['patch_error'] =
            'Exception not found.';

        redirect_patch();
    }


    /*
    |--------------------------------------------------------------------------
    | Security For Private / Team Data
    |--------------------------------------------------------------------------
    */

    $can_access =
        false;


    if ($is_admin) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Public'
    ) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Private' &&
        (
            (int) $exception['owner_id']
                === $current_user_id
            ||
            (int) $exception['requested_by']
                === $current_user_id
        )
    ) {

        $can_access =
            true;
    }


    elseif (
        $exception['visibility']
        === 'Team'
    ) {

        $stmt =
            $pdo->prepare("
                SELECT team
                FROM users
                WHERE id = ?
                LIMIT 1
            ");


        $stmt->execute([
            $current_user_id
        ]);


        $my_team =
            $stmt->fetchColumn();


        if (
            $my_team &&
            $my_team === $exception['team']
        ) {

            $can_access =
                true;
        }
    }


    if (!$can_access) {

        http_response_code(403);

        exit(
            'You do not have permission to view this exception.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

$attachments = [];


if ($exception) {

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            u.first_name,
            u.last_name
        FROM patch_exception_attachments a

        LEFT JOIN users u
            ON u.id = a.uploaded_by

        WHERE a.exception_id = ?

        ORDER BY a.created_at DESC
    ");


    $stmt->execute([
        $exception['id']
    ]);


    $attachments =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
}


/*
|--------------------------------------------------------------------------
| Teams
|--------------------------------------------------------------------------
*/

$teams_stmt = $pdo->query("
    SELECT DISTINCT team
    FROM users
    WHERE team IS NOT NULL
      AND TRIM(team) <> ''
    ORDER BY team
");


$teams =
    $teams_stmt->fetchAll(
        PDO::FETCH_COLUMN
    );


/*
|--------------------------------------------------------------------------
| Users
|--------------------------------------------------------------------------
*/

$users = [];


if ($is_admin) {

    $stmt = $pdo->query("
        SELECT
            id,
            first_name,
            last_name,
            email,
            team
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name, last_name
    ");


    $users =
        $stmt->fetchAll(
            PDO::FETCH_ASSOC
        );
}


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT status, COUNT(*) total
    FROM patch_exceptions
    GROUP BY status
");


$stats = [];


foreach (
    $stmt->fetchAll(
        PDO::FETCH_ASSOC
    ) as $row
) {

    $stats[$row['status']] =
        (int) $row['total'];
}


$total =
    array_sum($stats);


$draft =
    $stats['Draft'] ?? 0;


$pending =
    $stats['Pending Review'] ?? 0;


$approved =
    $stats['Approved'] ?? 0;


$active =
    $stats['Active'] ?? 0;


$rejected =
    $stats['Rejected'] ?? 0;


$expired =
    $stats['Expired'] ?? 0;


$page_title =
    'Patch & Exception Register';


require_once 'includes/header.php';
require_once 'includes/sidebar.php';

?>


<link
    rel="stylesheet"
    href="assets/css/sop.css"
>


<style>

.exception-content {
    padding-bottom: 50px;
}

.exception-header {
    display:flex;
    justify-content:space-between;
    align-items:center;
    gap:20px;
    margin-bottom:25px;
}

.exception-header h1 {
    margin:0;
}

.exception-header p {
    margin:5px 0 0;
    color:#777;
}

.exception-stats {
    display:grid;
    grid-template-columns:
        repeat(6, minmax(120px, 1fr));
    gap:14px;
    margin-bottom:25px;
}

.exception-stat {
    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:10px;
    padding:18px;
}

.exception-stat span {
    display:block;
    color:#777;
    font-size:13px;
}

.exception-stat strong {
    display:block;
    font-size:26px;
    margin-top:5px;
}

.exception-panel {
    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:10px;
    padding:20px;
}

.exception-toolbar {
    display:flex;
    justify-content:space-between;
    gap:15px;
    margin-bottom:20px;
}

.exception-search {
    width:300px;
    padding:10px 12px;
    border:1px solid var(--input-border);
    border-radius:7px;
    background: var(--input-bg);
    color: var(--text-primary);
}

.exception-table {
    width:100%;
    border-collapse:collapse;
}

.exception-table th,
.exception-table td {
    padding:12px;
    border-bottom:1px solid #eee;
    text-align:left;
    vertical-align:middle;
}

.exception-table th {
    font-size:12px;
    color:#666;
    text-transform:uppercase;
}

.exception-reference {
    font-weight:700;
    color:#2563eb;
}

.exception-title {
    font-weight:600;
    color:var(--text-primary);
}

.exception-type {
    font-size:12px;
    padding:5px 8px;
    border-radius:5px;
    background:#eef2ff;
}

.exception-status {
    display:inline-block;
    padding:5px 9px;
    border-radius:20px;
    font-size:12px;
    font-weight:600;
}

.status-draft {
    background:var(--hover-bg);
    color:var(--text-secondary);
}

.status-pending-review {
    background:#fff7ed;
    color:#c2410c;
}

.status-approved {
    background:#ecfdf5;
    color:#047857;
}

.status-active {
    background:#dbeafe;
    color:#1d4ed8;
}

.status-rejected {
    background:#fef2f2;
    color:#b91c1c;
}

.status-expired {
    background:var(--hover-bg);
    color:var(--text-secondary);
}

.exception-actions {
    display:flex;
    gap:8px;
    align-items:center;
}

.exception-actions a,
.exception-actions button {
    border:0;
    background:none;
    cursor:pointer;
    color:#2563eb;
    padding:0;
}

.exception-actions .delete {
    color:#dc2626;
}

.exception-form {
    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:10px;
    padding:25px;
}

.exception-grid {
    display:grid;
    grid-template-columns:
        repeat(2, minmax(0, 1fr));
    gap:18px;
}

.exception-field {
    display:flex;
    flex-direction:column;
    gap:7px;
}

.exception-field.full {
    grid-column:1 / -1;
}

.exception-field label {
    font-weight:600;
    font-size:14px;
}

.exception-field input,
.exception-field select,
.exception-field textarea {
    width:100%;
    box-sizing:border-box;
    border:1px solid #d1d5db;
    border-radius:7px;
    padding:10px 12px;
    font:inherit;
}

.exception-field textarea {
    min-height:120px;
    resize:vertical;
}

.exception-document {
    background:var(--bg-content);
    border:1px solid var(--border-color);
    border-radius:10px;
    padding:30px;
}

.exception-document-header {
    display:flex;
    justify-content:space-between;
    gap:20px;
    border-bottom:1px solid #eee;
    padding-bottom:20px;
    margin-bottom:25px;
}

.exception-document h1 {
    margin:5px 0;
}

.exception-reference-large {
    color:#2563eb;
    font-weight:700;
}

.exception-meta {
    display:grid;
    grid-template-columns:
        repeat(4, minmax(0, 1fr));
    gap:15px;
    margin-bottom:30px;
}

.exception-meta div {
    background:var(--hover-bg);
    padding:13px;
    border-radius:8px;
}

.exception-meta span {
    display:block;
    font-size:11px;
    color:var(--text-secondary);
    margin-bottom:5px;
}

.exception-section {
    margin-top:30px;
}

.exception-section h2 {
    font-size:18px;
    margin-bottom:10px;
}

.exception-risk {
    background:#fff7ed;
    border-left:4px solid #f97316;
    padding:15px;
}

.exception-mitigation {
    background:#ecfdf5;
    border-left:4px solid #10b981;
    padding:15px;
}

.exception-attachments {
    display:flex;
    flex-direction:column;
    gap:8px;
}

.exception-attachment {
    padding:10px 12px;
    background:var(--hover-bg);
    border:1px solid var(--border-color);
    border-radius:7px;
}

.exception-review {
    margin-top:30px;
    background:var(--hover-bg);
    border:1px solid var(--border-color);
    border-radius:8px;
    padding:20px;
}

.exception-review textarea {
    width:100%;
    min-height:100px;
    margin-bottom:15px;
}

@media(max-width:1000px) {

    .exception-stats {
        grid-template-columns:
            repeat(3, 1fr);
    }

    .exception-meta {
        grid-template-columns:
            repeat(2, 1fr);
    }
}

@media(max-width:700px) {

    .exception-grid,
    .exception-stats,
    .exception-meta {
        grid-template-columns:1fr;
    }

    .exception-header,
    .exception-toolbar,
    .exception-document-header {
        flex-direction:column;
        align-items:stretch;
    }

    .exception-search {
        width:100%;
    }
}

</style>


<div class="content exception-content">


<?php if ($success_msg): ?>

    <div class="sop-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="sop-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<?php

/*
|--------------------------------------------------------------------------
| CREATE / EDIT
|--------------------------------------------------------------------------
*/

if (
    $action === 'create' ||
    $action === 'edit'
):


    $editing =
        $action === 'edit';


    if (
        $editing &&
        !$exception
    ) {

        $_SESSION['patch_error'] =
            'Exception not found.';

        redirect_patch();
    }


    if (
        $editing &&
        !can_edit_exception(
            $pdo,
            $exception,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        )
    ) {

        http_response_code(403);

        exit(
            'Permission denied.'
        );
    }


    $form =
        $exception ?: [];

?>


<div class="exception-header">

    <div>

        <h1>

            <?= $editing
                ? 'Edit Exception'
                : 'New Patch / Upgrade Exception'
            ?>

        </h1>

        <p>
            Record patching, upgrade and control-fix exceptions.
        </p>

    </div>


    <a
        href="patch.php"
        class="sop-secondary-btn"
    >
        Back to Register
    </a>

</div>


<form
    method="POST"
    action="patch.php"
    enctype="multipart/form-data"
    class="exception-form"
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?= h($csrf_token) ?>"
    >


    <input
        type="hidden"
        name="form_action"
        value="save_exception"
    >


    <input
        type="hidden"
        name="exception_id"
        value="<?= (int) (
            $form['id'] ?? 0
        ) ?>"
    >


    <div class="exception-grid">


        <div class="exception-field">

            <label>
                Reference
            </label>

            <input
                type="text"
                readonly
                value="<?= h(
                    $form['reference_no']
                    ?? generate_exception_number($pdo)
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Type *
            </label>

            <select
                name="exception_type"
                required
            >

                <?php foreach ([
                    'Patch Exception',
                    'Upgrade Exception',
                    'Control Fix Exception'
                ] as $type): ?>

                    <option
                        value="<?= h($type) ?>"
                        <?= (
                            $form['exception_type']
                            ?? 'Patch Exception'
                        ) === $type
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($type) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field full">

            <label>
                Title *
            </label>

            <input
                type="text"
                name="title"
                required
                value="<?= h(
                    $form['title'] ?? ''
                ) ?>"
                placeholder="Example: RHEL 9.4 production patch exception"
            >

        </div>


        <div class="exception-field full">

            <label>
                Short Description
            </label>

            <textarea
                name="short_description"
                placeholder="Brief description of the exception."
            ><?= h(
                $form['short_description'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field">

            <label>
                System / Host
            </label>

            <input
                type="text"
                name="system_name"
                value="<?= h(
                    $form['system_name'] ?? ''
                ) ?>"
                placeholder="Server / cluster / platform"
            >

        </div>


        <div class="exception-field">

            <label>
                Application
            </label>

            <input
                type="text"
                name="application_name"
                value="<?= h(
                    $form['application_name'] ?? ''
                ) ?>"
                placeholder="Application / service"
            >

        </div>


        <div class="exception-field">

            <label>
                Current Version
            </label>

            <input
                type="text"
                name="current_version"
                value="<?= h(
                    $form['current_version'] ?? ''
                ) ?>"
                placeholder="Current version"
            >

        </div>


        <div class="exception-field">

            <label>
                Target Version
            </label>

            <input
                type="text"
                name="target_version"
                value="<?= h(
                    $form['target_version'] ?? ''
                ) ?>"
                placeholder="Required / target version"
            >

        </div>


        <div class="exception-field full">

            <label>
                Reason / Justification
            </label>

            <textarea
                name="reason"
                placeholder="Why can the patch, upgrade or control fix not be completed?"
            ><?= h(
                $form['reason'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Risk Description
            </label>

            <textarea
                name="risk_description"
                placeholder="Describe the risk created by this exception."
            ><?= h(
                $form['risk_description'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Mitigation / Compensating Control
            </label>

            <textarea
                name="mitigation"
                placeholder="What temporary or compensating control is being used?"
            ><?= h(
                $form['mitigation'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field">

            <label>
                Team
            </label>

            <select name="team">

                <option value="">
                    Select Team
                </option>


                <?php foreach (
                    $teams
                    as $team
                ): ?>

                    <option
                        value="<?= h($team) ?>"
                        <?= (
                            $form['team'] ?? ''
                        ) === $team
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($team) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field">

            <label>
                Owner
            </label>


            <?php if ($is_admin): ?>

                <select name="owner_id">

                    <?php foreach (
                        $users
                        as $user
                    ): ?>

                        <option
                            value="<?= (int) $user['id'] ?>"
                            <?= (int) (
                                $form['owner_id']
                                ?? $current_user_id
                            )
                            === (int) $user['id']
                                ? 'selected'
                                : ''
                            ?>
                        >

                            <?= h(
                                trim(
                                    $user['first_name']
                                    . ' '
                                    . $user['last_name']
                                )
                            ) ?>

                        </option>

                    <?php endforeach; ?>

                </select>

            <?php else: ?>

                <input
                    type="text"
                    readonly
                    value="Current User"
                >

            <?php endif; ?>

        </div>


        <div class="exception-field">

            <label>
                Start Date
            </label>

            <input
                type="date"
                name="start_date"
                value="<?= h(
                    $form['start_date'] ?? ''
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Expiry Date
            </label>

            <input
                type="date"
                name="expiry_date"
                value="<?= h(
                    $form['expiry_date'] ?? ''
                ) ?>"
            >

        </div>


        <div class="exception-field">

            <label>
                Visibility
            </label>

            <select name="visibility">

                <?php foreach ([
                    'Private',
                    'Team',
                    'Public'
                ] as $visibility): ?>

                    <option
                        value="<?= h($visibility) ?>"
                        <?= (
                            $form['visibility']
                            ?? 'Private'
                        ) === $visibility
                            ? 'selected'
                            : ''
                        ?>
                    >
                        <?= h($visibility) ?>
                    </option>

                <?php endforeach; ?>

            </select>

        </div>


        <div class="exception-field full">

            <label>
                Additional Details
            </label>

            <textarea
                name="additional_details"
                placeholder="Additional technical or operational information."
            ><?= h(
                $form['additional_details'] ?? ''
            ) ?></textarea>

        </div>


        <div class="exception-field full">

            <label>
                Attachments
            </label>

            <input
                type="file"
                name="attachments[]"
                multiple
            >

            <small>
                Supporting evidence, change records,
                screenshots, vendor documents, etc.
            </small>

        </div>

    </div>


    <div
        class="sop-form-actions"
        style="margin-top:25px;"
    >

        <a
            href="patch.php"
            class="sop-secondary-btn"
        >
            Cancel
        </a>


        <button
            type="submit"
            class="sop-secondary-btn"
        >
            Save Draft
        </button>


        <button
            type="submit"
            name="after_save"
            value="submit"
            class="sop-primary-btn"
        >
            Save & Submit for Review
        </button>

    </div>

</form>


<?php

/*
|--------------------------------------------------------------------------
| VIEW
|--------------------------------------------------------------------------
*/

elseif (
    $action === 'view' &&
    $exception
):


    $can_edit =
        can_edit_exception(
            $pdo,
            $exception,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        );

?>


<div class="exception-header">

    <div>

        <h1>
            Patch & Exception Register
        </h1>

        <p>
            Review exception details and supporting evidence.
        </p>

    </div>


    <div
        style="display:flex;gap:8px;"
    >

        <a
            href="patch.php"
            class="sop-secondary-btn"
        >
            Back
        </a>


        <?php if ($can_edit): ?>

            <a
                href="patch.php?action=edit&id=<?= (int) $exception['id'] ?>"
                class="sop-secondary-btn"
            >
                Edit
            </a>

        <?php endif; ?>

    </div>

</div>


<div class="exception-document">


    <div class="exception-document-header">

        <div>

            <div class="exception-reference-large">

                <?= h(
                    $exception['reference_no']
                ) ?>

            </div>


            <h1>

                <?= h(
                    $exception['title']
                ) ?>

            </h1>


            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'short_description'
                        ]
                    )
                ) ?>

            </p>

        </div>


        <div>

            <span
                class="exception-status status-<?= strtolower(
                    str_replace(
                        ' ',
                        '-',
                        $exception['status']
                    )
                ) ?>"
            >

                <?= h(
                    $exception['status']
                ) ?>

            </span>

        </div>

    </div>


    <div class="exception-meta">


        <div>

            <span>
                TYPE
            </span>

            <strong>

                <?= h(
                    $exception[
                        'exception_type'
                    ]
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                REGISTER VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'version'
                    ] ?? '1.0'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                SYSTEM
            </span>

            <strong>

                <?= h(
                    $exception[
                        'system_name'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                APPLICATION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'application_name'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                TEAM
            </span>

            <strong>

                <?= h(
                    $exception['team']
                    ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                CURRENT VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'current_version'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                TARGET VERSION
            </span>

            <strong>

                <?= h(
                    $exception[
                        'target_version'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                VISIBILITY
            </span>

            <strong>

                <?= h(
                    $exception[
                        'visibility'
                    ]
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                START DATE
            </span>

            <strong>

                <?= h(
                    $exception[
                        'start_date'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>


        <div>

            <span>
                EXPIRY
            </span>

            <strong>

                <?= h(
                    $exception[
                        'expiry_date'
                    ] ?: '—'
                ) ?>

            </strong>

        </div>

    </div>


    <div class="exception-section">

        <h2>
            Reason / Justification
        </h2>

        <p>

            <?= nl2br(
                h(
                    $exception['reason']
                )
            ) ?>

        </p>

    </div>


    <div class="exception-section">

        <h2>
            Risk
        </h2>

        <div class="exception-risk">

            <?= nl2br(
                h(
                    $exception[
                        'risk_description'
                    ]
                )
            ) ?>

        </div>

    </div>


    <div class="exception-section">

        <h2>
            Mitigation / Compensating Control
        </h2>

        <div class="exception-mitigation">

            <?= nl2br(
                h(
                    $exception[
                        'mitigation'
                    ]
                )
            ) ?>

        </div>

    </div>


    <?php if (
        trim(
            $exception[
                'additional_details'
            ] ?? ''
        ) !== ''
    ): ?>

        <div class="exception-section">

            <h2>
                Additional Details
            </h2>

            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'additional_details'
                        ]
                    )
                ) ?>

            </p>

        </div>

    <?php endif; ?>


    <div class="exception-section">

        <h2>
            Attachments
        </h2>


        <div class="exception-attachments">

            <?php if ($attachments): ?>

                <?php foreach (
                    $attachments
                    as $attachment
                ): ?>

                    <a
                        class="exception-attachment"
                        href="patch.php?action=file&id=<?= (int) $attachment['id'] ?>"
                    >

                        📎

                        <?= h(
                            $attachment[
                                'original_name'
                            ]
                        ) ?>


                        <small>

                            (
                            <?= h(
                                number_format(
                                    (
                                        (int) $attachment[
                                            'file_size'
                                        ]
                                    ) / 1024,
                                    1
                                )
                            ) ?>
                            KB)

                        </small>

                    </a>

                <?php endforeach; ?>

            <?php else: ?>

                <span class="muted">
                    No attachments.
                </span>

            <?php endif; ?>

        </div>

    </div>


    <?php if (
        $exception['status'] === 'Rejected' &&
        !empty(
            $exception['rejection_reason']
        )
    ): ?>

        <div class="exception-section">

            <h2>
                Rejection Reason
            </h2>


            <div class="exception-risk">

                <?= nl2br(
                    h(
                        $exception[
                            'rejection_reason'
                        ]
                    )
                ) ?>

            </div>

        </div>

    <?php endif; ?>


    <?php if (
        !empty(
            $exception['review_comment']
        ) &&
        $exception['status'] !== 'Rejected'
    ): ?>

        <div class="exception-section">

            <h2>
                Review Comment
            </h2>

            <p>

                <?= nl2br(
                    h(
                        $exception[
                            'review_comment'
                        ]
                    )
                ) ?>

            </p>

        </div>

    <?php endif; ?>


    <?php if (
        $is_admin &&
        $exception['status']
            === 'Pending Review'
    ): ?>

        <div class="exception-review">

            <h2>
                Admin Review
            </h2>


            <form
                method="POST"
                action="patch.php?view=<?= (int) $exception['id'] ?>"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h($csrf_token) ?>"
                >


                <input
                    type="hidden"
                    name="form_action"
                    value="review_exception"
                >


                <input
                    type="hidden"
                    name="exception_id"
                    value="<?= (int) $exception['id'] ?>"
                >


                <textarea
                    name="review_comment"
                    placeholder="Review comments / approval conditions / rejection reason"
                ></textarea>


                <div
                    style="display:flex;gap:10px;"
                >

                    <button
                        type="submit"
                        name="decision"
                        value="reject"
                        class="sop-secondary-btn"
                    >
                        Reject
                    </button>


                    <button
                        type="submit"
                        name="decision"
                        value="approve"
                        class="sop-primary-btn"
                    >
                        Approve Exception
                    </button>

                </div>

            </form>

        </div>

    <?php endif; ?>


</div>


<?php

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

else:

    /*
    |--------------------------------------------------------------------------
    | List query: visibility + search, server-side sort, server-side
    | pagination at the user's preferred page size.
    |--------------------------------------------------------------------------
    */

    [$list_where, $list_params] = build_exception_filter(
        $current_user_id,
        $current_user_team,
        $is_admin,
        $keyword,
        $advanced_search
    );

    $order_column = $exception_sort_columns[$sort_by];

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM patch_exceptions e WHERE $list_where");
    $count_stmt->execute($list_params);
    $filtered_total = (int) $count_stmt->fetchColumn();

    $page_size = resolveUserPageSize($pdo, $current_user_id);
    $current_page = max(1, (int) ($_GET['page'] ?? 1));
    $total_pages = max(1, (int) ceil($filtered_total / $page_size));
    if ($current_page > $total_pages) {
        $current_page = $total_pages;
    }
    $offset = ($current_page - 1) * $page_size;

    $list_stmt = $pdo->prepare("
        SELECT
            e.*,
            owner.first_name AS owner_first,
            owner.last_name AS owner_last,
            creator.first_name AS creator_first,
            creator.last_name AS creator_last
        FROM patch_exceptions e
        LEFT JOIN users owner ON owner.id = e.owner_id
        LEFT JOIN users creator ON creator.id = e.requested_by
        WHERE $list_where
        ORDER BY $order_column $sort_order
        LIMIT $page_size OFFSET $offset
    ");
    $list_stmt->execute($list_params);
    $rows = $list_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Every filter/sort param that needs to survive pagination, sorting,
    // page-size changes, and the Export link -- built once, reused by all
    // of them so they can never drift out of sync with each other.
    $list_query_params = array_filter([
        'keyword' => $keyword,
        'advanced_search' => $advanced_search,
        'sort_by' => $sort_by,
        'sort_order' => $sort_order,
    ], static fn($v) => $v !== '');

    $hidden_filter_fields = '';
    foreach ($list_query_params as $fk => $fv) {
        $hidden_filter_fields .= '<input type="hidden" name="' . h($fk) . '" value="' . h($fv) . '">';
    }

?>


<div class="exception-header">

    <div>

        <h1>
            Patch & Exception Register
        </h1>

        <p>
            Track patching, upgrade and control-fix exceptions.
        </p>

    </div>

    <div style="display:flex;gap:8px;flex-wrap:wrap;">

        <?php if ($is_admin || $canAudit): ?>
            <button type="button" class="sop-secondary-btn" onclick="openExceptionHistory(0)">History</button>
        <?php endif; ?>

        <?php if ($is_admin || $canExport): ?>
            <a
                href="patch.php?<?= h(http_build_query(array_merge($list_query_params, ['action' => 'export']))) ?>"
                class="sop-secondary-btn"
            >
                Export CSV
            </a>
        <?php endif; ?>

        <a
            href="patch.php?action=create"
            class="sop-primary-btn"
        >
            + New Exception
        </a>

    </div>

</div>


<div class="exception-stats">


    <div class="exception-stat">

        <span>
            Total
        </span>

        <strong>
            <?= $total ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Draft
        </span>

        <strong>
            <?= $draft ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Pending Review
        </span>

        <strong>
            <?= $pending ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Approved
        </span>

        <strong>
            <?= $approved ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Rejected
        </span>

        <strong>
            <?= $rejected ?>
        </strong>

    </div>


    <div class="exception-stat">

        <span>
            Expired
        </span>

        <strong>
            <?= $expired ?>
        </strong>

    </div>

</div>


<div class="exception-panel">


    <div class="exception-toolbar" style="flex-wrap:wrap;">

        <h2>
            Exception Register
        </h2>

        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">

            <form method="GET" action="patch.php" style="display:flex;gap:8px;">
                <input type="hidden" name="sort_by" value="<?= h($sort_by) ?>">
                <input type="hidden" name="sort_order" value="<?= h($sort_order) ?>">
                <input
                    type="text"
                    name="keyword"
                    class="exception-search"
                    placeholder="Search reference, title, system, app, team..."
                    value="<?= h($keyword) ?>"
                >
                <button type="submit" class="sop-secondary-btn">Search</button>
            </form>

            <button type="button" class="sop-secondary-btn" onclick="document.getElementById('advancedSearchModal').style.display='flex'">
                Advanced Search
            </button>

            <?php if ($keyword !== '' || $advanced_search !== ''): ?>
                <a href="patch.php" class="sop-secondary-btn">Clear</a>
            <?php endif; ?>

            <?= pageSizeSelectorHtml($page_size, $hidden_filter_fields) ?>

        </div>

    </div>


    <?php if ($advanced_search !== ''): ?>
        <div class="sop-alert" style="background:#eff6ff;color:#1d4ed8;border:1px solid #bfdbfe;margin-bottom:16px;">
            <strong>Multi-value search active:</strong> <?= h(str_replace(["\r", "\n"], ' | ', $advanced_search)) ?>
            <a href="patch.php" style="margin-left:10px;">Clear</a>
        </div>
    <?php endif; ?>


    <div style="overflow-x:auto;">

        <table
            class="exception-table"
            id="exceptionTable"
        >

            <thead>

                <tr>

                    <th><?= exception_sort_link('reference_no', 'Reference', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= exception_sort_link('title', 'Title', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= exception_sort_link('exception_type', 'Type', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= exception_sort_link('system_name', 'System', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= exception_sort_link('team', 'Team', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th>
                        Owner
                    </th>

                    <th><?= exception_sort_link('expiry_date', 'Expiry', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= exception_sort_link('status', 'Status', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>


<?php

/*
|--------------------------------------------------------------------------
| $rows was already fetched above (paginated, sorted, filtered by
| build_exception_filter() -- visibility is applied in SQL now, not by
| looping every row in PHP and re-querying each user's team along the way).
|--------------------------------------------------------------------------
*/

$visible_count = count($rows);

foreach (
    $rows
    as $row
):


    $owner =
        trim(
            ($row['owner_first'] ?? '')
            . ' '
            . ($row['owner_last'] ?? '')
        );


    $can_edit =
        can_edit_exception(
            $pdo,
            $row,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        );


    $can_delete =
        can_delete_exception(
            $pdo,
            $row,
            $current_user_id,
            $current_user_team,
            $role,
            $is_admin
        );

?>


<tr>


    <td>

        <a
            class="exception-reference"
            href="patch.php?view=<?= (int) $row['id'] ?>"
        >

            <?= h(
                $row['reference_no']
            ) ?>

        </a>

    </td>


    <td>

        <a
            class="exception-title"
            href="patch.php?view=<?= (int) $row['id'] ?>"
        >

            <?= h(
                $row['title']
            ) ?>

        </a>


        <?php if (
            !empty(
                $row['short_description']
            )
        ): ?>

            <br>

            <small>

                <?= h(
                    substr(
                        $row[
                            'short_description'
                        ],
                        0,
                        100
                    )
                ) ?>

            </small>

        <?php endif; ?>

    </td>


    <td>

        <span class="exception-type">

            <?= h(
                $row['exception_type']
            ) ?>

        </span>

    </td>


    <td>

        <?= h(
            $row['system_name']
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $row['team']
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $owner
            ?: '—'
        ) ?>

    </td>


    <td>

        <?= h(
            $row['expiry_date']
            ?: '—'
        ) ?>

    </td>


    <td>

        <span
            class="exception-status status-<?= strtolower(
                str_replace(
                    ' ',
                    '-',
                    $row['status']
                )
            ) ?>"
        >

            <?= h(
                $row['status']
            ) ?>

        </span>

    </td>


    <td>

        <div class="exception-actions">


            <a
                href="patch.php?view=<?= (int) $row['id'] ?>"
            >
                View
            </a>


            <?php if ($can_edit): ?>

                <a
                    href="patch.php?action=edit&id=<?= (int) $row['id'] ?>"
                >
                    Edit
                </a>

            <?php endif; ?>


            <?php if (
                $is_admin &&
                $row['status']
                    === 'Pending Review'
            ): ?>

                <a
                    href="patch.php?view=<?= (int) $row['id'] ?>"
                >
                    Review
                </a>

            <?php endif; ?>


            <?php if ($is_admin || $canAudit): ?>
                <button type="button" onclick="openExceptionHistory(<?= (int) $row['id'] ?>)">History</button>
            <?php endif; ?>


            <?php if ($can_delete): ?>

                <form
                    method="POST"
                    action="patch.php"
                    style="display:inline;"
                    onsubmit="return confirm('Delete this exception permanently?');"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= h(
                            $csrf_token
                        ) ?>"
                    >


                    <input
                        type="hidden"
                        name="form_action"
                        value="delete_exception"
                    >


                    <input
                        type="hidden"
                        name="exception_id"
                        value="<?= (int) $row['id'] ?>"
                    >


                    <button
                        type="submit"
                        class="delete"
                    >
                        Delete
                    </button>

                </form>

            <?php endif; ?>


        </div>

    </td>

</tr>


<?php endforeach; ?>


<?php if ($visible_count === 0): ?>

<tr>

    <td
        colspan="9"
        style="text-align:center;padding:40px;"
    >

        <?= ($keyword !== '' || $advanced_search !== '')
            ? 'No exceptions match your search.'
            : 'No exceptions have been created.' ?>

    </td>

</tr>

<?php endif; ?>


            </tbody>

        </table>

    </div>


    <?php if ($total_pages > 1): ?>
        <div class="pagination" style="display:flex;justify-content:center;gap:6px;margin-top:20px;flex-wrap:wrap;">
            <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                <a
                    href="patch.php?<?= h(http_build_query(array_merge($list_query_params, ['page' => $p]))) ?>"
                    class="sop-secondary-btn"
                    style="<?= $p === $current_page ? 'background:#2563eb;color:#fff;border-color:#2563eb;' : '' ?>"
                >
                    <?= $p ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

    <div style="text-align:center;color:var(--text-muted);font-size:12.5px;margin-top:10px;">
        Showing <?= count($rows) ?> of <?= $filtered_total ?> exception<?= $filtered_total === 1 ? '' : 's' ?>
    </div>

</div>


<!-- ADVANCED SEARCH MODAL -->
<div id="advancedSearchModal" class="modal-overlay" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.45);align-items:center;justify-content:center;z-index:5000;padding:20px;" onclick="if(event.target===this) this.style.display='none';">
    <div style="background:var(--bg-content);border-radius:16px;padding:26px;width:100%;max-width:600px;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(15,23,42,.25);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
            <h3 style="margin:0;">Advanced Multi-Value Search</h3>
            <button type="button" onclick="document.getElementById('advancedSearchModal').style.display='none'" style="border:none;background:var(--hover-bg);width:30px;height:30px;border-radius:8px;cursor:pointer;">&times;</button>
        </div>
        <form method="GET" action="patch.php">
            <p style="font-size:13px;color:var(--text-secondary);margin-bottom:10px;">
                Enter multiple reference numbers, titles, systems, applications, or team names -- separated by commas, semicolons, or new lines. Matches any of them.
            </p>
            <textarea name="advanced_search" rows="8" style="width:100%;box-sizing:border-box;border:1px solid #d1d5db;border-radius:7px;padding:10px 12px;font:inherit;" placeholder="EXC-001&#10;RHEL production&#10;Finance"><?= h($advanced_search) ?></textarea>
            <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:16px;">
                <a href="patch.php" class="sop-secondary-btn">Reset</a>
                <button type="button" class="sop-secondary-btn" onclick="document.getElementById('advancedSearchModal').style.display='none'">Cancel</button>
                <button type="submit" class="sop-primary-btn">Apply</button>
            </div>
        </form>
    </div>
</div>


<!-- AUDIT HISTORY MODAL (page audit when opened with id=0, line audit otherwise) -->
<div id="exceptionHistoryModal" class="modal-overlay" style="display:none;position:fixed;inset:0;background:rgba(15,23,42,.45);align-items:center;justify-content:center;z-index:5000;padding:20px;" onclick="if(event.target===this) this.style.display='none';">
    <div style="background:var(--bg-content);border-radius:16px;padding:26px;width:100%;max-width:750px;max-height:88vh;overflow-y:auto;box-shadow:0 20px 60px rgba(15,23,42,.25);">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
            <h3 id="exceptionHistoryTitle" style="margin:0;">Audit History</h3>
            <button type="button" onclick="document.getElementById('exceptionHistoryModal').style.display='none'" style="border:none;background:var(--hover-bg);width:30px;height:30px;border-radius:8px;cursor:pointer;">&times;</button>
        </div>
        <div id="exceptionHistoryContent"><p class="empty-state">Loading...</p></div>
    </div>
</div>


<?php endif; ?>


</div>


<style>
.audit-table { width: 100%; border-collapse: collapse; }
.audit-table th { text-align: left; padding: 8px 10px; background: var(--hover-bg); font-size: 11.5px; text-transform: uppercase; color: var(--text-secondary); border-bottom: 1px solid var(--border-color); }
.audit-table td { padding: 8px 10px; border-bottom: 1px solid var(--border-light); font-size: 13px; vertical-align: top; }
.audit-details { color: var(--text-secondary); }
</style>


<script>

function openExceptionHistory(exceptionId) {
    const modal = document.getElementById('exceptionHistoryModal');
    const content = document.getElementById('exceptionHistoryContent');
    const title = document.getElementById('exceptionHistoryTitle');

    title.innerText = exceptionId > 0 ? 'Audit History (Record #' + exceptionId + ')' : 'Audit History (All Exceptions)';
    content.innerHTML = '<p class="empty-state">Loading...</p>';
    modal.style.display = 'flex';

    const url = exceptionId > 0
        ? 'patch.php?action=get_history&exception_id=' + encodeURIComponent(exceptionId)
        : 'patch.php?action=get_history';

    fetch(url)
        .then(r => r.text())
        .then(html => { content.innerHTML = html; })
        .catch(() => { content.innerHTML = '<p class="empty-state">Unable to load history.</p>'; });
}

</script>


<?php

require_once 'includes/footer.php';

?>
