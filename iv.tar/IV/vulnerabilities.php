<?php

session_start();

require_once __DIR__ . '/config/vulnerability_db.php';

/*
|--------------------------------------------------------------------------
| LOGIN CHECK
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('vulnerabilities', 'can_view');



/*
|--------------------------------------------------------------------------
| CURRENT USER ROLE
|--------------------------------------------------------------------------
|
| Delete is allowed only for Admin users.
|
*/

$role = strtolower(trim($_SESSION['role'] ?? ''));

$isAdmin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);


/*
|--------------------------------------------------------------------------
| PAGE TITLE
|--------------------------------------------------------------------------
*/

$page_title = 'Vulnerability Management';


/*
|--------------------------------------------------------------------------
| DELETE VA REPORT
|--------------------------------------------------------------------------
|
| Only Admin users can execute this operation.
|
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['delete_report'])
) {

    /*
     * Extra server-side security check.
     *
     * Even if somebody manually creates a POST request,
     * non-admin users cannot delete reports.
     */
    if (!$isAdmin) {
        http_response_code(403);
        exit('You do not have permission to delete VA reports.');
    }


    /*
     * Get report ID.
     */
    $reportId = (int) ($_POST['report_id'] ?? 0);


    if ($reportId <= 0) {

        header('Location: vulnerabilities.php');
        exit;

    }


    try {

        /*
         * Get the report first so we know the physical
         * CSV file path before deleting the database row.
         */
        $reportStmt = $pdo->prepare("
            SELECT
                id,
                filename,
                file_path
            FROM va_reports
            WHERE id = ?
            LIMIT 1
        ");

        $reportStmt->execute([$reportId]);

        $reportToDelete = $reportStmt->fetch(PDO::FETCH_ASSOC);


        /*
         * Report does not exist.
         */
        if (!$reportToDelete) {

            header('Location: vulnerabilities.php');
            exit;

        }


        /*
         * Store the physical file path before
         * deleting the database record.
         */
        $filePath = $reportToDelete['file_path'] ?? '';


        /*
         * Start transaction.
         */
        $pdo->beginTransaction();


        /*
         * -------------------------------------------------------
         * DELETE TRACKING RECORDS
         * -------------------------------------------------------
         *
         * va_tracking references va_vulnerabilities.
         */
        $deleteTracking = $pdo->prepare("
            DELETE FROM va_tracking
            WHERE vulnerability_id IN (
                SELECT id
                FROM va_vulnerabilities
                WHERE report_id = ?
            )
        ");

        $deleteTracking->execute([$reportId]);


        /*
         * -------------------------------------------------------
         * DELETE VULNERABILITY RECORDS
         * -------------------------------------------------------
         */
        $deleteVulnerabilities = $pdo->prepare("
            DELETE FROM va_vulnerabilities
            WHERE report_id = ?
        ");

        $deleteVulnerabilities->execute([$reportId]);


        /*
         * -------------------------------------------------------
         * DELETE REPORT
         * -------------------------------------------------------
         */
        $deleteReport = $pdo->prepare("
            DELETE FROM va_reports
            WHERE id = ?
        ");

        $deleteReport->execute([$reportId]);


        /*
         * Commit database changes.
         */
        $pdo->commit();


        /*
         * -------------------------------------------------------
         * DELETE PHYSICAL CSV FILE
         * -------------------------------------------------------
         *
         * Database deletion has already succeeded.
         * If the physical file is missing, there is nothing
         * further to remove.
         */
        if (
            !empty($filePath)
            && is_file($filePath)
        ) {
            @unlink($filePath);
        }


        /*
         * Redirect after successful deletion.
         *
         * This prevents duplicate POST requests if the
         * browser page is refreshed.
         */
        header('Location: vulnerabilities.php?deleted=1');
        exit;


    } catch (Throwable $e) {

        /*
         * Roll back database changes if anything failed.
         */
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }


        /*
         * Do not expose database details to normal users.
         * Log the actual error to PHP error log.
         */
        error_log(
            'VA report deletion failed: ' . $e->getMessage()
        );


        header('Location: vulnerabilities.php?delete_error=1');
        exit;
    }
}


/*
|--------------------------------------------------------------------------
| SUCCESS / ERROR MESSAGE AFTER DELETE
|--------------------------------------------------------------------------
*/

$deleteMessage = '';

if (
    isset($_GET['deleted'])
    && $_GET['deleted'] === '1'
) {
    $deleteMessage = 'VA report deleted successfully.';
}


if (
    isset($_GET['delete_error'])
    && $_GET['delete_error'] === '1'
) {
    $deleteMessage = 'Unable to delete the VA report.';
}


/*
|--------------------------------------------------------------------------
| HEADER / SIDEBAR
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/header.php';

require_once __DIR__ . '/includes/sidebar.php';

?>


<link rel="stylesheet" href="assets/css/vulnerabilities.css">


<div class="content">


    <!-- =====================================================
         PAGE HEADER
    ====================================================== -->

    <div class="va-page-header">

        <div>

            <h1>
                Vulnerability Management
            </h1>

            <p>
                Manage uploaded VA reports and remediation status.
            </p>

        </div>


        <div class="va-header-actions">

            <a
                href="vulnerability_upload.php"
                class="va-btn va-btn-primary"
            >
                + Upload CSV
            </a>

        </div>

    </div>


    <?php if ($deleteMessage !== ''): ?>

        <div class="va-alert va-alert-success">

            <?= htmlspecialchars(
                $deleteMessage,
                ENT_QUOTES,
                'UTF-8'
            ); ?>

        </div>

    <?php endif; ?>


    <?php

    /* =====================================================
       GET LAST 10 UPLOADED REPORTS
    ====================================================== */

    $stmt = $pdo->query("
        SELECT
            r.*,
            u.first_name,
            u.last_name
        FROM va_reports r
        LEFT JOIN users u
            ON u.id = r.uploaded_by
        ORDER BY r.uploaded_at DESC
        LIMIT 10
    ");

    $reports = $stmt->fetchAll(PDO::FETCH_ASSOC);

    ?>


    <?php if (!$reports): ?>


        <!-- =================================================
             EMPTY STATE
        ================================================== -->

        <div class="va-empty">

            <div class="va-empty-icon">
                📊
            </div>

            <h2>
                No VA Reports
            </h2>

            <p>
                Upload your first vulnerability assessment CSV file.
            </p>

            <br>

            <a
                href="vulnerability_upload.php"
                class="va-btn va-btn-primary"
            >
                Upload CSV
            </a>

        </div>


    <?php else: ?>


        <!-- =================================================
             REPORT GRID
        ================================================== -->

        <div class="va-report-grid">


            <?php foreach ($reports as $report): ?>


                <?php

                /* =============================================
                   GET REPORT STATISTICS
                ============================================== */

                $countStmt = $pdo->prepare("
                    SELECT

                        COUNT(*) AS total,

                        SUM(
                            CASE
                                WHEN COALESCE(t.status, 'Open') = 'Open'
                                THEN 1
                                ELSE 0
                            END
                        ) AS open_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Assigned'
                                THEN 1
                                ELSE 0
                            END
                        ) AS assigned_count,

                        SUM(
                            CASE
                                WHEN t.status = 'In Progress'
                                THEN 1
                                ELSE 0
                            END
                        ) AS progress_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Exception'
                                THEN 1
                                ELSE 0
                            END
                        ) AS exception_count,

                        SUM(
                            CASE
                                WHEN t.status = 'Closed'
                                THEN 1
                                ELSE 0
                            END
                        ) AS closed_count

                    FROM va_vulnerabilities v

                    LEFT JOIN va_tracking t
                        ON t.vulnerability_id = v.id

                    WHERE v.report_id = ?
                ");


                $countStmt->execute([
                    $report['id']
                ]);


                $stats = $countStmt->fetch(
                    PDO::FETCH_ASSOC
                );


                /* =============================================
                   UPLOADER NAME
                ============================================== */

                $uploadedBy = trim(
                    ($report['first_name'] ?? '')
                    . ' '
                    . ($report['last_name'] ?? '')
                );

                ?>


                <!-- =========================================
                     REPORT CARD
                ========================================== -->

                <div class="va-report-card">


                    <!-- REPORT HEADER -->

                    <div class="va-report-top">


                        <div class="va-file-icon">
                            CSV
                        </div>


                        <div class="va-report-info">


                            <a
                                href="vulnerability_report.php?id=<?= (int) $report['id']; ?>"
                                class="va-report-name"
                            >

                                <?= htmlspecialchars(
                                    $report['filename'] ?? 'Unknown Report',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>

                            </a>


                            <div class="va-report-meta">

                                Uploaded

                                <?= htmlspecialchars(
                                    $report['uploaded_at'] ?? '',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>


                                <?php if ($uploadedBy !== ''): ?>

                                    by

                                    <?= htmlspecialchars(
                                        $uploadedBy,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>

                                <?php endif; ?>

                            </div>


                        </div>


                    </div>


                    <!-- =====================================
                         STATISTICS
                    ====================================== -->

                    <div class="va-report-stats">


                        <div>

                            <strong>
                                <?= (int) ($stats['total'] ?? 0); ?>
                            </strong>

                            <span>
                                Total
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['open_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Open
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['assigned_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Assigned
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['progress_count'] ?? 0); ?>
                            </strong>

                            <span>
                                In Progress
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['exception_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Exception
                            </span>

                        </div>


                        <div>

                            <strong>
                                <?= (int) ($stats['closed_count'] ?? 0); ?>
                            </strong>

                            <span>
                                Closed
                            </span>

                        </div>


                    </div>


                    <!-- =====================================
                         CARD FOOTER
                    ====================================== -->

                    <div class="va-report-footer">


                        <span>

                            <?= (int) (
                                $report['record_count'] ?? 0
                            ); ?>

                            records

                        </span>


                        <div>


                            <a
                                href="vulnerability_report.php?id=<?= (int) $report['id']; ?>"
                                class="va-btn va-btn-secondary"
                            >
                                Open Report
                            </a>


                            <a
                                href="vulnerability_export.php?id=<?= (int) $report['id']; ?>"
                                class="va-btn va-btn-secondary"
                            >
                                Export
                            </a>


                            <?php if ($isAdmin): ?>


                                <!-- =================================
                                     ADMIN ONLY DELETE
                                ================================== -->

                                <form
                                    method="POST"
                                    action="vulnerabilities.php"
                                    style="display:inline;"
                                    onsubmit="return confirm('Are you sure you want to permanently delete this VA report and all vulnerability records?');"
                                >

                                    <input
                                        type="hidden"
                                        name="delete_report"
                                        value="1"
                                    >


                                    <input
                                        type="hidden"
                                        name="report_id"
                                        value="<?= (int) $report['id']; ?>"
                                    >


                                    <button
                                        type="submit"
                                        class="va-btn va-btn-danger"
                                    >
                                        Delete
                                    </button>

                                </form>


                            <?php endif; ?>


                        </div>


                    </div>


                </div>


            <?php endforeach; ?>


        </div>


    <?php endif; ?>


</div>


<?php

require_once __DIR__ . '/includes/footer.php';

?>