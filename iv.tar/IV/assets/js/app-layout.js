/**
 * Application Layout board editor.
 *
 * The whole board is edited client-side as one nested structure and
 * submitted as a single JSON field, so a layout saves atomically rather
 * than as a stream of per-row requests that can half-apply.
 *
 * Reading the DOM back at submit time (rather than keeping a parallel
 * JavaScript model in sync with it) means what you see in the editor is
 * exactly what gets stored -- there is no second copy to drift.
 */

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }


/* ------------------------------------------------------------------
   Building blocks
------------------------------------------------------------------ */

function alServerRow(server) {
    server = server || {};

    const row = document.createElement('div');
    row.className = 'al-server-row';
    row.innerHTML =
        `<input list="platHostnames" class="al-in al-host" placeholder="hostname"
                value="${alEsc(server.hostname)}">
         <input class="al-in al-role" placeholder="role (optional)"
                value="${alEsc(server.server_role)}">
         <button type="button" class="al-x" title="Remove server">&times;</button>`;

    row.querySelector('.al-x').onclick = () => row.remove();
    return row;
}


function alComponentCard(comp) {
    comp = comp || {};

    const card = document.createElement('div');
    card.className = 'al-edit-card';

    const types = AL_COMP_TYPES
        .map(t => `<option value="${alEsc(t)}" ${comp.component_type === t ? 'selected' : ''}>${alEsc(t)}</option>`)
        .join('');

    card.innerHTML =
        `<div class="al-edit-card-head">
            <input class="al-in al-comp-name" placeholder="Component name"
                   value="${alEsc(comp.component_name)}">
            <button type="button" class="al-x" title="Remove component">&times;</button>
         </div>
         <div class="al-edit-card-meta">
            <select class="al-in al-comp-type"><option value="">Type…</option>${types}</select>
            <input class="al-in al-comp-tech" placeholder="Technology" value="${alEsc(comp.technology)}">
            <input class="al-in al-comp-port" placeholder="Port" value="${alEsc(comp.port)}">
         </div>
         <input class="al-in al-comp-notes" placeholder="Notes (optional)" value="${alEsc(comp.notes)}">
         <div class="al-servers"></div>
         <button type="button" class="al-add-server">+ Add server</button>`;

    const servers = card.querySelector('.al-servers');

    (comp.servers || []).forEach(s => servers.appendChild(alServerRow(s)));

    card.querySelector('.al-add-server').onclick = () => {
        servers.appendChild(alServerRow());
        servers.lastChild.querySelector('.al-host').focus();
    };

    card.querySelector('.al-edit-card-head .al-x').onclick = () => card.remove();

    return card;
}


function alTierBlock(tier) {
    tier = tier || {};

    const block = document.createElement('div');
    block.className = 'al-edit-tier';

    block.innerHTML =
        `<div class="al-edit-tier-head">
            <span class="al-grip" title="Move tier">⠿</span>
            <input class="al-in al-tier-name" placeholder="Tier name" value="${alEsc(tier.tier_name)}">
            <input class="al-in al-tier-type" placeholder="Tier note" value="${alEsc(tier.tier_type)}">
            <button type="button" class="al-move" data-dir="up"   title="Move up">↑</button>
            <button type="button" class="al-move" data-dir="down" title="Move down">↓</button>
            <button type="button" class="al-x" title="Remove tier">&times;</button>
         </div>
         <div class="al-edit-comps"></div>
         <button type="button" class="al-add-comp">+ Add component</button>`;

    const comps = block.querySelector('.al-edit-comps');

    (tier.components || []).forEach(c => comps.appendChild(alComponentCard(c)));

    block.querySelector('.al-add-comp').onclick = () => {
        comps.appendChild(alComponentCard());
        comps.lastChild.querySelector('.al-comp-name').focus();
    };

    block.querySelector('.al-edit-tier-head .al-x').onclick = () => block.remove();

    // Order is the DOM order, so moving a tier is just moving the node.
    block.querySelectorAll('.al-move').forEach(btn => {
        btn.onclick = () => {
            const dir = btn.dataset.dir;
            const sib = dir === 'up' ? block.previousElementSibling : block.nextElementSibling;
            if (!sib) { return; }
            dir === 'up' ? block.parentNode.insertBefore(block, sib)
                         : block.parentNode.insertBefore(sib, block);
        };
    });

    return block;
}


/* ------------------------------------------------------------------
   Open / populate
------------------------------------------------------------------ */

function alAddTier(name) {
    const t = alTierBlock({ tier_name: name || '' });
    document.getElementById('alTiers').appendChild(t);
    if (!name) { t.querySelector('.al-tier-name').focus(); }
}


function alNew() {
    document.getElementById('alTitle').innerText = 'New Layout';
    document.getElementById('al_id').value = '';

    ['app_name', 'project', 'technical_owner', 'description'].forEach(f => {
        document.getElementById('al_' + f).value = '';
    });
    document.getElementById('al_environment').value = '';
    document.getElementById('al_status').value = 'Active';

    document.getElementById('alTiers').innerHTML = '';

    // A blank board is unhelpful; start from the shape most applications
    // actually have, which the user can rename or delete.
    ['Web', 'Application', 'Database'].forEach(alAddTier);

    platOpen('alModal');
}


function alEdit(id) {
    document.getElementById('alTitle').innerText = 'Edit Layout';
    document.getElementById('alTiers').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('alModal');

    fetch('app_layout.php?action=meta_json&id=' + encodeURIComponent(id))
        .then(r => r.ok ? r.json() : null)
        .then(meta => {
            if (!meta) { return; }
            document.getElementById('al_id').value = meta.id;
            ['app_name', 'project', 'technical_owner', 'description', 'environment', 'status']
                .forEach(f => {
                    const el = document.getElementById('al_' + f);
                    if (el) { el.value = meta[f] ?? ''; }
                });
        })
        .catch(() => {});

    fetch('app_layout.php?action=board_json&id=' + encodeURIComponent(id))
        .then(r => r.ok ? r.json() : [])
        .then(board => {
            const host = document.getElementById('alTiers');
            host.innerHTML = '';
            (board || []).forEach(t => host.appendChild(alTierBlock(t)));
            if (!board || !board.length) { alAddTier(''); }
        })
        .catch(() => {
            document.getElementById('alTiers').innerHTML = '';
            alAddTier('');
        });
}


/* ------------------------------------------------------------------
   Serialise on submit
------------------------------------------------------------------ */

document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('alForm');
    if (!form) { return; }

    form.addEventListener('submit', () => {
        const board = [];

        document.querySelectorAll('#alTiers .al-edit-tier').forEach(tierEl => {
            const tierName = tierEl.querySelector('.al-tier-name').value.trim();
            if (!tierName) { return; }   // an unnamed tier is dropped, not saved empty

            const components = [];

            tierEl.querySelectorAll('.al-edit-card').forEach(cardEl => {
                const name = cardEl.querySelector('.al-comp-name').value.trim();
                if (!name) { return; }

                const servers = [];
                cardEl.querySelectorAll('.al-server-row').forEach(rowEl => {
                    const host = rowEl.querySelector('.al-host').value.trim();
                    if (!host) { return; }
                    servers.push({
                        hostname: host,
                        server_role: rowEl.querySelector('.al-role').value.trim()
                    });
                });

                components.push({
                    component_name: name,
                    component_type: cardEl.querySelector('.al-comp-type').value,
                    technology:     cardEl.querySelector('.al-comp-tech').value.trim(),
                    port:           cardEl.querySelector('.al-comp-port').value.trim(),
                    notes:          cardEl.querySelector('.al-comp-notes').value.trim(),
                    servers:        servers
                });
            });

            board.push({
                tier_name:  tierName,
                tier_type:  tierEl.querySelector('.al-tier-type').value.trim(),
                components: components
            });
        });

        document.getElementById('al_board').value = JSON.stringify(board);
    });
});


/* ------------------------------------------------------------------
   Modals
------------------------------------------------------------------ */

function alHistory(id) {
    document.getElementById('alHistTitle').innerText =
        id ? 'Audit History — layout #' + id : 'Module Audit History';
    document.getElementById('alHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('alHistModal');

    fetch('app_layout.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('alHistBody').innerHTML = h; })
        .catch(() => {
            document.getElementById('alHistBody').innerHTML = '<p class="plat-empty">Failed to load.</p>';
        });
}


function alDelete(id, name) {
    document.getElementById('alDelId').value = id;
    document.getElementById('alDelName').innerText = name;
    platOpen('alDelModal');
}


/* Values are interpolated into innerHTML, so they are escaped here. */
function alEsc(value) {
    return String(value ?? '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}
