<?php
/**
 * Knowledge Base Actions Handler - AJAX endpoints for team permissions, visibility, audit logging, comments
 *
 * Handles:
 * - Changing KB article visibility/sharing
 * - Retrieving audit trail
 * - Adding/deleting comments
 * - Getting shared teams list
 */

session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/comments-helpers.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('knowledge', 'can_view');


$current_user_id = (int)$_SESSION['user_id'];
$user_role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($user_role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

// Get user's team
$userStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    // ============================================
    // Get Audit Trail for a KB Article
    // ============================================
    if ($action === 'get_audit_trail') {
        $kb_id = (int)($_GET['kb_id'] ?? 0);

        if ($kb_id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid KB article ID']);
            exit;
        }

        // Get article details
        $kbStmt = $pdo->prepare("SELECT created_by FROM knowledge_base WHERE id = ? LIMIT 1");
        $kbStmt->execute([$kb_id]);
        $article = $kbStmt->fetch(PDO::FETCH_ASSOC);

        if (!$article) {
            http_response_code(404);
            echo json_encode(['error' => 'Article not found']);
            exit;
        }

        // Check permission: user or admin can audit
        if (!$is_admin && (int)$article['created_by'] !== $current_user_id && !hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_audit')) {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied']);
            exit;
        }

        // Get audit trail
        $trail = getItemAuditTrail($pdo, 'knowledge_base', $kb_id);

        echo json_encode([
            'success' => true,
            'audit_trail' => $trail
        ]);
        exit;
    }

    // ============================================
    // Get Shared Teams for a KB Article
    // ============================================
    if ($action === 'get_shared_teams') {
        $kb_id = (int)($_GET['kb_id'] ?? 0);

        if ($kb_id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid KB article ID']);
            exit;
        }

        $teams = getSharedTeams($pdo, 'knowledge_base', $kb_id);

        echo json_encode([
            'success' => true,
            'teams' => $teams
        ]);
        exit;
    }

    // ============================================
    // Save KB Article Visibility/Sharing
    // ============================================
    if ($action === 'save_visibility') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(400);
            echo json_encode(['error' => 'POST required']);
            exit;
        }

        $kb_id = (int)($_POST['kb_id'] ?? 0);
        $visibility = trim((string)($_POST['visibility'] ?? ''));
        $selected_teams = isset($_POST['teams']) ? (array)$_POST['teams'] : [];

        if ($kb_id <= 0 || !in_array($visibility, ['public', 'team', 'teams'], true)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid parameters']);
            exit;
        }

        // Get article details
        $kbStmt = $pdo->prepare("SELECT created_by, visibility as old_visibility FROM knowledge_base WHERE id = ? LIMIT 1");
        $kbStmt->execute([$kb_id]);
        $article = $kbStmt->fetch(PDO::FETCH_ASSOC);

        if (!$article) {
            http_response_code(404);
            echo json_encode(['error' => 'Article not found']);
            exit;
        }

        // Check permission: only author + can_edit or admin
        if (!$is_admin && (int)$article['created_by'] !== $current_user_id) {
            http_response_code(403);
            echo json_encode(['error' => 'Only author can change visibility']);
            exit;
        }

        if (!$is_admin && !hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_edit')) {
            http_response_code(403);
            echo json_encode(['error' => 'No edit permission']);
            exit;
        }

        // Save visibility
        $success = saveItemSharing($pdo, 'knowledge_base', $kb_id, $visibility, $selected_teams);

        if ($success) {
            // Log the action
            $oldVisibility = $article['old_visibility'];
            $details = [
                'old_visibility' => $oldVisibility,
                'new_visibility' => $visibility,
            ];
            if ($visibility === 'teams') {
                $details['shared_teams'] = $selected_teams;
            }

            $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
            logItemAction($pdo, 'knowledge_base', $kb_id, 'VISIBILITY_CHANGED', $current_user_id, $userName, $details);

            echo json_encode([
                'success' => true,
                'message' => 'Visibility updated successfully'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to save visibility']);
        }
        exit;
    }

    // ============================================
    // Add Comment to KB Article
    // ============================================
    if ($action === 'add_comment') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(400);
            echo json_encode(['error' => 'POST required']);
            exit;
        }

        $kb_id = (int)($_POST['kb_id'] ?? 0);
        $comment_text = trim((string)($_POST['comment_text'] ?? ''));

        if ($kb_id <= 0 || $comment_text === '') {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid parameters']);
            exit;
        }

        // Check permission: must have can_edit
        if (!$is_admin && !hasRolePermission($pdo, $user_role, 'knowledge_base', 'can_edit')) {
            http_response_code(403);
            echo json_encode(['error' => 'No permission to comment']);
            exit;
        }

        // Verify article exists and user can access it
        $kbStmt = $pdo->prepare("SELECT created_by, visibility, owner_team FROM knowledge_base WHERE id = ? LIMIT 1");
        $kbStmt->execute([$kb_id]);
        $article = $kbStmt->fetch(PDO::FETCH_ASSOC);

        if (!$article) {
            http_response_code(404);
            echo json_encode(['error' => 'Article not found']);
            exit;
        }

        $sharedTeams = getSharedTeams($pdo, 'knowledge_base', $kb_id);
        $access = getItemAccessLevel($pdo, $current_user_id, $user_role, $user_team,
                                     $article['created_by'], $article['visibility'],
                                     $article['owner_team'], $sharedTeams, 'knowledge_base');

        if ($access === 'none') {
            http_response_code(403);
            echo json_encode(['error' => 'No access to this article']);
            exit;
        }

        // Add comment
        $stmt = $pdo->prepare("
            INSERT INTO knowledge_base_comments (kb_id, comment_text, commented_by, created_at, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ");
        $stmt->execute([$kb_id, $comment_text, $current_user_id]);

        // Log to audit trail
        $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
        logItemAction($pdo, 'knowledge_base', $kb_id, 'COMMENT_ADDED', $current_user_id, $userName);

        echo json_encode([
            'success' => true,
            'message' => 'Comment added successfully'
        ]);
        exit;
    }

    // ============================================
    // Delete Comment
    // ============================================
    if ($action === 'delete_comment') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(400);
            echo json_encode(['error' => 'POST required']);
            exit;
        }

        $comment_id = (int)($_POST['comment_id'] ?? 0);

        if ($comment_id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid comment ID']);
            exit;
        }

        // Get comment
        $commentStmt = $pdo->prepare("SELECT commented_by, kb_id FROM knowledge_base_comments WHERE id = ? LIMIT 1");
        $commentStmt->execute([$comment_id]);
        $comment = $commentStmt->fetch(PDO::FETCH_ASSOC);

        if (!$comment) {
            http_response_code(404);
            echo json_encode(['error' => 'Comment not found']);
            exit;
        }

        // Check permission: only comment author or admin
        if (!$is_admin && (int)$comment['commented_by'] !== $current_user_id) {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied']);
            exit;
        }

        // Delete comment
        $pdo->prepare("DELETE FROM knowledge_base_comments WHERE id = ?")->execute([$comment_id]);

        echo json_encode([
            'success' => true,
            'message' => 'Comment deleted successfully'
        ]);
        exit;
    }

    // ============================================
    // Get All Available Teams
    // ============================================
    if ($action === 'get_all_teams') {
        $teams = getAllTeams($pdo);

        echo json_encode([
            'success' => true,
            'teams' => $teams
        ]);
        exit;
    }

    // ============================================
    // Default: Action not found
    // ============================================
    http_response_code(400);
    echo json_encode(['error' => 'Unknown action']);

} catch (Throwable $e) {
    error_log("KB Actions Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
