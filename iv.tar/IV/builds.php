<?php
require_once 'config/db.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$current_user_id = $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');

/* Permission model */
function buildHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'builds', $permission);
}
$canView=buildHasPermission($pdo,$role,'can_view');
$canEdit=buildHasPermission($pdo,$role,'can_edit');
$canDelete=buildHasPermission($pdo,$role,'can_delete');
$canExport=buildHasPermission($pdo,$role,'can_export');
$canImport=buildHasPermission($pdo,$role,'can_import');
$canAudit=buildHasPermission($pdo,$role,'can_audit');
if (!$canView) { http_response_code(403); exit('You do not have permission to view this page.'); }


$success_msg = '';
$error_msg = '';

$support_options = [
    'HCL',
    'Ejada',
    'STC',
    'Alfa',
    'MOF',
    'NCGR',
    'UGRP',
    'Others',
    'GRC',
    'ADT'
];

/*
|--------------------------------------------------------------------------
| CREATE HISTORY TABLE IF IT DOES NOT EXIST
|--------------------------------------------------------------------------
*/
try {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS build_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            build_id INTEGER,
            user_id INTEGER,
            action TEXT NOT NULL,
            changes TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    ");
} catch (Exception $e) {
    // Do not stop the page if history table creation fails.
}

/*
|--------------------------------------------------------------------------
| FETCH PORTAL USERS
|--------------------------------------------------------------------------
*/
$users_stmt = $pdo->query("
    SELECT id, first_name, last_name
    FROM users
    WHERE is_approved = 1
    ORDER BY first_name ASC
");

$all_portal_users = $users_stmt->fetchAll(PDO::FETCH_ASSOC);

/*
|--------------------------------------------------------------------------
| USER NAME HELPER
|--------------------------------------------------------------------------
*/
function getUserName($pdo, $user_id)
{
    if (empty($user_id)) {
        return '-';
    }

    $stmt = $pdo->prepare("
        SELECT first_name, last_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return 'Unknown User';
    }

    return trim(($user['first_name'] ?? '') . ' ' . ($user['last_name'] ?? ''));
}

/*
|--------------------------------------------------------------------------
| WRITE HISTORY
|--------------------------------------------------------------------------
*/
function addBuildHistory($pdo, $build_id, $user_id, $action, $changes = '')
{
    try {
        $stmt = $pdo->prepare("
            INSERT INTO build_history
                (build_id, user_id, action, changes, created_at)
            VALUES
                (?, ?, ?, ?, CURRENT_TIMESTAMP)
        ");

        $stmt->execute([
            $build_id,
            $user_id,
            $action,
            $changes
        ]);
    } catch (Exception $e) {
        // History must not prevent the main operation.
    }
}

/*
|--------------------------------------------------------------------------
| JSON HISTORY RESPONSE
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'get_history') {
    if (!$canAudit) { http_response_code(403); echo json_encode(['success'=>false,'message'=>'You do not have permission to view audit history.']); exit; }

    header('Content-Type: application/json; charset=utf-8');

    $build_id = (int)($_POST['build_id'] ?? 0);

    if ($build_id <= 0) {
        echo json_encode([
            'success' => false,
            'message' => 'Invalid build ID.'
        ]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("
            SELECT
                h.id,
                h.build_id,
                h.user_id,
                h.action,
                h.changes,
                h.created_at,
                u.first_name,
                u.last_name
            FROM build_history h
            LEFT JOIN users u ON h.user_id = u.id
            WHERE h.build_id = ?
            ORDER BY h.id DESC
        ");

        $stmt->execute([$build_id]);
        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($history as &$item) {
            $item['user_name'] = trim(
                ($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? '')
            );

            if ($item['user_name'] === '') {
                $item['user_name'] = 'Unknown User';
            }
        }

        echo json_encode([
            'success' => true,
            'history' => $history
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| GLOBAL HISTORY
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'get_global_history') {
    if (!$canAudit) { http_response_code(403); echo json_encode(['success'=>false,'message'=>'You do not have permission to view audit history.']); exit; }

    header('Content-Type: application/json; charset=utf-8');

    try {
        $stmt = $pdo->query("
            SELECT
                h.id,
                h.build_id,
                h.user_id,
                h.action,
                h.changes,
                h.created_at,
                b.build_no,
                b.project,
                u.first_name,
                u.last_name
            FROM build_history h
            LEFT JOIN builds b ON h.build_id = b.id
            LEFT JOIN users u ON h.user_id = u.id
            ORDER BY h.id DESC
            LIMIT 500
        ");

        $history = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach ($history as &$item) {
            $item['user_name'] = trim(
                ($item['first_name'] ?? '') . ' ' . ($item['last_name'] ?? '')
            );

            if ($item['user_name'] === '') {
                $item['user_name'] = 'Unknown User';
            }
        }

        echo json_encode([
            'success' => true,
            'history' => $history
        ]);
    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'message' => $e->getMessage()
        ]);
    }

    exit;
}

/*
|--------------------------------------------------------------------------
| EXPORT BUILDS (respects search filters)
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'export_builds') {
    if (!$canExport) { http_response_code(403); exit('You do not have permission to export build records.'); }

    $keyword = trim($_POST['keyword'] ?? '');
    $s_build_no = trim($_POST['s_build_no'] ?? '');
    $s_project = trim($_POST['s_project'] ?? '');
    $s_status = trim($_POST['s_status'] ?? '');

    $where_clauses = ['1=1'];
    $params = [];

    if (!empty($keyword)) {
        $where_clauses[] = "(b.build_no LIKE ? OR b.project LIKE ? OR b.status LIKE ?)";
        array_push($params, "%$keyword%", "%$keyword%", "%$keyword%");
    }
    if (!empty($s_build_no)) {
        $where_clauses[] = "b.build_no LIKE ?";
        $params[] = "%$s_build_no%";
    }
    if (!empty($s_project)) {
        $where_clauses[] = "b.project LIKE ?";
        $params[] = "%$s_project%";
    }
    if (!empty($s_status)) {
        $where_clauses[] = "b.status = ?";
        $params[] = "$s_status";
    }

    $where_sql = implode(" AND ", $where_clauses);

    $stmt = $pdo->prepare("
        SELECT
            b.build_no,
            b.project,
            b.status,
            creator.first_name AS creator_first,
            creator.last_name AS creator_last,
            builder.first_name AS builder_first,
            builder.last_name AS builder_last,
            b.supported_by,
            b.build_from,
            b.comments,
            b.created_at
        FROM builds b
        LEFT JOIN users creator ON b.user_id = creator.id
        LEFT JOIN users builder ON b.build_by = builder.id
        WHERE $where_sql
        ORDER BY b.created_at DESC
    ");
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="builds_export_' . date('Y-m-d_H-i-s') . '.csv"');
    fprintf($output = fopen('php://output', 'w'), chr(0xEF) . chr(0xBB) . chr(0xBF));

    fputcsv($output, [
        'Build No',
        'Project',
        'Status',
        'Build By',
        'Supported By',
        'From',
        'Comments',
        'Created By',
        'Created Date'
    ]);

    foreach ($rows as $row) {
        $created_by = trim(($row['creator_first'] ?? '') . ' ' . ($row['creator_last'] ?? '')) ?: 'Unknown User';
        $build_by = trim(($row['builder_first'] ?? '') . ' ' . ($row['builder_last'] ?? '')) ?: 'Unknown User';

        fputcsv($output, [
            $row['build_no'] ?? '',
            $row['project'] ?? '',
            $row['status'] ?? '',
            $build_by,
            $row['supported_by'] ?? '',
            $row['build_from'] ?? '',
            $row['comments'] ?? '',
            $created_by,
            $row['created_at'] ?? ''
        ]);
    }

    fclose($output);
    exit;
}

/*
|--------------------------------------------------------------------------
| HANDLE CREATE / UPDATE / DELETE
|--------------------------------------------------------------------------
*/
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? '';
    if ($action === 'create_build' && !$canEdit) { $error_msg = 'You do not have permission to create build records.'; $action = ''; }
    elseif ($action === 'update_build' && !$canEdit) { $error_msg = 'You do not have permission to edit build records.'; $action = ''; }
    elseif ($action === 'delete_build' && !$canDelete) { $error_msg = 'You do not have permission to delete build records.'; $action = ''; }

    /*
    |--------------------------------------------------------------------------
    | CREATE BUILD
    |--------------------------------------------------------------------------
    */
    if ($action === 'create_build') {

        $build_no = trim($_POST['build_no'] ?? '');
        $project = trim($_POST['project'] ?? '');
        $status = trim($_POST['status'] ?? '');
        $build_by = trim($_POST['build_by'] ?? '');
        $supported_by = trim($_POST['supported_by'] ?? '');
        $build_from = trim($_POST['build_from'] ?? '');
        $comments = trim($_POST['comments'] ?? '');

        if (
            empty($build_no) ||
            empty($project) ||
            empty($status) ||
            empty($build_by)
        ) {

            $error_msg = "Please fill in all required fields (Build No, Project, Status, Build By).";

        } else {

            try {

                $pdo->beginTransaction();

                $stmt = $pdo->prepare("
                    INSERT INTO builds
                    (
                        build_no,
                        project,
                        status,
                        build_by,
                        supported_by,
                        build_from,
                        comments,
                        user_id
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $stmt->execute([
                    $build_no,
                    $project,
                    $status,
                    $build_by,
                    $supported_by,
                    $build_from,
                    $comments,
                    $current_user_id
                ]);

                $build_id = $pdo->lastInsertId();

                /*
                |--------------------------------------------------------------------------
                | ATTACHMENTS
                |--------------------------------------------------------------------------
                */
                if (!empty($_FILES['attachments']['name'][0])) {

                    $upload_dir = 'uploads/builds/';

                    if (!is_dir($upload_dir)) {
                        mkdir($upload_dir, 0755, true);
                    }

                    foreach ($_FILES['attachments']['name'] as $key => $filename) {

                        if (
                            isset($_FILES['attachments']['error'][$key]) &&
                            $_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK
                        ) {

                            $tmp_name = $_FILES['attachments']['tmp_name'][$key];

                            $safe_filename =
                                time() . '_' .
                                preg_replace(
                                    "/[^a-zA-Z0-9\._-]/",
                                    "_",
                                    $filename
                                );

                            $destination = $upload_dir . $safe_filename;

                            if (move_uploaded_file($tmp_name, $destination)) {

                                $att_stmt = $pdo->prepare("
                                    INSERT INTO build_attachments
                                    (build_id, filename, filepath)
                                    VALUES (?, ?, ?)
                                ");

                                $att_stmt->execute([
                                    $build_id,
                                    $filename,
                                    $destination
                                ]);
                            }
                        }
                    }
                }

                addBuildHistory(
                    $pdo,
                    $build_id,
                    $current_user_id,
                    'Created',
                    'Build record created.'
                );

                $pdo->commit();

                $success_msg = "New build record successfully created.";

            } catch (Exception $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error_msg = "Unable to create build record: " . $e->getMessage();
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | UPDATE BUILD
    |--------------------------------------------------------------------------
    */
    elseif ($action === 'update_build') {

        $build_id = (int)($_POST['build_id'] ?? 0);

        $check_stmt = $pdo->prepare("
            SELECT *
            FROM builds
            WHERE id = ?
            LIMIT 1
        ");

        $check_stmt->execute([$build_id]);
        $old_build = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$old_build) {

            $error_msg = "Build record not found.";

        } else {

            $build_no = trim($_POST['build_no'] ?? '');
            $project = trim($_POST['project'] ?? '');
            $status = trim($_POST['status'] ?? '');
            $build_by = trim($_POST['build_by'] ?? '');
            $supported_by = trim($_POST['supported_by'] ?? '');
            $build_from = trim($_POST['build_from'] ?? '');
            $comments = trim($_POST['comments'] ?? '');

            if (
                empty($build_no) ||
                empty($project) ||
                empty($status) ||
                empty($build_by)
            ) {

                $error_msg = "Please fill in all required fields.";

            } else {

                try {

                    $pdo->beginTransaction();

                    $update_stmt = $pdo->prepare("
                        UPDATE builds
                        SET
                            build_no = ?,
                            project = ?,
                            status = ?,
                            build_by = ?,
                            supported_by = ?,
                            build_from = ?,
                            comments = ?
                        WHERE id = ?
                    ");

                    $update_stmt->execute([
                        $build_no,
                        $project,
                        $status,
                        $build_by,
                        $supported_by,
                        $build_from,
                        $comments,
                        $build_id
                    ]);

                    /*
                    |--------------------------------------------------------------------------
                    | BUILD CHANGE HISTORY
                    |--------------------------------------------------------------------------
                    */
                    $changes = [];

                    if (($old_build['build_no'] ?? '') !== $build_no) {
                        $changes[] =
                            "Build No: " .
                            ($old_build['build_no'] ?? '-') .
                            " → " .
                            $build_no;
                    }

                    if (($old_build['project'] ?? '') !== $project) {
                        $changes[] =
                            "Project: " .
                            ($old_build['project'] ?? '-') .
                            " → " .
                            $project;
                    }

                    if (($old_build['status'] ?? '') !== $status) {
                        $changes[] =
                            "Status: " .
                            ($old_build['status'] ?? '-') .
                            " → " .
                            $status;
                    }

                    if ((string)($old_build['build_by'] ?? '') !== (string)$build_by) {

                        $old_name = getUserName(
                            $pdo,
                            $old_build['build_by'] ?? null
                        );

                        $new_name = getUserName(
                            $pdo,
                            $build_by
                        );

                        $changes[] =
                            "Build By: " .
                            $old_name .
                            " → " .
                            $new_name;
                    }

                    if (($old_build['supported_by'] ?? '') !== $supported_by) {
                        $changes[] =
                            "Supported By: " .
                            ($old_build['supported_by'] ?? '-') .
                            " → " .
                            ($supported_by ?: '-');
                    }

                    if (($old_build['build_from'] ?? '') !== $build_from) {
                        $changes[] =
                            "From: " .
                            ($old_build['build_from'] ?? '-') .
                            " → " .
                            ($build_from ?: '-');
                    }

                    if (($old_build['comments'] ?? '') !== $comments) {
                        $changes[] = "Comments changed.";
                    }

                    /*
                    |--------------------------------------------------------------------------
                    | ATTACHMENTS
                    |--------------------------------------------------------------------------
                    */
                    $attachment_count = 0;

                    if (!empty($_FILES['attachments']['name'][0])) {

                        $upload_dir = 'uploads/builds/';

                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0755, true);
                        }

                        foreach ($_FILES['attachments']['name'] as $key => $filename) {

                            if (
                                isset($_FILES['attachments']['error'][$key]) &&
                                $_FILES['attachments']['error'][$key] === UPLOAD_ERR_OK
                            ) {

                                $tmp_name = $_FILES['attachments']['tmp_name'][$key];

                                $safe_filename =
                                    time() . '_' .
                                    uniqid() . '_' .
                                    preg_replace(
                                        "/[^a-zA-Z0-9\._-]/",
                                        "_",
                                        $filename
                                    );

                                $destination = $upload_dir . $safe_filename;

                                if (move_uploaded_file($tmp_name, $destination)) {

                                    $att_stmt = $pdo->prepare("
                                        INSERT INTO build_attachments
                                        (build_id, filename, filepath)
                                        VALUES (?, ?, ?)
                                    ");

                                    $att_stmt->execute([
                                        $build_id,
                                        $filename,
                                        $destination
                                    ]);

                                    $attachment_count++;
                                }
                            }
                        }
                    }

                    if ($attachment_count > 0) {
                        $changes[] =
                            $attachment_count .
                            " new attachment(s) added.";
                    }

                    if (empty($changes)) {
                        $changes[] = "Build record opened and saved. No field values changed.";
                    }

                    addBuildHistory(
                        $pdo,
                        $build_id,
                        $current_user_id,
                        'Updated',
                        implode("\n", $changes)
                    );

                    $pdo->commit();

                    $success_msg = "Build record successfully updated.";

                } catch (Exception $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $error_msg =
                        "Unable to update build record: " .
                        $e->getMessage();
                }
            }
        }
    }

    /*
    |--------------------------------------------------------------------------
    | DELETE BUILD
    |--------------------------------------------------------------------------
    */
    elseif ($action === 'delete_build') {

        $build_id = (int)($_POST['build_id'] ?? 0);

        $check_stmt = $pdo->prepare("
            SELECT *
            FROM builds
            WHERE id = ?
            LIMIT 1
        ");

        $check_stmt->execute([$build_id]);
        $build = $check_stmt->fetch(PDO::FETCH_ASSOC);

        if (!$build) {

            $error_msg = "Build record not found.";

        } else {

            try {

                $pdo->beginTransaction();

                /*
                |--------------------------------------------------------------------------
                | SAVE DELETE HISTORY BEFORE DELETE
                |--------------------------------------------------------------------------
                */
                addBuildHistory(
                    $pdo,
                    $build_id,
                    $current_user_id,
                    'Deleted',
                    'Build record deleted: ' .
                    ($build['build_no'] ?? '') .
                    ' - ' .
                    ($build['project'] ?? '')
                );

                /*
                |--------------------------------------------------------------------------
                | DELETE FILES
                |--------------------------------------------------------------------------
                */
                $att_query = $pdo->prepare("
                    SELECT filepath
                    FROM build_attachments
                    WHERE build_id = ?
                ");

                $att_query->execute([$build_id]);

                $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);

                foreach ($attachments as $att) {

                    if (
                        !empty($att['filepath']) &&
                        file_exists($att['filepath'])
                    ) {
                        @unlink($att['filepath']);
                    }
                }

                /*
                |--------------------------------------------------------------------------
                | DELETE ATTACHMENTS
                |--------------------------------------------------------------------------
                */
                $del_att = $pdo->prepare("
                    DELETE FROM build_attachments
                    WHERE build_id = ?
                ");

                $del_att->execute([$build_id]);

                /*
                |--------------------------------------------------------------------------
                | DELETE BUILD
                |--------------------------------------------------------------------------
                */
                $del_stmt = $pdo->prepare("
                    DELETE FROM builds
                    WHERE id = ?
                ");

                $del_stmt->execute([$build_id]);

                $pdo->commit();

                $success_msg = "Build record successfully deleted.";

            } catch (Exception $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error_msg =
                    "Unable to delete build record: " .
                    $e->getMessage();
            }
        }
    }
}

/*
|--------------------------------------------------------------------------
| SERVER-SIDE PAGINATION & SEARCH
|--------------------------------------------------------------------------
*/
$page_size = resolveUserPageSize($pdo, (int) $current_user_id);
$limit = $page_size; // alias: rest of this file's pagination logic uses $limit

$page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
$start = ($page - 1) * $limit;

$keyword = trim($_GET['keyword'] ?? '');
$s_build_no = trim($_GET['s_build_no'] ?? '');
$s_project = trim($_GET['s_project'] ?? '');
$s_status = trim($_GET['s_status'] ?? '');

$where_clauses = ['1=1'];
$params = [];

if (!empty($keyword)) {
    $where_clauses[] = "(b.build_no LIKE ? OR b.project LIKE ? OR b.status LIKE ?)";
    array_push($params, "%$keyword%", "%$keyword%", "%$keyword%");
}
if (!empty($s_build_no)) {
    $where_clauses[] = "b.build_no LIKE ?";
    $params[] = "%$s_build_no%";
}
if (!empty($s_project)) {
    $where_clauses[] = "b.project LIKE ?";
    $params[] = "%$s_project%";
}
if (!empty($s_status)) {
    $where_clauses[] = "b.status = ?";
    $params[] = "$s_status";
}

$where_sql = implode(" AND ", $where_clauses);

$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM builds b WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_records / $limit));

if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

$sort_by = trim((string) ($_GET['sort_by'] ?? 'created_at'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

$valid_sort_columns = ['id', 'build_no', 'project', 'status', 'supported_by', 'build_from', 'created_at'];
if (!in_array($sort_by, $valid_sort_columns, true)) { $sort_by = 'created_at'; }
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) { $sort_dir = 'DESC'; }

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

$builds_stmt = $pdo->prepare("
    SELECT
        b.*,
        creator.first_name AS creator_first,
        creator.last_name AS creator_last,
        builder.first_name AS builder_first,
        builder.last_name AS builder_last
    FROM builds b
    LEFT JOIN users creator ON b.user_id = creator.id
    LEFT JOIN users builder ON b.build_by = builder.id
    WHERE $where_sql
    ORDER BY `$sort_by` $sort_dir
    LIMIT $limit OFFSET $start
");
$builds_stmt->execute($params);
$builds = $builds_stmt->fetchAll(PDO::FETCH_ASSOC);

$page_title = "New Build Management - InfraVault";

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<style>

.bd-alert {
    padding: 13px 18px;
    border-radius: 10px;
    font-size: 14px;
    font-weight: 500;
    margin-bottom: 20px;
    border: 1px solid transparent;
}

.bd-alert.success {
    background: #ECFDF5;
    border-color: #A7F3D0;
    color: #047857;
}

.bd-alert.error {
    background: #FEF2F2;
    border-color: #FECACA;
    color: #B91C1C;
}

.bd-form-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 18px;
    margin-bottom: 18px;
}

.bd-field label {
    display: block;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 7px;
}

.bd-field small {
    display: block;
    margin-top: 6px;
    color: var(--text-muted);
    font-size: 12px;
}

.bd-field input[type="text"],
.bd-field input[type="file"],
.bd-field select,
.bd-field textarea {
    width: 100%;
    padding: 10px 12px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    font-family: inherit;
    font-size: 14px;
    color: var(--text-primary);
    background: var(--hover-bg);
    transition: .15s;
    box-sizing: border-box;
}

.bd-field textarea {
    min-height: 100px;
    resize: vertical;
}

.bd-field input:focus,
.bd-field select:focus,
.bd-field textarea:focus {
    outline: none;
    border-color: #2563EB;
    background: var(--bg-content);
    box-shadow: 0 0 0 3px rgba(37,99,235,.12);
}

.bd-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    border: none;
    border-radius: 9px;
    padding: 11px 20px;
    font-size: 14px;
    font-weight: 600;
    cursor: pointer;
    font-family: inherit;
    transition: .15s;
}

.bd-btn-primary {
    background: #2563EB;
    color: #fff;
}

.bd-btn-primary:hover {
    background: #1D4ED8;
}

.bd-btn-info {
    background: #EEF2FF;
    color: #4338CA;
}

.bd-btn-info:hover {
    background: #E0E7FF;
}

.bd-btn-warning {
    background: #FEF3C7;
    color: #D97706;
}

.bd-btn-warning:hover {
    background: #FDE68A;
}

.bd-btn-danger {
    background: #FEF2F2;
    color: #DC2626;
}

.bd-btn-danger:hover {
    background: #FEE2E2;
}

.bd-btn-ghost {
    background: var(--hover-bg);
    color: var(--text-primary);
}

.bd-btn-ghost:hover {
    background: var(--border-color);
}

.bd-icon-btn{width:34px;height:34px;padding:7px}.bd-icon-btn svg{width:18px;height:18px;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.bd-btn-history {
    background: #EEF2FF;
    color: #4338CA;
}

.bd-btn-history:hover {
    background: #E0E7FF;
}

.bd-btn-sm {
    padding: 7px 12px;
    font-size: 12.5px;
    border-radius: 7px;
}

.bd-btn-sm.active {
    background: #2563EB;
    color: #fff;
}

.bd-btn-sm.bd-icon-btn {
    width: 34px;
    height: 34px;
    padding: 7px;
    font-size: 14px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
}

.row-actions {
    display: flex;
    gap: 6px;
    flex-wrap: wrap;
    justify-content: center;
}

.bd-table-wrap {
    overflow-x: auto;
}

table.bd-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 13.5px;
}

table.bd-table thead th {
    text-align: left;
    padding: 13px 16px;
    background: var(--hover-bg);
    color: var(--text-secondary);
    font-weight: 600;
    font-size: 12.5px;
    text-transform: uppercase;
    letter-spacing: .03em;
    border-bottom: 1px solid var(--border-color);
    white-space: nowrap;
}

table.bd-table tbody td {
    padding: 14px 16px;
    border-bottom: 1px solid var(--border-light);
    color: var(--text-primary);
    vertical-align: middle;
}

table.bd-table tbody tr:last-child td {
    border-bottom: none;
}

table.bd-table tbody tr:hover {
    background: #FAFBFF;
}

table.bd-table tbody td.cell-primary {
    font-weight: 600;
}

.bd-empty {
    text-align: center;
    padding: 40px 20px;
    color: var(--text-muted);
    font-size: 14px;
}

.bd-badge {
    display: inline-block;
    padding: 4px 11px;
    border-radius: 20px;
    font-size: 11.5px;
    font-weight: 700;
    white-space: nowrap;
}

.bd-badge.st-inprogress {
    background: #EEF2FF;
    color: #4338CA;
}

.bd-badge.st-completed {
    background: #ECFDF5;
    color: #047857;
}

.bd-badge.st-onhold {
    background: #FFF7ED;
    color: #C2410C;
}

.bd-badge.st-cancelled {
    background: #FEF2F2;
    color: #B91C1C;
}

.bd-file-chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: var(--hover-bg);
    padding: 7px 13px;
    border-radius: 8px;
    font-size: 13px;
    margin: 0 8px 8px 0;
    text-decoration: none;
    color: #2563EB;
    font-weight: 500;
    transition: .15s;
}

.bd-file-chip:hover {
    background: var(--border-color);
}

.bd-view-only {
    color: var(--text-muted);
    font-size: 12.5px;
    font-style: italic;
}

.bd-modal {
    display: none;
    position: fixed;
    inset: 0;
    z-index: 3000;
    background: rgba(15, 23, 42, .5);
    overflow-y: auto;
    padding: 40px 20px;
}

.bd-modal-content {
    background: var(--bg-content);
    margin: 0 auto;
    max-width: 720px;
    width: 100%;
    border-radius: 18px;
    padding: 28px 30px;
    box-shadow: 0 20px 60px rgba(15,23,42,.25);
    position: relative;
    box-sizing: border-box;
}

#newBuildModal .bd-modal-content {
    max-width: 900px;
}

.bd-modal-wide {
    max-width: 1050px;
}

.bd-modal-close {
    position: absolute;
    top: 20px;
    right: 24px;
    font-size: 22px;
    color: var(--text-muted);
    cursor: pointer;
    line-height: 1;
    background: none;
    border: none;
}

.bd-modal-close:hover {
    color: var(--text-primary);
}

.bd-modal-title {
    font-size: 19px;
    font-weight: 700;
    color: var(--text-primary);
    margin-bottom: 20px;
    padding-right: 30px;
}

.bd-detail-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16px;
}

.bd-detail-box {
    background: var(--hover-bg);
    border: 1px solid var(--border-color);
    border-radius: 10px;
    padding: 13px 15px;
}

.bd-detail-label {
    font-size: 11px;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: var(--text-secondary);
    font-weight: 700;
    margin-bottom: 5px;
}

.bd-detail-value {
    color: var(--text-primary);
    font-size: 14px;
    white-space: pre-wrap;
}

.bd-history-item {
    border: 1px solid var(--border-color);
    border-radius: 11px;
    padding: 15px;
    margin-bottom: 10px;
    background: var(--bg-content);
}

.bd-history-top {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 15px;
    margin-bottom: 7px;
}

.bd-history-action {
    font-weight: 700;
    color: var(--text-primary);
}

.bd-history-date {
    color: var(--text-muted);
    font-size: 12px;
}

.bd-history-user {
    font-size: 12.5px;
    color: #2563EB;
    font-weight: 600;
    margin-bottom: 7px;
}

.bd-history-change {
    color: var(--text-secondary);
    font-size: 13px;
    white-space: pre-wrap;
    line-height: 1.6;
}

.bd-history-created {
    color: #047857;
}

.bd-history-updated {
    color: #4338CA;
}

.bd-history-deleted {
    color: #DC2626;
}

.bd-loading {
    text-align: center;
    padding: 30px;
    color: var(--text-muted);
}

.bd-global-actions {
    display: flex;
    gap: 8px;
    align-items: center;
}

/* Search bar styles */
.bd-search-container {
    display: flex;
    gap: 12px;
    align-items: center;
    margin-bottom: 20px;
    flex-wrap: wrap;
}

.bd-search-input {
    flex: 1;
    min-width: 250px;
    padding: 10px 16px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    font-size: 14px;
    background: var(--hover-bg);
    transition: .15s;
    font-family: inherit;
}

.bd-search-input:focus {
    outline: none;
    border-color: #2563EB;
    background: var(--bg-content);
    box-shadow: 0 0 0 3px rgba(37,99,235,.12);
}

.bd-search-input::placeholder {
    color: var(--text-muted);
}

.bd-search-clear {
    display: none;
    background: var(--hover-bg);
    border: 1px solid var(--border-color);
    border-radius: 9px;
    padding: 10px 16px;
    cursor: pointer;
    font-size: 14px;
    color: var(--text-secondary);
    transition: .15s;
    font-family: inherit;
}

.bd-search-clear:hover {
    background: var(--border-color);
}

.bd-search-clear.visible {
    display: inline-flex;
}

.bd-search-results {
    font-size: 13px;
    color: var(--text-secondary);
    margin-left: auto;
}

@media (max-width: 900px) {

    .bd-form-grid {
        grid-template-columns: 1fr;
    }

    .bd-detail-grid {
        grid-template-columns: 1fr;
    }

    .bd-global-actions {
        margin-top: 10px;
        flex-wrap: wrap;
    }

    .bd-search-container {
        flex-direction: column;
        align-items: stretch;
    }

    .bd-search-input {
        min-width: unset;
    }

    .bd-search-results {
        margin-left: 0;
    }
}

[data-theme="dark"] .bd-alert.success {
    background: #123528;
    border-color: #1f5a3e;
    color: #4CC49A;
}

[data-theme="dark"] .bd-alert.error {
    background: #3a1a1a;
    border-color: #5c2a2a;
    color: #F1837A;
}

[data-theme="dark"] .bd-btn-info,
[data-theme="dark"] .bd-btn-history {
    background: #1e2a4a;
    color: #7BA6FF;
}

[data-theme="dark"] .bd-btn-info:hover,
[data-theme="dark"] .bd-btn-history:hover {
    background: #29365a;
}

[data-theme="dark"] .bd-btn-warning {
    background: #3a2a14;
    color: #F5B054;
}

[data-theme="dark"] .bd-btn-warning:hover {
    background: #4a3620;
}

[data-theme="dark"] .bd-btn-danger {
    background: #3a1a1a;
    color: #F1837A;
}

[data-theme="dark"] .bd-btn-danger:hover {
    background: #4a2323;
}

[data-theme="dark"] .bd-badge.st-inprogress {
    background: #1e2a4a;
    color: #7BA6FF;
}

[data-theme="dark"] .bd-badge.st-completed {
    background: #123528;
    color: #4CC49A;
}

[data-theme="dark"] .bd-badge.st-onhold {
    background: #3a2a14;
    color: #F5B054;
}

[data-theme="dark"] .bd-badge.st-cancelled {
    background: #3a1a1a;
    color: #F1837A;
}

[data-theme="dark"] table.bd-table tbody tr:hover {
    background: var(--hover-bg);
}

</style>

<div class="content">

    <div class="dashboard-header">

        <div>
            <h1>Builds Management</h1>
            <p>
                Register and track infrastructure builds, ownership,
                supporting documentation, comments, and history.
            </p>
        </div>

        <div class="bd-global-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="bd-btn bd-btn-primary" onclick="openNewBuildModal()" title="Create a new build record">+ Add Record</button>
            <?php endif; ?>
            <?php if ($canImport): ?>
                <button type="button" class="bd-btn bd-btn-info" onclick="openImportModal()" title="Import builds from CSV">Import CSV</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <button type="button" class="bd-btn bd-btn-info" onclick="openExportModal()" title="Export build records">Export CSV</button>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="bd-btn bd-btn-warning" onclick="openGlobalHistoryModal()" title="View global build history">⏱ History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($success_msg): ?>

        <div class="bd-alert success">
            <?= htmlspecialchars($success_msg) ?>
        </div>

    <?php endif; ?>

    <?php if ($error_msg): ?>

        <div class="bd-alert error">
            <?= htmlspecialchars($error_msg) ?>
        </div>

    <?php endif; ?>


    <!-- Search & Filters Panel -->
    <div class="dashboard-panel" style="margin-bottom:22px;">

        <div class="panel-header" style="margin-bottom:14px;">
            <h3 class="panel-title" style="margin:0;">Search & Filters</h3>
            <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">
                Search Multiple Values &#9662;
            </span>
        </div>

        <form method="GET" action="builds.php" style="display:flex;gap:10px;flex-wrap:wrap;">
            <input type="text" name="keyword" class="bd-search-input" style="flex:1;min-width:250px;" placeholder="Search build no, project, status..." value="<?= htmlspecialchars($keyword, ENT_QUOTES) ?>">
            <button type="submit" class="bd-btn bd-btn-primary">Search</button>
            <?php if ($keyword !== '' || $s_build_no !== '' || $s_project !== '' || $s_status !== ''): ?>
                <a href="builds.php" class="bd-btn bd-btn-ghost">Clear</a>
            <?php endif; ?>
        </form>

        <div id="advancedSearchPanel" style="display:<?= ($s_build_no !== '' || $s_project !== '' || $s_status !== '') ? 'block' : 'none' ?>;margin-top:18px;padding:20px;background:var(--hover-bg);border-radius:10px;border:1px solid var(--border-color);">
            <form method="GET" action="builds.php" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;">
                <div class="bd-field">
                    <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Build No</label>
                    <input type="text" name="s_build_no" class="bd-search-input" placeholder="Build No..." value="<?= htmlspecialchars($s_build_no, ENT_QUOTES) ?>">
                </div>
                <div class="bd-field">
                    <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Project</label>
                    <input type="text" name="s_project" class="bd-search-input" placeholder="Project..." value="<?= htmlspecialchars($s_project, ENT_QUOTES) ?>">
                </div>
                <div class="bd-field">
                    <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Status</label>
                    <select name="s_status" class="bd-search-input">
                        <option value="">All Statuses</option>
                        <option value="In Progress" <?= $s_status === 'In Progress' ? 'selected' : '' ?>>In Progress</option>
                        <option value="Completed" <?= $s_status === 'Completed' ? 'selected' : '' ?>>Completed</option>
                        <option value="On Hold" <?= $s_status === 'On Hold' ? 'selected' : '' ?>>On Hold</option>
                        <option value="Cancelled" <?= $s_status === 'Cancelled' ? 'selected' : '' ?>>Cancelled</option>
                    </select>
                </div>
                <div style="grid-column:1/-1;display:flex;gap:10px;flex-wrap:wrap;">
                    <button type="submit" class="bd-btn bd-btn-primary" style="flex:1;min-width:120px;">🔍 Apply Filters</button>
                    <a href="builds.php" class="bd-btn bd-btn-ghost" style="flex:1;min-width:120px;text-align:center;">↺ Reset</a>
                </div>
            </form>
        </div>

    </div>

    <!-- Existing Builds -->

    <div class="dashboard-panel" style="padding-bottom:8px;">

        <div class="panel-header">
            <h3>Infrastructure Builds Directory</h3>
            <span id="buildCount"><?= (int)$total_records ?> total</span>
        </div>

        <div class="bd-table-wrap">

            <table class="bd-table" id="buildsTable">

                <thead>

                    <tr>

                        <th>
                            <a href="builds.php?sort_by=build_no&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                Build No
                                <?php if ($sort_by === 'build_no'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            <a href="builds.php?sort_by=project&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                Project
                                <?php if ($sort_by === 'project'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            <a href="builds.php?sort_by=status&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                Status
                                <?php if ($sort_by === 'status'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            Build By
                        </th>

                        <th>
                            <a href="builds.php?sort_by=supported_by&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                Supported By
                                <?php if ($sort_by === 'supported_by'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            <a href="builds.php?sort_by=build_from&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                From
                                <?php if ($sort_by === 'build_from'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            Created By
                        </th>

                        <th>
                            <a href="builds.php?sort_by=created_at&sort_dir=<?= $next_sort_dir ?>&page=1<?php echo ($keyword ? '&keyword='.urlencode($keyword) : '').($s_build_no ? '&s_build_no='.urlencode($s_build_no) : '').($s_project ? '&s_project='.urlencode($s_project) : '').($s_status ? '&s_status='.urlencode($s_status) : ''); ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                                Created Date
                                <?php if ($sort_by === 'created_at'): ?>
                                    <span style="color:#2563EB;"><?= $sort_dir === 'ASC' ? '↑' : '↓' ?></span>
                                <?php endif; ?>
                            </a>
                        </th>

                        <th>
                            Attachments
                        </th>

                        <th style="text-align:center;">
                            Actions
                        </th>

                    </tr>

                </thead>


                <tbody id="buildsTableBody">

                    <?php if (count($builds) > 0): ?>

                        <?php foreach ($builds as $b): ?>

                            <?php
                            $att_query = $pdo->prepare("SELECT * FROM build_attachments WHERE build_id = ?");
                            $att_query->execute([$b['id']]);
                            $attachments = $att_query->fetchAll(PDO::FETCH_ASSOC);

                            $status_class = 'st-inprogress';
                            switch ($b['status']) {
                                case 'Completed': $status_class = 'st-completed'; break;
                                case 'On Hold': $status_class = 'st-onhold'; break;
                                case 'Cancelled': $status_class = 'st-cancelled'; break;
                            }

                            $created_by = trim(($b['creator_first'] ?? '') . ' ' . ($b['creator_last'] ?? '')) ?: 'Unknown User';
                            $builder_name = trim(($b['builder_first'] ?? '') . ' ' . ($b['builder_last'] ?? '')) ?: 'Unknown User';
                            ?>

                            <tr>

                                <td class="cell-primary">
                                    <strong><?= htmlspecialchars($b['build_no']) ?></strong>
                                </td>

                                <td>
                                    <?= htmlspecialchars($b['project']) ?>
                                </td>

                                <td>
                                    <span class="bd-badge <?= $status_class ?>">
                                        <?= htmlspecialchars($b['status']) ?>
                                    </span>
                                </td>

                                <td>
                                    <?= htmlspecialchars($builder_name) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($b['supported_by'] ?: '-') ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($b['build_from'] ?: '-') ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($created_by) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($b['created_at']) ?>
                                </td>

                                <td>
                                    <button type="button" class="bd-btn bd-btn-ghost bd-btn-sm" onclick='openViewModal(<?= json_encode($attachments, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>, <?= json_encode($b['build_no']) ?>)'>
                                        📄 Docs (<?= count($attachments) ?>)
                                    </button>
                                </td>

                                <td style="white-space:nowrap;text-align:center;">
                                    <div class="row-actions">
                                        <button type="button" class="bd-btn bd-btn-ghost bd-btn-sm bd-icon-btn" onclick='openDetailsModal(<?= json_encode($b, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>)' title="View build record" aria-label="View">👁</button>
                                        <?php if ($canEdit): ?>
                                            <button type="button" class="bd-btn bd-btn-primary bd-btn-sm bd-icon-btn" title="Edit" aria-label="Edit" onclick='openEditModal(<?= json_encode($b, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?>)'>✎</button>
                                        <?php endif; ?>
                                        <?php if ($canDelete): ?>
                                            <form method="POST" style="display:inline;" onsubmit="return confirm('Are you sure you want to delete this build record?');">
                                                <input type="hidden" name="action" value="delete_build">
                                                <input type="hidden" name="build_id" value="<?= (int)$b['id'] ?>">
                                                <button type="submit" class="bd-btn bd-btn-danger bd-btn-sm bd-icon-btn" title="Delete" aria-label="Delete">🗑</button>
                                            </form>
                                        <?php endif; ?>
                                        <?php if ($canAudit): ?>
                                            <button type="button" class="bd-btn bd-btn-warning bd-btn-sm bd-icon-btn" title="Audit History" aria-label="History" onclick="openHistoryModal(<?= (int)$b['id'] ?>, <?= json_encode($b['build_no']) ?>)">⏱</button>
                                        <?php endif; ?>
                                    </div>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php else: ?>

                        <tr>
                            <td colspan="10" class="bd-empty">
                                No builds registered yet.
                            </td>
                        </tr>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

        <!-- Pagination & Rows Per Page -->
        <?php if ($total_pages > 1 || $limit != 15): ?>
            <div style="padding:22px;border-top:1px solid var(--border-color);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:15px;">
                <div style="font-size:13px;color:var(--text-secondary);">
                    Showing <?= min($start + 1, max(0, $total_records)) ?> - <?= min($start + $limit, $total_records) ?> of <?= (int)$total_records ?> records
                </div>
                <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;">
                    <?php
                        $builds_hidden_fields = '';
                        foreach ([
                            'keyword' => $keyword,
                            's_build_no' => $s_build_no,
                            's_project' => $s_project,
                            's_status' => $s_status,
                            'sort_by' => $sort_by,
                            'sort_dir' => $sort_dir,
                        ] as $bfk => $bfv) {
                            if ($bfv !== '') {
                                $builds_hidden_fields .= '<input type="hidden" name="' . htmlspecialchars($bfk) . '" value="' . htmlspecialchars($bfv) . '">';
                            }
                        }
                    ?>
                    <?= pageSizeSelectorHtml($page_size, $builds_hidden_fields) ?>
                    <?= ivPager($page, $total_pages, array_filter([
                        'page_size'  => $page_size,
                        'keyword'    => $keyword,
                        's_build_no' => $s_build_no,
                        's_project'  => $s_project,
                        's_status'   => $s_status,
                        'sort_by'    => $sort_by,
                        'sort_dir'   => $sort_dir,
                    ], static fn($v) => $v !== '' && $v !== null),
                    ['base' => 'builds.php', 'total_records' => $total_records ?? null, 'per_page' => $page_size]) ?>
                </div>
            </div>
        <?php endif; ?>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| NEW BUILD RECORD MODAL
|--------------------------------------------------------------------------
-->

<div
    id="newBuildModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            type="button"
            class="bd-modal-close"
            onclick="closeNewBuildModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Register New Infrastructure Build
        </h2>

        <form
            method="POST"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="action"
                value="create_build"
            >

            <div class="bd-form-grid">

                <div class="bd-field">

                    <label>
                        Build No *
                    </label>

                    <input
                        type="text"
                        name="build_no"
                        placeholder="e.g., BLD-2026-001"
                        required
                    >

                </div>

                <div class="bd-field">

                    <label>
                        Project *
                    </label>

                    <input
                        type="text"
                        name="project"
                        placeholder="Project Name"
                        required
                    >

                </div>

                <div class="bd-field">

                    <label>
                        Status *
                    </label>

                    <select
                        name="status"
                        required
                    >

                        <option value="In Progress">
                            In Progress
                        </option>

                        <option value="Completed">
                            Completed
                        </option>

                        <option value="On Hold">
                            On Hold
                        </option>

                        <option value="Cancelled">
                            Cancelled
                        </option>

                    </select>

                </div>

            </div>


            <div class="bd-form-grid">

                <div class="bd-field">

                    <label>
                        Build By *
                    </label>

                    <select
                        name="build_by"
                        required
                    >

                        <option value="">
                            -- Select Portal User --
                        </option>

                        <?php foreach ($all_portal_users as $usr): ?>

                            <option
                                value="<?= (int)$usr['id'] ?>"
                            >

                                <?= htmlspecialchars(
                                    trim(
                                        $usr['first_name'] .
                                        ' ' .
                                        $usr['last_name']
                                    )
                                ) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="bd-field">

                    <label>
                        Supported By
                    </label>

                    <select name="supported_by">

                        <option value="">
                            -- Select Support Team --
                        </option>

                        <?php foreach ($support_options as $opt): ?>

                            <option
                                value="<?= htmlspecialchars($opt) ?>"
                            >

                                <?= htmlspecialchars($opt) ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>


                <div class="bd-field">

                    <label>
                        From
                    </label>

                    <select name="build_from">

                        <option value="">
                            -- Select Source/Stage --
                        </option>

                        <option value="provisioning team">
                            Provisioning Team
                        </option>

                        <option value="others">
                            Others
                        </option>

                        <option value="handedover">
                            Handedover
                        </option>

                    </select>

                </div>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:20px;"
            >

                <label>
                    Comments
                </label>

                <textarea
                    name="comments"
                    placeholder="Add comments or additional information..."
                ></textarea>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:20px;"
            >

                <label>
                    Attachments
                </label>

                <input
                    type="file"
                    name="attachments[]"
                    multiple
                >

                <small>
                    You can select multiple files.
                </small>

            </div>


            <div
                style="
                    display:flex;
                    justify-content:flex-end;
                    gap:10px;
                    margin-top:10px;
                "
            >

                <button
                    type="button"
                    class="bd-btn bd-btn-ghost"
                    onclick="closeNewBuildModal()"
                >
                    Cancel
                </button>

                <button
                    type="submit"
                    class="bd-btn bd-btn-primary"
                >
                    Create Build Record
                </button>

            </div>

        </form>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| VIEW ATTACHMENTS MODAL
|--------------------------------------------------------------------------
-->

<div
    id="viewAttachmentsModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            class="bd-modal-close"
            onclick="closeViewModal()"
        >
            &times;
        </button>

        <h2
            id="viewModalTitle"
            class="bd-modal-title"
        >
            Attached Documents
        </h2>

        <div id="attachmentsListContainer"></div>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| VIEW DETAILS MODAL
|--------------------------------------------------------------------------
-->

<div
    id="detailsModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            class="bd-modal-close"
            onclick="closeDetailsModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Build Details
        </h2>

        <div
            id="detailsContainer"
            class="bd-detail-grid"
        ></div>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
-->

<div
    id="editModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            class="bd-modal-close"
            onclick="closeEditModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Edit Infrastructure Build
        </h2>


        <form
            method="POST"
            enctype="multipart/form-data"
        >

            <input
                type="hidden"
                name="action"
                value="update_build"
            >

            <input
                type="hidden"
                name="build_id"
                id="edit_build_id"
            >


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Build No *
                </label>

                <input
                    type="text"
                    name="build_no"
                    id="edit_build_no"
                    required
                >

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Project *
                </label>

                <input
                    type="text"
                    name="project"
                    id="edit_project"
                    required
                >

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Status *
                </label>

                <select
                    name="status"
                    id="edit_status"
                    required
                >

                    <option value="In Progress">
                        In Progress
                    </option>

                    <option value="Completed">
                        Completed
                    </option>

                    <option value="On Hold">
                        On Hold
                    </option>

                    <option value="Cancelled">
                        Cancelled
                    </option>

                </select>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Build By *
                </label>

                <select
                    name="build_by"
                    id="edit_build_by"
                    required
                >

                    <option value="">
                        -- Select Portal User --
                    </option>

                    <?php foreach ($all_portal_users as $usr): ?>

                        <option
                            value="<?= (int)$usr['id'] ?>"
                        >
                            <?= htmlspecialchars(
                                trim(
                                    $usr['first_name'] .
                                    ' ' .
                                    $usr['last_name']
                                )
                            ) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Supported By
                </label>

                <select
                    name="supported_by"
                    id="edit_supported_by"
                >

                    <option value="">
                        -- Select Support Team --
                    </option>

                    <?php foreach ($support_options as $opt): ?>

                        <option
                            value="<?= htmlspecialchars($opt) ?>"
                        >
                            <?= htmlspecialchars($opt) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    From
                </label>

                <select
                    name="build_from"
                    id="edit_build_from"
                >

                    <option value="">
                        -- Select Source/Stage --
                    </option>

                    <option value="provisioning team">
                        Provisioning Team
                    </option>

                    <option value="others">
                        Others
                    </option>

                    <option value="handedover">
                        Handedover
                    </option>

                </select>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:16px;"
            >

                <label>
                    Comments
                </label>

                <textarea
                    name="comments"
                    id="edit_comments"
                    placeholder="Add comments or additional information..."
                ></textarea>

            </div>


            <div
                class="bd-field"
                style="margin-bottom:20px;"
            >

                <label>
                    Add More Attachments
                </label>

                <input
                    type="file"
                    name="attachments[]"
                    multiple
                >

            </div>


            <button
                type="submit"
                class="bd-btn bd-btn-primary"
            >
                Update Build Record
            </button>

        </form>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| RECORD HISTORY MODAL
|--------------------------------------------------------------------------
-->

<div
    id="historyModal"
    class="bd-modal"
>

    <div class="bd-modal-content bd-modal-wide">

        <button
            class="bd-modal-close"
            onclick="closeHistoryModal()"
        >
            &times;
        </button>

        <h2
            id="historyModalTitle"
            class="bd-modal-title"
        >
            Build History
        </h2>

        <div id="historyContainer">

            <div class="bd-loading">
                Loading history...
            </div>

        </div>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| GLOBAL HISTORY MODAL
|--------------------------------------------------------------------------
-->

<div
    id="globalHistoryModal"
    class="bd-modal"
>

    <div class="bd-modal-content bd-modal-wide">

        <button
            class="bd-modal-close"
            onclick="closeGlobalHistoryModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Global Build History
        </h2>

        <div id="globalHistoryContainer">

            <div class="bd-loading">
                Loading history...
            </div>

        </div>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| EXPORT MODAL
|--------------------------------------------------------------------------
-->

<div
    id="exportModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            class="bd-modal-close"
            onclick="closeExportModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Export Builds
        </h2>

        <form
            method="POST"
            action="builds.php"
        >

            <input type="hidden" name="action" value="export_builds">
            <input type="hidden" name="keyword" value="<?= htmlspecialchars($keyword, ENT_QUOTES) ?>">
            <input type="hidden" name="s_build_no" value="<?= htmlspecialchars($s_build_no, ENT_QUOTES) ?>">
            <input type="hidden" name="s_project" value="<?= htmlspecialchars($s_project, ENT_QUOTES) ?>">
            <input type="hidden" name="s_status" value="<?= htmlspecialchars($s_status, ENT_QUOTES) ?>">

            <p style="color:var(--text-secondary);margin-bottom:20px;">
                Export <?= (int)$total_records ?> record<?= $total_records === 1 ? '' : 's' ?> <?= ($keyword || $s_build_no || $s_project || $s_status) ? 'matching your filters' : '' ?> to CSV.
            </p>

            <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:20px;">
                <button type="button" class="bd-btn bd-btn-ghost" onclick="closeExportModal()">Cancel</button>
                <button type="submit" class="bd-btn bd-btn-info">Export CSV</button>
            </div>

        </form>

    </div>

</div>


<!--
|--------------------------------------------------------------------------
| IMPORT CSV MODAL
|--------------------------------------------------------------------------
-->

<div
    id="importModal"
    class="bd-modal"
>

    <div class="bd-modal-content">

        <button
            class="bd-modal-close"
            onclick="closeImportModal()"
        >
            &times;
        </button>

        <h2 class="bd-modal-title">
            Import Builds from CSV
        </h2>

        <form
            action="builds-import.php"
            method="POST"
            enctype="multipart/form-data"
        >

            <div class="bd-field" style="margin-bottom:16px;">
                <label>CSV File *</label>
                <input type="file" name="csv_file" class="bd-search-input" accept=".csv" required>
            </div>

            <div style="background:var(--hover-bg);border:1px solid var(--border-color);border-radius:10px;padding:16px;margin-bottom:20px;">
                <p style="font-weight:600;color:var(--text-primary);margin:0 0 10px;">Expected CSV Format:</p>
                <code style="display:block;background:var(--hover-bg);padding:10px;border-radius:6px;overflow-x:auto;font-size:12px;">
build_no,project,status,build_by,supported_by,build_from,comments
                </code>
                <p style="font-size:12px;color:var(--text-secondary);margin:10px 0 0;">build_by is user ID, status must be one of: In Progress, Completed, On Hold, Cancelled</p>
            </div>

            <div style="display:flex;justify-content:flex-end;gap:10px;">
                <button type="button" class="bd-btn bd-btn-ghost" onclick="closeImportModal()">Cancel</button>
                <button type="submit" class="bd-btn bd-btn-info">Upload CSV</button>
            </div>

        </form>

    </div>

</div>


<script>

/*
|--------------------------------------------------------------------------
| ESCAPE HTML
|--------------------------------------------------------------------------
*/

function escapeHtml(value) {

    if (value === null || value === undefined) {
        return '';
    }

    return String(value)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}


/*
|--------------------------------------------------------------------------
| NEW BUILD RECORD MODAL
|--------------------------------------------------------------------------
*/

function openNewBuildModal() {

    document.getElementById(
        'newBuildModal'
    ).style.display = 'block';
}


function closeNewBuildModal() {

    document.getElementById(
        'newBuildModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| VIEW ATTACHMENTS
|--------------------------------------------------------------------------
*/

function openViewModal(attachments, buildNo) {

    document.getElementById('viewModalTitle').innerText =
        'Attached Documents for ' + buildNo;

    let container =
        document.getElementById('attachmentsListContainer');

    container.innerHTML = '';

    if (!attachments || attachments.length === 0) {

        container.innerHTML =
            '<p style="color:var(--text-muted);font-style:italic;font-size:13.5px;">' +
            'No documents attached to this build.' +
            '</p>';

    } else {

        let listHtml = '';

        attachments.forEach(function(att) {

            listHtml +=
                '<a href="' +
                escapeHtml(att.filepath) +
                '" class="bd-file-chip" target="_blank">' +
                '📄 ' +
                escapeHtml(att.filename) +
                '</a>';

        });

        container.innerHTML = listHtml;
    }

    document.getElementById(
        'viewAttachmentsModal'
    ).style.display = 'block';
}


function closeViewModal() {

    document.getElementById(
        'viewAttachmentsModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| VIEW DETAILS
|--------------------------------------------------------------------------
*/

function openDetailsModal(build) {

    const createdBy =
        (
            (build.creator_first || '') +
            ' ' +
            (build.creator_last || '')
        ).trim() || 'Unknown User';


    const buildBy =
        (
            (build.builder_first || '') +
            ' ' +
            (build.builder_last || '')
        ).trim() || 'Unknown User';


    let html = '';

    html += detailBox(
        'Build No',
        build.build_no
    );

    html += detailBox(
        'Project',
        build.project
    );

    html += detailBox(
        'Status',
        build.status
    );

    html += detailBox(
        'Build By',
        buildBy
    );

    html += detailBox(
        'Supported By',
        build.supported_by || '-'
    );

    html += detailBox(
        'From',
        build.build_from || '-'
    );

    html += detailBox(
        'Created By',
        createdBy
    );

    html += detailBox(
        'Created Date',
        build.created_at || '-'
    );

    html +=
        '<div class="bd-detail-box" style="grid-column:1/-1;">' +
            '<div class="bd-detail-label">Comments</div>' +
            '<div class="bd-detail-value">' +
                escapeHtml(build.comments || '-') +
            '</div>' +
        '</div>';

    document.getElementById(
        'detailsContainer'
    ).innerHTML = html;

    document.getElementById(
        'detailsModal'
    ).style.display = 'block';
}


function detailBox(label, value) {

    return (
        '<div class="bd-detail-box">' +
            '<div class="bd-detail-label">' +
                escapeHtml(label) +
            '</div>' +
            '<div class="bd-detail-value">' +
                escapeHtml(value || '-') +
            '</div>' +
        '</div>'
    );
}


function closeDetailsModal() {

    document.getElementById(
        'detailsModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
*/

function openEditModal(build) {

    document.getElementById(
        'edit_build_id'
    ).value = build.id;

    document.getElementById(
        'edit_build_no'
    ).value = build.build_no || '';

    document.getElementById(
        'edit_project'
    ).value = build.project || '';

    document.getElementById(
        'edit_status'
    ).value = build.status || 'In Progress';

    document.getElementById(
        'edit_build_by'
    ).value = build.build_by || '';

    document.getElementById(
        'edit_supported_by'
    ).value = build.supported_by || '';

    document.getElementById(
        'edit_build_from'
    ).value = build.build_from || '';

    document.getElementById(
        'edit_comments'
    ).value = build.comments || '';

    document.getElementById(
        'editModal'
    ).style.display = 'block';
}


function closeEditModal() {

    document.getElementById(
        'editModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| RECORD HISTORY
|--------------------------------------------------------------------------
*/

function openHistoryModal(buildId, buildNo) {

    document.getElementById(
        'historyModalTitle'
    ).innerText =
        'History - ' + buildNo;

    const container =
        document.getElementById(
            'historyContainer'
        );

    container.innerHTML =
        '<div class="bd-loading">Loading history...</div>';

    document.getElementById(
        'historyModal'
    ).style.display = 'block';


    const formData = new FormData();

    formData.append(
        'action',
        'get_history'
    );

    formData.append(
        'build_id',
        buildId
    );


    fetch(window.location.href, {

        method: 'POST',
        body: formData,
        credentials: 'same-origin'

    })
    .then(function(response) {

        return response.text();

    })
    .then(function(text) {

        let data;

        try {

            data = JSON.parse(text);

        } catch (error) {

            throw new Error(
                'Invalid server response.'
            );
        }

        if (!data.success) {

            throw new Error(
                data.message ||
                'Unable to load history.'
            );
        }

        renderHistory(
            data.history,
            container
        );

    })
    .catch(function(error) {

        container.innerHTML =
            '<div class="bd-alert error">' +
            escapeHtml(
                error.message ||
                'Unable to load history.'
            ) +
            '</div>';

    });
}


/*
|--------------------------------------------------------------------------
| RENDER HISTORY
|--------------------------------------------------------------------------
*/

function renderHistory(history, container) {

    if (!history || history.length === 0) {

        container.innerHTML =
            '<div class="bd-loading">' +
            'No history available for this record.' +
            '</div>';

        return;
    }


    let html = '';

    history.forEach(function(item) {

        let actionClass = '';

        if (item.action === 'Created') {
            actionClass = 'bd-history-created';
        } else if (item.action === 'Updated') {
            actionClass = 'bd-history-updated';
        } else if (item.action === 'Deleted') {
            actionClass = 'bd-history-deleted';
        }


        html +=
            '<div class="bd-history-item">' +

                '<div class="bd-history-top">' +

                    '<div class="bd-history-action ' +
                        actionClass +
                    '">' +
                        escapeHtml(item.action) +
                    '</div>' +

                    '<div class="bd-history-date">' +
                        escapeHtml(item.created_at) +
                    '</div>' +

                '</div>' +

                '<div class="bd-history-user">' +
                    'By: ' +
                    escapeHtml(
                        item.user_name ||
                        'Unknown User'
                    ) +
                '</div>' +

                '<div class="bd-history-change">' +
                    escapeHtml(
                        item.changes ||
                        ''
                    ) +
                '</div>' +

            '</div>';
    });

    container.innerHTML = html;
}


function closeHistoryModal() {

    document.getElementById(
        'historyModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| GLOBAL HISTORY
|--------------------------------------------------------------------------
*/

function openGlobalHistoryModal() {

    const modal =
        document.getElementById(
            'globalHistoryModal'
        );

    const container =
        document.getElementById(
            'globalHistoryContainer'
        );

    container.innerHTML =
        '<div class="bd-loading">Loading history...</div>';

    modal.style.display = 'block';


    const formData = new FormData();

    formData.append(
        'action',
        'get_global_history'
    );


    fetch(window.location.href, {

        method: 'POST',
        body: formData,
        credentials: 'same-origin'

    })
    .then(function(response) {

        return response.text();

    })
    .then(function(text) {

        let data;

        try {

            data = JSON.parse(text);

        } catch (error) {

            throw new Error(
                'Invalid server response.'
            );
        }

        if (!data.success) {

            throw new Error(
                data.message ||
                'Unable to load history.'
            );
        }


        if (
            !data.history ||
            data.history.length === 0
        ) {

            container.innerHTML =
                '<div class="bd-loading">' +
                'No global history available.' +
                '</div>';

            return;
        }


        let html = '';

        data.history.forEach(function(item) {

            let actionClass = '';

            if (item.action === 'Created') {
                actionClass = 'bd-history-created';
            } else if (item.action === 'Updated') {
                actionClass = 'bd-history-updated';
            } else if (item.action === 'Deleted') {
                actionClass = 'bd-history-deleted';
            }


            html +=
                '<div class="bd-history-item">' +

                    '<div class="bd-history-top">' +

                        '<div class="bd-history-action ' +
                            actionClass +
                        '">' +

                            escapeHtml(
                                item.action
                            ) +

                            ' — ' +

                            escapeHtml(
                                item.build_no ||
                                'Deleted Record'
                            ) +

                        '</div>' +

                        '<div class="bd-history-date">' +
                            escapeHtml(
                                item.created_at
                            ) +
                        '</div>' +

                    '</div>' +


                    '<div class="bd-history-user">' +

                        'User: ' +

                        escapeHtml(
                            item.user_name ||
                            'Unknown User'
                        ) +

                        ' | Project: ' +

                        escapeHtml(
                            item.project ||
                            '-'
                        ) +

                    '</div>' +


                    '<div class="bd-history-change">' +

                        escapeHtml(
                            item.changes ||
                            ''
                        ) +

                    '</div>' +

                '</div>';
        });


        container.innerHTML = html;

    })
    .catch(function(error) {

        container.innerHTML =
            '<div class="bd-alert error">' +
            escapeHtml(
                error.message ||
                'Unable to load global history.'
            ) +
            '</div>';

    });
}


function closeGlobalHistoryModal() {

    document.getElementById(
        'globalHistoryModal'
    ).style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| EXPORT & IMPORT MODALS
|--------------------------------------------------------------------------
*/

function openExportModal() {
    document.getElementById('exportModal').style.display = 'block';
}

function closeExportModal() {
    document.getElementById('exportModal').style.display = 'none';
}

function openImportModal() {
    document.getElementById('importModal').style.display = 'block';
}

function closeImportModal() {
    document.getElementById('importModal').style.display = 'none';
}

function toggleAdvancedSearch() {
    const panel = document.getElementById('advancedSearchPanel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
    } else {
        panel.style.display = 'none';
    }
}

function getFilterParams() {
    const keyword = new URLSearchParams(window.location.search).get('keyword') || '';
    const s_build_no = new URLSearchParams(window.location.search).get('s_build_no') || '';
    const s_project = new URLSearchParams(window.location.search).get('s_project') || '';
    const s_status = new URLSearchParams(window.location.search).get('s_status') || '';
    let params = '';
    if (keyword) params += '&keyword=' + encodeURIComponent(keyword);
    if (s_build_no) params += '&s_build_no=' + encodeURIComponent(s_build_no);
    if (s_project) params += '&s_project=' + encodeURIComponent(s_project);
    if (s_status) params += '&s_status=' + encodeURIComponent(s_status);
    return params;
}

/*
|--------------------------------------------------------------------------
| CLOSE MODALS WHEN CLICKING OUTSIDE
|--------------------------------------------------------------------------
*/

window.addEventListener(
    'click',
    function(event) {

        const newBuildModal = document.getElementById('newBuildModal');
        const editModal = document.getElementById('editModal');
        const viewModal = document.getElementById('viewAttachmentsModal');
        const detailsModal = document.getElementById('detailsModal');
        const historyModal = document.getElementById('historyModal');
        const globalHistoryModal = document.getElementById('globalHistoryModal');
        const exportModal = document.getElementById('exportModal');
        const importModal = document.getElementById('importModal');

        if (event.target === newBuildModal) { newBuildModal.style.display = 'none'; }
        if (event.target === editModal) { editModal.style.display = 'none'; }
        if (event.target === viewModal) { viewModal.style.display = 'none'; }
        if (event.target === detailsModal) { detailsModal.style.display = 'none'; }
        if (event.target === historyModal) { historyModal.style.display = 'none'; }
        if (event.target === globalHistoryModal) { globalHistoryModal.style.display = 'none'; }
        if (event.target === exportModal) { exportModal.style.display = 'none'; }
        if (event.target === importModal) { importModal.style.display = 'none'; }

    }
);


</script>

<?php include 'includes/footer.php'; ?>