<?php
/**
 * Container Platform inventory -- OpenShift and other Kubernetes
 * distributions, with their nodes.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('container_platform', 'can_view');

$canEdit   = can('container_platform', 'can_edit');
$canDelete = can('container_platform', 'can_delete');
$canExport = can('container_platform', 'can_export');
$canAudit  = can('container_platform', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const CP_MODULE = 'container_platform';

$platforms    = ['OpenShift', 'Vanilla Kubernetes', 'Rancher', 'Tanzu', 'EKS', 'AKS', 'GKE', 'OKD'];
$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development', 'Sandbox'];
$statuses     = ['Active', 'Building', 'Degraded', 'Decommissioned'];
$nodeRoles    = ['master', 'infra', 'worker', 'storage'];
$netPlugins   = ['OVN-Kubernetes', 'OpenShiftSDN', 'Calico', 'Cilium', 'Flannel', 'Other'];

/* Column list drives both the form and the CSV export. */
$cpFields = [
    'cluster_name'          => 'Cluster Name',
    'platform'              => 'Platform',
    'distribution_version'  => 'Platform Version',
    'kubernetes_version'    => 'Kubernetes Version',
    'environment'           => 'Environment',
    'project'               => 'Project',
    'location'              => 'Location / DC',
    'support_level'         => 'Support Level',
    'managed_by'            => 'Managed By',
    'api_endpoint'          => 'API Endpoint',
    'console_url'           => 'Console URL',
    'ingress_domain'        => 'Ingress Domain',
    'master_count'          => 'Masters',
    'infra_count'           => 'Infra Nodes',
    'worker_count'          => 'Workers',
    'total_cpu_cores'       => 'Total vCPU',
    'total_memory_gb'       => 'Total Memory (GB)',
    'total_storage_tb'      => 'Total Storage (TB)',
    'network_plugin'        => 'Network Plugin',
    'storage_backend'       => 'Storage Backend',
    'registry_type'         => 'Registry',
    'subscription_type'     => 'Subscription',
    'subscription_expiry'   => 'Subscription Expiry',
    'technical_owner'       => 'Technical Owner',
    'technical_owner_email' => 'Owner Email',
    'status'                => 'Status',
    'notes'                 => 'Notes',
];


/*
|--------------------------------------------------------------------------
| AJAX: audit history
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'history') {
    requirePermission('container_platform', 'can_audit');
    echo platformHistoryHtml($pdo, CP_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}


/*
|--------------------------------------------------------------------------
| AJAX: nodes for one cluster
|--------------------------------------------------------------------------
*/

/* Same data as the read-only view below, but as JSON for the editor. */
if (($_GET['action'] ?? '') === 'nodes_json') {
    header('Content-Type: application/json; charset=utf-8');

    $stmt = $pdo->prepare("
        SELECT hostname, node_role, cpu_cores, memory_gb, status
        FROM container_nodes WHERE cluster_id = ? ORDER BY node_role, hostname
    ");
    $stmt->execute([(int) ($_GET['id'] ?? 0)]);

    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

if (($_GET['action'] ?? '') === 'nodes') {
    $clusterId = (int) ($_GET['id'] ?? 0);

    $stmt = $pdo->prepare("SELECT * FROM container_nodes WHERE cluster_id = ? ORDER BY node_role, hostname");
    $stmt->execute([$clusterId]);
    $nodes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$nodes) {
        echo '<p class="plat-empty">No nodes recorded for this cluster yet.</p>';
        exit;
    }

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>Hostname</th><th>Role</th><th>vCPU</th><th>Memory (GB)</th><th>Status</th><th>Notes</th>'
       . '</tr></thead><tbody>';

    foreach ($nodes as $n) {
        echo '<tr>'
           . '<td class="plat-primary">' . plat_h($n['hostname']) . '</td>'
           . '<td><span class="plat-pill neutral">' . plat_h($n['node_role']) . '</span></td>'
           . '<td>' . (int) $n['cpu_cores'] . '</td>'
           . '<td>' . (int) $n['memory_gb'] . '</td>'
           . '<td><span class="plat-pill ' . platformStatusClass($n['status']) . '">' . plat_h($n['status']) . '</span></td>'
           . '<td>' . plat_h($n['notes']) . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/*
|--------------------------------------------------------------------------
| FILTERS (shared by the listing and the export)
|--------------------------------------------------------------------------
*/

$q           = trim((string) ($_GET['q'] ?? ''));
$fPlatform   = trim((string) ($_GET['f_platform'] ?? ''));
$fEnv        = trim((string) ($_GET['f_env'] ?? ''));
$fStatus     = trim((string) ($_GET['f_status'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(cluster_name LIKE ? OR project LIKE ? OR api_endpoint LIKE ? OR technical_owner LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fPlatform !== '') { $where[] = 'platform = ?';    $params[] = $fPlatform; }
if ($fEnv !== '')      { $where[] = 'environment = ?'; $params[] = $fEnv; }
if ($fStatus !== '')   { $where[] = 'status = ?';      $params[] = $fStatus; }

$whereSql = implode(' AND ', $where);


/*
|--------------------------------------------------------------------------
| EXPORT
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('container_platform', 'can_export');
    platformExportCsv($pdo, 'container_clusters', $cpFields, $whereSql, $params, 'container_platform');
}


/*
|--------------------------------------------------------------------------
| WRITES
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {

        requirePermission('container_platform', 'can_edit');

        $id   = (int) ($_POST['id'] ?? 0);
        $data = [];

        foreach (array_keys($cpFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        // Numeric columns stored as numbers, not text.
        foreach (['master_count', 'infra_count', 'worker_count', 'total_cpu_cores', 'total_memory_gb'] as $n) {
            $data[$n] = (int) $data[$n];
        }
        $data['total_storage_tb'] = (float) $data['total_storage_tb'];

        if ($data['cluster_name'] === '') {
            $err = 'Cluster name is required.';
        } else {
            try {
                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM container_clusters WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $stmt = $pdo->prepare("UPDATE container_clusters SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                    $stmt->execute([...array_values($data), $username, $id]);

                    platformLog($pdo, CP_MODULE, $id, 'UPDATED', $username,
                        "Updated cluster: {$data['cluster_name']}\n" . platformDiff($old, $data, $cpFields));

                    $msg = 'Cluster updated.';
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));
                    $stmt = $pdo->prepare("INSERT INTO container_clusters ($cols, created_by) VALUES ($ph, ?)");
                    $stmt->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    platformLog($pdo, CP_MODULE, $id, 'CREATED', $username, "Created cluster: {$data['cluster_name']}");

                    $msg = 'Cluster added.';
                }

                /* Nodes: replaced wholesale, which is simpler than diffing
                   and matches how the editor presents them. */
                $pdo->prepare("DELETE FROM container_nodes WHERE cluster_id = ?")->execute([$id]);

                $hosts  = $_POST['node_hostname'] ?? [];
                $roles  = $_POST['node_role'] ?? [];
                $cpus   = $_POST['node_cpu'] ?? [];
                $mems   = $_POST['node_mem'] ?? [];
                $states = $_POST['node_status'] ?? [];

                $insNode = $pdo->prepare("
                    INSERT OR IGNORE INTO container_nodes
                        (cluster_id, hostname, node_role, cpu_cores, memory_gb, status)
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

                foreach ($hosts as $i => $h) {
                    $h = trim((string) $h);
                    if ($h === '') { continue; }
                    $insNode->execute([
                        $id, $h,
                        trim((string) ($roles[$i] ?? 'worker')),
                        (int) ($cpus[$i] ?? 0),
                        (int) ($mems[$i] ?? 0),
                        trim((string) ($states[$i] ?? 'Ready')),
                    ]);
                }

            } catch (Throwable $e) {
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('container_platform', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);

        $nameStmt = $pdo->prepare("SELECT cluster_name FROM container_clusters WHERE id = ?");
        $nameStmt->execute([$id]);
        $name = (string) ($nameStmt->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM container_clusters WHERE id = ?")->execute([$id]);
        platformLog($pdo, CP_MODULE, $id, 'DELETED', $username, "Deleted cluster: {$name}");

        $msg = 'Cluster deleted.';
    }
}


/*
|--------------------------------------------------------------------------
| DATA
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("SELECT * FROM container_clusters WHERE $whereSql ORDER BY cluster_name");
$stmt->execute($params);
$clusters = $stmt->fetchAll(PDO::FETCH_ASSOC);

$nodeCounts = [];
foreach ($pdo->query("SELECT cluster_id, COUNT(*) c FROM container_nodes GROUP BY cluster_id")->fetchAll(PDO::FETCH_ASSOC) as $r) {
    $nodeCounts[(int) $r['cluster_id']] = (int) $r['c'];
}

$totClusters = count($clusters);
$totNodes    = 0;
$totCpu      = 0;
$totMem      = 0;
$prodCount   = 0;

foreach ($clusters as $c) {
    $totNodes += (int) $c['master_count'] + (int) $c['infra_count'] + (int) $c['worker_count'];
    $totCpu   += (int) $c['total_cpu_cores'];
    $totMem   += (int) $c['total_memory_gb'];
    if (strcasecmp((string) $c['environment'], 'Production') === 0) { $prodCount++; }
}

$hostnames = platformHostnames($pdo);

$page_title = 'Container Platform | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">☸</div>
            <div>
                <h1>Container Platform</h1>
                <p>OpenShift and Kubernetes clusters, their capacity, and the nodes that make them up.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="cpOpen()">+ Add Cluster</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_platform=<?= urlencode($fPlatform) ?>&amp;f_env=<?= urlencode($fEnv) ?>&amp;f_status=<?= urlencode($fStatus) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="cpHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $totClusters ?></b><span>Clusters</span></div>
        <div class="plat-stat tone-ok"><b><?= $prodCount ?></b><span>Production</span></div>
        <div class="plat-stat"><b><?= number_format($totNodes) ?></b><span>Nodes</span></div>
        <div class="plat-stat"><b><?= number_format($totCpu) ?></b><span>Total vCPU</span></div>
        <div class="plat-stat"><b><?= number_format($totMem) ?></b><span>Memory (GB)</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Search &amp; Filters</h3>
        </div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Cluster, project, endpoint, owner…">
                </div>
                <div class="plat-field">
                    <label>Platform</label>
                    <select name="f_platform">
                        <option value="">All</option>
                        <?php foreach ($platforms as $p): ?>
                            <option value="<?= plat_h($p) ?>" <?= $fPlatform === $p ? 'selected' : '' ?>><?= plat_h($p) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Environment</label>
                    <select name="f_env">
                        <option value="">All</option>
                        <?php foreach ($environments as $e): ?>
                            <option value="<?= plat_h($e) ?>" <?= $fEnv === $e ? 'selected' : '' ?>><?= plat_h($e) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Status</label>
                    <select name="f_status">
                        <option value="">All</option>
                        <?php foreach ($statuses as $s): ?>
                            <option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="container_platform.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Clusters</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $totClusters ?> shown</span>
        </div>

        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Cluster</th>
                        <th>Platform</th>
                        <th>Environment</th>
                        <th>Nodes (M/I/W)</th>
                        <th>Capacity</th>
                        <th>Project</th>
                        <th>Owner</th>
                        <th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$clusters): ?>
                    <tr><td colspan="9"><p class="plat-empty">No clusters recorded yet.</p></td></tr>
                <?php else: foreach ($clusters as $c): ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($c['cluster_name']) ?></span>
                            <span class="plat-sub"><?= plat_h($c['api_endpoint'] ?: $c['ingress_domain'] ?: '—') ?></span>
                        </td>
                        <td>
                            <?= plat_h($c['platform']) ?>
                            <span class="plat-sub"><?= plat_h($c['distribution_version'] ?: $c['kubernetes_version'] ?: '') ?></span>
                        </td>
                        <td><span class="plat-pill neutral"><?= plat_h($c['environment'] ?: '—') ?></span></td>
                        <td>
                            <?= (int) $c['master_count'] ?> / <?= (int) $c['infra_count'] ?> / <?= (int) $c['worker_count'] ?>
                            <?php if (!empty($nodeCounts[(int) $c['id']])): ?>
                                <span class="plat-sub"><?= (int) $nodeCounts[(int) $c['id']] ?> named</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?= number_format((int) $c['total_cpu_cores']) ?> vCPU
                            <span class="plat-sub"><?= number_format((int) $c['total_memory_gb']) ?> GB · <?= (float) $c['total_storage_tb'] ?> TB</span>
                        </td>
                        <td><?= plat_h($c['project'] ?: '—') ?></td>
                        <td>
                            <?= plat_h($c['technical_owner'] ?: '—') ?>
                            <span class="plat-sub"><?= plat_h($c['technical_owner_email']) ?></span>
                        </td>
                        <td><span class="plat-pill <?= platformStatusClass((string) $c['status']) ?>"><?= plat_h($c['status']) ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <button type="button" class="plat-icon-btn plat-icon-view" title="Nodes"
                                    onclick="cpNodes(<?= (int) $c['id'] ?>, '<?= plat_h(addslashes($c['cluster_name'])) ?>')">🖧</button>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='cpOpen(<?= json_encode($c, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History"
                                        onclick="cpHistory(<?= (int) $c['id'] ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="cpDelete(<?= (int) $c['id'] ?>, '<?= plat_h(addslashes($c['cluster_name'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>

</div>


<!-- ADD / EDIT -->
<div class="plat-modal" id="cpModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="cpTitle">Add Cluster</h2>
            <button type="button" class="plat-close" onclick="platClose('cpModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Cluster identity, capacity and the nodes that belong to it.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="cp_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Cluster Name *</label><input type="text" name="cluster_name" id="cp_cluster_name" required></div>
                <div class="plat-field"><label>Platform</label>
                    <select name="platform" id="cp_platform">
                        <?php foreach ($platforms as $p): ?><option value="<?= plat_h($p) ?>"><?= plat_h($p) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Status</label>
                    <select name="status" id="cp_status">
                        <?php foreach ($statuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Platform Version</label><input type="text" name="distribution_version" id="cp_distribution_version" placeholder="e.g. 4.14"></div>
                <div class="plat-field"><label>Kubernetes Version</label><input type="text" name="kubernetes_version" id="cp_kubernetes_version" placeholder="e.g. 1.27"></div>
                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="cp_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Project</label><input type="text" name="project" id="cp_project"></div>
                <div class="plat-field"><label>Location / DC</label><input type="text" name="location" id="cp_location"></div>
                <div class="plat-field"><label>Support Level</label><input type="text" name="support_level" id="cp_support_level"></div>

                <div class="plat-section-title">Endpoints</div>
                <div class="plat-field"><label>API Endpoint</label><input type="text" name="api_endpoint" id="cp_api_endpoint" placeholder="https://api.cluster.example:6443"></div>
                <div class="plat-field"><label>Console URL</label><input type="text" name="console_url" id="cp_console_url"></div>
                <div class="plat-field"><label>Ingress Domain</label><input type="text" name="ingress_domain" id="cp_ingress_domain" placeholder="*.apps.cluster.example"></div>

                <div class="plat-section-title">Capacity</div>
                <div class="plat-field"><label>Masters</label><input type="number" name="master_count" id="cp_master_count" value="0" min="0"></div>
                <div class="plat-field"><label>Infra Nodes</label><input type="number" name="infra_count" id="cp_infra_count" value="0" min="0"></div>
                <div class="plat-field"><label>Workers</label><input type="number" name="worker_count" id="cp_worker_count" value="0" min="0"></div>
                <div class="plat-field"><label>Total vCPU</label><input type="number" name="total_cpu_cores" id="cp_total_cpu_cores" value="0" min="0"></div>
                <div class="plat-field"><label>Total Memory (GB)</label><input type="number" name="total_memory_gb" id="cp_total_memory_gb" value="0" min="0"></div>
                <div class="plat-field"><label>Total Storage (TB)</label><input type="number" step="0.1" name="total_storage_tb" id="cp_total_storage_tb" value="0" min="0"></div>

                <div class="plat-section-title">Platform detail</div>
                <div class="plat-field"><label>Network Plugin</label>
                    <select name="network_plugin" id="cp_network_plugin">
                        <option value="">—</option>
                        <?php foreach ($netPlugins as $n): ?><option value="<?= plat_h($n) ?>"><?= plat_h($n) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Storage Backend</label><input type="text" name="storage_backend" id="cp_storage_backend" placeholder="ODF / NetApp / vSphere"></div>
                <div class="plat-field"><label>Registry</label><input type="text" name="registry_type" id="cp_registry_type" placeholder="Quay / Harbor / internal"></div>
                <div class="plat-field"><label>Subscription</label><input type="text" name="subscription_type" id="cp_subscription_type"></div>
                <div class="plat-field"><label>Subscription Expiry</label><input type="date" name="subscription_expiry" id="cp_subscription_expiry"></div>
                <div class="plat-field"><label>Managed By</label><input type="text" name="managed_by" id="cp_managed_by"></div>

                <div class="plat-section-title">Ownership</div>
                <div class="plat-field"><label>Technical Owner</label><input type="text" name="technical_owner" id="cp_technical_owner"></div>
                <div class="plat-field"><label>Owner Email</label><input type="email" name="technical_owner_email" id="cp_technical_owner_email"></div>
                <div class="plat-field full"><label>Notes</label><textarea name="notes" id="cp_notes" rows="2"></textarea></div>

                <div class="plat-section-title">Nodes</div>
                <div class="full">
                    <div id="cpNodeRows"></div>
                    <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="cpAddNode()">+ Add node</button>
                </div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('cpModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Cluster</button>
            </div>
        </form>
    </div>
</div>


<!-- NODES / HISTORY / DELETE -->
<div class="plat-modal" id="cpNodesModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="cpNodesTitle">Nodes</h2>
            <button type="button" class="plat-close" onclick="platClose('cpNodesModal')">&times;</button>
        </div>
        <div id="cpNodesBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="cpHistModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="cpHistTitle">Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('cpHistModal')">&times;</button>
        </div>
        <div id="cpHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="cpDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head">
            <h2>Delete cluster</h2>
            <button type="button" class="plat-close" onclick="platClose('cpDelModal')">&times;</button>
        </div>
        <p style="color:var(--text-secondary);">Delete <strong id="cpDelName"></strong> and all of its recorded nodes? This cannot be undone.</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="cpDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('cpDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<script>
const CP_NODE_ROLES = <?= json_encode($nodeRoles) ?>;
const CP_FIELDS = <?= json_encode(array_keys($cpFields)) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function cpNodeRow(n) {
    n = n || {};
    const roles = CP_NODE_ROLES.map(r =>
        `<option value="${r}" ${n.node_role === r ? 'selected' : ''}>${r}</option>`).join('');

    const row = document.createElement('div');
    row.className = 'plat-filters';
    row.style.marginBottom = '8px';
    row.innerHTML =
        `<div class="plat-field"><input list="platHostnames" name="node_hostname[]" placeholder="hostname" value="${n.hostname || ''}"></div>
         <div class="plat-field"><select name="node_role[]">${roles}</select></div>
         <div class="plat-field"><input type="number" name="node_cpu[]" placeholder="vCPU" style="min-width:90px" value="${n.cpu_cores || ''}"></div>
         <div class="plat-field"><input type="number" name="node_mem[]" placeholder="GB" style="min-width:90px" value="${n.memory_gb || ''}"></div>
         <div class="plat-field"><input name="node_status[]" placeholder="Ready" style="min-width:110px" value="${n.status || 'Ready'}"></div>
         <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="this.parentNode.remove()">Remove</button>`;
    return row;
}

function cpAddNode(n) { document.getElementById('cpNodeRows').appendChild(cpNodeRow(n)); }

function cpOpen(data) {
    const editing = !!data;
    document.getElementById('cpTitle').innerText = editing ? 'Edit Cluster' : 'Add Cluster';
    document.getElementById('cp_id').value = editing ? data.id : '';

    CP_FIELDS.forEach(f => {
        const el = document.getElementById('cp_' + f);
        if (!el) return;
        el.value = editing ? (data[f] ?? '') : (el.type === 'number' ? 0 : '');
    });

    const rows = document.getElementById('cpNodeRows');
    rows.innerHTML = '';

    if (editing) {
        // Nodes are fetched rather than embedded in the row: a cluster can
        // have many, and they are not needed until the editor is opened.
        fetch('container_platform.php?action=nodes_json&id=' + encodeURIComponent(data.id))
            .then(r => r.ok ? r.json() : [])
            .then(list => {
                (list || []).forEach(cpAddNode);
                if (!list || !list.length) cpAddNode();
            })
            .catch(() => cpAddNode());
    } else {
        cpAddNode();
    }

    platOpen('cpModal');
}

function cpNodes(id, name) {
    document.getElementById('cpNodesTitle').innerText = 'Nodes — ' + name;
    document.getElementById('cpNodesBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('cpNodesModal');

    fetch('container_platform.php?action=nodes&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(html => { document.getElementById('cpNodesBody').innerHTML = html; })
        .catch(() => { document.getElementById('cpNodesBody').innerHTML = '<p class="plat-empty">Failed to load nodes.</p>'; });
}

function cpHistory(id) {
    document.getElementById('cpHistTitle').innerText = id ? 'Audit History — cluster #' + id : 'Module Audit History';
    document.getElementById('cpHistBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('cpHistModal');

    fetch('container_platform.php?action=history&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(html => { document.getElementById('cpHistBody').innerHTML = html; })
        .catch(() => { document.getElementById('cpHistBody').innerHTML = '<p class="plat-empty">Failed to load history.</p>'; });
}

function cpDelete(id, name) {
    document.getElementById('cpDelId').value = id;
    document.getElementById('cpDelName').innerText = name;
    platOpen('cpDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
