<?php

session_start();
require_once __DIR__ . '/config/db.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$role = trim($_SESSION['role'] ?? '');

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

/*
| This file is the server list for a patching assignment -- it is loaded
| as a fragment inside patching.php's modal, and standalone. It is part
| of the Quarterly Patching module, so it is gated on the SAME
| page_key ('patching') that patching.php itself uses.
|
| It previously queried page_key = 'patch_servers', which is not a
| registered page (see permission.php) and so has no rows in the
| permissions table at all. fetchColumn() returned false for every
| role, can_view was always false, and every request -- including the
| modal's AJAX fetch -- got a 403, which the caller surfaced as
| "Failed to load servers."
|
| Truthiness is matched to patchingHasPermission() in patching.php
| (TRIM on both sides, accepts 1/true/yes/on) so the two cannot
| disagree about what a stored permission value means.
*/
function patchServersHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'patching', $permission);
}

$canView   = patchServersHasPermission($pdo, $role, 'can_view');
$canEdit   = patchServersHasPermission($pdo, $role, 'can_edit');
$canDelete = patchServersHasPermission($pdo, $role, 'can_delete');
$canExport = patchServersHasPermission($pdo, $role, 'can_export');
$canImport = patchServersHasPermission($pdo, $role, 'can_import');
$canAudit  = patchServersHasPermission($pdo, $role, 'can_audit');

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}

// Detect if this is an AJAX call or standalone view
$isAjax = isset($_GET['schedule_id']) && !isset($_GET['is_standalone']);

// If AJAX request, use old flow
if ($isAjax || (isset($_POST['schedule_id']) && !isset($_GET['is_standalone']))) {
    require_once __DIR__ . '/config/patching_db.php';

    function h($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }

    function serverStatusClass(string $status): string
    {
        $status = strtolower(str_replace(['/', ' '], '', $status));
        return $status === '' ? 'pending' : $status;
    }

    $currentUserId = (int) ($_SESSION['user_id'] ?? 0);
    $role = strtolower(trim($_SESSION['role'] ?? ''));
    $isAdmin = in_array($role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

    /*
     * 'Planned' and 'In Progress' exist so the Patch_Status column of the
     * hostname-level CSV round trip has somewhere to land. Without them in
     * this list an imported value would fail the in_array() check on the
     * next save of this page and be silently reset to Pending.
     */
    $serverStatuses = [
        '', 'Planned', 'In Progress', 'Completed', 'Rescheduled', 'N/A', 'Excluded',
        'Decommissioned', 'To Be Decom',
    ];

    $scheduleId = isset($_GET['schedule_id']) ? (int) $_GET['schedule_id'] : (int) ($_POST['schedule_id'] ?? 0);

    if (!$scheduleId) {
        echo '<p class="pt-server-empty">Invalid assignment.</p>';
        exit;
    }

    $stmt = $pdo->prepare("
        SELECT ps.*, u.first_name, u.last_name
        FROM patch_schedules ps
        LEFT JOIN users u ON u.id = ps.assigned_to
        WHERE ps.id = ?
    ");
    $stmt->execute([$scheduleId]);
    $schedule = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$schedule) {
        echo '<p class="pt-server-empty">Assignment not found.</p>';
        exit;
    }

    $canEdit = $isAdmin || (int) $schedule['assigned_to'] === $currentUserId;

    $portalUsers = $pdo->query("
        SELECT id, first_name, last_name
        FROM users
        WHERE is_approved = 1
        ORDER BY first_name, last_name
    ")->fetchAll(PDO::FETCH_ASSOC);

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (empty($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
            http_response_code(403);
            echo '<p class="pt-server-empty">Invalid security token — please reload the page and try again.</p>';
            exit;
        }

        if (!$canEdit) {
            http_response_code(403);
            echo '<p class="pt-server-empty">You do not have permission to edit these servers.</p>';
            exit;
        }

        /*
         * Rows arrive as one JSON variable (see submitServerForm in
         * patching.php). Posting them as rows[host][field] meant a few
         * hundred servers exceeded PHP's max_input_vars, and PHP truncates
         * that silently -- the save reported success while later rows were
         * never written.
         *
         * The rows[] shape is still accepted so a cached page mid-deploy,
         * or any other caller, keeps working.
         */
        $rows = $_POST['rows'] ?? [];

        if (isset($_POST['rows_json'])) {

            $decodedRows = json_decode((string) $_POST['rows_json'], true);

            if (!is_array($decodedRows)) {
                http_response_code(400);
                echo '<p class="pt-server-empty">Could not read the submitted server rows. Please reload the page and try again.</p>';
                exit;
            }

            $rows = $decodedRows;
        }

        /*
         * Pass one: read and validate every row before writing anything.
         *
         * Completing a server is a claim that the work was done, so the
         * assignee has to say what was done -- the fields below are all
         * required once Status is Completed. Validation is done up front
         * and the whole submit is refused if any row fails, so a grid of
         * servers can never end up half saved.
         */
        $completionRequiredFields = [
            'applied_patch'              => 'Applied Patch',
            'applied_patch_release_date' => 'Applied Patch Release Date',
            'patch_level'                => 'Patch Level (N)',
            'new_kernel_version'         => 'Applied Kernel Patch',
            'latest_available_patch'     => 'Latest Available Patch Details',
            'kernel_patch_n_level'       => 'Kernel Patch N Level',
            'cr'                         => 'Change Number',
        ];

        $parsedRows = [];
        $validationErrors = [];

        foreach ($rows as $hostname => $fields) {
            $hostname = trim((string) $hostname);

            if ($hostname === '') {
                continue;
            }

            $status = trim((string) ($fields['status'] ?? ''));

            if (!in_array($status, $serverStatuses, true)) {
                $status = '';
            }

            $parsed = [
                'hostname'                   => $hostname,
                'selected'                   => isset($fields['selected']) ? 1 : 0,
                'assigned_to'                => $isAdmin ? (int) ($fields['assigned_to'] ?? 0) : 0,
                'status'                     => $status,
                'patch_date'                 => trim((string) ($fields['patch_date'] ?? '')),
                'comment'                    => trim((string) ($fields['comment'] ?? '')),
                'cr'                         => trim((string) ($fields['cr'] ?? '')),
                'new_os_version'             => trim((string) ($fields['new_os_version'] ?? '')),
                'new_kernel_version'         => trim((string) ($fields['new_kernel_version'] ?? '')),
                'applied_patch'              => trim((string) ($fields['applied_patch'] ?? '')),
                'applied_patch_release_date' => trim((string) ($fields['applied_patch_release_date'] ?? '')),
                'patch_level'                => trim((string) ($fields['patch_level'] ?? '')),
                'latest_available_patch'     => trim((string) ($fields['latest_available_patch'] ?? '')),
                'kernel_patch_n_level'       => trim((string) ($fields['kernel_patch_n_level'] ?? '')),
            ];

            if ($status === 'Completed') {

                $missing = [];

                foreach ($completionRequiredFields as $field => $label) {
                    if ($parsed[$field] === '') {
                        $missing[] = $label;
                    }
                }

                if ($missing) {
                    $validationErrors[$hostname] = $missing;
                }
            }

            $parsedRows[] = $parsed;
        }

        $editable = isset($_POST['edit_mode']) && $_POST['edit_mode'] == '1';

        if ($validationErrors) {

            /*
             * Nothing is written. The form is re-rendered below from the
             * submitted values (see $tracking overlay) so the assignee does
             * not lose what they typed while fixing the gaps.
             */
            $saveBlocked = true;
            $submittedRows = [];

            foreach ($parsedRows as $parsed) {
                $submittedRows[$parsed['hostname']] = $parsed;
            }

        } else {

            $invUpdate = $pdo->prepare("UPDATE inventory SET os_version = ?, kernel_version = ? WHERE hostname = ?");
            $kernelSnapshot = $pdo->prepare("SELECT kernel_version FROM inventory WHERE hostname = ? LIMIT 1");
            $existingAssignee = $pdo->prepare("SELECT assigned_to FROM patch_schedule_servers WHERE schedule_id = ? AND hostname = ?");

            /*
             * last_kernel_patch is set on INSERT only and is deliberately
             * absent from the DO UPDATE list: it is the frozen "kernel
             * before this quarter's patch" snapshot, so re-saving this page
             * after the host has been patched must not move it.
             */
            $trackingUpsert = $pdo->prepare("
                INSERT INTO patch_schedule_servers
                    (schedule_id, hostname, selected, assigned_to, patch_date, status, comment, cr,
                     new_os_version, new_kernel_version, applied_patch, applied_patch_release_date,
                     patch_level, latest_available_patch, kernel_patch_n_level,
                     last_kernel_patch, updated_by, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ON CONFLICT(schedule_id, hostname) DO UPDATE SET
                    selected                   = excluded.selected,
                    assigned_to                = excluded.assigned_to,
                    patch_date                 = excluded.patch_date,
                    status                     = excluded.status,
                    comment                    = excluded.comment,
                    cr                         = excluded.cr,
                    new_os_version             = excluded.new_os_version,
                    new_kernel_version         = excluded.new_kernel_version,
                    applied_patch              = excluded.applied_patch,
                    applied_patch_release_date = excluded.applied_patch_release_date,
                    patch_level                = excluded.patch_level,
                    latest_available_patch     = excluded.latest_available_patch,
                    kernel_patch_n_level       = excluded.kernel_patch_n_level,
                    updated_by                 = excluded.updated_by,
                    updated_at                 = CURRENT_TIMESTAMP
            ");

            foreach ($parsedRows as $parsed) {

                $hostname = $parsed['hostname'];

                $rowAssignedTo = $parsed['assigned_to'] > 0 ? $parsed['assigned_to'] : null;

                if (!$isAdmin) {
                    $existingAssignee->execute([$scheduleId, $hostname]);
                    $existingRow = $existingAssignee->fetch(PDO::FETCH_ASSOC);
                    $rowAssignedTo = $existingRow ? $existingRow['assigned_to'] : null;
                }

                /*
                 * Read the snapshot BEFORE inventory is promoted below --
                 * otherwise a first save that also completes the host would
                 * freeze the post-patch kernel as the pre-patch one.
                 */
                $kernelSnapshot->execute([$hostname]);
                $snapshotKernel = (string) ($kernelSnapshot->fetchColumn() ?: '');

                $trackingUpsert->execute([
                    $scheduleId,
                    $hostname,
                    $parsed['selected'],
                    $rowAssignedTo,
                    $parsed['patch_date'] ?: null,
                    $parsed['status'],
                    $parsed['comment'],
                    $parsed['cr'],
                    $parsed['new_os_version'],
                    $parsed['new_kernel_version'],
                    $parsed['applied_patch'],
                    $parsed['applied_patch_release_date'],
                    $parsed['patch_level'],
                    $parsed['latest_available_patch'],
                    $parsed['kernel_patch_n_level'],
                    $snapshotKernel,
                    $currentUserId,
                ]);

                /*
                 * Promote the new versions into inventory once the host is
                 * Completed: inventory holds what the host runs now, and
                 * from this point that is the patched version. Before
                 * completion inventory is left alone, so a value typed in
                 * early never reaches the master data.
                 */
                if ($parsed['status'] === 'Completed') {

                    $promotedOs = $parsed['new_os_version'];
                    $promotedKernel = $parsed['new_kernel_version'];

                    if ($promotedOs !== '' || $promotedKernel !== '') {

                        $currentInventory = $pdo->prepare(
                            "SELECT os_version, kernel_version FROM inventory WHERE hostname = ? LIMIT 1"
                        );
                        $currentInventory->execute([$hostname]);
                        $currentRow = $currentInventory->fetch(PDO::FETCH_ASSOC) ?: [];

                        $invUpdate->execute([
                            $promotedOs !== '' ? $promotedOs : ($currentRow['os_version'] ?? ''),
                            $promotedKernel !== '' ? $promotedKernel : ($currentRow['kernel_version'] ?? ''),
                            $hostname,
                        ]);
                    }
                }
            }
        }

    } else {
        $editable = isset($_GET['edit']) && $_GET['edit'] == '1' && $canEdit;
    }

    $saveBlocked = $saveBlocked ?? false;
    $validationErrors = $validationErrors ?? [];
    $submittedRows = $submittedRows ?? [];

    if (trim((string) $schedule['application']) !== '') {
        $invStmt = $pdo->prepare("
            SELECT hostname, ip_address, project, application, support_level, os_family, os_version, kernel_version
            FROM inventory
            WHERE project = ? AND application = ? AND support_level = ? AND managed_by = 'HCL'
            ORDER BY hostname
        ");
        $invStmt->execute([$schedule['project'], $schedule['application'], $schedule['support_level']]);
    } else {
        $invStmt = $pdo->prepare("
            SELECT hostname, ip_address, project, application, support_level, os_family, os_version, kernel_version
            FROM inventory
            WHERE project = ? AND support_level = ? AND managed_by = 'HCL'
            ORDER BY hostname
        ");
        $invStmt->execute([$schedule['project'], $schedule['support_level']]);
    }

    $servers = $invStmt->fetchAll(PDO::FETCH_ASSOC);

    $trackingStmt = $pdo->prepare("
        SELECT pss.*, u.first_name AS assigned_first_name, u.last_name AS assigned_last_name
        FROM patch_schedule_servers pss
        LEFT JOIN users u ON u.id = pss.assigned_to
        WHERE pss.schedule_id = ?
    ");
    $trackingStmt->execute([$scheduleId]);

    $tracking = [];
    foreach ($trackingStmt->fetchAll(PDO::FETCH_ASSOC) as $t) {
        $tracking[$t['hostname']] = $t;
    }

    /*
     * A refused save re-renders from what was submitted, not from the
     * database, so the assignee keeps every value they typed while they
     * fill in the missing ones.
     */
    if ($saveBlocked) {
        foreach ($submittedRows as $submittedHost => $submittedRow) {
            $tracking[$submittedHost] = array_merge($tracking[$submittedHost] ?? [], $submittedRow);
        }
    }

    $assigneeName = trim(($schedule['first_name'] ?? '') . ' ' . ($schedule['last_name'] ?? ''));

    ?>
    <script>
    document.getElementById('serverModalTitle').innerText = <?= json_encode($schedule['application'] ?: $schedule['project']) ?>;
    document.getElementById('serverModalSubtitle').innerText =
        <?= json_encode(
            $schedule['project'] . ' · ' . ($schedule['support_level'] ?: 'All Support Levels') .
            ' · Assigned to ' . ($assigneeName ?: 'Unassigned') . ' · CR: ' . ($schedule['cr'] ?: '-')
        ) ?>;
    </script>

    <form id="serverForm" onsubmit="return false;">
        <input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token'] ?? '') ?>">
        <input type="hidden" name="schedule_id" value="<?= $scheduleId ?>">
        <input type="hidden" name="edit_mode" value="<?= $editable ? '1' : '0' ?>">

        <?php if ($saveBlocked): ?>
            <div class="pt-server-validation">
                <strong>Nothing was saved.</strong>
                A server cannot be marked <em>Completed</em> until the assignee has filled in
                every required field. Fix the rows below and save again.
                <ul>
                    <?php foreach (array_slice($validationErrors, 0, 12, true) as $badHost => $missingFields): ?>
                        <li><strong><?= h($badHost) ?></strong> &mdash; missing: <?= h(implode(', ', $missingFields)) ?></li>
                    <?php endforeach; ?>
                    <?php if (count($validationErrors) > 12): ?>
                        <li>&hellip; and <?= count($validationErrors) - 12 ?> more server(s).</li>
                    <?php endif; ?>
                </ul>
            </div>
        <?php endif; ?>


        <?php if ($isAdmin && $editable && $servers): ?>
            <div class="pt-bulk-toolbar">
                <div>
                    <strong>Bulk assignment</strong>
                    <span class="pt-bulk-help">Select servers below, choose a user, then apply.</span>
                </div>

                <div class="pt-bulk-controls">
                    <button type="button" class="pt-btn pt-btn-ghost pt-btn-sm" onclick="toggleAllServers(true)">Select All</button>
                    <button type="button" class="pt-btn pt-btn-ghost pt-btn-sm" onclick="toggleAllServers(false)">Clear All</button>

                    <select id="bulkUserSelect">
                        <option value="0">-- Assign Selected To --</option>
                        <?php foreach ($portalUsers as $user): ?>
                            <option value="<?= (int) $user['id'] ?>">
                                <?= h(trim($user['first_name'] . ' ' . $user['last_name'])) ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <button type="button" class="pt-btn pt-btn-primary pt-btn-sm" onclick="applyBulkAssignment()">Apply</button>
                </div>
            </div>
        <?php endif; ?>

        <div class="pt-server-table-wrap">
            <table class="pt-server-table">
                <thead>
                    <tr>
                        <?php if ($isAdmin && $editable): ?>
                            <th class="pt-server-select-col">Select</th>
                        <?php endif; ?>
                        <th>Hostname</th>
                        <th>IP Address</th>
                        <th>Project</th>
                        <th>Application</th>
                        <th>Support Level</th>
                        <th>OS Family</th>
                        <th>Current OS Version</th>
                        <th>Current Kernel Version</th>
                        <th>Last Kernel Patch</th>
                        <th>New OS Version</th>
                        <th>New Kernel Version <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Applied Patch <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Applied Patch Release Date <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Patch Level (N) <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Latest Available Patch Details <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Kernel Patch N Level <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <?php if ($isAdmin && $editable): ?>
                            <th>Assigned User</th>
                        <?php endif; ?>
                        <th>Status</th>
                        <th>Date</th>
                        <th>Change Number <span class="pt-req" title="Required to mark Completed">*</span></th>
                        <th>Comment</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!$servers): ?>
                        <tr>
                            <td colspan="<?= ($isAdmin && $editable) ? 22 : 20 ?>" class="pt-server-empty">
                                No HCL-managed servers found in inventory for this project / application / support level.
                            </td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($servers as $server):
                            $hostname = $server['hostname'];
                            $t = $tracking[$hostname] ?? [];
                            $t += [
                                'selected' => 0, 'assigned_to' => null, 'patch_date' => '',
                                'status' => '', 'comment' => '', 'cr' => '',
                                'new_os_version' => '', 'new_kernel_version' => '',
                                'applied_patch' => '', 'applied_patch_release_date' => '',
                                'patch_level' => '', 'latest_available_patch' => '',
                                'kernel_patch_n_level' => '', 'last_kernel_patch' => '',
                                'assigned_first_name' => '', 'assigned_last_name' => ''
                            ];
                            $selected = (int) ($t['selected'] ?? 0) === 1;
                            $rowHasError = isset($validationErrors[$hostname]);
                        ?>
                        <tr class="<?= $selected ? 'pt-server-selected' : 'pt-server-not-selected' ?><?= $rowHasError ? ' pt-server-row-error' : '' ?>"
                            data-pt-status="<?= h($t['status'] ?? '') ?>"
                            data-pt-assigned="<?= (int) ($t['assigned_to'] ?? 0) ?>">
                            <?php if ($isAdmin && $editable): ?>
                                <td class="pt-server-select-col">
                                    <input type="checkbox" class="server-checkbox" name="rows[<?= h($hostname) ?>][selected]" value="1" <?= $selected ? 'checked' : '' ?>>
                                </td>
                            <?php endif; ?>

                            <td><strong><?= h($hostname) ?></strong></td>
                            <td><?= h($server['ip_address']) ?></td>
                            <td><?= h($server['project']) ?></td>
                            <td><?= h($server['application']) ?></td>
                            <td><?= h($server['support_level'] ?: '-') ?></td>
                            <td><?= h($server['os_family']) ?></td>

                            <?php
                            /*
                             * Current OS / Kernel Version are inventory's values and are
                             * never editable here -- inventory is the master record, and
                             * this page only promotes into it once a host is Completed.
                             */
                            ?>
                            <td class="pt-server-readonly"><?= h($server['os_version'] ?: '-') ?></td>
                            <td class="pt-server-readonly"><?= h($server['kernel_version'] ?: '-') ?></td>
                            <td class="pt-server-readonly"><?= h($t['last_kernel_patch'] ?: '-') ?></td>

                            <?php if ($editable): ?>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][new_os_version]" value="<?= h($t['new_os_version']) ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][new_kernel_version]" value="<?= h($t['new_kernel_version']) ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][applied_patch]" value="<?= h($t['applied_patch']) ?>"></td>
                                <td><input type="date" name="rows[<?= h($hostname) ?>][applied_patch_release_date]" value="<?= h($t['applied_patch_release_date']) ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][patch_level]" value="<?= h($t['patch_level']) ?>" placeholder="N / N-1"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][latest_available_patch]" value="<?= h($t['latest_available_patch']) ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][kernel_patch_n_level]" value="<?= h($t['kernel_patch_n_level']) ?>"></td>
                            <?php else: ?>
                                <td><?= h($t['new_os_version'] ?: '-') ?></td>
                                <td><?= h($t['new_kernel_version'] ?: '-') ?></td>
                                <td><?= h($t['applied_patch'] ?: '-') ?></td>
                                <td><?= h($t['applied_patch_release_date'] ?: '-') ?></td>
                                <td><?= h($t['patch_level'] ?: '-') ?></td>
                                <td><?= h($t['latest_available_patch'] ?: '-') ?></td>
                                <td><?= h($t['kernel_patch_n_level'] ?: '-') ?></td>
                            <?php endif; ?>

                            <?php if ($isAdmin && $editable): ?>
                                <td>
                                    <select name="rows[<?= h($hostname) ?>][assigned_to]" class="server-assignee-select">
                                        <option value="0">-- Unassigned --</option>
                                        <?php foreach ($portalUsers as $user): ?>
                                            <option value="<?= (int) $user['id'] ?>" <?= (int) ($t['assigned_to'] ?? 0) === (int) $user['id'] ? 'selected' : '' ?>>
                                                <?= h(trim($user['first_name'] . ' ' . $user['last_name'])) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            <?php endif; ?>

                            <?php if ($editable): ?>
                                <td>
                                    <select name="rows[<?= h($hostname) ?>][status]">
                                        <?php foreach ($serverStatuses as $statusOption): ?>
                                            <option value="<?= h($statusOption) ?>" <?= ($t['status'] ?? '') === $statusOption ? 'selected' : '' ?>>
                                                <?= $statusOption === '' ? 'Pending' : h($statusOption) ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                                <td><input type="date" name="rows[<?= h($hostname) ?>][patch_date]" value="<?= h($t['patch_date'] ?? '') ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][cr]" value="<?= h($t['cr'] ?? '') ?>"></td>
                                <td><input type="text" name="rows[<?= h($hostname) ?>][comment]" value="<?= h($t['comment'] ?? '') ?>"></td>
                            <?php else: ?>
                                <td><span class="pt-server-badge <?= serverStatusClass($t['status'] ?? '') ?>"><?= h($t['status'] ?: 'Pending') ?></span></td>
                                <td><?= h($t['patch_date'] ?: '-') ?></td>
                                <td><?= h($t['cr'] ?: '-') ?></td>
                                <td><?= h($t['comment'] ?: '-') ?></td>
                            <?php endif; ?>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <div class="pt-modal-footer-row">
            <button type="button" class="pt-btn pt-btn-secondary" onclick="closeModal('serverModal')">Close</button>
            <?php if ($editable && $servers): ?>
                <button type="button" class="pt-btn pt-btn-primary pt-save-server-button" onclick="submitServerForm(<?= $scheduleId ?>)">Save Changes</button>
            <?php endif; ?>
        </div>
    </form>
    <?php
    exit;
}

// STANDALONE VIEW STARTS HERE

$page_title = "Patch Servers | InfraVault";
require 'includes/header.php';
?>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/decommission.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">
    <div class="dashboard-header">
        <div>
            <h1>Patch Servers Management</h1>
            <p>View and manage servers across patch schedules with version tracking and audit history.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canImport): ?>
                <button type="button" class="btn btn-info">📥 Import CSV</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <button type="button" class="btn btn-info">📤 Export CSV</button>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="btn btn-warning" onclick="openGlobalHistoryModal()">⏱ History</button>
            <?php endif; ?>
        </div>
    </div>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header">
            <h3 class="panel-title">Search & Filters</h3>
        </div>
        <form method="GET" action="patch_servers.php" style="display:flex; gap:10px; flex-wrap:wrap;">
            <input type="text" name="search" class="form-control" style="max-width:320px;" placeholder="Search hostname, IP, project...">
            <button type="submit" class="btn btn-primary">Search</button>
        </form>
    </div>

    <!-- Data Table -->
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th><a href="?sort_by=hostname&sort_dir=<?= isset($_GET['sort_dir']) && $_GET['sort_dir'] === 'ASC' ? 'DESC' : 'ASC' ?>">Hostname <?= isset($_GET['sort_by']) && $_GET['sort_by'] === 'hostname' ? '▼' : '' ?></a></th>
                    <th>IP Address</th>
                    <th>Project</th>
                    <th>Application</th>
                    <th>Support Level</th>
                    <th>OS Version</th>
                    <th>Kernel Version</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="9" class="text-center text-muted">No data to display. This is a standalone view for patch server management.</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>

<?php require 'includes/footer.php'; ?>
