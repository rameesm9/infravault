# Granular Visibility Implementation - Quick Reference Card

## File Locations & Changes

### Database Schemas Modified
```
config/schema/reminders.php       - Added reminder_teams, reminder_users, sticky_note_teams, sticky_note_users
config/schema/communications.php  - Added communication_teams, communication_users, visibility column
config/schema/mydata.php          - Added mydata_teams, mydata_users tables and indexes
```

### PHP Files Modified
```
reminders.php                      - Main implementation with UI, POST handlers, and visibility logic
assets/css/reminders-enterprise.css - Added .status-team and .status-user badge styles
```

### Documentation Added
```
VISIBILITY_IMPLEMENTATION_SUMMARY.md    - Detailed overview of all changes
VISIBILITY_IMPLEMENTATION_GUIDE.md      - Step-by-step guide for other modules
VISIBILITY_QUICK_REFERENCE.md          - This file
```

## Database Schema Template

```sql
-- Main table (add if missing)
ALTER TABLE your_table ADD COLUMN visibility TEXT DEFAULT 'private';

-- Join tables
CREATE TABLE IF NOT EXISTS your_table_teams (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    your_table_id INTEGER NOT NULL,
    team_name TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(your_table_id) REFERENCES your_table(id) ON DELETE CASCADE,
    UNIQUE(your_table_id, team_name)
);

CREATE TABLE IF NOT EXISTS your_table_users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    your_table_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY(your_table_id) REFERENCES your_table(id) ON DELETE CASCADE,
    UNIQUE(your_table_id, user_id)
);
```

## PHP Code Template

### Authorization Check
```php
function canViewRecord($record, $user_id, $user_team, $role, $pdo)
{
    if(strtolower($role) === 'admin') return true;
    if((int)$record['owner_id'] === (int)$user_id) return true;
    if(($record['visibility'] ?? 'private') === 'public') return true;
    if(($record['visibility'] ?? 'private') === 'private') return false;
    if(($record['visibility'] ?? '') === 'team' && !empty($user_team)) {
        $stmt = $pdo->prepare("SELECT 1 FROM your_table_teams WHERE your_table_id=? AND team_name=? LIMIT 1");
        return $stmt->execute([$record['id'], $user_team]) && $stmt->fetch();
    }
    if(($record['visibility'] ?? '') === 'user') {
        $stmt = $pdo->prepare("SELECT 1 FROM your_table_users WHERE your_table_id=? AND user_id=? LIMIT 1");
        return $stmt->execute([$record['id'], $user_id]) && $stmt->fetch();
    }
    return false;
}
```

### Save Teams/Users in POST Handler
```php
// After inserting main record, get $record_id

if($visibility === 'team' && !empty($selected_teams)) {
    $stmt = $pdo->prepare("INSERT INTO your_table_teams (your_table_id, team_name) VALUES (?, ?)");
    foreach($selected_teams as $team) {
        if(!empty(trim($team))) {
            $stmt->execute([$record_id, trim($team)]);
        }
    }
}

if($visibility === 'user' && !empty($selected_users)) {
    $stmt = $pdo->prepare("INSERT INTO your_table_users (your_table_id, user_id) VALUES (?, ?)");
    foreach($selected_users as $uid) {
        if((int)$uid > 0) {
            $stmt->execute([$record_id, (int)$uid]);
        }
    }
}
```

## HTML Form Template

```html
<div class="form-group">
    <label>Visibility</label>
    <label><input type="radio" name="visibility" value="private" checked> Private</label>
    <label><input type="radio" name="visibility" value="public"> Public</label>
    <label><input type="radio" name="visibility" value="team"> Team</label>
    <label><input type="radio" name="visibility" value="user"> Users</label>
</div>

<div id="team-selector" style="display:none;">
    <label>Teams:</label>
    <!-- Checkboxes will go here -->
</div>

<div id="user-selector" style="display:none;">
    <label>Users:</label>
    <!-- Checkboxes will go here -->
</div>
```

## JavaScript Template

```javascript
document.querySelectorAll('input[name="visibility"]').forEach(radio => {
    radio.addEventListener('change', function() {
        document.getElementById('team-selector').style.display = this.value === 'team' ? 'block' : 'none';
        document.getElementById('user-selector').style.display = this.value === 'user' ? 'block' : 'none';
    });
});

// Initialize on load
if(document.querySelector('input[name="visibility"]:checked')) {
    let val = document.querySelector('input[name="visibility"]:checked').value;
    document.getElementById('team-selector').style.display = val === 'team' ? 'block' : 'none';
    document.getElementById('user-selector').style.display = val === 'user' ? 'block' : 'none';
}
```

## CSS Classes

```css
/* Add to your module's CSS */
.status-all    { background: #dcfce7; color: #166534; }  /* Public - Green */
.status-private{ background: #fee2e2; color: #991b1b; }  /* Private - Red */
.status-team   { background: #dbeafe; color: #1e40af; }  /* Team - Blue */
.status-user   { background: #fce7f3; color: #831843; }  /* User - Pink */
```

## Key Variables to Capture

```php
$current_user_id = (int)$_SESSION['user_id'];
$current_user_team = $_SESSION['team'] ?? '';
$role = strtolower($_SESSION['role'] ?? '');
```

## Variable Naming Convention

For consistency across modules:
- Table join: `{table}_teams` and `{table}_users`
- Form inputs: `teams[]` and `users[]`
- Session variables: `$current_user_team`, `$current_user_id`, `$role`
- Helper functions: `canView{Record}()`, `canEdit{Record}()`, `canDelete{Record}()`

## Backward Compatibility Checklist

- [ ] Migrate old visibility values (e.g., 'all' → 'public')
- [ ] Handle records without team/user associations gracefully
- [ ] Support both old and new visibility models during transition
- [ ] Test with existing data
- [ ] Preserve admin access to all records
- [ ] Don't require join table entries for private/public visibility

## SQL Queries Reference

### Get record with visibility check
```sql
SELECT r.*, u.name FROM your_table r
LEFT JOIN users u ON r.user_id = u.id
WHERE r.id = ?
```

### Get shared teams for a record
```sql
SELECT team_name FROM your_table_teams WHERE your_table_id = ?
```

### Get shared users for a record
```sql
SELECT user_id FROM your_table_users WHERE your_table_id = ?
```

### Count shared items
```sql
SELECT COUNT(*) FROM your_table_users WHERE your_table_id = ?
```

## Testing Checklist

- [ ] Create with private visibility
- [ ] Create with public visibility
- [ ] Create with team visibility (multiple teams)
- [ ] Create with user visibility (multiple users)
- [ ] Edit and change visibility type
- [ ] Delete record (check join tables cleared)
- [ ] Verify non-owner can't see private records
- [ ] Verify team member can see team records
- [ ] Verify selected user can see user records
- [ ] Verify admin sees all records
- [ ] Verify radio buttons toggle selectors
- [ ] Verify badges display correctly
- [ ] Test with empty teams/users
- [ ] Test migration of old visibility values

## Common Issues & Fixes

| Issue | Cause | Fix |
|-------|-------|-----|
| Radio buttons don't toggle selectors | Missing change listeners | Add event listeners in JavaScript |
| Selected teams/users not saving | Not in POST handler | Read `$_POST['teams']` and `$_POST['users']` |
| Teams not showing in selector | Teams not in users table | Check users table has team values |
| Users see wrong visibility | Visibility check failing | Review canViewRecord() logic |
| Join table entries not deleted | No CASCADE delete | Use explicit DELETE or add CASCADE to FK |
| Performance issues | Too many queries | Add indexes to join tables |

## Implementation Order

1. Update schema file with join tables
2. Add helper functions to module
3. Update POST handlers (save, edit, delete)
4. Update SELECT queries with filtering
5. Update UI with radio buttons
6. Add JavaScript event listeners
7. Add CSS for new badges
8. Test all scenarios
9. Document any module-specific changes

## Files You'll Need to Modify

For each new module:
1. `config/schema/{module}.php` - Database
2. `{module}.php` - Backend logic
3. `assets/css/{module}.css` - Styling
4. (Optional) Template files if UI is separate

## Questions to Ask

- Does the module have an owner/creator field? (required)
- Are there existing teams in users table? (for team sharing)
- Is there a display section showing these items? (for visibility badges)
- Can users select teams/users in current UI? (for backward compat)
- Should admins always see everything? (generally yes)

