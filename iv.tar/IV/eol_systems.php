<?php
/**
 * EOL Systems -- everything flagged end-of-life, in one place.
 *
 * Two tabs:
 *   EOL Assets  -- asset rows where end_of_life = yes
 *   EOL Servers -- inventory rows where eol = yes
 *
 * Read-only by design. This is a view over data that is owned and edited
 * on asset.php and inventory.php; letting it write as well would create a
 * second place to change the same records and two audit trails to
 * reconcile. Each row links back to the page that owns it.
 *
 * Gated on 'license_warranty' -- the same key as the tracker this is
 * reached from, since it answers the hardware half of the same lifecycle
 * question.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('license_warranty', 'can_view');

$canExport = can('license_warranty', 'can_export');

/* Matching is case-insensitive and trimmed: these columns are free text
   filled in by hand and by CSV import, so "Yes", "yes " and "YES" all
   occur. */
const EOL_TRUE = "LOWER(TRIM(COALESCE(%s,''))) IN ('yes','y','true','1')";

$tab = ($_GET['tab'] ?? 'assets') === 'servers' ? 'servers' : 'assets';
$q   = trim((string) ($_GET['q'] ?? ''));

$assetWhere  = [sprintf(EOL_TRUE, 'end_of_life')];
$serverWhere = [sprintf(EOL_TRUE, 'eol')];
$assetParams = $serverParams = [];

if ($q !== '') {
    $assetWhere[] = '(asset_name LIKE ? OR hostname LIKE ? OR serial_number LIKE ? OR model LIKE ? OR manufacturer LIKE ?)';
    array_push($assetParams, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");

    $serverWhere[] = '(hostname LIKE ? OR ip_address LIKE ? OR project LIKE ? OR application LIKE ? OR os_family LIKE ?)';
    array_push($serverParams, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}

$assetSql  = implode(' AND ', $assetWhere);
$serverSql = implode(' AND ', $serverWhere);


/*
|--------------------------------------------------------------------------
| EXPORT -- whichever tab is being viewed
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('license_warranty', 'can_export');

    if ($tab === 'servers') {
        platformExportCsv($pdo, 'inventory', [
            'hostname'        => 'Hostname',
            'ip_address'      => 'IP Address',
            'os_family'       => 'OS Family',
            'os_version'      => 'OS Version',
            'support_level'   => 'Support Level',
            'server_state'    => 'Server State',
            'project'         => 'Project',
            'application'     => 'Application',
            'managed_by'      => 'Managed By',
            'technical_owner' => 'Technical Owner',
            'commissioned_date' => 'Commissioned',
            'eol'             => 'EOL',
        ], $serverSql, $serverParams, 'eol_servers');
    }

    platformExportCsv($pdo, 'asset', [
        'asset_name'           => 'Asset Name',
        'hostname'             => 'Hostname',
        'ip_address'           => 'IP Address',
        'asset_type'           => 'Type',
        'manufacturer'         => 'Manufacturer',
        'model'                => 'Model',
        'serial_number'        => 'Serial Number',
        'site'                 => 'Site',
        'location'             => 'Location',
        'rack'                 => 'Rack',
        'warranty_expiry_date' => 'Warranty Expiry',
        'support_vendor'       => 'Support Vendor',
        'status'               => 'Status',
        'end_of_life'          => 'End of Life',
    ], $assetSql, $assetParams, 'eol_assets');
}


/*
|--------------------------------------------------------------------------
| DATA
|--------------------------------------------------------------------------
*/

$assets = [];
$servers = [];

try {
    $stmt = $pdo->prepare("
        SELECT id, asset_name, hostname, ip_address, asset_type, manufacturer, model,
               serial_number, site, location, rack, purchase_date,
               warranty_expiry_date, support_vendor, status, end_of_life
        FROM asset WHERE $assetSql
        ORDER BY warranty_expiry_date IS NULL, warranty_expiry_date, asset_name
    ");
    $stmt->execute($assetParams);
    $assets = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('eol_systems assets: ' . $e->getMessage());
}

try {
    $stmt = $pdo->prepare("
        SELECT id, hostname, ip_address, os_family, os_version, kernel_version,
               support_level, server_state, project, application, managed_by,
               technical_owner, commissioned_date, live, eol
        FROM inventory WHERE $serverSql
        ORDER BY hostname
    ");
    $stmt->execute($serverParams);
    $servers = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('eol_systems servers: ' . $e->getMessage());
}

$assetCount  = count($assets);
$serverCount = count($servers);

/* Warranty already expired is the actionable subset of EOL assets. */
$today = date('Y-m-d');
$warrantyExpired = 0;
foreach ($assets as $a) {
    if (!empty($a['warranty_expiry_date']) && $a['warranty_expiry_date'] < $today) {
        $warrantyExpired++;
    }
}

/* An EOL server still powered on is the one that matters operationally. */
$stillRunning = 0;
foreach ($servers as $s) {
    if (stripos((string) $s['server_state'], 'on') !== false) {
        $stillRunning++;
    }
}

function eolUrl(array $overrides = []): string
{
    $params = array_merge([
        'tab' => $_GET['tab'] ?? 'assets',
        'q'   => $_GET['q'] ?? '',
    ], $overrides);

    $params = array_filter($params, fn($v) => $v !== '' && $v !== null);

    return 'eol_systems.php' . ($params ? '?' . http_build_query($params) : '');
}

$page_title = 'EOL Systems | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">⚠</div>
            <div>
                <h1>EOL Systems</h1>
                <p>Assets and servers flagged end-of-life. Read-only — records are edited on their own pages.</p>
            </div>
        </div>
        <div class="plat-actions">
            <a class="plat-btn" href="license_warranty.php">← Licence &amp; EOL Tracker</a>
            <?php if ($canExport): ?>
                <a class="plat-btn plat-btn-primary" href="<?= plat_h(eolUrl(['action' => 'export'])) ?>">
                    Export <?= $tab === 'servers' ? 'Servers' : 'Assets' ?>
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="plat-stats">
        <div class="plat-stat tone-crit"><b><?= $assetCount ?></b><span>EOL Assets</span></div>
        <div class="plat-stat tone-crit"><b><?= $serverCount ?></b><span>EOL Servers</span></div>
        <div class="plat-stat tone-warn"><b><?= $warrantyExpired ?></b><span>Warranty Expired</span></div>
        <div class="plat-stat tone-warn"><b><?= $stillRunning ?></b><span>EOL &amp; Powered On</span></div>
    </div>

    <div class="plat-panel">

        <div class="plat-panel-head">
            <div class="eol-tabs">
                <a class="eol-tab <?= $tab === 'assets' ? 'active' : '' ?>" href="<?= plat_h(eolUrl(['tab' => 'assets'])) ?>">
                    EOL Assets <span class="eol-count"><?= $assetCount ?></span>
                </a>
                <a class="eol-tab <?= $tab === 'servers' ? 'active' : '' ?>" href="<?= plat_h(eolUrl(['tab' => 'servers'])) ?>">
                    EOL Servers <span class="eol-count"><?= $serverCount ?></span>
                </a>
            </div>

            <form method="GET" class="plat-filters" style="margin:0;">
                <input type="hidden" name="tab" value="<?= plat_h($tab) ?>">
                <div class="plat-field">
                    <input type="text" name="q" value="<?= plat_h($q) ?>"
                        placeholder="<?= $tab === 'servers' ? 'Hostname, IP, project…' : 'Asset, serial, model…' ?>">
                </div>
                <button type="submit" class="plat-btn plat-btn-accent plat-btn-sm">Search</button>
                <?php if ($q !== ''): ?>
                    <a href="<?= plat_h(eolUrl(['q' => ''])) ?>" class="plat-btn plat-btn-light plat-btn-sm">Clear</a>
                <?php endif; ?>
            </form>
        </div>

        <?php if ($tab === 'assets'): ?>

            <div class="plat-table-wrap">
                <table class="plat-table">
                    <thead>
                        <tr>
                            <th>Asset</th><th>Type</th><th>Make / Model</th><th>Serial</th>
                            <th>Location</th><th>Warranty Expiry</th><th>Support Vendor</th>
                            <th>Status</th><th style="text-align:center;">Open</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!$assets): ?>
                        <tr><td colspan="9"><p class="plat-empty">
                            <?= $q !== '' ? 'No EOL assets match that search.' : 'No assets are flagged end-of-life.' ?>
                        </p></td></tr>
                    <?php else: foreach ($assets as $a): ?>
                        <?php
                            $expired = !empty($a['warranty_expiry_date']) && $a['warranty_expiry_date'] < $today;
                            $place = array_filter([$a['site'], $a['location']]);
                        ?>
                        <tr>
                            <td>
                                <span class="plat-primary"><?= plat_h($a['asset_name'] ?: '(unnamed)') ?></span>
                                <?php if ($a['hostname'] || $a['ip_address']): ?>
                                    <span class="plat-sub"><?= plat_h(trim(($a['hostname'] ?? '') . ' ' . ($a['ip_address'] ?? ''))) ?></span>
                                <?php endif; ?>
                            </td>
                            <td><span class="plat-pill neutral"><?= plat_h($a['asset_type'] ?: '—') ?></span></td>
                            <td><?= plat_h(trim(($a['manufacturer'] ?? '') . ' ' . ($a['model'] ?? '')) ?: '—') ?></td>
                            <td><span class="plat-chip"><?= plat_h($a['serial_number'] ?: '—') ?></span></td>
                            <td>
                                <?= plat_h(implode(' / ', $place) ?: '—') ?>
                                <?php if ($a['rack']): ?><span class="plat-sub">Rack <?= plat_h($a['rack']) ?></span><?php endif; ?>
                            </td>
                            <td>
                                <?php if ($expired): ?>
                                    <span class="plat-pill crit"><?= plat_h($a['warranty_expiry_date']) ?></span>
                                    <span class="plat-sub">expired</span>
                                <?php else: ?>
                                    <?= plat_h($a['warranty_expiry_date'] ?: '—') ?>
                                <?php endif; ?>
                            </td>
                            <td><?= plat_h($a['support_vendor'] ?: '—') ?></td>
                            <td><span class="plat-pill <?= platformStatusClass((string) $a['status']) ?>"><?= plat_h($a['status'] ?: '—') ?></span></td>
                            <td style="text-align:center;">
                                <a class="plat-icon-btn plat-icon-view" title="Open in Assets"
                                   href="asset.php?tab=detail&amp;id=<?= (int) $a['id'] ?>">↗</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

        <?php else: ?>

            <div class="plat-table-wrap">
                <table class="plat-table">
                    <thead>
                        <tr>
                            <th>Hostname</th><th>IP Address</th><th>OS</th><th>Support Level</th>
                            <th>State</th><th>Project / Application</th><th>Managed By</th>
                            <th>Owner</th><th style="text-align:center;">Open</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (!$servers): ?>
                        <tr><td colspan="9"><p class="plat-empty">
                            <?= $q !== '' ? 'No EOL servers match that search.' : 'No servers are flagged end-of-life.' ?>
                        </p></td></tr>
                    <?php else: foreach ($servers as $s): ?>
                        <?php
                            $state = strtolower((string) $s['server_state']);
                            $stateClass = str_contains($state, 'on') ? 'ok' : (str_contains($state, 'off') ? 'crit' : 'neutral');
                        ?>
                        <tr>
                            <td>
                                <span class="plat-primary"><?= plat_h($s['hostname']) ?></span>
                                <?php if ($s['commissioned_date']): ?>
                                    <span class="plat-sub">commissioned <?= plat_h($s['commissioned_date']) ?></span>
                                <?php endif; ?>
                            </td>
                            <td><span class="plat-chip"><?= plat_h($s['ip_address'] ?: '—') ?></span></td>
                            <td>
                                <?= plat_h(trim(($s['os_family'] ?? '') . ' ' . ($s['os_version'] ?? '')) ?: '—') ?>
                                <?php if ($s['kernel_version']): ?><span class="plat-sub">kernel <?= plat_h($s['kernel_version']) ?></span><?php endif; ?>
                            </td>
                            <td><span class="plat-pill neutral"><?= plat_h($s['support_level'] ?: '—') ?></span></td>
                            <td><span class="plat-pill <?= $stateClass ?>"><?= plat_h($s['server_state'] ?: '—') ?></span></td>
                            <td>
                                <?= plat_h($s['project'] ?: '—') ?>
                                <?php if ($s['application']): ?><span class="plat-sub"><?= plat_h($s['application']) ?></span><?php endif; ?>
                            </td>
                            <td><?= plat_h($s['managed_by'] ?: '—') ?></td>
                            <td><?= plat_h($s['technical_owner'] ?: '—') ?></td>
                            <td style="text-align:center;">
                                <a class="plat-icon-btn plat-icon-view" title="Open in Inventory"
                                   href="inventory.php?q=<?= urlencode((string) $s['hostname']) ?>">↗</a>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>

    </div>
</div>

<style>
.eol-tabs { display: flex; gap: 4px; }

.eol-tab {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 9px 16px;
    border-radius: 9px 9px 0 0;
    font-size: 13.5px;
    font-weight: 600;
    text-decoration: none;
    color: var(--text-secondary);
    border-bottom: 2px solid transparent;
    transition: .15s;
}

.eol-tab:hover { color: var(--text-primary); background: var(--hover-bg); }

.eol-tab.active {
    color: #B42318;
    border-bottom-color: #B42318;
}

[data-theme="dark"] .eol-tab.active { color: #F1837A; border-bottom-color: #F1837A; }

.eol-count {
    display: inline-block;
    min-width: 20px;
    padding: 1px 7px;
    border-radius: 999px;
    font-size: 11.5px;
    font-weight: 700;
    text-align: center;
    background: var(--hover-bg);
    color: var(--text-secondary);
}

.eol-tab.active .eol-count { background: #FCECEA; color: #B42318; }

[data-theme="dark"] .eol-tab.active .eol-count { background: #2C1614; color: #F1837A; }
</style>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
