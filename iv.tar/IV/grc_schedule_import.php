<?php

require_once 'config/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}


/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('grc_schedule', 'can_view');
requirePermission('grc_schedule', 'can_import');



$current_user_id =
    (int) $_SESSION['user_id'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars(
        (string) $value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/*
|--------------------------------------------------------------------------
| SQLite Helpers
|--------------------------------------------------------------------------
*/

function table_exists(
    PDO $pdo,
    string $table
): bool {

    $stmt = $pdo->prepare("
        SELECT name
        FROM sqlite_master
        WHERE type = 'table'
        AND name = ?
        LIMIT 1
    ");

    $stmt->execute([
        $table
    ]);

    return (bool) $stmt->fetchColumn();
}


function table_columns(
    PDO $pdo,
    string $table
): array {

    $safe =
        str_replace(
            '"',
            '""',
            $table
        );

    $stmt =
        $pdo->query(
            'PRAGMA table_info("' .
            $safe .
            '")'
        );

    $columns = [];

    foreach (
        $stmt->fetchAll(PDO::FETCH_ASSOC)
        as $row
    ) {

        $columns[] =
            $row['name'];
    }

    return $columns;
}


function normalize_header(
    string $value
): string {

    $value =
        trim($value);

    $value =
        preg_replace(
            '/^\xEF\xBB\xBF/',
            '',
            $value
        );

    $value =
        strtolower(
            $value
        );

    $value =
        preg_replace(
            '/[^a-z0-9]+/',
            '_',
            $value
        );

    return trim(
        $value,
        '_'
    );
}


function csv_value(
    array $row,
    array $possible_names,
    string $default = ''
): string {

    foreach (
        $possible_names
        as $name
    ) {

        $key =
            normalize_header(
                $name
            );

        if (
            array_key_exists(
                $key,
                $row
            )
        ) {

            return trim(
                (string) $row[$key]
            );
        }
    }

    return $default;
}


function nullable(
    string $value
): ?string {

    $value =
        trim($value);

    return $value === ''
        ? null
        : $value;
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {

    $_SESSION['csrf_token'] =
        bin2hex(
            random_bytes(32)
        );
}


$csrf_token =
    $_SESSION['csrf_token'];


function check_csrf(): void
{
    $token =
        $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals(
            $_SESSION['csrf_token'],
            $token
        )
    ) {

        http_response_code(403);

        exit(
            'Invalid security token.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Database Check
|--------------------------------------------------------------------------
*/

if (
    !isset($pdo) ||
    !($pdo instanceof PDO)
) {

    exit(
        'Database connection is not available.'
    );
}


/*
|--------------------------------------------------------------------------
| Check Tables
|--------------------------------------------------------------------------
*/

if (
    !table_exists(
        $pdo,
        'grc_schedules'
    )
) {

    exit(
        'SQLite table grc_schedules does not exist.'
    );
}


$grc_columns =
    table_columns(
        $pdo,
        'grc_schedules'
    );


$inventory_exists =
    table_exists(
        $pdo,
        'inventory'
    );


$users_exists =
    table_exists(
        $pdo,
        'users'
    );


$inventory_columns =
    $inventory_exists
        ? table_columns(
            $pdo,
            'inventory'
        )
        : [];


$user_columns =
    $users_exists
        ? table_columns(
            $pdo,
            'users'
        )
        : [];


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$error_msg = '';

$success_msg = '';

$import_result = null;


/*
|--------------------------------------------------------------------------
| Import
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD']
    === 'POST'
) {

    check_csrf();


    if (
        !isset(
            $_FILES['csv_file']
        ) ||
        $_FILES['csv_file']['error']
        !== UPLOAD_ERR_OK
    ) {

        $error_msg =
            'Please select a CSV file.';
    }

    else {

        $file =
            $_FILES['csv_file'];


        /*
        |--------------------------------------------------------------------------
        | File validation
        |--------------------------------------------------------------------------
        */

        $extension =
            strtolower(
                pathinfo(
                    $file['name'],
                    PATHINFO_EXTENSION
                )
            );


        if ($extension !== 'csv') {

            $error_msg =
                'Only CSV files are supported.';
        }


        /*
        |--------------------------------------------------------------------------
        | Open CSV
        |--------------------------------------------------------------------------
        */

        if ($error_msg === '') {

            $handle =
                fopen(
                    $file['tmp_name'],
                    'r'
                );


            if (!$handle) {

                $error_msg =
                    'Unable to open CSV file.';
            }
        }


        /*
        |--------------------------------------------------------------------------
        | Import
        |--------------------------------------------------------------------------
        */

        if ($error_msg === '') {

            $total_rows = 0;

            $imported_rows = 0;

            $updated_rows = 0;

            $created_rows = 0;

            $skipped_rows = 0;

            $error_rows = 0;

            $errors = [];


            /*
            |--------------------------------------------------------------------------
            | CSV Header
            |--------------------------------------------------------------------------
            */

            $header =
                fgetcsv(
                    $handle
                );


            if (
                !$header ||
                count($header) === 0
            ) {

                fclose($handle);

                $error_msg =
                    'CSV file is empty.';
            }


            if ($error_msg === '') {

                $headers = [];


                foreach (
                    $header
                    as $index => $column
                ) {

                    $headers[$index] =
                        normalize_header(
                            $column
                        );
                }


                /*
                |--------------------------------------------------------------------------
                | Transaction
                |--------------------------------------------------------------------------
                */

                $pdo->beginTransaction();


                try {

                    while (
                        (
                            $csv_row =
                            fgetcsv(
                                $handle
                            )
                        ) !== false
                    ) {

                        /*
                        |--------------------------------------------------------------------------
                        | Skip empty rows
                        |--------------------------------------------------------------------------
                        */

                        $is_empty = true;

                        foreach (
                            $csv_row
                            as $value
                        ) {

                            if (
                                trim(
                                    (string) $value
                                ) !== ''
                            ) {

                                $is_empty = false;

                                break;
                            }
                        }


                        if ($is_empty) {
                            continue;
                        }


                        $total_rows++;


                        /*
                        |--------------------------------------------------------------------------
                        | Convert CSV to associative array
                        |--------------------------------------------------------------------------
                        */

                        $row = [];


                        foreach (
                            $headers
                            as $index => $column
                        ) {

                            $row[$column] =
                                $csv_row[$index]
                                ?? '';
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Read values
                        |--------------------------------------------------------------------------
                        */

                        $schedule_id =
                            (int) csv_value(
                                $row,
                                [
                                    'Schedule ID',
                                    'ID',
                                    'schedule_id'
                                ]
                            );


                        $hostname =
                            csv_value(
                                $row,
                                [
                                    'Hostname',
                                    'hostname',
                                    'Host'
                                ]
                            );


                        $project =
                            csv_value(
                                $row,
                                [
                                    'Project',
                                    'project'
                                ]
                            );


                        $support_level =
                            csv_value(
                                $row,
                                [
                                    'Support Level',
                                    'support_level',
                                    'Support'
                                ]
                            );


                        $recurrence =
                            (int) csv_value(
                                $row,
                                [
                                    'Recurrence Days',
                                    'recurrence_interval_days',
                                    'Recurrence'
                                ],
                                '30'
                            );


                        if ($recurrence < 1) {
                            $recurrence = 30;
                        }


                        $scheduled_time =
                            csv_value(
                                $row,
                                [
                                    'Scheduled Time',
                                    'scheduled_time',
                                    'Scheduled'
                                ]
                            );


                        $patched_time =
                            csv_value(
                                $row,
                                [
                                    'Patched Time',
                                    'patched_time',
                                    'Patched'
                                ]
                            );


                        $next_date =
                            csv_value(
                                $row,
                                [
                                    'Next Date',
                                    'next_date'
                                ]
                            );


                        $status =
                            csv_value(
                                $row,
                                [
                                    'Status',
                                    'status'
                                ],
                                'Planned'
                            );


                        $new_os =
                            csv_value(
                                $row,
                                [
                                    'New OS Version',
                                    'new_os_version'
                                ]
                            );


                        $new_kernel =
                            csv_value(
                                $row,
                                [
                                    'New Kernel Version',
                                    'New Kernel',
                                    'new_kernel_version'
                                ]
                            );


                        $change_request =
                            csv_value(
                                $row,
                                [
                                    'Change Request',
                                    'CR',
                                    'CRQ',
                                    'change_request'
                                ]
                            );


                        $comments =
                            csv_value(
                                $row,
                                [
                                    'Comments',
                                    'comments',
                                    'Notes',
                                    'notes'
                                ]
                            );


                        $assignee_email =
                            csv_value(
                                $row,
                                [
                                    'Assignee Email',
                                    'assignee_email'
                                ]
                            );


                        $assignee_name =
                            csv_value(
                                $row,
                                [
                                    'Assignee',
                                    'assignee'
                                ]
                            );


                        /*
                        |--------------------------------------------------------------------------
                        | Validation
                        |--------------------------------------------------------------------------
                        */

                        if ($project === '') {

                            $skipped_rows++;

                            $errors[] =
                                "Row {$total_rows}: Project is required.";

                            continue;
                        }


                        if (
                            $support_level === ''
                        ) {

                            $skipped_rows++;

                            $errors[] =
                                "Row {$total_rows}: Support Level is required.";

                            continue;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Find inventory
                        |--------------------------------------------------------------------------
                        */

                        $inventory = null;


                        if (
                            $hostname !== '' &&
                            $inventory_exists &&
                            in_array(
                                'hostname',
                                $inventory_columns,
                                true
                            )
                        ) {

                            $stmt =
                                $pdo->prepare("
                                    SELECT *
                                    FROM inventory
                                    WHERE hostname = ?
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $hostname
                            ]);

                            $inventory =
                                $stmt->fetch(
                                    PDO::FETCH_ASSOC
                                );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Inventory ID
                        |--------------------------------------------------------------------------
                        */

                        $inventory_id = 0;


                        if (
                            $inventory &&
                            isset(
                                $inventory['id']
                            )
                        ) {

                            $inventory_id =
                                (int) $inventory['id'];
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Require inventory only when schema needs it
                        |--------------------------------------------------------------------------
                        */

                        $requires_inventory =
                            in_array(
                                'inventory_id',
                                $grc_columns,
                                true
                            );


                        if (
                            $requires_inventory &&
                            $inventory_id <= 0
                        ) {

                            $skipped_rows++;

                            $errors[] =
                                "Row {$total_rows}: Hostname '{$hostname}' was not found in inventory.";

                            continue;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | GRC validation
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $inventory &&
                            array_key_exists(
                                'grc',
                                $inventory
                            )
                        ) {

                            if (
                                strtolower(
                                    trim(
                                        (string)
                                        $inventory['grc']
                                    )
                                ) !== 'yes'
                            ) {

                                $skipped_rows++;

                                $errors[] =
                                    "Row {$total_rows}: Host '{$hostname}' is not marked GRC = yes.";

                                continue;
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Assignee
                        |--------------------------------------------------------------------------
                        */

                        $assignee_id = null;


                        if (
                            $assignee_email !== '' &&
                            $users_exists &&
                            in_array(
                                'email',
                                $user_columns,
                                true
                            )
                        ) {

                            $stmt =
                                $pdo->prepare("
                                    SELECT id
                                    FROM users
                                    WHERE LOWER(email) = LOWER(?)
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $assignee_email
                            ]);

                            $assignee_id =
                                $stmt->fetchColumn();

                            if (
                                $assignee_id !== false
                            ) {

                                $assignee_id =
                                    (int)
                                    $assignee_id;
                            }
                            else {

                                $assignee_id = null;
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Fallback by name
                        |--------------------------------------------------------------------------
                        */

                        if (
                            !$assignee_id &&
                            $assignee_name !== '' &&
                            $users_exists &&
                            in_array(
                                'first_name',
                                $user_columns,
                                true
                            ) &&
                            in_array(
                                'last_name',
                                $user_columns,
                                true
                            )
                        ) {

                            $parts =
                                preg_split(
                                    '/\s+/',
                                    trim(
                                        $assignee_name
                                    ),
                                    2
                                );


                            $first =
                                $parts[0] ?? '';


                            $last =
                                $parts[1] ?? '';


                            $stmt =
                                $pdo->prepare("
                                    SELECT id
                                    FROM users
                                    WHERE LOWER(first_name) = LOWER(?)
                                    AND LOWER(last_name) = LOWER(?)
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $first,
                                $last
                            ]);


                            $found =
                                $stmt->fetchColumn();


                            if (
                                $found !== false
                            ) {

                                $assignee_id =
                                    (int) $found;
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Find existing schedule
                        |--------------------------------------------------------------------------
                        */

                        $existing = null;


                        /*
                        |--------------------------------------------------------------------------
                        | First choice: Schedule ID
                        |--------------------------------------------------------------------------
                        */

                        if (
                            $schedule_id > 0 &&
                            in_array(
                                'id',
                                $grc_columns,
                                true
                            )
                        ) {

                            $stmt =
                                $pdo->prepare("
                                    SELECT *
                                    FROM grc_schedules
                                    WHERE id = ?
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $schedule_id
                            ]);

                            $existing =
                                $stmt->fetch(
                                    PDO::FETCH_ASSOC
                                );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Second choice:
                        | inventory_id + project
                        |--------------------------------------------------------------------------
                        */

                        if (
                            !$existing &&
                            $inventory_id > 0 &&
                            in_array(
                                'inventory_id',
                                $grc_columns,
                                true
                            )
                        ) {

                            $stmt =
                                $pdo->prepare("
                                    SELECT *
                                    FROM grc_schedules
                                    WHERE inventory_id = ?
                                    AND project = ?
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $inventory_id,
                                $project
                            ]);

                            $existing =
                                $stmt->fetch(
                                    PDO::FETCH_ASSOC
                                );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Third choice:
                        | hostname + project
                        |--------------------------------------------------------------------------
                        */

                        if (
                            !$existing &&
                            $hostname !== '' &&
                            in_array(
                                'hostname',
                                $grc_columns,
                                true
                            )
                        ) {

                            $stmt =
                                $pdo->prepare("
                                    SELECT *
                                    FROM grc_schedules
                                    WHERE hostname = ?
                                    AND project = ?
                                    LIMIT 1
                                ");

                            $stmt->execute([
                                $hostname,
                                $project
                            ]);

                            $existing =
                                $stmt->fetch(
                                    PDO::FETCH_ASSOC
                                );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Build values based on actual columns
                        |--------------------------------------------------------------------------
                        */

                        $values = [];


                        /*
                        |--------------------------------------------------------------------------
                        | inventory_id
                        |--------------------------------------------------------------------------
                        */

                        if (
                            in_array(
                                'inventory_id',
                                $grc_columns,
                                true
                            )
                        ) {

                            $values['inventory_id'] =
                                $inventory_id;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | hostname
                        |--------------------------------------------------------------------------
                        */

                        if (
                            in_array(
                                'hostname',
                                $grc_columns,
                                true
                            )
                        ) {

                            $values['hostname'] =
                                nullable(
                                    $hostname
                                );
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Standard fields
                        |--------------------------------------------------------------------------
                        */

                        $possible_fields = [

                            'project' =>
                                $project,

                            'support_level' =>
                                $support_level,

                            'recurrence_interval_days' =>
                                $recurrence,

                            'scheduled_time' =>
                                nullable(
                                    $scheduled_time
                                ),

                            'patched_time' =>
                                nullable(
                                    $patched_time
                                ),

                            'next_date' =>
                                nullable(
                                    $next_date
                                ),

                            'assignee_id' =>
                                $assignee_id,

                            'status' =>
                                $status,

                            'new_kernel_version' =>
                                nullable(
                                    $new_kernel
                                ),

                            'new_os_version' =>
                                nullable(
                                    $new_os
                                ),

                            'change_request' =>
                                nullable(
                                    $change_request
                                ),

                            'comments' =>
                                nullable(
                                    $comments
                                )

                        ];


                        foreach (
                            $possible_fields
                            as $field => $value
                        ) {

                            if (
                                in_array(
                                    $field,
                                    $grc_columns,
                                    true
                                )
                            ) {

                                $values[$field] =
                                    $value;
                            }
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Created / updated fields
                        |--------------------------------------------------------------------------
                        */

                        if (
                            !$existing &&
                            in_array(
                                'created_by',
                                $grc_columns,
                                true
                            )
                        ) {

                            $values['created_by'] =
                                $current_user_id;
                        }


                        if (
                            in_array(
                                'updated_by',
                                $grc_columns,
                                true
                            )
                        ) {

                            $values['updated_by'] =
                                $current_user_id;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | INSERT
                        |--------------------------------------------------------------------------
                        */

                        if (!$existing) {

                            /*
                            | Do not insert id.
                            | SQLite will auto-generate it.
                            */

                            $insert_fields =
                                array_keys(
                                    $values
                                );


                            if (
                                !$insert_fields
                            ) {

                                $skipped_rows++;

                                $errors[] =
                                    "Row {$total_rows}: No compatible columns found.";

                                continue;
                            }


                            $field_sql =
                                implode(
                                    ', ',
                                    array_map(
                                        function (
                                            $field
                                        ) {
                                            return '"' .
                                                str_replace(
                                                    '"',
                                                    '""',
                                                    $field
                                                ) .
                                                '"';
                                        },
                                        $insert_fields
                                    )
                                );


                            $placeholders =
                                implode(
                                    ', ',
                                    array_fill(
                                        0,
                                        count(
                                            $insert_fields
                                        ),
                                        '?'
                                    )
                                );


                            $insert_sql = "
                                INSERT INTO grc_schedules
                                ($field_sql)
                                VALUES
                                ($placeholders)
                            ";


                            $stmt =
                                $pdo->prepare(
                                    $insert_sql
                                );


                            $insert_values = [];


                            foreach (
                                $insert_fields
                                as $field
                            ) {

                                $insert_values[] =
                                    $values[$field];
                            }


                            $stmt->execute(
                                $insert_values
                            );


                            $created_rows++;

                            $imported_rows++;

                            continue;
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | UPDATE
                        |--------------------------------------------------------------------------
                        */

                        $update_fields = [];


                        foreach (
                            $values
                            as $field => $value
                        ) {

                            /*
                            | Never update primary key.
                            */

                            if (
                                $field === 'id'
                            ) {
                                continue;
                            }


                            /*
                            | Do not change created_by.
                            */

                            if (
                                $field === 'created_by'
                            ) {
                                continue;
                            }


                            /*
                            | Don't overwrite created_at.
                            */

                            if (
                                $field === 'created_at'
                            ) {
                                continue;
                            }


                            $update_fields[$field] =
                                $value;
                        }


                        if (
                            !$update_fields
                        ) {

                            $skipped_rows++;

                            $errors[] =
                                "Row {$total_rows}: Nothing to update.";

                            continue;
                        }


                        $set_parts = [];


                        foreach (
                            $update_fields
                            as $field => $value
                        ) {

                            $set_parts[] =
                                '"' .
                                str_replace(
                                    '"',
                                    '""',
                                    $field
                                ) .
                                '" = ?';
                        }


                        /*
                        |--------------------------------------------------------------------------
                        | Determine ID
                        |--------------------------------------------------------------------------
                        */

                        $existing_id =
                            (int) (
                                $existing['id']
                                ?? 0
                            );


                        if (
                            $existing_id <= 0
                        ) {

                            $skipped_rows++;

                            $errors[] =
                                "Row {$total_rows}: Existing schedule has no valid ID.";

                            continue;
                        }


                        $update_sql = "
                            UPDATE grc_schedules
                            SET
                                " .
                                implode(
                                    ', ',
                                    $set_parts
                                ) .
                                "
                            WHERE id = ?
                        ";


                        $update_values =
                            array_values(
                                $update_fields
                            );


                        $update_values[] =
                            $existing_id;


                        $stmt =
                            $pdo->prepare(
                                $update_sql
                            );


                        $stmt->execute(
                            $update_values
                        );


                        $updated_rows++;

                        $imported_rows++;
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Commit
                    |--------------------------------------------------------------------------
                    */

                    $pdo->commit();


                    fclose($handle);


                    /*
                    |--------------------------------------------------------------------------
                    | Import Log
                    |--------------------------------------------------------------------------
                    */

                    if (
                        table_exists(
                            $pdo,
                            'grc_schedule_import_log'
                        )
                    ) {

                        $log_columns =
                            table_columns(
                                $pdo,
                                'grc_schedule_import_log'
                            );


                        $log_values = [];


                        if (
                            in_array(
                                'filename',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['filename'] =
                                $file['name'];
                        }


                        if (
                            in_array(
                                'total_rows',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['total_rows'] =
                                $total_rows;
                        }


                        if (
                            in_array(
                                'imported_rows',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['imported_rows'] =
                                $imported_rows;
                        }


                        if (
                            in_array(
                                'skipped_rows',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['skipped_rows'] =
                                $skipped_rows;
                        }


                        if (
                            in_array(
                                'error_rows',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['error_rows'] =
                                $error_rows +
                                count($errors);
                        }


                        if (
                            in_array(
                                'imported_by',
                                $log_columns,
                                true
                            )
                        ) {

                            $log_values['imported_by'] =
                                $current_user_id;
                        }


                        if ($log_values) {

                            $fields =
                                array_keys(
                                    $log_values
                                );


                            $sql_fields =
                                implode(
                                    ', ',
                                    $fields
                                );


                            $placeholders =
                                implode(
                                    ', ',
                                    array_fill(
                                        0,
                                        count(
                                            $fields
                                        ),
                                        '?'
                                    )
                                );


                            $stmt =
                                $pdo->prepare("
                                    INSERT INTO
                                    grc_schedule_import_log
                                    ($sql_fields)
                                    VALUES
                                    ($placeholders)
                                ");


                            $stmt->execute(
                                array_values(
                                    $log_values
                                )
                            );
                        }
                    }


                    /*
                    |--------------------------------------------------------------------------
                    | Result
                    |--------------------------------------------------------------------------
                    */

                    $import_result = [

                        'total' =>
                            $total_rows,

                        'imported' =>
                            $imported_rows,

                        'created' =>
                            $created_rows,

                        'updated' =>
                            $updated_rows,

                        'skipped' =>
                            $skipped_rows,

                        'errors' =>
                            count($errors),

                        'messages' =>
                            $errors

                    ];
                }

                catch (Throwable $e) {

                    if (
                        $pdo->inTransaction()
                    ) {

                        $pdo->rollBack();
                    }


                    fclose($handle);


                    $error_msg =
                        'Import failed: ' .
                        $e->getMessage();
                }
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| Page
|--------------------------------------------------------------------------
*/

$page_title =
    'GRC Schedule Import';


require_once 'includes/header.php';

require_once 'includes/sidebar.php';

?>

<link
    rel="stylesheet"
    href="assets/css/grc_schedule.css"
>


<div class="content grc-content">


    <div class="grc-page-header">

        <div>

            <div class="grc-eyebrow">
                Infrastructure Compliance
            </div>

            <h1>
                Import GRC Schedule
            </h1>

            <p>
                Import or update GRC patching schedules
                from CSV.
            </p>

        </div>


        <div class="grc-header-actions">

            <a
                href="grc_schedule.php"
                class="grc-btn secondary"
            >
                ← Back to Schedule
            </a>

        </div>

    </div>


    <?php if ($error_msg): ?>

        <div class="grc-alert error">

            <?= h($error_msg) ?>

        </div>

    <?php endif; ?>


    <?php if ($import_result): ?>

        <div class="grc-alert success">

            <strong>
                Import completed.
            </strong>

            <br><br>

            Total rows:
            <strong>
                <?= (int) $import_result['total'] ?>
            </strong>

            &nbsp; | &nbsp;

            Imported:
            <strong>
                <?= (int) $import_result['imported'] ?>
            </strong>

            &nbsp; | &nbsp;

            Created:
            <strong>
                <?= (int) $import_result['created'] ?>
            </strong>

            &nbsp; | &nbsp;

            Updated:
            <strong>
                <?= (int) $import_result['updated'] ?>
            </strong>

            &nbsp; | &nbsp;

            Skipped:
            <strong>
                <?= (int) $import_result['skipped'] ?>
            </strong>

            &nbsp; | &nbsp;

            Errors:
            <strong>
                <?= (int) $import_result['errors'] ?>
            </strong>

        </div>


        <?php if (
            !empty(
                $import_result['messages']
            )
        ): ?>

            <div class="grc-panel">

                <div class="grc-panel-header">

                    <div>

                        <h2>
                            Import Messages
                        </h2>

                    </div>

                </div>


                <div
                    style="
                        padding:20px;
                        max-height:400px;
                        overflow:auto;
                    "
                >

                    <?php foreach (
                        $import_result['messages']
                        as $message
                    ): ?>

                        <div
                            style="
                                padding:8px 0;
                                border-bottom:1px solid #eee;
                            "
                        >

                            <?= h($message) ?>

                        </div>

                    <?php endforeach; ?>

                </div>

            </div>

        <?php endif; ?>

    <?php endif; ?>


    <div class="grc-panel">

        <div class="grc-panel-header">

            <div>

                <h2>
                    CSV Import
                </h2>

                <span>
                    Import GRC patching schedules
                </span>

            </div>

        </div>


        <div style="padding:25px;">


            <form
                method="POST"
                enctype="multipart/form-data"
            >

                <input
                    type="hidden"
                    name="csrf_token"
                    value="<?= h($csrf_token) ?>"
                >


                <div
                    class="grc-form-section"
                    style="margin-bottom:20px;"
                >

                    <div
                        class="grc-form-section-title"
                    >

                        <h3>
                            Select CSV File
                        </h3>

                        <span>
                            Use the CSV generated by Export CSV
                        </span>

                    </div>


                    <div class="grc-field">

                        <label>
                            CSV File *
                        </label>

                        <input
                            type="file"
                            name="csv_file"
                            accept=".csv,text/csv"
                            required
                        >

                        <small>
                            The recommended format is the CSV
                            produced by the GRC Schedule Export.
                        </small>

                    </div>

                </div>


                <div
                    class="grc-form-section"
                    style="margin-bottom:20px;"
                >

                    <div
                        class="grc-form-section-title"
                    >

                        <h3>
                            Import Behaviour
                        </h3>

                    </div>


                    <div
                        style="
                            line-height:1.8;
                            color:#555;
                        "
                    >

                        <div>
                            <strong>Existing schedule:</strong>
                            Updated using Schedule ID when available.
                        </div>

                        <div>
                            <strong>Without Schedule ID:</strong>
                            Hostname + Project is used where supported.
                        </div>

                        <div>
                            <strong>New schedule:</strong>
                            Created automatically when no matching schedule exists.
                        </div>

                        <div>
                            <strong>Inventory:</strong>
                            Hostname is matched against the inventory table.
                        </div>

                        <div>
                            <strong>GRC:</strong>
                            Hosts marked GRC = no are rejected.
                        </div>

                        <div>
                            <strong>Missing SQLite columns:</strong>
                            They are ignored rather than causing SQL errors.
                        </div>

                    </div>

                </div>


                <div
                    style="
                        display:flex;
                        gap:10px;
                        justify-content:flex-end;
                    "
                >

                    <a
                        href="grc_schedule.php"
                        class="grc-btn secondary"
                    >
                        Cancel
                    </a>


                    <button
                        type="submit"
                        class="grc-btn primary"
                    >
                        Import CSV
                    </button>

                </div>

            </form>

        </div>

    </div>


</div>


<?php

require_once 'includes/footer.php';

?>
