<?php

// reminder_notification_daemon.php
//
// Self-contained long-running notifier for container deployments with no
// cron daemon available. Loops forever, checking for due reminders every
// CHECK_INTERVAL_SECONDS, so it doesn't depend on anything outside PHP
// itself for scheduling.
//
// Run it as the container's foreground process (so Podman can supervise
// restarts) or as a sidecar container alongside the web app, e.g.:
//
//   podman run -d --name infravault-reminders \
//     -v infravault_data:/var/www/html/config:Z \
//     your-infravault-image \
//     php /var/www/html/reminder_notification_daemon.php
//
// Or as a Containerfile CMD for a dedicated worker image:
//   CMD ["php", "/var/www/html/reminder_notification_daemon.php"]
//
// It is NOT meant to be opened in a browser — it has no session/auth
// check because it's a command-line script, and it never exits on its
// own (stop it the normal container way -- `podman stop`, which sends
// SIGTERM; handled below for a clean shutdown instead of a hard kill).
//
// If you already have cron/systemd available and prefer that instead,
// use reminder_notification_cron.php (a one-shot check) on a `* * * * *`
// / OnCalendar=*-*-* *:*:00 schedule instead of this daemon.

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script may only be run from the command line.\n");
}

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/reminder-mail.php';

const CHECK_INTERVAL_SECONDS = 60;

$running = true;

if (function_exists('pcntl_async_signals')) {
    pcntl_async_signals(true);
    pcntl_signal(SIGTERM, function () use (&$running) { $running = false; });
    pcntl_signal(SIGINT, function () use (&$running) { $running = false; });
} else {
    echo "[WARN] pcntl extension not available -- container stop will terminate this process immediately rather than shutting down between checks. This still works correctly, it just won't log a clean exit line.\n";
}

echo "InfraVault reminder notification daemon started — " . date('Y-m-d H:i:s') . " (checking every " . CHECK_INTERVAL_SECONDS . "s)\n";

while ($running) {

    $result = checkAndSendDueReminders($pdo);

    if ($result['considered'] > 0) {
        echo "[" . date('Y-m-d H:i:s') . "] " . implode("\n", $result['log']) . "\n";
        echo "[" . date('Y-m-d H:i:s') . "] {$result['sent']} sent, {$result['failed']} with at least one failed recipient, {$result['considered']} considered.\n";
    }

    // sleep() is interrupted immediately by SIGTERM/SIGINT when pcntl_async_signals
    // is on, so a `podman stop` doesn't have to wait out the full interval.
    sleep(CHECK_INTERVAL_SECONDS);
}

echo "InfraVault reminder notification daemon stopping — " . date('Y-m-d H:i:s') . "\n";
exit(0);
