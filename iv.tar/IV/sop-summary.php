<?php
session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('sop', 'can_view');


function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

/**
 * Small local icon set for this dashboard -- matches the inline-SVG,
 * stroke-based style already used across the SOP/Inventory pages rather
 * than pulling in an icon font/library.
 */
function dashIcon(string $name, string $class = 'dsi'): string
{
    $paths = [
        'document'    => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
        'user-doc'    => '<path d="M9 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V11"/><path d="M9 2v5a2 2 0 0 0 2 2h5"/><circle cx="17" cy="6" r="3"/>',
        'edit'        => '<path d="M4 20h4l10.5-10.5a2.1 2.1 0 0 0-3-3L5 17v3Z"/><path d="m14.5 7.5 3 3"/>',
        'check-circle'=> '<circle cx="12" cy="12" r="9"/><path d="m8.5 12.5 2.5 2.5 5-5"/>',
        'clock'       => '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3.5 2"/>',
        'users'       => '<path d="M17 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'alert'       => '<path d="m10.3 3.9-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.7-3.1l-8-14a2 2 0 0 0-3.4 0Z"/><path d="M12 9v4"/><path d="M12 17h.01"/>',
        'trend'       => '<polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/>',
        'plus'        => '<path d="M12 5v14M5 12h14"/>',
        'folder'      => '<path d="M4 20h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-9.5L9 4H4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1Z"/>',
        'shield'      => '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
        'award'       => '<circle cx="12" cy="8" r="6"/><path d="M8.2 13.6 6 22l6-3 6 3-2.2-8.4"/>',
        'activity'    => '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
        'library'     => '<path d="M3 3h4v18H3z"/><path d="M9 3h4v18H9z"/><path d="M16 3.5 20 5v16l-4-1.5Z"/>',
        'arrow-right' => '<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>',
        'history'     => '<path d="M3 12a9 9 0 1 0 3-6.7"/><path d="M3 4v6h6"/><path d="M12 7v5l3 2"/>',
    ];
    $body = $paths[$name] ?? $paths['document'];
    return '<svg class="' . h($class) . '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . $body . '</svg>';
}

$current_user_id = (int)$_SESSION['user_id'];
$user_role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($user_role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

$userStmt = $pdo->prepare("SELECT first_name, team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';
$user_first_name = $userRecord['first_name'] ?? ($_SESSION['first_name'] ?? 'there');

$canView = hasRolePermission($pdo, $user_role, 'sop', 'can_view');
$canCreate = hasRolePermission($pdo, $user_role, 'sop', 'can_edit');
$canAudit = hasRolePermission($pdo, $user_role, 'sop', 'can_audit');

if (!$is_admin && !$canView) {
    http_response_code(403);
    exit('You do not have permission to view SOPs.');
}

$visibilityWhere = "
    owner_id = ?
    OR (visibility = 'public')
    OR (visibility = 'team' AND owner_team = ?)
    OR (visibility = 'teams' AND id IN (SELECT sop_id FROM sop_teams WHERE team_name = ?))
";
$visibilityParams = [$current_user_id, $user_team, $user_team];

$stats = [];

$visibleStmt = $pdo->prepare("SELECT COUNT(*) FROM sops WHERE $visibilityWhere");
$visibleStmt->execute($visibilityParams);
$stats['total_visible'] = (int) $visibleStmt->fetchColumn();

$scopeWhere = ($is_admin || $canAudit) ? '1=1' : $visibilityWhere;
$scopeParams = ($is_admin || $canAudit) ? [] : $visibilityParams;

$statusStmt = $pdo->prepare("
    SELECT COALESCE(status, 'Draft') as status, COUNT(*) as count
    FROM sops WHERE $scopeWhere GROUP BY status
");
$statusStmt->execute($scopeParams);
$stats['by_status'] = $statusStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$criticalityStmt = $pdo->prepare("
    SELECT COALESCE(criticality, 'Medium') as criticality, COUNT(*) as count
    FROM sops WHERE $scopeWhere GROUP BY criticality
");
$criticalityStmt->execute($scopeParams);
$stats['by_criticality'] = $criticalityStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$categoryStmt = $pdo->prepare("
    SELECT category, COUNT(*) as count
    FROM sops WHERE $scopeWhere GROUP BY category ORDER BY count DESC LIMIT 8
");
$categoryStmt->execute($scopeParams);
$stats['by_category'] = $categoryStmt->fetchAll(PDO::FETCH_KEY_PAIR);

$myStmt = $pdo->prepare("SELECT COUNT(*) FROM sops WHERE owner_id = ?");
$myStmt->execute([$current_user_id]);
$stats['my_sops'] = (int) $myStmt->fetchColumn();

if ($canCreate) {
    $editableStmt = $pdo->prepare("SELECT COUNT(*) FROM sops WHERE $visibilityWhere");
    $editableStmt->execute($visibilityParams);
    $stats['editable'] = (int) $editableStmt->fetchColumn();
} else {
    $stats['editable'] = $stats['my_sops'];
}

if ($is_admin || $canAudit) {
    $teamStmt = $pdo->prepare("SELECT COUNT(*) FROM sops WHERE owner_team = ? OR visibility = 'public'");
    $teamStmt->execute([$user_team]);
    $stats['team_sops'] = (int) $teamStmt->fetchColumn();
} else {
    $stats['team_sops'] = null;
}

// Published SOPs whose review_date has passed -- an operational-health
// signal that doesn't exist anywhere else in this module yet.
$overdueStmt = $pdo->prepare("
    SELECT COUNT(*) FROM sops
    WHERE $scopeWhere
      AND status = 'Published'
      AND review_date IS NOT NULL
      AND review_date < date('now')
");
$overdueStmt->execute($scopeParams);
$stats['overdue_review'] = (int) $overdueStmt->fetchColumn();

$recentUpdatedStmt = $pdo->prepare("
    SELECT COUNT(*) FROM sops WHERE $scopeWhere AND updated_at >= datetime('now', '-7 days')
");
$recentUpdatedStmt->execute($scopeParams);
$stats['recently_updated'] = (int) $recentUpdatedStmt->fetchColumn();

$stats['recent_actions'] = [];
if ($canAudit) {
    $recentStmt = $pdo->query("
        SELECT sa.action, sa.user_name, sa.action_date, s.id as sop_id, s.sop_number, s.title
        FROM sop_audit sa
        JOIN sops s ON sa.sop_id = s.id
        ORDER BY sa.action_date DESC
        LIMIT 8
    ");
    $stats['recent_actions'] = $recentStmt->fetchAll(PDO::FETCH_ASSOC);
}

$stats['top_authors'] = [];
if ($is_admin || $canAudit) {
    $authorsStmt = $pdo->query("
        SELECT
            owner_id,
            -- COALESCE wraps the whole subquery: an owner_id with no matching
            -- users row (deleted user, or NULL owner_id) makes the subquery
            -- itself NULL, which the inner COALESCE can never catch.
            COALESCE(
                (SELECT COALESCE(first_name || ' ' || last_name, ncgr_id) FROM users WHERE id = sops.owner_id),
                'Unknown'
            ) as author_name,
            COUNT(*) as sop_count
        FROM sops
        GROUP BY owner_id
        ORDER BY sop_count DESC
        LIMIT 5
    ");
    $stats['top_authors'] = $authorsStmt->fetchAll(PDO::FETCH_ASSOC);
}

$hour = (int) date('G');
$greeting = $hour < 12 ? 'Good morning' : ($hour < 18 ? 'Good afternoon' : 'Good evening');

/* Criticality and status tints are theme-dependent, so they are emitted as
   class names rather than inline style attributes: an inline style wins over
   any [data-theme="dark"] rule short of !important, which would have left
   these chips and bars stuck on their light-mode colours. Unknown values fall
   back to the neutral class. */
$criticalityClasses = [
    'critical' => 'crit-critical',
    'high' => 'crit-high',
    'medium' => 'crit-medium',
    'low' => 'crit-low',
];

$statusClasses = [
    'published' => 'st-published',
    'pending review' => 'st-pending',
    'draft' => 'st-draft',
    'rejected' => 'st-rejected',
];

$actionIcons = [
    'created' => 'plus',
    'edited' => 'edit',
    'updated' => 'edit',
    'published' => 'check-circle',
    'deleted' => 'alert',
    'visibility_changed' => 'shield',
];

$page_title = "SOP Dashboard | InfraVault";
require 'includes/header.php';
?>

<link rel="stylesheet" href="assets/css/dashboard.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

    <!-- HERO -->
    <div class="sopdash-hero">
        <div class="sopdash-hero-text">
            <span class="sopdash-eyebrow"><?php echo dashIcon('library', 'dsi dsi-sm'); ?> SOP Library</span>
            <h1><?php echo $greeting; ?>, <?php echo h($user_first_name); ?>.</h1>
            <p>
                This is your home for Standard Operating Procedures &mdash; controlled, version-tracked
                infrastructure runbooks with built-in review, approval, and team-based sharing.
                <?php if ($stats['overdue_review'] > 0): ?>
                    <strong><?php echo $stats['overdue_review']; ?> published SOP<?php echo $stats['overdue_review'] === 1 ? '' : 's'; ?></strong>
                    <?php echo $stats['overdue_review'] === 1 ? 'is' : 'are'; ?> currently past its scheduled review date.
                <?php endif; ?>
            </p>
            <div class="sopdash-hero-actions">
                <?php if ($canCreate): ?>
                    <a href="sop.php?action=create" class="sopdash-btn sopdash-btn-primary">
                        <?php echo dashIcon('plus'); ?> Create SOP
                    </a>
                <?php endif; ?>
                <a href="sop.php" class="sopdash-btn sopdash-btn-ghost">
                    Browse Library <?php echo dashIcon('arrow-right', 'dsi dsi-sm'); ?>
                </a>
                <?php if ($is_admin): ?>
                    <a href="sop.php?action=header_footer" class="sopdash-btn sopdash-btn-ghost">
                        <?php echo dashIcon('document', 'dsi dsi-sm'); ?> Header &amp; Footer
                    </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="sopdash-hero-icon"><?php echo dashIcon('document', 'dsi dsi-hero'); ?></div>
    </div>

    <!-- KPI CARDS -->
    <div class="sopdash-kpi-grid">
        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon blue"><?php echo dashIcon('document'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['total_visible']; ?></div>
                <div class="sopdash-kpi-label">Accessible to You</div>
            </div>
        </div>

        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon violet"><?php echo dashIcon('user-doc'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['my_sops']; ?></div>
                <div class="sopdash-kpi-label">Authored by You</div>
            </div>
        </div>

        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon teal"><?php echo dashIcon('edit'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['editable']; ?></div>
                <div class="sopdash-kpi-label">You Can Edit</div>
            </div>
        </div>

        <?php if ($stats['team_sops'] !== null): ?>
        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon indigo"><?php echo dashIcon('users'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['team_sops']; ?></div>
                <div class="sopdash-kpi-label">Team SOPs</div>
            </div>
        </div>
        <?php endif; ?>

        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon <?php echo $stats['overdue_review'] > 0 ? 'red' : 'green'; ?>"><?php echo dashIcon('alert'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['overdue_review']; ?></div>
                <div class="sopdash-kpi-label">Review Overdue</div>
            </div>
        </div>

        <div class="sopdash-kpi">
            <div class="sopdash-kpi-icon amber"><?php echo dashIcon('trend'); ?></div>
            <div>
                <div class="sopdash-kpi-value"><?php echo $stats['recently_updated']; ?></div>
                <div class="sopdash-kpi-label">Updated (7 days)</div>
            </div>
        </div>
    </div>

    <div class="sopdash-columns">

        <!-- LEFT COLUMN -->
        <div class="sopdash-col-main">

            <?php if (!empty($stats['by_status'])): ?>
            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <?php echo dashIcon('activity', 'dsi dsi-sm'); ?>
                    <h2>Status Breakdown</h2>
                </div>
                <div class="sopdash-panel-body">
                    <?php
                    $statusTotal = max(1, array_sum($stats['by_status']));
                    foreach ($stats['by_status'] as $status => $count):
                        $pct = round(($count / $statusTotal) * 100);
                        $statusClass = $statusClasses[strtolower($status)] ?? 'st-draft';
                    ?>
                        <div class="sopdash-bar-row">
                            <div class="sopdash-bar-label">
                                <span><?php echo h(ucwords($status)); ?></span>
                                <strong><?php echo (int)$count; ?></strong>
                            </div>
                            <div class="sopdash-bar-track">
                                <div class="sopdash-bar-fill <?php echo $statusClass; ?>" style="width: <?php echo $pct; ?>%;"></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($stats['by_criticality'])): ?>
            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <?php echo dashIcon('shield', 'dsi dsi-sm'); ?>
                    <h2>By Criticality</h2>
                </div>
                <div class="sopdash-panel-body sopdash-chip-row">
                    <?php foreach ($stats['by_criticality'] as $crit => $count):
                        $critClass = $criticalityClasses[strtolower($crit)] ?? 'crit-neutral';
                    ?>
                        <div class="sopdash-chip <?php echo $critClass; ?>">
                            <?php echo h($crit); ?> <strong><?php echo (int)$count; ?></strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($stats['by_category'])): ?>
            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <?php echo dashIcon('folder', 'dsi dsi-sm'); ?>
                    <h2>By Category</h2>
                </div>
                <div class="sopdash-panel-body sopdash-chip-row">
                    <?php foreach ($stats['by_category'] as $cat => $count): ?>
                        <div class="sopdash-chip sopdash-chip-outline">
                            <?php echo h($cat); ?> <strong><?php echo (int)$count; ?></strong>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <?php if (!empty($stats['top_authors'])): ?>
            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <?php echo dashIcon('award', 'dsi dsi-sm'); ?>
                    <h2>Most Active Authors</h2>
                </div>
                <div class="sopdash-panel-body">
                    <?php foreach ($stats['top_authors'] as $i => $author):
                        $authorName = trim((string) ($author['author_name'] ?? '')) ?: 'Unknown';
                    ?>
                        <div class="sopdash-leader-row">
                            <span class="sopdash-leader-rank">#<?php echo $i + 1; ?></span>
                            <span class="sopdash-leader-avatar"><?php echo h(strtoupper(substr($authorName, 0, 1))); ?></span>
                            <span class="sopdash-leader-name"><?php echo h($authorName); ?></span>
                            <span class="sopdash-leader-count"><?php echo (int)$author['sop_count']; ?> SOPs</span>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>

        <!-- RIGHT COLUMN -->
        <div class="sopdash-col-side">

            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <h2>Quick Actions</h2>
                </div>
                <div class="sopdash-panel-body sopdash-actions-list">
                    <?php if ($canCreate): ?>
                        <a href="sop.php?action=create" class="sopdash-action-item">
                            <span class="sopdash-action-icon blue"><?php echo dashIcon('plus'); ?></span>
                            <span>
                                <strong>Create New SOP</strong>
                                <small>Draft a new procedure</small>
                            </span>
                            <?php echo dashIcon('arrow-right', 'dsi dsi-sm'); ?>
                        </a>
                    <?php endif; ?>

                    <a href="sop.php" class="sopdash-action-item">
                        <span class="sopdash-action-icon violet"><?php echo dashIcon('library'); ?></span>
                        <span>
                            <strong>Browse SOP Library</strong>
                            <small>View, edit, and search all SOPs</small>
                        </span>
                        <?php echo dashIcon('arrow-right', 'dsi dsi-sm'); ?>
                    </a>

                    <?php if ($is_admin): ?>
                        <a href="sop.php?action=header_footer" class="sopdash-action-item">
                            <span class="sopdash-action-icon violet"><?php echo dashIcon('document'); ?></span>
                            <span>
                                <strong>Export Header &amp; Footer</strong>
                                <small>Logo and banner printed on every exported page</small>
                            </span>
                            <?php echo dashIcon('arrow-right', 'dsi dsi-sm'); ?>
                        </a>
                    <?php endif; ?>

                    <?php if ($stats['overdue_review'] > 0): ?>
                        <a href="sop.php" class="sopdash-action-item">
                            <span class="sopdash-action-icon red"><?php echo dashIcon('alert'); ?></span>
                            <span>
                                <strong>Review Overdue SOPs</strong>
                                <small><?php echo $stats['overdue_review']; ?> need attention</small>
                            </span>
                            <?php echo dashIcon('arrow-right', 'dsi dsi-sm'); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>

            <?php if ($canAudit && !empty($stats['recent_actions'])): ?>
            <div class="sopdash-panel">
                <div class="sopdash-panel-head">
                    <?php echo dashIcon('history', 'dsi dsi-sm'); ?>
                    <h2>Recent Activity</h2>
                </div>
                <div class="sopdash-panel-body sopdash-timeline">
                    <?php foreach ($stats['recent_actions'] as $action):
                        $actionName = strtolower(trim((string) ($action['action'] ?? '')));
                        $iconName = $actionIcons[$actionName] ?? 'activity';
                        $actionTime = strtotime((string) ($action['action_date'] ?? ''));
                    ?>
                        <div class="sopdash-timeline-item">
                            <span class="sopdash-timeline-icon"><?php echo dashIcon($iconName, 'dsi dsi-sm'); ?></span>
                            <div>
                                <div>
                                    <a href="sop.php?action=view&id=<?php echo (int)$action['sop_id']; ?>"><?php echo h($action['sop_number']); ?></a>
                                    <span class="sopdash-timeline-action"><?php echo h(ucwords(str_replace('_', ' ', $actionName))); ?></span>
                                </div>
                                <small><?php echo h($action['user_name'] ?? 'Unknown'); ?> &middot; <?php echo $actionTime ? date('M d, H:i', $actionTime) : '&mdash;'; ?></small>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>
</div>

<style>
.dsi { width: 20px; height: 20px; display: inline-block; flex-shrink: 0; }
.dsi-sm { width: 16px; height: 16px; }
.dsi-hero { width: 120px; height: 120px; opacity: .15; stroke-width: 1; }

.sopdash-hero {
    background: linear-gradient(135deg, #0f172a 0%, #1e3a8a 100%);
    border-radius: 20px;
    padding: 36px 40px;
    margin-bottom: 24px;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 24px;
    position: relative;
    overflow: hidden;
}

.sopdash-hero-text { max-width: 640px; z-index: 1; }

.sopdash-eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: rgba(255,255,255,.12);
    padding: 5px 12px;
    border-radius: 20px;
    font-size: 12.5px;
    font-weight: 600;
    letter-spacing: .02em;
    margin-bottom: 14px;
    color: #93c5fd;
}

.sopdash-hero h1 {
    font-size: 30px;
    font-weight: 700;
    margin: 0 0 10px;
    color: #fff;
}

.sopdash-hero p {
    color: #cbd5e1;
    font-size: 14.5px;
    line-height: 1.6;
    margin: 0 0 22px;
}

.sopdash-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; }

.sopdash-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 11px 20px;
    border-radius: 10px;
    font-weight: 600;
    font-size: 14px;
    text-decoration: none;
    transition: .15s ease;
    border: 1px solid transparent;
}

.sopdash-btn-primary { background: #2563eb; color: #fff; }
.sopdash-btn-primary:hover { background: #1d4ed8; }

.sopdash-btn-ghost { background: rgba(255,255,255,.08); color: #fff; border-color: rgba(255,255,255,.25); }
.sopdash-btn-ghost:hover { background: rgba(255,255,255,.16); }

.sopdash-hero-icon { position: absolute; right: 20px; top: 50%; transform: translateY(-50%); }

.sopdash-kpi-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.sopdash-kpi {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    padding: 18px;
    display: flex;
    align-items: center;
    gap: 14px;
    box-shadow: var(--shadow-sm);
}

.sopdash-kpi-icon {
    width: 42px;
    height: 42px;
    border-radius: 10px;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

/* Icon tiles keep a tinted plate in both themes, but the tint has to invert:
   a pastel plate that reads as "soft accent" on white reads as a glaring
   white chip on a dark card. Dark mode therefore darkens the plate and
   lightens the glyph rather than reusing the light values. */
.sopdash-kpi-icon.blue { background: #dbeafe; color: #1d4ed8; }
.sopdash-kpi-icon.violet { background: #ede9fe; color: #6d28d9; }
.sopdash-kpi-icon.teal { background: #ccfbf1; color: #0f766e; }
.sopdash-kpi-icon.indigo { background: #e0e7ff; color: #4338ca; }
.sopdash-kpi-icon.green { background: #dcfce7; color: #166534; }
.sopdash-kpi-icon.red { background: #fee2e2; color: #b91c1c; }
.sopdash-kpi-icon.amber { background: #fef3c7; color: #b45309; }

[data-theme="dark"] .sopdash-kpi-icon.blue { background: #1b2740; color: #7ba6ff; }
[data-theme="dark"] .sopdash-kpi-icon.violet { background: #262244; color: #b49bff; }
[data-theme="dark"] .sopdash-kpi-icon.teal { background: #123536; color: #5eead4; }
[data-theme="dark"] .sopdash-kpi-icon.indigo { background: #1f2348; color: #a5b4fc; }
[data-theme="dark"] .sopdash-kpi-icon.green { background: #12301f; color: #6ee7a8; }
[data-theme="dark"] .sopdash-kpi-icon.red { background: #3a1c20; color: #fca5a5; }
[data-theme="dark"] .sopdash-kpi-icon.amber { background: #3a2a12; color: #fcd34d; }

.sopdash-kpi-value { font-size: 24px; font-weight: 700; color: var(--text-primary); line-height: 1.1; }
.sopdash-kpi-label { font-size: 12.5px; color: var(--text-secondary); font-weight: 600; margin-top: 3px; }

.sopdash-columns {
    display: grid;
    grid-template-columns: 1.6fr 1fr;
    gap: 20px;
    align-items: start;
}

.sopdash-panel {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    margin-bottom: 20px;
    box-shadow: var(--shadow-sm);
}

.sopdash-panel-head {
    display: flex;
    align-items: center;
    gap: 8px;
    padding: 18px 20px 0;
    color: var(--text-secondary);
}

.sopdash-panel-head h2 { font-size: 15.5px; font-weight: 700; color: var(--text-primary); margin: 0; }

.sopdash-panel-body { padding: 16px 20px 20px; }

.sopdash-bar-row { margin-bottom: 14px; }
.sopdash-bar-row:last-child { margin-bottom: 0; }

.sopdash-bar-label {
    display: flex;
    justify-content: space-between;
    font-size: 13px;
    font-weight: 600;
    color: var(--text-secondary);
    margin-bottom: 6px;
}

.sopdash-bar-track { background: var(--border-light); border-radius: 8px; height: 8px; overflow: hidden; }
.sopdash-bar-fill { height: 100%; border-radius: 8px; }

.sopdash-bar-fill.st-published { background: #059669; }
.sopdash-bar-fill.st-pending   { background: #d97706; }
.sopdash-bar-fill.st-draft     { background: #6b7280; }
.sopdash-bar-fill.st-rejected  { background: #dc2626; }

/* Bar fills sit on a much darker track in dark mode, so they are lifted a
   step to keep the same contrast against it that they had on the light one. */
[data-theme="dark"] .sopdash-bar-fill.st-published { background: #10b981; }
[data-theme="dark"] .sopdash-bar-fill.st-pending   { background: #f59e0b; }
[data-theme="dark"] .sopdash-bar-fill.st-draft     { background: #8b95a7; }
[data-theme="dark"] .sopdash-bar-fill.st-rejected  { background: #f43f5e; }

.sopdash-chip-row { display: flex; flex-wrap: wrap; gap: 10px; }

.sopdash-chip {
    padding: 7px 14px;
    border-radius: 20px;
    font-size: 12.5px;
    font-weight: 600;
    text-transform: capitalize;
}

.sopdash-chip.crit-critical { background: #fee2e2; color: #991b1b; }
.sopdash-chip.crit-high     { background: #ffedd5; color: #c2410c; }
.sopdash-chip.crit-medium   { background: #fef9c3; color: #854d0e; }
.sopdash-chip.crit-low      { background: #dcfce7; color: #166534; }
.sopdash-chip.crit-neutral  { background: #f1f5f9; color: #475569; }

[data-theme="dark"] .sopdash-chip.crit-critical { background: #3a1c20; color: #fca5a5; }
[data-theme="dark"] .sopdash-chip.crit-high     { background: #3a2618; color: #fdba74; }
[data-theme="dark"] .sopdash-chip.crit-medium   { background: #3a3416; color: #fde047; }
[data-theme="dark"] .sopdash-chip.crit-low      { background: #12301f; color: #6ee7a8; }
[data-theme="dark"] .sopdash-chip.crit-neutral  { background: #29334a; color: #cbd5e1; }

.sopdash-chip-outline { background: var(--hover-bg); color: var(--text-secondary); border: 1px solid var(--border-color); }

.sopdash-leader-row {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border-light);
}

.sopdash-leader-row:last-child { border-bottom: none; padding-bottom: 0; }

.sopdash-leader-rank { font-size: 12px; font-weight: 700; color: var(--text-muted); width: 22px; }

.sopdash-leader-avatar {
    width: 32px; height: 32px;
    border-radius: 50%;
    background: #eff6ff;
    color: #2563eb;
    display: flex; align-items: center; justify-content: center;
    font-weight: 700; font-size: 13px;
    flex-shrink: 0;
}

[data-theme="dark"] .sopdash-leader-avatar { background: #1b2740; color: #7ba6ff; }

.sopdash-leader-name { flex: 1; font-weight: 600; color: var(--text-primary); font-size: 13.5px; }
.sopdash-leader-count { font-size: 12.5px; color: var(--text-secondary); font-weight: 600; }

.sopdash-actions-list { display: flex; flex-direction: column; gap: 10px; }

.sopdash-action-item {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px;
    border-radius: 10px;
    text-decoration: none;
    color: inherit;
    border: 1px solid var(--border-color);
    transition: .15s ease;
}

.sopdash-action-item:hover { background: var(--hover-bg); border-color: var(--text-muted); }

.sopdash-action-icon {
    width: 36px; height: 36px;
    border-radius: 9px;
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

.sopdash-action-icon.blue { background: #dbeafe; color: #1d4ed8; }
.sopdash-action-icon.violet { background: #ede9fe; color: #6d28d9; }
.sopdash-action-icon.red { background: #fee2e2; color: #b91c1c; }

[data-theme="dark"] .sopdash-action-icon.blue { background: #1b2740; color: #7ba6ff; }
[data-theme="dark"] .sopdash-action-icon.violet { background: #262244; color: #b49bff; }
[data-theme="dark"] .sopdash-action-icon.red { background: #3a1c20; color: #fca5a5; }

.sopdash-action-item span:nth-child(2) { flex: 1; display: flex; flex-direction: column; }
.sopdash-action-item strong { font-size: 13.5px; color: var(--text-primary); }
.sopdash-action-item small { font-size: 12px; color: var(--text-secondary); }
.sopdash-action-item .dsi-sm { color: var(--text-muted); }

.sopdash-timeline-item {
    display: flex;
    gap: 12px;
    padding: 10px 0;
    border-bottom: 1px solid var(--border-light);
}

.sopdash-timeline-item:last-child { border-bottom: none; padding-bottom: 0; }

.sopdash-timeline-icon {
    width: 30px; height: 30px;
    border-radius: 50%;
    background: var(--hover-bg);
    color: var(--text-secondary);
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
}

.sopdash-timeline-item a { color: var(--accent); text-decoration: none; font-weight: 700; font-size: 13px; }
.sopdash-timeline-action { font-size: 12.5px; color: var(--text-secondary); margin-left: 6px; }
.sopdash-timeline-item small { color: var(--text-muted); font-size: 11.5px; }

@media (max-width: 900px) {
    .sopdash-hero { flex-direction: column; align-items: flex-start; }
    .sopdash-hero-icon { display: none; }
    .sopdash-columns { grid-template-columns: 1fr; }
}
</style>

<?php require 'includes/footer.php'; ?>
