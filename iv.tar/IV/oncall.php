<?php
/**
 * On-Call Tracker -- the duty rota: who holds the pager, when, and who
 * backs them up.
 *
 * Each shift is published at one of four scopes using the same
 * vocabulary and helpers as quick links, SOPs and KB articles: private
 * ("only me"), team, teams (several), or public. Every create, edit,
 * delete and re-scope is written to oncall_audit.
 *
 * Two things differ deliberately from links.php, which this otherwise
 * follows closely:
 *
 *  1. Modify/delete is restricted to the shift's author and Admin, at
 *     every scope -- not to anyone holding can_edit. A rota is a record
 *     of accountability; a colleague quietly rewriting who was on call
 *     is exactly what it must not permit.
 *
 *  2. The primary and secondary contact details are SNAPSHOTS taken from
 *     the portal user at scheduling time, not a live join. See
 *     config/schema/workspace.php for why.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/permission-helpers.php';

requireLogin();
requirePermission('oncall', 'can_view');

$canEdit   = can('oncall', 'can_edit');
$canDelete = can('oncall', 'can_delete');
$canExport = can('oncall', 'can_export');
$canAudit  = can('oncall', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));
$userId   = (int) ($_SESSION['user_id'] ?? 0);
$role     = trim((string) ($_SESSION['role'] ?? ''));
$isAdmin  = strtolower($role) === 'admin';

/* The session carries the role but not the team; visibility depends on it. */
$teamStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$teamStmt->execute([$userId]);
$userTeam = (string) ($teamStmt->fetchColumn() ?: '');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const OC_MODULE = 'oncall';

$visibilities = [
    'private' => 'Only me',
    'team'    => 'My team',
    'teams'   => 'Multiple teams',
    'public'  => 'Public',
];

$allTeams = getTeamNames($pdo);

/*
 * Portal users offered as primary/secondary. Approved accounts only --
 * a pending signup is not someone you can hand the pager to. This list
 * also feeds the client-side auto-fill of NCGR ID and email.
 */
$portalUsers = $pdo->query("
    SELECT id, ncgr_id, first_name, last_name, email, phone, team
    FROM users
    WHERE is_approved = 1
    ORDER BY first_name COLLATE NOCASE, last_name COLLATE NOCASE
")->fetchAll(PDO::FETCH_ASSOC);

$portalById = [];
foreach ($portalUsers as $pu) {
    $portalById[(int) $pu['id']] = [
        'name'    => trim($pu['first_name'] . ' ' . $pu['last_name']),
        'ncgr_id' => (string) $pu['ncgr_id'],
        'email'   => (string) $pu['email'],
        'phone'   => (string) ($pu['phone'] ?? ''),
        'team'    => (string) ($pu['team'] ?? ''),
    ];
}

/* Columns carried straight through save and export. */
$ocFields = [
    'shift_label'    => 'Shift',
    'rota_team'      => 'Rota Team',
    'starts_at'      => 'Starts',
    'ends_at'        => 'Ends',
    'primary_name'   => 'Primary',
    'primary_ncgr_id'=> 'Primary NCGR ID',
    'primary_email'  => 'Primary Email',
    'primary_phone'  => 'Primary Phone',
    'secondary_name' => 'Secondary',
    'secondary_ncgr_id' => 'Secondary NCGR ID',
    'secondary_email'   => 'Secondary Email',
    'secondary_phone'   => 'Secondary Phone',
    'escalation_to'  => 'Escalation',
    'handover_notes' => 'Handover Notes',
];


/* ---------------- VISIBILITY ---------------- */

/**
 * Rows this user may see.
 *
 * Filtered in SQL rather than fetched-then-discarded: a private shift
 * must never reach a browser with no right to it, and "hide it in the
 * template" is how that goes wrong.
 */
function ocVisibleWhere(bool $isAdmin, int $userId, string $userTeam): array
{
    if ($isAdmin) {
        return ['1=1', []];
    }

    $sql = "(
        s.visibility = 'public'
        OR s.created_by_id = ?
        OR (s.visibility = 'team'  AND s.owner_team <> '' AND s.owner_team = ?)
        OR (s.visibility = 'teams' AND EXISTS (
                SELECT 1 FROM oncall_teams t
                WHERE t.oncall_id = s.id AND t.team_name = ?
        ))
    )";

    return [$sql, [$userId, $userTeam, $userTeam]];
}

/**
 * Loads a shift only if this user may see it, returning null otherwise.
 *
 * Every write path goes through this rather than a bare SELECT by id:
 * checking "may this user edit?" against a row fetched by id alone lets
 * someone reach a record they cannot even read by guessing its number.
 */
function ocLoadVisible(PDO $pdo, int $id, bool $isAdmin, int $userId, string $userTeam): ?array
{
    [$visSql, $visParams] = ocVisibleWhere($isAdmin, $userId, $userTeam);

    $stmt = $pdo->prepare("SELECT s.* FROM oncall_shifts s WHERE s.id = ? AND $visSql");
    $stmt->execute([$id, ...$visParams]);

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/**
 * Author-or-Admin only, at every scope.
 *
 * Stricter than links.php on purpose -- see the note in the file header.
 * can_edit governs whether you may create shifts at all; it does not let
 * you rewrite somebody else's.
 */
function ocCanModify(array $shift, bool $isAdmin, int $userId): bool
{
    return $isAdmin || (int) $shift['created_by_id'] === $userId;
}

/** Is this shift live at $now? Compared as strings, matching storage. */
function ocIsActive(array $s, string $now): bool
{
    return (string) $s['starts_at'] <= $now && (string) $s['ends_at'] >= $now;
}

/**
 * Normalises an <input type="datetime-local"> value to the format the
 * rest of the application stores dates in.
 *
 * The control posts "2026-09-01T08:00"; everything here compares shift
 * bounds against date('Y-m-d H:i:s') as plain strings, both in SQL
 * (the "on call now" filter) and in PHP (ocIsActive). Left as posted,
 * the 'T' sorts after a space, so a shift that had already started would
 * still compare as future and never show as live.
 */
function ocNormaliseDateTime(string $raw): string
{
    $v = trim($raw);
    if ($v === '') {
        return '';
    }

    $v = str_replace('T', ' ', $v);

    // The control omits seconds unless a step is set.
    if (preg_match('/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/', $v)) {
        $v .= ':00';
    }

    return $v;
}


/* ---------------- AJAX: AUDIT ---------------- */

if (($_GET['action'] ?? '') === 'audit') {
    requirePermission('oncall', 'can_audit');

    $id = (int) ($_GET['id'] ?? 0);

    [$visSql, $visParams] = ocVisibleWhere($isAdmin, $userId, $userTeam);

    if ($id > 0) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM oncall_shifts s WHERE s.id = ? AND $visSql");
        $chk->execute([$id, ...$visParams]);

        if (!$chk->fetchColumn()) {
            http_response_code(403);
            exit('<p class="plat-empty">You do not have access to this shift.</p>');
        }

        $rows  = getItemAuditTrail($pdo, OC_MODULE, $id);
        $empty = 'No audit entries for this shift yet.';
    } else {
        /*
         * Whole-module view. Non-admins see only entries for shifts they
         * can currently see, which necessarily drops deleted ones (no row
         * survives to test visibility against). Admins see everything,
         * including deletions -- "who removed that shift" is precisely
         * what the trail is kept for.
         */
        if ($isAdmin) {
            $sql  = "SELECT a.* FROM oncall_audit a ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = [];
        } else {
            $sql  = "SELECT a.* FROM oncall_audit a
                     JOIN oncall_shifts s ON s.id = a.oncall_id
                     WHERE $visSql
                     ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = $visParams;
        }

        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $rows  = $st->fetchAll(PDO::FETCH_ASSOC);
        $empty = 'No audit entries recorded yet.';
    }

    if (!$rows) {
        echo '<p class="plat-empty">' . $empty . '</p>';
        exit;
    }

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>When</th><th>Action</th><th>By</th><th>Details</th>'
       . '</tr></thead><tbody>';

    foreach ($rows as $r) {
        $detail = '';
        if (!empty($r['details'])) {
            $decoded = json_decode((string) $r['details'], true);
            $detail = is_array($decoded)
                ? implode('<br>', array_map(
                    fn($k, $v) => '<strong>' . plat_h($k) . ':</strong> ' . plat_h(is_scalar($v) ? (string) $v : json_encode($v)),
                    array_keys($decoded),
                    $decoded
                ))
                : plat_h((string) $r['details']);
        }

        echo '<tr>'
           . '<td>' . plat_h($r['action_date'] ?? '') . '</td>'
           . '<td><span class="plat-pill neutral">' . plat_h($r['action'] ?? '') . '</span></td>'
           . '<td>' . plat_h($r['user_name'] ?? '') . '</td>'
           . '<td>' . ($detail ?: '—') . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/* ---------------- FILTERS ---------------- */

$q     = trim((string) ($_GET['q'] ?? ''));
$fTeam = trim((string) ($_GET['f_team'] ?? ''));
$fVis  = trim((string) ($_GET['f_vis'] ?? ''));
$fWhen = trim((string) ($_GET['f_when'] ?? ''));

$now = date('Y-m-d H:i:s');

[$visSql, $visParams] = ocVisibleWhere($isAdmin, $userId, $userTeam);

$where  = [$visSql];
$params = $visParams;

if ($q !== '') {
    $where[] = '(s.shift_label LIKE ? OR s.primary_name LIKE ? OR s.secondary_name LIKE ?
                 OR s.primary_ncgr_id LIKE ? OR s.secondary_ncgr_id LIKE ? OR s.rota_team LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fTeam !== '') { $where[] = 's.rota_team = ?';  $params[] = $fTeam; }
if ($fVis  !== '') { $where[] = 's.visibility = ?'; $params[] = $fVis; }

if ($fWhen === 'active') {
    $where[] = 's.starts_at <= ? AND s.ends_at >= ?';
    array_push($params, $now, $now);
} elseif ($fWhen === 'upcoming') {
    $where[] = 's.starts_at > ?';
    $params[] = $now;
} elseif ($fWhen === 'past') {
    $where[] = 's.ends_at < ?';
    $params[] = $now;
}

$whereSql = implode(' AND ', $where);


/* ---------------- EXPORT ---------------- */

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('oncall', 'can_export');

    $stmt = $pdo->prepare("SELECT s.* FROM oncall_shifts s WHERE $whereSql ORDER BY s.starts_at DESC");
    $stmt->execute($params);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="oncall_rota_' . date('Ymd_His') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, [...array_values($ocFields), 'Visibility', 'Shared Teams', 'Created By', 'Created At']);

    foreach ($stmt as $r) {
        $shared = $r['visibility'] === 'teams'
            ? implode(' | ', getSharedTeams($pdo, OC_MODULE, (int) $r['id']))
            : '';

        fputcsv($out, [
            ...array_map(fn($c) => $r[$c] ?? '', array_keys($ocFields)),
            $r['visibility'],
            $shared,
            $r['created_by'],
            $r['created_at'],
        ]);
    }

    fclose($out);
    exit;
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('oncall', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);

        $data = [];
        foreach (array_keys($ocFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        $data['starts_at'] = ocNormaliseDateTime($data['starts_at']);
        $data['ends_at']   = ocNormaliseDateTime($data['ends_at']);

        /*
         * The contact details are re-derived server-side from the chosen
         * user id rather than trusted from the posted fields. The form
         * fills them in with JavaScript for the operator's benefit; a
         * posted NCGR ID or email that does not match the selected user
         * would otherwise write a false record of who was on call.
         */
        $primaryUserId   = (int) ($_POST['primary_user_id'] ?? 0);
        $secondaryUserId = (int) ($_POST['secondary_user_id'] ?? 0);

        if (isset($portalById[$primaryUserId])) {
            $data['primary_name']    = $portalById[$primaryUserId]['name'];
            $data['primary_ncgr_id'] = $portalById[$primaryUserId]['ncgr_id'];
            $data['primary_email']   = $portalById[$primaryUserId]['email'];
        } else {
            $primaryUserId = 0;
        }

        if (isset($portalById[$secondaryUserId])) {
            $data['secondary_name']    = $portalById[$secondaryUserId]['name'];
            $data['secondary_ncgr_id'] = $portalById[$secondaryUserId]['ncgr_id'];
            $data['secondary_email']   = $portalById[$secondaryUserId]['email'];
        } else {
            $secondaryUserId = 0;
            $data['secondary_name']    = '';
            $data['secondary_ncgr_id'] = '';
            $data['secondary_email']   = '';
            $data['secondary_phone']   = '';
        }

        $visibility = (string) ($_POST['visibility'] ?? 'public');
        if (!isset($visibilities[$visibility])) {
            $visibility = 'public';
        }

        $sharedTeams = array_values(array_filter(array_map(
            'trim',
            (array) ($_POST['shared_teams'] ?? [])
        ), fn($t) => $t !== ''));

        // A team the user invented is not a team; only real ones are stored.
        $sharedTeams = array_values(array_intersect($sharedTeams, $allTeams));

        // 'team' scope means the author's own team; storing it explicitly
        // keeps the row readable if the author later changes team.
        $data['owner_team'] = $visibility === 'team' ? $userTeam : '';

        if ($primaryUserId === 0) {
            $err = 'Choose a primary on-call from the portal users.';
        } elseif ($data['starts_at'] === '' || $data['ends_at'] === '') {
            $err = 'A shift needs both a start and an end.';
        } elseif ($data['ends_at'] <= $data['starts_at']) {
            $err = 'The shift ends before it starts — check the dates.';
        } elseif ($secondaryUserId !== 0 && $secondaryUserId === $primaryUserId) {
            $err = 'The secondary on-call must be someone other than the primary.';
        } elseif ($visibility === 'team' && $userTeam === '') {
            $err = 'You are not assigned to a team, so "My team" cannot be used. Ask an administrator to set your team.';
        } elseif ($visibility === 'teams' && !$sharedTeams) {
            $err = 'Choose at least one team to share with.';
        } else {
            try {
                $pdo->beginTransaction();

                $cols = [...array_keys($data), 'primary_user_id', 'secondary_user_id'];
                $vals = [...array_values($data), $primaryUserId, $secondaryUserId];

                if ($id > 0) {
                    $old = ocLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

                    // Same message whether the shift is missing or merely
                    // out of scope -- distinguishing them would confirm
                    // that a given id exists to someone who cannot see it.
                    if (!$old || !ocCanModify($old, $isAdmin, $userId)) {
                        throw new RuntimeException('That shift does not exist, or you cannot edit it.');
                    }

                    $set = implode(', ', array_map(fn($c) => "$c = ?", $cols));
                    $pdo->prepare("
                        UPDATE oncall_shifts
                        SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ")->execute([...$vals, $username, $id]);

                    $action  = 'UPDATED';
                    $details = ['Shift' => $data['shift_label'] ?: ($data['starts_at'] . ' → ' . $data['ends_at'])];

                    if ((string) $old['primary_name'] !== $data['primary_name']) {
                        $details['Primary'] = ($old['primary_name'] ?: '—') . ' → ' . $data['primary_name'];
                    }
                    if ((string) $old['secondary_name'] !== $data['secondary_name']) {
                        $details['Secondary'] = ($old['secondary_name'] ?: '—') . ' → ' . ($data['secondary_name'] ?: '—');
                    }
                    if ((string) $old['visibility'] !== $visibility) {
                        $details['Visibility'] =
                            ($visibilities[$old['visibility']] ?? $old['visibility'])
                            . ' → ' . $visibilities[$visibility];
                    }
                } else {
                    $colSql = implode(', ', $cols);
                    $ph     = implode(', ', array_fill(0, count($cols), '?'));

                    $pdo->prepare("
                        INSERT INTO oncall_shifts ($colSql, visibility, created_by, created_by_id)
                        VALUES ($ph, ?, ?, ?)
                    ")->execute([...$vals, $visibility, $username, $userId]);

                    $id      = (int) $pdo->lastInsertId();
                    $action  = 'CREATED';
                    $details = [
                        'Shift'      => $data['shift_label'] ?: ($data['starts_at'] . ' → ' . $data['ends_at']),
                        'Primary'    => $data['primary_name'],
                        'Visibility' => $visibilities[$visibility],
                    ];
                }

                $pdo->commit();

                // saveItemSharing opens its own transaction, so it runs
                // after the commit rather than nested inside it. Its return
                // value is checked: it reports failure rather than throwing,
                // and an unreported failure leaves the row at its previous
                // scope while the user is told the save succeeded.
                if (!saveItemSharing($pdo, OC_MODULE, $id, $visibility, $sharedTeams)) {
                    throw new RuntimeException(
                        'the shift was saved but its visibility could not be applied; it still has its previous scope'
                    );
                }

                if ($visibility === 'teams' && $sharedTeams) {
                    $details['Shared with'] = implode(', ', $sharedTeams);
                }

                logItemAction($pdo, OC_MODULE, $id, $action, $userId, $username, $details);
                $msg = $action === 'CREATED' ? 'Shift scheduled.' : 'Shift updated.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('oncall', 'can_delete');

        $id    = (int) ($_POST['id'] ?? 0);
        $shift = ocLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

        if (!$shift || !ocCanModify($shift, $isAdmin, $userId)) {
            $err = 'That shift does not exist, or you cannot delete it.';
        } else {
            // Foreign keys are off app-wide, so ON DELETE CASCADE on
            // oncall_teams does not fire -- clear the children here.
            $pdo->prepare("DELETE FROM oncall_teams WHERE oncall_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM oncall_shifts WHERE id = ?")->execute([$id]);

            // The audit rows deliberately outlive the shift.
            logItemAction($pdo, OC_MODULE, $id, 'DELETED', $userId, $username, [
                'Shift'   => $shift['shift_label'] ?: ($shift['starts_at'] . ' → ' . $shift['ends_at']),
                'Primary' => $shift['primary_name'],
            ]);
            $msg = 'Shift deleted.';
        }
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("SELECT s.* FROM oncall_shifts s WHERE $whereSql ORDER BY s.starts_at DESC");
$stmt->execute($params);
$shifts = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Shared-team lists for every visible row, in one query rather than N. */
$sharedByShift = [];
if ($shifts) {
    $ids = array_column($shifts, 'id');
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $ts  = $pdo->prepare("SELECT oncall_id, team_name FROM oncall_teams WHERE oncall_id IN ($in) ORDER BY team_name");
    $ts->execute($ids);
    foreach ($ts as $r) {
        $sharedByShift[(int) $r['oncall_id']][] = $r['team_name'];
    }
}

$activeShifts   = array_values(array_filter($shifts, fn($s) => ocIsActive($s, $now)));
$upcomingShifts = array_values(array_filter($shifts, fn($s) => (string) $s['starts_at'] > $now));
$pastShifts     = array_values(array_filter($shifts, fn($s) => (string) $s['ends_at'] < $now));

/* Rota teams actually in use, for the filter. */
$rotaTeams = array_values(array_unique(array_filter(
    array_map(fn($s) => trim((string) $s['rota_team']), $shifts),
    fn($t) => $t !== ''
)));
sort($rotaTeams);

$page_title = 'On-Call Tracker | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/platform.css">
<link rel="stylesheet" href="assets/css/workspace.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">📟</div>
            <div>
                <h1>On-Call Tracker</h1>
                <p>Who holds the pager, when, and who backs them up.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="ocOpen(null)">+ Schedule Shift</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn plat-btn-light" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_team=<?= urlencode($fTeam) ?>&amp;f_vis=<?= urlencode($fVis) ?>&amp;f_when=<?= urlencode($fWhen) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="ocAudit(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= count($activeShifts) ?></b><span>On call now</span></div>
        <div class="plat-stat"><b><?= count($upcomingShifts) ?></b><span>Upcoming</span></div>
        <div class="plat-stat"><b><?= count($pastShifts) ?></b><span>Completed</span></div>
        <div class="plat-stat"><b><?= count($shifts) ?></b><span>Visible to you</span></div>
    </div>

    <form method="get" class="plat-filters" style="margin-bottom:18px;">
        <div class="plat-field">
            <label>Search</label>
            <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Name, NCGR ID, shift…" style="min-width:210px;">
        </div>
        <div class="plat-field">
            <label>Rota team</label>
            <select name="f_team">
                <option value="">All</option>
                <?php foreach ($rotaTeams as $t): ?>
                    <option value="<?= plat_h($t) ?>" <?= $fTeam === $t ? 'selected' : '' ?>><?= plat_h($t) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="plat-field">
            <label>When</label>
            <select name="f_when">
                <option value="">All</option>
                <option value="active"   <?= $fWhen === 'active'   ? 'selected' : '' ?>>On call now</option>
                <option value="upcoming" <?= $fWhen === 'upcoming' ? 'selected' : '' ?>>Upcoming</option>
                <option value="past"     <?= $fWhen === 'past'     ? 'selected' : '' ?>>Completed</option>
            </select>
        </div>
        <div class="plat-field">
            <label>Visibility</label>
            <select name="f_vis">
                <option value="">All</option>
                <?php foreach ($visibilities as $k => $v): ?>
                    <option value="<?= plat_h($k) ?>" <?= $fVis === $k ? 'selected' : '' ?>><?= plat_h($v) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="plat-btn plat-btn-primary">Filter</button>
        <a class="plat-btn plat-btn-light" href="oncall.php">Reset</a>
    </form>

    <?php
    /* Renders one shift row. Declared inline because it closes over the
       per-user permission flags computed above. */
    $renderShift = function (array $s) use ($sharedByShift, $visibilities, $isAdmin, $userId, $canDelete, $canAudit, $now) {
        $id     = (int) $s['id'];
        $vis    = (string) $s['visibility'];
        $shared = $sharedByShift[$id] ?? [];
        $mine   = (int) $s['created_by_id'] === $userId;
        $modify = ocCanModify($s, $isAdmin, $userId);
        $live   = ocIsActive($s, $now);
        ?>
        <div class="oc-card <?= $live ? 'is-live' : '' ?>">

            <div class="oc-card-head">
                <div>
                    <div class="oc-shift-name">
                        <?= plat_h($s['shift_label'] ?: 'Shift #' . $id) ?>
                        <?php if ($live): ?><span class="oc-live-pill">On call now</span><?php endif; ?>
                    </div>
                    <div class="oc-window">
                        <?= plat_h($s['starts_at']) ?> &nbsp;→&nbsp; <?= plat_h($s['ends_at']) ?>
                        <?php if ($s['rota_team']): ?>
                            <span class="plat-pill neutral"><?= plat_h($s['rota_team']) ?></span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="oc-actions">
                    <?php if ($modify): ?>
                        <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                            onclick='ocOpen(<?= json_encode($s + ["shared_teams" => $shared], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                    <?php endif; ?>
                    <?php if ($canAudit): ?>
                        <button type="button" class="plat-icon-btn plat-icon-hist" title="Audit trail"
                            onclick="ocAudit(<?= $id ?>)">⏱</button>
                    <?php endif; ?>
                    <?php if ($canDelete && $modify): ?>
                        <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                            onclick='ocDelete(<?= $id ?>, <?= json_encode($s["shift_label"] ?: "Shift #$id", JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>🗑</button>
                    <?php endif; ?>
                </div>
            </div>

            <div class="oc-people">
                <div class="oc-person primary">
                    <span class="oc-role">Primary</span>
                    <span class="oc-name"><?= plat_h($s['primary_name'] ?: '—') ?></span>
                    <span class="oc-id"><?= plat_h($s['primary_ncgr_id']) ?></span>
                    <?php if ($s['primary_email']): ?>
                        <a class="oc-mail" href="mailto:<?= plat_h($s['primary_email']) ?>"><?= plat_h($s['primary_email']) ?></a>
                    <?php endif; ?>
                    <?php if ($s['primary_phone']): ?>
                        <span class="oc-phone"><?= plat_h($s['primary_phone']) ?></span>
                    <?php endif; ?>
                </div>

                <div class="oc-person secondary">
                    <span class="oc-role">Secondary</span>
                    <span class="oc-name"><?= plat_h($s['secondary_name'] ?: '—') ?></span>
                    <span class="oc-id"><?= plat_h($s['secondary_ncgr_id']) ?></span>
                    <?php if ($s['secondary_email']): ?>
                        <a class="oc-mail" href="mailto:<?= plat_h($s['secondary_email']) ?>"><?= plat_h($s['secondary_email']) ?></a>
                    <?php endif; ?>
                    <?php if ($s['secondary_phone']): ?>
                        <span class="oc-phone"><?= plat_h($s['secondary_phone']) ?></span>
                    <?php endif; ?>
                </div>
            </div>

            <?php if (trim((string) $s['handover_notes']) !== '' || trim((string) $s['escalation_to']) !== ''): ?>
                <div class="oc-notes">
                    <?php if ($s['escalation_to']): ?>
                        <div><strong>Escalation:</strong> <?= plat_h($s['escalation_to']) ?></div>
                    <?php endif; ?>
                    <?php if ($s['handover_notes']): ?>
                        <div><?= nl2br(plat_h($s['handover_notes'])) ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <div class="oc-foot">
                <span class="ws-vis vis-<?= plat_h($vis) ?>" title="<?= $vis === 'teams'
                    ? 'Shared with: ' . plat_h(implode(', ', $shared))
                    : ($vis === 'team' ? 'Team: ' . plat_h($s['owner_team']) : plat_h($visibilities[$vis] ?? $vis)) ?>">
                    <?= plat_h($visibilities[$vis] ?? $vis) ?>
                    <?php if ($vis === 'teams' && $shared): ?> (<?= count($shared) ?>)<?php endif; ?>
                </span>
                <span class="oc-by">Scheduled by <?= plat_h($s['created_by']) ?></span>
                <?php if ($mine): ?><span class="ws-mine">yours</span><?php endif; ?>
            </div>
        </div>
        <?php
    };
    ?>

    <?php if (!$shifts): ?>
        <p class="plat-empty">No shifts match. <?= $canEdit ? 'Add the first one with “Schedule Shift”.' : '' ?></p>
    <?php endif; ?>

    <?php if ($activeShifts): ?>
        <div class="ws-group-title">On call now <span class="ws-group-n"><?= count($activeShifts) ?></span></div>
        <?php foreach ($activeShifts as $s) { $renderShift($s); } ?>
    <?php endif; ?>

    <?php if ($upcomingShifts): ?>
        <div class="ws-group-title">Upcoming <span class="ws-group-n"><?= count($upcomingShifts) ?></span></div>
        <?php foreach ($upcomingShifts as $s) { $renderShift($s); } ?>
    <?php endif; ?>

    <?php if ($pastShifts): ?>
        <div class="ws-group-title">Completed <span class="ws-group-n"><?= count($pastShifts) ?></span></div>
        <?php foreach ($pastShifts as $s) { $renderShift($s); } ?>
    <?php endif; ?>

</div>


<?php if ($canEdit): ?>
<div class="plat-modal" id="ocModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="ocTitle">Schedule Shift</h2>
            <button type="button" class="plat-close" onclick="platClose('ocModal')">&times;</button>
        </div>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="oc_id">

            <div class="plat-form-grid cols-2">

                <div class="plat-field"><label>Shift name</label>
                    <input type="text" name="shift_label" id="oc_shift_label" placeholder="Week 36 — Linux"></div>

                <div class="plat-field"><label>Rota team</label>
                    <select name="rota_team" id="oc_rota_team">
                        <option value="">—</option>
                        <?php foreach ($allTeams as $t): ?><option value="<?= plat_h($t) ?>"><?= plat_h($t) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Starts *</label>
                    <input type="datetime-local" name="starts_at" id="oc_starts_at" required></div>

                <div class="plat-field"><label>Ends *</label>
                    <input type="datetime-local" name="ends_at" id="oc_ends_at" required></div>

                <div class="plat-section-title">Primary on-call</div>

                <div class="plat-field full"><label>Portal user *</label>
                    <select name="primary_user_id" id="oc_primary_user_id" required onchange="ocFill('primary')">
                        <option value="">— select a user —</option>
                        <?php foreach ($portalUsers as $pu): ?>
                            <option value="<?= (int) $pu['id'] ?>">
                                <?= plat_h(trim($pu['first_name'] . ' ' . $pu['last_name'])) ?>
                                (<?= plat_h($pu['ncgr_id']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <span class="ws-hint">NCGR ID and email fill in automatically and are re-checked on save.</span>
                </div>

                <div class="plat-field"><label>NCGR ID</label>
                    <input type="text" id="oc_primary_ncgr_id" readonly class="ws-readonly"></div>

                <div class="plat-field"><label>Email</label>
                    <input type="text" id="oc_primary_email" readonly class="ws-readonly"></div>

                <div class="plat-field full"><label>Contact number</label>
                    <input type="text" name="primary_phone" id="oc_primary_phone" placeholder="Mobile reachable during the shift">
                    <span class="ws-hint">Defaults from the selected user's profile phone -- edit if they're reachable on a different number for this shift.</span></div>

                <div class="plat-section-title">Secondary on-call</div>

                <div class="plat-field full"><label>Portal user</label>
                    <select name="secondary_user_id" id="oc_secondary_user_id" onchange="ocFill('secondary')">
                        <option value="">— none —</option>
                        <?php foreach ($portalUsers as $pu): ?>
                            <option value="<?= (int) $pu['id'] ?>">
                                <?= plat_h(trim($pu['first_name'] . ' ' . $pu['last_name'])) ?>
                                (<?= plat_h($pu['ncgr_id']) ?>)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>NCGR ID</label>
                    <input type="text" id="oc_secondary_ncgr_id" readonly class="ws-readonly"></div>

                <div class="plat-field"><label>Email</label>
                    <input type="text" id="oc_secondary_email" readonly class="ws-readonly"></div>

                <div class="plat-field full"><label>Contact number</label>
                    <input type="text" name="secondary_phone" id="oc_secondary_phone"></div>

                <div class="plat-section-title">Handover</div>

                <div class="plat-field full"><label>Escalation to</label>
                    <input type="text" name="escalation_to" id="oc_escalation_to" placeholder="Manager or vendor to escalate to"></div>

                <div class="plat-field full"><label>Handover notes</label>
                    <textarea name="handover_notes" id="oc_handover_notes" rows="3" placeholder="Open incidents, changes in flight, anything the next shift needs."></textarea></div>

                <div class="plat-section-title">Publish to</div>

                <div class="plat-field full">
                    <div class="ws-vis-opts">
                        <?php foreach ($visibilities as $k => $label): ?>
                            <label class="ws-vis-opt">
                                <input type="radio" name="visibility" value="<?= plat_h($k) ?>"
                                       <?= $k === 'public' ? 'checked' : '' ?> onchange="ocVisChanged()">
                                <span><?= plat_h($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <span class="ws-hint" id="oc_vis_hint"></span>
                </div>

                <div class="plat-field full" id="oc_teams_wrap" style="display:none;">
                    <label>Share with teams</label>
                    <div class="ws-team-list">
                        <?php foreach ($allTeams as $t): ?>
                            <label class="ws-team">
                                <input type="checkbox" name="shared_teams[]" value="<?= plat_h($t) ?>">
                                <span><?= plat_h($t) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('ocModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-primary">Save Shift</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="ocDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete Shift</h2>
            <button type="button" class="plat-close" onclick="platClose('ocDelModal')">&times;</button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="ocDelId">
            <p>Delete <strong id="ocDelName"></strong>? The audit trail is kept.</p>
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('ocDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="plat-modal" id="ocAuditModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="ocAuditTitle">Audit Trail</h2>
            <button type="button" class="plat-close" onclick="platClose('ocAuditModal')">&times;</button></div>
        <div id="ocAuditBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<script>
const OC_USERS = <?= json_encode($portalById, JSON_HEX_APOS | JSON_HEX_QUOT | JSON_HEX_TAG) ?>;

const OC_VIS_HINT = {
    private: 'Only you (and an administrator) can see this shift.',
    team:    'Everyone in your team can see this shift.',
    teams:   'Only the teams you tick below can see this shift.',
    public:  'Everyone who can open this page can see this shift.'
};

/* Modal show/hide. Defined per page across this codebase -- there is no
   shared platform.js, and platform.css only supplies the .show rule. */
function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

/* Fills the read-only identity fields from the chosen portal user.
   Convenience only -- oncall.php re-derives both from the posted user id,
   so a tampered field cannot misattribute a shift. */
function ocFill(which) {
    const sel = document.getElementById('oc_' + which + '_user_id');
    const u   = OC_USERS[sel.value];

    document.getElementById('oc_' + which + '_ncgr_id').value = u ? u.ncgr_id : '';
    document.getElementById('oc_' + which + '_email').value   = u ? u.email   : '';

    // Unlike NCGR ID/email, the phone field stays editable after this --
    // it's a starting default from the portal profile, not a fact that
    // must match. The person on call may be reachable on a different
    // number for this particular shift.
    const phoneField = document.getElementById('oc_' + which + '_phone');
    if (phoneField) { phoneField.value = u ? u.phone : ''; }

    // Filling the rota team from the primary's own team is a starting
    // point, not a rule: a Linux engineer can cover the DB rota.
    if (which === 'primary' && u && u.team) {
        const rota = document.getElementById('oc_rota_team');
        if (rota && rota.value === '') { rota.value = u.team; }
    }
}

function ocVisChanged() {
    // The editor markup only exists for users with can_edit, but this runs
    // on DOMContentLoaded for everyone -- without the guards a view-only
    // user takes a TypeError on every page load.
    const wrap = document.getElementById('oc_teams_wrap');
    const hint = document.getElementById('oc_vis_hint');
    if (!wrap || !hint) return;

    const el = document.querySelector('input[name="visibility"]:checked');
    const v  = el ? el.value : 'public';

    wrap.style.display = v === 'teams' ? '' : 'none';
    hint.textContent = OC_VIS_HINT[v] || '';
}

/* 'YYYY-MM-DD HH:MM:SS' (how SQLite holds it) -> what datetime-local wants. */
function ocToLocal(v) {
    if (!v) return '';
    return String(v).replace(' ', 'T').slice(0, 16);
}

function ocOpen(data) {
    const editing = !!data;
    document.getElementById('ocTitle').innerText = editing ? 'Edit Shift' : 'Schedule Shift';
    document.getElementById('oc_id').value = editing ? data.id : '';

    ['shift_label', 'rota_team', 'escalation_to', 'handover_notes',
     'primary_phone', 'secondary_phone'].forEach(f => {
        const el = document.getElementById('oc_' + f);
        if (el) el.value = editing ? (data[f] ?? '') : '';
    });

    document.getElementById('oc_starts_at').value = editing ? ocToLocal(data.starts_at) : '';
    document.getElementById('oc_ends_at').value   = editing ? ocToLocal(data.ends_at)   : '';

    document.getElementById('oc_primary_user_id').value   = editing ? (data.primary_user_id   || '') : '';
    document.getElementById('oc_secondary_user_id').value = editing ? (data.secondary_user_id || '') : '';

    ocFill('primary');
    ocFill('secondary');

    const vis = editing ? (data.visibility || 'public') : 'public';
    const radio = document.querySelector(`input[name="visibility"][value="${vis}"]`);
    if (radio) radio.checked = true;

    const shared = (editing && Array.isArray(data.shared_teams)) ? data.shared_teams : [];
    document.querySelectorAll('input[name="shared_teams[]"]').forEach(cb => {
        cb.checked = shared.includes(cb.value);
    });

    ocVisChanged();
    platOpen('ocModal');
}

function ocDelete(id, name) {
    document.getElementById('ocDelId').value = id;
    document.getElementById('ocDelName').innerText = name;
    platOpen('ocDelModal');
}

function ocAudit(id) {
    document.getElementById('ocAuditTitle').innerText =
        id ? 'Audit Trail — shift #' + id : 'Audit Trail — all shifts';
    document.getElementById('ocAuditBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('ocAuditModal');
    fetch('oncall.php?action=audit&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('ocAuditBody').innerHTML = h; })
        .catch(() => {
            document.getElementById('ocAuditBody').innerHTML = '<p class="plat-empty">Failed to load.</p>';
        });
}

document.addEventListener('DOMContentLoaded', ocVisChanged);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
