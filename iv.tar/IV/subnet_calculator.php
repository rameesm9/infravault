<?php

require_once __DIR__ . '/config/db.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
| Authorization. This page had neither a login check nor a permission
| check -- it fell back to a 'System' username and rendered for anyone.
*/
requireLogin();
requirePermission('subnet_calculator', 'can_view');

$page_title = 'Subnet Calculator';

$current_user = $_SESSION['user_name']
    ?? $_SESSION['username']
    ?? $_SESSION['name']
    ?? $_SESSION['user']['name']
    ?? 'System';

$current_role = strtolower(
    $_SESSION['user_role']
    ?? $_SESSION['role']
    ?? $_SESSION['user']['role']
    ?? 'user'
);

$isAdmin = ($current_role === 'admin' || $current_role === 'administrator');

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<style>

* {
    box-sizing: border-box;
}

.sc-page {
    position: fixed;
    left: 250px;
    right: 0;
    top: var(--header-height, 60px);
    bottom: 0;
    background: var(--bg-main);
    overflow-y: auto;
    transition: .3s ease;
}

body.sidebar-collapsed .sc-page {
    left: 72px;
}

/* ---------------------------------------------------------
   HEADER
--------------------------------------------------------- */

.sc-header {
    background: var(--bg-content);
    border-bottom: 1px solid var(--border-color);
    padding: 20px 24px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.sc-title-area {
    display: flex;
    align-items: center;
    gap: 14px;
}

.sc-title-icon {
    width: 46px;
    height: 46px;
    border-radius: 12px;
    background: #EFF6FF;
    color: #2563EB;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 23px;
    font-weight: 800;
}

.sc-title {
    font-size: 20px;
    font-weight: 750;
    color: var(--text-primary);
}

.sc-subtitle {
    font-size: 12px;
    color: var(--text-muted);
    margin-top: 3px;
}

.sc-offline {
    display: inline-flex;
    align-items: center;
    gap: 7px;
    padding: 7px 11px;
    border-radius: 8px;
    background: #ECFDF5;
    color: #047857;
    font-size: 11px;
    font-weight: 700;
}

.sc-offline-dot {
    width: 7px;
    height: 7px;
    background: #10B981;
    border-radius: 50%;
}

/* ---------------------------------------------------------
   CONTENT
--------------------------------------------------------- */

.sc-content {
    padding: 22px;
    max-width: 1500px;
    margin: 0 auto;
}

.sc-grid {
    display: grid;
    grid-template-columns: minmax(350px, 440px) minmax(500px, 1fr);
    gap: 18px;
    align-items: start;
}

/* ---------------------------------------------------------
   CARDS
--------------------------------------------------------- */

.sc-card {
    background: var(--bg-content);
    border: 1px solid var(--border-color);
    border-radius: 14px;
    box-shadow: 0 2px 10px rgba(15, 23, 42, .035);
    overflow: hidden;
}

.sc-card-header {
    padding: 17px 18px;
    border-bottom: 1px solid var(--border-light);
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.sc-card-title {
    font-size: 14px;
    font-weight: 750;
    color: var(--text-primary);
}

.sc-card-subtitle {
    font-size: 11px;
    color: var(--text-muted);
    margin-top: 3px;
}

.sc-card-body {
    padding: 18px;
}

/* ---------------------------------------------------------
   INPUTS
--------------------------------------------------------- */

.sc-field {
    margin-bottom: 15px;
}

.sc-label {
    display: block;
    font-size: 11px;
    font-weight: 750;
    color: var(--text-secondary);
    text-transform: uppercase;
    letter-spacing: .04em;
    margin-bottom: 7px;
}

.sc-input-row {
    display: flex;
    gap: 8px;
}

.sc-input {
    width: 100%;
    height: 43px;
    border: 1px solid #DDE4EC;
    border-radius: 9px;
    padding: 0 12px;
    background: var(--hover-bg);
    color: var(--text-primary);
    font-family: inherit;
    font-size: 13px;
}

.sc-input:focus {
    outline: none;
    border-color: #2563EB;
    background: var(--bg-content);
    box-shadow: 0 0 0 3px rgba(37, 99, 235, .10);
}

.sc-cidr {
    max-width: 105px;
}

.sc-select {
    width: 100%;
    height: 43px;
    border: 1px solid #DDE4EC;
    border-radius: 9px;
    padding: 0 10px;
    background: var(--hover-bg);
    color: var(--text-primary);
    font-family: inherit;
    font-size: 13px;
}

.sc-select:focus {
    outline: none;
    border-color: #2563EB;
}

/* ---------------------------------------------------------
   BUTTONS
--------------------------------------------------------- */

.sc-buttons {
    display: flex;
    gap: 8px;
    margin-top: 18px;
}

.sc-btn {
    height: 41px;
    border-radius: 9px;
    border: 1px solid var(--border-color);
    background: var(--bg-content);
    padding: 0 15px;
    cursor: pointer;
    font-family: inherit;
    font-size: 12px;
    font-weight: 700;
    color: var(--text-primary);
    transition: .15s ease;
}

.sc-btn:hover {
    background: var(--hover-bg);
}

.sc-btn-primary {
    flex: 1;
    background: #2563EB;
    border-color: #2563EB;
    color: #FFFFFF;
}

.sc-btn-primary:hover {
    background: #1D4ED8;
}

.sc-btn-danger {
    background: #FEF2F2;
    color: #DC2626;
    border-color: #FECACA;
}

/* ---------------------------------------------------------
   RESULT GRID
--------------------------------------------------------- */

.sc-result-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 10px;
}

.sc-result {
    background: var(--hover-bg);
    border: 1px solid #E8EDF3;
    border-radius: 10px;
    padding: 12px;
    min-height: 72px;
}

.sc-result.full {
    grid-column: 1 / -1;
}

.sc-result-label {
    font-size: 10px;
    text-transform: uppercase;
    letter-spacing: .04em;
    color: var(--text-muted);
    font-weight: 750;
    margin-bottom: 6px;
}

.sc-result-value {
    color: var(--text-primary);
    font-size: 13px;
    font-weight: 700;
    word-break: break-word;
}

.sc-result-value.blue {
    color: #2563EB;
}

.sc-result-value.green {
    color: #059669;
}

.sc-result-value.orange {
    color: #D97706;
}

.sc-result-value.red {
    color: #DC2626;
}

/* ---------------------------------------------------------
   COPY
--------------------------------------------------------- */

.sc-copy-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 8px;
}

.sc-copy-btn {
    border: 1px solid var(--border-color);
    background: var(--bg-content);
    color: var(--text-secondary);
    border-radius: 6px;
    padding: 4px 8px;
    font-size: 10px;
    font-weight: 700;
    cursor: pointer;
}

.sc-copy-btn:hover {
    background: #EFF6FF;
    border-color: #93C5FD;
    color: #2563EB;
}

/* ---------------------------------------------------------
   BINARY
--------------------------------------------------------- */

.sc-binary {
    font-family: Consolas, Monaco, monospace;
    font-size: 12px;
    line-height: 1.9;
    color: var(--text-secondary);
    background: #0F172A;
    padding: 14px;
    border-radius: 9px;
    overflow-x: auto;
}

.binary-network {
    color: #60A5FA;
    font-weight: 700;
}

.binary-host {
    color: #CBD5E1;
}

/* ---------------------------------------------------------
   QUICK CIDR
--------------------------------------------------------- */

.sc-reference {
    margin-top: 18px;
}

.sc-table-wrapper {
    overflow-x: auto;
}

.sc-table {
    width: 100%;
    border-collapse: collapse;
    font-size: 11px;
}

.sc-table th {
    text-align: left;
    background: var(--hover-bg);
    color: var(--text-secondary);
    font-weight: 750;
    padding: 9px 10px;
    border-bottom: 1px solid var(--border-color);
}

.sc-table td {
    padding: 9px 10px;
    border-bottom: 1px solid var(--border-light);
    color: var(--text-primary);
}

.sc-table tr:hover td {
    background: var(--hover-bg);
}

.sc-cidr-link {
    color: #2563EB;
    font-weight: 750;
    cursor: pointer;
}

/* ---------------------------------------------------------
   STATUS
--------------------------------------------------------- */

.sc-message {
    margin-top: 12px;
    padding: 10px 12px;
    border-radius: 8px;
    display: none;
    font-size: 11px;
    font-weight: 600;
}

.sc-message.error {
    display: block;
    background: #FEF2F2;
    color: #B91C1C;
    border: 1px solid #FECACA;
}

.sc-message.success {
    display: block;
    background: #ECFDF5;
    color: #047857;
    border: 1px solid #A7F3D0;
}

/* ---------------------------------------------------------
   HOST RANGE
--------------------------------------------------------- */

.sc-host-range {
    background: #EFF6FF;
    border: 1px solid #BFDBFE;
    border-radius: 10px;
    padding: 13px;
    margin-top: 12px;
}

.sc-host-range-title {
    font-size: 10px;
    color: var(--text-secondary);
    text-transform: uppercase;
    font-weight: 750;
    margin-bottom: 5px;
}

.sc-host-range-value {
    font-size: 13px;
    font-weight: 750;
    color: #1D4ED8;
}

/* ---------------------------------------------------------
   DARK MODE
--------------------------------------------------------- */

[data-theme="dark"] .sc-btn-danger {
    background: #3a1a1a;
    color: #F1837A;
    border-color: #5c2a2a;
}

[data-theme="dark"] .sc-message.error {
    background: #3a1a1a;
    color: #F1837A;
    border-color: #5c2a2a;
}

[data-theme="dark"] .sc-message.success {
    background: #123528;
    color: #4CC49A;
    border-color: #1f5a3e;
}

[data-theme="dark"] .sc-host-range {
    background: #1e2a4a;
    border-color: #29365a;
}

[data-theme="dark"] .sc-host-range-value {
    color: #7BA6FF;
}

[data-theme="dark"] .sc-copy-btn:hover {
    background: #1e2a4a;
    border-color: #29365a;
    color: #7BA6FF;
}

/* ---------------------------------------------------------
   RESPONSIVE
--------------------------------------------------------- */

@media (max-width: 1100px) {

    .sc-grid {
        grid-template-columns: 1fr;
    }

}

@media (max-width: 700px) {

    .sc-page {
        left: 0;
        top: 70px;
    }

    body.sidebar-collapsed .sc-page {
        left: 0;
    }

    .sc-header {
        padding: 15px;
    }

    .sc-content {
        padding: 12px;
    }

    .sc-offline {
        display: none;
    }

    .sc-result-grid {
        grid-template-columns: 1fr;
    }

    .sc-result.full {
        grid-column: auto;
    }

}

</style>


<div class="sc-page">

    <!-- HEADER -->
    <div class="sc-header">

        <div class="sc-title-area">

            <div class="sc-title-icon">
                #
            </div>

            <div>
                <div class="sc-title">
                    IPv4 Subnet Calculator
                </div>

                <div class="sc-subtitle">
                    Calculate network, broadcast, hosts, masks and address ranges
                </div>
            </div>

        </div>

        <div class="sc-offline">
            <span class="sc-offline-dot"></span>
            100% Offline
        </div>

    </div>


    <div class="sc-content">

        <div class="sc-grid">

            <!-- =====================================================
                 CALCULATOR
            ====================================================== -->

            <div>

                <div class="sc-card">

                    <div class="sc-card-header">

                        <div>
                            <div class="sc-card-title">
                                Network Input
                            </div>

                            <div class="sc-card-subtitle">
                                Enter an IPv4 address and CIDR prefix
                            </div>
                        </div>

                    </div>

                    <div class="sc-card-body">

                        <div class="sc-field">

                            <label class="sc-label">
                                IPv4 Address
                            </label>

                            <div class="sc-input-row">

                                <input
                                    id="ipAddress"
                                    class="sc-input"
                                    type="text"
                                    value="192.168.1.10"
                                    placeholder="192.168.1.10"
                                    autocomplete="off"
                                >

                                <input
                                    id="cidr"
                                    class="sc-input sc-cidr"
                                    type="number"
                                    min="0"
                                    max="32"
                                    value="24"
                                    placeholder="/24"
                                >

                            </div>

                        </div>


                        <div class="sc-field">

                            <label class="sc-label">
                                CIDR Prefix
                            </label>

                            <select id="cidrSelect" class="sc-select">

                                <option value="0">/0</option>
                                <option value="1">/1</option>
                                <option value="2">/2</option>
                                <option value="3">/3</option>
                                <option value="4">/4</option>
                                <option value="5">/5</option>
                                <option value="6">/6</option>
                                <option value="7">/7</option>
                                <option value="8">/8</option>
                                <option value="9">/9</option>
                                <option value="10">/10</option>
                                <option value="11">/11</option>
                                <option value="12">/12</option>
                                <option value="13">/13</option>
                                <option value="14">/14</option>
                                <option value="15">/15</option>
                                <option value="16">/16</option>
                                <option value="17">/17</option>
                                <option value="18">/18</option>
                                <option value="19">/19</option>
                                <option value="20">/20</option>
                                <option value="21">/21</option>
                                <option value="22">/22</option>
                                <option value="23">/23</option>
                                <option value="24" selected>/24</option>
                                <option value="25">/25</option>
                                <option value="26">/26</option>
                                <option value="27">/27</option>
                                <option value="28">/28</option>
                                <option value="29">/29</option>
                                <option value="30">/30</option>
                                <option value="31">/31</option>
                                <option value="32">/32</option>

                            </select>

                        </div>


                        <div class="sc-buttons">

                            <button
                                type="button"
                                class="sc-btn sc-btn-primary"
                                onclick="calculateSubnet()"
                            >
                                Calculate Subnet
                            </button>

                            <button
                                type="button"
                                class="sc-btn"
                                onclick="loadExample()"
                            >
                                Example
                            </button>

                            <button
                                type="button"
                                class="sc-btn sc-btn-danger"
                                onclick="clearCalculator()"
                            >
                                Clear
                            </button>

                        </div>


                        <div id="messageBox" class="sc-message"></div>

                    </div>

                </div>


                <!-- QUICK REFERENCE -->

                <div class="sc-card sc-reference">

                    <div class="sc-card-header">

                        <div>
                            <div class="sc-card-title">
                                CIDR Quick Reference
                            </div>

                            <div class="sc-card-subtitle">
                                Common IPv4 subnet sizes
                            </div>
                        </div>

                    </div>

                    <div class="sc-card-body">

                        <div class="sc-table-wrapper">

                            <table class="sc-table">

                                <thead>

                                    <tr>
                                        <th>CIDR</th>
                                        <th>Subnet Mask</th>
                                        <th>Total</th>
                                        <th>Usable</th>
                                    </tr>

                                </thead>

                                <tbody>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(8)">/8</td>
                                        <td>255.0.0.0</td>
                                        <td>16,777,216</td>
                                        <td>16,777,214</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(16)">/16</td>
                                        <td>255.255.0.0</td>
                                        <td>65,536</td>
                                        <td>65,534</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(24)">/24</td>
                                        <td>255.255.255.0</td>
                                        <td>256</td>
                                        <td>254</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(25)">/25</td>
                                        <td>255.255.255.128</td>
                                        <td>128</td>
                                        <td>126</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(26)">/26</td>
                                        <td>255.255.255.192</td>
                                        <td>64</td>
                                        <td>62</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(27)">/27</td>
                                        <td>255.255.255.224</td>
                                        <td>32</td>
                                        <td>30</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(28)">/28</td>
                                        <td>255.255.255.240</td>
                                        <td>16</td>
                                        <td>14</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(29)">/29</td>
                                        <td>255.255.255.248</td>
                                        <td>8</td>
                                        <td>6</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(30)">/30</td>
                                        <td>255.255.255.252</td>
                                        <td>4</td>
                                        <td>2</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(31)">/31</td>
                                        <td>255.255.255.254</td>
                                        <td>2</td>
                                        <td>2*</td>
                                    </tr>

                                    <tr>
                                        <td class="sc-cidr-link" onclick="setCIDR(32)">/32</td>
                                        <td>255.255.255.255</td>
                                        <td>1</td>
                                        <td>1*</td>
                                    </tr>

                                </tbody>

                            </table>

                        </div>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 RESULTS
            ====================================================== -->

            <div class="sc-card">

                <div class="sc-card-header">

                    <div>

                        <div class="sc-card-title">
                            Subnet Details
                        </div>

                        <div class="sc-card-subtitle">
                            Calculated IPv4 network information
                        </div>

                    </div>

                </div>


                <div class="sc-card-body">

                    <div class="sc-result-grid">

                        <!-- NETWORK -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Network Address
                            </div>

                            <div class="sc-copy-row">

                                <div
                                    id="networkAddress"
                                    class="sc-result-value blue"
                                >
                                    —
                                </div>

                                <button
                                    class="sc-copy-btn"
                                    onclick="copyResult('networkAddress')"
                                >
                                    Copy
                                </button>

                            </div>

                        </div>


                        <!-- BROADCAST -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Broadcast Address
                            </div>

                            <div class="sc-copy-row">

                                <div
                                    id="broadcastAddress"
                                    class="sc-result-value orange"
                                >
                                    —
                                </div>

                                <button
                                    class="sc-copy-btn"
                                    onclick="copyResult('broadcastAddress')"
                                >
                                    Copy
                                </button>

                            </div>

                        </div>


                        <!-- FIRST -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                First Usable Host
                            </div>

                            <div
                                id="firstHost"
                                class="sc-result-value green"
                            >
                                —
                            </div>

                        </div>


                        <!-- LAST -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Last Usable Host
                            </div>

                            <div
                                id="lastHost"
                                class="sc-result-value green"
                            >
                                —
                            </div>

                        </div>


                        <!-- MASK -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Subnet Mask
                            </div>

                            <div
                                id="subnetMask"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- WILDCARD -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Wildcard Mask
                            </div>

                            <div
                                id="wildcardMask"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- CIDR -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                CIDR
                            </div>

                            <div
                                id="cidrResult"
                                class="sc-result-value blue"
                            >
                                —
                            </div>

                        </div>


                        <!-- IP CLASS -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                IP Class
                            </div>

                            <div
                                id="ipClass"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- TOTAL -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Total Addresses
                            </div>

                            <div
                                id="totalAddresses"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- USABLE -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Usable Hosts
                            </div>

                            <div
                                id="usableHosts"
                                class="sc-result-value green"
                            >
                                —
                            </div>

                        </div>


                        <!-- NETWORK BITS -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Network Bits
                            </div>

                            <div
                                id="networkBits"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- HOST BITS -->

                        <div class="sc-result">

                            <div class="sc-result-label">
                                Host Bits
                            </div>

                            <div
                                id="hostBits"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>


                        <!-- TYPE -->

                        <div class="sc-result full">

                            <div class="sc-result-label">
                                Address Type
                            </div>

                            <div
                                id="addressType"
                                class="sc-result-value"
                            >
                                —
                            </div>

                        </div>

                    </div>


                    <!-- HOST RANGE -->

                    <div class="sc-host-range">

                        <div class="sc-host-range-title">
                            Host Range
                        </div>

                        <div
                            id="hostRange"
                            class="sc-host-range-value"
                        >
                            —
                        </div>

                    </div>


                    <!-- BINARY -->

                    <div style="margin-top:18px;">

                        <div
                            class="sc-card-title"
                            style="margin-bottom:8px;"
                        >
                            Binary Representation
                        </div>

                        <div
                            id="binaryOutput"
                            class="sc-binary"
                        >
                            —
                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</div>


<script>

/* =========================================================
   IPv4 SUBNET CALCULATOR
   100% CLIENT SIDE / OFFLINE
========================================================= */

function ipToNumber(ip) {

    const parts = ip.trim().split('.');

    if (parts.length !== 4) {
        return null;
    }

    let result = 0;

    for (let i = 0; i < 4; i++) {

        if (!/^\d+$/.test(parts[i])) {
            return null;
        }

        const value = Number(parts[i]);

        if (value < 0 || value > 255) {
            return null;
        }

        result = result * 256 + value;
    }

    return result;
}


function numberToIP(num) {

    num = Number(num) >>> 0;

    return [
        (num >>> 24) & 255,
        (num >>> 16) & 255,
        (num >>> 8) & 255,
        num & 255
    ].join('.');
}


function cidrToMask(cidr) {

    if (cidr === 0) {
        return 0;
    }

    return (0xFFFFFFFF << (32 - cidr)) >>> 0;
}


function wildcardFromMask(mask) {

    return (~mask) >>> 0;
}


function formatNumber(num) {

    return Number(num).toLocaleString('en-US');
}


function binaryIP(num) {

    const ip = numberToIP(num);

    return ip
        .split('.')
        .map(part => Number(part).toString(2).padStart(8, '0'))
        .join('.');
}


function getIPClass(firstOctet) {

    if (firstOctet >= 1 && firstOctet <= 126) {
        return 'Class A';
    }

    if (firstOctet >= 128 && firstOctet <= 191) {
        return 'Class B';
    }

    if (firstOctet >= 192 && firstOctet <= 223) {
        return 'Class C';
    }

    if (firstOctet >= 224 && firstOctet <= 239) {
        return 'Class D (Multicast)';
    }

    if (firstOctet >= 240 && firstOctet <= 255) {
        return 'Class E (Experimental)';
    }

    return 'Unknown';
}


function getAddressType(ipNum) {

    const a = (ipNum >>> 24) & 255;
    const b = (ipNum >>> 16) & 255;

    /* Private 10.0.0.0/8 */
    if (a === 10) {
        return 'Private IPv4 — 10.0.0.0/8';
    }

    /* Private 172.16.0.0/12 */
    if (a === 172 && b >= 16 && b <= 31) {
        return 'Private IPv4 — 172.16.0.0/12';
    }

    /* Private 192.168.0.0/16 */
    if (a === 192 && b === 168) {
        return 'Private IPv4 — 192.168.0.0/16';
    }

    /* Loopback */
    if (a === 127) {
        return 'Loopback — 127.0.0.0/8';
    }

    /* Link local */
    if (a === 169 && b === 254) {
        return 'Link-Local — 169.254.0.0/16';
    }

    /* Multicast */
    if (a >= 224 && a <= 239) {
        return 'Multicast';
    }

    /* Experimental */
    if (a >= 240) {
        return 'Experimental / Reserved';
    }

    return 'Public IPv4';
}


function setText(id, value, className = '') {

    const el = document.getElementById(id);

    if (!el) {
        return;
    }

    el.textContent = value;

    el.classList.remove(
        'blue',
        'green',
        'orange',
        'red'
    );

    if (className) {
        el.classList.add(className);
    }
}


function showMessage(message, type = 'error') {

    const box = document.getElementById('messageBox');

    box.textContent = message;
    box.className = 'sc-message ' + type;
}


function clearMessage() {

    const box = document.getElementById('messageBox');

    box.textContent = '';
    box.className = 'sc-message';

}


function calculateSubnet() {

    clearMessage();

    const ipText =
        document.getElementById('ipAddress').value.trim();

    let cidr =
        Number(document.getElementById('cidr').value);

    if (!ipText) {

        showMessage(
            'Please enter an IPv4 address.'
        );

        return;
    }

    if (
        !Number.isInteger(cidr) ||
        cidr < 0 ||
        cidr > 32
    ) {

        showMessage(
            'CIDR prefix must be between /0 and /32.'
        );

        return;
    }


    const ipNum = ipToNumber(ipText);

    if (ipNum === null) {

        showMessage(
            'Invalid IPv4 address. Example: 192.168.1.10'
        );

        return;
    }


    const mask = cidrToMask(cidr);

    const wildcard = wildcardFromMask(mask);

    const network =
        (ipNum & mask) >>> 0;

    const broadcast =
        (network | wildcard) >>> 0;


    let totalAddresses;

    if (cidr === 0) {
        totalAddresses = 4294967296;
    } else {
        totalAddresses =
            Math.pow(2, 32 - cidr);
    }


    let usableHosts;

    let firstHost;
    let lastHost;


    /*
     * RFC 3021 style handling:
     *
     * /31 = 2 usable addresses
     * /32 = 1 address
     */

    if (cidr === 32) {

        usableHosts = 1;
        firstHost = network;
        lastHost = network;

    } else if (cidr === 31) {

        usableHosts = 2;
        firstHost = network;
        lastHost = broadcast;

    } else {

        usableHosts =
            Math.max(0, totalAddresses - 2);

        firstHost =
            (network + 1) >>> 0;

        lastHost =
            (broadcast - 1) >>> 0;
    }


    const firstOctet =
        (ipNum >>> 24) & 255;


    const maskIP =
        numberToIP(mask);

    const wildcardIP =
        numberToIP(wildcard);

    const networkIP =
        numberToIP(network);

    const broadcastIP =
        numberToIP(broadcast);

    const firstHostIP =
        numberToIP(firstHost);

    const lastHostIP =
        numberToIP(lastHost);


    /* OUTPUT */

    setText(
        'networkAddress',
        networkIP,
        'blue'
    );

    setText(
        'broadcastAddress',
        broadcastIP,
        'orange'
    );

    setText(
        'firstHost',
        firstHostIP,
        'green'
    );

    setText(
        'lastHost',
        lastHostIP,
        'green'
    );

    setText(
        'subnetMask',
        maskIP
    );

    setText(
        'wildcardMask',
        wildcardIP
    );

    setText(
        'cidrResult',
        '/' + cidr,
        'blue'
    );

    setText(
        'ipClass',
        getIPClass(firstOctet)
    );

    setText(
        'totalAddresses',
        formatNumber(totalAddresses)
    );

    setText(
        'usableHosts',
        formatNumber(usableHosts),
        'green'
    );

    setText(
        'networkBits',
        cidr + ' bits'
    );

    setText(
        'hostBits',
        (32 - cidr) + ' bits'
    );

    setText(
        'addressType',
        getAddressType(ipNum)
    );


    let rangeText;

    if (cidr === 32) {

        rangeText =
            networkIP;

    } else {

        rangeText =
            firstHostIP + ' — ' + lastHostIP;
    }


    setText(
        'hostRange',
        rangeText
    );


    /* -----------------------------------------------------
       BINARY
    ----------------------------------------------------- */

    const ipBinary =
        binaryIP(ipNum);

    const maskBinary =
        binaryIP(mask);

    const networkBinary =
        binaryIP(network);

    const broadcastBinary =
        binaryIP(broadcast);


    document.getElementById(
        'binaryOutput'
    ).innerHTML =

        '<div>' +
            '<strong>IP&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;:</strong> ' +
            ipBinary +
        '</div>' +

        '<div>' +
            '<strong>Mask&nbsp;&nbsp;&nbsp;&nbsp;:</strong> ' +
            maskBinary +
        '</div>' +

        '<div>' +
            '<strong>Network&nbsp;&nbsp;:</strong> ' +
            networkBinary +
        '</div>' +

        '<div>' +
            '<strong>Broadcast&nbsp;:</strong> ' +
            broadcastBinary +
        '</div>';


    showMessage(
        'Subnet calculated successfully.',
        'success'
    );
}


/* =========================================================
   CIDR SELECT
========================================================= */

const cidrInput =
    document.getElementById('cidr');

const cidrSelect =
    document.getElementById('cidrSelect');


cidrInput.addEventListener(
    'input',
    function () {

        let value = Number(this.value);

        if (value < 0) {
            value = 0;
        }

        if (value > 32) {
            value = 32;
        }

        if (this.value !== '') {
            cidrSelect.value = value;
        }

        calculateSubnet();
    }
);


cidrSelect.addEventListener(
    'change',
    function () {

        cidrInput.value = this.value;

        calculateSubnet();
    }
);


/* =========================================================
   ENTER KEY
========================================================= */

document.getElementById(
    'ipAddress'
).addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Enter') {
            calculateSubnet();
        }

    }
);


document.getElementById(
    'cidr'
).addEventListener(
    'keydown',
    function (event) {

        if (event.key === 'Enter') {
            calculateSubnet();
        }

    }
);


/* =========================================================
   QUICK CIDR
========================================================= */

function setCIDR(cidr) {

    document.getElementById(
        'cidr'
    ).value = cidr;

    document.getElementById(
        'cidrSelect'
    ).value = cidr;

    calculateSubnet();
}


/* =========================================================
   EXAMPLE
========================================================= */

function loadExample() {

    document.getElementById(
        'ipAddress'
    ).value = '192.168.10.25';

    document.getElementById(
        'cidr'
    ).value = 24;

    document.getElementById(
        'cidrSelect'
    ).value = 24;

    calculateSubnet();
}


/* =========================================================
   CLEAR
========================================================= */

function clearCalculator() {

    document.getElementById(
        'ipAddress'
    ).value = '';

    document.getElementById(
        'cidr'
    ).value = 24;

    document.getElementById(
        'cidrSelect'
    ).value = 24;

    const fields = [
        'networkAddress',
        'broadcastAddress',
        'firstHost',
        'lastHost',
        'subnetMask',
        'wildcardMask',
        'cidrResult',
        'ipClass',
        'totalAddresses',
        'usableHosts',
        'networkBits',
        'hostBits',
        'addressType',
        'hostRange'
    ];

    fields.forEach(function(id) {

        setText(id, '—');

    });

    document.getElementById(
        'binaryOutput'
    ).textContent = '—';

    clearMessage();
}


/* =========================================================
   COPY
========================================================= */

function copyResult(id) {

    const el =
        document.getElementById(id);

    if (!el) {
        return;
    }

    const value =
        el.textContent.trim();

    if (
        !value ||
        value === '—'
    ) {
        return;
    }


    if (
        navigator.clipboard &&
        window.isSecureContext
    ) {

        navigator.clipboard
            .writeText(value)
            .then(function () {

                showMessage(
                    'Copied: ' + value,
                    'success'
                );

            })
            .catch(function () {

                fallbackCopy(value);

            });

    } else {

        fallbackCopy(value);

    }
}


function fallbackCopy(text) {

    const textarea =
        document.createElement('textarea');

    textarea.value = text;

    textarea.style.position = 'fixed';
    textarea.style.left = '-9999px';

    document.body.appendChild(textarea);

    textarea.select();

    try {

        document.execCommand('copy');

        showMessage(
            'Copied: ' + text,
            'success'
        );

    } catch (error) {

        showMessage(
            'Unable to copy automatically.',
            'error'
        );

    }

    document.body.removeChild(textarea);
}


/* =========================================================
   AUTO CALCULATE
========================================================= */

calculateSubnet();

</script>


<?php require_once __DIR__ . '/includes/footer.php'; ?>