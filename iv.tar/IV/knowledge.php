<?php

require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/comments-helpers.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/*
|--------------------------------------------------------------------------
| Authentication
|--------------------------------------------------------------------------
*/

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('knowledge', 'can_view');


$current_user_id = (int) $_SESSION['user_id'];

$role = strtolower(trim($_SESSION['role'] ?? ''));

$is_admin = in_array($role, [
    'admin',
    'administrator',
    'super admin',
    'superadmin'
], true);

// Get user's team (for team-based visibility)
$userTeamStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userTeamStmt->execute([$current_user_id]);
$userTeamRecord = $userTeamStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userTeamRecord['team'] ?? '';

// Permission checks for this module
$canViewKB = hasRolePermission($pdo, $role, 'knowledge_base', 'can_view');
$canEditKB = hasRolePermission($pdo, $role, 'knowledge_base', 'can_edit');
$canDeleteKB = hasRolePermission($pdo, $role, 'knowledge_base', 'can_delete');
$canExportKB = hasRolePermission($pdo, $role, 'knowledge_base', 'can_export');
$canAuditKB = hasRolePermission($pdo, $role, 'knowledge_base', 'can_audit');

if (!$is_admin && !$canViewKB) {
    http_response_code(403);
    exit('You do not have permission to view Knowledge Base.');
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
*/

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrf_token = $_SESSION['csrf_token'];


/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}


function redirect_kb($id = null): void
{
    if ($id !== null) {
        header('Location: knowledge.php?action=view&id=' . (int) $id);
    } else {
        header('Location: knowledge.php');
    }

    exit;
}


function check_csrf(): void
{
    $token = $_POST['csrf_token'] ?? '';

    if (
        empty($_SESSION['csrf_token']) ||
        !hash_equals($_SESSION['csrf_token'], $token)
    ) {
        http_response_code(403);
        exit('Invalid security token.');
    }
}


/*
|--------------------------------------------------------------------------
| HTML Sanitizer
|--------------------------------------------------------------------------
*/

function sanitize_kb_html(string $html): string
{
    $allowed_tags = [
        'p',
        'br',
        'strong',
        'b',
        'em',
        'i',
        'u',
        'h1',
        'h2',
        'h3',
        'h4',
        'ul',
        'ol',
        'li',
        'blockquote',
        'pre',
        'code',
        'table',
        'thead',
        'tbody',
        'tr',
        'th',
        'td',
        'a',
        'img',
        'hr'
    ];

    $html = strip_tags(
        $html,
        '<' . implode('><', $allowed_tags) . '>'
    );

    // Remove JavaScript event handlers.
    $html = preg_replace(
        '/\son[a-z]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/i',
        '',
        $html
    );

    // Remove javascript URLs.
    $html = preg_replace(
        '/javascript\s*:/i',
        '',
        $html
    );

    // Remove dangerous data URLs.
    $html = preg_replace_callback(
        '/<img\b([^>]*)>/i',
        function ($match) {

            $attributes = $match[1];

            if (
                preg_match(
                    '/src\s*=\s*["\']\s*data:/i',
                    $attributes
                )
            ) {
                return '';
            }

            return '<img' . $attributes . '>';
        },
        $html
    );

    return trim($html);
}


/*
|--------------------------------------------------------------------------
| Generate KB number
|--------------------------------------------------------------------------
*/

function generate_kb_number(PDO $pdo): string
{
    $stmt = $pdo->query("
        SELECT kb_number
        FROM knowledge_base
        ORDER BY id DESC
        LIMIT 1
    ");

    $last = $stmt->fetchColumn();

    if (!$last) {
        return 'KB-001';
    }

    if (preg_match('/(\d+)$/', $last, $matches)) {

        $number = ((int) $matches[1]) + 1;

        return 'KB-' . str_pad(
            $number,
            3,
            '0',
            STR_PAD_LEFT
        );
    }

    return 'KB-001';
}


/*
|--------------------------------------------------------------------------
| User name
|--------------------------------------------------------------------------
*/

function get_user_name(PDO $pdo, int $user_id): string
{
    if ($user_id <= 0) {
        return 'Unknown User';
    }

    $stmt = $pdo->prepare("
        SELECT first_name, last_name
        FROM users
        WHERE id = ?
        LIMIT 1
    ");

    $stmt->execute([$user_id]);

    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        return 'Unknown User';
    }

    return trim(
        $user['first_name'] . ' ' . $user['last_name']
    );
}


/*
|--------------------------------------------------------------------------
| Permissions
|--------------------------------------------------------------------------
*/

function can_edit_kb(
    array $kb,
    int $user_id,
    bool $is_admin
): bool {
    global $pdo, $role, $user_team;

    if ($is_admin) {
        return true;
    }

    $is_author = ((int) $kb['created_by'] === $user_id);

    if ($is_author) {
        return hasRolePermission($pdo, $role, 'knowledge_base', 'can_edit');
    }

    $sharedTeams = getSharedTeams($pdo, 'knowledge_base', (int) $kb['id']);
    $access = getItemAccessLevel(
        $pdo, $user_id, $role, $user_team,
        (int) $kb['created_by'], $kb['visibility'] ?? 'public', $kb['owner_team'] ?? '',
        $sharedTeams, 'knowledge_base'
    );

    return $access === 'full_access' || $access === 'edit_only';
}


function can_delete_kb(
    array $kb,
    int $user_id,
    bool $is_admin
): bool {
    global $pdo, $role, $user_team;

    if ($is_admin) {
        return true;
    }

    $is_author = ((int) $kb['created_by'] === $user_id);

    if ($is_author) {
        return hasRolePermission($pdo, $role, 'knowledge_base', 'can_delete');
    }

    $sharedTeams = getSharedTeams($pdo, 'knowledge_base', (int) $kb['id']);
    $access = getItemAccessLevel(
        $pdo, $user_id, $role, $user_team,
        (int) $kb['created_by'], $kb['visibility'] ?? 'public', $kb['owner_team'] ?? '',
        $sharedTeams, 'knowledge_base'
    );

    return $access === 'full_access' && hasRolePermission($pdo, $role, 'knowledge_base', 'can_delete');
}


function can_view_kb(
    array $kb,
    int $user_id,
    bool $is_admin
): bool {
    global $pdo, $role, $user_team;

    if ($is_admin) {
        return true;
    }

    $sharedTeams = getSharedTeams($pdo, 'knowledge_base', (int) $kb['id']);
    $access = getItemAccessLevel(
        $pdo, $user_id, $role, $user_team,
        (int) $kb['created_by'], $kb['visibility'] ?? 'public', $kb['owner_team'] ?? '',
        $sharedTeams, 'knowledge_base'
    );

    return $access !== 'none';
}


/*
|--------------------------------------------------------------------------
| Attachment Upload
|--------------------------------------------------------------------------
*/

function process_kb_attachments(
    PDO $pdo,
    string $upload_dir_fs,
    int $kb_id,
    int $uploader_id
): void {

    if (
        empty($_FILES['attachments']) ||
        empty($_FILES['attachments']['name'][0])
    ) {
        return;
    }

    if (!is_dir($upload_dir_fs)) {
        mkdir($upload_dir_fs, 0755, true);
    }

    $allowed_exts = [
        'pdf',
        'doc',
        'docx',
        'xls',
        'xlsx',
        'csv',
        'ppt',
        'pptx',
        'png',
        'jpg',
        'jpeg',
        'gif',
        'webp',
        'txt',
        'zip',
        'rar',
        '7z'
    ];

    $count = count($_FILES['attachments']['name']);

    for ($i = 0; $i < $count; $i++) {

        if (
            $_FILES['attachments']['error'][$i]
            !== UPLOAD_ERR_OK
        ) {
            continue;
        }

        $orig = basename(
            $_FILES['attachments']['name'][$i]
        );

        $ext = strtolower(
            pathinfo($orig, PATHINFO_EXTENSION)
        );

        if (!in_array($ext, $allowed_exts, true)) {
            continue;
        }

        $safe_name = preg_replace(
            "/[^a-zA-Z0-9._-]/",
            "_",
            $orig
        );

        $stored = bin2hex(
            random_bytes(12)
        ) . '_' . $safe_name;

        $destination =
            $upload_dir_fs . '/' . $stored;

        if (
            move_uploaded_file(
                $_FILES['attachments']['tmp_name'][$i],
                $destination
            )
        ) {

            $relative =
                'uploads/knowledge/' . $stored;

            $mime =
                mime_content_type($destination)
                ?: 'application/octet-stream';

            $size =
                filesize($destination);

            $stmt = $pdo->prepare("
                INSERT INTO knowledge_base_attachments (
                    kb_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size,
                    uploaded_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $kb_id,
                $orig,
                $stored,
                $relative,
                $mime,
                $size,
                $uploader_id
            ]);
        }
    }
}


/*
|--------------------------------------------------------------------------
| Categories
|--------------------------------------------------------------------------
*/

$categories = [
    'Linux',
    'Windows',
    'Database',
    'Network',
    'Security',
    'Cloud',
    'Application',
    'Server',
    'Storage',
    'Backup',
    'Monitoring',
    'Troubleshooting',
    'Commands',
    'Configuration',
    'Deployment',
    'Infrastructure',
    'General',
    'Other'
];


/*
|--------------------------------------------------------------------------
| Messages
|--------------------------------------------------------------------------
*/

$success_msg =
    $_SESSION['kb_success'] ?? '';

$error_msg =
    $_SESSION['kb_error'] ?? '';

unset(
    $_SESSION['kb_success'],
    $_SESSION['kb_error']
);


/*
|--------------------------------------------------------------------------
| Action
|--------------------------------------------------------------------------
*/

$action = $_GET['action'] ?? 'list';

$upload_dir_fs =
    __DIR__ . '/uploads/knowledge';


/*
|--------------------------------------------------------------------------
| POST ACTIONS
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    check_csrf();

    $post_action =
        $_POST['form_action'] ?? '';


    /*
    |--------------------------------------------------------------------------
    | SAVE
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'save_kb') {

        $kb_id =
            (int) ($_POST['kb_id'] ?? 0);

        $title =
            trim($_POST['title'] ?? '');

        $category =
            trim($_POST['category'] ?? '');

        $description =
            trim($_POST['description'] ?? '');

        $visibility =
            trim($_POST['visibility'] ?? 'public');

        $content =
            sanitize_kb_html(
                $_POST['content_html'] ?? ''
            );

        // Validate visibility
        if (!in_array(
            $visibility,
            ['public', 'team', 'teams'],
            true
        )) {
            $visibility = 'public';
        }

        // Get shared teams
        $shared_teams = isset($_POST['shared_teams']) ? array_filter(explode(',', trim($_POST['shared_teams']))) : [];


        if ($title === '') {

            $_SESSION['kb_error'] =
                'Knowledge title is required.';

            redirect_kb($kb_id ?: null);
        }


        if ($category === '') {

            $_SESSION['kb_error'] =
                'Category is required.';

            redirect_kb($kb_id ?: null);
        }


        /*
        |--------------------------------------------------------------------------
        | CREATE
        |--------------------------------------------------------------------------
        */

        if ($kb_id === 0) {

            $kb_number =
                generate_kb_number($pdo);

            $stmt = $pdo->prepare("
                INSERT INTO knowledge_base (
                    kb_number,
                    title,
                    category,
                    description,
                    content_html,
                    created_by,
                    visibility,
                    version,
                    created_at,
                    updated_at
                )
                VALUES (
                    ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP
                )
            ");

            $stmt->execute([
                $kb_number,
                $title,
                $category,
                $description,
                $content,
                $current_user_id,
                $visibility,
                '1.0'
            ]);

            $kb_id =
                (int) $pdo->lastInsertId();


            /*
            |--------------------------------------------------------------------------
            | Initial revision
            |--------------------------------------------------------------------------
            */

            $revision =
                $pdo->prepare("
                    INSERT INTO knowledge_base_revisions (
                        kb_id,
                        version,
                        title,
                        content_html,
                        changed_by,
                        change_summary
                    )
                    VALUES (?, ?, ?, ?, ?, ?)
                ");

            $revision->execute([
                $kb_id,
                '1.0',
                $title,
                $content,
                $current_user_id,
                'Knowledge note created'
            ]);


            process_kb_attachments(
                $pdo,
                $upload_dir_fs,
                $kb_id,
                $current_user_id
            );

            // Save visibility and sharing
            saveItemSharing($pdo, 'knowledge_base', $kb_id, $visibility, $shared_teams);
            if ($visibility === 'team') {
                $pdo->prepare("UPDATE knowledge_base SET owner_team = ? WHERE id = ?")->execute([$user_team, $kb_id]);
            }

            // Log creation to audit trail
            $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
            logItemAction($pdo, 'knowledge_base', $kb_id, 'CREATED', $current_user_id, $userName, ['visibility' => $visibility]);

            $_SESSION['kb_success'] =
                'Knowledge note created successfully.';

            redirect_kb($kb_id);
        }


        /*
        |--------------------------------------------------------------------------
        | UPDATE
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT *
            FROM knowledge_base
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$kb_id]);

        $existing =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$existing) {

            $_SESSION['kb_error'] =
                'Knowledge note not found.';

            redirect_kb();
        }


        if (!can_edit_kb(
            $existing,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'You do not have permission to edit this knowledge note.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Version
        |--------------------------------------------------------------------------
        */

        $old_version =
            $existing['version'] ?: '1.0';

        $parts =
            explode('.', $old_version);

        $major =
            (int) ($parts[0] ?? 1);

        $minor =
            (int) ($parts[1] ?? 0);

        $new_version =
            $major . '.' . ($minor + 1);


        $stmt = $pdo->prepare("
            UPDATE knowledge_base
            SET
                title = ?,
                category = ?,
                description = ?,
                content_html = ?,
                visibility = ?,
                version = ?,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");

        $stmt->execute([
            $title,
            $category,
            $description,
            $content,
            $visibility,
            $new_version,
            $kb_id
        ]);


        /*
        |--------------------------------------------------------------------------
        | Revision
        |--------------------------------------------------------------------------
        */

        $revision =
            $pdo->prepare("
                INSERT INTO knowledge_base_revisions (
                    kb_id,
                    version,
                    title,
                    content_html,
                    changed_by,
                    change_summary
                )
                VALUES (?, ?, ?, ?, ?, ?)
            ");

        $revision->execute([
            $kb_id,
            $new_version,
            $title,
            $content,
            $current_user_id,
            'Knowledge note updated'
        ]);


        process_kb_attachments(
            $pdo,
            $upload_dir_fs,
            $kb_id,
            $current_user_id
        );

        // Save visibility and sharing (junction table + owner_team)
        saveItemSharing($pdo, 'knowledge_base', $kb_id, $visibility, $shared_teams);
        if ($visibility === 'team') {
            $pdo->prepare("UPDATE knowledge_base SET owner_team = ? WHERE id = ?")->execute([$user_team, $kb_id]);
        }

        // Log update to audit trail
        $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
        logItemAction($pdo, 'knowledge_base', $kb_id, 'EDITED', $current_user_id, $userName, [
            'old_visibility' => $existing['visibility'] ?? 'public',
            'new_visibility' => $visibility,
        ]);

        $_SESSION['kb_success'] =
            'Knowledge note updated successfully.';

        redirect_kb($kb_id);
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'delete_kb') {

        $kb_id =
            (int) ($_POST['kb_id'] ?? 0);

        $stmt = $pdo->prepare("
            SELECT *
            FROM knowledge_base
            WHERE id = ?
            LIMIT 1
        ");

        $stmt->execute([$kb_id]);

        $kb =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$kb) {

            $_SESSION['kb_error'] =
                'Knowledge note not found.';

            redirect_kb();
        }


        if (!can_delete_kb(
            $kb,
            $current_user_id,
            $is_admin
        )) {

            http_response_code(403);

            exit(
                'You do not have permission to delete this knowledge note.'
            );
        }


        /*
        |--------------------------------------------------------------------------
        | Delete attachment files
        |--------------------------------------------------------------------------
        */

        $stmt = $pdo->prepare("
            SELECT file_path
            FROM knowledge_base_attachments
            WHERE kb_id = ?
        ");

        $stmt->execute([$kb_id]);

        foreach (
            $stmt->fetchAll(PDO::FETCH_ASSOC)
            as $attachment
        ) {

            $file =
                __DIR__ . '/' .
                ltrim(
                    $attachment['file_path'],
                    '/\\'
                );

            if (is_file($file)) {
                @unlink($file);
            }
        }


        // Log deletion to audit trail BEFORE removing the record
        $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
        logItemAction($pdo, 'knowledge_base', $kb_id, 'DELETED', $current_user_id, $userName, ['title' => $kb['title'] ?? '']);

        $pdo->prepare("
            DELETE FROM knowledge_base_attachments
            WHERE kb_id = ?
        ")->execute([$kb_id]);


        $pdo->prepare("
            DELETE FROM knowledge_base_revisions
            WHERE kb_id = ?
        ")->execute([$kb_id]);


        $pdo->prepare("
            DELETE FROM knowledge_base
            WHERE id = ?
        ")->execute([$kb_id]);


        $_SESSION['kb_success'] =
            'Knowledge note deleted successfully.';

        redirect_kb();
    }


    /*
    |--------------------------------------------------------------------------
    | DELETE ATTACHMENT
    |--------------------------------------------------------------------------
    */

    if ($post_action === 'delete_attachment') {

        $attachment_id =
            (int) ($_POST['attachment_id'] ?? 0);


        $stmt = $pdo->prepare("
            SELECT
                a.*,
                k.created_by
            FROM knowledge_base_attachments a
            INNER JOIN knowledge_base k
                ON k.id = a.kb_id
            WHERE a.id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $attachment_id
        ]);

        $attachment =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$attachment) {

            $_SESSION['kb_error'] =
                'Attachment not found.';

            redirect_kb();
        }


        if (
            !$is_admin &&
            (int) $attachment['created_by']
                !== $current_user_id
        ) {

            http_response_code(403);

            exit('Permission denied.');
        }


        $file =
            __DIR__ . '/' .
            ltrim(
                $attachment['file_path'],
                '/\\'
            );


        if (is_file($file)) {
            @unlink($file);
        }


        $stmt = $pdo->prepare("
            DELETE FROM knowledge_base_attachments
            WHERE id = ?
        ");

        $stmt->execute([
            $attachment_id
        ]);


        $_SESSION['kb_success'] =
            'Attachment removed.';

        redirect_kb(
            $attachment['kb_id']
        );
    }


    /*
    |--------------------------------------------------------------------------
    | IMAGE UPLOAD
    |--------------------------------------------------------------------------
    */

    if (
        isset($_POST['upload_image'])
    ) {

        header(
            'Content-Type: application/json'
        );


        $kb_id =
            (int) ($_POST['kb_id'] ?? 0);


        if ($kb_id > 0) {

            $stmt = $pdo->prepare("
                SELECT *
                FROM knowledge_base
                WHERE id = ?
                LIMIT 1
            ");

            $stmt->execute([
                $kb_id
            ]);

            $kb =
                $stmt->fetch(PDO::FETCH_ASSOC);


            if (
                !$kb ||
                !can_edit_kb(
                    $kb,
                    $current_user_id,
                    $is_admin
                )
            ) {

                echo json_encode([
                    'success' => false,
                    'message' =>
                        'Permission denied.'
                ]);

                exit;
            }
        }


        if (
            !isset($_FILES['image']) ||
            $_FILES['image']['error']
                !== UPLOAD_ERR_OK
        ) {

            echo json_encode([
                'success' => false,
                'message' =>
                    'Image upload failed.'
            ]);

            exit;
        }


        $file =
            $_FILES['image'];


        if (
            $file['size'] >
            5 * 1024 * 1024
        ) {

            echo json_encode([
                'success' => false,
                'message' =>
                    'Maximum image size is 5 MB.'
            ]);

            exit;
        }


        $allowed = [
            'image/png' => 'png',
            'image/jpeg' => 'jpg',
            'image/gif' => 'gif',
            'image/webp' => 'webp'
        ];


        $mime =
            mime_content_type(
                $file['tmp_name']
            );


        if (!isset($allowed[$mime])) {

            echo json_encode([
                'success' => false,
                'message' =>
                    'Unsupported image format.'
            ]);

            exit;
        }


        if (!is_dir($upload_dir_fs)) {
            mkdir(
                $upload_dir_fs,
                0755,
                true
            );
        }


        $stored_name =
            bin2hex(
                random_bytes(16)
            ) . '.' .
            $allowed[$mime];


        $destination =
            $upload_dir_fs .
            '/' .
            $stored_name;


        if (
            !move_uploaded_file(
                $file['tmp_name'],
                $destination
            )
        ) {

            echo json_encode([
                'success' => false,
                'message' =>
                    'Unable to save image.'
            ]);

            exit;
        }


        $relative_path =
            'uploads/knowledge/' .
            $stored_name;


        /*
        |--------------------------------------------------------------------------
        | Existing KB
        |--------------------------------------------------------------------------
        */

        if ($kb_id > 0) {

            $stmt = $pdo->prepare("
                INSERT INTO knowledge_base_attachments (
                    kb_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size,
                    uploaded_by
                )
                VALUES (?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([
                $kb_id,
                $file['name'],
                $stored_name,
                $relative_path,
                $mime,
                $file['size'],
                $current_user_id
            ]);


            $attachment_id =
                (int) $pdo->lastInsertId();


            $image_url =
                'knowledge.php?action=file&id=' .
                $attachment_id;

        } else {

            /*
            |--------------------------------------------------------------------------
            | New KB
            |
            | Image path is temporary until KB is saved.
            |--------------------------------------------------------------------------
            */

            $image_url =
                $relative_path;
        }


        echo json_encode([
            'success' => true,
            'url' => $image_url
        ]);

        exit;
    }
}


/*
|--------------------------------------------------------------------------
| SECURE FILE DELIVERY
|--------------------------------------------------------------------------
*/

if ($action === 'file') {

    $attachment_id =
        (int) ($_GET['id'] ?? 0);


    $stmt = $pdo->prepare("
        SELECT
            a.*,
            k.created_by,
            k.visibility
        FROM knowledge_base_attachments a
        INNER JOIN knowledge_base k
            ON k.id = a.kb_id
        WHERE a.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $attachment_id
    ]);

    $attachment =
        $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$attachment) {

        http_response_code(404);

        exit('File not found.');
    }


    if (!can_view_kb(
        $attachment,
        $current_user_id,
        $is_admin
    )) {

        http_response_code(403);

        exit('Access denied.');
    }


    $file =
        __DIR__ . '/' .
        ltrim(
            $attachment['file_path'],
            '/\\'
        );


    if (!is_file($file)) {

        http_response_code(404);

        exit('File not found.');
    }


    $mime =
        $attachment['mime_type']
        ?: 'application/octet-stream';


    header(
        'Content-Type: ' . $mime
    );

    header(
        'Content-Length: ' .
        filesize($file)
    );

    header(
        'X-Content-Type-Options: nosniff'
    );


    if (
        strpos($mime, 'image/') === 0
    ) {

        header(
            'Content-Disposition: inline; filename="' .
            basename(
                $attachment['original_name']
            ) .
            '"'
        );

    } else {

        header(
            'Content-Disposition: attachment; filename="' .
            basename(
                $attachment['original_name']
            ) .
            '"'
        );
    }


    readfile($file);

    exit;
}


/*
|--------------------------------------------------------------------------
| LOAD KB
|--------------------------------------------------------------------------
*/

$kb_id =
    (int) ($_GET['id'] ?? 0);

$kb = null;


if ($kb_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            k.*,
            u.first_name,
            u.last_name,
            u.email,
            u.team
        FROM knowledge_base k
        LEFT JOIN users u
            ON u.id = k.created_by
        WHERE k.id = ?
        LIMIT 1
    ");

    $stmt->execute([
        $kb_id
    ]);

    $kb =
        $stmt->fetch(PDO::FETCH_ASSOC);


    if (!$kb) {

        $_SESSION['kb_error'] =
            'Knowledge note not found.';

        redirect_kb();
    }


    if (!can_view_kb(
        $kb,
        $current_user_id,
        $is_admin
    )) {

        http_response_code(403);

        exit(
            'You do not have permission to view this knowledge note.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| FORM / VIEW
|--------------------------------------------------------------------------
*/

$is_form =
    in_array(
        $action,
        ['create', 'edit'],
        true
    );

$is_view =
    $action === 'view';


if (
    $action === 'edit' &&
    $kb
) {

    if (!can_edit_kb(
        $kb,
        $current_user_id,
        $is_admin
    )) {

        http_response_code(403);

        exit(
            'You do not have permission to edit this knowledge note.'
        );
    }
}


/*
|--------------------------------------------------------------------------
| Attachments
|--------------------------------------------------------------------------
*/

$attachments = [];


if ($kb_id > 0) {

    $stmt = $pdo->prepare("
        SELECT
            a.*,
            u.first_name,
            u.last_name
        FROM knowledge_base_attachments a
        LEFT JOIN users u
            ON u.id = a.uploaded_by
        WHERE a.kb_id = ?
        ORDER BY a.created_at DESC
    ");

    $stmt->execute([
        $kb_id
    ]);

    $attachments =
        $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*
|--------------------------------------------------------------------------
| Statistics
|--------------------------------------------------------------------------
*/

$stmt = $pdo->query("
    SELECT
        visibility,
        COUNT(*) AS total
    FROM knowledge_base
    GROUP BY visibility
");

$visibility_counts = [];

foreach (
    $stmt->fetchAll(PDO::FETCH_ASSOC)
    as $row
) {

    $visibility_counts[
        $row['visibility']
    ] = (int) $row['total'];
}


$total_kb =
    array_sum($visibility_counts);

$public_count =
    $visibility_counts['public'] ?? 0;

$private_count =
    ($visibility_counts['team'] ?? 0) + ($visibility_counts['teams'] ?? 0);


/*
|--------------------------------------------------------------------------
| Page
|--------------------------------------------------------------------------
*/

$page_title =
    'Knowledge Base';


require_once 'includes/header.php';

require_once 'includes/sidebar.php';

?>

<link
    rel="stylesheet"
    href="assets/css/knowledge.css"
>


<div class="content knowledge-content">

<?php if ($success_msg): ?>

    <div class="kb-alert success">
        <?= h($success_msg) ?>
    </div>

<?php endif; ?>


<?php if ($error_msg): ?>

    <div class="kb-alert error">
        <?= h($error_msg) ?>
    </div>

<?php endif; ?>


<?php

/*
|--------------------------------------------------------------------------
| CREATE / EDIT
|--------------------------------------------------------------------------
*/

if ($is_form):

    $editing =
        $action === 'edit';

    $form_title =
        $editing
            ? 'Edit Knowledge Note'
            : 'Create Knowledge Note';


    $form_kb_number =
        $kb['kb_number']
        ?? generate_kb_number($pdo);


    $form_title_value =
        $kb['title'] ?? '';


    $form_category =
        $kb['category'] ?? '';


    $form_description =
        $kb['description'] ?? '';


    $form_content =
        $kb['content_html'] ?? '';


    $form_visibility =
        $kb['visibility'] ?? 'public';

    // Visibility & Sharing
    $form_shared_teams = [];
    if ($kb && ($kb['visibility'] ?? '') === 'teams') {
        $form_shared_teams = getSharedTeams($pdo, 'knowledge_base', (int)$kb['id']);
    }

?>

<div class="kb-page-header">

    <div>

        <h1>
            <?= h($form_title) ?>
        </h1>

        <p>
            Capture infrastructure knowledge, troubleshooting notes,
            commands and useful technical information.
        </p>

    </div>

    <a
        href="knowledge.php"
        class="kb-secondary-btn"
    >
        Back to Knowledge Base
    </a>

</div>


<form
    method="POST"
    action="knowledge.php"
    enctype="multipart/form-data"
    id="knowledgeForm"
>

    <input
        type="hidden"
        name="csrf_token"
        value="<?= h($csrf_token) ?>"
    >

    <input
        type="hidden"
        name="form_action"
        value="save_kb"
    >

    <input
        type="hidden"
        name="kb_id"
        value="<?= (int) ($kb['id'] ?? 0) ?>"
    >

    <input
        type="hidden"
        name="shared_teams"
        id="shared_teams"
        value="<?= h(implode(',', $form_shared_teams ?? [])) ?>"
    >


    <!-- BASIC INFORMATION -->

    <div class="kb-form-panel">

        <div class="kb-section-title">

            <div>
                <h2>Knowledge Information</h2>

                <span>
                    Basic information and visibility
                </span>
            </div>

        </div>


        <div class="kb-form-grid">


            <div class="kb-field">

                <label>
                    KB Number
                </label>

                <input
                    type="text"
                    value="<?= h($form_kb_number) ?>"
                    readonly
                >

            </div>


            <div class="kb-field">

                <label>
                    Version
                </label>

                <input
                    type="text"
                    value="<?= h($kb['version'] ?? '1.0') ?>"
                    readonly
                >

            </div>


            <div class="kb-field full">

                <label>
                    Title <span>*</span>
                </label>

                <input
                    type="text"
                    name="title"
                    required
                    value="<?= h($form_title_value) ?>"
                    placeholder="Example: Useful Linux troubleshooting commands"
                >

            </div>


            <div class="kb-field">

                <label>
                    Category <span>*</span>
                </label>

                <select
                    name="category"
                    required
                >

                    <option value="">
                        Select Category
                    </option>

                    <?php foreach (
                        $categories
                        as $category
                    ): ?>

                        <option
                            value="<?= h($category) ?>"
                            <?= $form_category === $category
                                ? 'selected'
                                : '' ?>
                        >
                            <?= h($category) ?>
                        </option>

                    <?php endforeach; ?>

                </select>

            </div>


            <div class="kb-field full">

                <fieldset class="kb-visibility-fieldset" style="border: 1px solid var(--border-color); padding: 16px; border-radius: 8px;">
                    <legend style="font-weight: 600; color: var(--text-secondary);">Access Level <span style="color: #ef4444;">*</span></legend>

                    <div style="margin-bottom: 16px;">
                        <label class="kb-vis-option">
                            <input type="radio" name="visibility" value="public"
                                <?= ($form_visibility ?? 'public') === 'public' ? 'checked' : '' ?>
                                onchange="updateVisibilityFields()">
                            <span class="kb-vis-label">Public</span>
                            <span class="kb-vis-desc">(Visible to all users with KB access)</span>
                        </label>

                        <label class="kb-vis-option">
                            <input type="radio" name="visibility" value="team"
                                <?= ($form_visibility ?? 'public') === 'team' ? 'checked' : '' ?>
                                onchange="updateVisibilityFields()">
                            <span class="kb-vis-label">My Team Only</span>
                            <span class="kb-vis-desc">(Visible only to your team members)</span>
                        </label>

                        <label class="kb-vis-option" style="margin-bottom: 0;">
                            <input type="radio" name="visibility" value="teams"
                                <?= ($form_visibility ?? 'public') === 'teams' ? 'checked' : '' ?>
                                onchange="updateVisibilityFields()">
                            <span class="kb-vis-label">Specific Teams</span>
                            <span class="kb-vis-desc">(Visible to selected teams only)</span>
                        </label>
                    </div>

                    <div id="teams-selector" style="display: none; margin-top: 12px; padding-top: 12px; border-top: 1px solid var(--border-color);">
                        <label class="kb-vis-label" style="display: block; margin-bottom: 8px;">Select Teams:</label>
                        <div id="teams-checkboxes" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 8px;">
                            <!-- Populated by JS -->
                        </div>
                    </div>
                </fieldset>

            </div>

            <style>
                /* .kb-field input, .kb-field select, .kb-field textarea { width: 100%; }
                   (see assets/css/knowledge.css) stretches radio/checkbox inputs to fill
                   the row, which breaks this fieldset's layout entirely -- and
                   .kb-field label span { color: #c62828 } (meant for a required-field
                   asterisk) paints every span in these labels red. Both scoped back out
                   here rather than patching every element with inline overrides,
                   since the team checkboxes below are also generated by JS. */
                .kb-visibility-fieldset input[type="radio"],
                .kb-visibility-fieldset input[type="checkbox"] {
                    width: 16px;
                    height: 16px;
                    flex-shrink: 0;
                }
                .kb-vis-option {
                    display: flex;
                    align-items: center;
                    gap: 8px;
                    cursor: pointer;
                    margin-bottom: 12px;
                }
                .kb-vis-label {
                    font-weight: 600;
                    color: var(--text-primary);
                }
                .kb-vis-desc {
                    font-size: 0.85em;
                    color: var(--text-secondary);
                }
                #teams-checkboxes label {
                    display: flex;
                    align-items: center;
                    gap: 6px;
                    cursor: pointer;
                    color: var(--text-secondary);
                    font-weight: 400;
                }
            </style>


            <div class="kb-field full">

                <label>
                    Description
                </label>

                <textarea
                    name="description"
                    rows="4"
                    placeholder="Brief summary of this knowledge note."
                ><?= h($form_description) ?></textarea>

            </div>

        </div>

    </div>


    <!-- CONTENT -->

    <div class="kb-form-panel">

        <div class="kb-section-title">

            <div>

                <h2>
                    Knowledge Content
                </h2>

                <span>
                    Add documentation, screenshots, commands and links.
                </span>

            </div>

        </div>


        <div class="kb-editor-toolbar">

            <button
                type="button"
                onclick="formatEditor('bold')"
            >
                <b>B</b>
            </button>


            <button
                type="button"
                onclick="formatEditor('italic')"
            >
                <i>I</i>
            </button>


            <button
                type="button"
                onclick="formatEditor('underline')"
            >
                <u>U</u>
            </button>


            <button
                type="button"
                onclick="formatBlock('h2')"
            >
                H2
            </button>


            <button
                type="button"
                onclick="formatBlock('h3')"
            >
                H3
            </button>


            <button
                type="button"
                onclick="formatEditor('insertUnorderedList')"
            >
                • List
            </button>


            <button
                type="button"
                onclick="formatEditor('insertOrderedList')"
            >
                1. List
            </button>


            <button
                type="button"
                onclick="insertLink()"
            >
                Link
            </button>


            <button
                type="button"
                onclick="insertCodeBlock()"
            >
                &lt;/&gt; Command
            </button>


            <label class="kb-editor-upload">

                Image

                <input
                    type="file"
                    id="editorImage"
                    accept="image/png,image/jpeg,image/gif,image/webp"
                    hidden
                >

            </label>

        </div>


        <div
            id="knowledgeEditor"
            class="kb-rich-editor"
            contenteditable="true"
        ><?= $form_content ?></div>


        <textarea
            name="content_html"
            id="contentHtml"
            class="editor-hidden"
        ></textarea>

    </div>


    <!-- ATTACHMENTS -->

    <div class="kb-form-panel">

        <div class="kb-section-title">

            <div>

                <h2>
                    Attachments
                </h2>

                <span>
                    Add supporting files and documents.
                </span>

            </div>

        </div>


        <input
            type="file"
            name="attachments[]"
            multiple
            class="kb-attachment-input"
        >


        <?php if ($attachments): ?>

            <div class="kb-attachment-list">

                <?php foreach (
                    $attachments
                    as $attachment
                ): ?>

                    <div class="kb-attachment-item">

                        <div>

                            <strong>
                                <?= h(
                                    $attachment['original_name']
                                ) ?>
                            </strong>

                            <small>
                                <?= h(
                                    number_format(
                                        $attachment['file_size'] / 1024,
                                        1
                                    )
                                ) ?>
                                KB
                            </small>

                        </div>


                        <div>

                            <a
                                href="knowledge.php?action=file&id=<?= (int) $attachment['id'] ?>"
                                class="kb-download"
                            >
                                Download
                            </a>


                            <?php if (
                                can_edit_kb(
                                    $kb,
                                    $current_user_id,
                                    $is_admin
                                )
                            ): ?>

                                <button
                                    type="submit"
                                    name="form_action"
                                    value="delete_attachment"
                                    formaction="knowledge.php"
                                    formmethod="POST"
                                    onclick="return confirm('Remove this attachment?');"
                                    class="kb-remove"
                                >
                                    Remove
                                </button>

                                <input
                                    type="hidden"
                                    name="attachment_id"
                                    value="<?= (int) $attachment['id'] ?>"
                                >

                            <?php endif; ?>

                        </div>

                    </div>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>


    <!-- ACTIONS -->

    <div class="kb-form-actions">

        <a
            href="knowledge.php"
            class="kb-secondary-btn"
        >
            Cancel
        </a>


        <button
            type="submit"
            class="kb-primary-btn"
        >
            Save Knowledge
        </button>

    </div>

</form>


<?php

/*
|--------------------------------------------------------------------------
| VIEW
|--------------------------------------------------------------------------
*/

elseif ($is_view && $kb):

    $can_edit =
        can_edit_kb(
            $kb,
            $current_user_id,
            $is_admin
        );

?>

<div class="kb-document-header">

    <div>

        <div class="kb-document-number">
            <?= h($kb['kb_number']) ?>
        </div>

        <h1>
            <?= h($kb['title']) ?>
        </h1>

        <?php if (
            trim(
                (string) $kb['description']
            ) !== ''
        ): ?>

            <p>
                <?= h($kb['description']) ?>
            </p>

        <?php endif; ?>

    </div>


    <div class="kb-document-actions">

        <?php if ($can_edit): ?>

            <a
                href="knowledge.php?action=edit&id=<?= (int) $kb['id'] ?>"
                class="kb-secondary-btn"
            >
                Edit
            </a>

        <?php endif; ?>


        <?php if ($is_admin || $canExportKB): ?>
            <a
                href="knowledge-export.php?id=<?= (int) $kb['id'] ?>"
                class="kb-secondary-btn"
            >
                Export Word
            </a>
        <?php endif; ?>

        <?php if ($is_admin || (int)$kb['created_by'] === $current_user_id || $canAuditKB): ?>
            <button
                type="button"
                class="kb-secondary-btn"
                onclick="openAuditTrail(<?= (int) $kb['id'] ?>)"
            >
                Audit Trail
            </button>
        <?php endif; ?>

    </div>

</div>


<!-- META -->

<div class="kb-meta-grid">

    <div>

        <span>
            VISIBILITY
        </span>

        <strong
            class="kb-visibility <?= strtolower(
                $kb['visibility'] ?? 'public'
            ) ?>"
        >
            <?php
                $visLabels = ['public' => 'Public', 'team' => 'My Team', 'teams' => 'Specific Teams'];
                echo h($visLabels[$kb['visibility'] ?? 'public'] ?? ucfirst((string)$kb['visibility']));
            ?>
        </strong>

    </div>


    <div>

        <span>
            VERSION
        </span>

        <strong>
            <?= h($kb['version']) ?>
        </strong>

    </div>


    <div>

        <span>
            CATEGORY
        </span>

        <strong>
            <?= h($kb['category']) ?>
        </strong>

    </div>


    <div>

        <span>
            OWNER
        </span>

        <strong>
            <?= h(
                trim(
                    $kb['first_name'] .
                    ' ' .
                    $kb['last_name']
                )
            ) ?>
        </strong>

    </div>


    <div>

        <span>
            CREATED
        </span>

        <strong>
            <?= h(
                date(
                    'd M Y',
                    strtotime(
                        $kb['created_at']
                    )
                )
            ) ?>
        </strong>

    </div>


    <div>

        <span>
            UPDATED
        </span>

        <strong>
            <?= h(
                date(
                    'd M Y H:i',
                    strtotime(
                        $kb['updated_at']
                    )
                )
            ) ?>
        </strong>

    </div>

</div>


<!-- DOCUMENT -->

<div class="kb-document">

    <section>

        <div class="kb-rich-content">

            <?php if (
                trim(
                    (string) $kb['content_html']
                ) !== ''
            ): ?>

                <?= $kb['content_html'] ?>

            <?php else: ?>

                <p class="muted">
                    No content has been added.
                </p>

            <?php endif; ?>

        </div>

    </section>


    <!-- ATTACHMENTS -->

    <section>

        <h2>
            Attachments
        </h2>


        <?php if ($attachments): ?>

            <div class="kb-view-attachments">

                <?php foreach (
                    $attachments
                    as $attachment
                ): ?>

                    <a
                        href="knowledge.php?action=file&id=<?= (int) $attachment['id'] ?>"
                        class="kb-view-attachment"
                    >

                        <span class="kb-attachment-icon">
                            📎
                        </span>

                        <span>

                            <strong>
                                <?= h(
                                    $attachment['original_name']
                                ) ?>
                            </strong>

                            <small>
                                <?= h(
                                    number_format(
                                        $attachment['file_size'] / 1024,
                                        1
                                    )
                                ) ?>
                                KB
                            </small>

                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php else: ?>

            <p class="muted">
                No attachments.
            </p>

        <?php endif; ?>

    </section>


    <!-- COMMENTS -->

    <section id="comments-section">

        <h2>Comments (<span id="comment-count"><?= getCommentCount($pdo, 'knowledge_base', (int)$kb['id']) ?></span>)</h2>

        <?php if ($is_admin || hasRolePermission($pdo, $role, 'knowledge_base', 'can_edit')): ?>
            <form id="commentForm" style="margin-bottom: 20px;" onsubmit="submitComment(event, <?= (int)$kb['id'] ?>)">
                <textarea
                    id="comment_text"
                    class="form-control"
                    rows="3"
                    placeholder="Add a comment..."
                    style="width: 100%; border: 1px solid var(--border-color); border-radius: 8px; padding: 10px; font-family: inherit; margin-bottom: 8px;"
                    required
                ></textarea>
                <button type="submit" class="kb-primary-btn">Post Comment</button>
            </form>
        <?php endif; ?>

        <div id="comments-list">
            <?= formatCommentsList(getComments($pdo, 'knowledge_base', (int)$kb['id'])) ?>
        </div>

    </section>

</div>


<!-- AUDIT TRAIL MODAL -->
<div id="auditTrailModal" style="display:none; position:fixed; inset:0; background:rgba(15,23,42,.45); z-index:5000; align-items:center; justify-content:center; padding:20px;">
    <div style="background:var(--bg-content); border-radius:16px; padding:26px; width:100%; max-width:700px; max-height:80vh; overflow-y:auto; box-shadow:0 20px 60px rgba(15,23,42,.25);">
        <div style="display:flex; align-items:center; justify-content:space-between; margin-bottom:16px;">
            <h3 style="margin:0;">Audit Trail</h3>
            <button type="button" onclick="closeAuditTrail()" style="border:none; background:var(--hover-bg); width:30px; height:30px; border-radius:8px; cursor:pointer;">&times;</button>
        </div>
        <div id="auditTrailContent">Loading...</div>
    </div>
</div>


<?php

/*
|--------------------------------------------------------------------------
| LIST
|--------------------------------------------------------------------------
*/

else:

    /*
    |--------------------------------------------------------------------------
    | List query: same visibility rule as before (own OR public OR team match
    | OR teams-junction match, unless admin), plus a keyword search, server-
    | side sort, and server-side pagination at the user's preferred page size.
    |--------------------------------------------------------------------------
    */

    function build_kb_filter(int $user_id, string $user_team, bool $is_admin, string $keyword): array
    {
        $where = [];
        $params = [];

        if (!$is_admin) {
            $where[] = "(
                k.created_by = ?
                OR k.visibility = 'public'
                OR (k.visibility = 'team' AND k.owner_team = ?)
                OR (k.visibility = 'teams' AND k.id IN (
                    SELECT kb_id FROM knowledge_base_teams WHERE team_name = ?
                ))
            )";
            array_push($params, $user_id, $user_team, $user_team);
        }

        if ($keyword !== '') {
            $where[] = "(k.kb_number LIKE ? OR k.title LIKE ? OR k.category LIKE ? OR k.visibility LIKE ?)";
            $w = "%$keyword%";
            array_push($params, $w, $w, $w, $w);
        }

        return [$where ? implode(' AND ', $where) : '1=1', $params];
    }

    function kb_sort_link(string $column, string $label, string $current_sort, string $current_order, array $baseParams): string
    {
        $nextOrder = ($current_sort === $column && $current_order === 'ASC') ? 'DESC' : 'ASC';
        $params = array_merge($baseParams, ['sort_by' => $column, 'sort_order' => $nextOrder]);
        $arrow = $current_sort === $column ? ($current_order === 'ASC' ? ' &#9650;' : ' &#9660;') : '';

        return '<a href="knowledge.php?' . htmlspecialchars(http_build_query($params), ENT_QUOTES, 'UTF-8')
            . '" style="color:inherit;text-decoration:none;">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . $arrow . '</a>';
    }

    $kb_sort_columns = [
        'kb_number'  => 'k.kb_number',
        'title'      => 'k.title',
        'category'   => 'k.category',
        'visibility' => 'k.visibility',
        'updated_at' => 'k.updated_at',
    ];

    $sort_by = $_GET['sort_by'] ?? 'updated_at';
    if (!array_key_exists($sort_by, $kb_sort_columns)) {
        $sort_by = 'updated_at';
    }
    $sort_order = (strtoupper($_GET['sort_order'] ?? 'DESC') === 'ASC') ? 'ASC' : 'DESC';

    $keyword = trim($_GET['keyword'] ?? '');

    [$list_where, $list_params] = build_kb_filter($current_user_id, $user_team, $is_admin, $keyword);

    $order_column = $kb_sort_columns[$sort_by];

    $count_stmt = $pdo->prepare("SELECT COUNT(*) FROM knowledge_base k WHERE $list_where");
    $count_stmt->execute($list_params);
    $filtered_total = (int) $count_stmt->fetchColumn();

    $page_size = resolveUserPageSize($pdo, $current_user_id);
    $current_page = max(1, (int) ($_GET['page'] ?? 1));
    $total_pages = max(1, (int) ceil($filtered_total / $page_size));
    if ($current_page > $total_pages) {
        $current_page = $total_pages;
    }
    $offset = ($current_page - 1) * $page_size;

    $stmt = $pdo->prepare("
        SELECT
            k.*,
            u.first_name,
            u.last_name
        FROM knowledge_base k
        LEFT JOIN users u
            ON u.id = k.created_by
        WHERE $list_where
        ORDER BY $order_column $sort_order
        LIMIT $page_size OFFSET $offset
    ");
    $stmt->execute($list_params);
    $knowledge_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Every filter/sort param that needs to survive pagination, sorting,
    // and page-size changes -- built once, reused everywhere below.
    $list_query_params = array_filter([
        'keyword'    => $keyword,
        'sort_by'    => $sort_by,
        'sort_order' => $sort_order,
    ], static fn($v) => $v !== '');

    $hidden_filter_fields = '';
    foreach ($list_query_params as $fk => $fv) {
        $hidden_filter_fields .= '<input type="hidden" name="' . h($fk) . '" value="' . h($fv) . '">';
    }

?>

<div class="kb-page-header">

    <div>

        <h1>
            Knowledge Base
        </h1>

        <p>
            Shared technical knowledge, troubleshooting notes,
            commands and infrastructure documentation.
        </p>

    </div>


    <a
        href="knowledge.php?action=create"
        class="kb-primary-btn"
    >
        + New Knowledge
    </a>

</div>


<!-- STATISTICS -->

<div class="kb-stats">

    <div class="kb-stat-card">

        <span>
            Total
        </span>

        <strong>
            <?= $total_kb ?>
        </strong>

    </div>


    <div class="kb-stat-card public">

        <span>
            Public
        </span>

        <strong>
            <?= $public_count ?>
        </strong>

    </div>


    <div class="kb-stat-card private">

        <span>
            Team-Scoped
        </span>

        <strong>
            <?= $private_count ?>
        </strong>

    </div>

</div>


<!-- LIBRARY -->

<div class="kb-panel">

    <div class="kb-panel-header">

        <div>

            <h2>
                Knowledge Library
            </h2>

            <span>
                Technical notes and shared knowledge
            </span>

        </div>


        <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;">

            <form method="GET" action="knowledge.php" style="display:flex;gap:8px;">
                <input type="hidden" name="sort_by" value="<?= h($sort_by) ?>">
                <input type="hidden" name="sort_order" value="<?= h($sort_order) ?>">
                <input
                    type="text"
                    name="keyword"
                    id="kbSearch"
                    class="kb-search"
                    placeholder="Search knowledge..."
                    value="<?= h($keyword) ?>"
                >
                <button type="submit" class="kb-secondary-btn">Search</button>
            </form>

            <?php if ($keyword !== ''): ?>
                <a href="knowledge.php" class="kb-secondary-btn">Clear</a>
            <?php endif; ?>

            <?= pageSizeSelectorHtml($page_size, $hidden_filter_fields) ?>

        </div>

    </div>


    <div class="kb-table-wrapper">

        <table class="kb-table">

            <thead>

                <tr>

                    <th><?= kb_sort_link('kb_number', 'KB', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= kb_sort_link('title', 'Title', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= kb_sort_link('category', 'Category', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th><?= kb_sort_link('visibility', 'Visibility', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th>
                        Owner
                    </th>

                    <th>
                        Version
                    </th>

                    <th><?= kb_sort_link('updated_at', 'Updated', $sort_by, $sort_order, $list_query_params) ?></th>

                    <th>
                        Actions
                    </th>

                </tr>

            </thead>


            <tbody>

<?php

/*
|--------------------------------------------------------------------------
| $knowledge_items was already fetched above (paginated, sorted, filtered
| by build_kb_filter() -- visibility is applied in SQL now).
|--------------------------------------------------------------------------
*/

?>


<?php if (!$knowledge_items): ?>

    <tr>

        <td
            colspan="8"
            class="kb-empty"
        >
            <?= $keyword !== '' ? 'No knowledge notes match your search.' : 'No knowledge notes available.' ?>
        </td>

    </tr>

<?php endif; ?>


<?php foreach (
    $knowledge_items
    as $row
): ?>

<?php

$owner =
    trim(
        $row['first_name'] .
        ' ' .
        $row['last_name']
    );


$can_edit =
    can_edit_kb(
        $row,
        $current_user_id,
        $is_admin
    );


$can_delete =
    can_delete_kb(
        $row,
        $current_user_id,
        $is_admin
    );

?>

<tr>

    <td>
        <strong>
            <?= h($row['kb_number']) ?>
        </strong>
    </td>


    <td>

        <a
            href="knowledge.php?action=view&id=<?= (int) $row['id'] ?>"
            class="kb-title"
        >
            <?= h($row['title']) ?>
        </a>

    </td>


    <td>
        <?= h($row['category']) ?>
    </td>


    <td>

        <span
            class="kb-visibility <?= strtolower(
                $row['visibility'] ?? 'public'
            ) ?>"
        >
            <?php
                $rowVisLabels = ['public' => 'Public', 'team' => 'My Team', 'teams' => 'Teams'];
                echo h($rowVisLabels[$row['visibility'] ?? 'public'] ?? ucfirst((string)$row['visibility']));
            ?>
        </span>

    </td>


    <td>
        <?= h($owner) ?>
    </td>


    <td>
        <?= h($row['version']) ?>
    </td>


    <td>

        <?= h(
            date(
                'd M Y',
                strtotime(
                    $row['updated_at']
                )
            )
        ) ?>

    </td>


    <td>

        <div class="kb-actions">

            <a
                href="knowledge.php?action=view&id=<?= (int) $row['id'] ?>"
            >
                View
            </a>


            <?php if ($can_edit): ?>

                <a
                    class="edit"
                    href="knowledge.php?action=edit&id=<?= (int) $row['id'] ?>"
                >
                    Edit
                </a>

            <?php endif; ?>


            <?php if ($can_delete): ?>

                <form
                    method="POST"
                    action="knowledge.php"
                    style="display:inline"
                    onsubmit="return confirm('Delete this knowledge note permanently?');"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= h($csrf_token) ?>"
                    >

                    <input
                        type="hidden"
                        name="form_action"
                        value="delete_kb"
                    >

                    <input
                        type="hidden"
                        name="kb_id"
                        value="<?= (int) $row['id'] ?>"
                    >

                    <button
                        type="submit"
                        class="delete"
                    >
                        Delete
                    </button>

                </form>

            <?php endif; ?>

        </div>

    </td>

</tr>

<?php endforeach; ?>

            </tbody>

        </table>

    </div>

    <?php if ($total_pages > 1): ?>
        <div class="pagination" style="display:flex;justify-content:center;gap:6px;margin-top:20px;flex-wrap:wrap;">
            <?php for ($p = 1; $p <= $total_pages; $p++): ?>
                <a
                    href="knowledge.php?<?= h(http_build_query(array_merge($list_query_params, ['page' => $p]))) ?>"
                    class="kb-secondary-btn"
                    style="<?= $p === $current_page ? 'background:#2563eb;color:#fff;border-color:#2563eb;' : '' ?>"
                >
                    <?= $p ?>
                </a>
            <?php endfor; ?>
        </div>
    <?php endif; ?>

    <div style="text-align:center;color:var(--text-muted);font-size:12.5px;margin-top:10px;">
        Showing <?= count($knowledge_items) ?> of <?= $filtered_total ?> article<?= $filtered_total === 1 ? '' : 's' ?>
    </div>

</div>

<?php endif; ?>

</div>


<script>

/*
|--------------------------------------------------------------------------
| Editor
|--------------------------------------------------------------------------
*/

function formatEditor(command) {

    document.execCommand(
        command,
        false,
        null
    );
}


function formatBlock(tag) {

    document.execCommand(
        'formatBlock',
        false,
        tag
    );
}


function insertLink() {

    const url =
        prompt('Enter URL:');

    if (!url) {
        return;
    }

    document.execCommand(
        'createLink',
        false,
        url
    );
}


function insertCodeBlock() {

    const selection =
        window.getSelection();

    const text =
        selection.toString();

    const code =
        document.createElement('pre');

    code.className =
        'kb-command';

    code.textContent =
        text || 'Enter command here';


    const range =
        selection.rangeCount
            ? selection.getRangeAt(0)
            : null;


    if (range) {

        range.deleteContents();

        range.insertNode(code);

    } else {

        document
            .getElementById(
                'knowledgeEditor'
            )
            ?.appendChild(code);
    }
}


/*
|--------------------------------------------------------------------------
| Visibility & Sharing Controls
|--------------------------------------------------------------------------
*/

function updateVisibilityFields() {
    const visibility = document.querySelector('input[name="visibility"]:checked')?.value || 'public';
    const teamsSelector = document.getElementById('teams-selector');

    if (visibility === 'teams') {
        teamsSelector.style.display = 'block';
        loadTeamsList();
    } else {
        teamsSelector.style.display = 'none';
        document.getElementById('shared_teams').value = '';
    }
}

function loadTeamsList() {
    fetch('kb-actions.php?action=get_all_teams')
        .then(r => r.json())
        .then(data => {
            if (!data.success) return;

            const container = document.getElementById('teams-checkboxes');
            const currentTeams = document.getElementById('shared_teams').value.split(',').filter(t => t);

            container.innerHTML = '';
            data.teams.forEach(team => {
                const label = document.createElement('label');
                label.style.cssText = 'display:flex; align-items:center; gap:6px; cursor:pointer;';

                const input = document.createElement('input');
                input.type = 'checkbox';
                input.value = team;
                input.checked = currentTeams.includes(team);
                input.onchange = () => updateSharedTeams();

                label.appendChild(input);
                label.appendChild(document.createTextNode(team));
                container.appendChild(label);
            });
        });
}

function updateSharedTeams() {
    const selected = Array.from(document.querySelectorAll('#teams-checkboxes input[type="checkbox"]:checked'))
        .map(cb => cb.value);
    document.getElementById('shared_teams').value = selected.join(',');
}

// Initialize visibility on page load
document.addEventListener('DOMContentLoaded', function() {
    updateVisibilityFields();
});


/*
|--------------------------------------------------------------------------
| Comments
|--------------------------------------------------------------------------
*/

function submitComment(event, kbId) {
    event.preventDefault();

    const text = document.getElementById('comment_text').value.trim();
    if (!text) return;

    const formData = new FormData();
    formData.append('action', 'add_comment');
    formData.append('kb_id', kbId);
    formData.append('comment_text', text);

    fetch('kb-actions.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                document.getElementById('comment_text').value = '';
                window.location.reload();
            } else {
                alert(data.error || 'Unable to post comment.');
            }
        })
        .catch(() => alert('Unable to post comment.'));
}

document.addEventListener('click', function (e) {
    const btn = e.target.closest('.delete-comment-btn');
    if (!btn) return;

    if (!confirm('Delete this comment?')) return;

    const formData = new FormData();
    formData.append('action', 'delete_comment');
    formData.append('comment_id', btn.dataset.commentId);

    fetch('kb-actions.php', { method: 'POST', body: formData })
        .then(r => r.json())
        .then(data => {
            if (data.success) {
                window.location.reload();
            } else {
                alert(data.error || 'Unable to delete comment.');
            }
        })
        .catch(() => alert('Unable to delete comment.'));
});


/*
|--------------------------------------------------------------------------
| Audit Trail Modal
|--------------------------------------------------------------------------
*/

function openAuditTrail(kbId) {
    const modal = document.getElementById('auditTrailModal');
    const content = document.getElementById('auditTrailContent');
    modal.style.display = 'flex';
    content.innerHTML = 'Loading...';

    fetch('kb-actions.php?action=get_audit_trail&kb_id=' + kbId)
        .then(r => r.json())
        .then(data => {
            if (!data.success) {
                content.innerHTML = '<p>' + (data.error || 'Unable to load audit trail.') + '</p>';
                return;
            }

            if (data.audit_trail.length === 0) {
                content.innerHTML = '<p style="color:var(--text-secondary);">No audit history recorded yet.</p>';
                return;
            }

            let html = '<table style="width:100%; border-collapse:collapse;">';
            html += '<thead><tr style="background:var(--hover-bg);"><th style="padding:8px; text-align:left;">Date/Time</th><th style="padding:8px; text-align:left;">Action</th><th style="padding:8px; text-align:left;">By</th></tr></thead><tbody>';

            data.audit_trail.forEach(entry => {
                html += '<tr style="border-top:1px solid var(--border-light);">';
                html += '<td style="padding:8px;">' + entry.action_date + '</td>';
                html += '<td style="padding:8px;"><span style="background:#e0f2fe; color:#0369a1; padding:2px 10px; border-radius:12px; font-size:0.85em;">' + entry.action + '</span></td>';
                html += '<td style="padding:8px;">' + entry.user_name + '</td>';
                html += '</tr>';
            });

            html += '</tbody></table>';
            content.innerHTML = html;
        })
        .catch(() => {
            content.innerHTML = '<p>Unable to load audit trail.</p>';
        });
}

function closeAuditTrail() {
    document.getElementById('auditTrailModal').style.display = 'none';
}


/*
|--------------------------------------------------------------------------
| Image Upload
|--------------------------------------------------------------------------
*/

const imageInput =
    document.getElementById(
        'editorImage'
    );


if (imageInput) {

    imageInput.addEventListener(
        'change',
        async function () {

            if (!this.files.length) {
                return;
            }


            const file =
                this.files[0];


            const formData =
                new FormData();


            formData.append(
                'upload_image',
                '1'
            );


            formData.append(
                'csrf_token',
                '<?= h($csrf_token) ?>'
            );


            formData.append(
                'kb_id',
                '<?= (int) ($kb['id'] ?? 0) ?>'
            );


            formData.append(
                'image',
                file
            );


            try {

                const response =
                    await fetch(
                        'knowledge.php',
                        {
                            method: 'POST',
                            body: formData
                        }
                    );


                const result =
                    await response.json();


                if (!result.success) {

                    alert(
                        result.message ||
                        'Image upload failed.'
                    );

                    return;
                }


                const editor =
                    document.getElementById(
                        'knowledgeEditor'
                    );


                const image =
                    document.createElement(
                        'img'
                    );


                image.src =
                    result.url;


                image.className =
                    'kb-inline-image';


                editor.focus();


                document.execCommand(
                    'insertHTML',
                    false,
                    image.outerHTML
                );


            } catch (error) {

                alert(
                    'Unable to upload image.'
                );
            }
        }
    );
}


/*
|--------------------------------------------------------------------------
| Copy Editor HTML
|--------------------------------------------------------------------------
*/

document
    .getElementById('knowledgeForm')
    ?.addEventListener(
        'submit',
        function () {

            const editor =
                document.getElementById(
                    'knowledgeEditor'
                );


            const content =
                document.getElementById(
                    'contentHtml'
                );


            if (editor && content) {

                content.value =
                    editor.innerHTML;
            }
        }
    );



</script>


<?php

require_once 'includes/footer.php';

?>

