<?php

session_start();
require 'config/db.php';
require_once 'includes/csv-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('decommission', 'can_view');
requirePermission('decommission', 'can_import');


$role = $_SESSION['role'] ?? 'User';

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');

// Check permissions
if ($role !== 'Admin' && $role !== 'Edit') {
    die("Permission denied");
}

$message = "";
$errors = [];
$imported = 0;
$skipped = 0;

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {

            // Header cells are normalised to column keys first: the raw
            // header was used verbatim, so a file from this module's own
            // export ("Hostname", "Support Level") never matched the
            // lowercase keys read below, and every row imported blank.
            $header = csvNormaliseHeader((array) fgetcsv($handle));

            while (($row = fgetcsv($handle)) !== false) {

                // A short row would make array_combine fail outright.
                $row = array_pad(array_slice($row, 0, count($header)), count($header), '');
                $data = array_combine($header, $row);

                // Extract required fields
                $hostname = trim($data['hostname'] ?? '');

                if (!$hostname) {
                    $skipped++;
                    continue;
                }

                // Check for duplicate
                $stmt = $pdo->prepare("SELECT id FROM decommission WHERE hostname = ?");
                $stmt->execute([$hostname]);

                if ($stmt->fetch()) {
                    $skipped++;
                    continue;
                }

                // Extract optional fields
                $server_state = trim($data['server_state'] ?? '');
                $support_level = trim($data['support_level'] ?? '');
                $project = trim($data['project'] ?? '');
                $application_name = trim($data['application_name'] ?? '');
                $ip_address = trim($data['ip_address'] ?? '');
                $additional_ips = trim($data['additional_ips'] ?? '');
                $decommission_start_date = trim($data['decommission_start_date'] ?? '');
                $decommission_end_date = trim($data['decommission_end_date'] ?? '');

                // Insert the record
                $stmt = $pdo->prepare("
                    INSERT INTO decommission
                    (hostname, server_state, support_level, project, application_name, ip_address, additional_ips, decommission_start_date, decommission_end_date, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                try {
                    $stmt->execute([
                        $hostname,
                        $server_state,
                        $support_level,
                        $project,
                        $application_name,
                        $ip_address,
                        $additional_ips,
                        !empty($decommission_start_date) ? $decommission_start_date : null,
                        !empty($decommission_end_date) ? $decommission_end_date : null,
                        $username
                    ]);

                    $new_id = $pdo->lastInsertId();

                    // Create default tasks
                    $default_tasks_stmt = $pdo->query("SELECT id, name FROM decommission_task_templates");
                    $default_tasks = $default_tasks_stmt->fetchAll(PDO::FETCH_ASSOC);

                    foreach ($default_tasks as $t) {
                        $t_stmt = $pdo->prepare("INSERT INTO decommission_tasks (decommission_id, task_name, status, req_no) VALUES (?, ?, 'Pending', '')");
                        $t_stmt->execute([$new_id, $t['name']]);
                    }

                    // Log to audit history
                    $h_stmt = $pdo->prepare("INSERT INTO decommission_history (decommission_id, action_type, performed_by, details) VALUES (?, 'CREATED', ?, ?)");
                    $h_stmt->execute([$new_id, $username, "Imported from CSV: $hostname"]);

                    $imported++;
                } catch (Exception $e) {
                    $skipped++;
                }
            }

            fclose($handle);
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Decommission CSV</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Decommission CSV</h2>

        <?php if ($imported > 0 || $skipped > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Imported</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped; ?></strong>
                </div>
            </div>
            <p class="text-center" style="margin-top: 20px;">
                <a href="decommission.php" class="btn btn-primary">Return to Decommission List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="decommission.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
