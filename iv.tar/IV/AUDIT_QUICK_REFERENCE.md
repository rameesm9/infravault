# Audit System - Quick Reference Guide

## For End Users

### Viewing Audit History

1. **In Reminders Module** (reminders.php)
   - Open the reminders page
   - Click the "⏱ History" button on any reminder row
   - View the audit trail in the modal popup

2. **In Sticky Notes** (reminders.php)
   - Open the sticky notes section
   - Click the "⏱ History" button on any note card
   - See who created/edited the note and when

3. **In Communications** (notification.php)
   - Open Team Notes & Handover Board
   - Click "⏱ History" button on any note
   - Track creation, edits, and status changes

4. **In My Data** (mydata.php)
   - Open My Data page
   - Click "⏱ History" button on any data item
   - See modification history

### What You'll See
- **Action**: What happened (CREATED, UPDATED, DELETED, STATUS_CHANGED)
- **Performed By**: Who did it (user name)
- **Date/Time**: When it happened
- **Details**: What was changed (context information)

### Permissions Note
- History buttons only appear if you have `can_audit` permission
- Admins always see history buttons
- If you can't see history buttons, ask your administrator to grant you audit permissions

## For Administrators

### Granting Audit Permissions

#### Via SQL (Direct Database Access)

```sql
-- Grant audit permission to a role
INSERT INTO permissions (role, page_key, can_audit) 
VALUES ('Manager', 'reminder', 1);

-- Grant for all modules to a specific role
INSERT INTO permissions (role, page_key, can_audit) VALUES ('Manager', 'reminder', 1);
INSERT INTO permissions (role, page_key, can_audit) VALUES ('Manager', 'sticky_note', 1);
INSERT INTO permissions (role, page_key, can_audit) VALUES ('Manager', 'communication', 1);
INSERT INTO permissions (role, page_key, can_audit) VALUES ('Manager', 'mydata', 1);

-- Check who has audit permissions
SELECT role, page_key FROM permissions WHERE can_audit = 1;
```

#### Module Keys
- `reminder` - Audit for reminders module
- `sticky_note` - Audit for sticky notes module
- `communication` - Audit for communications/notifications module
- `mydata` - Audit for my data module

### Viewing Audit Data Directly

```sql
-- View all reminder audit entries
SELECT * FROM reminder_audit ORDER BY action_date DESC;

-- View all sticky note audit entries
SELECT * FROM sticky_note_audit ORDER BY action_date DESC;

-- View all communication audit entries
SELECT * FROM communication_audit ORDER BY action_date DESC;

-- View all mydata audit entries
SELECT * FROM mydata_audit ORDER BY action_date DESC;

-- View audit entries for a specific record
SELECT * FROM reminder_audit WHERE reminder_id = 123 ORDER BY action_date DESC;

-- View audit entries by a specific user
SELECT * FROM reminder_audit WHERE user_name = 'John Smith' ORDER BY action_date DESC;

-- View all deletions
SELECT * FROM reminder_audit WHERE action = 'DELETED' ORDER BY action_date DESC;
```

### Cleanup & Maintenance

```sql
-- View audit log size
SELECT 
    'reminder_audit' as table_name, COUNT(*) as count FROM reminder_audit
UNION ALL
SELECT 'sticky_note_audit', COUNT(*) FROM sticky_note_audit
UNION ALL
SELECT 'communication_audit', COUNT(*) FROM communication_audit
UNION ALL
SELECT 'mydata_audit', COUNT(*) FROM mydata_audit;

-- Delete audit entries older than 1 year
DELETE FROM reminder_audit WHERE action_date < datetime('now', '-1 year');
DELETE FROM sticky_note_audit WHERE action_date < datetime('now', '-1 year');
DELETE FROM communication_audit WHERE action_date < datetime('now', '-1 year');
DELETE FROM mydata_audit WHERE action_date < datetime('now', '-1 year');

-- Optimize database
VACUUM;
```

## For Developers

### Adding Audit Logging to a New Module

1. **Create audit table in schema file** (config/schema/yourmodule.php)
```php
$pdo->exec("
    CREATE TABLE IF NOT EXISTS yourmodule_audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        yourmodule_id INTEGER NOT NULL,
        action TEXT NOT NULL,
        performed_by_id INTEGER,
        user_name TEXT NOT NULL,
        action_date DATETIME DEFAULT CURRENT_TIMESTAMP,
        details TEXT,
        FOREIGN KEY(yourmodule_id) REFERENCES your_module(id) ON DELETE CASCADE
    )
");
```

2. **Include audit helpers** in your PHP file
```php
require_once __DIR__ . '/includes/audit_helpers.php';
```

3. **Log actions** in POST handlers
```php
// In your create action
logYourmoduleAudit($pdo, $record_id, 'CREATED', $current_user_id, $current_name, "Details");

// In your update action
logYourmoduleAudit($pdo, $record_id, 'UPDATED', $current_user_id, $current_name, "Details");

// In your delete action
logYourmoduleAudit($pdo, $record_id, 'DELETED', $current_user_id, $current_name, "Details");
```

4. **Add fetch endpoint**
```php
if($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'get_audit_history'){
    header('Content-Type: application/json');
    
    $id = (int)($_POST['id'] ?? 0);
    if($id <= 0) {
        echo json_encode(['error' => 'Invalid request']);
        exit;
    }
    
    if(!canAudit($pdo, $current_user_id, $role, 'yourmodule')) {
        echo json_encode(['error' => 'No audit permission']);
        exit;
    }
    
    $history = getYourmoduleAuditHistory($pdo, $id);
    echo json_encode($history);
    exit;
}
```

5. **Add getYourmoduleAuditHistory() helper** in audit_helpers.php
```php
function getYourmoduleAuditHistory($pdo, $yourmodule_id) {
    try {
        $stmt = $pdo->prepare("
            SELECT id, action, performed_by_id, user_name, action_date, details
            FROM yourmodule_audit
            WHERE yourmodule_id = ?
            ORDER BY action_date DESC
        ");
        $stmt->execute([$yourmodule_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        return [];
    }
}
```

### Helper Functions Reference

```php
// Log functions
logReminderAudit($pdo, $id, $action, $user_id, $user_name, $details);
logStickyNoteAudit($pdo, $id, $action, $user_id, $user_name, $details);
logCommunicationAudit($pdo, $id, $action, $user_id, $user_name, $details);
logMydataAudit($pdo, $id, $action, $user_id, $user_name, $details);

// Get history functions
getReminderAuditHistory($pdo, $id);
getStickyNoteAuditHistory($pdo, $id);
getCommunicationAuditHistory($pdo, $id);
getMydataAuditHistory($pdo, $id);

// Permission check
canAudit($pdo, $user_id, $role, $module_key);

// Format for display
formatAuditEntry($entry);
```

### Action Types
- `CREATED` - Record created
- `UPDATED` - Record modified
- `DELETED` - Record deleted
- `STATUS_CHANGED` - Status/state changed
- Custom actions as needed (e.g., `PUBLISHED`, `ARCHIVED`, etc.)

## File Locations

```
d:\ubunut\IV\
├── includes/
│   └── audit_helpers.php          (All audit helper functions)
├── config/schema/
│   ├── reminders.php              (Reminder & sticky note audit tables)
│   ├── communications.php         (Communication audit table)
│   └── mydata.php                 (MyData audit table)
├── reminders.php                  (Reminders & sticky notes implementation)
├── notification.php               (Communications implementation)
├── mydata.php                     (MyData implementation)
└── AUDIT_IMPLEMENTATION.md        (Full technical documentation)
```

## Common Tasks

### Grant audit access to all managers
```sql
UPDATE permissions 
SET can_audit = 1 
WHERE role = 'Manager' 
AND page_key IN ('reminder', 'sticky_note', 'communication', 'mydata');
```

### Create audit report of deletions
```sql
SELECT 
    'Reminder' as type,
    action_date,
    user_name,
    details
FROM reminder_audit
WHERE action = 'DELETED'

UNION ALL

SELECT 'Communication', action_date, user_name, details
FROM communication_audit
WHERE action = 'DELETED'

ORDER BY action_date DESC;
```

### Track changes by a specific user
```sql
SELECT * FROM reminder_audit WHERE user_name = 'John Smith' ORDER BY action_date DESC
UNION ALL
SELECT * FROM sticky_note_audit WHERE user_name = 'John Smith' ORDER BY action_date DESC
UNION ALL
SELECT * FROM communication_audit WHERE user_name = 'John Smith' ORDER BY action_date DESC
UNION ALL
SELECT * FROM mydata_audit WHERE user_name = 'John Smith' ORDER BY action_date DESC
ORDER BY action_date DESC;
```

## Support & Troubleshooting

### History button not showing?
- Check user has `can_audit` permission for that module
- Admin role always has access
- Verify tables were created in database

### Can't access history via API?
- Verify permission check: `canAudit($pdo, $user_id, $role, 'module_key')`
- Admin users should always have access
- Check error message in JSON response

### Audit entries not being logged?
- Check PHP error logs
- Verify audit tables exist in database
- Confirm POST handlers include audit logging calls
- Audit logging is non-blocking, check if error_log shows any issues

## Module Compatibility

| Module | Status | History Button | API Endpoint | Notes |
|--------|--------|-----------------|--------------|-------|
| Reminders | Implemented | Yes | Yes | Full tracking |
| Sticky Notes | Implemented | Yes | Yes | Full tracking |
| Communications | Implemented | Via API | Yes | No UI button yet |
| My Data | Implemented | Via API | Yes | No UI button yet |

## Next Steps

1. Set permissions for your team members
2. Test audit trail by creating/editing records
3. Regularly review audit logs for compliance
4. Configure retention policy if needed
5. Consider exporting audit logs for external compliance reports
