<?php
/**
 * Org & Escalation Charts.
 *
 * A structure-first chart builder, deliberately not a second drawing
 * canvas. diagram_designer.php already draws: it drops a pile of shapes
 * on a page and leaves you to arrange them. What it cannot do is answer
 * "who is tier 2 for payments, and what is their number" -- because the
 * result is a picture, not data.
 *
 * Here the chart IS the data. You fill in a node list; the layout is
 * computed. That is what makes a chart exportable to CSV, searchable by
 * a person's name, and re-renderable when a name changes, and it is why
 * an escalation matrix and a RACI grid render as tables rather than as
 * boxes -- an SLA, a coverage window and a phone number do not fit in a
 * rectangle on a canvas.
 *
 * Four shapes, one storage model -- see config/schema/org_charts.php.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';

requireLogin();
requirePermission('org_charts', 'can_view');

$canEdit   = can('org_charts', 'can_edit');
$canDelete = can('org_charts', 'can_delete');
$canExport = can('org_charts', 'can_export');
$canAudit  = can('org_charts', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const OCH_MODULE = 'org_charts';

$ochTypes = [
    'hierarchy'  => 'Org Hierarchy',
    'escalation' => 'Escalation Matrix',
    'cycle'      => 'Cycle / Lifecycle',
    'raci'       => 'RACI Matrix',
];

$ochTypeIcons = [
    'hierarchy'  => '🏛',
    'escalation' => '🚨',
    'cycle'      => '🔄',
    'raci'       => '🧭',
];

$ochStatuses = ['Draft', 'Active', 'Under Review', 'Archived'];
$ochAccents  = ['slate', 'blue', 'green', 'amber', 'red', 'violet', 'teal'];

/** Chart columns, for the CSV export and the audit diff. */
$ochChartFields = [
    'title'          => 'Title',
    'chart_type'     => 'Type',
    'description'    => 'Description',
    'owner_team'     => 'Owner Team',
    'scope'          => 'Scope',
    'status'         => 'Status',
    'version'        => 'Version',
    'effective_date' => 'Effective Date',
    'review_date'    => 'Review Date',
];

/** Node columns. Keys match the data-f attributes in the builder. */
$ochNodeCols = [
    'label'          => 'label',
    'person'         => 'person_name',
    'title'          => 'job_title',
    'email'          => 'contact_email',
    'phone'          => 'contact_phone',
    'alt'            => 'contact_alt',
    'tier'           => 'tier_level',
    'respond'        => 'respond_within',
    'resolve'        => 'resolve_within',
    'coverage'       => 'coverage',
    'duration'       => 'duration',
    'notes'          => 'node_notes',
    'accent'         => 'accent',
];


/* =========================================================
   TEMPLATES

   Starting content, not saved presets: choosing one fills the
   builder in and everything is then editable. They exist because a
   blank escalation matrix does not tell you that a tier needs a
   response target AND a coverage window -- a filled-in one does.

   Held in PHP and handed to the browser as JSON so there is one
   copy, not a server list and a client list that drift.
========================================================= */

function ochTemplates(): array
{
    /** Fills in the fields a template did not set, so every node is the same shape. */
    $n = function (array $node): array {
        return array_merge([
            'label' => '', 'person' => '', 'title' => '', 'email' => '', 'phone' => '',
            'alt' => '', 'tier' => '', 'respond' => '', 'resolve' => '', 'coverage' => '',
            'duration' => '', 'notes' => '', 'accent' => 'slate', 'parent' => null,
        ], $node);
    };

    $t = [];

    /* ---------------- HIERARCHY ---------------- */

    $t['blank_hierarchy'] = [
        'name' => 'Blank hierarchy',
        'type' => 'hierarchy',
        'icon' => '⬚',
        'desc' => 'One root node. Build the reporting tree from scratch.',
        'meta' => ['title' => '', 'description' => '', 'scope' => ''],
        'nodes' => [
            $n(['label' => 'Head of Department', 'accent' => 'blue']),
        ],
    ];

    $t['infra_team'] = [
        'name' => 'Infrastructure team',
        'type' => 'hierarchy',
        'icon' => '🏛',
        'desc' => 'Head of Infrastructure over the systems, network, database and security lines.',
        'meta' => [
            'title'       => 'Infrastructure Team Structure',
            'description' => 'Reporting lines for the infrastructure function.',
            'scope'       => 'Infrastructure',
        ],
        'nodes' => [
            $n(['label' => 'Head of Infrastructure', 'title' => 'Department Head', 'accent' => 'blue',  'parent' => null]),
            $n(['label' => 'Systems Lead',          'title' => 'Team Lead',       'accent' => 'teal',   'parent' => 0]),
            $n(['label' => 'Network Lead',          'title' => 'Team Lead',       'accent' => 'teal',   'parent' => 0]),
            $n(['label' => 'Database Lead',         'title' => 'Team Lead',       'accent' => 'teal',   'parent' => 0]),
            $n(['label' => 'Security Lead',         'title' => 'Team Lead',       'accent' => 'teal',   'parent' => 0]),
            $n(['label' => 'Linux Engineer',        'title' => 'Engineer',        'accent' => 'slate',  'parent' => 1]),
            $n(['label' => 'Storage Engineer',      'title' => 'Engineer',        'accent' => 'slate',  'parent' => 1]),
            $n(['label' => 'Network Engineer',      'title' => 'Engineer',        'accent' => 'slate',  'parent' => 2]),
            $n(['label' => 'DBA',                   'title' => 'Engineer',        'accent' => 'slate',  'parent' => 3]),
        ],
    ];

    $t['it_org'] = [
        'name' => 'IT organisation',
        'type' => 'hierarchy',
        'icon' => '🏢',
        'desc' => 'CIO down through the IT directorate and its service managers.',
        'meta' => [
            'title'       => 'IT Organisation Chart',
            'description' => 'Directorate-level reporting structure.',
            'scope'       => 'Information Technology',
        ],
        'nodes' => [
            $n(['label' => 'CIO',                   'title' => 'Chief Information Officer', 'accent' => 'violet', 'parent' => null]),
            $n(['label' => 'IT Operations Director','title' => 'Director',                  'accent' => 'blue',   'parent' => 0]),
            $n(['label' => 'Applications Director', 'title' => 'Director',                  'accent' => 'blue',   'parent' => 0]),
            $n(['label' => 'Information Security',  'title' => 'CISO',                      'accent' => 'red',    'parent' => 0]),
            $n(['label' => 'Infrastructure Manager','title' => 'Manager',                   'accent' => 'teal',   'parent' => 1]),
            $n(['label' => 'Service Desk Manager',  'title' => 'Manager',                   'accent' => 'teal',   'parent' => 1]),
            $n(['label' => 'Application Support',   'title' => 'Manager',                   'accent' => 'teal',   'parent' => 2]),
        ],
    ];

    /* ---------------- ESCALATION ---------------- */

    $t['blank_escalation'] = [
        'name' => 'Blank escalation matrix',
        'type' => 'escalation',
        'icon' => '⬚',
        'desc' => 'One empty tier with the SLA and coverage fields ready.',
        'meta' => ['title' => '', 'description' => '', 'scope' => ''],
        'nodes' => [
            $n(['label' => 'Tier 1', 'tier' => 1, 'accent' => 'green']),
        ],
    ];

    $t['it_support'] = [
        'name' => 'IT support escalation',
        'type' => 'escalation',
        'icon' => '🚨',
        'desc' => 'Four tiers from the service desk out to the vendor, with response and resolution targets.',
        'meta' => [
            'title'       => 'IT Support Escalation Matrix',
            'description' => 'Standard escalation path for incidents raised against IT services.',
            'scope'       => 'All IT services',
        ],
        'nodes' => [
            $n([
                'label' => 'Tier 1 — Service Desk', 'tier' => 1, 'accent' => 'green',
                'title' => 'First line', 'coverage' => '24x7',
                'respond' => '15 minutes', 'resolve' => '1 hour',
                'notes' => 'Logs, triages and resolves known issues from the knowledge base.',
            ]),
            $n([
                'label' => 'Tier 2 — Platform Engineering', 'tier' => 2, 'accent' => 'amber',
                'title' => 'Second line', 'coverage' => 'Mon–Fri 08:00–18:00, on-call outside',
                'respond' => '30 minutes', 'resolve' => '4 hours',
                'notes' => 'Owns the platform. Engaged when Tier 1 cannot resolve or the service is degraded.',
            ]),
            $n([
                'label' => 'Tier 3 — Subject Matter Expert', 'tier' => 3, 'accent' => 'red',
                'title' => 'Third line', 'coverage' => 'On-call',
                'respond' => '1 hour', 'resolve' => '1 business day',
                'notes' => 'Product or application specialist. Engaged for root-cause work.',
            ]),
            $n([
                'label' => 'Tier 4 — Vendor / Management', 'tier' => 4, 'accent' => 'violet',
                'title' => 'External', 'coverage' => 'Per support contract',
                'respond' => 'Per contract', 'resolve' => 'Per contract',
                'notes' => 'Raise a vendor case and notify the service owner. Record the case number on the ticket.',
            ]),
        ],
    ];

    $t['major_incident'] = [
        'name' => 'Major incident escalation',
        'type' => 'escalation',
        'icon' => '🔥',
        'desc' => 'Command chain for a P1: incident commander through to executive notification.',
        'meta' => [
            'title'       => 'Major Incident Escalation',
            'description' => 'Who is engaged, in what order, during a declared P1 major incident.',
            'scope'       => 'Severity 1 incidents',
        ],
        'nodes' => [
            $n([
                'label' => 'Incident Commander', 'tier' => 1, 'accent' => 'red',
                'title' => 'Runs the bridge', 'coverage' => '24x7',
                'respond' => 'Immediate', 'resolve' => 'Until stood down',
                'notes' => 'Declares the major incident, opens the bridge and owns all communication.',
            ]),
            $n([
                'label' => 'Technical Lead', 'tier' => 2, 'accent' => 'amber',
                'title' => 'Owns the fix', 'coverage' => '24x7 on-call',
                'respond' => '10 minutes', 'resolve' => 'Until service restored',
                'notes' => 'Directs the technical response and reports status to the commander.',
            ]),
            $n([
                'label' => 'Duty Manager', 'tier' => 3, 'accent' => 'blue',
                'title' => 'Business decisions', 'coverage' => '24x7 on-call',
                'respond' => '30 minutes', 'resolve' => 'N/A',
                'notes' => 'Authorises workarounds with business impact and approves customer messaging.',
            ]),
            $n([
                'label' => 'Service Owner / Executive', 'tier' => 4, 'accent' => 'violet',
                'title' => 'Notified', 'coverage' => 'Business hours, paged if P1',
                'respond' => '1 hour', 'resolve' => 'N/A',
                'notes' => 'Notified at declaration and at every status update. Owns the post-incident review.',
            ]),
        ],
    ];

    /* ---------------- CYCLE ---------------- */

    $t['blank_cycle'] = [
        'name' => 'Blank cycle',
        'type' => 'cycle',
        'icon' => '⬚',
        'desc' => 'Three empty stages arranged in a ring.',
        'meta' => ['title' => '', 'description' => '', 'scope' => ''],
        'nodes' => [
            $n(['label' => 'Stage 1', 'accent' => 'blue']),
            $n(['label' => 'Stage 2', 'accent' => 'teal']),
            $n(['label' => 'Stage 3', 'accent' => 'green']),
        ],
    ];

    $t['pdca'] = [
        'name' => 'PDCA improvement cycle',
        'type' => 'cycle',
        'icon' => '🔄',
        'desc' => 'Plan, Do, Check, Act — the continual-improvement loop.',
        'meta' => [
            'title'       => 'Continual Improvement Cycle (PDCA)',
            'description' => 'The improvement loop applied to service management processes.',
            'scope'       => 'Service management',
        ],
        'nodes' => [
            $n(['label' => 'Plan',  'accent' => 'blue',   'duration' => '2 weeks', 'notes' => 'Define the objective, the measure and the change to be trialled.']),
            $n(['label' => 'Do',    'accent' => 'teal',   'duration' => '4 weeks', 'notes' => 'Run the change on a limited scope.']),
            $n(['label' => 'Check', 'accent' => 'amber',  'duration' => '1 week',  'notes' => 'Compare the measured result against the objective.']),
            $n(['label' => 'Act',   'accent' => 'green',  'duration' => '1 week',  'notes' => 'Adopt, adjust or abandon — then start the next turn.']),
        ],
    ];

    $t['incident_lifecycle'] = [
        'name' => 'Incident lifecycle',
        'type' => 'cycle',
        'icon' => '⚡',
        'desc' => 'Detect, triage, contain, resolve, review — and back to detection.',
        'meta' => [
            'title'       => 'Incident Lifecycle',
            'description' => 'The stages every incident passes through, ending in a review that feeds detection.',
            'scope'       => 'Incident management',
        ],
        'nodes' => [
            $n(['label' => 'Detect',   'accent' => 'blue',   'duration' => 'Continuous', 'notes' => 'Monitoring alert, user report or health check.']),
            $n(['label' => 'Triage',   'accent' => 'teal',   'duration' => '15 min',     'notes' => 'Classify severity, assign an owner, notify.']),
            $n(['label' => 'Contain',  'accent' => 'amber',  'duration' => 'Varies',     'notes' => 'Limit the impact — failover, isolate, apply the workaround.']),
            $n(['label' => 'Resolve',  'accent' => 'green',  'duration' => 'Varies',     'notes' => 'Restore the service and confirm with the reporter.']),
            $n(['label' => 'Review',   'accent' => 'violet', 'duration' => '5 days',     'notes' => 'Post-incident review; actions feed back into detection.']),
        ],
    ];

    $t['patch_cycle'] = [
        'name' => 'Patch management cycle',
        'type' => 'cycle',
        'icon' => '🩹',
        'desc' => 'The quarterly patch loop from assessment through to reporting.',
        'meta' => [
            'title'       => 'Quarterly Patch Management Cycle',
            'description' => 'The repeating cycle each quarterly patch campaign follows.',
            'scope'       => 'Server estate',
        ],
        'nodes' => [
            $n(['label' => 'Assess',   'accent' => 'blue',   'duration' => 'Week 1',   'notes' => 'Review advisories and the vulnerability report; scope the affected hosts.']),
            $n(['label' => 'Test',     'accent' => 'teal',   'duration' => 'Week 2–3', 'notes' => 'Apply to non-production and validate the applications.']),
            $n(['label' => 'Approve',  'accent' => 'amber',  'duration' => 'Week 4',   'notes' => 'Raise the change and obtain CAB approval.']),
            $n(['label' => 'Deploy',   'accent' => 'red',    'duration' => 'Window',   'notes' => 'Patch production during the agreed window.']),
            $n(['label' => 'Verify',   'accent' => 'green',  'duration' => '48 hours', 'notes' => 'Confirm kernel and package levels; watch for regressions.']),
            $n(['label' => 'Report',   'accent' => 'violet', 'duration' => 'Week 6',   'notes' => 'Publish compliance figures and carry exceptions into the next cycle.']),
        ],
    ];

    /* ---------------- RACI ---------------- */

    $t['blank_raci'] = [
        'name' => 'Blank RACI matrix',
        'type' => 'raci',
        'icon' => '⬚',
        'desc' => 'Three roles and three activities, ready to fill in.',
        'meta' => ['title' => '', 'description' => '', 'scope' => ''],
        'nodes' => [
            $n(['label' => 'Role 1', 'accent' => 'blue']),
            $n(['label' => 'Role 2', 'accent' => 'teal']),
            $n(['label' => 'Role 3', 'accent' => 'amber']),
        ],
        'raci' => [
            ['activity' => 'Activity 1', 'notes' => '', 'cells' => ['A', 'R', 'I']],
            ['activity' => 'Activity 2', 'notes' => '', 'cells' => ['R', 'C', 'I']],
            ['activity' => 'Activity 3', 'notes' => '', 'cells' => ['C', 'A', 'R']],
        ],
    ];

    $t['change_raci'] = [
        'name' => 'Change management RACI',
        'type' => 'raci',
        'icon' => '🧭',
        'desc' => 'Who is responsible, accountable, consulted and informed at each step of a change.',
        'meta' => [
            'title'       => 'Change Management RACI',
            'description' => 'Responsibility assignment across the change lifecycle.',
            'scope'       => 'Change management',
        ],
        'nodes' => [
            $n(['label' => 'Requester',      'accent' => 'slate',  'title' => 'Raises the change']),
            $n(['label' => 'Technical Owner','accent' => 'blue',   'title' => 'Builds and implements']),
            $n(['label' => 'Change Manager', 'accent' => 'amber',  'title' => 'Runs the process']),
            $n(['label' => 'CAB',            'accent' => 'violet', 'title' => 'Approval body']),
            $n(['label' => 'Service Owner',  'accent' => 'green',  'title' => 'Accountable for the service']),
        ],
        'raci' => [
            ['activity' => 'Raise change request',   'notes' => '',                          'cells' => ['R', 'C', 'A', 'I', 'I']],
            ['activity' => 'Impact & risk assessment','notes' => 'Includes rollback plan',   'cells' => ['C', 'R', 'A', 'C', 'I']],
            ['activity' => 'Approve change',          'notes' => 'Standard changes pre-approved', 'cells' => ['I', 'I', 'R', 'A', 'C']],
            ['activity' => 'Schedule window',         'notes' => '',                          'cells' => ['C', 'C', 'R', 'I', 'A']],
            ['activity' => 'Implement',               'notes' => '',                          'cells' => ['I', 'R', 'A', 'I', 'I']],
            ['activity' => 'Verify & close',          'notes' => '',                          'cells' => ['C', 'R', 'A', 'I', 'C']],
            ['activity' => 'Post-implementation review','notes' => 'Failed changes only',     'cells' => ['I', 'C', 'R', 'C', 'A']],
        ],
    ];

    return $t;
}


/* =========================================================
   RENDERING HELPERS
========================================================= */

/**
 * Trims a string to fit a fixed-width SVG label.
 *
 * SVG <text> does not wrap, so anything longer than the box has to be cut
 * here rather than by the renderer. The full value is repeated in a
 * <title> so hovering still shows it, and the detail table below every
 * chart always shows it in full.
 */
function ochClip(?string $s, int $len): string
{
    $s = trim((string) $s);
    if ($s === '' || strlen($s) <= $len) {
        return $s;
    }
    return rtrim(substr($s, 0, $len - 1)) . '…';
}

function ochAccentClass(?string $a): string
{
    $a = strtolower(trim((string) $a));
    return in_array($a, ['slate', 'blue', 'green', 'amber', 'red', 'violet', 'teal'], true) ? $a : 'slate';
}

/**
 * Arranges the nodes into a tree and assigns every node a position.
 *
 * A plain two-pass layout: leaves are laid out left to right in the order
 * they were entered, and each parent is centred over its children. That is
 * enough for a reporting chart and, unlike a general graph layout, it never
 * reorders the rows the user typed.
 *
 * Nodes whose parent chain loops back on themselves are promoted to roots
 * rather than dropped -- a chart that silently loses a person is worse than
 * one that shows them detached, and the parent picker cannot rule this out
 * once rows have been reordered.
 */
function ochLayoutTree(array $nodes): array
{
    $W = 200; $H = 74; $HGAP = 24; $VGAP = 76; $PAD = 18;

    $byId = [];
    foreach ($nodes as $n) {
        $byId[(int) $n['id']] = $n;
    }

    $children = [];
    $roots    = [];

    foreach ($nodes as $n) {
        $id  = (int) $n['id'];
        $pid = (int) ($n['parent_id'] ?? 0);

        $attach = $pid > 0 && $pid !== $id && isset($byId[$pid]);

        if ($attach) {
            // Walk up from the parent; meeting this node again means the
            // chain loops, so it cannot be attached.
            $seen = [$id => true];
            $cur  = $pid;

            while ($cur > 0 && isset($byId[$cur])) {
                if (isset($seen[$cur])) { $attach = false; break; }
                $seen[$cur] = true;
                $cur = (int) ($byId[$cur]['parent_id'] ?? 0);
            }
        }

        if ($attach) {
            $children[$pid][] = $id;
        } else {
            $roots[] = $id;
        }
    }

    $xOf = []; $yOf = []; $maxDepth = 0;
    $cursor = 0.0;

    $place = function (int $id, int $d) use (&$place, &$children, &$xOf, &$yOf, &$cursor, &$maxDepth, $W, $H, $HGAP, $VGAP) {
        $yOf[$id] = $d * ($H + $VGAP);
        $maxDepth = max($maxDepth, $d);

        $kids = $children[$id] ?? [];

        if (!$kids) {
            $xOf[$id] = $cursor;
            $cursor += $W + $HGAP;
            return;
        }

        $first = null; $last = null;
        foreach ($kids as $k) {
            $place($k, $d + 1);
            if ($first === null) { $first = $xOf[$k]; }
            $last = $xOf[$k];
        }

        $xOf[$id] = ($first + $last) / 2;
    };

    foreach ($roots as $i => $r) {
        if ($i > 0) { $cursor += $HGAP; }   // breathing room between separate trees
        $place($r, 0);
    }

    return [
        'x' => $xOf, 'y' => $yOf, 'children' => $children, 'byId' => $byId,
        'w' => $W, 'h' => $H, 'vgap' => $VGAP, 'pad' => $PAD,
        'width'  => max(1, (int) ceil($cursor - $HGAP)) + $PAD * 2,
        'height' => $maxDepth * ($H + $VGAP) + $H + $PAD * 2,
    ];
}

function ochRenderHierarchy(array $nodes): string
{
    if (!$nodes) {
        return '<p class="och-empty">No positions defined yet.</p>';
    }

    $L = ochLayoutTree($nodes);
    $W = $L['w']; $H = $L['h']; $PAD = $L['pad'];

    $svg = '<svg class="och-svg" viewBox="0 0 ' . $L['width'] . ' ' . $L['height'] . '"'
         . ' width="' . $L['width'] . '" height="' . $L['height'] . '" role="img"'
         . ' aria-label="Organisational hierarchy chart">';

    // Connectors first, so boxes always sit on top of the lines.
    foreach ($L['children'] as $pid => $kids) {
        $px = $L['x'][$pid] + $PAD + $W / 2;
        $py = $L['y'][$pid] + $PAD + $H;

        foreach ($kids as $cid) {
            $cx = $L['x'][$cid] + $PAD + $W / 2;
            $cy = $L['y'][$cid] + $PAD;
            $mid = $py + $L['vgap'] / 2;

            $svg .= '<path class="och-link" d="M' . round($px, 1) . ',' . round($py, 1)
                  . ' V' . round($mid, 1)
                  . ' H' . round($cx, 1)
                  . ' V' . round($cy, 1) . '"/>';
        }
    }

    foreach ($nodes as $n) {
        $id = (int) $n['id'];
        if (!isset($L['x'][$id])) { continue; }

        $x = $L['x'][$id] + $PAD;
        $y = $L['y'][$id] + $PAD;

        $person = trim((string) $n['person_name']);
        $role   = trim((string) $n['job_title']);
        $meta   = trim((string) $n['contact_email']) ?: trim((string) $n['contact_phone']);

        $svg .= '<g class="acc-' . ochAccentClass($n['accent']) . '">'
              . '<title>' . plat_h(trim($n['label'] . ($person !== '' ? ' — ' . $person : ''))) . '</title>'
              . '<rect class="och-box" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . $W . '" height="' . $H . '"/>'
              . '<text class="och-t-title" x="' . ($x + 13) . '" y="' . ($y + 25) . '">' . plat_h(ochClip($n['label'], 24)) . '</text>';

        if ($person !== '') {
            $svg .= '<text class="och-t-sub" x="' . ($x + 13) . '" y="' . ($y + 44) . '">' . plat_h(ochClip($person, 27)) . '</text>';
        }

        $foot = $role !== '' ? $role : $meta;
        if ($foot !== '') {
            $svg .= '<text class="och-t-meta" x="' . ($x + 13) . '" y="' . ($y + ($person !== '' ? 61 : 46)) . '">'
                  . plat_h(ochClip($foot, 30)) . '</text>';
        }

        $svg .= '</g>';
    }

    return $svg . '</svg>';
}

function ochRenderCycle(array $nodes, string $centreLabel): string
{
    $count = count($nodes);

    if ($count === 0) {
        return '<p class="och-empty">No stages defined yet.</p>';
    }

    $cw = 178; $ch = 80;

    // Radius large enough that the cards do not overlap: each needs roughly
    // its own width plus a gap of arc to itself.
    $R = max(178, (int) ceil($count * 34));

    $half = $R + (int) ($cw / 2) + 30;
    $size = $half * 2;
    $cx = $half; $cy = $half;

    // Arrow arcs run inside the ring of cards, between the hub and the cards.
    $arcR = max(52, $R - (int) ($ch / 2) - 24);
    $hubR = max(38, $arcR - 30);

    $svg = '<svg class="och-svg" viewBox="0 0 ' . $size . ' ' . $size . '"'
         . ' width="' . $size . '" height="' . $size . '" role="img"'
         . ' aria-label="Cycle diagram with ' . $count . ' stages">'
         . '<defs><marker id="ochArrowHead" viewBox="0 0 10 10" refX="9" refY="5"'
         . ' markerWidth="6" markerHeight="6" orient="auto-start-reverse">'
         . '<path class="och-arrowhead" d="M0,0 L10,5 L0,10 z"/></marker></defs>';

    // Hub.
    $svg .= '<circle class="och-hub" cx="' . $cx . '" cy="' . $cy . '" r="' . $hubR . '"/>';

    $hubText = ochClip($centreLabel, 20);
    if ($hubText !== '') {
        $svg .= '<text class="och-hub-text" x="' . $cx . '" y="' . ($cy + 5) . '" text-anchor="middle">'
              . plat_h($hubText) . '</text>';
    }

    $angle = function (int $i) use ($count): float {
        return -M_PI / 2 + (2 * M_PI * $i / $count);
    };

    // Arrows between consecutive stages, drawn before the cards.
    if ($count > 1) {
        $pad = min(0.42, (2 * M_PI / $count) * 0.30);

        for ($i = 0; $i < $count; $i++) {
            $a1 = $angle($i) + $pad;
            $a2 = $angle(($i + 1) % $count) - $pad;

            $x1 = $cx + $arcR * cos($a1); $y1 = $cy + $arcR * sin($a1);
            $x2 = $cx + $arcR * cos($a2); $y2 = $cy + $arcR * sin($a2);

            $svg .= '<path class="och-arrow" marker-end="url(#ochArrowHead)"'
                  . ' d="M' . round($x1, 1) . ',' . round($y1, 1)
                  . ' A' . $arcR . ',' . $arcR . ' 0 0 1 ' . round($x2, 1) . ',' . round($y2, 1) . '"/>';
        }
    }

    foreach (array_values($nodes) as $i => $n) {
        $a = $angle($i);
        $x = $cx + $R * cos($a) - $cw / 2;
        $y = $cy + $R * sin($a) - $ch / 2;

        $owner = trim((string) $n['person_name']);
        $dur   = trim((string) $n['duration']);

        $foot = $owner;
        if ($dur !== '') {
            $foot = $foot !== '' ? $foot . ' · ' . $dur : $dur;
        }

        $svg .= '<g class="acc-' . ochAccentClass($n['accent']) . '">'
              . '<title>' . plat_h(trim($n['label'] . ($n['node_notes'] ? ' — ' . $n['node_notes'] : ''))) . '</title>'
              . '<rect class="och-box" x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . $cw . '" height="' . $ch . '"/>'
              . '<text class="och-step-no" x="' . round($x + 14, 1) . '" y="' . round($y + 24, 1) . '">STEP '
              . str_pad((string) ($i + 1), 2, '0', STR_PAD_LEFT) . '</text>'
              . '<text class="och-t-title" x="' . round($x + 14, 1) . '" y="' . round($y + 47, 1) . '">'
              . plat_h(ochClip($n['label'], 21)) . '</text>';

        if ($foot !== '') {
            $svg .= '<text class="och-t-meta" x="' . round($x + 14, 1) . '" y="' . round($y + 66, 1) . '">'
                  . plat_h(ochClip($foot, 27)) . '</text>';
        }

        $svg .= '</g>';
    }

    return $svg . '</svg>';
}

function ochRenderEscalation(array $nodes): string
{
    if (!$nodes) {
        return '<p class="och-empty">No tiers defined yet.</p>';
    }

    $html = '<div class="och-ladder">';

    foreach (array_values($nodes) as $i => $n) {
        if ($i > 0) {
            $html .= '<div class="och-drop">Not resolved / not reachable → escalate</div>';
        }

        $tier   = trim((string) $n['tier_level']) !== '' ? (int) $n['tier_level'] : ($i + 1);
        $person = trim((string) $n['person_name']);
        $email  = trim((string) $n['contact_email']);
        $phone  = trim((string) $n['contact_phone']);
        $alt    = trim((string) $n['contact_alt']);

        $html .= '<div class="och-tier acc-' . ochAccentClass($n['accent']) . '">'
               . '<div class="och-tier-badge"><small>Tier</small><b>' . $tier . '</b></div>'
               . '<div>'
               . '<div class="och-tier-name">' . plat_h($n['label']) . '</div>';

        if (trim((string) $n['job_title']) !== '') {
            $html .= '<div class="och-tier-role">' . plat_h($n['job_title']) . '</div>';
        }

        if (trim((string) $n['node_notes']) !== '') {
            $html .= '<div class="och-tier-note">' . plat_h($n['node_notes']) . '</div>';
        }

        $html .= '</div><div class="och-contact">';

        if ($person !== '') {
            $html .= '<span class="och-who">' . plat_h($person) . '</span>';
        }
        if ($email !== '') {
            $html .= '<a href="mailto:' . plat_h($email) . '">' . plat_h($email) . '</a>';
        }
        if ($phone !== '') {
            $html .= '<a href="tel:' . plat_h(preg_replace('/[^0-9+]/', '', $phone)) . '">' . plat_h($phone) . '</a>';
        }
        if ($alt !== '') {
            $html .= '<span>' . plat_h($alt) . '</span>';
        }
        if ($person === '' && $email === '' && $phone === '' && $alt === '') {
            $html .= '<span style="color:var(--text-muted);">No contact recorded</span>';
        }

        $html .= '</div><div class="och-sla">';

        foreach ([
            'Respond'  => trim((string) $n['respond_within']),
            'Resolve'  => trim((string) $n['resolve_within']),
            'Coverage' => trim((string) $n['coverage']),
        ] as $lbl => $val) {
            if ($val === '') { continue; }
            $html .= '<span class="och-sla-chip">' . $lbl . ' <b>' . plat_h($val) . '</b></span>';
        }

        $html .= '</div></div>';
    }

    return $html . '</div>';
}

function ochRenderRaci(array $roles, array $rows): string
{
    if (!$roles) {
        return '<p class="och-empty">No roles defined yet — add the columns first, then the activities.</p>';
    }
    if (!$rows) {
        return '<p class="och-empty">No activities defined yet.</p>';
    }

    $html = '';

    // An activity with no Accountable is the failure mode a RACI exists to
    // prevent, so it is called out rather than left for the reader to spot.
    $missing = [];
    foreach ($rows as $r) {
        $letters = json_decode((string) $r['assignments'], true);
        if (!is_array($letters) || !in_array('A', $letters, true)) {
            $missing[] = $r['activity'];
        }
    }

    if ($missing) {
        $html .= '<p class="och-warn"><strong>No accountable role</strong> for: '
               . plat_h(implode(', ', array_slice($missing, 0, 6)))
               . (count($missing) > 6 ? ' and ' . (count($missing) - 6) . ' more' : '')
               . '. Every activity should have exactly one A.</p>';
    }

    $html .= '<div class="plat-table-wrap"><table class="och-raci"><thead><tr>'
           . '<th class="och-raci-act">Activity</th>';

    foreach ($roles as $role) {
        $html .= '<th>' . plat_h($role['label']);
        if (trim((string) $role['person_name']) !== '') {
            $html .= '<small>' . plat_h($role['person_name']) . '</small>';
        } elseif (trim((string) $role['job_title']) !== '') {
            $html .= '<small>' . plat_h($role['job_title']) . '</small>';
        }
        $html .= '</th>';
    }

    $html .= '</tr></thead><tbody>';

    foreach ($rows as $r) {
        $letters = json_decode((string) $r['assignments'], true);
        if (!is_array($letters)) { $letters = []; }

        $html .= '<tr><td class="och-raci-act">' . plat_h($r['activity']);
        if (trim((string) $r['notes']) !== '') {
            $html .= '<span>' . plat_h($r['notes']) . '</span>';
        }
        $html .= '</td>';

        foreach (array_keys($roles) as $i) {
            $l = strtoupper(trim((string) ($letters[$i] ?? '')));
            $l = in_array($l, ['R', 'A', 'C', 'I'], true) ? $l : '';

            $html .= '<td><span class="och-letter ' . ($l === '' ? 'l-none' : 'l-' . strtolower($l)) . '">'
                   . ($l === '' ? '·' : $l) . '</span></td>';
        }

        $html .= '</tr>';
    }

    $html .= '</tbody></table></div>'
           . '<div class="och-legend">'
           . '<span><i class="och-letter l-r">R</i> Responsible — does the work</span>'
           . '<span><i class="och-letter l-a">A</i> Accountable — owns the outcome</span>'
           . '<span><i class="och-letter l-c">C</i> Consulted — asked beforehand</span>'
           . '<span><i class="och-letter l-i">I</i> Informed — told afterwards</span>'
           . '</div>';

    return $html;
}

function ochRenderChart(array $chart, array $nodes, array $raciRows): string
{
    switch ((string) $chart['chart_type']) {
        case 'escalation': return ochRenderEscalation($nodes);
        case 'cycle':      return ochRenderCycle($nodes, (string) $chart['title']);
        case 'raci':       return ochRenderRaci(array_values($nodes), $raciRows);
        default:           return ochRenderHierarchy($nodes);
    }
}

/**
 * Nodes for a chart, already in the order every renderer wants them.
 *
 * Escalation is the one exception: its rows are ordered by the tier number
 * the user typed rather than by row position, so a tier inserted later
 * still lands in the right place on the ladder.
 */
function ochLoadNodes(PDO $pdo, int $chartId, string $type): array
{
    $order = $type === 'escalation'
        ? 'ORDER BY (tier_level IS NULL), tier_level, node_order, id'
        : 'ORDER BY node_order, id';

    $s = $pdo->prepare("SELECT * FROM org_chart_nodes WHERE chart_id = ? $order");
    $s->execute([$chartId]);

    return $s->fetchAll(PDO::FETCH_ASSOC);
}

function ochLoadRaci(PDO $pdo, int $chartId): array
{
    $s = $pdo->prepare("SELECT * FROM org_chart_raci_rows WHERE chart_id = ? ORDER BY row_order, id");
    $s->execute([$chartId]);

    return $s->fetchAll(PDO::FETCH_ASSOC);
}


/* =========================================================
   AJAX
========================================================= */

if (($_GET['ajax'] ?? '') === 'history') {
    requirePermission('org_charts', 'can_audit');
    echo platformHistoryHtml($pdo, OCH_MODULE, (int) ($_GET['id'] ?? 0));
    exit;
}

if (($_GET['ajax'] ?? '') === 'chart') {
    header('Content-Type: application/json; charset=utf-8');

    $id = (int) ($_GET['id'] ?? 0);

    $s = $pdo->prepare("SELECT * FROM org_charts WHERE id = ?");
    $s->execute([$id]);
    $chart = $s->fetch(PDO::FETCH_ASSOC);

    if (!$chart) {
        echo json_encode(['error' => 'Chart not found.']);
        exit;
    }

    $nodes = ochLoadNodes($pdo, $id, (string) $chart['chart_type']);

    // The builder addresses parents by row position, not by database id --
    // it rewrites every node on save, so ids are not stable across one.
    $ordinalOf = [];
    foreach (array_values($nodes) as $i => $n) {
        $ordinalOf[(int) $n['id']] = $i;
    }

    $out = [];
    foreach ($nodes as $n) {
        $pid = (int) ($n['parent_id'] ?? 0);

        $out[] = [
            'label'    => (string) $n['label'],
            'person'   => (string) $n['person_name'],
            'title'    => (string) $n['job_title'],
            'email'    => (string) $n['contact_email'],
            'phone'    => (string) $n['contact_phone'],
            'alt'      => (string) $n['contact_alt'],
            'tier'     => (string) $n['tier_level'],
            'respond'  => (string) $n['respond_within'],
            'resolve'  => (string) $n['resolve_within'],
            'coverage' => (string) $n['coverage'],
            'duration' => (string) $n['duration'],
            'notes'    => (string) $n['node_notes'],
            'accent'   => ochAccentClass($n['accent']),
            'parent'   => array_key_exists($pid, $ordinalOf) ? $ordinalOf[$pid] : null,
        ];
    }

    $raci = [];
    foreach (ochLoadRaci($pdo, $id) as $r) {
        $cells = json_decode((string) $r['assignments'], true);

        $raci[] = [
            'activity' => (string) $r['activity'],
            'notes'    => (string) $r['notes'],
            'cells'    => is_array($cells) ? array_values($cells) : [],
        ];
    }

    echo json_encode(['chart' => $chart, 'nodes' => $out, 'raci' => $raci]);
    exit;
}


/* =========================================================
   CSV EXPORT

   Two shapes, because two questions get asked. Without an id it is the
   register -- every chart, when it was last reviewed. With an id it is
   that chart's contents, one row per node, which is what someone wants
   when they are pasting an escalation matrix into a runbook.
========================================================= */

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('org_charts', 'can_export');

    $id = (int) ($_GET['id'] ?? 0);

    header('Content-Type: text/csv; charset=utf-8');

    if ($id > 0) {
        $s = $pdo->prepare("SELECT * FROM org_charts WHERE id = ?");
        $s->execute([$id]);
        $chart = $s->fetch(PDO::FETCH_ASSOC);

        if (!$chart) { exit('Chart not found.'); }

        $slug = preg_replace('/[^A-Za-z0-9]+/', '_', (string) $chart['title']) ?: 'chart';
        header('Content-Disposition: attachment; filename=' . trim($slug, '_') . '_' . date('Y-m-d') . '.csv');

        $out   = fopen('php://output', 'w');
        $nodes = ochLoadNodes($pdo, $id, (string) $chart['chart_type']);

        fputcsv($out, ['Chart', $chart['title']]);
        fputcsv($out, ['Type', $ochTypes[$chart['chart_type']] ?? $chart['chart_type']]);
        fputcsv($out, ['Version', $chart['version'], 'Status', $chart['status']]);
        fputcsv($out, ['Effective', $chart['effective_date'], 'Review by', $chart['review_date']]);
        fputcsv($out, []);

        if ($chart['chart_type'] === 'raci') {
            $roles  = array_values($nodes);
            $header = ['Activity'];

            foreach ($roles as $r) {
                $header[] = $r['label'] . (trim((string) $r['person_name']) !== '' ? ' (' . $r['person_name'] . ')' : '');
            }
            $header[] = 'Notes';
            fputcsv($out, $header);

            foreach (ochLoadRaci($pdo, $id) as $row) {
                $letters = json_decode((string) $row['assignments'], true);
                if (!is_array($letters)) { $letters = []; }

                $line = [$row['activity']];
                foreach (array_keys($roles) as $i) {
                    $line[] = strtoupper(trim((string) ($letters[$i] ?? '')));
                }
                $line[] = $row['notes'];

                fputcsv($out, $line);
            }
        } else {
            fputcsv($out, [
                '#', 'Label', 'Reports to', 'Person', 'Job Title', 'Email', 'Phone',
                'Alternate Contact', 'Tier', 'Respond Within', 'Resolve Within',
                'Coverage', 'Duration', 'Notes',
            ]);

            $labelOf = [];
            foreach ($nodes as $n) { $labelOf[(int) $n['id']] = (string) $n['label']; }

            foreach (array_values($nodes) as $i => $n) {
                fputcsv($out, [
                    $i + 1,
                    $n['label'],
                    $labelOf[(int) ($n['parent_id'] ?? 0)] ?? '',
                    $n['person_name'], $n['job_title'], $n['contact_email'], $n['contact_phone'],
                    $n['contact_alt'], $n['tier_level'], $n['respond_within'], $n['resolve_within'],
                    $n['coverage'], $n['duration'], $n['node_notes'],
                ]);
            }
        }

        fclose($out);
        exit;
    }

    header('Content-Disposition: attachment; filename=org_charts_' . date('Y-m-d') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, ['Title', 'Type', 'Owner Team', 'Scope', 'Status', 'Version',
                   'Effective Date', 'Review Date', 'Nodes', 'Updated By', 'Updated At']);

    $rows = $pdo->query("
        SELECT c.*, (SELECT COUNT(*) FROM org_chart_nodes n WHERE n.chart_id = c.id) AS node_count
        FROM org_charts c ORDER BY c.title
    ")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $c) {
        fputcsv($out, [
            $c['title'], $ochTypes[$c['chart_type']] ?? $c['chart_type'], $c['owner_team'], $c['scope'],
            $c['status'], $c['version'], $c['effective_date'], $c['review_date'],
            $c['node_count'], $c['updated_by'] ?: $c['created_by'], $c['updated_at'] ?: $c['created_at'],
        ]);
    }

    fclose($out);
    exit;
}


/* =========================================================
   WRITES
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('org_charts', 'can_edit');

        $id   = (int) ($_POST['id'] ?? 0);
        $type = (string) ($_POST['chart_type'] ?? 'hierarchy');

        if (!isset($ochTypes[$type])) { $type = 'hierarchy'; }

        $data = [
            'title'          => trim((string) ($_POST['title'] ?? '')),
            'chart_type'     => $type,
            'description'    => trim((string) ($_POST['description'] ?? '')),
            'owner_team'     => trim((string) ($_POST['owner_team'] ?? '')),
            'scope'          => trim((string) ($_POST['scope'] ?? '')),
            'status'         => in_array((string) ($_POST['status'] ?? ''), $ochStatuses, true) ? (string) $_POST['status'] : 'Draft',
            'version'        => trim((string) ($_POST['version'] ?? '')),
            'effective_date' => trim((string) ($_POST['effective_date'] ?? '')),
            'review_date'    => trim((string) ($_POST['review_date'] ?? '')),
            'template_key'   => trim((string) ($_POST['template_key'] ?? '')),
        ];

        /* The whole builder arrives as ONE field rather than as ~14 inputs
           per row. A 60-node chart posted field-by-field is 840 variables,
           and PHP's max_input_vars (default 1000, PHP_INI_PERDIR so it
           cannot be raised from here) silently TRUNCATES the request rather
           than failing it -- the save then reports success having dropped
           every row past the cut-off. patch_servers.php was bitten by
           exactly this. One JSON field cannot be truncated that way. */
        $builder = json_decode((string) ($_POST['builder_json'] ?? ''), true);

        $postedNodes = is_array($builder['nodes'] ?? null) ? $builder['nodes'] : [];
        $postedRaci  = is_array($builder['raci']  ?? null) ? $builder['raci']  : [];

        // Drop rows the user left completely blank rather than storing
        // nameless nodes that render as empty boxes.
        $postedNodes = array_values(array_filter($postedNodes, function ($n) {
            return is_array($n) && trim((string) ($n['label'] ?? '')) !== '';
        }));

        if ($data['title'] === '') {
            $err = 'Chart title is required.';
        } elseif (!$postedNodes) {
            $err = $type === 'raci'
                ? 'Add at least one role before saving.'
                : 'Add at least one node before saving.';
        } else {
            try {
                $pdo->beginTransaction();

                $cols = array_keys($data);

                if ($id > 0) {
                    $oldStmt = $pdo->prepare("SELECT * FROM org_charts WHERE id = ?");
                    $oldStmt->execute([$id]);
                    $old = $oldStmt->fetch(PDO::FETCH_ASSOC) ?: [];

                    $set = implode(', ', array_map(fn($c) => "$c = ?", $cols));
                    $pdo->prepare("UPDATE org_charts SET $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?")
                        ->execute([...array_values($data), $username, $id]);

                    $action = 'UPDATED';
                    $detail = "Updated chart: {$data['title']}\n" . platformDiff($old, $data, $ochChartFields);
                } else {
                    $ph = implode(', ', array_fill(0, count($cols), '?'));
                    $pdo->prepare("INSERT INTO org_charts (" . implode(', ', $cols) . ", created_by) VALUES ($ph, ?)")
                        ->execute([...array_values($data), $username]);

                    $id = (int) $pdo->lastInsertId();
                    $action = 'CREATED';
                    $detail = "Created chart: {$data['title']} (" . ($ochTypes[$type] ?? $type) . ')';
                }

                /* Nodes are replaced wholesale. They are reordered, renamed
                   and re-parented freely in the builder, so there is no
                   stable identity to diff a row against; the audit trail
                   records the shape of the result instead. */
                $pdo->prepare("DELETE FROM org_chart_nodes WHERE chart_id = ?")->execute([$id]);
                $pdo->prepare("DELETE FROM org_chart_raci_rows WHERE chart_id = ?")->execute([$id]);

                $ins = $pdo->prepare("
                    INSERT INTO org_chart_nodes
                        (chart_id, node_order, label, person_name, job_title, contact_email,
                         contact_phone, contact_alt, tier_level, respond_within, resolve_within,
                         coverage, duration, node_notes, accent)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $idOfOrdinal = [];

                foreach ($postedNodes as $i => $node) {
                    $tier = trim((string) ($node['tier'] ?? ''));

                    $ins->execute([
                        $id, $i,
                        trim((string) $node['label']),
                        trim((string) ($node['person']   ?? '')),
                        trim((string) ($node['title']    ?? '')),
                        trim((string) ($node['email']    ?? '')),
                        trim((string) ($node['phone']    ?? '')),
                        trim((string) ($node['alt']      ?? '')),
                        $tier === '' ? null : (int) $tier,
                        trim((string) ($node['respond']  ?? '')),
                        trim((string) ($node['resolve']  ?? '')),
                        trim((string) ($node['coverage'] ?? '')),
                        trim((string) ($node['duration'] ?? '')),
                        trim((string) ($node['notes']    ?? '')),
                        ochAccentClass($node['accent'] ?? 'slate'),
                    ]);

                    $idOfOrdinal[$i] = (int) $pdo->lastInsertId();
                }

                /* Parents are resolved in a second pass: a row may name a
                   parent that appears after it in the list, so the ids do
                   not all exist until every row is inserted.

                   Chains that loop are broken here rather than at render
                   time, so the stored data is a tree even though the picker
                   cannot prevent the user building a ring. */
                if ($type === 'hierarchy') {

                    // Pass one: every link the payload asked for, minus the
                    // ones that are impossible on their own (self-parent,
                    // parent row that does not exist).
                    $claimed = [];

                    foreach ($postedNodes as $i => $node) {
                        $p = $node['parent'] ?? null;

                        if ($p === null || $p === '' || (int) $p === $i || !isset($idOfOrdinal[(int) $p])) {
                            continue;
                        }

                        $claimed[$i] = (int) $p;
                    }

                    // Pass two: drop any link whose chain loops back on
                    // itself. This has to see the WHOLE map -- a row can
                    // name a parent that appears below it, so checking as
                    // the map is built would miss half the rings. A cycle
                    // is possible whenever rows have been reordered, and
                    // storing one would leave the chart unrenderable.
                    $parentOrdinal = [];

                    foreach ($claimed as $child => $parent) {
                        $cur   = $parent;
                        $steps = 0;
                        $ok    = true;

                        while ($cur !== null) {
                            if ($cur === $child || ++$steps > count($postedNodes)) {
                                $ok = false;
                                break;
                            }
                            $cur = $claimed[$cur] ?? null;
                        }

                        if ($ok) {
                            $parentOrdinal[$child] = $parent;
                        }
                    }

                    $upd = $pdo->prepare("UPDATE org_chart_nodes SET parent_id = ? WHERE id = ?");

                    foreach ($parentOrdinal as $childOrd => $parentOrd) {
                        $upd->execute([$idOfOrdinal[$parentOrd], $idOfOrdinal[$childOrd]]);
                    }
                }

                $raciCount = 0;

                if ($type === 'raci') {
                    $insR = $pdo->prepare("
                        INSERT INTO org_chart_raci_rows (chart_id, activity, row_order, assignments, notes)
                        VALUES (?, ?, ?, ?, ?)
                    ");

                    foreach ($postedRaci as $row) {
                        $activity = trim((string) ($row['activity'] ?? ''));
                        if ($activity === '') { continue; }

                        $cells = is_array($row['cells'] ?? null) ? $row['cells'] : [];
                        $clean = [];

                        // One letter per role, in role order, so a stored row
                        // stays aligned with the columns it was entered against.
                        foreach (array_keys($postedNodes) as $ri) {
                            $l = strtoupper(trim((string) ($cells[$ri] ?? '')));
                            $clean[] = in_array($l, ['R', 'A', 'C', 'I'], true) ? $l : '';
                        }

                        $insR->execute([
                            $id, $activity, $raciCount,
                            json_encode($clean),
                            trim((string) ($row['notes'] ?? '')),
                        ]);

                        $raciCount++;
                    }
                }

                $pdo->commit();

                $shape = count($postedNodes) . ($type === 'raci' ? ' role(s), ' . $raciCount . ' activity row(s)' : ' node(s)');
                platformLog($pdo, OCH_MODULE, $id, $action, $username, $detail . "\n" . $shape);

                $msg = $action === 'CREATED' ? 'Chart created.' : 'Chart updated.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'duplicate') {
        requirePermission('org_charts', 'can_edit');

        $id = (int) ($_POST['id'] ?? 0);

        try {
            $s = $pdo->prepare("SELECT * FROM org_charts WHERE id = ?");
            $s->execute([$id]);
            $src = $s->fetch(PDO::FETCH_ASSOC);

            if (!$src) {
                $err = 'Chart not found.';
            } else {
                $pdo->beginTransaction();

                // A copy starts as a Draft on purpose: two charts both marked
                // Active for the same service is how an out-of-date
                // escalation path ends up being the one someone follows.
                $pdo->prepare("
                    INSERT INTO org_charts
                        (title, chart_type, template_key, description, owner_team, scope,
                         status, version, effective_date, review_date, created_by)
                    VALUES (?, ?, ?, ?, ?, ?, 'Draft', ?, ?, ?, ?)
                ")->execute([
                    $src['title'] . ' (copy)', $src['chart_type'], $src['template_key'],
                    $src['description'], $src['owner_team'], $src['scope'],
                    $src['version'], $src['effective_date'], $src['review_date'], $username,
                ]);

                $newId = (int) $pdo->lastInsertId();

                $nodes = ochLoadNodes($pdo, $id, (string) $src['chart_type']);

                $ins = $pdo->prepare("
                    INSERT INTO org_chart_nodes
                        (chart_id, node_order, label, person_name, job_title, contact_email,
                         contact_phone, contact_alt, tier_level, respond_within, resolve_within,
                         coverage, duration, node_notes, accent)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");

                $map = [];
                foreach (array_values($nodes) as $i => $n) {
                    $ins->execute([
                        $newId, $i, $n['label'], $n['person_name'], $n['job_title'], $n['contact_email'],
                        $n['contact_phone'], $n['contact_alt'], $n['tier_level'], $n['respond_within'],
                        $n['resolve_within'], $n['coverage'], $n['duration'], $n['node_notes'], $n['accent'],
                    ]);
                    $map[(int) $n['id']] = (int) $pdo->lastInsertId();
                }

                $upd = $pdo->prepare("UPDATE org_chart_nodes SET parent_id = ? WHERE id = ?");
                foreach ($nodes as $n) {
                    $pid = (int) ($n['parent_id'] ?? 0);
                    if ($pid > 0 && isset($map[$pid])) {
                        $upd->execute([$map[$pid], $map[(int) $n['id']]]);
                    }
                }

                $insR = $pdo->prepare("
                    INSERT INTO org_chart_raci_rows (chart_id, activity, row_order, assignments, notes)
                    VALUES (?, ?, ?, ?, ?)
                ");
                foreach (ochLoadRaci($pdo, $id) as $r) {
                    $insR->execute([$newId, $r['activity'], $r['row_order'], $r['assignments'], $r['notes']]);
                }

                $pdo->commit();

                platformLog($pdo, OCH_MODULE, $newId, 'CREATED', $username,
                    "Duplicated from chart #{$id}: {$src['title']}");

                $msg = 'Chart duplicated as a draft.';
            }
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) { $pdo->rollBack(); }
            $err = 'Unable to duplicate: ' . $e->getMessage();
        }
    }

    if ($formAction === 'delete') {
        requirePermission('org_charts', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);

        $n = $pdo->prepare("SELECT title FROM org_charts WHERE id = ?");
        $n->execute([$id]);
        $title = (string) ($n->fetchColumn() ?: 'Unknown');

        // The FKs declare ON DELETE CASCADE, but this app leaves SQLite's
        // PRAGMA foreign_keys at its default (off), so the child rows have
        // to go explicitly or they are orphaned with nothing left to reach
        // them -- the same reason special_projects.php deletes by hand.
        $pdo->prepare("DELETE FROM org_chart_nodes WHERE chart_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM org_chart_raci_rows WHERE chart_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM org_charts WHERE id = ?")->execute([$id]);

        platformLog($pdo, OCH_MODULE, $id, 'DELETED', $username, "Deleted chart: {$title}");
        $msg = 'Chart deleted.';
    }
}


/* =========================================================
   SINGLE CHART VIEW
========================================================= */

if (($_GET['action'] ?? '') === 'view') {

    $id = (int) ($_GET['id'] ?? 0);

    $s = $pdo->prepare("SELECT * FROM org_charts WHERE id = ?");
    $s->execute([$id]);
    $chart = $s->fetch(PDO::FETCH_ASSOC);

    if (!$chart) {
        $page_title = 'Chart not found | InfraVault';
        require_once __DIR__ . '/includes/header.php';
        require_once __DIR__ . '/includes/sidebar.php';
        echo '<link rel="stylesheet" href="assets/css/platform.css">'
           . '<div class="content"><div class="plat-panel"><div class="plat-panel-body">'
           . '<p class="plat-empty">That chart no longer exists. '
           . '<a href="org_charts.php">Back to all charts</a>.</p></div></div></div>';
        require_once __DIR__ . '/includes/footer.php';
        exit;
    }

    $type     = (string) $chart['chart_type'];
    $nodes    = ochLoadNodes($pdo, $id, $type);
    $raciRows = $type === 'raci' ? ochLoadRaci($pdo, $id) : [];

    $today       = date('Y-m-d');
    $reviewDue   = !empty($chart['review_date']) && $chart['review_date'] < $today;

    $page_title = $chart['title'] . ' | InfraVault';
    require_once __DIR__ . '/includes/header.php';
    require_once __DIR__ . '/includes/sidebar.php';
    ?>
    <link rel="stylesheet" href="assets/css/platform.css">
    <link rel="stylesheet" href="assets/css/org-charts.css">

    <div class="content och-scope">

        <a class="och-back" href="org_charts.php">← All charts</a>

        <div class="plat-hero">
            <div class="plat-hero-main">
                <div class="plat-hero-icon"><?= $ochTypeIcons[$type] ?? '📊' ?></div>
                <div>
                    <h1><?= plat_h($chart['title']) ?></h1>
                    <p>
                        <?= plat_h($ochTypes[$type] ?? $type) ?>
                        <?php if ($chart['scope']): ?> · <?= plat_h($chart['scope']) ?><?php endif; ?>
                        <?php if ($chart['description']): ?><br><?= plat_h($chart['description']) ?><?php endif; ?>
                    </p>
                </div>
            </div>
            <div class="plat-actions">
                <button type="button" class="plat-btn" onclick="window.print()">Print</button>
                <?php if ($canExport): ?>
                    <a class="plat-btn" href="?action=export&amp;id=<?= $id ?>">Export CSV</a>
                <?php endif; ?>
                <?php if ($canEdit): ?>
                    <a class="plat-btn plat-btn-primary" href="org_charts.php?edit=<?= $id ?>">Edit chart</a>
                <?php endif; ?>
            </div>
        </div>

        <?php if ($reviewDue): ?>
            <div class="plat-alert plat-alert-err">
                This chart was due for review on <?= plat_h($chart['review_date']) ?>.
                Confirm the names and numbers below are still correct.
            </div>
        <?php endif; ?>

        <div class="plat-panel">
            <div class="plat-panel-body">
                <div class="och-meta">
                    <div><label>Status</label><strong><?= plat_h($chart['status']) ?></strong></div>
                    <div><label>Version</label><strong><?= plat_h($chart['version'] ?: '—') ?></strong></div>
                    <div><label>Owner team</label><strong><?= plat_h($chart['owner_team'] ?: '—') ?></strong></div>
                    <div><label>Effective</label><strong><?= plat_h($chart['effective_date'] ?: '—') ?></strong></div>
                    <div><label>Review by</label><strong><?= plat_h($chart['review_date'] ?: '—') ?></strong></div>
                    <div><label>Last updated</label><strong><?= plat_h($chart['updated_at'] ?: $chart['created_at']) ?></strong></div>
                    <div><label>By</label><strong><?= plat_h($chart['updated_by'] ?: $chart['created_by'] ?: '—') ?></strong></div>
                </div>
            </div>
        </div>

        <div class="plat-panel">
            <div class="plat-panel-head"><h3><?= plat_h($ochTypes[$type] ?? 'Chart') ?></h3></div>
            <div class="plat-panel-body">
                <div class="och-stage">
                    <?= ochRenderChart($chart, $nodes, $raciRows) ?>
                </div>
            </div>
        </div>

        <?php if ($nodes): ?>
        <div class="plat-panel">
            <div class="plat-panel-head">
                <h3><?= $type === 'raci' ? 'Roles' : ($type === 'cycle' ? 'Stages' : ($type === 'escalation' ? 'Tiers' : 'Positions')) ?></h3>
                <span style="font-size:13px;color:var(--text-muted);"><?= count($nodes) ?> entries</span>
            </div>
            <div class="plat-table-wrap">
                <table class="plat-table">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th><?= $type === 'cycle' ? 'Stage' : 'Label' ?></th>
                            <th><?= $type === 'cycle' ? 'Owner' : 'Person' ?></th>
                            <th>Contact</th>
                            <?php if ($type === 'escalation'): ?><th>SLA</th><th>Coverage</th><?php endif; ?>
                            <?php if ($type === 'cycle'): ?><th>Duration</th><?php endif; ?>
                            <th>Notes</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach (array_values($nodes) as $i => $n): ?>
                        <tr>
                            <td><?= $type === 'escalation' && $n['tier_level'] !== null ? 'T' . (int) $n['tier_level'] : $i + 1 ?></td>
                            <td>
                                <span class="plat-primary"><?= plat_h($n['label']) ?></span>
                                <?php if ($n['job_title']): ?><span class="plat-sub"><?= plat_h($n['job_title']) ?></span><?php endif; ?>
                            </td>
                            <td><?= plat_h($n['person_name'] ?: '—') ?></td>
                            <td>
                                <?php if ($n['contact_email']): ?><a href="mailto:<?= plat_h($n['contact_email']) ?>"><?= plat_h($n['contact_email']) ?></a><?php endif; ?>
                                <?php if ($n['contact_phone']): ?><span class="plat-sub"><?= plat_h($n['contact_phone']) ?></span><?php endif; ?>
                                <?php if ($n['contact_alt']): ?><span class="plat-sub"><?= plat_h($n['contact_alt']) ?></span><?php endif; ?>
                                <?php if (!$n['contact_email'] && !$n['contact_phone'] && !$n['contact_alt']): ?>—<?php endif; ?>
                            </td>
                            <?php if ($type === 'escalation'): ?>
                                <td>
                                    <?= plat_h($n['respond_within'] ?: '—') ?>
                                    <span class="plat-sub">then <?= plat_h($n['resolve_within'] ?: '—') ?></span>
                                </td>
                                <td><?= plat_h($n['coverage'] ?: '—') ?></td>
                            <?php endif; ?>
                            <?php if ($type === 'cycle'): ?>
                                <td><?= plat_h($n['duration'] ?: '—') ?></td>
                            <?php endif; ?>
                            <td style="max-width:320px;white-space:pre-wrap;"><?= plat_h($n['node_notes'] ?: '—') ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

    </div>
    <?php
    require_once __DIR__ . '/includes/footer.php';
    exit;
}


/* =========================================================
   LIST
========================================================= */

$q       = trim((string) ($_GET['q'] ?? ''));
$fType   = trim((string) ($_GET['f_type'] ?? ''));
$fStatus = trim((string) ($_GET['f_status'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    // Node text is searched too, so looking up a person's name finds every
    // chart they appear on -- the question asked when someone leaves.
    $where[] = '(c.title LIKE ? OR c.description LIKE ? OR c.scope LIKE ? OR c.owner_team LIKE ?'
             . ' OR EXISTS (SELECT 1 FROM org_chart_nodes n WHERE n.chart_id = c.id'
             . '   AND (n.label LIKE ? OR n.person_name LIKE ? OR n.contact_email LIKE ?)))';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fType !== '' && isset($ochTypes[$fType])) { $where[] = 'c.chart_type = ?'; $params[] = $fType; }
if ($fStatus !== '')                           { $where[] = 'c.status = ?';     $params[] = $fStatus; }

$stmt = $pdo->prepare("
    SELECT c.*, (SELECT COUNT(*) FROM org_chart_nodes n WHERE n.chart_id = c.id) AS node_count
    FROM org_charts c
    WHERE " . implode(' AND ', $where) . "
    ORDER BY
        CASE c.status WHEN 'Active' THEN 1 WHEN 'Under Review' THEN 2 WHEN 'Draft' THEN 3 ELSE 4 END,
        c.title
");
$stmt->execute($params);
$charts = $stmt->fetchAll(PDO::FETCH_ASSOC);

$today = date('Y-m-d');

$countActive = 0;
$countDue    = 0;
$byType      = array_fill_keys(array_keys($ochTypes), 0);

foreach ($charts as $c) {
    if ($c['status'] === 'Active') { $countActive++; }
    if (!empty($c['review_date']) && $c['review_date'] < $today && $c['status'] !== 'Archived') { $countDue++; }
    if (isset($byType[$c['chart_type']])) { $byType[$c['chart_type']]++; }
}

$templates = ochTemplates();

$page_title = 'Org & Escalation Charts | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">
<link rel="stylesheet" href="assets/css/org-charts.css">

<div class="content och-scope">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🧬</div>
            <div>
                <h1>Org &amp; Escalation Charts</h1>
                <p>Reporting hierarchies, escalation matrices, lifecycle diagrams and RACI grids — built from structured data, not drawn by hand.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="ochPickTemplate()">+ New Chart</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn" href="?action=export">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="ochHistory(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= count($charts) ?></b><span>Shown</span></div>
        <div class="plat-stat tone-ok"><b><?= $countActive ?></b><span>Active</span></div>
        <div class="plat-stat tone-warn"><b><?= $countDue ?></b><span>Review overdue</span></div>
        <div class="plat-stat"><b><?= $byType['hierarchy'] ?></b><span>Hierarchies</span></div>
        <div class="plat-stat"><b><?= $byType['escalation'] ?></b><span>Escalation</span></div>
        <div class="plat-stat"><b><?= $byType['cycle'] + $byType['raci'] ?></b><span>Cycles &amp; RACI</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search &amp; Filters</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Title, scope, a person's name or email…">
                </div>
                <div class="plat-field">
                    <label>Type</label>
                    <select name="f_type">
                        <option value="">All</option>
                        <?php foreach ($ochTypes as $k => $label): ?>
                            <option value="<?= plat_h($k) ?>" <?= $fType === $k ? 'selected' : '' ?>><?= plat_h($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Status</label>
                    <select name="f_status">
                        <option value="">All</option>
                        <?php foreach ($ochStatuses as $s): ?>
                            <option value="<?= plat_h($s) ?>" <?= $fStatus === $s ? 'selected' : '' ?>><?= plat_h($s) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="org_charts.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Charts</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= count($charts) ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Chart</th><th>Type</th><th>Owner</th><th>Entries</th>
                        <th>Version</th><th>Review</th><th>Status</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$charts): ?>
                    <tr><td colspan="8"><p class="plat-empty">
                        No charts yet.
                        <?= $canEdit ? 'Start from a template — an escalation matrix or an org tree takes about a minute.' : '' ?>
                    </p></td></tr>
                <?php else: foreach ($charts as $c): ?>
                    <?php
                        $cid = (int) $c['id'];
                        $ct  = (string) $c['chart_type'];
                        $overdue = !empty($c['review_date']) && $c['review_date'] < $today && $c['status'] !== 'Archived';

                        $statusTone = match ((string) $c['status']) {
                            'Active'       => 'ok',
                            'Under Review' => 'warn',
                            'Archived'     => 'neutral',
                            default        => 'neutral',
                        };
                    ?>
                    <tr>
                        <td>
                            <a href="?action=view&amp;id=<?= $cid ?>" class="plat-primary" style="text-decoration:none;"><?= plat_h($c['title']) ?></a>
                            <?php if ($c['scope'] || $c['description']): ?>
                                <span class="plat-sub"><?= plat_h($c['scope'] ?: $c['description']) ?></span>
                            <?php endif; ?>
                        </td>
                        <td><span class="och-type-pill t-<?= plat_h($ct) ?>"><?= $ochTypeIcons[$ct] ?? '' ?> <?= plat_h($ochTypes[$ct] ?? $ct) ?></span></td>
                        <td><?= plat_h($c['owner_team'] ?: '—') ?></td>
                        <td><?= (int) $c['node_count'] ?></td>
                        <td><?= plat_h($c['version'] ?: '—') ?></td>
                        <td>
                            <?php if ($overdue): ?>
                                <span class="plat-pill crit">due <?= plat_h($c['review_date']) ?></span>
                            <?php else: ?>
                                <?= plat_h($c['review_date'] ?: '—') ?>
                            <?php endif; ?>
                        </td>
                        <td><span class="plat-pill <?= $statusTone ?>"><?= plat_h($c['status']) ?></span></td>
                        <td>
                            <div class="plat-row-actions">
                                <a class="plat-icon-btn plat-icon-view" title="Open" href="?action=view&amp;id=<?= $cid ?>">👁</a>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit" onclick="ochEdit(<?= $cid ?>)">✎</button>
                                    <button type="button" class="plat-icon-btn" title="Duplicate" onclick="ochDuplicate(<?= $cid ?>, <?= htmlspecialchars(json_encode($c['title']), ENT_QUOTES, 'UTF-8') ?>)">⧉</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="History" onclick="ochHistory(<?= $cid ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete" onclick="ochDelete(<?= $cid ?>, <?= htmlspecialchars(json_encode($c['title']), ENT_QUOTES, 'UTF-8') ?>)">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<!-- ============ TEMPLATE PICKER ============ -->
<div class="plat-modal" id="ochTplModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2>Start from a template</h2>
            <button type="button" class="plat-close" onclick="platClose('ochTplModal')">&times;</button>
        </div>
        <p class="plat-modal-sub">Templates are starting content, not fixed layouts — every field is editable afterwards.</p>

        <div class="och-tpl-grid och-scope">
            <?php
            $groups = [
                'hierarchy'  => 'Organisational hierarchy',
                'escalation' => 'Escalation matrix',
                'cycle'      => 'Cycle / lifecycle',
                'raci'       => 'RACI matrix',
            ];

            foreach ($groups as $gType => $gLabel):
                $inGroup = array_filter($templates, fn($t) => $t['type'] === $gType);
                if (!$inGroup) { continue; }
            ?>
                <div class="och-tpl-group"><?= plat_h($gLabel) ?></div>
                <?php foreach ($inGroup as $key => $tpl): ?>
                    <button type="button" class="och-tpl" onclick="ochUseTemplate('<?= plat_h($key) ?>')">
                        <span class="och-tpl-icon"><?= $tpl['icon'] ?></span>
                        <span>
                            <b><?= plat_h($tpl['name']) ?></b>
                            <small><?= plat_h($tpl['desc']) ?></small>
                        </span>
                    </button>
                <?php endforeach; ?>
            <?php endforeach; ?>
        </div>
    </div>
</div>


<!-- ============ EDITOR ============ -->
<div class="plat-modal" id="ochModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2 id="ochTitle">New Chart</h2>
            <button type="button" class="plat-close" onclick="platClose('ochModal')">&times;</button>
        </div>
        <p class="plat-modal-sub" id="ochSub">Fill in the structure — the chart is drawn from it.</p>

        <form method="POST" id="ochForm">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="och_id">
            <input type="hidden" name="template_key" id="och_template_key">
            <input type="hidden" name="builder_json" id="och_builder_json">

            <div class="plat-form-grid">
                <div class="plat-field full">
                    <label>Title *</label>
                    <input type="text" name="title" id="och_title" required placeholder="Payments platform escalation matrix">
                </div>

                <div class="plat-field">
                    <label>Chart type</label>
                    <select name="chart_type" id="och_chart_type" onchange="ochApplyType()">
                        <?php foreach ($ochTypes as $k => $label): ?>
                            <option value="<?= plat_h($k) ?>"><?= plat_h($label) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Owner team</label>
                    <input type="text" name="owner_team" id="och_owner_team" placeholder="Infrastructure">
                </div>
                <div class="plat-field">
                    <label>Scope</label>
                    <input type="text" name="scope" id="och_scope" placeholder="Service or process this covers">
                </div>

                <div class="plat-field full">
                    <label>Description</label>
                    <textarea name="description" id="och_description" rows="2"></textarea>
                </div>

                <div class="plat-field">
                    <label>Status</label>
                    <select name="status" id="och_status">
                        <?php foreach ($ochStatuses as $s): ?><option value="<?= plat_h($s) ?>"><?= plat_h($s) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field">
                    <label>Version</label>
                    <input type="text" name="version" id="och_version" placeholder="1.0">
                </div>
                <div class="plat-field">
                    <label>Effective date</label>
                    <input type="date" name="effective_date" id="och_effective_date">
                </div>
                <div class="plat-field">
                    <label>Review by</label>
                    <input type="date" name="review_date" id="och_review_date">
                </div>
            </div>

            <div class="och-builder-root och-scope" id="ochBuilderRoot" data-type="hierarchy">

                <div class="plat-section-title" id="ochNodesHeading">Positions</div>
                <p class="och-builder-hint" id="ochNodesHint"></p>

                <div class="och-builder" id="ochNodes"></div>

                <div style="margin-top:10px;">
                    <button type="button" class="plat-btn plat-btn-light" onclick="ochAddRow()">+ Add row</button>
                </div>

                <div data-for="raci">
                    <div class="plat-section-title">Activities</div>
                    <p class="och-builder-hint">One row per activity. Mark exactly one <strong>A</strong> per row — that is the role answerable for the outcome.</p>

                    <div class="och-grid-wrap">
                        <table class="och-grid" id="ochGrid">
                            <thead><tr id="ochGridHead"></tr></thead>
                            <tbody id="ochGridBody"></tbody>
                        </table>
                    </div>

                    <div style="margin-top:10px;">
                        <button type="button" class="plat-btn plat-btn-light" onclick="ochAddActivity()">+ Add activity</button>
                    </div>
                </div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('ochModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save chart</button>
            </div>
        </form>
    </div>
</div>


<!-- ============ HISTORY ============ -->
<div class="plat-modal" id="ochHistModal">
    <div class="plat-modal-inner wide">
        <div class="plat-modal-head">
            <h2>Audit History</h2>
            <button type="button" class="plat-close" onclick="platClose('ochHistModal')">&times;</button>
        </div>
        <div id="ochHistBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>


<!-- ============ HIDDEN ACTION FORM ============ -->
<form method="POST" id="ochActionForm" style="display:none;">
    <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
    <input type="hidden" name="form_action" id="och_af_action">
    <input type="hidden" name="id" id="och_af_id">
</form>


<script>
/* One copy of the template catalogue, handed over from PHP -- a second
   list maintained in JS is a list that drifts. */
const OCH_TEMPLATES = <?= json_encode(ochTemplates(), JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
const OCH_ACCENTS   = <?= json_encode($ochAccents) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }


/* ---------------------------------------------------------
   Per-type wording.

   The same field means different things in different charts:
   "Person" is a post-holder on an org chart and a stage owner on a
   cycle. Relabelling is cheaper -- and keeps what was already typed --
   than swapping in a different input per type.
--------------------------------------------------------- */
const OCH_WORDING = {
    hierarchy: {
        heading: 'Positions',
        hint:    'One row per position. “Reports to” builds the tree; leave it at top level for the person at the top.',
        label:   'Role / position',
        person:  'Person',
        ph:      'VP Engineering'
    },
    escalation: {
        heading: 'Tiers',
        hint:    'One row per tier. Tier number decides the order on the ladder, so inserting a tier later still lands in the right place.',
        label:   'Tier name',
        person:  'Person / rota',
        ph:      'Tier 2 — Platform Engineering'
    },
    cycle: {
        heading: 'Stages',
        hint:    'One row per stage, in the order they run. The last stage loops back to the first.',
        label:   'Stage',
        person:  'Owner',
        ph:      'Plan'
    },
    raci: {
        heading: 'Roles (grid columns)',
        hint:    'One row per role. These become the columns of the grid below.',
        label:   'Role',
        person:  'Person',
        ph:      'Change Manager'
    }
};

const OCH_ROW_HTML = `
<div class="och-row-handle"><span data-role="idx">1</span></div>
<div class="och-row-fields">
    <div data-for="hierarchy escalation cycle raci">
        <label data-lbl="label">Label</label>
        <input type="text" data-f="label" data-ph="label">
    </div>
    <div data-for="hierarchy escalation cycle raci">
        <label data-lbl="person">Person</label>
        <input type="text" data-f="person">
    </div>
    <div data-for="hierarchy escalation raci">
        <label>Job title</label>
        <input type="text" data-f="title">
    </div>
    <div data-for="hierarchy">
        <label>Reports to</label>
        <select data-f="parent"></select>
    </div>
    <div data-for="escalation">
        <label>Tier level</label>
        <input type="number" min="1" step="1" data-f="tier">
    </div>
    <div data-for="hierarchy escalation raci">
        <label>Email</label>
        <input type="email" data-f="email">
    </div>
    <div data-for="hierarchy escalation raci">
        <label>Phone</label>
        <input type="text" data-f="phone">
    </div>
    <div data-for="escalation">
        <label>Alternate contact</label>
        <input type="text" data-f="alt" placeholder="Group mailbox, pager, vendor case line">
    </div>
    <div data-for="escalation">
        <label>Respond within</label>
        <input type="text" data-f="respond" placeholder="30 minutes">
    </div>
    <div data-for="escalation">
        <label>Resolve within</label>
        <input type="text" data-f="resolve" placeholder="4 hours">
    </div>
    <div data-for="escalation">
        <label>Coverage</label>
        <input type="text" data-f="coverage" placeholder="24x7">
    </div>
    <div data-for="cycle">
        <label>Typical duration</label>
        <input type="text" data-f="duration" placeholder="2 weeks">
    </div>
    <div class="full" data-for="hierarchy escalation cycle raci">
        <label>Notes</label>
        <input type="text" data-f="notes">
    </div>
    <div class="full" data-for="hierarchy escalation cycle raci">
        <label>Colour</label>
        <div class="och-accent-pick" data-role="accent"></div>
        <input type="hidden" data-f="accent" value="slate">
    </div>
</div>
<div class="och-row-tools">
    <button type="button" class="och-mini" title="Move up" onclick="ochMove(this,-1)">↑</button>
    <button type="button" class="och-mini" title="Move down" onclick="ochMove(this,1)">↓</button>
    <button type="button" class="och-mini danger" title="Remove" onclick="ochRemove(this)">✕</button>
</div>`;


function ochNodesBox() { return document.getElementById('ochNodes'); }
function ochRows()     { return Array.from(ochNodesBox().children); }
function ochType()     { return document.getElementById('och_chart_type').value; }


function ochAddRow(data) {
    data = data || {};

    const row = document.createElement('div');
    row.className = 'och-row';
    row.innerHTML = OCH_ROW_HTML;

    // Colour swatches, built here rather than in the template string so the
    // accent list stays defined in exactly one place (PHP).
    const pick = row.querySelector('[data-role="accent"]');
    OCH_ACCENTS.forEach(a => {
        const b = document.createElement('button');
        b.type = 'button';
        b.className = 'och-swatch s-' + a;
        b.title = a;
        b.setAttribute('aria-pressed', 'false');
        b.onclick = () => ochSetAccent(row, a);
        pick.appendChild(b);
    });

    ochNodesBox().appendChild(row);

    ['label','person','title','email','phone','alt','tier','respond','resolve','coverage','duration','notes']
        .forEach(f => {
            const el = row.querySelector('[data-f="' + f + '"]');
            if (el) { el.value = data[f] != null ? data[f] : ''; }
        });

    ochSetAccent(row, data.accent || 'slate');

    // Held on the element until ochSyncRows() can turn it into a <select>
    // option -- the row it points at may not exist yet during a bulk load.
    row.dataset.pendingParent = (data.parent === null || data.parent === undefined) ? '' : String(data.parent);

    ochSyncRows();
    return row;
}

function ochSetAccent(row, accent) {
    row.querySelector('[data-f="accent"]').value = accent;
    row.querySelectorAll('.och-swatch').forEach(b => {
        b.setAttribute('aria-pressed', b.classList.contains('s-' + accent) ? 'true' : 'false');
    });
}

function ochRemove(btn) {
    btn.closest('.och-row').remove();
    ochSyncRows();
}

function ochMove(btn, dir) {
    const row  = btn.closest('.och-row');
    const rows = ochRows();
    const i    = rows.indexOf(row);
    const j    = i + dir;

    if (j < 0 || j >= rows.length) { return; }

    // Parents are addressed by position, so capture them before the move
    // and restore them after -- otherwise reordering silently re-parents.
    const parents = rows.map(r => {
        const s = r.querySelector('[data-f="parent"]');
        const v = s && s.value !== '' ? parseInt(s.value, 10) : null;
        return v;
    });

    const order = rows.map((_, k) => k);
    order.splice(j, 0, order.splice(i, 1)[0]);

    if (dir < 0) { ochNodesBox().insertBefore(row, rows[j]); }
    else         { ochNodesBox().insertBefore(rows[j], row); }

    // newIndexOf[oldIndex] = position after the move
    const newIndexOf = [];
    order.forEach((oldIdx, newIdx) => { newIndexOf[oldIdx] = newIdx; });

    const moved = ochRows();
    order.forEach((oldIdx, newIdx) => {
        const p = parents[oldIdx];
        moved[newIdx].dataset.pendingParent = (p === null || newIndexOf[p] === undefined) ? '' : String(newIndexOf[p]);
    });

    ochSyncRows();
}


/**
 * Renumbers the rows, rebuilds every "Reports to" list and keeps the RACI
 * grid's columns matching the roles above it.
 */
function ochSyncRows() {
    const rows = ochRows();

    rows.forEach((row, i) => {
        row.querySelector('[data-role="idx"]').textContent = i + 1;

        const sel = row.querySelector('[data-f="parent"]');
        if (!sel) { return; }

        const current = row.dataset.pendingParent !== undefined && row.dataset.pendingParent !== ''
            ? row.dataset.pendingParent
            : sel.value;

        sel.innerHTML = '';

        const top = document.createElement('option');
        top.value = '';
        top.textContent = '— top level —';
        sel.appendChild(top);

        rows.forEach((other, j) => {
            if (j === i) { return; }   // a node cannot report to itself

            const label = (other.querySelector('[data-f="label"]').value || '').trim();
            const o = document.createElement('option');
            o.value = String(j);
            o.textContent = (j + 1) + '. ' + (label || 'Untitled');
            sel.appendChild(o);
        });

        sel.value = (current !== '' && current !== null && parseInt(current, 10) !== i
                     && parseInt(current, 10) < rows.length) ? String(parseInt(current, 10)) : '';

        delete row.dataset.pendingParent;
    });

    ochSyncGrid();
}

/** Keeps the RACI grid's columns aligned with the role rows. */
function ochSyncGrid() {
    const head = document.getElementById('ochGridHead');
    const body = document.getElementById('ochGridBody');
    if (!head || !body) { return; }

    const roles = ochRows().map(r => (r.querySelector('[data-f="label"]').value || '').trim());

    head.innerHTML = '';

    const first = document.createElement('th');
    first.textContent = 'Activity';
    head.appendChild(first);

    roles.forEach((label, i) => {
        const th = document.createElement('th');
        th.textContent = label || ('Role ' + (i + 1));
        head.appendChild(th);
    });

    const last = document.createElement('th');
    last.textContent = '';
    head.appendChild(last);

    Array.from(body.children).forEach(tr => ochFitRow(tr, roles.length));
}

/** Adds or trims a grid row's letter cells so it has one per role. */
function ochFitRow(tr, count) {
    const tools = tr.querySelector('.och-raci-tools');
    let cells = tr.querySelectorAll('td.och-cell');

    while (cells.length > count) {
        cells[cells.length - 1].remove();
        cells = tr.querySelectorAll('td.och-cell');
    }

    while (cells.length < count) {
        const td = document.createElement('td');
        td.className = 'och-cell';

        const sel = document.createElement('select');
        ['', 'R', 'A', 'C', 'I'].forEach(l => {
            const o = document.createElement('option');
            o.value = l;
            o.textContent = l === '' ? '·' : l;
            sel.appendChild(o);
        });

        td.appendChild(sel);
        tr.insertBefore(td, tools);
        cells = tr.querySelectorAll('td.och-cell');
    }
}

function ochAddActivity(data) {
    data = data || {};

    const tr = document.createElement('tr');
    tr.innerHTML = '<td><input type="text" data-f="activity" placeholder="Approve change">'
                 + '<input type="text" data-f="notes" placeholder="Note (optional)" style="margin-top:5px;"></td>'
                 + '<td class="och-raci-tools"><button type="button" class="och-mini danger" onclick="this.closest(\'tr\').remove()">✕</button></td>';

    document.getElementById('ochGridBody').appendChild(tr);

    tr.querySelector('[data-f="activity"]').value = data.activity || '';
    tr.querySelector('[data-f="notes"]').value    = data.notes || '';

    ochFitRow(tr, ochRows().length);

    (data.cells || []).forEach((l, i) => {
        const sel = tr.querySelectorAll('td.och-cell select')[i];
        if (sel) { sel.value = ['R','A','C','I'].includes(l) ? l : ''; }
    });

    return tr;
}


/** Applies the chart type to field visibility and wording. */
function ochApplyType() {
    const type = ochType();
    const w    = OCH_WORDING[type] || OCH_WORDING.hierarchy;

    document.getElementById('ochBuilderRoot').dataset.type = type;
    document.getElementById('ochNodesHeading').textContent = w.heading;
    document.getElementById('ochNodesHint').textContent    = w.hint;

    ochRows().forEach(row => {
        row.querySelector('[data-lbl="label"]').textContent  = w.label;
        row.querySelector('[data-lbl="person"]').textContent = w.person;
        row.querySelector('[data-ph="label"]').placeholder   = w.ph;
    });

    ochSyncGrid();
}


/* ---------------------------------------------------------
   Opening the editor
--------------------------------------------------------- */

function ochPickTemplate() { platOpen('ochTplModal'); }

function ochReset() {
    document.getElementById('ochForm').reset();
    document.getElementById('och_id').value = '';
    document.getElementById('och_template_key').value = '';
    ochNodesBox().innerHTML = '';
    document.getElementById('ochGridBody').innerHTML = '';
}

function ochUseTemplate(key) {
    const tpl = OCH_TEMPLATES[key];
    if (!tpl) { return; }

    ochReset();

    document.getElementById('ochTitle').textContent = 'New Chart — ' + tpl.name;
    document.getElementById('ochSub').textContent   = tpl.desc;
    document.getElementById('och_template_key').value = key;
    document.getElementById('och_chart_type').value   = tpl.type;

    document.getElementById('och_title').value       = (tpl.meta && tpl.meta.title) || '';
    document.getElementById('och_description').value = (tpl.meta && tpl.meta.description) || '';
    document.getElementById('och_scope').value       = (tpl.meta && tpl.meta.scope) || '';
    document.getElementById('och_status').value      = 'Draft';

    (tpl.nodes || []).forEach(n => ochAddRow(n));
    (tpl.raci  || []).forEach(r => ochAddActivity(r));

    ochApplyType();
    ochSyncRows();

    platClose('ochTplModal');
    platOpen('ochModal');
    document.getElementById('och_title').focus();
}

function ochEdit(id) {
    fetch('org_charts.php?ajax=chart&id=' + id)
        .then(r => r.json())
        .then(d => {
            if (d.error) { alert(d.error); return; }

            ochReset();

            const c = d.chart;

            document.getElementById('ochTitle').textContent = 'Edit — ' + c.title;
            document.getElementById('ochSub').textContent   = 'Changes replace the whole structure; the audit trail records who and when.';

            document.getElementById('och_id').value             = c.id;
            document.getElementById('och_template_key').value   = c.template_key || '';
            document.getElementById('och_chart_type').value     = c.chart_type;
            document.getElementById('och_title').value          = c.title || '';
            document.getElementById('och_description').value    = c.description || '';
            document.getElementById('och_owner_team').value     = c.owner_team || '';
            document.getElementById('och_scope').value          = c.scope || '';
            document.getElementById('och_status').value         = c.status || 'Draft';
            document.getElementById('och_version').value        = c.version || '';
            document.getElementById('och_effective_date').value = c.effective_date || '';
            document.getElementById('och_review_date').value    = c.review_date || '';

            (d.nodes || []).forEach(n => ochAddRow(n));
            (d.raci  || []).forEach(r => ochAddActivity(r));

            ochApplyType();
            ochSyncRows();

            platOpen('ochModal');
        })
        .catch(() => alert('Unable to load that chart.'));
}

function ochHistory(id) {
    const box = document.getElementById('ochHistBody');
    box.innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('ochHistModal');

    fetch('org_charts.php?ajax=history&id=' + id)
        .then(r => r.text())
        .then(h => { box.innerHTML = h; })
        .catch(() => { box.innerHTML = '<p class="plat-empty">Unable to load history.</p>'; });
}

function ochDuplicate(id, title) {
    if (!confirm('Duplicate "' + title + '"? The copy is created as a draft.')) { return; }
    ochSubmitAction('duplicate', id);
}

function ochDelete(id, title) {
    if (!confirm('Delete "' + title + '" and everything in it? This cannot be undone.')) { return; }
    ochSubmitAction('delete', id);
}

function ochSubmitAction(action, id) {
    document.getElementById('och_af_action').value = action;
    document.getElementById('och_af_id').value = id;
    document.getElementById('ochActionForm').submit();
}


/* ---------------------------------------------------------
   Submit

   The builder is serialised into ONE hidden field. Posting ~14 inputs
   per row instead would put a large chart over PHP's max_input_vars,
   which truncates the request silently rather than rejecting it.
--------------------------------------------------------- */
document.getElementById('ochForm').addEventListener('submit', function (e) {
    const type = ochType();

    const nodes = ochRows().map(row => {
        const val = f => {
            const el = row.querySelector('[data-f="' + f + '"]');
            return el ? el.value : '';
        };

        const parentRaw = val('parent');

        return {
            label:    val('label'),
            person:   val('person'),
            title:    val('title'),
            email:    val('email'),
            phone:    val('phone'),
            alt:      val('alt'),
            tier:     val('tier'),
            respond:  val('respond'),
            resolve:  val('resolve'),
            coverage: val('coverage'),
            duration: val('duration'),
            notes:    val('notes'),
            accent:   val('accent') || 'slate',
            parent:   (type === 'hierarchy' && parentRaw !== '') ? parseInt(parentRaw, 10) : null
        };
    }).filter(n => n.label.trim() !== '');

    if (!nodes.length) {
        e.preventDefault();
        alert(type === 'raci'
            ? 'Add at least one role before saving.'
            : 'Add at least one row with a label before saving.');
        return;
    }

    const raci = Array.from(document.getElementById('ochGridBody').children).map(tr => ({
        activity: tr.querySelector('[data-f="activity"]').value,
        notes:    tr.querySelector('[data-f="notes"]').value,
        cells:    Array.from(tr.querySelectorAll('td.och-cell select')).map(s => s.value)
    })).filter(r => r.activity.trim() !== '');

    document.getElementById('och_builder_json').value =
        JSON.stringify({ type: type, nodes: nodes, raci: raci });
});

/* Relabelling depends on the row existing, so a row added later needs the
   wording applied to it too. Cheapest correct hook: re-apply on any input
   in the builder, which also keeps the parent picker's labels current. */
document.getElementById('ochNodes').addEventListener('input', function (e) {
    if (e.target.matches('[data-f="label"]')) { ochSyncRows(); }
});

<?php if ($canEdit): ?>
/* ?edit=N deep link, used by the "Edit chart" button on the view page. */
(function () {
    const m = window.location.search.match(/[?&]edit=(\d+)/);
    if (m) { ochEdit(parseInt(m[1], 10)); }
})();
<?php endif; ?>
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
