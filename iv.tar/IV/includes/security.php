<?php
/**
 * Per-request security bootstrap.
 *
 * Included from config/db.php, which 65 of the application's 70 pages
 * require before producing any output -- that is what makes a single file
 * able to protect the whole app rather than each page opting in (and the
 * ones that forget silently going unprotected).
 *
 * Everything here is unconditional. The only value read from the database
 * is the tunable policy in security_settings (timeout lengths, CSP mode);
 * there is deliberately no switch that turns any of these protections off,
 * because a defence that can be disabled from a web form is a defence an
 * attacker who reaches that form can disable.
 */

require_once __DIR__ . '/security-helpers.php';

/**
 * True when the request arrived over TLS, including the common case of a
 * reverse proxy terminating TLS and forwarding plain HTTP.
 *
 * X-Forwarded-Proto is only honoured when TRUSTED_PROXY=1 is set on the
 * container. The header is client-supplied otherwise, and trusting it
 * blindly would let anyone claim HTTPS -- which would hand out Secure
 * cookies over a plaintext connection and satisfy the HTTPS redirect
 * without any encryption actually being involved.
 */
function requestIsHttps(): bool
{
    if (!empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
        return true;
    }

    if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
        return true;
    }

    if (getenv('TRUSTED_PROXY') === '1') {
        $proto = strtolower(trim((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')));
        if ($proto === 'https') {
            return true;
        }
    }

    return false;
}

/**
 * Hardens the session cookie, then starts the session.
 *
 * Must run before session_start(). Pages that call session_start()
 * themselves before requiring config/db.php (index.php does) will already
 * have a session by the time this runs -- for those, the cookie flags come
 * from the php.ini settings shipped in the Containerfile instead, which
 * apply process-wide regardless of call order. This function is the
 * belt-and-braces half of that pair.
 */
function securityStartSession(): void
{
    if (session_status() !== PHP_SESSION_NONE) {
        return;
    }

    // Refuse to adopt a session id the server never issued, which is what
    // makes session fixation possible in the first place.
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');

    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => requestIsHttps(),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);

    session_start();
}

/**
 * Sends the security response headers.
 *
 * Called before any page output. Silently does nothing if headers are
 * already sent, so an unexpected early echo degrades to "no headers"
 * rather than a warning printed into the middle of the page.
 */
function securitySendHeaders(PDO $pdo): void
{
    if (headers_sent()) {
        return;
    }

    // Clickjacking. frame-ancestors in the CSP is the modern equivalent,
    // but X-Frame-Options is still what older browsers honour.
    header('X-Frame-Options: DENY');

    // Stop the browser guessing a response's type -- the mechanism behind
    // "uploaded .txt executes as HTML" style attacks. This app serves user
    // uploads and CSV exports, so it matters here.
    header('X-Content-Type-Options: nosniff');

    // Don't leak the full internal URL (which carries record ids and search
    // terms in the query string) to external sites.
    header('Referrer-Policy: strict-origin-when-cross-origin');

    // No page in this app uses these; denying them means an injected script
    // cannot either.
    header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=(), usb=()');

    // HSTS only over a connection that is already HTTPS. Sending it over
    // plain HTTP is meaningless, and sending it from a host still served on
    // HTTP would lock browsers out of the site.
    if (requestIsHttps()) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }

    $settings = getSecuritySettings($pdo);
    $cspMode = $settings['csp_mode'];

    if ($cspMode === 'off') {
        return;
    }

    /*
     * 'unsafe-inline' is present because the application currently relies
     * on inline <script> blocks and inline onclick= handlers throughout.
     * That weakens the XSS half of this policy and is the reason the
     * default mode is report-only rather than enforce.
     *
     * The other directives still carry their full weight even with inline
     * script allowed: frame-ancestors blocks framing, form-action stops an
     * injected form posting credentials off-site, base-uri stops a <base>
     * tag rewriting every relative URL on the page, and object-src kills
     * plugin-based vectors outright.
     *
     * To reach a strict policy, move inline handlers to addEventListener
     * in assets/js/, then drop 'unsafe-inline' from script-src and switch
     * this to enforce.
     */
    $csp = implode('; ', [
        "default-src 'self'",
        "script-src 'self' 'unsafe-inline'",
        "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
        "font-src 'self' https://fonts.gstatic.com data:",
        "img-src 'self' data:",
        "connect-src 'self'",
        "frame-ancestors 'none'",
        "base-uri 'self'",
        "form-action 'self'",
        "object-src 'none'",
    ]);

    header(
        ($cspMode === 'enforce'
            ? 'Content-Security-Policy: '
            : 'Content-Security-Policy-Report-Only: ') . $csp
    );
}

/**
 * Redirects plain HTTP to HTTPS when APP_FORCE_HTTPS=1.
 *
 * Deployment configuration, not a database setting: whether TLS is
 * available is a property of how the container is fronted, and a instance
 * still on plain HTTP would lock itself out if this were toggled on from
 * the UI by mistake.
 */
function securityForceHttps(): void
{
    if (getenv('APP_FORCE_HTTPS') !== '1' || requestIsHttps() || headers_sent()) {
        return;
    }

    $host = (string) ($_SERVER['HTTP_HOST'] ?? '');
    $uri  = (string) ($_SERVER['REQUEST_URI'] ?? '/');

    if ($host === '') {
        return;
    }

    header('Location: https://' . $host . $uri, true, 301);
    exit;
}

/**
 * Enforces idle and absolute session lifetimes.
 *
 * Skipped on the pages that manage authentication itself, otherwise an
 * expired session would redirect the login page to the login page.
 */
function securityEnforceSessionTimeouts(PDO $pdo): void
{
    if (session_status() !== PHP_SESSION_ACTIVE || !isset($_SESSION['user_id'])) {
        return;
    }

    $script = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));
    if (in_array($script, ['index.php', 'login.php', 'logout.php', 'signup.php'], true)) {
        return;
    }

    $settings = getSecuritySettings($pdo);
    $now = time();

    $idleSeconds     = max(0, (int) $settings['idle_timeout_minutes']) * 60;
    $absoluteSeconds = max(0, (int) $settings['absolute_timeout_hours']) * 3600;

    $expired = false;

    if ($idleSeconds > 0) {
        $last = (int) ($_SESSION['last_activity'] ?? $now);
        if ($now - $last > $idleSeconds) {
            $expired = true;
        }
    }

    // Absolute lifetime: a session cannot be kept alive indefinitely just
    // by staying active, which is what an attacker with a stolen cookie
    // would do.
    if (!$expired && $absoluteSeconds > 0) {
        $started = (int) ($_SESSION['session_started_at'] ?? $now);
        if ($now - $started > $absoluteSeconds) {
            $expired = true;
        }
    }

    if ($expired) {
        securityDestroySession();

        if (!headers_sent()) {
            header('Location: index.php?timeout=1');
        }
        exit;
    }

    $_SESSION['last_activity'] = $now;

    if (!isset($_SESSION['session_started_at'])) {
        $_SESSION['session_started_at'] = $now;
    }
}

/**
 * Confines a session holding a temporary password to change-password.php.
 *
 * forgot-password.php mails a password in plaintext, so that password must
 * buy nothing except the chance to replace itself. Enforcing that at login
 * alone would be cosmetic -- the session is fully valid, so typing any other
 * URL would walk straight past the redirect. Doing it here, in the bootstrap
 * every page runs before producing output, is what makes it hold.
 *
 * Reads the session copy of the flag rather than the users column: this runs
 * on every request, and a query per request to answer "no" for every normal
 * session is not worth it. index.php seeds the flag at login and
 * change-password.php clears it.
 */
function securityEnforcePasswordChange(): void
{
    if (session_status() !== PHP_SESSION_ACTIVE || empty($_SESSION['user_id'])) {
        return;
    }

    if ((int) ($_SESSION['must_change_password'] ?? 0) !== 1) {
        return;
    }

    /*
     * The pages that must stay reachable: the change form itself, the way
     * out, and the unauthenticated auth pages -- redirecting those would
     * trap a user who would rather sign out and start again.
     */
    $script = strtolower(basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')));
    if (in_array($script, ['change-password.php', 'logout.php', 'index.php', 'forgot-password.php', 'signup.php'], true)) {
        return;
    }

    if (!headers_sent()) {
        header('Location: change-password.php');
    }

    exit;
}

/**
 * Clears session state, the session cookie, and the server-side record.
 */
function securityDestroySession(): void
{
    $_SESSION = [];

    if (ini_get('session.use_cookies') && !headers_sent()) {
        $params = session_get_cookie_params();
        setcookie(
            session_name(),
            '',
            [
                'expires'  => time() - 42000,
                'path'     => $params['path'] ?: '/',
                'domain'   => $params['domain'] ?? '',
                'secure'   => (bool) ($params['secure'] ?? false),
                'httponly' => true,
                'samesite' => $params['samesite'] ?: 'Lax',
            ]
        );
    }

    if (session_status() === PHP_SESSION_ACTIVE) {
        session_destroy();
    }
}

/**
 * Call immediately after credentials are accepted. Issues a new session id
 * so that any id an attacker planted before login is discarded, and stamps
 * the timers the timeout check reads.
 */
function securityOnLogin(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        session_regenerate_id(true);
    }

    $_SESSION['session_started_at'] = time();
    $_SESSION['last_activity'] = time();
}


/*
|--------------------------------------------------------------------------
| CSRF
|--------------------------------------------------------------------------
|
| Always on -- there is no setting for this. The token lives in the session
| and is compared with hash_equals (constant time), matching the pattern
| settings.php and patch_servers.php already use, so those keep working
| unchanged.
*/

function csrfToken(): string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return '';
    }

    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

/** Ready-made hidden input for a form. */
function csrfField(): string
{
    return '<input type="hidden" name="csrf_token" value="'
        . htmlspecialchars(csrfToken(), ENT_QUOTES, 'UTF-8') . '">';
}

function csrfTokenIsValid(?string $token): bool
{
    if (empty($_SESSION['csrf_token']) || $token === null || $token === '') {
        return false;
    }

    return hash_equals($_SESSION['csrf_token'], $token);
}

/** Verifies the current POST, or stops the request with a 403. */
function csrfVerifyOrDie(): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        return;
    }

    if (!csrfTokenIsValid($_POST['csrf_token'] ?? null)) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }
}


/**
 * Entry point, called once from config/db.php.
 */
function securityBootstrap(PDO $pdo): void
{
    // CLI scripts (the reminder daemon and the two cron jobs) have no
    // request, no session and no response headers. Running any of this
    // there would emit "headers already sent" noise at best.
    if (PHP_SAPI === 'cli') {
        return;
    }

    securityForceHttps();
    securityStartSession();
    securitySendHeaders($pdo);
    securityEnforceSessionTimeouts($pdo);

    // After the timeout check: an expired session should be sent to the login
    // page, not to the change-password form.
    securityEnforcePasswordChange();
}
