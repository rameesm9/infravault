<?php
/**
 * Security settings access, password policy, and login lockout.
 *
 * Split from includes/security.php (the request bootstrap) so that CLI
 * scripts and the Settings UI can read/validate policy without pulling in
 * session and header handling.
 */

/**
 * Environment overrides, same convention as MAIL_ENV_OVERRIDES /
 * LDAP_ENV_OVERRIDES. Lets a hardened deployment pin a policy value from
 * the container so it cannot be weakened through the UI at all.
 */
const SECURITY_ENV_OVERRIDES = [
    'idle_timeout_minutes'   => 'SECURITY_IDLE_TIMEOUT_MINUTES',
    'absolute_timeout_hours' => 'SECURITY_ABSOLUTE_TIMEOUT_HOURS',
    'lockout_enabled'        => 'SECURITY_LOCKOUT_ENABLED',
    'lockout_threshold'      => 'SECURITY_LOCKOUT_THRESHOLD',
    'password_min_length'    => 'SECURITY_PASSWORD_MIN_LENGTH',
    'csp_mode'               => 'SECURITY_CSP_MODE',
];

const SECURITY_DEFAULTS = [
    'idle_timeout_minutes'     => 30,
    'absolute_timeout_hours'   => 12,
    'lockout_enabled'          => 1,
    'lockout_threshold'        => 5,
    'lockout_window_minutes'   => 15,
    'lockout_duration_minutes' => 15,
    'password_min_length'      => 12,
    'password_require_upper'   => 1,
    'password_require_lower'   => 1,
    'password_require_number'  => 1,
    'password_require_symbol'  => 0,
    'csp_mode'                 => 'report-only',
];

function getSecurityEnvOverrides(): array
{
    $active = [];
    foreach (SECURITY_ENV_OVERRIDES as $column => $envVar) {
        $value = getenv($envVar);
        if ($value !== false && trim((string) $value) !== '') {
            $active[$column] = $envVar;
        }
    }
    return $active;
}

/**
 * Stored policy with environment overrides applied. Falls back to the
 * defaults if the table is missing, so a half-migrated database degrades
 * to secure-by-default rather than fatal-erroring on every page.
 */
function getSecuritySettings(PDO $pdo): array
{
    static $cached = null;
    if ($cached !== null) {
        return $cached;
    }

    $row = SECURITY_DEFAULTS;

    try {
        $stored = $pdo->query("SELECT * FROM security_settings WHERE id = 1 LIMIT 1")
                      ->fetch(PDO::FETCH_ASSOC);
        if ($stored) {
            foreach (SECURITY_DEFAULTS as $key => $default) {
                if (array_key_exists($key, $stored) && $stored[$key] !== null) {
                    $row[$key] = $stored[$key];
                }
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to read security_settings, using defaults: ' . $e->getMessage());
    }

    foreach (getSecurityEnvOverrides() as $column => $envVar) {
        $row[$column] = getenv($envVar);
    }

    // Normalize types once, here, so no caller has to cast.
    foreach (SECURITY_DEFAULTS as $key => $default) {
        if ($key === 'csp_mode') {
            $row[$key] = strtolower(trim((string) $row[$key]));
            if (!in_array($row[$key], ['off', 'report-only', 'enforce'], true)) {
                $row[$key] = 'report-only';
            }
        } else {
            $row[$key] = (int) $row[$key];
        }
    }

    $cached = $row;
    return $row;
}


/*
|--------------------------------------------------------------------------
| PASSWORD POLICY
|--------------------------------------------------------------------------
|
| Applies to local accounts only. LDAP-sourced logins never reach this --
| those passwords are validated by the directory on every bind and are
| never stored or evaluated here.
*/

/**
 * @return string[] Human-readable failures; empty array means the password
 *                  satisfies the configured policy.
 */
function validatePasswordPolicy(PDO $pdo, string $password): array
{
    $policy = getSecuritySettings($pdo);
    $errors = [];

    $minLength = max(1, (int) $policy['password_min_length']);

    // strlen, not mb_strlen: the requirement is a floor on entropy-bearing
    // characters, and counting bytes never under-counts.
    if (strlen($password) < $minLength) {
        $errors[] = "Password must be at least {$minLength} characters long.";
    }

    if ((int) $policy['password_require_upper'] === 1 && !preg_match('/[A-Z]/', $password)) {
        $errors[] = 'Password must contain at least one uppercase letter.';
    }

    if ((int) $policy['password_require_lower'] === 1 && !preg_match('/[a-z]/', $password)) {
        $errors[] = 'Password must contain at least one lowercase letter.';
    }

    if ((int) $policy['password_require_number'] === 1 && !preg_match('/[0-9]/', $password)) {
        $errors[] = 'Password must contain at least one number.';
    }

    if ((int) $policy['password_require_symbol'] === 1 && !preg_match('/[^A-Za-z0-9]/', $password)) {
        $errors[] = 'Password must contain at least one symbol.';
    }

    return $errors;
}

/**
 * One-line description of the active policy, for display next to a
 * password field so the rules are known before the form is submitted.
 */
function describePasswordPolicy(PDO $pdo): string
{
    $policy = getSecuritySettings($pdo);

    $parts = ['at least ' . (int) $policy['password_min_length'] . ' characters'];

    if ((int) $policy['password_require_upper'] === 1)  { $parts[] = 'an uppercase letter'; }
    if ((int) $policy['password_require_lower'] === 1)  { $parts[] = 'a lowercase letter'; }
    if ((int) $policy['password_require_number'] === 1) { $parts[] = 'a number'; }
    if ((int) $policy['password_require_symbol'] === 1) { $parts[] = 'a symbol'; }

    if (count($parts) === 1) {
        return 'Must be ' . $parts[0] . '.';
    }

    $last = array_pop($parts);
    return 'Must contain ' . implode(', ', $parts) . ' and ' . $last . '.';
}


/*
|--------------------------------------------------------------------------
| LOGIN LOCKOUT
|--------------------------------------------------------------------------
|
| Attempts are keyed on the submitted identifier AND the client IP. Keying
| on the identifier alone lets one attacker lock a known account out on
| purpose (a denial-of-service against that user); keying on IP alone is
| defeated by rotating source addresses. Requiring both to match the
| threshold narrows each failure mode.
*/

function clientIpAddress(): string
{
    // REMOTE_ADDR only. X-Forwarded-For is attacker-controlled unless a
    // trusted proxy is known to rewrite it, and trusting it blindly would
    // let anyone evade the lockout by sending a fresh header each attempt.
    return (string) ($_SERVER['REMOTE_ADDR'] ?? '');
}

function recordLoginAttempt(PDO $pdo, string $identifier, bool $success): void
{
    try {
        $pdo->prepare("
            INSERT INTO login_attempts (identifier, ip_address, success, attempted_at, user_agent)
            VALUES (?, ?, ?, ?, ?)
        ")->execute([
            strtolower(trim($identifier)),
            clientIpAddress(),
            $success ? 1 : 0,
            time(),
            substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? ''), 0, 255),
        ]);

        // A successful login clears that identifier's failure history, so a
        // user who eventually gets it right doesn't stay near the threshold.
        if ($success) {
            $pdo->prepare("DELETE FROM login_attempts WHERE identifier = ? AND success = 0")
                ->execute([strtolower(trim($identifier))]);
        }
    } catch (Throwable $e) {
        error_log('Unable to record login attempt: ' . $e->getMessage());
    }
}

/**
 * @return array{locked:bool, seconds_remaining:int, failures:int}
 */
function checkLoginLockout(PDO $pdo, string $identifier): array
{
    $policy = getSecuritySettings($pdo);

    $result = ['locked' => false, 'seconds_remaining' => 0, 'failures' => 0];

    if ((int) $policy['lockout_enabled'] !== 1) {
        return $result;
    }

    $threshold = max(1, (int) $policy['lockout_threshold']);
    $windowSec = max(60, (int) $policy['lockout_window_minutes'] * 60);
    $lockSec   = max(60, (int) $policy['lockout_duration_minutes'] * 60);

    try {
        $stmt = $pdo->prepare("
            SELECT COUNT(*) AS failures, COALESCE(MAX(attempted_at), 0) AS last_attempt
            FROM login_attempts
            WHERE success = 0
              AND attempted_at >= ?
              AND identifier = ?
              AND ip_address = ?
        ");
        $stmt->execute([time() - $windowSec, strtolower(trim($identifier)), clientIpAddress()]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC) ?: ['failures' => 0, 'last_attempt' => 0];

        $result['failures'] = (int) $row['failures'];

        if ($result['failures'] >= $threshold) {
            $unlocksAt = (int) $row['last_attempt'] + $lockSec;
            if ($unlocksAt > time()) {
                $result['locked'] = true;
                $result['seconds_remaining'] = $unlocksAt - time();
            }
        }
    } catch (Throwable $e) {
        // Fail open rather than locking every user out of a working system
        // because of a query error -- the failure is logged for follow-up.
        error_log('Unable to evaluate login lockout: ' . $e->getMessage());
    }

    return $result;
}

/**
 * Housekeeping: drop attempt rows older than a day. Called opportunistically
 * from the login page so the table cannot grow without bound in a
 * deployment that has no cron.
 */
function pruneLoginAttempts(PDO $pdo): void
{
    try {
        $pdo->prepare("DELETE FROM login_attempts WHERE attempted_at < ?")
            ->execute([time() - 86400]);
    } catch (Throwable $e) {
        error_log('Unable to prune login_attempts: ' . $e->getMessage());
    }
}
