<?php
/**
 * LDAPS authentication.
 *
 * Never stores or compares the directory password locally -- every login
 * for an LDAP-sourced account does a live bind against the directory.
 * A first-time successful LDAP login creates a users row with
 * is_approved=0 (see index.php), which then goes through the exact same
 * admin approval flow in users.php that local signup.php registrations
 * already use.
 */

/**
 * Environment variable overrides, same idea as MAIL_ENV_OVERRIDES --
 * lets a container inject the service account password (in particular)
 * without it ever being typed into the Settings form or stored in the DB.
 */
const LDAP_ENV_OVERRIDES = [
    'host' => 'LDAP_HOST',
    'port' => 'LDAP_PORT',
    'encryption' => 'LDAP_ENCRYPTION',
    'base_dn' => 'LDAP_BASE_DN',
    'bind_dn' => 'LDAP_BIND_DN',
    'bind_password' => 'LDAP_BIND_PASSWORD',
];

function getLdapEnvOverrides(): array
{
    $active = [];
    foreach (LDAP_ENV_OVERRIDES as $column => $envVar) {
        $value = getenv($envVar);
        if ($value !== false && trim((string) $value) !== '') {
            $active[$column] = $envVar;
        }
    }
    return $active;
}

function getLdapSettingsRow(PDO $pdo): array
{
    $row = $pdo->query("SELECT * FROM ldap_settings WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        $row = [
            'is_enabled' => 0, 'host' => '', 'port' => 636, 'encryption' => 'ldaps',
            'base_dn' => '', 'bind_dn' => '', 'bind_password' => '', 'ca_cert' => '',
            'verify_certificate' => 1, 'user_search_filter' => '(sAMAccountName=%s)',
            'default_role' => 'Read-only', 'updated_by' => null, 'updated_at' => null,
        ];
    }

    foreach (getLdapEnvOverrides() as $column => $envVar) {
        $row[$column] = getenv($envVar);
    }

    return $row;
}

function isLdapEnabled(PDO $pdo): bool
{
    $row = getLdapSettingsRow($pdo);
    return (int) $row['is_enabled'] === 1 && trim((string) $row['host']) !== '';
}

/**
 * Where the CA certificate PEM gets written for libldap to read at
 * connect time. Colocated with the SQLite database rather than a fixed
 * path under config/, so it lives on the same persistent volume in a
 * container deployment (see APP_DB_PATH in config/db.php) without
 * needing a volume of its own.
 */
function getLdapCaCertPath(): string
{
    global $db_file;
    return dirname($db_file) . '/ldap_ca.pem';
}

/**
 * Writes the configured CA cert to disk if there's one configured.
 * Returns the file path, or null if no cert is configured.
 */
function ensureLdapCaCertFile(array $ldapSettings): ?string
{
    $pem = trim((string) ($ldapSettings['ca_cert'] ?? ''));
    if ($pem === '') {
        return null;
    }

    $path = getLdapCaCertPath();

    // Rewriting on every auth attempt is cheap (this is a small text file)
    // and guarantees the file always matches whatever's currently saved,
    // even right after an admin updates it in Settings.
    file_put_contents($path, $pem);

    return $path;
}

/**
 * Live LDAP authentication: binds with the service account, searches for
 * the user by the configured filter, then re-binds as that user's DN with
 * the password they submitted -- the only real credential check that
 * happens. Returns the directory attributes on success; the caller
 * decides what to do with them (create/update a users row).
 *
 * @return array{success:bool, message:string, attributes?:array{samaccountname:string,username:string,email:string,first_name:string,last_name:string}}
 */
function authenticateAgainstLdap(PDO $pdo, string $username, string $password): array
{
    if (!extension_loaded('ldap')) {
        return ['success' => false, 'message' => 'The PHP ldap extension is not installed on this server.'];
    }

    $settings = getLdapSettingsRow($pdo);

    if ((int) $settings['is_enabled'] !== 1 || trim((string) $settings['host']) === '') {
        return ['success' => false, 'message' => 'LDAP authentication is not enabled.'];
    }

    if ($username === '' || $password === '') {
        return ['success' => false, 'message' => 'Username and password are required.'];
    }

    $host = (string) $settings['host'];
    $port = (int) $settings['port'];
    $encryption = (string) $settings['encryption']; // 'ldaps' or 'starttls'
    $baseDn = (string) $settings['base_dn'];
    $bindDn = (string) $settings['bind_dn'];
    $bindPassword = (string) $settings['bind_password'];
    $verifyCert = (int) $settings['verify_certificate'] === 1;

    $caCertPath = ensureLdapCaCertFile($settings);

    // These are GLOBAL libldap options -- OpenLDAP initializes its TLS
    // context once per process on first use, so per-connection overrides
    // set after that point are unreliable. Must be set before ldap_connect().
    if ($caCertPath !== null) {
        @ldap_set_option(null, LDAP_OPT_X_TLS_CACERTFILE, $caCertPath);
    }
    @ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, $verifyCert ? LDAP_OPT_X_TLS_DEMAND : LDAP_OPT_X_TLS_ALLOW);

    $uri = ($encryption === 'starttls' ? 'ldap://' : 'ldaps://') . $host . ':' . $port;

    $conn = @ldap_connect($uri);

    if ($conn === false) {
        return ['success' => false, 'message' => "Could not initialize connection to {$uri}."];
    }

    ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
    ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, 10);

    if ($encryption === 'starttls') {
        if (!@ldap_start_tls($conn)) {
            $error = ldap_error($conn);
            @ldap_unbind($conn);
            return ['success' => false, 'message' => "STARTTLS negotiation failed: {$error}"];
        }
    }

    // Step 1: bind with the service account to search for the user's DN.
    if (!@ldap_bind($conn, $bindDn, $bindPassword)) {
        $error = ldap_error($conn);
        @ldap_unbind($conn);
        return ['success' => false, 'message' => "Service account bind failed: {$error}"];
    }

    $escapedUsername = ldap_escape($username, '', LDAP_ESCAPE_FILTER);
    $filter = str_replace('%s', $escapedUsername, (string) $settings['user_search_filter']);

    $search = @ldap_search($conn, $baseDn, $filter, ['samaccountname', 'userprincipalname', 'mail', 'givenname', 'sn']);

    if ($search === false) {
        $error = ldap_error($conn);
        @ldap_unbind($conn);
        return ['success' => false, 'message' => "Directory search failed: {$error}"];
    }

    $entries = ldap_get_entries($conn, $search);

    if ($entries['count'] === 0) {
        @ldap_unbind($conn);
        return ['success' => false, 'message' => 'User not found in directory.'];
    }

    $entry = $entries[0];
    $userDn = $entry['dn'];

    // Service account bind is done with -- rebind as the actual user with
    // their submitted password. This is the only real password check;
    // it either matches what's in the directory or it doesn't.
    if (!@ldap_bind($conn, $userDn, $password)) {
        @ldap_unbind($conn);
        return ['success' => false, 'message' => 'Invalid username or password.'];
    }

    @ldap_unbind($conn);

    $attributes = [
        'samaccountname' => $entry['samaccountname'][0] ?? $username,
        'username' => $entry['userprincipalname'][0] ?? ($entry['samaccountname'][0] ?? $username),
        'email' => $entry['mail'][0] ?? '',
        'first_name' => $entry['givenname'][0] ?? ($entry['samaccountname'][0] ?? $username),
        'last_name' => $entry['sn'][0] ?? '',
    ];

    return ['success' => true, 'message' => 'Authenticated.', 'attributes' => $attributes];
}

/**
 * Service-account-only connectivity check for the Settings page's "Test
 * LDAP Connection" button -- verifies host/port/TLS/bind_dn all work,
 * and optionally that a given username can be found, without needing a
 * real end-user password.
 *
 * @return array{success:bool, message:string}
 */
function testLdapConnection(PDO $pdo, string $testUsername = ''): array
{
    if (!extension_loaded('ldap')) {
        return ['success' => false, 'message' => 'The PHP ldap extension is not installed on this server.'];
    }

    $settings = getLdapSettingsRow($pdo);

    if (trim((string) $settings['host']) === '') {
        return ['success' => false, 'message' => 'Set a host first.'];
    }

    $host = (string) $settings['host'];
    $port = (int) $settings['port'];
    $encryption = (string) $settings['encryption'];
    $bindDn = (string) $settings['bind_dn'];
    $bindPassword = (string) $settings['bind_password'];
    $verifyCert = (int) $settings['verify_certificate'] === 1;

    $caCertPath = ensureLdapCaCertFile($settings);

    if ($caCertPath !== null) {
        @ldap_set_option(null, LDAP_OPT_X_TLS_CACERTFILE, $caCertPath);
    }
    @ldap_set_option(null, LDAP_OPT_X_TLS_REQUIRE_CERT, $verifyCert ? LDAP_OPT_X_TLS_DEMAND : LDAP_OPT_X_TLS_ALLOW);

    $uri = ($encryption === 'starttls' ? 'ldap://' : 'ldaps://') . $host . ':' . $port;

    $conn = @ldap_connect($uri);
    if ($conn === false) {
        return ['success' => false, 'message' => "Could not initialize connection to {$uri}."];
    }

    ldap_set_option($conn, LDAP_OPT_PROTOCOL_VERSION, 3);
    ldap_set_option($conn, LDAP_OPT_REFERRALS, 0);
    ldap_set_option($conn, LDAP_OPT_NETWORK_TIMEOUT, 10);

    if ($encryption === 'starttls' && !@ldap_start_tls($conn)) {
        $error = ldap_error($conn);
        @ldap_unbind($conn);
        return ['success' => false, 'message' => "STARTTLS negotiation failed: {$error}"];
    }

    if (!@ldap_bind($conn, $bindDn, $bindPassword)) {
        $error = ldap_error($conn);
        @ldap_unbind($conn);
        return ['success' => false, 'message' => "Connected, but the service account bind failed: {$error}"];
    }

    if (trim($testUsername) === '') {
        @ldap_unbind($conn);
        return ['success' => true, 'message' => 'Connected and service account bind succeeded.'];
    }

    $escapedUsername = ldap_escape($testUsername, '', LDAP_ESCAPE_FILTER);
    $filter = str_replace('%s', $escapedUsername, (string) $settings['user_search_filter']);
    $search = @ldap_search($conn, (string) $settings['base_dn'], $filter, ['samaccountname', 'mail']);

    if ($search === false) {
        $error = ldap_error($conn);
        @ldap_unbind($conn);
        return ['success' => false, 'message' => "Bind succeeded, but the search failed: {$error}"];
    }

    $entries = ldap_get_entries($conn, $search);
    @ldap_unbind($conn);

    if ($entries['count'] === 0) {
        return ['success' => false, 'message' => "Bind succeeded, but no entry matched \"{$testUsername}\" with filter {$filter}."];
    }

    $mail = $entries[0]['mail'][0] ?? '(no mail attribute)';
    return ['success' => true, 'message' => "Found: {$entries[0]['dn']} — mail: {$mail}"];
}
