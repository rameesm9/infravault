<?php

/*
|--------------------------------------------------------------------------
| SmtpMailer
|--------------------------------------------------------------------------
| A minimal, dependency-free SMTP client using plain PHP streams.
| No Composer / PHPMailer required — works fully offline as long as the
| SMTP host given in config/mail_config.php is reachable on your network.
|
| Supports: plaintext auth (AUTH LOGIN), STARTTLS, and implicit SSL.
|--------------------------------------------------------------------------
*/

class SmtpMailer
{
    private string $host;
    private int $port;
    private string $username;
    private string $password;
    private string $encryption; // '', 'tls', or 'ssl'
    private string $fromEmail;
    private string $fromName;
    private int $timeout;

    public function __construct(array $config)
    {
        $this->host = (string) ($config['host'] ?? 'localhost');
        $this->port = (int) ($config['port'] ?? 25);
        $this->username = (string) ($config['username'] ?? '');
        $this->password = (string) ($config['password'] ?? '');
        $this->encryption = strtolower((string) ($config['encryption'] ?? ''));
        $this->fromEmail = (string) ($config['from_email'] ?? 'noreply@example.com');
        $this->fromName = (string) ($config['from_name'] ?? 'InfraVault');
        $this->timeout = (int) ($config['timeout'] ?? 15);
    }

    /**
     * @return array{success: bool, message: string}
     */
    public function send(string $toEmail, string $toName, string $subject, string $htmlBody, ?string $textBody = null): array
    {
        $socket = null;

        try {
            if ($toEmail === '' || !filter_var($toEmail, FILTER_VALIDATE_EMAIL)) {
                throw new RuntimeException("Invalid recipient address: {$toEmail}");
            }

            $transport = $this->encryption === 'ssl' ? 'ssl://' : '';

            $socket = @stream_socket_client(
                $transport . $this->host . ':' . $this->port,
                $errno,
                $errstr,
                $this->timeout
            );

            if (!$socket) {
                throw new RuntimeException("Could not connect to SMTP server {$this->host}:{$this->port} — {$errstr} ({$errno})");
            }

            stream_set_timeout($socket, $this->timeout);

            $this->expect($socket, 220);

            $localHost = gethostname() ?: 'localhost';

            $this->command($socket, 'EHLO ' . $localHost, 250);

            if ($this->encryption === 'tls') {

                $this->command($socket, 'STARTTLS', 220);

                $cryptoMethod = STREAM_CRYPTO_METHOD_TLS_CLIENT;

                if (defined('STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT')) {
                    $cryptoMethod |= STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT;
                }

                if (!stream_socket_enable_crypto($socket, true, $cryptoMethod)) {
                    throw new RuntimeException('Unable to negotiate TLS encryption with the SMTP server.');
                }

                $this->command($socket, 'EHLO ' . $localHost, 250);
            }

            if ($this->username !== '') {
                $this->command($socket, 'AUTH LOGIN', 334);
                $this->command($socket, base64_encode($this->username), 334);
                $this->command($socket, base64_encode($this->password), 235);
            }

            $this->command($socket, 'MAIL FROM:<' . $this->fromEmail . '>', 250);
            $this->command($socket, 'RCPT TO:<' . $toEmail . '>', 250);
            $this->command($socket, 'DATA', 354);

            $message = $this->buildMessage($toEmail, $toName, $subject, $htmlBody, $textBody);

            // Dot-stuff any line that starts with a lone '.' per RFC 5321.
            $message = preg_replace('/^\./m', '..', $message);

            fwrite($socket, $message . "\r\n.\r\n");

            $this->expect($socket, 250);

            $this->command($socket, 'QUIT', 221);

            return ['success' => true, 'message' => 'Sent'];

        } catch (Throwable $e) {

            return ['success' => false, 'message' => $e->getMessage()];

        } finally {

            if (is_resource($socket)) {
                fclose($socket);
            }
        }
    }

    private function buildMessage(string $toEmail, string $toName, string $subject, string $htmlBody, ?string $textBody): string
    {
        $boundary = 'iv_' . bin2hex(random_bytes(10));

        $headers = [
            'From: ' . $this->encodeHeaderValue($this->fromName) . ' <' . $this->fromEmail . '>',
            'To: ' . ($toName !== '' ? $this->encodeHeaderValue($toName) . " <{$toEmail}>" : $toEmail),
            'Subject: ' . $this->encodeHeaderValue($subject),
            'Date: ' . date('r'),
            'Message-ID: <' . bin2hex(random_bytes(16)) . '@' . (gethostname() ?: 'infravault') . '>',
            'MIME-Version: 1.0',
            'Content-Type: multipart/alternative; boundary="' . $boundary . '"',
        ];

        $plain = $textBody ?? trim(strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $htmlBody)));

        $body = "--{$boundary}\r\n";
        $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
        $body .= $plain . "\r\n\r\n";

        $body .= "--{$boundary}\r\n";
        $body .= "Content-Type: text/html; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: 8bit\r\n\r\n";
        $body .= $htmlBody . "\r\n\r\n";

        $body .= "--{$boundary}--";

        return implode("\r\n", $headers) . "\r\n\r\n" . $body;
    }

    private function encodeHeaderValue(string $value): string
    {
        if (preg_match('/^[\x20-\x7E]*$/', $value)) {
            return $value;
        }

        return '=?UTF-8?B?' . base64_encode($value) . '?=';
    }

    /**
     * @param resource $socket
     */
    private function command($socket, string $command, int $expectedCode): string
    {
        fwrite($socket, $command . "\r\n");

        return $this->expect($socket, $expectedCode);
    }

    /**
     * @param resource $socket
     */
    private function expect($socket, int $expectedCode): string
    {
        $response = '';

        while (($line = fgets($socket, 515)) !== false) {

            $response .= $line;

            // A space (not a dash) in position 3 marks the final line of
            // a (possibly multi-line) SMTP response.
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }

            if ($line === '') {
                break;
            }
        }

        $meta = stream_get_meta_data($socket);

        if (!empty($meta['timed_out'])) {
            throw new RuntimeException('SMTP connection timed out waiting for a response.');
        }

        $code = (int) substr($response, 0, 3);

        if ($code !== $expectedCode) {
            throw new RuntimeException("SMTP error — expected {$expectedCode}, server said: " . trim($response));
        }

        return $response;
    }
}
