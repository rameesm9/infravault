<?php
/**
 * Minimal mbstring polyfill.
 *
 * WHY
 * ---
 * The PHP running this application does not necessarily have ext-mbstring
 * loaded. Calling mb_* without it is a fatal error, not a warning -- and a
 * fatal part-way down a page stops the render *before the footer*, so the
 * layout is truncated and assets/js/sidebar.js never loads. The visible
 * symptom is "the sidebar stopped working", which gives no hint that the
 * real cause is a missing string function three panels up the page.
 *
 * app_layout.php, vulnerability_report.php and vulnerability_upload.php
 * all called mb_* functions unguarded.
 *
 * These implementations are deliberately conservative: they are correct
 * for UTF-8 and for single-byte input, which is all this application
 * handles. If the real extension is present, nothing here is defined and
 * the native functions are used instead.
 */

if (!function_exists('mb_strlen')) {
    function mb_strlen(?string $string, ?string $encoding = null): int
    {
        // Counts characters, not bytes: a UTF-8 continuation byte is
        // 10xxxxxx, so skipping those counts code points.
        return (int) preg_match_all('/./us', (string) $string);
    }
}

if (!function_exists('mb_substr')) {
    function mb_substr(?string $string, int $start, ?int $length = null, ?string $encoding = null): string
    {
        $chars = preg_split('//u', (string) $string, -1, PREG_SPLIT_NO_EMPTY);

        if ($chars === false) {
            // Not valid UTF-8; fall back to byte semantics rather than
            // returning nothing.
            return $length === null
                ? substr((string) $string, $start)
                : substr((string) $string, $start, $length);
        }

        $slice = $length === null
            ? array_slice($chars, $start)
            : array_slice($chars, $start, $length);

        return implode('', $slice);
    }
}

if (!function_exists('mb_strimwidth')) {
    function mb_strimwidth(?string $string, int $start, int $width, string $trimMarker = '', ?string $encoding = null): string
    {
        $string = (string) $string;
        $chars = preg_split('//u', $string, -1, PREG_SPLIT_NO_EMPTY);

        if ($chars === false) {
            $chars = str_split($string);
        }

        $chars = array_slice($chars, $start);

        if (count($chars) <= $width) {
            return implode('', $chars);
        }

        // The trim marker counts toward the requested width, matching the
        // native function's behaviour.
        $markerLen = (int) preg_match_all('/./us', $trimMarker);
        $keep = max(0, $width - $markerLen);

        return implode('', array_slice($chars, 0, $keep)) . $trimMarker;
    }
}

if (!function_exists('mb_convert_encoding')) {
    function mb_convert_encoding(?string $string, string $toEncoding, $fromEncoding = null): string
    {
        $string = (string) $string;

        if (function_exists('iconv')) {
            $from = is_array($fromEncoding) ? ($fromEncoding[0] ?? 'UTF-8') : ($fromEncoding ?: 'UTF-8');
            // //IGNORE so one bad byte cannot blank the whole value.
            $converted = @iconv($from, $toEncoding . '//IGNORE', $string);
            if ($converted !== false) {
                return $converted;
            }
        }

        // No iconv either: strip anything that is not valid UTF-8 rather
        // than emitting bytes that will break the page.
        return (string) preg_replace('/[^\x00-\x7F\xC2-\xF4][\x80-\xBF]*/u', '', $string);
    }
}

if (!function_exists('mb_strtolower')) {
    function mb_strtolower(?string $string, ?string $encoding = null): string
    {
        return strtolower((string) $string);
    }
}

if (!function_exists('mb_strtoupper')) {
    function mb_strtoupper(?string $string, ?string $encoding = null): string
    {
        return strtoupper((string) $string);
    }
}
