<?php
/**
 * Shared logic for sending due reminder-notification emails.
 *
 * Used by both reminder_notification_cron.php (one-shot, for a traditional
 * crontab/systemd timer) and reminder_notification_daemon.php (a
 * self-contained long-running loop, for container deployments with no
 * cron daemon available) so the actual send/mark-sent behavior lives in
 * exactly one place.
 */

require_once __DIR__ . '/mail-helpers.php';

/**
 * Recipients for a reminder: its owner (needs owner_email/owner_first_name/
 * owner_last_name joined in, as both call sites below do) plus everyone
 * listed in "Additional Emails" (comma/semicolon/whitespace separated,
 * validated, deduped).
 *
 * @return array<string,string> email => display name (name may be '')
 */
function buildReminderRecipients(array $row): array
{
    $recipients = [];

    if (!empty($row['owner_email'])) {
        $ownerName = trim(($row['owner_first_name'] ?? '') . ' ' . ($row['owner_last_name'] ?? ''));
        $recipients[$row['owner_email']] = $ownerName;
    }

    $additional = preg_split('/[,;\s]+/', (string) ($row['additional_emails'] ?? ''), -1, PREG_SPLIT_NO_EMPTY);
    foreach ($additional as $email) {
        $email = trim($email);
        if ($email !== '' && filter_var($email, FILTER_VALIDATE_EMAIL) && !isset($recipients[$email])) {
            $recipients[$email] = '';
        }
    }

    return $recipients;
}

/**
 * Finds reminders whose scheduled date/time has arrived and haven't been
 * emailed yet, sends to the owner + "Additional Emails", and marks each
 * one as sent (best-effort: a failed recipient doesn't block marking the
 * reminder done, so a bad address can't cause it to be retried forever).
 *
 * @return array{considered:int, sent:int, failed:int, log:string[]}
 */
function checkAndSendDueReminders(PDO $pdo): array
{
    $log = [];

    registerMailModule($pdo, 'reminder_notifications', 'Reminders & Notes Email Notifications');

    if (!isMailModuleEnabled($pdo, 'reminder_notifications')) {
        return ['considered' => 0, 'sent' => 0, 'failed' => 0, 'log' => ['Reminder email is disabled (globally or for this module) in Settings.']];
    }

    // Naive string comparison against a naive column -- both sides are
    // wall-clock time in the timezone config/db.php sets via
    // date_default_timezone_set(), not SQLite's (always-UTC) CURRENT_TIMESTAMP.
    $now = date('Y-m-d H:i:s');

    $stmt = $pdo->prepare("
        SELECT r.*, u.first_name AS owner_first_name, u.last_name AS owner_last_name, u.email AS owner_email
        FROM reminders r
        LEFT JOIN users u ON u.id = r.user_id
        WHERE r.reminder_date <= ?
          AND r.reminder_sent_at IS NULL
    ");
    $stmt->execute([$now]);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        return ['considered' => 0, 'sent' => 0, 'failed' => 0, 'log' => []];
    }

    $sent = 0;
    $failed = 0;

    foreach ($rows as $row) {

        $recipients = buildReminderRecipients($row);

        if (empty($recipients)) {
            $log[] = "[SKIP] Reminder #{$row['id']} ({$row['title']}) — no valid recipient email addresses.";
            $pdo->prepare("UPDATE reminders SET reminder_sent_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$row['id']]);
            continue;
        }

        $subject = "Reminder: {$row['title']}";

        $html = '<p>' . nl2br(htmlspecialchars((string) $row['message'], ENT_QUOTES, 'UTF-8')) . '</p>'
            . '<p><strong>Scheduled for:</strong> ' . htmlspecialchars((string) $row['reminder_date'], ENT_QUOTES, 'UTF-8') . '</p>'
            . '<p style="color:#64748b;font-size:12px;">Sent by InfraVault Reminders &amp; Notes.</p>';

        $rowFailures = 0;

        foreach ($recipients as $email => $name) {
            $result = sendAppMail($pdo, 'reminder_notifications', $email, $name, $subject, $html);

            if ($result['success']) {
                $log[] = "[OK]   Reminder #{$row['id']} ({$row['title']}) — sent to {$email}.";
            } else {
                $log[] = "[FAIL] Reminder #{$row['id']} ({$row['title']}) — {$email}: {$result['message']}";
                $rowFailures++;
            }
        }

        $pdo->prepare("UPDATE reminders SET reminder_sent_at = CURRENT_TIMESTAMP WHERE id = ?")->execute([$row['id']]);

        if ($rowFailures > 0) {
            $failed++;
        } else {
            $sent++;
        }
    }

    return ['considered' => count($rows), 'sent' => $sent, 'failed' => $failed, 'log' => $log];
}
