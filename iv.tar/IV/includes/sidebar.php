<?php

/*
|--------------------------------------------------------------------------
| SIDEBAR
|--------------------------------------------------------------------------
| Uses SQLite permissions table.
|
| can_view = 1  -> show menu item
| can_view = 0  -> hide menu item
|
|--------------------------------------------------------------------------
*/

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . '/../config/db.php';


/*
|--------------------------------------------------------------------------
| CURRENT PAGE
|--------------------------------------------------------------------------
*/

/*
| Deliberately NOT named $current_page.
|
| This file is included at global scope, part-way down pages that have
| already set up their own state. Several list pages (grc_schedule.php,
| hostname.php, mydata.php, reminders.php) compute a $current_page
| pagination number BEFORE requiring the sidebar, so a generic
| $current_page here silently overwrote that integer with a filename
| string.
|
| On grc_schedule.php that was fatal: the pagination footer multiplies
| $current_page, and "grc_schedule.php" * 20 throws a TypeError in
| PHP 8, killing the render part-way through -- which dropped the
| page's entire <script> block and left the markup truncated, so no
| button and no sidebar link responded.
*/
$sidebar_current_page = basename($_SERVER['PHP_SELF']);


/*
|--------------------------------------------------------------------------
| CURRENT USER ROLE
|--------------------------------------------------------------------------
*/

$current_role = trim($_SESSION['role'] ?? '');


/*
|--------------------------------------------------------------------------
| CHECK PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
|
| Example:
|
| canViewPage('asset')
|
| will check:
|
| role = current user's role
| page_key = asset
| can_view = 1
|
|--------------------------------------------------------------------------
*/

function canViewPage($pageKey)
{
    global $pdo, $current_role;

    /*
    --------------------------------------------------------------
    | No logged-in role
    --------------------------------------------------------------
    */

    if ($current_role === '') {
        return false;
    }


    /*
    --------------------------------------------------------------
    | Admin is NOT automatically allowed.
    |
    | This is intentional.
    |
    | If you uncheck View for Admin in permission.php,
    | the item will also disappear for Admin.
    --------------------------------------------------------------
    */

    static $permissions = null;


    /*
    --------------------------------------------------------------
    | Load permissions once
    --------------------------------------------------------------
    */

    if ($permissions === null) {

        $permissions = [];

        try {

            $stmt = $pdo->prepare("
                SELECT
                    page_key,
                    can_view
                FROM permissions
                WHERE role = ?
            ");

            $stmt->execute([
                $current_role
            ]);


            foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {

                $permissions[
                    $row['page_key']
                ] = (int)$row['can_view'];

            }

        } catch (Throwable $e) {

            /*
            ------------------------------------------------------
            | If permissions table/query fails,
            | hide protected menu items.
            ------------------------------------------------------
            */

            return false;
        }
    }


    /*
    --------------------------------------------------------------
    | Return permission
    --------------------------------------------------------------
    */

    return isset($permissions[$pageKey])
        && $permissions[$pageKey] === 1;
}


/*
|--------------------------------------------------------------------------
| CHECK IF ANY PAGE IN A MENU GROUP IS VISIBLE
|--------------------------------------------------------------------------
*/

function canViewAnyPage(array $pageKeys)
{
    foreach ($pageKeys as $pageKey) {

        if (canViewPage($pageKey)) {
            return true;
        }

    }

    return false;
}

?>


<aside id="sidebar" class="sidebar">


    <!-- =====================================================
         Sidebar Header
    ====================================================== -->

    <div class="sidebar-top">

        <button
            id="sidebarToggle"
            title="Toggle Sidebar"
        >
            ☰
        </button>


        <img
            src="assets/images/infravault-logo.svg"
            alt="InfraVault"
        >


        <span class="sidebar-title">
            InfraVault
        </span>

    </div>


    <nav>


        <!-- =====================================================
             DASHBOARD
        ====================================================== -->

        <a
            href="home.php"
            class="nav-item <?= $sidebar_current_page == 'home.php' ? 'active' : ''; ?>"
        >

            <span class="nav-icon">

                <svg
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                >

                    <path d="M3 13h8V3H3z"/>

                    <path d="M13 21h8v-8h-8z"/>

                    <path d="M13 3h8v6h-8z"/>

                    <path d="M3 17h8v4H3z"/>

                </svg>

            </span>


            <span class="nav-text">
                Dashboard
            </span>

        </a>


        <!-- =====================================================
             INVENTORY
        ====================================================== -->

        <?php

        $inventoryPages = [
            'asset',
            'inventory',
            'license_warranty',
            'ip',
            'ownership',
            'uid_gid',
            'handover',
            'decommission',
            'builds',
            'container_platform',
            'oracle_db',
            'dr_mapping',
            'major_layouts'
        ];

        ?>

        <?php if (canViewAnyPage($inventoryPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <path d="M21 16V8"/>

                        <path d="M3 8v8"/>

                        <path d="M12 3v18"/>

                        <path d="M3 8l9-5 9 5-9 5-9-5z"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Inventory
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php if (canViewPage('asset')): ?>

                <a href="asset.php">

                    <span class="nav-text">
                        Asset Management
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('inventory')): ?>

                <a href="inventory.php">

                    <span class="nav-text">
                        Server Inventory
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('license_warranty')): ?>

                <a href="license_warranty.php">

                    <span class="nav-text">
                        License and EOL tracking
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('ip')): ?>

                <a href="ip.php">

                    <span class="nav-text">
                        IP Address Management
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('ownership')): ?>

                <a href="ownership.php">

                    <span class="nav-text">
                        Asset Ownership
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('uid_gid')): ?>

                <a href="uid-gid-tracking.php">

                    <span class="nav-text">
                        UID/GID Tracking
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('handover')): ?>

                <a href="handover.php">

                    <span class="nav-text">
                        Asset Handover
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('decommission')): ?>

                <a href="decommission.php">

                    <span class="nav-text">
                        Asset Decommission
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('builds')): ?>

                <a href="builds.php">

                    <span class="nav-text">
                        New Build
                    </span>

                </a>

                <?php endif; ?>


                <?php /* Major Layouts pages -- these were placeholder "#"
                         links until the four modules were built. */ ?>

                <?php if (canViewPage('container_platform')): ?>

                <a href="container_platform.php">

                    <span class="nav-text">
                        Container Platform
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('oracle_db')): ?>

                <a href="oracle_db.php">

                    <span class="nav-text">
                        Oracle Databases
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('dr_mapping')): ?>

                <a href="dr_mapping.php">

                    <span class="nav-text">
                        Production / DR Mapping
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('major_layouts')): ?>

                <a href="app_layout.php">

                    <span class="nav-text">
                        Application Layout
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             VULNERABILITY & CONTROLS
        ====================================================== -->

        <?php

        $vulnerabilityPages = [
            'patching',
            'critical_exploitable',
            'grc_schedule',
            'vulnerabilities',
            'compliance',
            'patch'
        ];

        ?>

        <?php if (canViewAnyPage($vulnerabilityPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Vulnerability & Controls
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php if (canViewPage('patching')): ?>

                <a href="patching.php">

                    <span class="nav-text">
                        Quarterly Patching
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('critical_exploitable')): ?>

                <a href="#">

                    <span class="nav-text">
                        Critical Exploitable
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('grc_schedule')): ?>

                <a href="grc_schedule.php">

                    <span class="nav-text">
                        GRC Schedule
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('vulnerabilities')): ?>

                <a href="vulnerabilities.php">

                    <span class="nav-text">
                        DMZ Assessment
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('compliance')): ?>

                <a href="compliance.php">

                    <span class="nav-text">
                        Compliance
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('patch')): ?>

                <a href="patch.php">

                    <span class="nav-text">
                        Exception Register
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             RUNBOOK
        ====================================================== -->

        <?php

        $runbookPages = [
            'sop',
            'knowledge',
            'known_issues'
        ];

        ?>

        <?php if (canViewAnyPage($runbookPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <path d="M4 19h16"/>

                        <path d="M4 5h16"/>

                        <path d="M8 5v14"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Runbook
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php if (canViewPage('sop')): ?>

                <a href="sop-summary.php">

                    <span class="nav-text">
                        SOP
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('knowledge')): ?>

                <a href="knowledge-summary.php">

                    <span class="nav-text">
                        Knowledge Base
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('known_issues')): ?>

                <a href="known-issues-summary.php">

                    <span class="nav-text">
                        Known Issues
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             MONITORING
        ====================================================== -->

        <?php

        $monitoringPages = [
            'splunk',
            'bmc_cmdb',
            'grafana'
        ];

        ?>

        <?php if (canViewAnyPage($monitoringPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Monitoring
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php if (canViewPage('splunk')): ?>

                <a href="#">

                    <span class="nav-text">
                        Splunk
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('bmc_cmdb')): ?>

                <a href="#">

                    <span class="nav-text">
                        BMC CMDB
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('grafana')): ?>

                <a href="#">

                    <span class="nav-text">
                        Grafana
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             TEAM WORKSPACE
             -----------------------------------------------------
             The team's own working information -- who is on call,
             who is away, what is being tracked and where the team
             keeps its shortcuts -- as opposed to the infrastructure
             inventory groups above.

             My Data, Special Projects, Ticket Tracking and Quick
             Links moved here from Utilities and Options: Utilities
             is now only the standalone tools (generators,
             calculators, the vault), which is what its name implies.
        ====================================================== -->

        <?php

        $workspacePages = [
            'oncall',
            'leave',
            'special_projects',
            'ticket',
            'links',
            'mydata'
        ];

        ?>

        <?php if (canViewAnyPage($workspacePages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>

                        <circle
                            cx="9"
                            cy="7"
                            r="4"
                        />

                        <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>

                        <path d="M16 3.13a4 4 0 0 1 0 7.75"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Team Workspace
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php if (canViewPage('oncall')): ?>

                <a href="oncall.php">

                    <span class="nav-text">
                        On-Call Tracker
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('leave')): ?>

                <a href="leave.php">

                    <span class="nav-text">
                        Leave Tracker
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('special_projects')): ?>

                <a href="special_projects.php">

                    <span class="nav-text">
                        Special Projects
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('ticket')): ?>

                <a href="tickets.php">

                    <span class="nav-text">
                        Ticket Tracking
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('links')): ?>

                <a href="links.php">

                    <span class="nav-text">
                        Quick Links
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('mydata')): ?>

                <a href="mydata.php">

                    <span class="nav-text">
                        My Data
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             UTILITIES
        ====================================================== -->

        <?php

        $utilityPages = [
            'diagram_designer',
            'org_charts',
            'hostname',
            'subnet_calculator',
            'tcpdump_analyzer',
            'ssl_manager',
            'pasgen',
            'vault',
            'presentation_designer'
        ];

        ?>

        <?php if (canViewAnyPage($utilityPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>

                        <circle
                            cx="12"
                            cy="7"
                            r="4"
                        />

                    </svg>

                </span>


                <span class="nav-text">
                    Utilities
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php /* Separate page key from tickets on purpose: holding
                         ticket access must not imply credential access. */ ?>
                <?php if (canViewPage('vault')): ?>

                <a href="vault.php">

                    <span class="nav-text">
                        Password Vault
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('diagram_designer')): ?>

                <a href="diagram_designer.php">

                    <span class="nav-text">
                        Draw Designs
                    </span>

                </a>

                <?php endif; ?>


                <?php /* Sits next to Draw Designs but is not another canvas:
                         this one builds charts from structured data, so an
                         escalation matrix stays searchable and exportable
                         rather than becoming a picture. */ ?>
                <?php if (canViewPage('org_charts')): ?>

                <a href="org_charts.php">

                    <span class="nav-text">
                        Org &amp; Escalation Charts
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('hostname')): ?>

                <a href="hostname.php">

                    <span class="nav-text">
                        Hostname Generator
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('subnet_calculator')): ?>

                <a href="subnet_calculator.php">

                    <span class="nav-text">
                        Subnet Calculator
                    </span>

                </a>

                <?php endif; ?>
                <?php if (canViewPage('tcpdump_analyzer')): ?>

                <a href="tcpdump_analyzer.php">

                    <span class="nav-text">
                        Tcpdump Analyzer
                    </span>

                </a>

                <?php endif; ?>
                <?php if (canViewPage('pasgen')): ?>

                <a href="pasgen.php">

                    <span class="nav-text">
                        Password Generator
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('ssl_manager')): ?>

                <a href="ssl_manager.php">

                    <span class="nav-text">
                        SSL Certificate Manager
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('presentation_designer')): ?>

                <a href="presentation-designer.php">

                    <span class="nav-text">
                        Presentation Designer
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>


        <!-- =====================================================
             OPTIONS
        ====================================================== -->

        <?php

        $optionPages = [
            'notification',
            'reminders',
            'myprofile',
            'users',
            'help',
            'about'
        ];

        ?>

        <?php if (canViewAnyPage($optionPages)): ?>

        <div class="menu-group">


            <div
                class="menu-header"
                onclick="toggleMenu(this)"
            >

                <span class="nav-icon">

                    <svg
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                    >

                        <circle
                            cx="12"
                            cy="12"
                            r="3"
                        />


                        <path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 0 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.6V21a2 2 0 0 1-4 0v-.2a1.7 1.7 0 0 0-1.1-1.6 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 0 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.6-1H3a2 2 0 0 1 0-4h.2a1.7 1.7 0 0 0 1.6-1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 0 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3h.1a1.7 1.7 0 0 0 1-1.6V3a2 2 0 0 1 4 0v.2a1.7 1.7 0 0 0 1 1.6 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 0 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8v.1a1.7 1.7 0 0 0 1.6 1H21a2 2 0 0 1 0 4h-.2a1.7 1.7 0 0 0-1.4.8z"/>

                    </svg>

                </span>


                <span class="nav-text">
                    Options
                </span>


                <span class="arrow">
                    ▾
                </span>

            </div>


            <div class="submenu">


                <?php /* Special Projects moved to Team Workspace. */ ?>

                <?php if (canViewPage('notification')): ?>

                <a href="notification.php">

                    <span class="nav-text">
                        Notifications
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('reminders')): ?>

                <a href="reminders.php">

                    <span class="nav-text">
                        Reminders and Notes
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('myprofile')): ?>

                <a href="myprofile.php">

                    <span class="nav-text">
                        My Profile
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('users')): ?>

                <a href="users.php">

                    <span class="nav-text">
                        Manage Users
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('settings')): ?>

                <a href="settings.php">

                    <span class="nav-text">
                        Settings
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('help')): ?>

                <a href="help.php">

                    <span class="nav-text">
                        Help Center
                    </span>

                </a>

                <?php endif; ?>


                <?php if (canViewPage('about')): ?>

                <a href="about.php">

                    <span class="nav-text">
                        About
                    </span>

                </a>

                <?php endif; ?>


            </div>

        </div>

        <?php endif; ?>



    </nav>

</aside>
