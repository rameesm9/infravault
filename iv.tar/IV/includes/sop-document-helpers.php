<?php
/**
 * Shared logic for the SOP export document template -- the running header
 * and footer that every exported SOP carries on every page.
 *
 * It is one template for the whole module (edited by an Admin from
 * sop.php?action=header_footer), not a per-SOP field, so the same helpers
 * back both the editor preview in sop.php and the real Word bands written
 * by sop-export.php. Keeping them here is what stops the preview and the
 * exported document from drifting apart.
 *
 * A band is three cells -- left, centre, right -- exactly like a Word
 * header, plus one optional logo placed in one of those cells. Cells are
 * plain text carrying {tokens}; they are escaped on output, so there is no
 * HTML for a caller to inject.
 */

const SOP_BAND_LOGO_HEIGHTS = [
    24 => 'Small',
    40 => 'Medium',
    64 => 'Large',
];

/**
 * The template row, with every field defaulted so callers never have to
 * test for a column that a half-run migration has not added yet.
 */
function getSopDocumentSettings(PDO $pdo): array
{
    $defaults = [
        'show_page_numbers' => 1,
        'updated_by'        => null,
        'updated_at'        => null,
    ];

    foreach (['header', 'footer'] as $band) {
        foreach (['left', 'center', 'right'] as $cell) {
            $defaults["{$band}_{$cell}"] = '';
            $defaults["{$band}_{$cell}_logo"] = '';
            $defaults["{$band}_{$cell}_logo_height"] = 40;
        }
    }

    try {
        $row = $pdo->query("SELECT * FROM sop_document_settings WHERE id = 1 LIMIT 1")
            ->fetch(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        // Table not migrated yet -- exporting must not hard-fail on it.
        return $defaults;
    }

    if (!$row) {
        return $defaults;
    }

    // array_merge would let a NULL column overwrite a usable default.
    foreach ($row as $key => $value) {
        if (array_key_exists($key, $defaults) && $value !== null) {
            $defaults[$key] = $value;
        }
    }

    return $defaults;
}

/**
 * True when the Admin has not composed anything yet, so the export can fall
 * back to an identified default rather than printing an empty banner.
 */
function sopBandIsEmpty(array $settings, string $band): bool
{
    foreach (['left', 'center', 'right'] as $cell) {
        if (trim((string)$settings["{$band}_{$cell}"]) !== ''
            || trim((string)$settings["{$band}_{$cell}_logo"]) !== '') {
            return false;
        }
    }

    return true;
}

/**
 * Applied when the template has never been set up, so a fresh installation
 * still exports a properly identified document.
 */
function sopBandDefaults(array $settings): array
{
    if (sopBandIsEmpty($settings, 'header')) {
        $settings['header_left'] = '{sop_number} — {title}';
        $settings['header_right'] = 'Version {version}';
    }

    if (sopBandIsEmpty($settings, 'footer')) {
        $settings['footer_left'] = 'Internal Use Only — uncontrolled when printed';
    }

    return $settings;
}

/**
 * The {token} values available inside a band cell.
 *
 * Values are HTML-escaped because a rendered cell is emitted as markup.
 * $page_markup swaps in either Word field codes (export) or sample numbers
 * (editor preview).
 */
function sopBandTokens(array $sop, array $page_markup = []): array
{
    $owner = trim(($sop['owner_first'] ?? '') . ' ' . ($sop['owner_last'] ?? ''));
    $reviewer = trim(($sop['assigned_first'] ?? '') . ' ' . ($sop['assigned_last'] ?? ''));

    $updated = !empty($sop['updated_at']) ? strtotime((string)$sop['updated_at']) : false;

    $esc = function ($value) {
        return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
    };

    return [
        '{sop_number}'  => $esc($sop['sop_number'] ?? ''),
        '{title}'       => $esc($sop['title'] ?? ''),
        '{version}'     => $esc($sop['version'] ?? ''),
        '{status}'      => $esc($sop['status'] ?? ''),
        '{category}'    => $esc($sop['category'] ?? ''),
        '{criticality}' => $esc($sop['criticality'] ?? ''),
        '{owner}'       => $esc($owner ?: 'Unassigned'),
        '{reviewer}'    => $esc($reviewer ?: 'Unassigned'),
        '{updated}'     => $esc($updated ? date('d M Y', $updated) : '—'),
        '{date}'        => $esc(date('d M Y')),
        '{pages}'       => $page_markup['pages'] ?? 'N',
        '{page}'        => $page_markup['page'] ?? '1',
    ];
}

/**
 * Renders one cell: the Admin's plain text, escaped, with its {tokens}
 * resolved.
 *
 * Longest token first, or replacing {page} would leave the "s" of {pages}
 * stranded next to the page number.
 */
function renderSopBandCell(string $text, array $tokens): string
{
    $out = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');

    uksort($tokens, function ($a, $b) {
        return strlen($b) <=> strlen($a);
    });

    return str_ireplace(array_keys($tokens), array_values($tokens), $out);
}

/**
 * The <img> for a band's logo, or '' when that cell carries none.
 *
 * $base_url makes the source absolute for the export: Word downloads header
 * images itself over HTTP when the document is opened, so a relative path
 * would resolve against nothing and print as a broken-image box.
 */
function sopBandLogoTag(array $settings, string $band, string $cell, string $base_url = ''): string
{
    $logo = trim((string)($settings["{$band}_{$cell}_logo"] ?? ''));

    if ($logo === '') {
        return '';
    }

    $height = (int)($settings["{$band}_{$cell}_logo_height"] ?? 40);
    $height = isset(SOP_BAND_LOGO_HEIGHTS[$height]) ? $height : 40;

    /*
    | Word must be given BOTH dimensions. With only a height it does not
    | infer the width from the image it downloads -- it stretches the
    | picture across the whole text column, which is what turned an exported
    | logo into a smear the width of the page. So the real pixel size is
    | read here and the width scaled to match the chosen height.
    */
    $width = 0;
    $file = dirname(__DIR__) . '/' . ltrim($logo, '/');

    if (is_file($file)) {
        $size = @getimagesize($file);

        if ($size && (int)$size[1] > 0) {
            $width = (int) round($height * ((int)$size[0] / (int)$size[1]));
        }
    }

    // Unreadable file (a different server, a deleted upload): assume square
    // rather than emitting a height on its own and inviting the stretch.
    if ($width <= 0) {
        $width = $height;
    }

    // A very wide banner would otherwise push the other two cells off the
    // line, so cap the printed width and scale the height with it.
    $max_width = 260;

    if ($width > $max_width) {
        $height = max(1, (int) round($height * ($max_width / $width)));
        $width = $max_width;
    }

    $src = $base_url !== '' ? $base_url . ltrim($logo, '/') : $logo;

    return '<img src="' . htmlspecialchars($src, ENT_QUOTES, 'UTF-8') . '"'
        . ' width="' . $width . '" height="' . $height . '"'
        . ' style="width:' . $width . 'px;height:' . $height . 'px;vertical-align:middle"'
        . ' alt="">';
}

/**
 * One cell, logo and text together, ready to drop into a band.
 */
function renderSopBandContent(array $settings, string $band, string $cell, array $tokens, string $base_url = ''): string
{
    $logo = sopBandLogoTag($settings, $band, $cell, $base_url);
    $text = renderSopBandCell((string)$settings["{$band}_{$cell}"], $tokens);

    if ($logo !== '' && $text !== '') {
        return $logo . '&nbsp;' . $text;
    }

    return $logo . $text;
}
