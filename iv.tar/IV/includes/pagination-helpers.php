<?php
/**
 * Pagination: the per-user page-size preference (users.list_page_size),
 * and the shared page-number control.
 *
 * Both live here rather than in a second include, so there is one place
 * that owns paging for every list in the app.
 */

const ALLOWED_PAGE_SIZES = [15, 20, 30];

function getUserPageSize(PDO $pdo, int $user_id): int
{
    try {
        $stmt = $pdo->prepare("SELECT list_page_size FROM users WHERE id = ? LIMIT 1");
        $stmt->execute([$user_id]);
        $size = (int) $stmt->fetchColumn();
    } catch (Throwable $e) {
        $size = 0;
    }

    return in_array($size, ALLOWED_PAGE_SIZES, true) ? $size : 15;
}

function setUserPageSize(PDO $pdo, int $user_id, int $size): bool
{
    if (!in_array($size, ALLOWED_PAGE_SIZES, true)) {
        return false;
    }

    $pdo->prepare("UPDATE users SET list_page_size = ? WHERE id = ?")->execute([$size, $user_id]);
    return true;
}

/**
 * Reads a ?page_size= change request from $_GET, persists it for the
 * user if present/valid, and returns the effective size to paginate
 * with this request (freshly-changed value or the stored preference).
 * Called at the top of a list page, before running the count/list query.
 */
function resolveUserPageSize(PDO $pdo, int $user_id): int
{
    if (isset($_GET['page_size'])) {
        $requested = (int) $_GET['page_size'];
        if (setUserPageSize($pdo, $user_id, $requested)) {
            return $requested;
        }
    }

    return getUserPageSize($pdo, $user_id);
}

/**
 * The page-size <select> markup shared by every paginated list page.
 * Submits via the given form id (defaults to a GET reload of the current
 * page, dropping back to page 1 since the old page number may no longer
 * make sense at a different size) -- callers just echo this inside their
 * toolbar.
 */
function pageSizeSelectorHtml(int $currentSize, string $extraHiddenFieldsHtml = ''): string
{
    $options = '';
    foreach (ALLOWED_PAGE_SIZES as $size) {
        $selected = $size === $currentSize ? 'selected' : '';
        $options .= "<option value=\"{$size}\" {$selected}>{$size} / page</option>";
    }

    return <<<HTML
        <form method="GET" class="page-size-form" style="display:inline-flex;align-items:center;gap:6px;">
            {$extraHiddenFieldsHtml}
            <input type="hidden" name="page" value="1">
            <label style="font-size:12.5px;color:#6b7280;font-weight:600;">Rows:</label>
            <select name="page_size" onchange="this.form.submit()" class="form-control" style="width:auto;padding:6px 10px;font-size:13px;">
                {$options}
            </select>
        </form>
    HTML;
}
/**
 * Shared pager.
 *
 * Nine pages rendered their page links with a bare `for ($i = 1; $i <=
 * $total_pages; $i++)`, which is fine at three pages and unusable at
 * twenty-three -- the row wraps into a block of numbers with no way to
 * reach the end except by counting. This renders a fixed-width control
 * instead: first and last are always reachable, the current page sits in a
 * small window of neighbours, and everything else collapses into an
 * ellipsis.
 *
 * Deliberately namespaced `iv-pager` rather than reusing `.pagination`:
 * that class already has different rules in decommission.css,
 * uid-gid-tracking.css and others, so reusing it would mean each page
 * inheriting whichever definition happened to load. The component ships
 * its own CSS, emitted once per request, so a page adopting it needs no
 * stylesheet change.
 */

/**
 * @param int    $current       1-based current page
 * @param int    $totalPages    total number of pages
 * @param array  $queryParams   filters to preserve in every link
 * @param array  $options       base, page_param, total_records, per_page, window
 */
function ivPager(int $current, int $totalPages, array $queryParams = [], array $options = []): string
{
    if ($totalPages < 2) {
        return '';
    }

    $base      = $options['base']         ?? basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $pageParam = $options['page_param']   ?? 'page';
    $total     = $options['total_records'] ?? null;
    $perPage   = $options['per_page']     ?? null;
    $window    = max(1, (int) ($options['window'] ?? 1));

    $current = max(1, min($current, $totalPages));

    /*
     * Pages already vary in how they build a page URL -- several keep a
     * $page_link closure, others concatenate their filters by hand. Rather
     * than force every caller onto the query-array form, accept a callable
     * and use it when given.
     */
    $custom = $options['link'] ?? null;

    $link = static function (int $p) use ($base, $pageParam, $queryParams, $custom): string {
        if (is_callable($custom)) {
            return htmlspecialchars((string) $custom($p), ENT_QUOTES, 'UTF-8');
        }
        $q = array_merge($queryParams, [$pageParam => $p]);
        return htmlspecialchars($base . '?' . http_build_query($q), ENT_QUOTES, 'UTF-8');
    };

    /*
     * Which page numbers get a button: always 1 and the last page, plus a
     * window either side of the current one. Sorting and de-duplicating
     * afterwards is simpler than trying to emit them in order while
     * handling the overlaps near either end.
     */
    $show = [1, $totalPages];
    for ($p = $current - $window; $p <= $current + $window; $p++) {
        if ($p >= 1 && $p <= $totalPages) {
            $show[] = $p;
        }
    }
    $show = array_values(array_unique($show));
    sort($show);

    $out = '<nav class="iv-pager" role="navigation" aria-label="Pagination">';

    if ($total !== null && $perPage) {
        $from = (($current - 1) * (int) $perPage) + 1;
        $to   = min($current * (int) $perPage, (int) $total);
        $out .= '<span class="iv-pager-count">Showing <strong>' . number_format($from) . '</strong>&ndash;<strong>'
              . number_format($to) . '</strong> of <strong>' . number_format((int) $total) . '</strong></span>';
    }

    $out .= '<span class="iv-pager-links">';

    // Previous
    $out .= $current > 1
        ? '<a class="iv-pager-step" href="' . $link($current - 1) . '" rel="prev" aria-label="Previous page">&lsaquo;</a>'
        : '<span class="iv-pager-step is-disabled" aria-hidden="true">&lsaquo;</span>';

    $previous = 0;
    foreach ($show as $p) {
        // A gap of exactly one is rendered as that page rather than an
        // ellipsis: "1 … 3" wastes the same width as "1 2 3" and hides a
        // page the reader could have clicked.
        if ($previous && $p - $previous === 2) {
            $out .= '<a class="iv-pager-page" href="' . $link($previous + 1) . '">' . ($previous + 1) . '</a>';
        } elseif ($previous && $p - $previous > 2) {
            $out .= '<span class="iv-pager-gap" aria-hidden="true">&hellip;</span>';
        }

        $out .= $p === $current
            ? '<span class="iv-pager-page is-current" aria-current="page">' . $p . '</span>'
            : '<a class="iv-pager-page" href="' . $link($p) . '">' . $p . '</a>';

        $previous = $p;
    }

    // Next
    $out .= $current < $totalPages
        ? '<a class="iv-pager-step" href="' . $link($current + 1) . '" rel="next" aria-label="Next page">&rsaquo;</a>'
        : '<span class="iv-pager-step is-disabled" aria-hidden="true">&rsaquo;</span>';

    $out .= '</span>';

    // A direct jump, which is the thing a long list actually needs: at
    // twenty-three pages, reaching page 17 otherwise means four clicks.
    if ($totalPages > 7) {
        $out .= '<form class="iv-pager-jump" method="get" action="' . htmlspecialchars($base, ENT_QUOTES, 'UTF-8') . '">';
        foreach ($queryParams as $k => $v) {
            if ($k === $pageParam) { continue; }
            $out .= '<input type="hidden" name="' . htmlspecialchars((string) $k, ENT_QUOTES, 'UTF-8')
                  . '" value="' . htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8') . '">';
        }
        $out .= '<label for="ivPagerGo">Go to</label>'
              . '<input id="ivPagerGo" type="number" name="' . htmlspecialchars($pageParam, ENT_QUOTES, 'UTF-8')
              . '" min="1" max="' . $totalPages . '" value="' . $current . '" aria-label="Page number">'
              . '<span class="iv-pager-of">of ' . $totalPages . '</span>'
              . '</form>';
    }

    $out .= '</nav>';

    return ivPagerStyles() . $out;
}

/**
 * The component's CSS, returned once per request.
 *
 * Inline rather than a stylesheet because the pages that need it load
 * nineteen different CSS files between them; shipping it with the markup
 * means adopting the pager is a one-line change per page.
 */
function ivPagerStyles(): string
{
    static $emitted = false;
    if ($emitted) {
        return '';
    }
    $emitted = true;

    return <<<'CSS'
<style>
.iv-pager {
    display: flex;
    align-items: center;
    justify-content: space-between;
    flex-wrap: wrap;
    gap: 12px 18px;
    padding: 16px 20px 20px;
    font-size: 13px;
}
.iv-pager-count { color: var(--text-muted, #64748B); font-variant-numeric: tabular-nums; }
.iv-pager-count strong { color: var(--text-primary, #0F172A); font-weight: 650; }

.iv-pager-links { display: inline-flex; align-items: center; gap: 4px; }

.iv-pager-page,
.iv-pager-step {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 34px;
    height: 34px;
    padding: 0 9px;
    border: 1px solid var(--border-color, #E2E8F0);
    border-radius: 8px;
    background: var(--bg-content, #fff);
    color: var(--text-primary, #0F172A);
    text-decoration: none;
    font-variant-numeric: tabular-nums;
    transition: border-color .12s, background .12s, color .12s;
}
.iv-pager-page:hover,
.iv-pager-step:hover { border-color: var(--accent, #4338CA); color: var(--accent, #4338CA); }

.iv-pager-page.is-current {
    background: var(--accent, #4338CA);
    border-color: var(--accent, #4338CA);
    color: #fff;
    font-weight: 650;
}
.iv-pager-step.is-disabled { opacity: .4; pointer-events: none; }
.iv-pager-step { font-size: 16px; line-height: 1; }

.iv-pager-gap {
    padding: 0 2px;
    color: var(--text-muted, #94A3B8);
    user-select: none;
}

.iv-pager-jump { display: inline-flex; align-items: center; gap: 7px; color: var(--text-muted, #64748B); }
.iv-pager-jump label { font-size: 12px; }
.iv-pager-jump input {
    width: 66px;
    height: 34px;
    padding: 0 8px;
    border: 1px solid var(--border-color, #E2E8F0);
    border-radius: 8px;
    background: var(--input-bg, #fff);
    color: var(--text-primary, #0F172A);
    font: inherit;
    font-variant-numeric: tabular-nums;
}
.iv-pager-jump input:focus {
    outline: none;
    border-color: var(--accent, #4338CA);
    box-shadow: 0 0 0 3px var(--focus-ring, rgba(67,56,202,.15));
}
.iv-pager-of { font-size: 12px; }

[data-theme="dark"] .iv-pager-page,
[data-theme="dark"] .iv-pager-step { background: rgba(255,255,255,.04); }

@media (max-width: 640px) {
    .iv-pager { justify-content: center; }
    .iv-pager-count, .iv-pager-jump { width: 100%; justify-content: center; text-align: center; }
}
</style>
CSS;
}
