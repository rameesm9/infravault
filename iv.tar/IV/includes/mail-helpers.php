<?php
/**
 * Centralized mail configuration and sending.
 *
 * Every module that needs to send an email should go through
 * sendAppMail() rather than instantiating SmtpMailer directly with its own
 * config file -- that's what let the settings drift into the broken,
 * scattered mail_config.php setup this replaces.
 */

require_once __DIR__ . '/SmtpMailer.php';

/**
 * Environment variable overrides, keyed by the mail_settings column they
 * replace. Any of these set on the container (Podman --env / --env-file /
 * secret) take precedence over the stored DB value at read-time -- the
 * idiomatic way to inject SMTP credentials into a container without
 * putting them in the database or the settings UI.
 */
const MAIL_ENV_OVERRIDES = [
    'smtp_host' => 'SMTP_HOST',
    'smtp_port' => 'SMTP_PORT',
    'smtp_encryption' => 'SMTP_ENCRYPTION',
    'smtp_username' => 'SMTP_USERNAME',
    'smtp_password' => 'SMTP_PASSWORD',
    'from_email' => 'SMTP_FROM_EMAIL',
    'from_name' => 'SMTP_FROM_NAME',
    'smtp_timeout' => 'SMTP_TIMEOUT',
];

/**
 * Which mail_settings columns currently have an active environment
 * variable override. Used by settings.php to show the admin which fields
 * are controlled outside the UI, so editing them there is not silently
 * ignored without explanation.
 *
 * @return array<string,string> column => env var name
 */
function getMailEnvOverrides(): array
{
    $active = [];
    foreach (MAIL_ENV_OVERRIDES as $column => $envVar) {
        $value = getenv($envVar);
        if ($value !== false && trim((string) $value) !== '') {
            $active[$column] = $envVar;
        }
    }
    return $active;
}

/**
 * Load the stored mail settings row, with any active environment variable
 * overrides applied on top.
 */
function getMailSettingsRow(PDO $pdo): array
{
    $row = $pdo->query("SELECT * FROM mail_settings WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        // Schema not migrated yet for some reason -- fall back to safe defaults
        // rather than fatal-erroring every page that touches mail settings.
        $row = [
            'is_enabled' => 0, 'smtp_host' => '', 'smtp_port' => 587, 'smtp_encryption' => 'tls',
            'smtp_username' => '', 'smtp_password' => '', 'from_email' => '', 'from_name' => 'InfraVault',
            'smtp_timeout' => 15, 'updated_by' => null, 'updated_at' => null,
        ];
    }

    foreach (getMailEnvOverrides() as $column => $envVar) {
        $row[$column] = getenv($envVar);
    }

    return $row;
}

/**
 * Config array shaped for SmtpMailer's constructor.
 */
function getMailSettings(PDO $pdo): array
{
    $row = getMailSettingsRow($pdo);

    return [
        'host' => (string) $row['smtp_host'],
        'port' => (int) $row['smtp_port'],
        'encryption' => (string) $row['smtp_encryption'],
        'username' => (string) $row['smtp_username'],
        'password' => (string) $row['smtp_password'],
        'from_email' => (string) $row['from_email'],
        'from_name' => (string) $row['from_name'],
        'timeout' => (int) $row['smtp_timeout'],
    ];
}

/**
 * Global "is mail sending turned on at all" switch.
 */
function isMailEnabled(PDO $pdo): bool
{
    $row = getMailSettingsRow($pdo);
    return (int) $row['is_enabled'] === 1;
}

/**
 * Ensures a module has a toggle row, without needing to edit
 * config/schema/mail_settings.php every time a new module wants one.
 * Safe to call on every request (INSERT OR IGNORE).
 */
function registerMailModule(PDO $pdo, string $moduleKey, string $moduleLabel): void
{
    $pdo->prepare("
        INSERT OR IGNORE INTO mail_module_toggles (module_key, module_label)
        VALUES (?, ?)
    ")->execute([$moduleKey, $moduleLabel]);
}

/**
 * Whether a specific module is allowed to send mail right now -- both the
 * global switch and that module's own toggle must be on.
 */
function isMailModuleEnabled(PDO $pdo, string $moduleKey): bool
{
    if (!isMailEnabled($pdo)) {
        return false;
    }

    $stmt = $pdo->prepare("SELECT is_enabled FROM mail_module_toggles WHERE module_key = ? LIMIT 1");
    $stmt->execute([$moduleKey]);
    $result = $stmt->fetchColumn();

    // A module that was never registered/toggled defaults to off, not on --
    // enabling mail for a module should be an explicit admin action.
    return $result !== false && (int) $result === 1;
}

/**
 * Get all module toggles for display on the settings page.
 */
function getAllMailModuleToggles(PDO $pdo): array
{
    return $pdo->query("
        SELECT module_key, module_label, is_enabled
        FROM mail_module_toggles
        ORDER BY module_label ASC
    ")->fetchAll(PDO::FETCH_ASSOC);
}

/**
 * The single entry point every module should use to send mail.
 *
 * Checks the global switch and the module's own toggle before attempting
 * to send; returns a synthetic skipped result (not an exception) if either
 * is off, so callers can log/ignore it without special-casing "disabled"
 * as an error.
 *
 * @return array{success: bool, message: string, skipped?: bool}
 */
function sendAppMail(
    PDO $pdo,
    string $moduleKey,
    string $toEmail,
    string $toName,
    string $subject,
    string $htmlBody,
    ?string $textBody = null
): array {
    if (!isMailModuleEnabled($pdo, $moduleKey)) {
        return [
            'success' => false,
            'skipped' => true,
            'message' => "Mail is disabled for module '{$moduleKey}' (or globally) in Settings.",
        ];
    }

    $mailer = new SmtpMailer(getMailSettings($pdo));

    return $mailer->send($toEmail, $toName, $subject, $htmlBody, $textBody);
}
