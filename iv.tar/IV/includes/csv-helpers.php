<?php
/**
 * CSV header handling, shared by every importer.
 *
 * Every import in this app maps a CSV header row onto database column
 * names, and each one did it by lowercasing the header cell and using the
 * result verbatim. That works only for single-word columns: a header of
 * "IP Address" becomes "ip address", which never matches the key
 * "ip_address", so the field silently reads as empty. The row is then
 * rejected for a missing required field, and the user is told the file
 * contained duplicates.
 *
 * It bites hardest on a file produced by this app's own export, because
 * the exports write display labels ("Support Level") while the imports
 * expect keys ("support_level") -- so exporting and re-importing loses
 * everything.
 */

/**
 * Turns one header cell into a candidate column key.
 *
 *   "IP Address"   -> ip_address
 *   "NCGR Owner"   -> ncgr_owner
 *   "ip_address"   -> ip_address   (already a key: unchanged)
 *   "CPU"          -> cpu
 */
function csvHeaderKey(string $cell): string
{
    $slug = strtolower(trim($cell));
    if ($slug === '') {
        return '';
    }

    return trim(preg_replace('/[^a-z0-9]+/', '_', $slug), '_');
}

/**
 * Normalises a whole header row.
 *
 * $columnMap, when given as key => 'Display Label', lets a label be
 * resolved back to its exact key even where slugging alone would not
 * reach it -- and leaves anything unrecognised as its slug, so a column
 * the map does not know about still lands under a sensible name.
 *
 * @param array<int,string>    $cells     raw header cells from str_getcsv
 * @param array<string,string> $columnMap key => label
 * @return array<int,string>              one column key per input cell
 */
function csvNormaliseHeader(array $cells, array $columnMap = []): array
{
    $lookup = [];
    foreach ($columnMap as $key => $label) {
        $lookup[$key] = $key;
        $lookup[csvHeaderKey((string) $label)] = $key;
    }

    return array_map(static function ($cell) use ($lookup) {
        $slug = csvHeaderKey((string) $cell);
        return $lookup[$slug] ?? $slug;
    }, $cells);
}
