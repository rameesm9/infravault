<?php
/**
 * Permission Helpers for Team-Based Access Control
 *
 * Provides core functions for:
 * - Access level determination (full_access, edit_only, view_only, none)
 * - Role-based permission checks
 * - Item visibility filtering
 * - Audit logging
 * - Sharing/visibility management
 */

/**
 * Determine access level for a user to a specific item
 *
 * @param PDO $pdo Database connection
 * @param int $user_id User ID
 * @param string $user_role User role
 * @param string $user_team User's team
 * @param int $item_owner_id Item owner/author ID
 * @param string $item_visibility Visibility mode (private, public, team, teams)
 * @param string $item_owner_team Item's owner team
 * @param array $shared_teams List of teams item is shared with (for 'teams' visibility)
 * @param string $module Module name (sop, knowledge_base, known_issue, quick_link)
 *
 * @return string Access level: 'full_access', 'edit_only', 'view_only', 'none'
 */
function getItemAccessLevel(PDO $pdo, int $user_id, string $user_role, string $user_team,
                            int $item_owner_id, string $item_visibility, string $item_owner_team = '',
                            array $shared_teams = [], string $module = 'sop'): string
{
    // ADMINS: Always full access to everything
    if (strtolower($user_role) === 'admin') {
        return 'full_access';
    }

    // AUTHOR: Can edit/delete own items (if role permits)
    if ((int)$item_owner_id === (int)$user_id) {
        $editPerm = hasRolePermission($pdo, $user_role, $module, 'can_edit');
        return $editPerm ? 'full_access' : 'view_only';
    }

    // PRIVATE ("only me"): nobody but the author reaches this point, since
    // the author and Admin both returned above. Listed explicitly rather
    // than falling through to the final 'none' so the intent is readable
    // and an unknown visibility value stays distinguishable from this one.
    if ($item_visibility === 'private') {
        return 'none';
    }

    // PUBLIC visibility: Check role-based permissions
    if ($item_visibility === 'public') {
        return getRoleAccessLevel($pdo, $user_role, $module);
    }

    // TEAM visibility: Accessible only to members of owner_team.
    //
    // The empty-string guard is load-bearing: a user with no team assigned
    // has $user_team = '', and an item saved before owner_team was set has
    // $item_owner_team = ''. Comparing those two alone means every
    // teamless user matches every team-less item, quietly handing them
    // team-scoped content. Neither side may be blank.
    if ($item_visibility === 'team') {
        if ($user_team !== '' && $item_owner_team !== '' && $user_team === $item_owner_team) {
            return getRoleAccessLevel($pdo, $user_role, $module);
        }
        return 'none';
    }

    // TEAMS (multi-team) visibility: Accessible to users in any shared team
    if ($item_visibility === 'teams') {
        if ($user_team !== '' && in_array($user_team, $shared_teams, true)) {
            return getRoleAccessLevel($pdo, $user_role, $module);
        }
        return 'none';
    }

    return 'none';
}

/**
 * Get role-based access level from permissions table
 *
 * @param PDO $pdo Database connection
 * @param string $role Role name
 * @param string $module Module name (sop, knowledge_base, known_issue)
 *
 * @return string Access level: 'full_access', 'edit_only', 'view_only', 'none'
 */
function getRoleAccessLevel(PDO $pdo, string $role, string $module): string
{
    // Map module names to page_key values used in permissions table
    $pageKeyMap = [
        'sop' => 'sop',
        'knowledge_base' => 'knowledge',
        'known_issue' => 'known_issues',
        'quick_link' => 'links',
        'oncall' => 'oncall',
        'leave' => 'leave',
    ];

    $pageKey = $pageKeyMap[$module] ?? $module;

    try {
        $stmt = $pdo->prepare("
            SELECT can_view, can_edit, can_delete
            FROM permissions
            WHERE LOWER(role) = LOWER(?) AND page_key = ?
            LIMIT 1
        ");
        $stmt->execute([$role, $pageKey]);
        $perms = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$perms || !$perms['can_view']) {
            return 'none';
        }

        if ($perms['can_edit'] && $perms['can_delete']) {
            return 'full_access';
        }

        if ($perms['can_edit']) {
            return 'edit_only';
        }

        return 'view_only';
    } catch (Throwable $e) {
        error_log("Error checking role access level for role=$role, module=$module: " . $e->getMessage());
        return 'none';
    }
}

/**
 * Check if a role has a specific permission for a module
 *
 * @param PDO $pdo Database connection
 * @param string $role Role name
 * @param string $module Module name
 * @param string $permission Permission type (can_view, can_edit, can_delete, can_export, can_audit)
 *
 * @return bool True if role has the permission
 */
function hasRolePermission(PDO $pdo, string $role, string $module, string $permission): bool
{
    $validPermissions = ['can_view', 'can_edit', 'can_delete', 'can_export', 'can_import', 'can_audit'];
    if (!in_array($permission, $validPermissions, true)) {
        return false;
    }

    $pageKeyMap = [
        'sop' => 'sop',
        'knowledge_base' => 'knowledge',
        'known_issue' => 'known_issues',
        'quick_link' => 'links',
        'oncall' => 'oncall',
        'leave' => 'leave',
    ];

    $pageKey = $pageKeyMap[$module] ?? $module;

    try {
        $stmt = $pdo->prepare("
            SELECT `$permission`
            FROM permissions
            WHERE LOWER(role) = LOWER(?) AND page_key = ?
            LIMIT 1
        ");
        $stmt->execute([$role, $pageKey]);
        $result = $stmt->fetchColumn();

        return ((int)$result === 1);
    } catch (Throwable $e) {
        error_log("Error checking permission: role=$role, module=$module, permission=$permission: " . $e->getMessage());
        return false;
    }
}

/**
 * Get list of shared teams for a multi-team visibility item
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name (sop, knowledge_base, known_issue)
 * @param int $item_id Item ID
 *
 * @return array List of team names
 */
function getSharedTeams(PDO $pdo, string $module, int $item_id): array
{
    $tableMap = [
        'sop' => 'sop_teams',
        'knowledge_base' => 'knowledge_base_teams',
        'known_issue' => 'known_issue_teams',
        'quick_link' => 'quick_link_teams',
        'oncall' => 'oncall_teams',
        'leave' => 'leave_teams',
        'handover' => 'handover_teams',
    ];

    $table = $tableMap[$module] ?? null;
    if (!$table) {
        return [];
    }

    $idCol = $module === 'known_issue' ? 'issue_id' : "{$module}_id";

    try {
        $stmt = $pdo->prepare("
            SELECT team_name
            FROM $table
            WHERE $idCol = ?
            ORDER BY team_name ASC
        ");
        $stmt->execute([$item_id]);
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        error_log("Error fetching shared teams: module=$module, item_id=$item_id: " . $e->getMessage());
        return [];
    }
}

/**
 * Save item sharing configuration
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name (sop, knowledge_base, known_issue)
 * @param int $item_id Item ID
 * @param string $visibility Visibility mode (public, team, teams)
 * @param array $selected_teams Team names (for 'teams' visibility)
 *
 * @return bool Success
 */
function saveItemSharing(PDO $pdo, string $module, int $item_id, string $visibility, array $selected_teams = []): bool
{
    try {
        $pdo->beginTransaction();

        $tableMap = [
            'sop' => 'sops',
            'knowledge_base' => 'knowledge_base',
            'known_issue' => 'known_issues',
            'quick_link' => 'quick_links',
            'oncall' => 'oncall_shifts',
            'leave' => 'leave_entries',
            'handover' => 'handovers',
        ];

        $teamsTableMap = [
            'sop' => 'sop_teams',
            'knowledge_base' => 'knowledge_base_teams',
            'known_issue' => 'known_issue_teams',
            'quick_link' => 'quick_link_teams',
            'oncall' => 'oncall_teams',
            'leave' => 'leave_teams',
            'handover' => 'handover_teams',
        ];

        // An unregistered module used to fall through as an undefined index,
        // building "DELETE FROM  WHERE ..." -- a SQL syntax error that the
        // catch below swallowed, so callers saw a silent no-op rather than a
        // failure and believed the visibility had been saved. Fail loudly.
        if (!isset($tableMap[$module], $teamsTableMap[$module])) {
            throw new InvalidArgumentException("saveItemSharing: unknown module '$module'");
        }

        $table = $tableMap[$module];
        $teamsTable = $teamsTableMap[$module];
        $idCol = $module === 'known_issue' ? 'issue_id' : "{$module}_id";
        $visCol = $module === 'known_issue' ? 'team_scoped_visibility' : 'visibility';

        // Clear existing team associations
        $stmt = $pdo->prepare("DELETE FROM $teamsTable WHERE $idCol = ?");
        $stmt->execute([$item_id]);

        // Insert new team associations if multi-team visibility
        if ($visibility === 'teams') {
            $stmt = $pdo->prepare("
                INSERT INTO $teamsTable ($idCol, team_name, created_at)
                VALUES (?, ?, CURRENT_TIMESTAMP)
            ");
            foreach ($selected_teams as $team) {
                $team = trim((string)$team);
                if ($team !== '') {
                    $stmt->execute([$item_id, $team]);
                }
            }
        }

        // Update visibility field
        $stmt = $pdo->prepare("UPDATE $table SET $visCol = ? WHERE id = ?");
        $stmt->execute([$visibility, $item_id]);

        $pdo->commit();
        return true;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log("Error saving item sharing: module=$module, item_id=$item_id: " . $e->getMessage());
        return false;
    }
}

/**
 * Log an action to the audit trail
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name (sop, knowledge_base, known_issue)
 * @param int $item_id Item ID
 * @param string $action Action name (CREATED, EDITED, DELETED, etc.)
 * @param int $user_id User ID who performed the action
 * @param string $user_name User's display name
 * @param array $details Optional details (field changes, etc.)
 *
 * @return bool Success
 */
function logItemAction(PDO $pdo, string $module, int $item_id, string $action,
                       int $user_id, string $user_name, array $details = []): bool
{
    try {
        $auditTableMap = [
            'sop' => 'sop_audit',
            'knowledge_base' => 'knowledge_base_audit',
            'known_issue' => 'known_issue_audit',
            'quick_link' => 'quick_link_audit',
            'oncall' => 'oncall_audit',
            'leave' => 'leave_audit',
        ];

        $idColMap = [
            'sop' => 'sop_id',
            'knowledge_base' => 'kb_id',
            'known_issue' => 'issue_id',
            'quick_link' => 'quick_link_id',
            'oncall' => 'oncall_id',
            'leave' => 'leave_id',
        ];

        $table = $auditTableMap[$module];
        $idCol = $idColMap[$module];

        $stmt = $pdo->prepare("
            INSERT INTO $table ($idCol, action, performed_by_id, user_name, details, action_date)
            VALUES (?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
        ");

        $detailsJson = !empty($details) ? json_encode($details) : null;

        $stmt->execute([
            $item_id,
            strtoupper($action),
            $user_id,
            $user_name,
            $detailsJson,
        ]);

        return true;
    } catch (Throwable $e) {
        error_log("Error logging item action: module=$module, item_id=$item_id, action=$action: " . $e->getMessage());
        return false;
    }
}

/**
 * Get audit trail for an item
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name
 * @param int $item_id Item ID
 *
 * @return array Audit entries (newest first)
 */
function getItemAuditTrail(PDO $pdo, string $module, int $item_id): array
{
    try {
        $auditTableMap = [
            'sop' => 'sop_audit',
            'knowledge_base' => 'knowledge_base_audit',
            'known_issue' => 'known_issue_audit',
            'quick_link' => 'quick_link_audit',
            'oncall' => 'oncall_audit',
            'leave' => 'leave_audit',
        ];

        $idColMap = [
            'sop' => 'sop_id',
            'knowledge_base' => 'kb_id',
            'known_issue' => 'issue_id',
            'quick_link' => 'quick_link_id',
            'oncall' => 'oncall_id',
            'leave' => 'leave_id',
        ];

        $table = $auditTableMap[$module];
        $idCol = $idColMap[$module];

        $stmt = $pdo->prepare("
            SELECT
                id,
                action,
                performed_by_id,
                user_name,
                action_date,
                details
            FROM $table
            WHERE $idCol = ?
            ORDER BY action_date DESC
        ");

        $stmt->execute([$item_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log("Error fetching audit trail: module=$module, item_id=$item_id: " . $e->getMessage());
        return [];
    }
}

/**
 * Get visible items for a user (respects team membership and role permissions)
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name
 * @param int $user_id User ID
 * @param string $user_role User role
 * @param string $user_team User's team
 * @param int $limit Results limit (default: 100)
 * @param int $offset Results offset (default: 0)
 *
 * @return array Items visible to the user
 */
function getVisibleItems(PDO $pdo, string $module, int $user_id, string $user_role,
                        string $user_team, int $limit = 100, int $offset = 0): array
{
    try {
        $tableMap = [
            'sop' => 'sops',
            'knowledge_base' => 'knowledge_base',
            'known_issue' => 'known_issues',
            'quick_link' => 'quick_links',
            'oncall' => 'oncall_shifts',
            'leave' => 'leave_entries',
            'handover' => 'handovers',
        ];

        $teamsTableMap = [
            'sop' => 'sop_teams',
            'knowledge_base' => 'knowledge_base_teams',
            'known_issue' => 'known_issue_teams',
            'quick_link' => 'quick_link_teams',
            'oncall' => 'oncall_teams',
            'leave' => 'leave_teams',
            'handover' => 'handover_teams',
        ];

        $table = $tableMap[$module];
        $teamsTable = $teamsTableMap[$module];
        $visCol = $module === 'known_issue' ? 'team_scoped_visibility' : 'visibility';
        $idCol = $module === 'known_issue' ? 'issue_id' : "{$module}_id";
        // knowledge_base tracks authorship via created_by; sops/known_issues use owner_id.
        $ownerCol = $module === 'knowledge_base' ? 'created_by' : 'owner_id';

        // Admins see everything
        if (strtolower($user_role) === 'admin') {
            $stmt = $pdo->prepare("
                SELECT *
                FROM $table
                ORDER BY created_at DESC
                LIMIT ? OFFSET ?
            ");
            $stmt->execute([$limit, $offset]);
            return $stmt->fetchAll(PDO::FETCH_ASSOC);
        }

        // Check if user has can_view permission. Built conditionally rather than
        // as a bound "? = 1" SQL comparison: PDO binds parameters as strings, and
        // SQLite's type-affinity rules never consider a TEXT '1' equal to the
        // INTEGER literal 1, so that comparison silently always evaluates false.
        $publicClause = hasRolePermission($pdo, $user_role, $module, 'can_view')
            ? "OR $visCol = 'public'"
            : '';

        // Build WHERE clause
        $sql = "
            SELECT *
            FROM $table
            WHERE
                -- User's own items
                $ownerCol = ?

                -- Public items (only included if user has can_view permission)
                $publicClause

                -- Team-scoped items matching user's team
                OR ($visCol = 'team' AND owner_team = ?)

                -- Multi-team items where user's team is listed
                OR ($visCol = 'teams' AND id IN (
                    SELECT $idCol FROM $teamsTable
                    WHERE team_name = ?
                ))

            ORDER BY created_at DESC
            LIMIT ? OFFSET ?
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([$user_id, $user_team, $user_team, $limit, $offset]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log("Error fetching visible items: module=$module, user_id=$user_id: " . $e->getMessage());
        return [];
    }
}

/**
 * Check if user can perform an action on an item
 *
 * @param PDO $pdo Database connection
 * @param int $user_id User ID
 * @param string $user_role User role
 * @param string $module Module name
 * @param string $action Action type (edit, delete, view_audit, comment)
 * @param string $access_level User's access level (from getItemAccessLevel)
 * @param bool $is_author Whether user is the item author
 *
 * @return bool Whether action is allowed
 */
function canPerformAction(PDO $pdo, int $user_id, string $user_role, string $module,
                         string $action, string $access_level, bool $is_author = false): bool
{
    // Admins can always act
    if (strtolower($user_role) === 'admin') {
        return true;
    }

    // No access at all
    if ($access_level === 'none') {
        return false;
    }

    switch ($action) {
        case 'view':
            return $access_level !== 'none';

        case 'edit':
            // Author can edit if role permits can_edit
            if ($is_author) {
                return hasRolePermission($pdo, $user_role, $module, 'can_edit');
            }
            // Non-author needs can_edit and full_access level
            return $access_level === 'full_access' || $access_level === 'edit_only';

        case 'delete':
            // Author can delete if role permits can_delete
            if ($is_author) {
                return hasRolePermission($pdo, $user_role, $module, 'can_delete');
            }
            // Non-author needs can_delete and full_access level
            return $access_level === 'full_access' && hasRolePermission($pdo, $user_role, $module, 'can_delete');

        case 'export':
            return hasRolePermission($pdo, $user_role, $module, 'can_export');

        case 'view_audit':
            // Item author or users with can_audit permission
            if ($is_author) {
                return true;
            }
            return hasRolePermission($pdo, $user_role, $module, 'can_audit');

        case 'comment':
            // Must have can_edit permission and access to item
            return $access_level !== 'none' && hasRolePermission($pdo, $user_role, $module, 'can_edit');

        default:
            return false;
    }
}

/**
 * Get all team names for dropdowns / multi-selects.
 *
 * Union of the teams registry (config/schema/teams.php, managed from
 * users.php) and the team names actually in use on users.team.
 *
 * Both halves are needed. The registry alone would drop a legacy team
 * name that users still hold but that was never registered; the users
 * table alone -- which is all this used to read -- would hide a team
 * created ahead of anyone joining it, making a brand new team
 * impossible to share anything with.
 *
 * @param PDO $pdo Database connection
 *
 * @return array List of team names
 */
function getAllTeams(PDO $pdo): array
{
    try {
        $stmt = $pdo->prepare("
            SELECT team_name AS team FROM teams
            UNION
            SELECT DISTINCT TRIM(team) FROM users
            WHERE team IS NOT NULL AND TRIM(team) != ''
            ORDER BY team COLLATE NOCASE ASC
        ");
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        error_log("Error fetching all teams: " . $e->getMessage());
        return [];
    }
}
