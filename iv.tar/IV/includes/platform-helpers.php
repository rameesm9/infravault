<?php
/**
 * Shared helpers for the Major Layouts modules (container platform,
 * Oracle estate, DR mapping, application layouts).
 *
 * Written once here rather than copied into four pages -- the same
 * mistake that produced sixteen divergent permission helpers elsewhere
 * in this codebase.
 */

/** Escape for HTML output. */
if (!function_exists('plat_h')) {
    function plat_h($value): string
    {
        return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
    }
}

/**
 * Records an action against the shared platform_history table.
 */
function platformLog(PDO $pdo, string $module, ?int $recordId, string $action, string $user, string $details): void
{
    try {
        $pdo->prepare("
            INSERT INTO platform_history (module, record_id, action_type, performed_by, details)
            VALUES (?, ?, ?, ?, ?)
        ")->execute([$module, $recordId, strtoupper($action), $user, $details]);
    } catch (Throwable $e) {
        error_log("platformLog failed for {$module}#{$recordId}: " . $e->getMessage());
    }
}

/**
 * Renders the audit trail for a module, or for one record within it.
 */
function platformHistoryHtml(PDO $pdo, string $module, int $recordId = 0): string
{
    try {
        if ($recordId > 0) {
            $stmt = $pdo->prepare("
                SELECT * FROM platform_history
                WHERE module = ? AND record_id = ?
                ORDER BY timestamp DESC, id DESC
            ");
            $stmt->execute([$module, $recordId]);
        } else {
            $stmt = $pdo->prepare("
                SELECT * FROM platform_history
                WHERE module = ?
                ORDER BY timestamp DESC, id DESC
                LIMIT 200
            ");
            $stmt->execute([$module]);
        }

        $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        return '<p class="empty-state">Unable to load audit history.</p>';
    }

    if (!$rows) {
        return '<p class="empty-state">'
             . ($recordId > 0 ? 'No history for this record yet.' : 'No audit history recorded yet.')
             . '</p>';
    }

    $tone = [
        'CREATED' => 'background:#E4F3ED;color:#047857;',
        'UPDATED' => 'background:#FDF2E3;color:#B45309;',
        'DELETED' => 'background:#FCECEA;color:#B42318;',
    ];

    $html = '<table class="audit-table"><thead><tr>'
          . '<th>Action</th><th>By</th><th>Details</th><th>When</th>'
          . '</tr></thead><tbody>';

    foreach ($rows as $r) {
        $style = $tone[$r['action_type']] ?? 'background:#EDF0F4;color:#39424F;';
        $html .= '<tr>'
              . '<td><span class="audit-badge" style="' . $style . '">' . plat_h($r['action_type']) . '</span></td>'
              . '<td>' . plat_h($r['performed_by']) . '</td>'
              . '<td class="audit-details">' . nl2br(plat_h($r['details'])) . '</td>'
              . '<td>' . plat_h($r['timestamp']) . '</td>'
              . '</tr>';
    }

    return $html . '</tbody></table>';
}

/**
 * Hostnames from inventory, for the server pickers.
 *
 * Every module here references servers by hostname; offering the real
 * list stops the same machine being recorded three different ways.
 */
function platformHostnames(PDO $pdo): array
{
    try {
        return $pdo->query("
            SELECT hostname FROM inventory
            WHERE hostname IS NOT NULL AND TRIM(hostname) <> ''
            ORDER BY hostname
        ")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * Hostnames from inventory *and* the asset register, for pickers that
 * need to reach hardware which was never onboarded into inventory.
 *
 * platformHostnames() above stays inventory-only: its seven callers all
 * pick managed servers specifically, and silently widening them would
 * offer switches and appliances where only servers belong.
 *
 * Returns [['hostname' => ..., 'source' => 'inventory'|'asset',
 *           'detail' => short context], ...] sorted by hostname. A host
 * recorded in both is reported once, as 'inventory' -- that is the
 * richer record, and showing it twice would imply two machines.
 */
function platformHostnamesAll(PDO $pdo): array
{
    $out = [];

    try {
        $rows = $pdo->query("
            SELECT hostname, os_family, project, application
            FROM inventory
            WHERE hostname IS NOT NULL AND TRIM(hostname) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $r) {
            $h = trim((string) $r['hostname']);
            $detail = array_filter([
                trim((string) ($r['os_family'] ?? '')),
                trim((string) ($r['project'] ?? '')),
                trim((string) ($r['application'] ?? '')),
            ], fn($v) => $v !== '');

            $out[strtolower($h)] = [
                'hostname' => $h,
                'source'   => 'inventory',
                'detail'   => implode(' · ', $detail),
            ];
        }
    } catch (Throwable $e) {
        error_log('platformHostnamesAll: inventory read failed: ' . $e->getMessage());
    }

    try {
        $rows = $pdo->query("
            SELECT hostname, asset_name, asset_type, location
            FROM asset
            WHERE hostname IS NOT NULL AND TRIM(hostname) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);

        foreach ($rows as $r) {
            $h   = trim((string) $r['hostname']);
            $key = strtolower($h);

            // Inventory already claimed this host; keep the richer record.
            if (isset($out[$key])) { continue; }

            $detail = array_filter([
                trim((string) ($r['asset_type'] ?? '')),
                trim((string) ($r['asset_name'] ?? '')),
                trim((string) ($r['location'] ?? '')),
            ], fn($v) => $v !== '');

            $out[$key] = [
                'hostname' => $h,
                'source'   => 'asset',
                'detail'   => implode(' · ', $detail),
            ];
        }
    } catch (Throwable $e) {
        error_log('platformHostnamesAll: asset read failed: ' . $e->getMessage());
    }

    usort($out, fn($a, $b) => strcasecmp($a['hostname'], $b['hostname']));
    return $out;
}

/**
 * Splits a stored hostname list back into trimmed, de-duplicated names.
 *
 * Accepts newlines or commas so a list pasted from a spreadsheet, a
 * ticket, or an ansible inventory all parse the same way.
 */
function platformSplitHosts(?string $raw): array
{
    $parts = preg_split('/[\r\n,;]+/', (string) $raw) ?: [];
    $seen  = [];

    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') { continue; }

        // First spelling wins, matching the picker's client-side de-dupe --
        // otherwise a list survives a round-trip with its casing changed.
        $seen[strtolower($p)] ??= $p;
    }

    return array_values($seen);
}

/**
 * Distinct non-empty values of a column, for filter dropdowns.
 */
function platformDistinct(PDO $pdo, string $table, string $column): array
{
    // Identifiers cannot be bound; both come from page code, never input.
    if (!preg_match('/^[a-z_]+$/', $table) || !preg_match('/^[a-z_]+$/', $column)) {
        return [];
    }

    try {
        return $pdo->query("
            SELECT DISTINCT $column FROM $table
            WHERE $column IS NOT NULL AND TRIM($column) <> ''
            ORDER BY $column
        ")->fetchAll(PDO::FETCH_COLUMN);
    } catch (Throwable $e) {
        return [];
    }
}

/**
 * Streams a CSV export and ends the request.
 *
 * @param array<string,string> $columns  db column => header label
 */
function platformExportCsv(PDO $pdo, string $table, array $columns, string $where, array $params, string $filename): void
{
    if (!preg_match('/^[a-z_]+$/', $table)) {
        exit('Invalid export target.');
    }

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $filename . '_' . date('Y-m-d') . '.csv');

    $out = fopen('php://output', 'w');
    fputcsv($out, array_values($columns));

    try {
        $cols = implode(', ', array_keys($columns));
        $stmt = $pdo->prepare("SELECT $cols FROM $table WHERE $where ORDER BY id DESC");
        $stmt->execute($params);

        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            fputcsv($out, $row);
        }
    } catch (Throwable $e) {
        fputcsv($out, ['Export failed: ' . $e->getMessage()]);
    }

    fclose($out);
    exit;
}

/**
 * Field-level diff for the audit trail, so an update records what
 * actually changed rather than just "updated".
 */
function platformDiff(array $old, array $new, array $labels): string
{
    $changes = [];

    foreach ($new as $col => $value) {
        $before = trim((string) ($old[$col] ?? ''));
        $after  = trim((string) $value);

        if ($before === $after) {
            continue;
        }

        $label = $labels[$col] ?? $col;
        $changes[] = sprintf('%s: "%s" -> "%s"',
            $label,
            $before === '' ? '(empty)' : $before,
            $after === '' ? '(empty)' : $after);
    }

    return $changes ? implode("\n", $changes) : 'No field values changed.';
}

/**
 * Status pill colouring shared by all four modules.
 */
function platformStatusClass(string $status): string
{
    $s = strtolower(trim($status));

    if (in_array($s, ['active', 'ready', 'up', 'running', 'passed', 'healthy'], true))        { return 'ok'; }
    if (in_array($s, ['degraded', 'warning', 'partial', 'building', 'pending'], true))        { return 'warn'; }
    if (in_array($s, ['down', 'failed', 'decommissioned', 'error', 'not ready'], true))       { return 'crit'; }

    return 'neutral';
}
