<?php
/**
 * All-column search, shared by the inventory and asset lists.
 *
 * Both pages used to match a search term against a handful of columns --
 * five in inventory, four in assets -- chosen when the tables were much
 * smaller. Searching for a VLAN, a rack, an owner's name, a serial or a
 * support vendor therefore returned nothing at all, and nothing on the
 * page indicated that those columns were never consulted. An empty result
 * is indistinguishable from "no such record", which is the worst way for
 * a search to fail.
 *
 * Clauses are built from the page's own column map, so a column added to
 * the table becomes searchable at the same moment rather than being
 * forgotten here.
 */

/**
 * Splits a multi-value search box into individual terms.
 *
 * Accepts newlines, commas and semicolons so a list pasted from a
 * spreadsheet, a ticket or a shell loop all behave the same. Duplicates
 * are dropped case-insensitively -- repeating a term would otherwise add
 * a redundant OR branch and its bind parameters for no benefit.
 *
 * @return array<int,string>
 */
function splitSearchTerms(?string $raw): array
{
    $parts = preg_split('/[\r\n,;]+/', (string) $raw) ?: [];
    $seen  = [];

    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') {
            continue;
        }
        $seen[strtolower($p)] ??= $p;
    }

    return array_values($seen);
}

/**
 * One term, matched against every column in the map.
 *
 * COALESCE because a NULL column would otherwise make its comparison
 * unknown rather than false, and LOWER on both sides so matching is
 * case-insensitive regardless of the collation the column was created
 * with.
 *
 * @param  array<string,string> $columns key => label
 * @return array{0:string,1:array<int,string>} clause and its bind values
 */
function allColumnSearchClause(string $term, array $columns): array
{
    $needle = '%' . strtolower(trim($term)) . '%';

    $parts  = [];
    $params = [];

    foreach (array_keys($columns) as $col) {
        // Identifiers come from a page's own column map, never from input.
        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $col)) {
            continue;
        }
        $parts[]  = "LOWER(COALESCE($col,'')) LIKE ?";
        $params[] = $needle;
    }

    if (!$parts) {
        // No usable column: a clause that matches nothing is safer than
        // one that matches everything.
        return ['1=0', []];
    }

    return ['(' . implode(' OR ', $parts) . ')', $params];
}

/**
 * Resolves a field name typed by a user onto a real column key.
 *
 * Accepts the key ("os_version"), the display label ("OS Version") and
 * anything that slugs to either, so a user can type what they see in the
 * table header rather than having to know the schema.
 */
function resolveSearchField(string $name, array $columns): ?string
{
    $slug = trim(preg_replace('/[^a-z0-9]+/', '_', strtolower(trim($name))), '_');

    foreach ($columns as $key => $label) {
        if ($slug === $key) {
            return $key;
        }
        if ($slug === trim(preg_replace('/[^a-z0-9]+/', '_', strtolower($label)), '_')) {
            return $key;
        }
    }

    return null;
}

/**
 * A whole multi-value box, supporting field-scoped terms.
 *
 * Plain terms behave as before: each is matched against every column, and
 * they are OR-ed together, which is what a pasted list of hostnames means.
 *
 * A term may instead name a field:
 *
 *     os_family: RHEL          field contains RHEL
 *     OS Version: 7, 8         field contains 7 OR contains 8
 *     kernel_version = 9       field equals 9 exactly
 *
 * Values listed after a field are OR-ed with each other; different fields
 * are AND-ed together. That combination is the thing a plain OR box
 * cannot express -- "RHEL, 7, 8" as a flat list matches any row with a 7
 * anywhere in it, including a CPU count or an IP octet.
 *
 * Repeating a field simply adds to its OR group, so these are the same:
 *
 *     os_version: 7, 8
 *     os_version: 7
 *     os_version: 8
 *
 * @param  array<string,string> $columns key => label
 * @return array{0:string,1:array<int,string>}|null
 */
function multiValueSearchClause(?string $raw, array $columns): ?array
{
    // Field-scoped terms are separated by newlines and semicolons only:
    // a comma separates the values *within* one field.
    $lines = preg_split('/[\r\n;]+/', (string) $raw) ?: [];

    $scoped = [];   // column key => list of values (OR-ed)
    $plain  = [];   // unscoped terms (OR-ed, matched against every column)

    foreach ($lines as $line) {
        $line = trim($line);
        if ($line === '') {
            continue;
        }

        // "field: value" or "field = value". The field part is restricted
        // to word characters and spaces so a value containing a colon --
        // a URL, an IPv6 address, a time -- is not mistaken for a field.
        if (preg_match('/^([A-Za-z][A-Za-z0-9_ ]*?)\s*(:|=)\s*(.+)$/', $line, $m)) {
            $field = resolveSearchField($m[1], $columns);

            if ($field !== null) {
                $exact = $m[2] === '=';

                foreach (preg_split('/,/', $m[3]) as $value) {
                    $value = trim($value);
                    if ($value !== '') {
                        $scoped[$field][] = ['value' => $value, 'exact' => $exact];
                    }
                }
                continue;
            }
            // Unrecognised field name: fall through and treat the whole
            // line as an ordinary term rather than silently dropping it.
        }

        foreach (splitSearchTerms($line) as $t) {
            $plain[] = $t;
        }
    }

    if (!$scoped && !$plain) {
        return null;
    }

    $groups = [];
    $params = [];

    // One AND group per named field, OR-ing that field's values.
    foreach ($scoped as $field => $entries) {
        if (!preg_match('/^[a-z_][a-z0-9_]*$/', $field)) {
            continue;
        }

        $parts = [];
        foreach ($entries as $e) {
            if ($e['exact']) {
                $parts[]  = "LOWER(COALESCE($field,'')) = ?";
                $params[] = strtolower($e['value']);
            } else {
                $parts[]  = "LOWER(COALESCE($field,'')) LIKE ?";
                $params[] = '%' . strtolower($e['value']) . '%';
            }
        }

        if ($parts) {
            $groups[] = '(' . implode(' OR ', $parts) . ')';
        }
    }

    // All the unscoped terms together form one further AND group.
    if ($plain) {
        $anyCol = [];
        foreach ($plain as $term) {
            [$clause, $bind] = allColumnSearchClause($term, $columns);
            $anyCol[] = $clause;
            $params   = array_merge($params, $bind);
        }
        $groups[] = '(' . implode(' OR ', $anyCol) . ')';
    }

    if (!$groups) {
        return null;
    }

    return ['(' . implode(' AND ', $groups) . ')', $params];
}
