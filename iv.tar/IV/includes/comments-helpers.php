<?php
/**
 * Comments Helper Functions
 *
 * Provides CRUD operations for comments on KB articles and Known Issues
 */

/**
 * Get all comments for an item
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name (knowledge_base, known_issue)
 * @param int $item_id Item ID
 *
 * @return array Comments with author info
 */
function getComments(PDO $pdo, string $module, int $item_id): array
{
    try {
        $tableMap = [
            'knowledge_base' => 'knowledge_base_comments',
            'known_issue' => 'known_issue_comments',
        ];

        $idColMap = [
            'knowledge_base' => 'kb_id',
            'known_issue' => 'issue_id',
        ];

        $table = $tableMap[$module] ?? null;
        $idCol = $idColMap[$module] ?? null;

        if (!$table || !$idCol) {
            return [];
        }

        $stmt = $pdo->prepare("
            SELECT
                c.id,
                c.comment_text,
                c.commented_by,
                c.created_at,
                c.updated_at,
                u.first_name,
                u.last_name,
                u.ncgr_id
            FROM $table c
            LEFT JOIN users u ON c.commented_by = u.id
            WHERE c.$idCol = ?
            ORDER BY c.created_at ASC
        ");

        $stmt->execute([$item_id]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log("Error fetching comments: module=$module, item_id=$item_id: " . $e->getMessage());
        return [];
    }
}

/**
 * Add comment to an item
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name
 * @param int $item_id Item ID
 * @param string $comment_text Comment text
 * @param int $user_id User ID of commenter
 *
 * @return bool Success
 */
function addComment(PDO $pdo, string $module, int $item_id, string $comment_text, int $user_id): bool
{
    try {
        $tableMap = [
            'knowledge_base' => 'knowledge_base_comments',
            'known_issue' => 'known_issue_comments',
        ];

        $idColMap = [
            'knowledge_base' => 'kb_id',
            'known_issue' => 'issue_id',
        ];

        $table = $tableMap[$module] ?? null;
        $idCol = $idColMap[$module] ?? null;

        if (!$table || !$idCol) {
            return false;
        }

        $stmt = $pdo->prepare("
            INSERT INTO $table ($idCol, comment_text, commented_by, created_at, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ");

        return $stmt->execute([$item_id, $comment_text, $user_id]);
    } catch (Throwable $e) {
        error_log("Error adding comment: module=$module, item_id=$item_id: " . $e->getMessage());
        return false;
    }
}

/**
 * Delete a comment
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name
 * @param int $comment_id Comment ID
 *
 * @return bool Success
 */
function deleteComment(PDO $pdo, string $module, int $comment_id): bool
{
    try {
        $tableMap = [
            'knowledge_base' => 'knowledge_base_comments',
            'known_issue' => 'known_issue_comments',
        ];

        $table = $tableMap[$module] ?? null;

        if (!$table) {
            return false;
        }

        $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
        return $stmt->execute([$comment_id]);
    } catch (Throwable $e) {
        error_log("Error deleting comment: module=$module, comment_id=$comment_id: " . $e->getMessage());
        return false;
    }
}

/**
 * Format comments for HTML display
 *
 * @param array $comments Array of comments from getComments()
 *
 * @return string HTML
 */
function formatCommentsList(array $comments): string
{
    if (empty($comments)) {
        return '<div style="padding: 20px; text-align: center; color: #6b7280;">No comments yet. Be the first to comment!</div>';
    }

    $html = '<div class="comments-list">';

    foreach ($comments as $comment) {
        $authorName = trim(($comment['first_name'] ?? '') . ' ' . ($comment['last_name'] ?? ''));
        if (!$authorName) {
            $authorName = $comment['ncgr_id'] ?? 'Anonymous';
        }

        $timestamp = date('M d, Y H:i', strtotime($comment['created_at']));
        $commentText = htmlspecialchars((string)$comment['comment_text'], ENT_QUOTES, 'UTF-8');
        $commentId = (int)$comment['id'];
        $commentedBy = (int)$comment['commented_by'];

        $html .= '<div class="comment-item" style="border-bottom: 1px solid #e5e7eb; padding: 16px 0;">';
        $html .= '<div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 8px;">';
        $html .= '<div>';
        $html .= '<strong style="color: var(--text-primary);">' . htmlspecialchars($authorName) . '</strong>';
        $html .= '<br><small style="color: #6b7280;">' . $timestamp . '</small>';
        $html .= '</div>';
        $html .= '<button type="button" class="delete-comment-btn" data-comment-id="' . $commentId . '" data-commenter-id="' . $commentedBy . '" style="background: none; border: none; color: #ef4444; cursor: pointer; font-size: 0.85em; padding: 4px 8px;">Delete</button>';
        $html .= '</div>';
        $html .= '<p style="margin: 0; color: #334155; line-height: 1.5;">' . nl2br($commentText) . '</p>';
        $html .= '</div>';
    }

    $html .= '</div>';

    return $html;
}

/**
 * Get comment count for an item
 *
 * @param PDO $pdo Database connection
 * @param string $module Module name
 * @param int $item_id Item ID
 *
 * @return int Comment count
 */
function getCommentCount(PDO $pdo, string $module, int $item_id): int
{
    try {
        $tableMap = [
            'knowledge_base' => 'knowledge_base_comments',
            'known_issue' => 'known_issue_comments',
        ];

        $idColMap = [
            'knowledge_base' => 'kb_id',
            'known_issue' => 'issue_id',
        ];

        $table = $tableMap[$module] ?? null;
        $idCol = $idColMap[$module] ?? null;

        if (!$table || !$idCol) {
            return 0;
        }

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE $idCol = ?");
        $stmt->execute([$item_id]);
        return (int)$stmt->fetchColumn();
    } catch (Throwable $e) {
        return 0;
    }
}
