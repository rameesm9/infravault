<?php

/*
|--------------------------------------------------------------------------
| Shared notification feed
|--------------------------------------------------------------------------
|
| Pulls together the things a user actually needs to see in one place:
| open team communications/handover tasks (communications table), their
| visible reminders, and their visible sticky notes -- same visibility
| rule already used by reminders.php / sticky notes ("all", their own
| user_id, or admin sees everything).
|
| Used by both includes/header.php (notification bell) and home.php
| (dashboard notifications panel) so the two stay in sync.
|
*/

/*
|--------------------------------------------------------------------------
| Plain-PHP text truncation (no mbstring dependency -- this app runs
| fully offline on a minimal PHP setup that may not have it enabled)
|--------------------------------------------------------------------------
*/

if (!function_exists('infravault_truncate')) {
function infravault_truncate(string $text, int $length = 60): string
{
    $text = trim($text);

    if (strlen($text) <= $length) {
        return $text;
    }

    return rtrim(substr($text, 0, $length)) . '...';
}
}


function infravault_get_notifications(
    PDO $pdo,
    int $user_id,
    string $role
): array {

    $role_lower = strtolower(trim($role));


    /*
    |----------------------------------------------------------------
    | Team Communications / Handover Tasks (still open)
    |----------------------------------------------------------------
    */

    $communications = [];

    try {

        $stmt = $pdo->query("
            SELECT
                c.id,
                c.title,
                c.note_type,
                c.priority,
                c.status,
                c.created_at,
                u.first_name AS creator_first,
                u.last_name AS creator_last
            FROM communications c
            LEFT JOIN users u
                ON u.id = c.created_by
            WHERE c.status != 'Completed'
            ORDER BY c.created_at DESC
            LIMIT 6
        ");

        $communications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $communications = [];
    }


    /*
    |----------------------------------------------------------------
    | Communications assigned specifically to this user (Handover
    | Tasks -- the only note_type that sets assigned_to). Pulled as
    | its own query, not sliced from $communications above, so a busy
    | team-notes feed can never push a personal assignment out of view.
    |----------------------------------------------------------------
    */

    $assigned_to_me = [];

    try {

        $stmt = $pdo->prepare("
            SELECT
                c.id,
                c.title,
                c.note_type,
                c.priority,
                c.status,
                c.target_date,
                c.created_at,
                u.first_name AS creator_first,
                u.last_name AS creator_last
            FROM communications c
            LEFT JOIN users u
                ON u.id = c.created_by
            WHERE c.assigned_to = ?
              AND c.status != 'Completed'
            ORDER BY
                CASE WHEN c.target_date IS NOT NULL AND TRIM(c.target_date) != ''
                     THEN c.target_date ELSE c.created_at END ASC
            LIMIT 8
        ");

        $stmt->execute([$user_id]);

        $assigned_to_me = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $assigned_to_me = [];
    }


    /*
    |----------------------------------------------------------------
    | Reminders visible to this user
    |----------------------------------------------------------------
    */

    $reminders = [];
    $overdue_count = 0;

    try {

        $stmt = $pdo->prepare("
            SELECT
                r.id,
                r.title,
                r.reminder_date,
                r.visibility
            FROM reminders r
            WHERE
                r.visibility = 'all'
                OR r.user_id = ?
                OR ? = 'admin'
            ORDER BY r.reminder_date ASC
            LIMIT 6
        ");

        $stmt->execute([
            $user_id,
            $role_lower
        ]);

        $reminders = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $now = date('Y-m-d H:i:s');

        foreach ($reminders as $r) {

            if (
                !empty($r['reminder_date']) &&
                $r['reminder_date'] < $now
            ) {
                $overdue_count++;
            }
        }

    } catch (Throwable $e) {
        $reminders = [];
    }


    /*
    |----------------------------------------------------------------
    | Sticky notes visible to this user
    |----------------------------------------------------------------
    */

    $sticky_notes = [];

    try {

        $stmt = $pdo->prepare("
            SELECT
                n.id,
                n.content,
                n.visibility,
                n.updated_at,
                u.first_name,
                u.last_name
            FROM sticky_notes n
            LEFT JOIN users u
                ON u.id = n.user_id
            WHERE
                n.visibility = 'all'
                OR n.user_id = ?
                OR ? = 'admin'
            ORDER BY n.updated_at DESC
            LIMIT 5
        ");

        $stmt->execute([
            $user_id,
            $role_lower
        ]);

        $sticky_notes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Throwable $e) {
        $sticky_notes = [];
    }


    return [
        'communications'  => $communications,
        'assigned_to_me'  => $assigned_to_me,
        'reminders'       => $reminders,
        'sticky_notes'    => $sticky_notes,
        'badge_count'     => count($communications) + $overdue_count,
    ];
}
