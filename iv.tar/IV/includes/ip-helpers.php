<?php
/**
 * IP range maths, shared by ip.php.
 *
 * Ranges are stored as an `ip_range` string plus a `cidr` column. The
 * address in ip_range is NOT reliably the network address -- existing
 * rows contain values like "10.13.3.3/24", where .3 is just some host in
 * the subnet -- so the network is always recomputed from the address and
 * the prefix rather than being taken at face value.
 */

/**
 * Normalises a dotted-quad to an unsigned 32-bit integer.
 *
 * ip2long() returns a signed int on 32-bit builds and a large positive
 * one on 64-bit; masking makes the comparisons below behave the same on
 * both.
 *
 * @return int|null null when the value is not a valid IPv4 address
 */
function ipToLong(?string $ip): ?int
{
    $ip = trim((string) $ip);

    if ($ip === '' || !filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4)) {
        return null;
    }

    $long = ip2long($ip);

    return $long === false ? null : ($long & 0xFFFFFFFF);
}

/**
 * Network and broadcast bounds for a stored range.
 *
 * Accepts "10.1.2.0/24", or an address plus a separate prefix. Handles
 * /31 (RFC 3021 point-to-point, both addresses usable) and /32 (single
 * host) without special-casing: the arithmetic already collapses to the
 * right answer.
 *
 * @return array{network:int,broadcast:int,prefix:int,label:string}|null
 */
function ipRangeBounds(?string $ipRange, $cidr = null): ?array
{
    $ipRange = trim((string) $ipRange);

    if ($ipRange === '') {
        return null;
    }

    $prefix = null;
    $address = $ipRange;

    if (str_contains($ipRange, '/')) {
        [$address, $suffix] = explode('/', $ipRange, 2);
        $address = trim($address);
        if (is_numeric(trim($suffix))) {
            $prefix = (int) trim($suffix);
        }
    }

    // The cidr column wins only when the string carried no prefix.
    if ($prefix === null && $cidr !== null && is_numeric($cidr)) {
        $prefix = (int) $cidr;
    }

    if ($prefix === null || $prefix < 0 || $prefix > 32) {
        return null;
    }

    $long = ipToLong($address);

    if ($long === null) {
        return null;
    }

    // A /0 mask cannot be produced by shifting a 32-bit value left by 32,
    // so it is written out explicitly.
    $mask = $prefix === 0 ? 0 : ((0xFFFFFFFF << (32 - $prefix)) & 0xFFFFFFFF);

    $network   = $long & $mask;
    $broadcast = $network | (~$mask & 0xFFFFFFFF);

    return [
        'network'   => $network,
        'broadcast' => $broadcast,
        'prefix'    => $prefix,
        'label'     => long2ip($network) . '/' . $prefix,
    ];
}

/**
 * Is this address inside the range?
 */
function ipInRange(?string $ip, array $bounds): bool
{
    $long = ipToLong($ip);

    if ($long === null) {
        return false;
    }

    return $long >= $bounds['network'] && $long <= $bounds['broadcast'];
}

/**
 * Splits an additional_ips field into individual addresses.
 *
 * The column is free text and has been filled in with commas, spaces,
 * semicolons and newlines depending on who typed it, so all of them are
 * treated as separators.
 */
function ipSplitList(?string $value): array
{
    $parts = preg_split('/[\s,;|]+/', (string) $value, -1, PREG_SPLIT_NO_EMPTY);

    return $parts === false ? [] : $parts;
}

/**
 * Inventory hosts whose primary or additional address falls inside the
 * range.
 *
 * Matching is done in PHP rather than SQL because inventory.ip_address is
 * TEXT: SQLite has no IP type and no integer conversion for it, so a
 * BETWEEN on the stored strings would compare lexically ("10.14.9.1" >
 * "10.14.10.1") and silently return the wrong rows.
 *
 * @return array<int,array<string,mixed>>
 */
function ipHostsInRange(PDO $pdo, array $bounds): array
{
    try {
        $rows = $pdo->query("
            SELECT hostname, ip_address, additional_ips, os_family, os_version,
                   support_level, server_state, project, application, managed_by,
                   technical_owner
            FROM inventory
            WHERE hostname IS NOT NULL AND TRIM(hostname) <> ''
            ORDER BY hostname
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('ipHostsInRange: ' . $e->getMessage());
        return [];
    }

    $matched = [];

    foreach ($rows as $row) {

        $hits = [];

        if (ipInRange($row['ip_address'] ?? '', $bounds)) {
            $hits[] = ['ip' => trim((string) $row['ip_address']), 'primary' => true];
        }

        foreach (ipSplitList($row['additional_ips'] ?? '') as $extra) {
            if (ipInRange($extra, $bounds)) {
                $hits[] = ['ip' => $extra, 'primary' => false];
            }
        }

        if (!$hits) {
            continue;
        }

        $row['matched_ips'] = $hits;

        // Sorted by address so the list reads in network order rather
        // than alphabetically ("10.1.1.9" before "10.1.1.10").
        $row['sort_key'] = ipToLong($hits[0]['ip']) ?? 0;

        $matched[] = $row;
    }

    usort($matched, fn($a, $b) => $a['sort_key'] <=> $b['sort_key']);

    return $matched;
}

/**
 * Asset records whose address falls inside the range.
 *
 * The asset table carries a single `ip_address` and no additional-IP
 * column, so there is only one address per row to consider. Values that
 * are not valid IPv4 are simply skipped -- the column is free text and
 * does contain non-address entries.
 */
function ipAssetsInRange(PDO $pdo, array $bounds): array
{
    try {
        $rows = $pdo->query("
            SELECT asset_name, hostname, ip_address, asset_type, manufacturer, model,
                   serial_number, location, site, rack, status, vendor
            FROM asset
            WHERE ip_address IS NOT NULL AND TRIM(ip_address) <> ''
        ")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('ipAssetsInRange: ' . $e->getMessage());
        return [];
    }

    $matched = [];

    foreach ($rows as $row) {
        if (!ipInRange($row['ip_address'] ?? '', $bounds)) {
            continue;
        }

        $row['matched_ips'] = [['ip' => trim((string) $row['ip_address']), 'primary' => true]];
        $row['sort_key'] = ipToLong($row['ip_address']) ?? 0;

        $matched[] = $row;
    }

    usort($matched, fn($a, $b) => $a['sort_key'] <=> $b['sort_key']);

    return $matched;
}

/**
 * Which IP range row (if any) an address falls inside, for auto-filling
 * a record's VLAN/Port Group from Inventory's IP Address Management data
 * (used by asset.php: an asset's VLAN and Port Group are derived from its
 * IP Address rather than typed in, so they can never drift out of sync
 * with what ip.php actually has on file for that subnet).
 *
 * When an address falls inside more than one stored range (overlapping
 * ranges do exist -- e.g. a /16 summary alongside the /24s carved out of
 * it), the most specific one wins: the highest prefix, i.e. the smallest
 * matching subnet, same tie-break a router's longest-prefix-match would
 * use.
 *
 * @return array<string,mixed>|null the matching ip_ranges row, or null
 */
function ipFindRangeForAddress(PDO $pdo, ?string $ip): ?array
{
    if (ipToLong($ip) === null) {
        return null;
    }

    try {
        $ranges = $pdo->query("SELECT * FROM ip_ranges")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Throwable $e) {
        error_log('ipFindRangeForAddress: ' . $e->getMessage());
        return null;
    }

    $best = null;
    $bestPrefix = -1;

    foreach ($ranges as $range) {

        $bounds = ipRangeBounds($range['ip_range'] ?? null, $range['cidr'] ?? null);

        if ($bounds === null || !ipInRange($ip, $bounds)) {
            continue;
        }

        if ($bounds['prefix'] > $bestPrefix) {
            $bestPrefix = $bounds['prefix'];
            $best = $range;
            $best['matched_label'] = $bounds['label'];
        }
    }

    return $best;
}

/**
 * Everything in the range, from both Inventory and Assets, normalised to
 * one shape and sorted together by address.
 *
 * The two tables describe different things -- a server build versus a
 * physical asset record -- so their columns are mapped onto common
 * headings rather than shown as two disjoint tables. Sorting the merged
 * list by address is the point: it answers "what is actually using this
 * subnet", which is the question the tab exists for, and a device that
 * appears in both sources shows up adjacent rather than in two places.
 *
 * @return array<int,array<string,mixed>>
 */
function ipRecordsInRange(PDO $pdo, array $bounds): array
{
    $records = [];

    foreach (ipHostsInRange($pdo, $bounds) as $h) {
        $records[] = [
            'source'      => 'Inventory',
            'source_page' => 'inventory.php',
            'matched_ips' => $h['matched_ips'],
            'sort_key'    => $h['sort_key'],
            'name'        => (string) $h['hostname'],
            'kind'        => trim(($h['os_family'] ?? '') . ' ' . ($h['os_version'] ?? '')),
            'tier'        => (string) ($h['support_level'] ?? ''),
            'state'       => (string) ($h['server_state'] ?? ''),
            'context'     => (string) ($h['project'] ?? ''),
            'context_sub' => (string) ($h['application'] ?? ''),
            'owner'       => (string) ($h['technical_owner'] ?? ''),
        ];
    }

    foreach (ipAssetsInRange($pdo, $bounds) as $a) {
        // Prefer the asset's own name; fall back to its hostname.
        $name = trim((string) ($a['asset_name'] ?? ''));
        if ($name === '') {
            $name = trim((string) ($a['hostname'] ?? ''));
        }

        $place = array_filter([
            trim((string) ($a['site'] ?? '')),
            trim((string) ($a['location'] ?? '')),
        ]);

        $records[] = [
            'source'      => 'Asset',
            'source_page' => 'asset.php',
            'matched_ips' => $a['matched_ips'],
            'sort_key'    => $a['sort_key'],
            'name'        => $name !== '' ? $name : '(unnamed asset)',
            'kind'        => trim(($a['manufacturer'] ?? '') . ' ' . ($a['model'] ?? '')),
            'tier'        => (string) ($a['asset_type'] ?? ''),
            'state'       => (string) ($a['status'] ?? ''),
            'context'     => implode(' / ', $place),
            'context_sub' => trim((string) ($a['rack'] ?? '')) !== '' ? 'Rack ' . $a['rack'] : '',
            'owner'       => (string) ($a['vendor'] ?? ''),
        ];
    }

    usort($records, function ($a, $b) {
        // Same address in both tables: Inventory first, as the richer record.
        return [$a['sort_key'], $a['source']] <=> [$b['sort_key'], $b['source']];
    });

    return $records;
}
