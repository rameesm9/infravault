<?php
/**
 * Credential vault encryption.
 *
 * THE KEY
 * -------
 * Read from the APP_VAULT_KEY environment variable, base64-encoded,
 * decoding to exactly 32 bytes. It is deliberately NOT stored in the
 * database and there is deliberately no way to set it from the UI: a key
 * kept beside the ciphertext it protects is not a key, and a backup of
 * config/infravault.db would otherwise contain both halves.
 *
 * Generate one with:
 *     openssl rand -base64 32
 *
 * FAIL CLOSED
 * -----------
 * With no key configured the vault refuses to encrypt or decrypt rather
 * than falling back to storing plaintext. A vault that quietly degrades
 * to plaintext when misconfigured is worse than no vault, because people
 * keep using it believing the secrets are protected.
 *
 * THE CIPHER
 * ----------
 * AES-256-GCM: authenticated, so a row edited directly in the database
 * fails to decrypt instead of returning altered bytes. Each secret gets
 * its own random 96-bit IV -- reusing an IV under GCM with the same key
 * is catastrophic, so it is generated per encryption, never derived.
 */

const VAULT_CIPHER = 'aes-256-gcm';
const VAULT_KEY_VERSION = 1;

/**
 * @return string|null 32 raw key bytes, or null when unconfigured/invalid.
 */
function vaultKey(): ?string
{
    static $cached = false;

    if ($cached !== false) {
        return $cached;
    }

    $raw = (string) getenv('APP_VAULT_KEY');

    if (trim($raw) === '') {
        $cached = null;
        return null;
    }

    $key = base64_decode(trim($raw), true);

    if ($key === false || strlen($key) !== 32) {
        error_log('vault: APP_VAULT_KEY must be base64 for exactly 32 bytes (openssl rand -base64 32); vault disabled');
        $cached = null;
        return null;
    }

    $cached = $key;
    return $key;
}

function vaultIsConfigured(): bool
{
    return vaultKey() !== null && extension_loaded('openssl');
}

/**
 * Human-readable reason the vault is unavailable, for the UI.
 */
function vaultUnavailableReason(): string
{
    if (!extension_loaded('openssl')) {
        return 'The PHP openssl extension is not loaded, so secrets cannot be encrypted.';
    }

    $raw = (string) getenv('APP_VAULT_KEY');

    if (trim($raw) === '') {
        return 'APP_VAULT_KEY is not set. Generate one with "openssl rand -base64 32" and set it on the container.';
    }

    return 'APP_VAULT_KEY is set but is not valid base64 for exactly 32 bytes.';
}

/**
 * Encrypts one value.
 *
 * @return array{ct:string,iv:string,tag:string}|null
 */
function vaultEncrypt(string $plaintext): ?array
{
    $key = vaultKey();

    if ($key === null) {
        return null;
    }

    // 96-bit IV: the size GCM is specified for, and fresh every time.
    $iv = random_bytes(12);
    $tag = '';

    $ct = openssl_encrypt($plaintext, VAULT_CIPHER, $key, OPENSSL_RAW_DATA, $iv, $tag);

    if ($ct === false) {
        error_log('vault: encryption failed');
        return null;
    }

    return [
        'ct'  => base64_encode($ct),
        'iv'  => base64_encode($iv),
        'tag' => base64_encode($tag),
    ];
}

/**
 * Decrypts one value.
 *
 * Returns null on any failure -- wrong key, tampered ciphertext, corrupt
 * row. Callers must treat null as "cannot be shown", never as an empty
 * secret.
 */
function vaultDecrypt(?string $ct, ?string $iv, ?string $tag): ?string
{
    $key = vaultKey();

    if ($key === null || $ct === null || $ct === '' || $iv === null || $tag === null) {
        return null;
    }

    $ctRaw  = base64_decode($ct, true);
    $ivRaw  = base64_decode($iv, true);
    $tagRaw = base64_decode($tag, true);

    if ($ctRaw === false || $ivRaw === false || $tagRaw === false) {
        return null;
    }

    $plain = openssl_decrypt($ctRaw, VAULT_CIPHER, $key, OPENSSL_RAW_DATA, $ivRaw, $tagRaw);

    return $plain === false ? null : $plain;
}

/**
 * Appends to the access log.
 *
 * Called for reads as well as writes: REVEAL and COPY are the entries
 * that make the log worth having.
 */
function vaultLog(PDO $pdo, ?int $entryId, string $entryTitle, string $action, string $user): void
{
    try {
        $pdo->prepare("
            INSERT INTO vault_access_log (entry_id, entry_title, action, performed_by, ip_address)
            VALUES (?, ?, ?, ?, ?)
        ")->execute([
            $entryId,
            $entryTitle,
            strtoupper($action),
            $user,
            (string) ($_SERVER['REMOTE_ADDR'] ?? ''),
        ]);
    } catch (Throwable $e) {
        error_log('vault: unable to write access log: ' . $e->getMessage());
    }
}

/**
 * Rough password strength, shown next to stored secrets so weak ones are
 * visible without anyone having to reveal them.
 *
 * @return array{score:int,label:string,tone:string}
 */
function vaultStrength(string $secret): array
{
    $len = strlen($secret);
    $score = 0;

    if ($len >= 8)  { $score++; }
    if ($len >= 12) { $score++; }
    if ($len >= 16) { $score++; }
    if (preg_match('/[a-z]/', $secret) && preg_match('/[A-Z]/', $secret)) { $score++; }
    if (preg_match('/[0-9]/', $secret)) { $score++; }
    if (preg_match('/[^A-Za-z0-9]/', $secret)) { $score++; }

    if ($score <= 2) { return ['score' => $score, 'label' => 'Weak',   'tone' => 'crit']; }
    if ($score <= 4) { return ['score' => $score, 'label' => 'Fair',   'tone' => 'warn']; }

    return ['score' => $score, 'label' => 'Strong', 'tone' => 'ok'];
}
