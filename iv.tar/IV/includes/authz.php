<?php
/**
 * Authorization: the single source of truth.
 *
 * WHY THIS FILE EXISTS
 * --------------------
 * Authorization used to be re-implemented in every module: sixteen
 * separate `…HasPermission()` functions plus a shared helper, and they
 * did not agree with each other. Three different rules were in use:
 *
 *   - `WHERE role = ?`                (exact, case-sensitive)  x10 files
 *   - `WHERE TRIM(role) = TRIM(?)`    (trimmed)                x2  files
 *   - `WHERE LOWER(role) = LOWER(?)`  (case-insensitive)       shared helper
 *
 * and two definitions of "granted" ((int)$v === 1 versus a truthy list
 * of 1/true/yes/on). The same identity therefore resolved differently
 * depending on which page evaluated it -- a role stored with a trailing
 * space passed on patching.php and failed on inventory.php.
 *
 * Everything now funnels through authzCan(). One role-matching rule, one
 * definition of granted, one place to audit.
 *
 * THE MODEL
 * ---------
 * role -> page_key -> verb, where verb is exactly one of the six columns
 * on the `permissions` table. There is no second model: no hardcoded
 * role-name comparisons, no implicit "admin sees everything" bypass. An
 * administrator has access because the table grants it, which means the
 * permission screen tells the truth about what it controls.
 *
 * DENY BY DEFAULT
 * ---------------
 * A missing row is a deny. An unregistered page key is a deny (and is
 * logged, because it means a gate is pointing at nothing -- that is how
 * patch_servers.php silently denied every user until it was found).
 */

const AUTHZ_VERBS = [
    'can_view',
    'can_edit',
    'can_delete',
    'can_export',
    'can_import',
    'can_audit',
];

/** Values in the permission columns that mean "granted". */
const AUTHZ_TRUTHY = ['1', 'true', 'yes', 'on'];


/**
 * The current user's role, trimmed. Empty string when not signed in.
 */
function authzRole(): string
{
    return trim((string) ($_SESSION['role'] ?? ''));
}

function authzUserId(): int
{
    return (int) ($_SESSION['user_id'] ?? 0);
}

function authzIsLoggedIn(): bool
{
    return authzUserId() > 0;
}


/**
 * Is a page key registered?
 *
 * Checked against `permissions` rather than `pages`: `permissions` is
 * what a grant is actually read from, so a key present only in `pages`
 * would still deny everyone and should still be reported.
 */
function authzPageKeyIsKnown(PDO $pdo, string $pageKey): bool
{
    static $keys = null;

    if ($keys === null) {
        $keys = [];
        try {
            foreach ($pdo->query("SELECT DISTINCT page_key FROM permissions")->fetchAll(PDO::FETCH_COLUMN) as $k) {
                $keys[strtolower(trim((string) $k))] = true;
            }
        } catch (Throwable $e) {
            error_log('authz: unable to read page keys: ' . $e->getMessage());
            $keys = [];
        }
    }

    return isset($keys[strtolower(trim($pageKey))]);
}


/**
 * The one permission check.
 *
 * Role matching is trimmed and case-insensitive. That is deliberately
 * the most forgiving of the three rules that were previously in use:
 * tightening to exact matching would have silently revoked access from
 * any identity that had been relying on one of the looser helpers.
 */
function authzCan(PDO $pdo, string $role, string $pageKey, string $verb): bool
{
    if (!in_array($verb, AUTHZ_VERBS, true)) {
        error_log("authz: unknown verb '{$verb}' for page '{$pageKey}'");
        return false;
    }

    $role = trim($role);
    $pageKey = trim($pageKey);

    if ($role === '' || $pageKey === '') {
        return false;
    }

    // An unregistered key can never grant. Logged loudly: it means a gate
    // is guarding a page that does not exist in the permission model.
    if (!authzPageKeyIsKnown($pdo, $pageKey)) {
        error_log("authz: page_key '{$pageKey}' is not registered in the permissions table - denying");
        return false;
    }

    // Per-request cache: a page renders many checks (one per toolbar
    // button) and they would otherwise each be a query.
    static $cache = [];
    $cacheKey = strtolower($role) . '|' . strtolower($pageKey);

    if (!array_key_exists($cacheKey, $cache)) {
        try {
            $stmt = $pdo->prepare("
                SELECT can_view, can_edit, can_delete, can_export, can_import, can_audit
                FROM permissions
                WHERE LOWER(TRIM(role)) = LOWER(TRIM(?))
                  AND LOWER(TRIM(page_key)) = LOWER(TRIM(?))
                LIMIT 1
            ");
            $stmt->execute([$role, $pageKey]);
            $cache[$cacheKey] = $stmt->fetch(PDO::FETCH_ASSOC) ?: false;
        } catch (Throwable $e) {
            error_log("authz: lookup failed for role='{$role}' page='{$pageKey}': " . $e->getMessage());
            $cache[$cacheKey] = false;
        }
    }

    $row = $cache[$cacheKey];

    // No row = deny. Security must not depend on a row existing.
    if ($row === false || !array_key_exists($verb, $row)) {
        return false;
    }

    return in_array(strtolower(trim((string) $row[$verb])), AUTHZ_TRUTHY, true);
}


/**
 * Convenience wrapper using the signed-in user and the global connection.
 * Use for rendering decisions ("should this button exist?").
 */
function can(string $pageKey, string $verb): bool
{
    $pdo = $GLOBALS['pdo'] ?? null;

    if (!$pdo instanceof PDO) {
        error_log('authz: can() called with no database connection available');
        return false;
    }

    return authzCan($pdo, authzRole(), $pageKey, $verb);
}


/**
 * All six verbs for a page, for the common
 * `[$canView, $canEdit, ...] = authzFlags('inventory')` shape.
 *
 * @return array<string,bool>
 */
function authzFlags(string $pageKey): array
{
    $flags = [];
    foreach (AUTHZ_VERBS as $verb) {
        $flags[$verb] = can($pageKey, $verb);
    }
    return $flags;
}


/**
 * Ends the request unless someone is signed in.
 *
 * Call at the very top of every page, before any output.
 */
function requireLogin(): void
{
    if (authzIsLoggedIn()) {
        return;
    }

    if (PHP_SAPI === 'cli') {
        return;
    }

    if (!headers_sent()) {
        header('Location: index.php');
    }

    exit;
}


/**
 * Ends the request unless the signed-in user holds the permission.
 *
 * Deliberately a 403 rather than a redirect: redirecting to another page
 * that is itself permission-gated is how redirect loops start, and a
 * refusal should be visible rather than disguised as navigation.
 */
function requirePermission(string $pageKey, string $verb = 'can_view'): void
{
    requireLogin();

    if (can($pageKey, $verb)) {
        return;
    }

    if (!headers_sent()) {
        http_response_code(403);
    }

    $label = str_replace('can_', '', $verb);

    exit('You do not have permission to ' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8')
       . ' this page. Ask an administrator to grant it under Manage Permissions.');
}


/**
 * Guards the last remaining administrator.
 *
 * Without this, the account holding permission.can_edit can revoke it
 * from its own role and lock every user out of the permission screen --
 * unrecoverable through the UI.
 *
 * @return bool true when the change is safe to apply
 */
function authzWouldOrphanAdmin(PDO $pdo, string $role, array $newFlags): bool
{
    // Only relevant when the change removes edit rights on the
    // permission page itself.
    $stillGrants = in_array(strtolower(trim((string) ($newFlags['can_edit'] ?? '0'))), AUTHZ_TRUTHY, true);

    if ($stillGrants) {
        return false;
    }

    try {
        // Any OTHER role that both keeps permission.can_edit and has at
        // least one user assigned to it.
        $stmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM permissions p
            JOIN users u ON LOWER(TRIM(u.role)) = LOWER(TRIM(p.role))
            WHERE p.page_key = 'permission'
              AND p.can_edit = 1
              AND LOWER(TRIM(p.role)) <> LOWER(TRIM(?))
              AND u.is_approved = 1
        ");
        $stmt->execute([$role]);

        return ((int) $stmt->fetchColumn()) === 0;

    } catch (Throwable $e) {
        error_log('authz: orphan-admin check failed: ' . $e->getMessage());
        // Fail safe: block the change rather than risk a lockout.
        return true;
    }
}
