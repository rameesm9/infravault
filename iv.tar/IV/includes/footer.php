</div>


<footer>


InfraVault © <?= date("Y"); ?>

&nbsp; | &nbsp;

Enterprise IT Inventory Management


</footer>



<?php
/*
| The footer's inline <style> block was removed rather than updated.
|
| It re-declared `footer { ... }` with hardcoded background:white,
| color:#64748B and border-top:#E2E8F0. Being later in the document at
| the same specificity as the rule in assets/css/style.css, it won the
| cascade -- so the footer stayed white with light-grey text in dark
| mode, ignoring --bg-footer entirely.
|
| style.css already styles the footer fully (fixed position, flex
| centring, height, and the themed colours), so the padding/text-align
| here were redundant against a flex-centred bar.
*/
?>

<script src="assets/js/app.js"></script>
<script src="assets/js/sidebar.js"></script>
</body>

</html>
