<?php
/**
 * Avatar catalogue and renderer.
 *
 * Single source of truth. The avatar list used to be written out twice --
 * an emoji map inside get_user_avatar() in includes/header.php and a
 * separate $avatars / $avatar_labels / $avatar_display trio in
 * myprofile.php -- so adding or renaming one meant editing both, and the
 * two could (and did) drift apart.
 *
 * Avatars are flat illustrated portraits built as inline SVG rather than
 * emoji: emoji render differently on every OS (and several of the old
 * ones were plain pictograms like a star or a clown rather than people),
 * whereas these look identical everywhere and need no image files.
 *
 * The set is weighted for this deployment's users -- Gulf/Middle East
 * first, then South Asian, then general and role-based options.
 *
 * Every portrait is composed from the same parts (background, shoulders,
 * neck, head, features, then a headwear layer), so a new option is a
 * data row here rather than a new hand-drawn illustration.
 */

/**
 * Skin tones: [base, shade]. The shade is used for the neck, which sits
 * in shadow under the chin.
 */
const AVATAR_SKIN_TONES = [
    'light'  => ['#F2CDA7', '#DDAE86'],
    'medium' => ['#DFA97B', '#C68C60'],
    'tan'    => ['#C68A58', '#A97143'],
    'brown'  => ['#9C6437', '#7E4E28'],
    'deep'   => ['#71441F', '#573316'],
];

/**
 * The catalogue.
 *
 * group   - used to render the picker in labelled sections
 * bg      - circle background
 * skin    - key into AVATAR_SKIN_TONES
 * hair    - hair / brow / facial-hair colour
 * cloth   - shoulders colour
 * head    - headwear style (see avatarHeadwear)
 * head2   - headwear colour
 * face    - optional facial features: beard, moustache, glasses, sunglasses, bindi
 */
function avatarCatalogue(): array
{
    return [

        /* ---------------- Middle East ---------------- */

        'me_ghutra_white' => [
            'label' => 'Ghutra', 'group' => 'Middle East',
            'bg' => '#2E6F8E', 'skin' => 'medium', 'hair' => '#2B2118',
            'cloth' => '#F4F6F8', 'head' => 'ghutra', 'head2' => '#FFFFFF',
            'face' => ['beard', 'moustache'],
        ],
        'me_ghutra_red' => [
            'label' => 'Shemagh', 'group' => 'Middle East',
            'bg' => '#3F6D57', 'skin' => 'medium', 'hair' => '#2B2118',
            'cloth' => '#F4F6F8', 'head' => 'ghutra_check', 'head2' => '#E8494A',
            'face' => ['beard', 'moustache'],
        ],
        'me_thobe' => [
            'label' => 'Thobe', 'group' => 'Middle East',
            'bg' => '#B4552F', 'skin' => 'tan', 'hair' => '#241C15',
            'cloth' => '#FAFBFC', 'head' => 'short', 'head2' => '#241C15',
            'face' => ['beard', 'moustache'],
        ],
        'me_hijab_navy' => [
            'label' => 'Hijab', 'group' => 'Middle East',
            'bg' => '#C9A227', 'skin' => 'medium', 'hair' => '#2B2118',
            'cloth' => '#26355B', 'head' => 'hijab', 'head2' => '#26355B',
            'face' => [],
        ],
        'me_hijab_teal' => [
            'label' => 'Hijab', 'group' => 'Middle East',
            'bg' => '#7A4E8C', 'skin' => 'light', 'hair' => '#2B2118',
            'cloth' => '#0E7C7B', 'head' => 'hijab', 'head2' => '#0E7C7B',
            'face' => [],
        ],
        'me_abaya' => [
            'label' => 'Abaya', 'group' => 'Middle East',
            'bg' => '#4C7FA8', 'skin' => 'tan', 'hair' => '#2B2118',
            'cloth' => '#23252B', 'head' => 'hijab', 'head2' => '#23252B',
            'face' => [],
        ],

        /* ---------------- South Asia ---------------- */

        'in_turban' => [
            'label' => 'Turban', 'group' => 'South Asia',
            'bg' => '#2F6E5A', 'skin' => 'tan', 'hair' => '#26201A',
            'cloth' => '#E8E3D8', 'head' => 'turban', 'head2' => '#D9552F',
            'face' => ['beard', 'moustache'],
        ],
        'in_man' => [
            'label' => 'Classic', 'group' => 'South Asia',
            'bg' => '#3C63A8', 'skin' => 'tan', 'hair' => '#1F1913',
            'cloth' => '#F2F4F6', 'head' => 'short', 'head2' => '#1F1913',
            'face' => ['moustache'],
        ],
        'in_man_glasses' => [
            'label' => 'Glasses', 'group' => 'South Asia',
            'bg' => '#8E5B3C', 'skin' => 'brown', 'hair' => '#171310',
            'cloth' => '#3E4C63', 'head' => 'short', 'head2' => '#171310',
            'face' => ['glasses', 'moustache'],
        ],
        'in_saree' => [
            'label' => 'Saree', 'group' => 'South Asia',
            'bg' => '#2C7A6B', 'skin' => 'tan', 'hair' => '#1B1510',
            'cloth' => '#D6425F', 'head' => 'bun', 'head2' => '#1B1510',
            'face' => ['bindi'],
        ],
        'in_braid' => [
            'label' => 'Braid', 'group' => 'South Asia',
            'bg' => '#B8562F', 'skin' => 'medium', 'hair' => '#1B1510',
            'cloth' => '#4C6EBF', 'head' => 'braid', 'head2' => '#1B1510',
            'face' => ['bindi'],
        ],
        'in_dupatta' => [
            'label' => 'Dupatta', 'group' => 'South Asia',
            'bg' => '#5B5FA8', 'skin' => 'tan', 'hair' => '#1B1510',
            'cloth' => '#E9A23B', 'head' => 'dupatta', 'head2' => '#E9A23B',
            'face' => ['bindi'],
        ],

        /* ---------------- Roles ---------------- */

        'role_support' => [
            'label' => 'Helpdesk', 'group' => 'Roles',
            'bg' => '#2F6DB5', 'skin' => 'light', 'hair' => '#4A3524',
            'cloth' => '#1E3A5F', 'head' => 'headset', 'head2' => '#2A2E35',
            'face' => [],
        ],
        'role_engineer' => [
            'label' => 'Engineer', 'group' => 'Roles',
            'bg' => '#39708B', 'skin' => 'medium', 'hair' => '#2B2118',
            'cloth' => '#E8A33D', 'head' => 'hardhat', 'head2' => '#F2B33D',
            'face' => ['moustache'],
        ],
        'role_doctor' => [
            'label' => 'Medical', 'group' => 'Roles',
            'bg' => '#4FA3A0', 'skin' => 'light', 'hair' => '#3A2A1C',
            'cloth' => '#1F9E8F', 'head' => 'short', 'head2' => '#3A2A1C',
            'face' => ['glasses'],
        ],
        'role_security' => [
            'label' => 'Security', 'group' => 'Roles',
            'bg' => '#2B3B57', 'skin' => 'brown', 'hair' => '#141010',
            'cloth' => '#2B3B57', 'head' => 'cap', 'head2' => '#1B2740',
            'face' => ['sunglasses'],
        ],

        /* ---------------- General ---------------- */

        'gen_man' => [
            'label' => 'Classic', 'group' => 'General',
            'bg' => '#4A7FBF', 'skin' => 'light', 'hair' => '#5A3E27',
            'cloth' => '#33507A', 'head' => 'short', 'head2' => '#5A3E27',
            'face' => [],
        ],
        'gen_woman' => [
            'label' => 'Classic', 'group' => 'General',
            'bg' => '#C25E86', 'skin' => 'light', 'hair' => '#7A4A2B',
            'cloth' => '#8E3D63', 'head' => 'long', 'head2' => '#7A4A2B',
            'face' => [],
        ],
        'gen_man_dark' => [
            'label' => 'Curly', 'group' => 'General',
            'bg' => '#C7502F', 'skin' => 'deep', 'hair' => '#171210',
            'cloth' => '#5C3A8E', 'head' => 'curly', 'head2' => '#171210',
            'face' => [],
        ],
        'gen_woman_curly' => [
            'label' => 'Curls', 'group' => 'General',
            'bg' => '#3E8E7E', 'skin' => 'brown', 'hair' => '#191412',
            'cloth' => '#D9552F', 'head' => 'curly', 'head2' => '#191412',
            'face' => [],
        ],
        'gen_glasses' => [
            'label' => 'Glasses', 'group' => 'General',
            'bg' => '#6B7BA8', 'skin' => 'light', 'hair' => '#2E2118',
            'cloth' => '#3B4A63', 'head' => 'short', 'head2' => '#2E2118',
            'face' => ['glasses'],
        ],
        'gen_grey' => [
            'label' => 'Senior', 'group' => 'General',
            'bg' => '#5F7A8C', 'skin' => 'light', 'hair' => '#C9CDD2',
            'cloth' => '#44546B', 'head' => 'short', 'head2' => '#C9CDD2',
            'face' => ['glasses', 'moustache'],
        ],
    ];
}

/**
 * Legacy keys stored on existing user rows, mapped onto the new set so
 * nobody's saved choice resolves to nothing after this change.
 */
function avatarLegacyMap(): array
{
    return [
        'smile'        => 'gen_man',
        'cool'         => 'role_security',
        'grin'         => 'gen_man',
        'heart_eyes'   => 'gen_woman',
        'hug'          => 'gen_woman',
        'nerd'         => 'gen_glasses',
        'man'          => 'gen_man',
        'woman'        => 'gen_woman',
        'man_tech'     => 'role_support',
        'woman_tech'   => 'role_support',
        'man_office'   => 'gen_man',
        'woman_office' => 'gen_woman',
        'star'         => 'initials',
        'sun'          => 'initials',
        'moon'         => 'initials',
        'heart'        => 'initials',
        'clown'        => 'initials',
    ];
}

/**
 * Resolves a stored value to a key that exists in the current catalogue.
 */
function avatarResolveKey(?string $key): string
{
    $key = trim((string) $key);

    if ($key === '' || $key === 'initials') {
        return 'initials';
    }

    if (array_key_exists($key, avatarCatalogue())) {
        return $key;
    }

    $legacy = avatarLegacyMap();

    return $legacy[$key] ?? 'initials';
}

function avatarLabel(string $key): string
{
    $catalogue = avatarCatalogue();
    return $catalogue[$key]['label'] ?? 'Initials';
}

/**
 * Headwear / hair layers. Returned as two pieces: what is drawn behind
 * the head (hair falling behind the shoulders, hijab body) and what is
 * drawn in front (fringe, headwear).
 *
 * @return array{0:string,1:string} [behind, front]
 */
function avatarHeadwear(string $style, string $colour, string $hair): array
{
    $behind = '';
    $front  = '';

    switch ($style) {

        case 'short':
            $front = '<path d="M30 43c0-13 8-21 20-21s20 8 20 21c0-7-7-11-20-11s-20 4-20 11z" fill="' . $hair . '"/>';
            break;

        case 'curly':
            $behind = '<circle cx="34" cy="30" r="9" fill="' . $hair . '"/>'
                    . '<circle cx="50" cy="24" r="10" fill="' . $hair . '"/>'
                    . '<circle cx="66" cy="30" r="9" fill="' . $hair . '"/>'
                    . '<circle cx="30" cy="41" r="7" fill="' . $hair . '"/>'
                    . '<circle cx="70" cy="41" r="7" fill="' . $hair . '"/>';
            $front  = '<path d="M31 42c0-12 8-20 19-20s19 8 19 20c0-6-7-10-19-10s-19 4-19 10z" fill="' . $hair . '"/>';
            break;

        case 'long':
            $behind = '<path d="M27 44c0-16 10-24 23-24s23 8 23 24v26h-8V44a15 15 0 0 0-30 0v26h-8z" fill="' . $hair . '"/>';
            $front  = '<path d="M30 43c0-13 8-21 20-21s20 8 20 21c0-7-7-11-20-11s-20 4-20 11z" fill="' . $hair . '"/>';
            break;

        case 'bun':
            $behind = '<circle cx="50" cy="19" r="8" fill="' . $hair . '"/>'
                    . '<path d="M28 46c0-16 10-25 22-25s22 9 22 25v14h-6V45a16 16 0 0 0-32 0v15h-6z" fill="' . $hair . '"/>';
            $front  = '<path d="M30 43c0-13 8-21 20-21s20 8 20 21c0-7-7-11-20-11s-20 4-20 11z" fill="' . $hair . '"/>';
            break;

        case 'braid':
            $behind = '<path d="M28 45c0-16 10-24 22-24s22 8 22 24v10h-6V45a16 16 0 0 0-32 0v10h-6z" fill="' . $hair . '"/>'
                    . '<path d="M66 52c5 6 6 16 4 26h-8c2-9 1-18-2-24z" fill="' . $hair . '"/>'
                    . '<circle cx="66" cy="62" r="3.4" fill="' . $hair . '"/>'
                    . '<circle cx="66" cy="70" r="3.2" fill="' . $hair . '"/>';
            $front  = '<path d="M30 43c0-13 8-21 20-21s20 8 20 21c0-7-7-11-20-11s-20 4-20 11z" fill="' . $hair . '"/>';
            break;

        case 'hijab':
            // Cloth behind: covers hair, sides and shoulders.
            $behind = '<path d="M50 16c-16 0-25 12-25 27 0 8 2 14 5 19l-7 14h54l-7-14c3-5 5-11 5-19 0-15-9-27-25-27z" fill="' . $colour . '"/>';
            // Front band framing the face.
            $front  = '<path d="M50 20a24 24 0 0 0-24 24v6h7v-6a17 17 0 0 1 34 0v6h7v-6a24 24 0 0 0-24-24z" fill="' . $colour . '"/>'
                    . '<path d="M26 44a24 24 0 0 1 48 0 27 27 0 0 0-48 0z" fill="rgba(0,0,0,.10)"/>';
            break;

        case 'dupatta':
            // Looser than a hijab: a little hair shows at the front.
            $behind = '<path d="M50 17c-15 0-24 11-24 26 0 8 2 14 5 19l-6 12h50l-6-12c3-5 5-11 5-19 0-15-9-26-24-26z" fill="' . $colour . '"/>';
            $front  = '<path d="M31 43c0-12 8-20 19-20s19 8 19 20c0-6-7-10-19-10s-19 4-19 10z" fill="' . $hair . '"/>'
                    . '<path d="M50 19a25 25 0 0 0-24 20l-1 7h6l1-5a19 19 0 0 1 36 0l1 5h6l-1-7a25 25 0 0 0-24-20z" fill="' . $colour . '"/>';
            break;

        case 'turban':
            $front = '<path d="M27 44c0-18 10-28 23-28s23 10 23 28c-4-6-11-10-23-10s-19 4-23 10z" fill="' . $colour . '"/>'
                   . '<path d="M27 44c4-6 11-10 23-10s19 4 23 10c0-4-1-7-2-10-5-4-12-6-21-6s-16 2-21 6c-1 3-2 6-2 10z" fill="rgba(0,0,0,.12)"/>'
                   . '<path d="M50 16c-6 0-11 2-15 5 4-1 9-2 15-2s11 1 15 2c-4-3-9-5-15-5z" fill="rgba(255,255,255,.18)"/>';
            break;

        case 'ghutra':
        case 'ghutra_check':
            $fill = $style === 'ghutra_check' ? 'url(#kef)' : $colour;
            // Cloth draping behind the head and down both sides.
            $behind = '<path d="M50 15c-17 0-26 12-26 27v28h9V44a17 17 0 0 1 34 0v26h9V42c0-15-9-27-26-27z" fill="' . $fill . '"/>';
            // Crown of the cloth plus the black agal cord.
            $front  = '<path d="M50 17c-15 0-24 11-24 25v4h8v-4a16 16 0 0 1 32 0v4h8v-4c0-14-9-25-24-25z" fill="' . $fill . '"/>'
                    . '<rect x="25" y="23" width="50" height="4.6" rx="2.3" fill="#1C1C1C"/>'
                    . '<rect x="25" y="29.5" width="50" height="4.6" rx="2.3" fill="#1C1C1C"/>';
            break;

        case 'hardhat':
            $front = '<path d="M28 42a22 22 0 0 1 44 0z" fill="' . $colour . '"/>'
                   . '<rect x="21" y="40" width="58" height="5.4" rx="2.7" fill="' . $colour . '"/>'
                   . '<rect x="21" y="40" width="58" height="5.4" rx="2.7" fill="rgba(0,0,0,.14)"/>'
                   . '<rect x="47" y="21" width="6" height="20" rx="3" fill="rgba(0,0,0,.12)"/>';
            break;

        case 'cap':
            $front = '<path d="M28 41a22 22 0 0 1 44 0z" fill="' . $colour . '"/>'
                   . '<rect x="24" y="39" width="52" height="5" rx="2.5" fill="rgba(0,0,0,.22)"/>'
                   . '<path d="M26 44h26a10 10 0 0 1-10 6H30a4 4 0 0 1-4-4z" fill="rgba(0,0,0,.30)"/>'
                   . '<circle cx="50" cy="30" r="4" fill="rgba(255,255,255,.30)"/>';
            break;

        case 'headset':
            $front = '<path d="M30 43c0-13 8-21 20-21s20 8 20 21c0-7-7-11-20-11s-20 4-20 11z" fill="' . $hair . '"/>'
                   . '<path d="M27 44a23 23 0 0 1 46 0" stroke="' . $colour . '" stroke-width="4.6" fill="none" stroke-linecap="round"/>'
                   . '<rect x="22" y="41" width="8" height="14" rx="4" fill="' . $colour . '"/>'
                   . '<rect x="70" y="41" width="8" height="14" rx="4" fill="' . $colour . '"/>'
                   . '<path d="M26 55c0 8 6 12 12 13" stroke="' . $colour . '" stroke-width="2.6" fill="none" stroke-linecap="round"/>'
                   . '<circle cx="39" cy="68" r="3" fill="' . $colour . '"/>';
            break;
    }

    return [$behind, $front];
}

/**
 * Facial feature layers.
 */
function avatarFace(array $features, string $hair, string $skinShade): string
{
    $svg = '';

    if (in_array('beard', $features, true)) {
        // Follows the jaw, leaving the mouth clear.
        $svg .= '<path d="M31 42v4c0 12 8 21 19 21s19-9 19-21v-4c-2 9-8 14-19 14s-17-5-19-14z" fill="' . $hair . '"/>';
    }

    // Eyes sit above any beard.
    $svg .= '<ellipse cx="42.5" cy="43" rx="2.5" ry="2.9" fill="#2A2118"/>'
          . '<ellipse cx="57.5" cy="43" rx="2.5" ry="2.9" fill="#2A2118"/>';

    // Brows.
    $svg .= '<path d="M38.5 37.5q4-2.6 8-.4" stroke="' . $hair . '" stroke-width="1.9" fill="none" stroke-linecap="round"/>'
          . '<path d="M61.5 37.5q-4-2.6-8-.4" stroke="' . $hair . '" stroke-width="1.9" fill="none" stroke-linecap="round"/>';

    // Nose + mouth.
    $svg .= '<path d="M50 45v4.5" stroke="' . $skinShade . '" stroke-width="1.8" fill="none" stroke-linecap="round"/>'
          . '<path d="M45.5 54q4.5 3.4 9 0" stroke="#8C4B3C" stroke-width="1.9" fill="none" stroke-linecap="round"/>';

    if (in_array('moustache', $features, true)) {
        $svg .= '<path d="M42.5 51.5q7.5 3.4 15 0-7.5-2.6-15 0z" fill="' . $hair . '"/>';
    }

    if (in_array('bindi', $features, true)) {
        $svg .= '<circle cx="50" cy="33" r="2" fill="#C62B4A"/>';
    }

    if (in_array('glasses', $features, true)) {
        $svg .= '<g fill="none" stroke="#2F3742" stroke-width="1.9">'
              . '<rect x="35.5" y="38.5" width="14" height="10" rx="5"/>'
              . '<rect x="50.5" y="38.5" width="14" height="10" rx="5"/>'
              . '<path d="M49.5 43.5h1"/>'
              . '</g>';
    }

    if (in_array('sunglasses', $features, true)) {
        $svg .= '<g fill="#23252B">'
              . '<rect x="34.5" y="38" width="15" height="10.5" rx="5"/>'
              . '<rect x="50.5" y="38" width="15" height="10.5" rx="5"/>'
              . '<rect x="49" y="42" width="2" height="2.2"/>'
              . '</g>';
    }

    return $svg;
}

/**
 * Renders one avatar as inline SVG.
 *
 * @param string $key   Catalogue key, or 'initials'
 * @param int    $size  Rendered pixel size
 * @param string $text  Initial(s), used only by the 'initials' avatar
 * @param string $bg    Background for the 'initials' avatar
 */
function renderAvatar(string $key, int $size = 40, string $text = 'U', string $bg = '#3B82F6'): string
{
    static $uid = 0;
    $uid++;

    $key = avatarResolveKey($key);
    $px = (int) $size;

    if ($key === 'initials') {
        $initial = htmlspecialchars(strtoupper(substr(trim($text) !== '' ? $text : 'U', 0, 1)), ENT_QUOTES, 'UTF-8');
        return '<svg class="iv-avatar" viewBox="0 0 100 100" width="' . $px . '" height="' . $px . '" '
             . 'role="img" aria-label="Initial ' . $initial . '">'
             . '<circle cx="50" cy="50" r="50" fill="' . htmlspecialchars($bg, ENT_QUOTES, 'UTF-8') . '"/>'
             . '<text x="50" y="50" text-anchor="middle" dominant-baseline="central" '
             . 'font-family="Inter, Segoe UI, Arial, sans-serif" font-size="44" font-weight="700" fill="#FFFFFF">'
             . $initial . '</text></svg>';
    }

    $a = avatarCatalogue()[$key];

    [$skin, $skinShade] = AVATAR_SKIN_TONES[$a['skin']] ?? AVATAR_SKIN_TONES['medium'];

    [$behind, $front] = avatarHeadwear($a['head'], $a['head2'], $a['hair']);

    $clip = 'ivc' . $uid;

    $defs = '<clipPath id="' . $clip . '"><circle cx="50" cy="50" r="50"/></clipPath>';

    // The keffiyeh check is a real pattern rather than drawn lines so it
    // scales with the avatar instead of turning into mush at 32px.
    //
    // The id is per-render: this avatar can appear twice on one page (the
    // header shows the user's choice while the profile picker lists every
    // option), and a duplicate id is invalid HTML.
    $kef = 'ivk' . $uid;

    if ($a['head'] === 'ghutra_check') {
        $defs .= '<pattern id="' . $kef . '" width="8" height="8" patternUnits="userSpaceOnUse">'
               . '<rect width="8" height="8" fill="#FFFFFF"/>'
               . '<path d="M0 0h4v4H0z" fill="' . $a['head2'] . '" opacity=".85"/>'
               . '<path d="M4 4h4v4H4z" fill="' . $a['head2'] . '" opacity=".85"/>'
               . '</pattern>';

        // The headwear layer was built before the id was known.
        $behind = str_replace('url(#kef)', 'url(#' . $kef . ')', $behind);
        $front  = str_replace('url(#kef)', 'url(#' . $kef . ')', $front);
    }

    return '<svg class="iv-avatar" viewBox="0 0 100 100" width="' . $px . '" height="' . $px . '" '
         . 'role="img" aria-label="' . htmlspecialchars($a['label'], ENT_QUOTES, 'UTF-8') . ' avatar">'
         . '<defs>' . $defs . '</defs>'
         . '<g clip-path="url(#' . $clip . ')">'
         . '<rect width="100" height="100" fill="' . $a['bg'] . '"/>'
         . $behind
         // Shoulders.
         . '<path d="M50 64c-19 0-32 12-35 24l-1 12h72l-1-12c-3-12-16-24-35-24z" fill="' . $a['cloth'] . '"/>'
         // Neck.
         . '<path d="M43 55h14v13a7 7 0 0 1-14 0z" fill="' . $skinShade . '"/>'
         // Head + ears.
         . '<ellipse cx="50" cy="43" rx="19" ry="22" fill="' . $skin . '"/>'
         . '<circle cx="30.5" cy="45" r="4" fill="' . $skin . '"/>'
         . '<circle cx="69.5" cy="45" r="4" fill="' . $skin . '"/>'
         . avatarFace($a['face'], $a['hair'], $skinShade)
         . $front
         . '</g></svg>';
}

/**
 * Catalogue grouped by section, for the picker.
 */
function avatarGroups(): array
{
    $groups = [];

    foreach (avatarCatalogue() as $key => $a) {
        $groups[$a['group']][$key] = $a;
    }

    return $groups;
}
