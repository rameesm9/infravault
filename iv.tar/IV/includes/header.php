<?php

if(session_status() === PHP_SESSION_NONE){
    session_start();
}


require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/notifications.php';


$page_title = $page_title ?? "InfraVault";

$header_notifications = infravault_get_notifications(
    $pdo,
    (int) ($_SESSION['user_id'] ?? 0),
    (string) ($_SESSION['role'] ?? '')
);

if (!function_exists('notif_time_ago')) {
function notif_time_ago(?string $datetime): string
{
    if (!$datetime) {
        return '';
    }

    $timestamp = strtotime($datetime);

    if (!$timestamp) {
        return '';
    }

    $diff = time() - $timestamp;

    if ($diff < 60) {
        return 'just now';
    }
    if ($diff < 3600) {
        return floor($diff / 60) . 'm ago';
    }
    if ($diff < 86400) {
        return floor($diff / 3600) . 'h ago';
    }
    if ($diff < 2592000) {
        return floor($diff / 86400) . 'd ago';
    }

    return date('d M Y', $timestamp);
}
}

require_once __DIR__ . '/avatars.php';

if (!function_exists('get_user_avatar')) {
/**
 * Renders a user's chosen avatar.
 *
 * The emoji map that used to live here has moved to includes/avatars.php
 * as illustrated SVG portraits -- emoji rendered differently on every
 * OS, and half the old options (star, sun, moon, heart, clown) were not
 * people at all. Saved values from the old set are mapped across by
 * avatarResolveKey(), so no existing profile loses its selection.
 */
function get_user_avatar($user_id, $avatar_choice, $name): string
{
    $colors = ['#3B82F6', '#EF4444', '#10B981', '#F59E0B', '#8B5CF6', '#EC4899', '#14B8A6', '#F97316'];
    $color = $colors[((int) $user_id) % count($colors)];

    return '<div class="avatar-icon avatar-svg">'
         . renderAvatar((string) $avatar_choice, 40, (string) ($name ?? 'U'), $color)
         . '</div>';
}
}

?>


<!DOCTYPE html>

<html lang="en">


<head>

<meta charset="UTF-8">

<meta name="viewport" content="width=device-width, initial-scale=1.0">


<title>
<?= htmlspecialchars($page_title); ?>
</title>

<?php /* Without an explicit icon the browser requests /favicon.ico on every
         page load and logs a 404, since the project ships no .ico file.
         Pointing at the existing SVG logo stops that request entirely. */ ?>
<link rel="icon" type="image/svg+xml" href="assets/images/infravault-logo.svg">



<link rel="stylesheet" href="assets/css/style.css">

<link rel="stylesheet" href="assets/css/components.css">

<link rel="stylesheet" href="assets/css/header.css">

<link rel="stylesheet" href="assets/css/dashboard.css">


</head>



<body>




<header class="top-header">



<!-- LEFT BRAND -->


<div class="header-brand">







<div class="brand-subtitle">

Enterprise IT Management Platform




</div>


</div>








<!-- CENTER MENU -->


<nav class="header-navigation">


<a href="home.php" class="active" title="Dashboard">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M3 13h8V3H3z"/>
<path d="M13 21h8v-8h-8z"/>
<path d="M13 3h8v6h-8z"/>
<path d="M3 17h8v4H3z"/>
</svg>
</a>


<a href="inventory.php" title="Inventory">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M21 16V8"/>
<path d="M3 8v8"/>
<path d="M12 3v18"/>
<path d="M3 8l9-5 9 5-9 5-9-5z"/>
</svg>
</a>


<a href="#" title="Security">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
</svg>
</a>


<a href="#" title="Monitoring">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
</svg>
</a>


<a href="#" title="Reports">
<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/>
<polyline points="14 2 14 8 20 8"/>
<line x1="16" y1="13" x2="8" y2="13"/>
<line x1="16" y1="17" x2="8" y2="17"/>
</svg>
</a>


</nav>








<!-- RIGHT AREA -->


<div class="header-right">












<!-- DARK MODE TOGGLE -->

<button
    id="themeToggle"
    class="header-button"
    type="button"
    title="Toggle dark/light mode"
    aria-label="Toggle dark/light mode"
>
    <svg id="sunIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="display: none;">
        <circle cx="12" cy="12" r="5"></circle>
        <line x1="12" y1="1" x2="12" y2="3"></line>
        <line x1="12" y1="21" x2="12" y2="23"></line>
        <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"></line>
        <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"></line>
        <line x1="1" y1="12" x2="3" y2="12"></line>
        <line x1="21" y1="12" x2="23" y2="12"></line>
        <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"></line>
        <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"></line>
    </svg>
    <svg id="moonIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"></path>
    </svg>
</button>

<!-- NOTIFICATION -->


<div class="notif-wrap">

<button
    class="header-button notification-btn"
    id="notifBellBtn"
    type="button"
    aria-haspopup="true"
    aria-expanded="false"
>


<svg viewBox="0 0 24 24">


<path d="M18 8a6 6 0 0 0-12 0c0 7-3 7-3 9h18c0-2-3-2-3-9"></path>


<path d="M13 21h-2"></path>


</svg>


<?php if ($header_notifications['badge_count'] > 0): ?>
<span><?= $header_notifications['badge_count'] > 9 ? '9+' : (int) $header_notifications['badge_count'] ?></span>
<?php endif; ?>


</button>


<div class="notif-panel" id="notifPanel">

    <div class="notif-panel-header">
        <strong>Notifications</strong>
        <a href="notification.php">View all</a>
    </div>

    <div class="notif-panel-body">

        <?php if (
            !$header_notifications['communications'] &&
            !$header_notifications['reminders'] &&
            !$header_notifications['sticky_notes']
        ): ?>

            <div class="notif-empty">
                You're all caught up.
            </div>

        <?php endif; ?>


        <?php if ($header_notifications['communications']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Team Notes</span>

                <?php foreach ($header_notifications['communications'] as $c): ?>

                    <a href="notification.php" class="notif-item">

                        <span class="notif-dot priority-<?= htmlspecialchars(strtolower($c['priority'] ?? 'normal')) ?>"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($c['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= htmlspecialchars($c['note_type'] ?? 'Announcement') ?>
                                &middot;
                                <?= notif_time_ago($c['created_at']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['reminders']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Reminders</span>

                <?php foreach ($header_notifications['reminders'] as $r): ?>

                    <?php $is_overdue = !empty($r['reminder_date']) && $r['reminder_date'] < date('Y-m-d H:i:s'); ?>

                    <a href="reminders.php" class="notif-item">

                        <span class="notif-dot <?= $is_overdue ? 'priority-critical' : 'priority-normal' ?>"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title"><?= htmlspecialchars($r['title']) ?></span>
                            <span class="notif-item-meta">
                                <?= $is_overdue ? 'Overdue' : 'Due' ?>
                                <?= htmlspecialchars(date('d M, H:i', strtotime($r['reminder_date']))) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>


        <?php if ($header_notifications['sticky_notes']): ?>

            <div class="notif-section">

                <span class="notif-section-title">Sticky Notes</span>

                <?php foreach ($header_notifications['sticky_notes'] as $n): ?>

                    <a href="reminders.php" class="notif-item">

                        <span class="notif-dot priority-note"></span>

                        <span class="notif-item-text">
                            <span class="notif-item-title">
                                <?= htmlspecialchars(infravault_truncate($n['content'], 60)) ?>
                            </span>
                            <span class="notif-item-meta">
                                <?= htmlspecialchars(trim(($n['first_name'] ?? '') . ' ' . ($n['last_name'] ?? '')) ?: 'Team') ?>
                                &middot;
                                <?= notif_time_ago($n['updated_at']) ?>
                            </span>
                        </span>

                    </a>

                <?php endforeach; ?>

            </div>

        <?php endif; ?>

    </div>

</div>

</div>


<script>
(function(){
    const btn = document.getElementById('notifBellBtn');
    const panel = document.getElementById('notifPanel');

    if (!btn || !panel) {
        return;
    }

    btn.addEventListener('click', function(e){
        e.stopPropagation();
        const open = panel.classList.toggle('open');
        btn.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    document.addEventListener('click', function(e){
        if (!panel.classList.contains('open')) {
            return;
        }
        if (e.target.closest('.notif-wrap')) {
            return;
        }
        panel.classList.remove('open');
        btn.setAttribute('aria-expanded', 'false');
    });
})();
</script>


<script>
(function(){
    const themeToggle = document.getElementById('themeToggle');
    const sunIcon = document.getElementById('sunIcon');
    const moonIcon = document.getElementById('moonIcon');
    const html = document.documentElement;

    const savedTheme = localStorage.getItem('theme') || 'light';

    function setTheme(theme) {
        html.setAttribute('data-theme', theme);
        localStorage.setItem('theme', theme);

        if (theme === 'dark') {
            sunIcon.style.display = 'block';
            moonIcon.style.display = 'none';
        } else {
            sunIcon.style.display = 'none';
            moonIcon.style.display = 'block';
        }
    }

    setTheme(savedTheme);

    themeToggle.addEventListener('click', function() {
        const currentTheme = html.getAttribute('data-theme') || 'light';
        const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
        setTheme(newTheme);
    });
})();
</script>







<!-- USER -->


<div class="header-user">



<div class="user-avatar">
<a href="myprofile.php" title="Edit Profile">

<?= get_user_avatar(
    (int) ($_SESSION['user_id'] ?? 0),
    (string) ($_SESSION['avatar'] ?? 'initials'),
    (string) ($_SESSION['name'] ?? 'User')
); ?>

</a>
</div>





<div class="user-details">

<strong>

<?= htmlspecialchars($_SESSION['name'] ?? 'Admin'); ?>

</strong>

</div>



</div>








<!-- SIGN OUT -->


<a href="logout.php" class="header-signout"
onclick="return confirm('Are you sure you want to sign out?');">
    <i class="fa-solid fa-right-from-bracket"></i>
<span>
Sign Out
</span>

</a>



</div>



</header>





<!-- PAGE START -->

<div class="main-container">
