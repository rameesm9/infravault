<?php

session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

$role = trim($_SESSION['role'] ?? '');

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, last_name, ncgr_id, email FROM users WHERE id = ?");
$user_stmt->execute([$_SESSION['user_id']]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);

if ($user_info) {
    $firstName = trim($user_info['first_name'] ?? '');
    $lastName  = trim($user_info['last_name'] ?? '');
    $ncgrId    = trim($user_info['ncgr_id'] ?? '');
    $fullName  = trim($firstName . ' ' . $lastName);

    if ($fullName !== '' && $ncgrId !== '') {
        $username = $fullName . ' (' . $ncgrId . ')';
    } elseif ($fullName !== '') {
        $username = $fullName;
    } elseif ($ncgrId !== '') {
        $username = $ncgrId;
    } else {
        $username = $user_info['email'] ?? 'Unknown User';
    }
} else {
    $username = 'Unknown User';
}

// Check permissions
function handoverHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'handover', $permission);
}

$canImport = handoverHasPermission($pdo, $role, 'can_import');

if (!$canImport) {
    die("Permission denied");
}

$message = "";
$errors = [];
$imported = 0;
$skipped = 0;

// Handle CSV upload
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!isset($_FILES['csv_file'])) {
        $message = "CSV file required";
    } else {

        $file = $_FILES['csv_file']['tmp_name'];

        if (($handle = fopen($file, "r")) !== false) {

            $header = fgetcsv($handle);

            while (($row = fgetcsv($handle)) !== false) {

                $data = array_combine($header, $row);

                // Extract required fields
                $project_name = trim($data['project_name'] ?? '');
                $current_owner = trim($data['current_owner'] ?? '');
                $new_owner = trim($data['new_owner'] ?? '');

                if (!$project_name || !$current_owner || !$new_owner) {
                    $skipped++;
                    continue;
                }

                // Check for duplicate
                $stmt = $pdo->prepare("SELECT id FROM handovers WHERE project_name = ? AND current_owner = ? AND new_owner = ?");
                $stmt->execute([$project_name, $current_owner, $new_owner]);

                if ($stmt->fetch()) {
                    $skipped++;
                    continue;
                }

                // Extract optional fields
                $project_id = trim($data['project_id'] ?? '');
                $handover_date = trim($data['handover_date'] ?? '');
                $handover_status = trim($data['handover_status'] ?? 'Planned');
                $reason_for_handover = trim($data['reason_for_handover'] ?? '');
                $project_phase = trim($data['project_phase'] ?? 'Planning');
                $documentation_status = trim($data['documentation_status'] ?? 'Complete');
                $open_issues = trim($data['open_issues'] ?? '');
                $pending_actions = trim($data['pending_actions'] ?? '');
                $risks = trim($data['risks'] ?? '');
                $dependencies = trim($data['dependencies'] ?? '');
                $kt_completed = trim($data['kt_completed'] ?? 'No');
                $training_completed = trim($data['training_completed'] ?? 'No');
                $access_transferred = trim($data['access_transferred'] ?? 'No');
                $stakeholder_signoff = trim($data['stakeholder_signoff'] ?? '');
                $client_notified = trim($data['client_notified'] ?? 'No');
                $warranty_period = trim($data['warranty_period'] ?? '');
                $notes = trim($data['notes'] ?? '');

                // Insert the record
                $stmt = $pdo->prepare("
                    INSERT INTO handovers
                    (project_name, project_id, current_owner, new_owner, handover_date, handover_status,
                     reason_for_handover, project_phase, documentation_status, open_issues, pending_actions,
                     risks, dependencies, kt_completed, training_completed, access_transferred,
                     stakeholder_signoff, client_notified, warranty_period, notes, user_id, last_updated)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
                ");

                try {
                    $stmt->execute([
                        $project_name,
                        $project_id,
                        $current_owner,
                        $new_owner,
                        !empty($handover_date) ? $handover_date : null,
                        $handover_status,
                        $reason_for_handover,
                        $project_phase,
                        $documentation_status,
                        $open_issues,
                        $pending_actions,
                        $risks,
                        $dependencies,
                        $kt_completed,
                        $training_completed,
                        $access_transferred,
                        $stakeholder_signoff,
                        $client_notified,
                        $warranty_period,
                        $notes,
                        $_SESSION['user_id']
                    ]);

                    $new_id = $pdo->lastInsertId();

                    // Log to audit history
                    $h_stmt = $pdo->prepare("
                        INSERT INTO handover_history
                        (handover_id, action_type, performed_by, details)
                        VALUES (?, 'CREATED', ?, ?)
                    ");

                    $h_stmt->execute([
                        $new_id,
                        $username,
                        "Imported from CSV: $project_name"
                    ]);

                    $imported++;
                } catch (Exception $e) {
                    $skipped++;
                }
            }

            fclose($handle);
        }
    }
}

?>
<!DOCTYPE html>
<html>
<head>
    <title>Import Handover CSV</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 20px; background: #f5f5f5; }
        .container { max-width: 600px; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .alert { margin: 20px 0; }
        .stats { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin: 20px 0; }
        .stat-card { padding: 20px; background: #f8f9fa; border-radius: 6px; text-align: center; }
        .stat-card strong { display: block; font-size: 24px; color: #2563eb; margin-top: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Import Handover CSV</h2>

        <?php if ($imported > 0 || $skipped > 0): ?>
            <div class="stats">
                <div class="stat-card">
                    <span>Imported</span>
                    <strong style="color: #16a34a;"><?php echo $imported; ?></strong>
                </div>
                <div class="stat-card">
                    <span>Skipped</span>
                    <strong style="color: #dc2626;"><?php echo $skipped; ?></strong>
                </div>
            </div>
            <p class="text-center" style="margin-top: 20px;">
                <a href="handover.php" class="btn btn-primary">Return to Handover List</a>
            </p>
        <?php else: ?>
            <p class="text-danger"><?php echo htmlspecialchars($message); ?></p>
            <p class="text-center">
                <a href="handover.php" class="btn btn-secondary">Back</a>
            </p>
        <?php endif; ?>
    </div>
</body>
</html>
