<?php
// sop-export.php
//
// Exports a single SOP as a Word-compatible document. Word (and most
// office suites) will happily open an .doc file that is really HTML,
// which avoids needing a PHPWord/COM dependency on the server.
//
// The document is laid out as a controlled procedure: a cover page with a
// document-control block, a contents list, numbered sections, then the
// appendices (attachments and revision history). The SOP's own header and
// footer text is written into the Word page header/footer, so it repeats on
// every printed page.

session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/sop-document-helpers.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('sop', 'can_view');
requirePermission('sop', 'can_export');


$current_user_id = (int)$_SESSION['user_id'];
$user_role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($user_role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

// Get user's team
$userStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';

// Check export permission
if (!$is_admin && !hasRolePermission($pdo, $user_role, 'sop', 'can_export')) {
    http_response_code(403);
    exit('You do not have permission to export SOPs.');
}

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/*
|--------------------------------------------------------------------------
| Rewrite relative attachment/image URLs to absolute ones so Word can
| actually fetch them when it renders the exported document.
|--------------------------------------------------------------------------
*/
function sop_export_absolute_urls(string $html, string $base_url): string
{
    return preg_replace_callback(
        '/\ssrc\s*=\s*(["\'])(?!https?:\/\/|data:)([^"\']*)\1/i',
        function ($match) use ($base_url) {
            $quote = $match[1];
            $path = ltrim($match[2], '/');
            return ' src=' . $quote . $base_url . $path . $quote;
        },
        $html
    );
}

function sop_export_date($value, string $format = 'd M Y'): string
{
    if (empty($value)) {
        return '—';
    }

    $timestamp = strtotime((string)$value);

    return $timestamp ? date($format, $timestamp) : '—';
}

/*
|--------------------------------------------------------------------------
| Embedding images in the document.
|
| A linked image does not survive the trip: Word fetches <img src> itself
| when the file is opened, with no session cookie, over a URL the reader's
| machine may not resolve at all -- and Word blocks remote content in
| downloaded documents anyway. The result is a red-X placeholder where the
| logo should be.
|
| So the document is packaged as MHTML (multipart/related), the same
| single-file format Word itself writes: the HTML in one part, every image
| base64-encoded in its own part, referenced by Content-Location. Nothing
| is fetched, and the logo travels with the file when the SOP is emailed.
|--------------------------------------------------------------------------
*/

/**
 * Resolves an image URL from the document back to a file on this server,
 * or null when it is not ours to embed.
 */
function sop_export_local_asset(string $url, string $base_url, PDO $pdo): ?array
{
    $url = html_entity_decode($url, ENT_QUOTES, 'UTF-8');

    // Our own absolute URLs come back to relative paths.
    if (stripos($url, $base_url) === 0) {
        $url = substr($url, strlen($base_url));
    }

    if (preg_match('#^https?://#i', $url) || stripos($url, 'data:') === 0) {
        return null;
    }

    $path = null;

    // Body images are served through the authenticated file endpoint;
    // resolve those back to the stored attachment.
    if (preg_match('#(?:^|/)sop\.php\?action=file&(?:amp;)?id=(\d+)#i', $url, $match)) {
        $stmt = $pdo->prepare("SELECT file_path FROM sop_attachments WHERE id = ? LIMIT 1");
        $stmt->execute([(int)$match[1]]);
        $stored = $stmt->fetchColumn();

        if ($stored) {
            $path = __DIR__ . '/' . ltrim((string)$stored, '/');
        }
    } else {
        $path = __DIR__ . '/' . ltrim(parse_url($url, PHP_URL_PATH) ?? '', '/');
    }

    if ($path === null) {
        return null;
    }

    $real = realpath($path);
    $root = realpath(__DIR__);

    // Never read outside the application directory, whatever the stored
    // path claims.
    if ($real === false || $root === false || strpos($real, $root . DIRECTORY_SEPARATOR) !== 0) {
        return null;
    }

    $size = @getimagesize($real);

    if (!$size || empty($size['mime'])) {
        return null;
    }

    return ['path' => $real, 'mime' => $size['mime']];
}

/**
 * Swaps every embeddable <img src> for a Content-Location, and returns the
 * rewritten HTML together with the assets to attach.
 */
function sop_export_collect_assets(string $html, string $base_url, PDO $pdo, string $asset_base): array
{
    $assets = [];

    $html = preg_replace_callback(
        '/(<img\b[^>]*?\ssrc\s*=\s*)(["\'])(.*?)\2/i',
        function ($match) use (&$assets, $base_url, $pdo, $asset_base) {
            $asset = sop_export_local_asset($match[3], $base_url, $pdo);

            // Not resolvable locally: leave the URL alone so Word can at
            // least try to fetch it.
            if ($asset === null) {
                return $match[0];
            }

            $key = $asset['path'];

            if (!isset($assets[$key])) {
                $extension = pathinfo($asset['path'], PATHINFO_EXTENSION) ?: 'img';
                $assets[$key] = [
                    'location' => $asset_base . 'image' . (count($assets) + 1) . '.' . $extension,
                    'mime'     => $asset['mime'],
                    'path'     => $asset['path'],
                ];
            }

            return $match[1] . $match[2] . $assets[$key]['location'] . $match[2];
        },
        $html
    );

    return [$html, $assets];
}

/**
 * Wraps the document and its images into one MHTML file.
 */
function sop_export_mhtml(string $html, array $assets, string $document_location): string
{
    $boundary = '----=_NextPart_InfraVault_SOP';
    $eol = "\r\n";

    $out = 'MIME-Version: 1.0' . $eol
        . 'Content-Type: multipart/related; boundary="' . $boundary . '"; type="text/html"' . $eol
        . $eol
        . 'This document is a single-file web page (MHTML). Open it with Microsoft Word.' . $eol
        . $eol;

    $out .= '--' . $boundary . $eol
        . 'Content-Location: ' . $document_location . $eol
        . 'Content-Transfer-Encoding: quoted-printable' . $eol
        . 'Content-Type: text/html; charset="utf-8"' . $eol
        . $eol
        . quoted_printable_encode($html) . $eol
        . $eol;

    foreach ($assets as $asset) {
        $data = @file_get_contents($asset['path']);

        if ($data === false) {
            continue;
        }

        $out .= '--' . $boundary . $eol
            . 'Content-Location: ' . $asset['location'] . $eol
            . 'Content-Transfer-Encoding: base64' . $eol
            . 'Content-Type: ' . $asset['mime'] . $eol
            . $eol
            . chunk_split(base64_encode($data), 76, $eol)
            . $eol;
    }

    return $out . '--' . $boundary . '--' . $eol;
}

function sop_export_filesize($bytes): string
{
    $bytes = (float)$bytes;

    if ($bytes >= 1048576) {
        return number_format($bytes / 1048576, 1) . ' MB';
    }

    return number_format($bytes / 1024, 1) . ' KB';
}

$sop_id = (int) ($_GET['id'] ?? 0);

if ($sop_id <= 0) {
    http_response_code(400);
    exit('Invalid SOP.');
}

$stmt = $pdo->prepare("
    SELECT
        s.*,
        owner.first_name  AS owner_first,
        owner.last_name   AS owner_last,
        assigned.first_name AS assigned_first,
        assigned.last_name  AS assigned_last,
        reviewer.first_name AS reviewer_first,
        reviewer.last_name  AS reviewer_last
    FROM sops s
    LEFT JOIN users owner    ON owner.id = s.owner_id
    LEFT JOIN users assigned ON assigned.id = s.reviewer_id
    LEFT JOIN users reviewer ON reviewer.id = s.reviewer_id
    WHERE s.id = ?
    LIMIT 1
");
$stmt->execute([$sop_id]);
$sop = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$sop) {
    http_response_code(404);
    exit('SOP not found.');
}

// Check visibility permissions
if (!$is_admin) {
    $sharedTeams = getSharedTeams($pdo, 'sop', $sop_id);
    $accessLevel = getItemAccessLevel(
        $pdo,
        $current_user_id,
        $user_role,
        $user_team,
        $sop['owner_id'],
        $sop['visibility'],
        $sop['owner_team'],
        $sharedTeams,
        'sop'
    );

    if ($accessLevel === 'none') {
        http_response_code(403);
        exit('You do not have permission to access this SOP.');
    }
}

$owner_name = trim($sop['owner_first'] . ' ' . $sop['owner_last']);
$assigned_reviewer_name = trim(($sop['assigned_first'] ?? '') . ' ' . ($sop['assigned_last'] ?? ''));
$actual_reviewer_name = trim(($sop['reviewer_first'] ?? '') . ' ' . ($sop['reviewer_last'] ?? ''));

$base_url = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . $_SERVER['HTTP_HOST']
    . rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/')
    . '/';

/*
|--------------------------------------------------------------------------
| Appendix data: attachments and revision history.
|--------------------------------------------------------------------------
*/

$attachStmt = $pdo->prepare("
    SELECT original_name, file_path, file_size, created_at
    FROM sop_attachments
    WHERE sop_id = ?
    ORDER BY id
");
$attachStmt->execute([$sop_id]);
$attachments = $attachStmt->fetchAll(PDO::FETCH_ASSOC);

$revisionStmt = $pdo->prepare("
    SELECT r.version, r.change_summary, r.created_at,
           u.first_name, u.last_name
    FROM sop_revisions r
    LEFT JOIN users u ON u.id = r.changed_by
    WHERE r.sop_id = ?
    ORDER BY r.id DESC
");
$revisionStmt->execute([$sop_id]);
$revisions = $revisionStmt->fetchAll(PDO::FETCH_ASSOC);

$visibility_label = [
    'public' => 'Internal — All Teams',
    'team'   => 'Restricted — Owning Team',
    'teams'  => 'Restricted — Selected Teams',
][$sop['visibility'] ?? 'public'] ?? 'Internal';

/*
|--------------------------------------------------------------------------
| The running header and footer.
|
| One template for the whole module, composed by an Admin under
| sop.php?action=header_footer. It is stored as sanitised HTML (so it can
| carry a logo), then has its {tokens} resolved against this SOP and its
| image sources made absolute, because Word fetches header images itself
| over HTTP when the document is opened.
|--------------------------------------------------------------------------
*/

$doc_settings = sopBandDefaults(getSopDocumentSettings($pdo));

$band_tokens = sopBandTokens($sop, [
    'page'  => '<span style=\'mso-field-code:PAGE\'></span>',
    'pages' => '<span style=\'mso-field-code:NUMPAGES\'></span>',
]);

$bands = [];

foreach (['header', 'footer'] as $band) {
    foreach (['left', 'center', 'right'] as $cell) {
        $bands[$band][$cell] = renderSopBandContent($doc_settings, $band, $cell, $band_tokens, $base_url);
    }
}

// "Page X of Y" is added at the bottom right, unless a footer cell places
// the page number itself -- otherwise it would print twice.
$footer_text = $doc_settings['footer_left'] . ' ' . $doc_settings['footer_center'] . ' ' . $doc_settings['footer_right'];

$show_page_numbers = (int)$doc_settings['show_page_numbers'] === 1
    && !preg_match('/\{(page|pages)\}/i', $footer_text);

if ($show_page_numbers) {
    $page_field = 'Page <span style=\'mso-field-code:PAGE\'></span> of <span style=\'mso-field-code:NUMPAGES\'></span>';

    $bands['footer']['right'] = $bands['footer']['right'] !== ''
        ? $bands['footer']['right'] . '&nbsp;&nbsp;' . $page_field
        : $page_field;
}

/*
|--------------------------------------------------------------------------
| Body sections. Built as a list so the contents page, the numbering and
| the sections themselves can never drift apart.
|--------------------------------------------------------------------------
*/

$sections = [];

if (trim((string)$sop['description']) !== '') {
    $sections[] = [
        'title' => 'Purpose and Scope',
        'html'  => '<p>' . nl2br(h($sop['description'])) . '</p>',
    ];
}

$body_map = [
    'Prerequisites' => 'prerequisites_html',
    'Procedure'     => 'content_html',
    'Validation'    => 'validation_html',
    'Rollback'      => 'rollback_html',
    'Escalation'    => 'escalation_html',
];

foreach ($body_map as $section_title => $column) {
    $html = trim((string)($sop[$column] ?? ''));

    if ($html === '' && $section_title !== 'Procedure') {
        continue;
    }

    $sections[] = [
        'title' => $section_title,
        'html'  => $html !== ''
            ? sop_export_absolute_urls($html, $base_url)
            : '<p class="doc-empty">No procedure provided.</p>',
    ];
}

if (!empty($sop['rejection_reason'])) {
    $sections[] = [
        'title' => 'Review Feedback',
        'html'  => '<p>' . nl2br(h($sop['rejection_reason'])) . '</p>',
    ];
}

// Appendices are numbered after the body sections.
$appendices = [];
$appendices[] = 'Attachments';
$appendices[] = 'Revision History';

$filename = preg_replace('/[^a-zA-Z0-9_-]+/', '_', $sop['sop_number'] . '_' . $sop['title']);
$filename = trim($filename, '_') . '.doc';

// Buffered, because the images can only be collected once the whole
// document exists, and the response headers depend on what came back.
ob_start();
?>
<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:w="urn:schemas-microsoft-com:office:word" xmlns="http://www.w3.org/TR/REC-html40">
<head>
<meta charset="utf-8">
<title><?= h($sop['sop_number']) ?> — <?= h($sop['title']) ?></title>
<!--[if gte mso 9]>
<xml>
<o:DocumentProperties>
    <o:Title><?= h($sop['sop_number']) ?> <?= h($sop['title']) ?></o:Title>
    <o:Subject><?= h($sop['category']) ?> — Standard Operating Procedure</o:Subject>
    <o:Author><?= h($owner_name ?: 'InfraVault') ?></o:Author>
    <o:Category>Standard Operating Procedure</o:Category>
    <o:Version><?= h($sop['version']) ?></o:Version>
</o:DocumentProperties>
<w:WordDocument>
<w:View>Print</w:View>
<w:Zoom>100</w:Zoom>
<w:DoNotOptimizeForBrowser/>
</w:WordDocument>
</xml>
<![endif]-->
<style>
    /* --------------------------------------------------------------
       Page setup. mso-header / mso-footer point at the two
       `mso-element` divs at the end of <body>, which is what makes the
       banner repeat on every page instead of printing once inline.
       -------------------------------------------------------------- */
    @page WordSection1 {
        size: 21.0cm 29.7cm;
        margin: 2.4cm 2.0cm 2.2cm 2.0cm;
        mso-header-margin: 1.1cm;
        mso-footer-margin: 1.1cm;
        mso-header: h1;
        mso-footer: f1;
        mso-paper-source: 0;
    }
    div.WordSection1 { page: WordSection1; }

    body {
        font-family: Calibri, Arial, sans-serif;
        font-size: 11pt;
        line-height: 1.45;
        color: #1F2937;
    }

    p { margin: 0 0 8pt; }

    p.MsoHeader, p.MsoFooter {
        margin: 0;
        font-family: Calibri, Arial, sans-serif;
        font-size: 8.5pt;
        color: #64748B;
        letter-spacing: .2pt;
    }
    p.MsoHeader {
        border-bottom: .75pt solid #C7D2DE;
        padding-bottom: 3pt;
    }
    p.MsoFooter {
        border-top: .75pt solid #C7D2DE;
        padding-top: 3pt;
    }
    /* A logo dropped into a band. Its width and height are written onto
       the tag itself (see sopBandLogoTag) because Word stretches an image
       given only one dimension; nothing is constrained here. */
    p.MsoHeader img, p.MsoFooter img {
        vertical-align: middle;
    }

    /* ---------------------------- Cover ---------------------------- */
    .cover-rule {
        border-top: 3pt solid #0F2A44;
        margin-bottom: 14pt;
    }
    .cover-eyebrow {
        font-size: 9pt;
        letter-spacing: 1.4pt;
        text-transform: uppercase;
        color: #64748B;
        margin-bottom: 26pt;
    }
    .cover-number {
        font-size: 13pt;
        font-weight: bold;
        letter-spacing: 2pt;
        color: #1D4ED8;
        margin-bottom: 6pt;
    }
    .cover-title {
        font-size: 27pt;
        font-weight: bold;
        line-height: 1.15;
        color: #0F2A44;
        margin: 0 0 10pt;
    }
    .cover-summary {
        font-size: 11.5pt;
        color: #475569;
        margin-bottom: 26pt;
    }
    .cover-classification {
        font-size: 8.5pt;
        letter-spacing: 1.2pt;
        text-transform: uppercase;
        color: #92400E;
        background: #FEF3C7;
        padding: 4pt 8pt;
        margin-bottom: 20pt;
    }

    /* ------------------------- Control table ----------------------- */
    .block-title {
        font-size: 9pt;
        font-weight: bold;
        letter-spacing: 1.2pt;
        text-transform: uppercase;
        color: #0F2A44;
        border-bottom: 1pt solid #0F2A44;
        padding-bottom: 3pt;
        margin: 0 0 8pt;
    }

    table.doc-table {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 20pt;
        font-size: 10pt;
    }
    table.doc-table td, table.doc-table th {
        border: .75pt solid #D8E0EA;
        padding: 5pt 8pt;
        vertical-align: top;
    }
    table.doc-table th {
        background: #0F2A44;
        color: #FFFFFF;
        text-align: left;
        font-size: 9pt;
        letter-spacing: .6pt;
        text-transform: uppercase;
    }
    td.doc-label {
        background: #F4F7FB;
        font-weight: bold;
        color: #475569;
        width: 22%;
        white-space: nowrap;
    }
    tr.doc-alt td { background: #F8FAFC; }

    /* ---------------------------- Contents ------------------------- */
    table.toc {
        width: 100%;
        border-collapse: collapse;
        margin: 0 0 20pt;
        font-size: 10.5pt;
    }
    table.toc td {
        border-bottom: .5pt dotted #CBD5E1;
        padding: 5pt 4pt;
    }
    td.toc-num {
        width: 34pt;
        color: #1D4ED8;
        font-weight: bold;
    }

    /* ---------------------------- Sections ------------------------- */
    h1.doc-h1 {
        font-size: 14pt;
        color: #0F2A44;
        border-bottom: 1.5pt solid #1D4ED8;
        padding-bottom: 4pt;
        margin: 22pt 0 10pt;
        page-break-after: avoid;
    }
    .doc-section h2 {
        font-size: 12pt;
        color: #0F2A44;
        margin: 14pt 0 6pt;
        page-break-after: avoid;
    }
    .doc-section h3 {
        font-size: 11pt;
        color: #334155;
        margin: 12pt 0 5pt;
        page-break-after: avoid;
    }
    .doc-section ul, .doc-section ol { margin: 0 0 8pt 18pt; }
    .doc-section li { margin-bottom: 3pt; }
    .doc-section table {
        border-collapse: collapse;
        margin: 8pt 0;
        font-size: 10pt;
    }
    .doc-section table td, .doc-section table th {
        border: .75pt solid #D8E0EA;
        padding: 4pt 8pt;
    }
    .doc-section table th { background: #F4F7FB; text-align: left; }
    .doc-section img { max-width: 16.5cm; }
    .doc-section blockquote {
        margin: 8pt 0 8pt 12pt;
        padding-left: 10pt;
        border-left: 2.5pt solid #CBD5E1;
        color: #475569;
    }
    .doc-section pre, .sop-command {
        background: #0F172A;
        color: #E2E8F0;
        padding: 8pt 10pt;
        font-family: Consolas, "Courier New", monospace;
        font-size: 9.5pt;
        white-space: pre-wrap;
    }
    .doc-section code {
        font-family: Consolas, "Courier New", monospace;
        font-size: 9.5pt;
    }
    p.doc-empty { color: #94A3B8; font-style: italic; }

    /* --------------------------- Sign-off -------------------------- */
    td.sign-line {
        border: .75pt solid #D8E0EA;
        height: 44pt;
        vertical-align: bottom;
        font-size: 8.5pt;
        color: #94A3B8;
        padding: 5pt 8pt;
    }

    .doc-end {
        margin-top: 24pt;
        padding-top: 8pt;
        border-top: .75pt solid #D8E0EA;
        font-size: 8.5pt;
        color: #94A3B8;
        text-align: center;
        letter-spacing: 1pt;
        text-transform: uppercase;
    }
</style>
</head>
<body lang="EN-GB">

<div class="WordSection1">

    <!-- =====================  COVER PAGE  ===================== -->

    <div class="cover-rule"></div>

    <p class="cover-eyebrow">Standard Operating Procedure &nbsp;&bull;&nbsp; <?= h($sop['category']) ?></p>

    <p class="cover-number"><?= h($sop['sop_number']) ?></p>
    <p class="cover-title"><?= h($sop['title']) ?></p>

    <?php if (trim((string)$sop['description']) !== ''): ?>
        <p class="cover-summary"><?= nl2br(h($sop['description'])) ?></p>
    <?php else: ?>
        <p class="cover-summary">&nbsp;</p>
    <?php endif; ?>

    <p class="cover-classification"><?= h($visibility_label) ?> &nbsp;&bull;&nbsp; Criticality: <?= h($sop['criticality']) ?></p>

    <p class="block-title">Document Control</p>

    <table class="doc-table">
        <tr>
            <td class="doc-label">Document No.</td>
            <td><?= h($sop['sop_number']) ?></td>
            <td class="doc-label">Version</td>
            <td><?= h($sop['version']) ?></td>
        </tr>
        <tr class="doc-alt">
            <td class="doc-label">Status</td>
            <td><?= h($sop['status']) ?></td>
            <td class="doc-label">Category</td>
            <td><?= h($sop['category']) ?></td>
        </tr>
        <tr>
            <td class="doc-label">Owner</td>
            <td><?= h($owner_name ?: '—') ?></td>
            <td class="doc-label">Criticality</td>
            <td><?= h($sop['criticality']) ?></td>
        </tr>
        <tr class="doc-alt">
            <td class="doc-label">Assigned Reviewer</td>
            <td><?= h($assigned_reviewer_name ?: '—') ?></td>
            <td class="doc-label">Next Review Due</td>
            <td><?= h(sop_export_date($sop['review_date'] ?? null)) ?></td>
        </tr>
        <tr>
            <td class="doc-label">Created</td>
            <td><?= h(sop_export_date($sop['created_at'])) ?></td>
            <td class="doc-label">Last Updated</td>
            <td><?= h(sop_export_date($sop['updated_at'], 'd M Y H:i')) ?></td>
        </tr>
        <?php if (!empty($sop['reviewed_at'])): ?>
            <tr class="doc-alt">
                <td class="doc-label"><?= $sop['status'] === 'Rejected' ? 'Rejected By' : 'Approved By' ?></td>
                <td><?= h($actual_reviewer_name ?: '—') ?></td>
                <td class="doc-label"><?= $sop['status'] === 'Rejected' ? 'Rejected On' : 'Approved On' ?></td>
                <td><?= h(sop_export_date($sop['reviewed_at'], 'd M Y H:i')) ?></td>
            </tr>
        <?php endif; ?>
        <tr<?= empty($sop['reviewed_at']) ? ' class="doc-alt"' : '' ?>>
            <td class="doc-label">Classification</td>
            <td colspan="3"><?= h($visibility_label) ?></td>
        </tr>
        <tr<?= empty($sop['reviewed_at']) ? '' : ' class="doc-alt"' ?>>
            <td class="doc-label">Exported</td>
            <td colspan="3"><?= h(date('d M Y H:i')) ?> by <?= h(trim(($_SESSION['first_name'] ?? '') . ' ' . ($_SESSION['last_name'] ?? '')) ?: ($_SESSION['ncgr_id'] ?? 'Unknown user')) ?></td>
        </tr>
    </table>

    <p class="block-title">Approval</p>

    <table class="doc-table">
        <tr>
            <th style="width:34%">Prepared By</th>
            <th style="width:33%">Reviewed By</th>
            <th style="width:33%">Approved By</th>
        </tr>
        <tr>
            <td class="sign-line">&nbsp;</td>
            <td class="sign-line">&nbsp;</td>
            <td class="sign-line">&nbsp;</td>
        </tr>
        <tr>
            <td><?= h($owner_name ?: '—') ?><br><span style="font-size:8.5pt;color:#94A3B8">Name / Date</span></td>
            <td><?= h($assigned_reviewer_name ?: '—') ?><br><span style="font-size:8.5pt;color:#94A3B8">Name / Date</span></td>
            <td><?= h($actual_reviewer_name ?: '—') ?><br><span style="font-size:8.5pt;color:#94A3B8">Name / Date</span></td>
        </tr>
    </table>

    <!-- Page break: the cover and control block stay on page one. -->
    <br clear="all" style="mso-special-character:line-break;page-break-before:always">

    <!-- =====================  CONTENTS  ===================== -->

    <p class="block-title">Contents</p>

    <table class="toc">
        <?php $toc_index = 0; ?>
        <?php foreach ($sections as $section): $toc_index++; ?>
            <tr>
                <td class="toc-num"><?= $toc_index ?>.</td>
                <td><?= h($section['title']) ?></td>
            </tr>
        <?php endforeach; ?>
        <?php foreach ($appendices as $appendix): $toc_index++; ?>
            <tr>
                <td class="toc-num"><?= $toc_index ?>.</td>
                <td><?= h($appendix) ?></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <!-- =====================  BODY  ===================== -->

    <?php $index = 0; ?>
    <?php foreach ($sections as $section): $index++; ?>
        <h1 class="doc-h1"><?= $index ?>. <?= h($section['title']) ?></h1>
        <div class="doc-section"><?= $section['html'] ?></div>
    <?php endforeach; ?>

    <!-- =====================  APPENDICES  ===================== -->

    <?php $index++; ?>
    <h1 class="doc-h1"><?= $index ?>. Attachments</h1>

    <?php if ($attachments): ?>
        <table class="doc-table">
            <tr>
                <th style="width:52%">File</th>
                <th style="width:16%">Size</th>
                <th style="width:32%">Added</th>
            </tr>
            <?php foreach ($attachments as $i => $attachment): ?>
                <tr<?= $i % 2 ? ' class="doc-alt"' : '' ?>>
                    <td><a href="<?= h($base_url . ltrim((string)$attachment['file_path'], '/')) ?>"><?= h($attachment['original_name']) ?></a></td>
                    <td><?= h(sop_export_filesize($attachment['file_size'])) ?></td>
                    <td><?= h(sop_export_date($attachment['created_at'], 'd M Y H:i')) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p class="doc-empty">No attachments are associated with this procedure.</p>
    <?php endif; ?>

    <?php $index++; ?>
    <h1 class="doc-h1"><?= $index ?>. Revision History</h1>

    <?php if ($revisions): ?>
        <table class="doc-table">
            <tr>
                <th style="width:12%">Version</th>
                <th style="width:22%">Date</th>
                <th style="width:24%">Changed By</th>
                <th style="width:42%">Summary</th>
            </tr>
            <?php foreach ($revisions as $i => $revision): ?>
                <?php $changed_by = trim(($revision['first_name'] ?? '') . ' ' . ($revision['last_name'] ?? '')); ?>
                <tr<?= $i % 2 ? ' class="doc-alt"' : '' ?>>
                    <td><?= h($revision['version']) ?></td>
                    <td><?= h(sop_export_date($revision['created_at'], 'd M Y H:i')) ?></td>
                    <td><?= h($changed_by ?: '—') ?></td>
                    <td><?= h($revision['change_summary'] ?: '—') ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    <?php else: ?>
        <p class="doc-empty">No revisions recorded.</p>
    <?php endif; ?>

    <p class="doc-end">End of document &nbsp;&bull;&nbsp; <?= h($sop['sop_number']) ?> v<?= h($sop['version']) ?></p>

<!-- =====================  PAGE HEADER / FOOTER  =====================
     Referenced by "mso-header: h1" / "mso-footer: f1" in @page above.

     These live INSIDE the WordSection div on purpose. Placed after it,
     Word bound them as the real header and footer but also laid them out
     as ordinary body content, so the logo and a dead "Page of" appeared a
     second time at the end of the document.

     Left / centre / right sit on Word's own tab stops: a centre tab at the
     middle of the 17cm text column and a right tab at its edge. That is how
     Word lays out a three-part header natively, so the alignment survives
     the document being edited afterwards.
-->

<div style='mso-element:header' id="h1">
    <p class="MsoHeader" style="tab-stops:center 8.5cm right 17.0cm"><?= $bands['header']['left'] ?><span style="mso-tab-count:1"></span><?= $bands['header']['center'] ?><span style="mso-tab-count:1"></span><?= $bands['header']['right'] ?></p>
</div>

<div style='mso-element:footer' id="f1">
    <p class="MsoFooter" style="tab-stops:center 8.5cm right 17.0cm"><?= $bands['footer']['left'] ?><span style="mso-tab-count:1"></span><?= $bands['footer']['center'] ?><span style="mso-tab-count:1"></span><?= $bands['footer']['right'] ?></p>
</div>

</div>

</body>
</html>
<?php

$html = ob_get_clean();

/*
| Word resolves Content-Location against a document location, so both use
| the same made-up absolute base. The names never touch this server's
| filesystem -- they are only labels tying an <img> to its MIME part.
*/
$asset_base = 'file:///C:/infravault/sop/';

list($html, $assets) = sop_export_collect_assets($html, $base_url, $pdo, $asset_base);

if ($assets) {
    $document = sop_export_mhtml($html, $assets, $asset_base . 'document.htm');
} else {
    // Nothing to embed: plain HTML opens in Word just as well.
    $document = $html;
}

header('Content-Type: application/msword; charset=utf-8');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Content-Length: ' . strlen($document));
header('Cache-Control: max-age=0');

echo $document;
