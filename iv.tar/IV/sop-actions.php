<?php
/**
 * SOP Actions Handler - AJAX endpoints for team permissions, visibility, audit logging
 *
 * Handles:
 * - Changing SOP visibility/sharing
 * - Retrieving audit trail
 * - Logging actions to audit table
 * - Getting shared teams list
 */

session_start();
require_once 'config/db.php';
require_once 'includes/permission-helpers.php';

header('Content-Type: application/json; charset=utf-8');

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('sop', 'can_view');


$current_user_id = (int)$_SESSION['user_id'];
$user_role = strtolower(trim($_SESSION['role'] ?? ''));
$is_admin = in_array($user_role, ['admin', 'administrator', 'super admin', 'superadmin'], true);

// Get user's team
$userStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$userStmt->execute([$current_user_id]);
$userRecord = $userStmt->fetch(PDO::FETCH_ASSOC);
$user_team = $userRecord['team'] ?? '';

$action = $_GET['action'] ?? $_POST['action'] ?? '';

try {
    // ============================================
    // Get Audit Trail for a SOP
    // ============================================
    if ($action === 'get_audit_trail') {
        $sop_id = (int)($_GET['sop_id'] ?? 0);

        if ($sop_id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid SOP ID']);
            exit;
        }

        // Get SOP details
        $sopStmt = $pdo->prepare("SELECT owner_id FROM sops WHERE id = ? LIMIT 1");
        $sopStmt->execute([$sop_id]);
        $sop = $sopStmt->fetch(PDO::FETCH_ASSOC);

        if (!$sop) {
            http_response_code(404);
            echo json_encode(['error' => 'SOP not found']);
            exit;
        }

        // Check permission: user or admin can audit
        if (!$is_admin && (int)$sop['owner_id'] !== $current_user_id && !hasRolePermission($pdo, $user_role, 'sop', 'can_audit')) {
            http_response_code(403);
            echo json_encode(['error' => 'Permission denied']);
            exit;
        }

        // Get audit trail
        $trail = getItemAuditTrail($pdo, 'sop', $sop_id);

        echo json_encode([
            'success' => true,
            'audit_trail' => $trail
        ]);
        exit;
    }

    // ============================================
    // Get Shared Teams for a SOP
    // ============================================
    if ($action === 'get_shared_teams') {
        $sop_id = (int)($_GET['sop_id'] ?? 0);

        if ($sop_id <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid SOP ID']);
            exit;
        }

        $teams = getSharedTeams($pdo, 'sop', $sop_id);

        echo json_encode([
            'success' => true,
            'teams' => $teams
        ]);
        exit;
    }

    // ============================================
    // Save SOP Visibility/Sharing
    // ============================================
    if ($action === 'save_visibility') {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(400);
            echo json_encode(['error' => 'POST required']);
            exit;
        }

        $sop_id = (int)($_POST['sop_id'] ?? 0);
        $visibility = trim((string)($_POST['visibility'] ?? ''));
        $selected_teams = isset($_POST['teams']) ? (array)$_POST['teams'] : [];

        if ($sop_id <= 0 || !in_array($visibility, ['public', 'team', 'teams'], true)) {
            http_response_code(400);
            echo json_encode(['error' => 'Invalid parameters']);
            exit;
        }

        // Get SOP details
        $sopStmt = $pdo->prepare("SELECT owner_id, visibility as old_visibility FROM sops WHERE id = ? LIMIT 1");
        $sopStmt->execute([$sop_id]);
        $sop = $sopStmt->fetch(PDO::FETCH_ASSOC);

        if (!$sop) {
            http_response_code(404);
            echo json_encode(['error' => 'SOP not found']);
            exit;
        }

        // Check permission: only author + can_edit or admin
        if (!$is_admin && (int)$sop['owner_id'] !== $current_user_id) {
            http_response_code(403);
            echo json_encode(['error' => 'Only author can change visibility']);
            exit;
        }

        if (!$is_admin && !hasRolePermission($pdo, $user_role, 'sop', 'can_edit')) {
            http_response_code(403);
            echo json_encode(['error' => 'No edit permission']);
            exit;
        }

        // Save visibility
        $success = saveItemSharing($pdo, 'sop', $sop_id, $visibility, $selected_teams);

        if ($success) {
            // Log the action
            $oldVisibility = $sop['old_visibility'];
            $details = [
                'old_visibility' => $oldVisibility,
                'new_visibility' => $visibility,
            ];
            if ($visibility === 'teams') {
                $details['shared_teams'] = $selected_teams;
            }

            $userName = $_SESSION['first_name'] ?? $_SESSION['ncgr_id'] ?? 'Unknown User';
            logItemAction($pdo, 'sop', $sop_id, 'VISIBILITY_CHANGED', $current_user_id, $userName, $details);

            echo json_encode([
                'success' => true,
                'message' => 'Visibility updated successfully'
            ]);
        } else {
            http_response_code(500);
            echo json_encode(['error' => 'Failed to save visibility']);
        }
        exit;
    }

    // ============================================
    // Get All Available Teams
    // ============================================
    if ($action === 'get_all_teams') {
        $teams = getAllTeams($pdo);

        echo json_encode([
            'success' => true,
            'teams' => $teams
        ]);
        exit;
    }

    // ============================================
    // Default: Action not found
    // ============================================
    http_response_code(400);
    echo json_encode(['error' => 'Unknown action']);

} catch (Throwable $e) {
    error_log("SOP Actions Error: " . $e->getMessage());
    http_response_code(500);
    echo json_encode(['error' => 'Server error: ' . $e->getMessage()]);
}
