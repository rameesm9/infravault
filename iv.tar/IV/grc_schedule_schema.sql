/*
|--------------------------------------------------------------------------
| GRC PATCHING SCHEDULE - SQLITE3
|--------------------------------------------------------------------------
|
| Existing tables:
|   inventory
|   users
|
| Expected inventory fields:
|   id
|   hostname
|   support_level
|   ip_address
|   application
|   os_family
|   os_version
|   kernel_version
|   grc
|
|--------------------------------------------------------------------------
*/


PRAGMA foreign_keys = ON;


/*
|--------------------------------------------------------------------------
| GRC PATCHING SCHEDULE
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_schedules (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    inventory_id INTEGER NOT NULL,

    project TEXT NOT NULL,

    support_level TEXT NOT NULL,

    recurrence_interval_days INTEGER NOT NULL DEFAULT 30,

    /*
    | Snapshot of the versions when the schedule was created/updated.
    */

    current_os_version TEXT,

    current_kernel_version TEXT,

    /*
    | Target versions.
    */

    new_os_version TEXT,

    new_kernel_version TEXT,

    /*
    | Schedule dates.
    */

    scheduled_time TEXT,

    patched_time TEXT,

    next_date TEXT,

    /*
    | User responsible for patching.
    */

    assignee_id INTEGER,

    /*
    | Planned
    | Scheduled
    | In Progress
    | Completed
    | Failed
    | Cancelled
    | Skipped
    */

    status TEXT NOT NULL DEFAULT 'Planned',

    /*
    | Patch result.
    */

    patch_result TEXT,

    result_notes TEXT,

    /*
    | Change Request.
    */

    change_request TEXT,

    /*
    | Additional comments.
    */

    comments TEXT,

    /*
    | Optional attachment.
    */

    attachment_original_name TEXT,

    attachment_stored_name TEXT,

    attachment_path TEXT,

    attachment_mime TEXT,

    attachment_size INTEGER,

    /*
    | Audit ownership.
    */

    created_by INTEGER,

    updated_by INTEGER,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    /*
    |--------------------------------------------------------------------------
    | Foreign keys
    |--------------------------------------------------------------------------
    */

    FOREIGN KEY (inventory_id)
        REFERENCES inventory(id)
        ON DELETE CASCADE,

    FOREIGN KEY (assignee_id)
        REFERENCES users(id)
        ON DELETE SET NULL,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE SET NULL,

    FOREIGN KEY (updated_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


/*
|--------------------------------------------------------------------------
| Indexes
|--------------------------------------------------------------------------
*/

CREATE INDEX IF NOT EXISTS idx_grc_inventory_id
ON grc_schedules(inventory_id);

CREATE INDEX IF NOT EXISTS idx_grc_project
ON grc_schedules(project);

CREATE INDEX IF NOT EXISTS idx_grc_support_level
ON grc_schedules(support_level);

CREATE INDEX IF NOT EXISTS idx_grc_assignee
ON grc_schedules(assignee_id);

CREATE INDEX IF NOT EXISTS idx_grc_status
ON grc_schedules(status);

CREATE INDEX IF NOT EXISTS idx_grc_next_date
ON grc_schedules(next_date);

CREATE INDEX IF NOT EXISTS idx_grc_scheduled_time
ON grc_schedules(scheduled_time);

CREATE INDEX IF NOT EXISTS idx_grc_patched_time
ON grc_schedules(patched_time);


/*
|--------------------------------------------------------------------------
| Prevent duplicate project schedule for same server
|--------------------------------------------------------------------------
*/

CREATE UNIQUE INDEX IF NOT EXISTS
uq_grc_inventory_project
ON grc_schedules(
    inventory_id,
    project
);


/*
|--------------------------------------------------------------------------
| GRC AUDIT
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_schedule_audit (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,

    action TEXT NOT NULL,

    field_name TEXT,

    old_value TEXT,

    new_value TEXT,

    changed_by INTEGER,

    changed_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (schedule_id)
        REFERENCES grc_schedules(id)
        ON DELETE CASCADE,

    FOREIGN KEY (changed_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


/*
|--------------------------------------------------------------------------
| Audit indexes
|--------------------------------------------------------------------------
*/

CREATE INDEX IF NOT EXISTS idx_grc_audit_schedule
ON grc_schedule_audit(schedule_id);

CREATE INDEX IF NOT EXISTS idx_grc_audit_changed_by
ON grc_schedule_audit(changed_by);

CREATE INDEX IF NOT EXISTS idx_grc_audit_changed_at
ON grc_schedule_audit(changed_at);

CREATE INDEX IF NOT EXISTS idx_grc_audit_action
ON grc_schedule_audit(action);


/*
|--------------------------------------------------------------------------
| CSV IMPORT LOG
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_schedule_import_log (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    filename TEXT NOT NULL,

    total_rows INTEGER NOT NULL DEFAULT 0,

    imported_rows INTEGER NOT NULL DEFAULT 0,

    skipped_rows INTEGER NOT NULL DEFAULT 0,

    error_rows INTEGER NOT NULL DEFAULT 0,

    error_summary TEXT,

    imported_by INTEGER,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (imported_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


/*
|--------------------------------------------------------------------------
| Import indexes
|--------------------------------------------------------------------------
*/

CREATE INDEX IF NOT EXISTS idx_grc_import_user
ON grc_schedule_import_log(imported_by);

CREATE INDEX IF NOT EXISTS idx_grc_import_date
ON grc_schedule_import_log(created_at);


/*
|--------------------------------------------------------------------------
| ATTACHMENTS
|--------------------------------------------------------------------------
|
| Multiple attachments can be stored against one schedule.
|
| Recommended for:
|
|   PDF
|   Email PDF
|   Change request
|   Patch report
|   Screenshot
|   Evidence
|
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_schedule_attachments (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,

    original_name TEXT NOT NULL,

    stored_name TEXT NOT NULL,

    file_path TEXT NOT NULL,

    mime_type TEXT,

    file_size INTEGER,

    uploaded_by INTEGER,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (schedule_id)
        REFERENCES grc_schedules(id)
        ON DELETE CASCADE,

    FOREIGN KEY (uploaded_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


/*
|--------------------------------------------------------------------------
| Attachment indexes
|--------------------------------------------------------------------------
*/

CREATE INDEX IF NOT EXISTS idx_grc_attachment_schedule
ON grc_schedule_attachments(schedule_id);

CREATE INDEX IF NOT EXISTS idx_grc_attachment_user
ON grc_schedule_attachments(uploaded_by);

CREATE INDEX IF NOT EXISTS idx_grc_attachment_created
ON grc_schedule_attachments(created_at);


/*
|--------------------------------------------------------------------------
| STATUS HISTORY
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_schedule_status_history (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    schedule_id INTEGER NOT NULL,

    old_status TEXT,

    new_status TEXT NOT NULL,

    changed_by INTEGER,

    comments TEXT,

    changed_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (schedule_id)
        REFERENCES grc_schedules(id)
        ON DELETE CASCADE,

    FOREIGN KEY (changed_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


CREATE INDEX IF NOT EXISTS idx_grc_status_schedule
ON grc_schedule_status_history(schedule_id);

CREATE INDEX IF NOT EXISTS idx_grc_status_changed_by
ON grc_schedule_status_history(changed_by);

CREATE INDEX IF NOT EXISTS idx_grc_status_changed_at
ON grc_schedule_status_history(changed_at);


/*
|--------------------------------------------------------------------------
| PROJECTS
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_projects (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    project_name TEXT NOT NULL UNIQUE,

    description TEXT,

    active INTEGER NOT NULL DEFAULT 1,

    created_by INTEGER,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    FOREIGN KEY (created_by)
        REFERENCES users(id)
        ON DELETE SET NULL

);


CREATE INDEX IF NOT EXISTS idx_grc_project_active
ON grc_projects(active);


/*
|--------------------------------------------------------------------------
| SUPPORT LEVELS
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_support_levels (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    support_level TEXT NOT NULL UNIQUE,

    description TEXT,

    active INTEGER NOT NULL DEFAULT 1,

    created_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP,

    updated_at TEXT NOT NULL
        DEFAULT CURRENT_TIMESTAMP

);


CREATE INDEX IF NOT EXISTS idx_grc_support_active
ON grc_support_levels(active);


/*
|--------------------------------------------------------------------------
| Default support levels
|--------------------------------------------------------------------------
*/

INSERT OR IGNORE INTO grc_support_levels
(
    support_level
)
VALUES
    ('L1');

INSERT OR IGNORE INTO grc_support_levels
(
    support_level
)
VALUES
    ('L2');

INSERT OR IGNORE INTO grc_support_levels
(
    support_level
)
VALUES
    ('L3');

INSERT OR IGNORE INTO grc_support_levels
(
    support_level
)
VALUES
    ('24x7');

INSERT OR IGNORE INTO grc_support_levels
(
    support_level
)
VALUES
    ('Business Hours');


/*
|--------------------------------------------------------------------------
| RECURRENCE INTERVALS
|--------------------------------------------------------------------------
*/

CREATE TABLE IF NOT EXISTS grc_recurrence_intervals (

    id INTEGER PRIMARY KEY AUTOINCREMENT,

    interval_name TEXT NOT NULL,

    interval_days INTEGER NOT NULL UNIQUE,

    active INTEGER NOT NULL DEFAULT 1

);


/*
|--------------------------------------------------------------------------
| Default recurrence options
|--------------------------------------------------------------------------
*/

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 30 Days', 30);

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 60 Days', 60);

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 90 Days', 90);

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 120 Days', 120);

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 180 Days', 180);

INSERT OR IGNORE INTO grc_recurrence_intervals
(
    interval_name,
    interval_days
)
VALUES
    ('Every 365 Days', 365);
