<?php

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/pagination-helpers.php';


/*
|--------------------------------------------------------------------------
| SESSION
|--------------------------------------------------------------------------
*/

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

/*
| An anonymous visitor was already refused further down (empty role means
| no permission row matches, so $canView is false), but only as a side
| effect. Stating it explicitly means the page does not depend on that
| coincidence continuing to hold.
*/
requireLogin();

$current_user_id = (int) ($_SESSION['user_id'] ?? 0);


/*
|--------------------------------------------------------------------------
| PAGE
|--------------------------------------------------------------------------
*/

$page_title = "License, Warranty & EOL";


/*
|--------------------------------------------------------------------------
| CURRENT PAGE
|--------------------------------------------------------------------------
*/

$current_page = basename($_SERVER['PHP_SELF']);


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

function hasPermission(PDO $pdo, string $role, string $pageKey, string $permission): bool {
    /*
    | Delegates to the single authorization helper (includes/authz.php).
    |
    | This was a seventeenth private copy of the permission check, and the
    | only one taking a page key as an argument. Its `WHERE role = ?` was
    | case-sensitive, so the stray lowercase 'admin' row that exists in
    | the permissions table for this very page resolved here but nowhere
    | else in the application.
    */
    return authzCan($pdo, $role, $pageKey, $permission);
}


/*
|--------------------------------------------------------------------------
| PAGE KEY
|--------------------------------------------------------------------------
*/

$pageKey = 'license_warranty';


/*
|--------------------------------------------------------------------------
| GET PERMISSIONS
|--------------------------------------------------------------------------
*/

$session_role = trim($_SESSION['role'] ?? '');

$canView = hasPermission($pdo, $session_role, $pageKey, 'can_view');
$canEdit = hasPermission($pdo, $session_role, $pageKey, 'can_edit');
$canDelete = hasPermission($pdo, $session_role, $pageKey, 'can_delete');
$canExport = hasPermission($pdo, $session_role, $pageKey, 'can_export');
$canImport = hasPermission($pdo, $session_role, $pageKey, 'can_import');
$canAudit = hasPermission($pdo, $session_role, $pageKey, 'can_audit');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
*/
if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}


/*
|--------------------------------------------------------------------------
| CURRENT USER
|--------------------------------------------------------------------------
*/

if (empty($current_user_name)) {
    $current_user_name = $_SESSION['user_name'] 
        ?? $_SESSION['username'] 
        ?? $_SESSION['name'] 
        ?? $_SESSION['user']['name'] 
        ?? 'System';
}


/*
|--------------------------------------------------------------------------
| HTML ESCAPE
|--------------------------------------------------------------------------
*/

function h($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}


/*
|--------------------------------------------------------------------------
| PAGE URL
|--------------------------------------------------------------------------
*/

function page_url($params = []) {
    global $current_page;
    $query = $_GET;
    unset($query['action']);
    foreach ($params as $key => $value) {
        $query[$key] = $value;
    }
    return $current_page . (!empty($query) ? '?' . http_build_query($query) : '');
}


/*
|--------------------------------------------------------------------------
| REDIRECT
|--------------------------------------------------------------------------
*/

function redirect_page($tab = 'view') {
    global $current_page;
    header('Location: ' . $current_page . '?tab=' . urlencode($tab));
    exit;
}


/*
|--------------------------------------------------------------------------
| HISTORY LABEL
|--------------------------------------------------------------------------
*/

function history_label($field) {
    $labels = [
        'product_name' => 'Product Name',
        'product_type' => 'Product Type',
        'manufacturer' => 'Manufacturer',
        'product_version' => 'Product Version',
        'license_type' => 'License Type',
        'license_key' => 'License Key',
        'license_quantity' => 'License Quantity',
        'vendor' => 'Vendor',
        'support_vendor' => 'Supplier Contact',
        'agreement_number' => 'Contract Number',
        'purchase_date' => 'Purchase Date',
        'license_start_date' => 'License Start Date',
        'license_expiry_date' => 'License Expiry Date',
        'warranty_start_date' => 'Warranty Start Date',
        'warranty_expiry_date' => 'Warranty Expiry Date',
        'support_start_date' => 'Support Start Date',
        'support_expiry_date' => 'Support Expiry Date',
        'eos_date' => 'EOS Date',
        'eol_date' => 'EOL Date',
        'renewal_required' => 'Renewal Required',
        'renewal_date' => 'Renewal Date',
        'owner_name' => 'Owner Name',
        'owner_email' => 'Owner Email',
        'team' => 'Team',
        'status' => 'Status',
        'notes' => 'Notes'
    ];
    return $labels[$field] ?? ucwords(str_replace('_', ' ', $field));
}


/*
|--------------------------------------------------------------------------
| HISTORY DISPLAY
|--------------------------------------------------------------------------
*/

function history_display_value($field, $value) {
    $value = (string)$value;
    if ($field === 'license_key' && $value !== '') {
        $length = strlen($value);
        if ($length <= 4) {
            return str_repeat('*', $length);
        }
        return str_repeat('*', max(0, $length - 4)) . substr($value, -4);
    }
    return $value;
}


/*
|--------------------------------------------------------------------------
| CREATE HISTORY
|--------------------------------------------------------------------------
*/

function add_license_history($pdo, $license_id, $action, $changed_by, $old_values = null, $new_values = null) {
    $stmt = $pdo->prepare("
        INSERT INTO license_warranty_history
        (license_warranty_id, action, changed_by, old_values, new_values)
        VALUES (?, ?, ?, ?, ?)
    ");
    $stmt->execute([
        $license_id ?: null,
        $action,
        $changed_by,
        $old_values !== null ? json_encode($old_values, JSON_UNESCAPED_UNICODE) : null,
        $new_values !== null ? json_encode($new_values, JSON_UNESCAPED_UNICODE) : null
    ]);
}


/*
|--------------------------------------------------------------------------
| AUDIT FIELDS
|--------------------------------------------------------------------------
*/

function license_audit_fields() {
    return [
        'product_name', 'product_type', 'manufacturer', 'product_version',
        'license_type', 'license_key', 'license_quantity',
        'vendor', 'support_vendor', 'agreement_number',
        'purchase_date', 'license_start_date', 'license_expiry_date',
        'warranty_start_date', 'warranty_expiry_date',
        'support_start_date', 'support_expiry_date',
        'eos_date', 'eol_date',
        'renewal_required', 'renewal_date',
        'owner_name', 'owner_email', 'team',
        'status', 'notes'
    ];
}


/*
|--------------------------------------------------------------------------
| COMPARE OLD / NEW
|--------------------------------------------------------------------------
*/

function get_changed_values($old, $new) {
    $old_changed = [];
    $new_changed = [];
    foreach (license_audit_fields() as $field) {
        $old_value = (string)($old[$field] ?? '');
        $new_value = (string)($new[$field] ?? '');
        if ($old_value !== $new_value) {
            $old_changed[$field] = $old_value;
            $new_changed[$field] = $new_value;
        }
    }
    return [$old_changed, $new_changed];
}


/*
|--------------------------------------------------------------------------
| BUILD RECORD FROM POST
|--------------------------------------------------------------------------
*/

function get_post_data() {
    return [
        'product_name' => trim($_POST['product_name'] ?? ''),
        'product_type' => trim($_POST['product_type'] ?? ''),
        'manufacturer' => trim($_POST['manufacturer'] ?? ''),
        'product_version' => trim($_POST['product_version'] ?? ''),
        'license_type' => trim($_POST['license_type'] ?? ''),
        'license_key' => trim($_POST['license_key'] ?? ''),
        'license_quantity' => trim($_POST['license_quantity'] ?? ''),
        'vendor' => trim($_POST['vendor'] ?? ''),
        'support_vendor' => trim($_POST['support_vendor'] ?? ''),
        'agreement_number' => trim($_POST['agreement_number'] ?? ''),
        'purchase_date' => trim($_POST['purchase_date'] ?? ''),
        'license_start_date' => trim($_POST['license_start_date'] ?? ''),
        'license_expiry_date' => trim($_POST['license_expiry_date'] ?? ''),
        'warranty_start_date' => trim($_POST['warranty_start_date'] ?? ''),
        'warranty_expiry_date' => trim($_POST['warranty_expiry_date'] ?? ''),
        'support_start_date' => trim($_POST['support_start_date'] ?? ''),
        'support_expiry_date' => trim($_POST['support_expiry_date'] ?? ''),
        'eos_date' => trim($_POST['eos_date'] ?? ''),
        'eol_date' => trim($_POST['eol_date'] ?? ''),
        'renewal_required' => trim($_POST['renewal_required'] ?? 'No'),
        'renewal_date' => trim($_POST['renewal_date'] ?? ''),
        'owner_name' => trim($_POST['owner_name'] ?? ''),
        'owner_email' => trim($_POST['owner_email'] ?? ''),
        'team' => trim($_POST['team'] ?? ''),
        'status' => trim($_POST['status'] ?? 'Active'),
        'notes' => trim($_POST['notes'] ?? '')
    ];
}


/*
|--------------------------------------------------------------------------
| DATABASE VALUES
|--------------------------------------------------------------------------
*/

function record_to_data($record) {
    $data = [];
    foreach (license_audit_fields() as $field) {
        $data[$field] = (string)($record[$field] ?? '');
    }
    return $data;
}


/*
|--------------------------------------------------------------------------
| DELETE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    if (!$canDelete) {
        http_response_code(403);
        die('Access denied. You do not have permission to delete records.');
    }

    $id = (int)($_POST['id'] ?? 0);
    if ($id <= 0) {
        die('Invalid record ID.');
    }

    $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
    $stmt->execute([$id]);
    $old_record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$old_record) {
        die('Record not found.');
    }

    try {
        $pdo->beginTransaction();

        add_license_history(
            $pdo,
            $id,
            'DELETE',
            $current_user_name,
            record_to_data($old_record),
            null
        );

        $stmt = $pdo->prepare("DELETE FROM license_warranty WHERE id = ?");
        $stmt->execute([$id]);

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    redirect_page('view');
}


/*
|--------------------------------------------------------------------------
| SAVE / UPDATE
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'save') {
    if (!$canEdit) {
        http_response_code(403);
        die('Access denied. You do not have permission to add or edit records.');
    }

    $id = (int)($_POST['id'] ?? 0);
    $data = get_post_data();

    if ($data['product_name'] === '') {
        die('Product name is required.');
    }

    // UPDATE
    if ($id > 0) {
        $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
        $stmt->execute([$id]);
        $old_record = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$old_record) {
            die('Record not found.');
        }

        try {
            $pdo->beginTransaction();

            $sql = "
                UPDATE license_warranty SET
                    product_name = ?,
                    product_type = ?,
                    manufacturer = ?,
                    product_version = ?,
                    license_type = ?,
                    license_key = ?,
                    license_quantity = ?,
                    vendor = ?,
                    support_vendor = ?,
                    agreement_number = ?,
                    purchase_date = ?,
                    license_start_date = ?,
                    license_expiry_date = ?,
                    warranty_start_date = ?,
                    warranty_expiry_date = ?,
                    support_start_date = ?,
                    support_expiry_date = ?,
                    eos_date = ?,
                    eol_date = ?,
                    renewal_required = ?,
                    renewal_date = ?,
                    owner_name = ?,
                    owner_email = ?,
                    team = ?,
                    status = ?,
                    notes = ?,
                    updated_by = ?,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = ?
            ";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $data['product_name'],
                $data['product_type'],
                $data['manufacturer'],
                $data['product_version'],
                $data['license_type'],
                $data['license_key'],
                $data['license_quantity'],
                $data['vendor'],
                $data['support_vendor'],
                $data['agreement_number'],
                $data['purchase_date'],
                $data['license_start_date'],
                $data['license_expiry_date'],
                $data['warranty_start_date'],
                $data['warranty_expiry_date'],
                $data['support_start_date'],
                $data['support_expiry_date'],
                $data['eos_date'],
                $data['eol_date'],
                $data['renewal_required'],
                $data['renewal_date'],
                $data['owner_name'],
                $data['owner_email'],
                $data['team'],
                $data['status'],
                $data['notes'],
                $current_user_name,
                $id
            ]);

            $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
            $stmt->execute([$id]);
            $new_record = $stmt->fetch(PDO::FETCH_ASSOC);

            [$old_changed, $new_changed] = get_changed_values($old_record, $new_record);

            if (!empty($old_changed)) {
                add_license_history(
                    $pdo,
                    $id,
                    'UPDATE',
                    $current_user_name,
                    $old_changed,
                    $new_changed
                );
            }

            $pdo->commit();
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $e;
        }

        redirect_page('view');
    }

    // INSERT
    try {
        $pdo->beginTransaction();

        $sql = "
            INSERT INTO license_warranty (
                product_name, product_type, manufacturer, product_version,
                license_type, license_key, license_quantity,
                vendor, support_vendor, agreement_number,
                purchase_date, license_start_date, license_expiry_date,
                warranty_start_date, warranty_expiry_date,
                support_start_date, support_expiry_date,
                eos_date, eol_date,
                renewal_required, renewal_date,
                owner_name, owner_email, team,
                status, notes,
                created_by
            ) VALUES (
                ?,?,?,?,?,?,?,?,?,?,
                ?,?,?,?,?,?,?,?,?,?,
                ?,?,?,?,?,?,
                ?
            )
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute([
            $data['product_name'],
            $data['product_type'],
            $data['manufacturer'],
            $data['product_version'],
            $data['license_type'],
            $data['license_key'],
            $data['license_quantity'],
            $data['vendor'],
            $data['support_vendor'],
            $data['agreement_number'],
            $data['purchase_date'],
            $data['license_start_date'],
            $data['license_expiry_date'],
            $data['warranty_start_date'],
            $data['warranty_expiry_date'],
            $data['support_start_date'],
            $data['support_expiry_date'],
            $data['eos_date'],
            $data['eol_date'],
            $data['renewal_required'],
            $data['renewal_date'],
            $data['owner_name'],
            $data['owner_email'],
            $data['team'],
            $data['status'],
            $data['notes'],
            $current_user_name
        ]);

        $new_id = (int)$pdo->lastInsertId();

        add_license_history(
            $pdo,
            $new_id,
            'CREATE',
            $current_user_name,
            null,
            $data
        );

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }

    redirect_page('view');
}


/*
|--------------------------------------------------------------------------
| CSV EXPORT
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'export') {
    if (!$canExport) {
        http_response_code(403);
        exit('Access denied. You do not have permission to export records.');
    }

    // Build WHERE clause with same filters as main page
    $export_where_clauses = ['1=1'];
    $export_params = [];

    $s_product = trim($_GET['s_product'] ?? '');
    $s_manufacturer = trim($_GET['s_manufacturer'] ?? '');
    $s_vendor = trim($_GET['s_vendor'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');
    $s_owner = trim($_GET['s_owner'] ?? '');

    if (!empty($s_product)) {
        $export_where_clauses[] = "(product_name LIKE ? OR product_type LIKE ?)";
        $export_params[] = "%$s_product%";
        $export_params[] = "%$s_product%";
    }
    if (!empty($s_manufacturer)) {
        $export_where_clauses[] = "manufacturer LIKE ?";
        $export_params[] = "%$s_manufacturer%";
    }
    if (!empty($s_vendor)) {
        $export_where_clauses[] = "vendor LIKE ?";
        $export_params[] = "%$s_vendor%";
    }
    if (!empty($s_status)) {
        $export_where_clauses[] = "status = ?";
        $export_params[] = $s_status;
    }
    if (!empty($s_owner)) {
        $export_where_clauses[] = "(owner_name LIKE ? OR owner_email LIKE ?)";
        $export_params[] = "%$s_owner%";
        $export_params[] = "%$s_owner%";
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    $stmt = $pdo->prepare("
        SELECT
            product_name,
            product_type,
            manufacturer,
            product_version,
            license_type,
            license_key,
            license_quantity,
            vendor,
            support_vendor,
            agreement_number,
            purchase_date,
            license_start_date,
            license_expiry_date,
            warranty_start_date,
            warranty_expiry_date,
            support_start_date,
            support_expiry_date,
            eos_date,
            eol_date,
            renewal_required,
            renewal_date,
            owner_name,
            owner_email,
            team,
            status,
            notes,
            created_by,
            created_at,
            updated_by,
            updated_at
        FROM license_warranty
        WHERE $export_where_sql
        ORDER BY product_name ASC
    ");

    $stmt->execute($export_params);

    $filename = 'license_warranty_export_' . date('Ymd_His') . '.csv';

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fprintf($output, chr(0xEF) . chr(0xBB) . chr(0xBF));

    fputcsv($output, [
        'Product Name',
        'Product Type',
        'Manufacturer',
        'Product Version',
        'License Type',
        'License Key',
        'License Quantity',
        'Vendor',
        'Supplier Contact',
        'Contract Number',
        'Purchase Date',
        'License Start Date',
        'License Expiry Date',
        'Warranty Start Date',
        'Warranty Expiry Date',
        'Support Start Date',
        'Support Expiry Date',
        'EOS Date',
        'EOL Date',
        'Renewal Required',
        'Renewal Date',
        'Owner Name',
        'Owner Email',
        'Team',
        'Status',
        'Notes',
        'Created By',
        'Created At',
        'Updated By',
        'Updated At'
    ]);

    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($output, [
            $row['product_name'],
            $row['product_type'],
            $row['manufacturer'],
            $row['product_version'],
            $row['license_type'],
            $row['license_key'],
            $row['license_quantity'],
            $row['vendor'],
            $row['support_vendor'],
            $row['agreement_number'],
            $row['purchase_date'],
            $row['license_start_date'],
            $row['license_expiry_date'],
            $row['warranty_start_date'],
            $row['warranty_expiry_date'],
            $row['support_start_date'],
            $row['support_expiry_date'],
            $row['eos_date'],
            $row['eol_date'],
            $row['renewal_required'],
            $row['renewal_date'],
            $row['owner_name'],
            $row['owner_email'],
            $row['team'],
            $row['status'],
            $row['notes'],
            $row['created_by'],
            $row['created_at'],
            $row['updated_by'],
            $row['updated_at']
        ]);
    }

    fclose($output);
    exit;
}


/*
|--------------------------------------------------------------------------
| CSV IMPORT
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import') {
    if (!$canImport) {
        http_response_code(403);
        die('Access denied. You do not have permission to import CSV files.');
    }

    if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] !== UPLOAD_ERR_OK) {
        die('Please select a valid CSV file.');
    }

    $file = $_FILES['csv_file']['tmp_name'];
    $handle = fopen($file, 'r');

    if (!$handle) {
        die('Unable to read CSV file.');
    }

    $header = fgetcsv($handle);
    if (!$header) {
        fclose($handle);
        die('CSV file is empty.');
    }

    $header = array_map(function ($value) {
        $value = preg_replace('/^\xEF\xBB\xBF/', '', $value);
        return strtolower(trim($value));
    }, $header);

    $column_map = [
        'product name' => 'product_name',
        'product type' => 'product_type',
        'manufacturer' => 'manufacturer',
        'product version' => 'product_version',
        'license type' => 'license_type',
        'license key' => 'license_key',
        'license quantity' => 'license_quantity',
        'vendor' => 'vendor',
        'supplier contact' => 'support_vendor',
        'contract number' => 'agreement_number',
        'purchase date' => 'purchase_date',
        'license start date' => 'license_start_date',
        'license expiry date' => 'license_expiry_date',
        'warranty start date' => 'warranty_start_date',
        'warranty expiry date' => 'warranty_expiry_date',
        'support start date' => 'support_start_date',
        'support expiry date' => 'support_expiry_date',
        'eos date' => 'eos_date',
        'eol date' => 'eol_date',
        'renewal required' => 'renewal_required',
        'renewal date' => 'renewal_date',
        'owner name' => 'owner_name',
        'owner email' => 'owner_email',
        'team' => 'team',
        'status' => 'status',
        'notes' => 'notes'
    ];

    $indexes = [];
    foreach ($header as $index => $column) {
        if (isset($column_map[$column])) {
            $indexes[$column_map[$column]] = $index;
        }
    }

    if (!isset($indexes['product_name'])) {
        fclose($handle);
        die("CSV must contain a 'Product Name' column.");
    }

    $insert = $pdo->prepare("
        INSERT INTO license_warranty (
            product_name, product_type, manufacturer, product_version,
            license_type, license_key, license_quantity,
            vendor, support_vendor, agreement_number,
            purchase_date, license_start_date, license_expiry_date,
            warranty_start_date, warranty_expiry_date,
            support_start_date, support_expiry_date,
            eos_date, eol_date,
            renewal_required, renewal_date,
            owner_name, owner_email, team,
            status, notes,
            created_by
        ) VALUES (
            ?,?,?,?,?,?,?,?,?,?,
            ?,?,?,?,?,?,?,?,?,?,
            ?,?,?,?,?,?,
            ?
        )
    ");

    $imported = 0;

    try {
        $pdo->beginTransaction();

        while (($row = fgetcsv($handle)) !== false) {
            if (count($row) === 1 && trim($row[0]) === '') {
                continue;
            }

            $get = function ($field) use ($indexes, $row) {
                if (!isset($indexes[$field])) {
                    return '';
                }
                return trim($row[$indexes[$field]] ?? '');
            };

            $product_name = $get('product_name');
            if ($product_name === '') {
                continue;
            }

            $imported_data = [
                'product_name' => $product_name,
                'product_type' => $get('product_type'),
                'manufacturer' => $get('manufacturer'),
                'product_version' => $get('product_version'),
                'license_type' => $get('license_type'),
                'license_key' => $get('license_key'),
                'license_quantity' => $get('license_quantity'),
                'vendor' => $get('vendor'),
                'support_vendor' => $get('support_vendor'),
                'agreement_number' => $get('agreement_number'),
                'purchase_date' => $get('purchase_date'),
                'license_start_date' => $get('license_start_date'),
                'license_expiry_date' => $get('license_expiry_date'),
                'warranty_start_date' => $get('warranty_start_date'),
                'warranty_expiry_date' => $get('warranty_expiry_date'),
                'support_start_date' => $get('support_start_date'),
                'support_expiry_date' => $get('support_expiry_date'),
                'eos_date' => $get('eos_date'),
                'eol_date' => $get('eol_date'),
                'renewal_required' => $get('renewal_required') ?: 'No',
                'renewal_date' => $get('renewal_date'),
                'owner_name' => $get('owner_name'),
                'owner_email' => $get('owner_email'),
                'team' => $get('team'),
                'status' => $get('status') ?: 'Active',
                'notes' => $get('notes')
            ];

            $insert->execute([
                $imported_data['product_name'],
                $imported_data['product_type'],
                $imported_data['manufacturer'],
                $imported_data['product_version'],
                $imported_data['license_type'],
                $imported_data['license_key'],
                $imported_data['license_quantity'],
                $imported_data['vendor'],
                $imported_data['support_vendor'],
                $imported_data['agreement_number'],
                $imported_data['purchase_date'],
                $imported_data['license_start_date'],
                $imported_data['license_expiry_date'],
                $imported_data['warranty_start_date'],
                $imported_data['warranty_expiry_date'],
                $imported_data['support_start_date'],
                $imported_data['support_expiry_date'],
                $imported_data['eos_date'],
                $imported_data['eol_date'],
                $imported_data['renewal_required'],
                $imported_data['renewal_date'],
                $imported_data['owner_name'],
                $imported_data['owner_email'],
                $imported_data['team'],
                $imported_data['status'],
                $imported_data['notes'],
                $current_user_name
            ]);

            $imported_id = (int)$pdo->lastInsertId();

            add_license_history(
                $pdo,
                $imported_id,
                'CREATE',
                $current_user_name,
                null,
                $imported_data
            );

            $imported++;
        }

        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        fclose($handle);
        throw $e;
    }

    fclose($handle);
    redirect_page('view');
}


/*
|--------------------------------------------------------------------------
| AJAX: HISTORY
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'get_history') {
    if (!$canAudit) {
        http_response_code(403);
        echo '<div style="padding:20px;color:#991b1b;text-align:center;">You do not have permission to view audit history.</div>';
        exit;
    }

    $historyId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

    if ($historyId > 0) {
        $stmt = $pdo->prepare("
            SELECT h.*, lw.product_name
            FROM license_warranty_history h
            LEFT JOIN license_warranty lw ON lw.id = h.license_warranty_id
            WHERE h.license_warranty_id = ?
            ORDER BY h.changed_at DESC, h.id DESC
        ");
        $stmt->execute([$historyId]);
    } else {
        $stmt = $pdo->query("
            SELECT h.*, lw.product_name
            FROM license_warranty_history h
            LEFT JOIN license_warranty lw ON lw.id = h.license_warranty_id
            ORDER BY h.changed_at DESC, h.id DESC
        ");
    }

    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (count($logs) > 0) {
        echo '<table class="data-table">';
        echo '<thead><tr>
            <th>Action</th>
            <th>Product</th>
            <th>User</th>
            <th>Timestamp</th>
            <th>Details</th>
        </tr></thead>';
        echo '<tbody>';

        foreach ($logs as $log) {
            $badge_color = 'background:var(--border-color);color:var(--text-primary);';
            switch (strtoupper($log['action'] ?? '')) {
                case 'CREATE':
                    $badge_color = 'background:#dcfce7;color:#166534;';
                    break;
                case 'DELETE':
                    $badge_color = 'background:#fee2e2;color:#991b1b;';
                    break;
                case 'UPDATE':
                    $badge_color = 'background:#fef9c3;color:#854d0e;';
                    break;
            }

            echo '<tr>';
            echo '<td><span style="' . h($badge_color) . ' display:inline-block;padding:4px 8px;border-radius:4px;font-size:12px;font-weight:500;">' . h($log['action'] ?? '') . '</span></td>';
            echo '<td>' . h($log['product_name'] ?? '[Deleted Record]') . '</td>';
            echo '<td>' . h($log['changed_by'] ?? '') . '</td>';
            echo '<td>' . h($log['changed_at'] ?? '') . '</td>';

            echo '<td>';
            if ($log['action'] === 'CREATE') {
                echo '<span style="color:#166534;">Record created</span>';
            } elseif ($log['action'] === 'DELETE') {
                echo '<span style="color:#991b1b;">Record deleted</span>';
            } else {
                $old = $log['old_values'] ? json_decode($log['old_values'], true) : [];
                $new = $log['new_values'] ? json_decode($log['new_values'], true) : [];
                $changed_fields = array_unique(array_merge(array_keys($old), array_keys($new)));
                echo '<div style="font-size:12px;">';
                foreach ($changed_fields as $field) {
                    echo '<div style="margin-bottom:4px;">' . h(history_label($field)) . ': ';
                    echo '<span style="color:#991b1b;">old="' . h(history_display_value($field, $old[$field] ?? '')) . '"</span> → ';
                    echo '<span style="color:#166534;">new="' . h(history_display_value($field, $new[$field] ?? '')) . '"</span>';
                    echo '</div>';
                }
                echo '</div>';
            }
            echo '</td>';

            echo '</tr>';
        }

        echo '</tbody></table>';
    } else {
        echo '<p style="text-align:center;padding:20px;color:var(--text-secondary);">No audit history records found.</p>';
    }

    exit;
}


/*
|--------------------------------------------------------------------------
| CURRENT TAB
|--------------------------------------------------------------------------
*/

$tab = $_GET['tab'] ?? 'view';
$allowed_tabs = ['view', 'detail', 'add', 'edit', 'delete', 'import', 'history', 'record_history'];

if (!in_array($tab, $allowed_tabs, true)) {
    $tab = 'view';
}

// Restrict tabs based on permissions
if ($tab === 'add' || $tab === 'edit') {
    if (!$canEdit) {
        $tab = 'view';
    }
}
if ($tab === 'delete') {
    if (!$canDelete) {
        $tab = 'view';
    }
}
if ($tab === 'import') {
    if (!$canImport) {
        $tab = 'view';
    }
}
if ($tab === 'history' || $tab === 'record_history') {
    if (!$canAudit) {
        $tab = 'view';
    }
}


/*
|--------------------------------------------------------------------------
| SEARCH
|--------------------------------------------------------------------------
*/

$search = trim($_GET['search'] ?? '');


/*
|--------------------------------------------------------------------------
| DETAIL RECORD
|--------------------------------------------------------------------------
*/

$detail = null;
if ($tab === 'detail' && isset($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
    $stmt->execute([$id]);
    $detail = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$detail) {
        $tab = 'view';
    }
}


/*
|--------------------------------------------------------------------------
| EDIT RECORD
|--------------------------------------------------------------------------
*/

$edit_record = null;
if ($tab === 'edit' && isset($_GET['id']) && $canEdit) {
    $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
    $stmt->execute([(int)$_GET['id']]);
    $edit_record = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$edit_record) {
        $tab = 'view';
    }
}


/*
|--------------------------------------------------------------------------
| DELETE RECORD
|--------------------------------------------------------------------------
*/

$delete_record = null;
if ($tab === 'delete' && isset($_GET['id']) && $canDelete) {
    $stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE id = ?");
    $stmt->execute([(int)$_GET['id']]);
    $delete_record = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$delete_record) {
        $tab = 'view';
    }
}


/*
|--------------------------------------------------------------------------
| GLOBAL HISTORY
|--------------------------------------------------------------------------
*/

$history_records = [];
if ($tab === 'history' && $canAudit) {
    $stmt = $pdo->query("
        SELECT h.*, lw.product_name
        FROM license_warranty_history h
        LEFT JOIN license_warranty lw ON lw.id = h.license_warranty_id
        ORDER BY h.changed_at DESC, h.id DESC
    ");
    $history_records = $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*
|--------------------------------------------------------------------------
| RECORD HISTORY
|--------------------------------------------------------------------------
*/

$record_history = [];
$history_product = '';
if ($tab === 'record_history' && isset($_GET['id']) && $canAudit) {
    $history_id = (int)$_GET['id'];

    $stmt = $pdo->prepare("SELECT product_name FROM license_warranty WHERE id = ?");
    $stmt->execute([$history_id]);
    $history_product = $stmt->fetchColumn();

    $stmt = $pdo->prepare("
        SELECT * FROM license_warranty_history
        WHERE license_warranty_id = ?
        ORDER BY changed_at DESC, id DESC
    ");
    $stmt->execute([$history_id]);
    $record_history = $stmt->fetchAll(PDO::FETCH_ASSOC);
}


/*
|--------------------------------------------------------------------------
| PAGINATION & SEARCH
|--------------------------------------------------------------------------
*/

$page = isset($_GET['page'])
    ? max(1, (int)$_GET['page'])
    : 1;

// Row count selector (shared, per-user persisted page size)
$rowCount = resolveUserPageSize($pdo, $current_user_id);
$limit = $rowCount;
$start = ($page - 1) * $limit;

// Search fields
$s_product = trim($_GET['s_product'] ?? '');
$s_manufacturer = trim($_GET['s_manufacturer'] ?? '');
$s_vendor = trim($_GET['s_vendor'] ?? '');
$s_status = trim($_GET['s_status'] ?? '');
$s_owner = trim($_GET['s_owner'] ?? '');

$where_clauses = ['1=1'];
$params = [];

if (!empty($s_product)) {
    $where_clauses[] = "(product_name LIKE ? OR product_type LIKE ?)";
    $params[] = "%$s_product%";
    $params[] = "%$s_product%";
}
if (!empty($s_manufacturer)) {
    $where_clauses[] = "manufacturer LIKE ?";
    $params[] = "%$s_manufacturer%";
}
if (!empty($s_vendor)) {
    $where_clauses[] = "vendor LIKE ?";
    $params[] = "%$s_vendor%";
}
if (!empty($s_status)) {
    $where_clauses[] = "status = ?";
    $params[] = $s_status;
}
if (!empty($s_owner)) {
    $where_clauses[] = "(owner_name LIKE ? OR owner_email LIKE ?)";
    $params[] = "%$s_owner%";
    $params[] = "%$s_owner%";
}

$where_sql = implode(" AND ", $where_clauses);

// Count total records
$total_stmt = $pdo->prepare("SELECT COUNT(*) FROM license_warranty WHERE $where_sql");
$total_stmt->execute($params);
$total_records = $total_stmt->fetchColumn();
$total_pages = max(1, (int)ceil($total_records / $limit));

// Correct page if out of range
if ($page > $total_pages && $total_records > 0) {
    $page = $total_pages;
    $start = ($page - 1) * $limit;
}

// Sorting - validate and apply
$sort_by = trim((string) ($_GET['sort_by'] ?? 'product_name'));
$sort_dir = trim((string) ($_GET['sort_dir'] ?? 'ASC'));

$valid_sort_columns = ['id', 'product_name', 'manufacturer', 'vendor', 'license_type', 'license_expiry_date', 'warranty_expiry_date', 'eol_date', 'status', 'owner_name', 'created_at'];
if (!in_array($sort_by, $valid_sort_columns, true)) {
    $sort_by = 'product_name';
}
if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
    $sort_dir = 'ASC';
}

$next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

// Fetch records
$data_stmt = $pdo->prepare("SELECT * FROM license_warranty WHERE $where_sql ORDER BY `$sort_by` $sort_dir LIMIT $limit OFFSET $start");
$data_stmt->execute($params);
$records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

// Helper function for expiry dates
function is_expired($date) {
    if (empty($date)) return false;
    try {
        $d = new DateTime($date);
        $now = new DateTime();
        return $d < $now;
    } catch (Exception $e) {
        return false;
    }
}


/*
|--------------------------------------------------------------------------
| LAYOUT
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';

?>

<link rel="stylesheet" href="assets/css/license_warranty.css">
<style>
body { font-family: system-ui, -apple-system, sans-serif; color: var(--text-primary); line-height: 1.5; }
.btn { display: inline-block; padding: 10px 16px; border: 1px solid #D1D5DB; border-radius: 6px; text-decoration: none; cursor: pointer; font-weight: 500; font-size: 14px; text-align: center; background: var(--bg-content); color: var(--text-secondary); transition: all 0.2s; }
.btn:hover { opacity: 0.9; }
.btn-success { background: #10B981; color: white; border-color: #10B981; }
.btn-info { background: #3B82F6; color: white; border-color: #3B82F6; }
.btn-warning { background: #F59E0B; color: white; border-color: #F59E0B; }
.btn-primary { background: #2563EB; color: white; border-color: #2563EB; }
.btn-secondary { background: #6B7280; color: white; border-color: #6B7280; }
.btn-danger { background: #EF4444; color: white; border-color: #EF4444; }
.btn-sm { padding: 8px 12px; font-size: 13px; }
.btn-icon { width: auto; padding: 6px 8px; font-size: 14px; }
.btn-outline-secondary { background: var(--bg-content); color: var(--text-secondary); border-color: var(--border-color); }
.btn-outline-secondary:hover { background: var(--hover-bg); }
.btn-outline-secondary.active { background: #2563EB; color: white; border-color: #2563EB; }
.form-control { width: 100%; padding: 10px 12px; border: 1px solid var(--border-color); border-radius: 6px; font-size: 14px; box-sizing: border-box; }
.form-control:focus { outline: none; border-color: #2563EB; box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1); }
.form-group { margin-bottom: 0; }
.panel { background: var(--bg-content); border: 1px solid var(--border-color); border-radius: 8px; padding: 20px; margin-bottom: 20px; box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05); }
.panel-header { display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px; }
.panel-title { font-size: 16px; font-weight: 600; color: var(--text-primary); margin: 0; }
.table-wrap { overflow-x: auto; }
.data-table { width: 100%; border-collapse: collapse; }
.data-table thead tr { background: var(--hover-bg); }
.data-table th { padding: 12px 16px; text-align: left; font-weight: 600; color: var(--text-secondary); border-bottom: 1px solid var(--border-color); }
.data-table th a { color: inherit; text-decoration: none; }
.data-table th a:hover { color: #2563EB; }
.data-table td { padding: 12px 16px; border-bottom: 1px solid var(--border-color); }
.data-table tbody tr:hover { background: var(--hover-bg); }
.cell-primary { font-weight: 600; color: var(--text-primary); }
.status-badge { display: inline-block; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: 500; background: #DBEAFE; color: #1E40AF; }
.row-actions { display: flex; gap: 6px; justify-content: center; align-items: center; }
.pagination-row { display: flex; gap: 8px; padding: 20px 22px; justify-content: center; flex-wrap: wrap; }
.modal-overlay { display: none !important; position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.5); z-index: 1000; align-items: center; justify-content: center; }
.modal-overlay.active { display: flex !important; }
.modal-content { background: var(--bg-content); border-radius: 8px; max-width: 800px; width: 90%; max-height: 90vh; overflow-y: auto; box-shadow: 0 10px 40px rgba(0, 0, 0, 0.2); }
.modal-header { padding: 20px; border-bottom: 1px solid var(--border-color); display: flex; justify-content: space-between; align-items: center; }
.modal-header h3 { margin: 0; font-size: 18px; }
.modal-body { padding: 20px; }
.close-modal { background: none; border: none; font-size: 24px; cursor: pointer; color: var(--text-secondary); padding: 0; width: 32px; height: 32px; display: flex; align-items: center; justify-content: center; }
.close-modal:hover { color: var(--text-primary); }
.dashboard-header { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 30px; gap: 20px; flex-wrap: wrap; }
.dashboard-header > div:first-child { flex: 1; }
.dashboard-header h1 { margin: 0 0 8px 0; font-size: 28px; }
.dashboard-header p { margin: 0; color: var(--text-secondary); font-size: 14px; }
.dashboard-actions { display: flex; gap: 10px; flex-wrap: wrap; align-items: center; }
.expired { color: #DC2626; font-weight: 500; }
</style>

<div class="content">

<div class="dashboard-header">
    <div>
        <h1>License, Warranty &amp; EOL Management</h1>
        <p>Track software products, licenses, warranties, support contracts and lifecycle dates.</p>
    </div>
    <div class="dashboard-actions">
        <?php
        /*
        | EOL Systems sits on the same page key as this tracker: it is the
        | hardware/server side of the same lifecycle question, so anyone
        | who may see licence and EOL data may see it.
        */
        ?>
        <a href="eol_systems.php" class="btn btn-danger">⚠ EOL Systems</a>
        <?php if ($canEdit): ?>
            <a href="<?= h(page_url(['tab' => 'add'])); ?>" class="btn btn-success">+ Add Record</a>
        <?php endif; ?>
        <?php if ($canImport): ?>
            <a href="<?= h(page_url(['tab' => 'import'])); ?>" class="btn btn-info">Import CSV</a>
        <?php endif; ?>
        <?php if ($canExport): ?>
            <?php
            $export_params = ['action' => 'export'];
            if ($s_product !== '') $export_params['s_product'] = $s_product;
            if ($s_manufacturer !== '') $export_params['s_manufacturer'] = $s_manufacturer;
            if ($s_vendor !== '') $export_params['s_vendor'] = $s_vendor;
            if ($s_status !== '') $export_params['s_status'] = $s_status;
            if ($s_owner !== '') $export_params['s_owner'] = $s_owner;
            $export_url = $current_page . '?' . http_build_query($export_params);
            ?>
            <a href="<?= h($export_url) ?>" class="btn btn-info">Export CSV</a>
        <?php endif; ?>
        <?php if ($canAudit): ?>
            <button type="button" class="btn btn-warning" onclick="openGlobalHistoryModal()">⏱ History</button>
        <?php endif; ?>
    </div>
</div>

<?php if ($tab === 'view'): ?>

<!-- Search Panel -->
<div class="panel">
    <div class="panel-header" style="margin-bottom:14px;">
        <h3 class="panel-title" style="margin:0;">Search &amp; Filters</h3>
        <span style="cursor:pointer;color:#2563EB;font-size:13px;font-weight:600;" onclick="toggleAdvancedSearch()">
            Search Multiple Values &#9662;
        </span>
    </div>

    <form method="GET" action="<?= h($current_page); ?>" style="display:flex;gap:10px;flex-wrap:wrap;">
        <input type="hidden" name="tab" value="view">
        <input type="text" name="s_product" class="form-control" style="max-width:320px;" placeholder="Search product name, type..." value="<?= h($s_product); ?>" autocomplete="off">
        <button type="submit" class="btn btn-primary">Search</button>
        <?php if ($s_product !== '' || $s_manufacturer !== '' || $s_vendor !== '' || $s_status !== '' || $s_owner !== ''): ?>
            <a href="<?= h($current_page . '?tab=view'); ?>" class="btn">Clear</a>
        <?php endif; ?>
    </form>

    <div id="advancedSearchPanel" style="display:<?= ($s_product !== '' || $s_manufacturer !== '' || $s_vendor !== '' || $s_status !== '' || $s_owner !== '') ? 'block' : 'none'; ?>;margin-top:18px;padding:20px;background:var(--hover-bg);border-radius:10px;border:1px solid var(--border-color);">
        <form method="GET" action="<?= h($current_page); ?>" style="display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;">
            <input type="hidden" name="tab" value="view">

            <div class="form-group">
                <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Product</label>
                <input type="text" name="s_product" class="form-control" placeholder="Product name, type..." value="<?= h($s_product); ?>">
            </div>

            <div class="form-group">
                <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Manufacturer</label>
                <input type="text" name="s_manufacturer" class="form-control" placeholder="Manufacturer..." value="<?= h($s_manufacturer); ?>">
            </div>

            <div class="form-group">
                <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Vendor</label>
                <input type="text" name="s_vendor" class="form-control" placeholder="Vendor..." value="<?= h($s_vendor); ?>">
            </div>

            <div class="form-group">
                <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Status</label>
                <select name="s_status" class="form-control">
                    <option value="">All Statuses</option>
                    <option value="Active" <?= $s_status === 'Active' ? 'selected' : ''; ?>>Active</option>
                    <option value="Pending Renewal" <?= $s_status === 'Pending Renewal' ? 'selected' : ''; ?>>Pending Renewal</option>
                    <option value="Expired" <?= $s_status === 'Expired' ? 'selected' : ''; ?>>Expired</option>
                    <option value="Retired" <?= $s_status === 'Retired' ? 'selected' : ''; ?>>Retired</option>
                </select>
            </div>

            <div class="form-group">
                <label style="font-weight:700;font-size:12px;color:var(--text-secondary);text-transform:uppercase;display:block;margin-bottom:8px;">Owner</label>
                <input type="text" name="s_owner" class="form-control" placeholder="Owner name, email..." value="<?= h($s_owner); ?>">
            </div>

            <div style="grid-column:1/-1;display:flex;gap:10px;flex-wrap:wrap;">
                <button type="submit" class="btn btn-primary" style="flex:1;min-width:120px;">🔍 Apply Filters</button>
                <a href="<?= h($current_page . '?tab=view'); ?>" class="btn" style="flex:1;min-width:120px;text-align:center;">↺ Reset</a>
            </div>
        </form>
    </div>
</div>

<!-- Data Table Panel -->
<div class="panel" style="padding:0;">
    <div style="padding:22px 22px 0;">
        <div class="panel-header" style="margin-bottom:0;">
            <div style="display:flex;align-items:center;gap:15px;">
                <span class="panel-title" style="margin-bottom:0;">License & Warranty Records</span>
                <span style="color:var(--text-secondary);font-size:13px;"><?php echo (int)$total_records; ?> total</span>
            </div>
            <div style="display:flex;align-items:center;gap:10px;">
                <?php
                    $lw_hidden_fields = '';
                    foreach ([
                        'tab' => 'view',
                        's_product' => $s_product,
                        's_manufacturer' => $s_manufacturer,
                        's_vendor' => $s_vendor,
                        's_status' => $s_status,
                        's_owner' => $s_owner,
                        'sort_by' => $sort_by,
                        'sort_dir' => $sort_dir,
                    ] as $lwfk => $lwfv) {
                        if ($lwfv !== '') {
                            $lw_hidden_fields .= '<input type="hidden" name="' . h($lwfk) . '" value="' . h($lwfv) . '">';
                        }
                    }
                ?>
                <?= pageSizeSelectorHtml($rowCount, $lw_hidden_fields) ?>
            </div>
        </div>
    </div>

    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=product_name&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Product
                            <?php if ($sort_by === 'product_name'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=manufacturer&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Manufacturer
                            <?php if ($sort_by === 'manufacturer'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=license_type&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            License Type
                            <?php if ($sort_by === 'license_type'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=vendor&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Vendor
                            <?php if ($sort_by === 'vendor'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=license_expiry_date&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            License Expiry
                            <?php if ($sort_by === 'license_expiry_date'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=warranty_expiry_date&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Warranty Expiry
                            <?php if ($sort_by === 'warranty_expiry_date'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=eol_date&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            EOL Date
                            <?php if ($sort_by === 'eol_date'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=status&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Status
                            <?php if ($sort_by === 'status'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th>
                        <a href="<?= h($current_page); ?>?tab=view&sort_by=owner_name&sort_dir=<?php echo $next_sort_dir; ?>&page=1<?php if ($s_product) echo '&s_product=' . urlencode($s_product); ?><?php if ($s_manufacturer) echo '&s_manufacturer=' . urlencode($s_manufacturer); ?><?php if ($s_vendor) echo '&s_vendor=' . urlencode($s_vendor); ?><?php if ($s_status) echo '&s_status=' . urlencode($s_status); ?><?php if ($s_owner) echo '&s_owner=' . urlencode($s_owner); ?>&page_size=<?= $rowCount; ?>" style="display:flex;align-items:center;gap:6px;text-decoration:none;color:inherit;">
                            Owner
                            <?php if ($sort_by === 'owner_name'): ?>
                                <span style="color:#2563EB;"><?php echo $sort_dir === 'ASC' ? '↑' : '↓'; ?></span>
                            <?php endif; ?>
                        </a>
                    </th>
                    <th style="text-align:center;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($records) > 0): ?>
                    <?php foreach ($records as $row): ?>
                    <tr>
                        <td class="cell-primary"><strong><?= h($row['product_name']); ?></strong></td>
                        <td><?= h($row['manufacturer']); ?></td>
                        <td><?= h($row['license_type']); ?></td>
                        <td><?= h($row['vendor']); ?></td>
                        <td class="date <?= is_expired($row['license_expiry_date']) ? 'expired' : ''; ?>"><?= h($row['license_expiry_date']); ?></td>
                        <td class="date <?= is_expired($row['warranty_expiry_date']) ? 'expired' : ''; ?>"><?= h($row['warranty_expiry_date']); ?></td>
                        <td><?= h($row['eol_date']); ?></td>
                        <td><span class="status-badge"><?= h($row['status']); ?></span></td>
                        <td><?= h($row['owner_name']); ?></td>
                        <td style="text-align:center;white-space:nowrap;">
                            <div class="row-actions">
                                <button type="button" class="btn btn-sm btn-secondary btn-icon" title="View" onclick="location.href='<?= h(page_url(['tab' => 'detail', 'id' => (int)$row['id']])); ?>'">👁</button>
                                <?php if ($canEdit): ?>
                                    <button type="button" class="btn btn-sm btn-primary btn-icon" title="Edit" onclick="location.href='<?= h(page_url(['tab' => 'edit', 'id' => (int)$row['id']])); ?>'">✎</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="btn btn-sm btn-danger btn-icon" title="Delete" onclick="location.href='<?= h(page_url(['tab' => 'delete', 'id' => (int)$row['id']])); ?>'">🗑</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="btn btn-sm btn-warning btn-icon" title="Record History" onclick="openRowHistoryModal(<?php echo (int)$row['id']; ?>, '<?= h($row['product_name']); ?>')">⏱</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="10" style="text-align:center;padding:30px;color:var(--text-secondary);">No license or warranty records found.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?= ivPager($page, $total_pages, array_filter([
        'tab'            => 'view',
        's_product'      => $s_product,
        's_manufacturer' => $s_manufacturer,
        's_vendor'       => $s_vendor,
        's_status'       => $s_status,
        's_owner'        => $s_owner,
        'sort_by'        => $sort_by,
        'sort_dir'       => $sort_dir,
        'page_size'      => $rowCount,
    ], static fn($v) => $v !== '' && $v !== null),
    ['base' => $current_page, 'total_records' => $total_records ?? null, 'per_page' => $rowCount]) ?>
</div>

<?php endif; ?>

<!-- =======================================================
     DETAIL VIEW
======================================================= -->

<?php if ($tab === 'detail' && $detail): ?>
<div class="lw-panel">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h2><?= h($detail['product_name']); ?></h2>
        <a href="<?= h(page_url(['tab' => 'view'])); ?>" class="lw-btn secondary">← Back</a>
    </div>
    
    <div class="lw-grid">
        <?php
        $detail_fields = [
            'product_name' => 'Product Name',
            'product_type' => 'Product Type',
            'manufacturer' => 'Manufacturer',
            'product_version' => 'Product Version',
            'license_type' => 'License Type',
            'license_key' => 'License Key',
            'license_quantity' => 'License Quantity',
            'vendor' => 'Vendor',
            'support_vendor' => 'Supplier Contact',
            'agreement_number' => 'Contract Number',
            'purchase_date' => 'Purchase Date',
            'license_start_date' => 'License Start Date',
            'license_expiry_date' => 'License Expiry Date',
            'warranty_start_date' => 'Warranty Start Date',
            'warranty_expiry_date' => 'Warranty Expiry Date',
            'support_start_date' => 'Support Start Date',
            'support_expiry_date' => 'Support Expiry Date',
            'eos_date' => 'EOS Date',
            'eol_date' => 'EOL Date',
            'renewal_required' => 'Renewal Required',
            'renewal_date' => 'Renewal Date',
            'owner_name' => 'Owner',
            'owner_email' => 'Owner Email',
            'team' => 'Team',
            'status' => 'Status'
        ];
        foreach ($detail_fields as $field => $label):
        ?>
        <label>
            <span style="color:var(--text-secondary);font-size:12px;font-weight:600;"><?= h($label); ?></span>
            <span style="padding:8px 0;font-weight:500;"><?= h($detail[$field] ?? ''); ?></span>
        </label>
        <?php endforeach; ?>
        <label style="grid-column:1/-1;">
            <span style="color:var(--text-secondary);font-size:12px;font-weight:600;">Notes</span>
            <span style="padding:8px 0;font-weight:500;"><?= nl2br(h($detail['notes'] ?? '')); ?></span>
        </label>
    </div>
</div>
<?php endif; ?>

<!-- =======================================================
     ADD / EDIT FORM
======================================================= -->

<?php if (($tab === 'add' || ($tab === 'edit' && $edit_record)) && $canEdit):
    $r = $edit_record ?: [
        'id' => '',
        'product_name' => '',
        'product_type' => '',
        'manufacturer' => '',
        'product_version' => '',
        'license_type' => '',
        'license_key' => '',
        'license_quantity' => '',
        'vendor' => '',
        'support_vendor' => '',
        'agreement_number' => '',
        'purchase_date' => '',
        'license_start_date' => '',
        'license_expiry_date' => '',
        'warranty_start_date' => '',
        'warranty_expiry_date' => '',
        'support_start_date' => '',
        'support_expiry_date' => '',
        'eos_date' => '',
        'eol_date' => '',
        'renewal_required' => 'No',
        'renewal_date' => '',
        'owner_name' => '',
        'owner_email' => '',
        'team' => '',
        'status' => 'Active',
        'notes' => ''
    ];
?>
<div class="lw-panel">
    <h2><?= $edit_record ? 'Edit Product' : 'Add New Product'; ?></h2>
    
    <form method="POST" action="<?= h($current_page); ?>">
        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= h($r['id']); ?>">

        <!-- Product Information -->
        <div class="lw-section">
            <h3>Product Information</h3>
            <div class="lw-grid">
                <label>Product Name *<input type="text" name="product_name" required value="<?= h($r['product_name']); ?>"></label>
                <label>Product Type<input type="text" name="product_type" placeholder="Software / Hardware / Platform" value="<?= h($r['product_type']); ?>"></label>
                <label>Manufacturer<input type="text" name="manufacturer" value="<?= h($r['manufacturer']); ?>"></label>
                <label>Product Version<input type="text" name="product_version" value="<?= h($r['product_version']); ?>"></label>
            </div>
        </div>

        <!-- License Information -->
        <div class="lw-section">
            <h3>License Information</h3>
            <div class="lw-grid">
                <label>License Type
                    <select name="license_type">
                        <option value="">Select</option>
                        <?php foreach (['Perpetual', 'Subscription', 'Enterprise', 'Named User', 'Concurrent', 'Open Source', 'Evaluation', 'Other'] as $option): ?>
                        <option value="<?= h($option); ?>" <?= ($r['license_type'] === $option) ? 'selected' : ''; ?>><?= h($option); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <label>License Key / Reference<input type="text" name="license_key" value="<?= h($r['license_key']); ?>"></label>
                <label>License Quantity<input type="text" name="license_quantity" placeholder="e.g. 100 users" value="<?= h($r['license_quantity']); ?>"></label>
            </div>
        </div>

        <!-- Vendor & Contract -->
        <div class="lw-section">
            <h3>Vendor &amp; Contract</h3>
            <div class="lw-grid">
                <label>Vendor<input type="text" name="vendor" value="<?= h($r['vendor']); ?>"></label>
                <label>Supplier Contact<input type="text" name="support_vendor" value="<?= h($r['support_vendor']); ?>"></label>
                <label>Contract Number<input type="text" name="agreement_number" value="<?= h($r['agreement_number']); ?>"></label>
            </div>
        </div>

        <!-- Dates -->
        <div class="lw-section">
            <h3>Purchase &amp; License Dates</h3>
            <div class="lw-grid">
                <label>Purchase Date<input type="date" name="purchase_date" value="<?= h($r['purchase_date']); ?>"></label>
                <label>License Start Date<input type="date" name="license_start_date" value="<?= h($r['license_start_date']); ?>"></label>
                <label>License Expiry Date<input type="date" name="license_expiry_date" value="<?= h($r['license_expiry_date']); ?>"></label>
            </div>
        </div>

        <!-- Warranty & Support -->
        <div class="lw-section">
            <h3>Warranty &amp; Support</h3>
            <div class="lw-grid">
                <label>Warranty Start Date<input type="date" name="warranty_start_date" value="<?= h($r['warranty_start_date']); ?>"></label>
                <label>Warranty Expiry Date<input type="date" name="warranty_expiry_date" value="<?= h($r['warranty_expiry_date']); ?>"></label>
                <label>Support Start Date<input type="date" name="support_start_date" value="<?= h($r['support_start_date']); ?>"></label>
                <label>Support Expiry Date<input type="date" name="support_expiry_date" value="<?= h($r['support_expiry_date']); ?>"></label>
            </div>
        </div>

        <!-- EOS / EOL -->
        <div class="lw-section">
            <h3>End of Life / End of Support</h3>
            <div class="lw-grid">
                <label>EOS Date<input type="date" name="eos_date" value="<?= h($r['eos_date']); ?>"></label>
                <label>EOL Date<input type="date" name="eol_date" value="<?= h($r['eol_date']); ?>"></label>
                <label>Renewal Required
                    <select name="renewal_required">
                        <option value="No" <?= ($r['renewal_required'] === 'No') ? 'selected' : ''; ?>>No</option>
                        <option value="Yes" <?= ($r['renewal_required'] === 'Yes') ? 'selected' : ''; ?>>Yes</option>
                    </select>
                </label>
                <label>Renewal Date<input type="date" name="renewal_date" value="<?= h($r['renewal_date']); ?>"></label>
            </div>
        </div>

        <!-- Ownership -->
        <div class="lw-section">
            <h3>Ownership</h3>
            <div class="lw-grid">
                <label>Owner Name<input type="text" name="owner_name" value="<?= h($r['owner_name']); ?>"></label>
                <label>Owner Email<input type="email" name="owner_email" value="<?= h($r['owner_email']); ?>"></label>
                <label>Team<input type="text" name="team" value="<?= h($r['team']); ?>"></label>
                <label>Status
                    <select name="status">
                        <?php foreach (['Active', 'Pending Renewal', 'Expired', 'Retired'] as $status_option): ?>
                        <option value="<?= h($status_option); ?>" <?= ($r['status'] === $status_option) ? 'selected' : ''; ?>><?= h($status_option); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
        </div>

        <!-- Notes -->
        <div class="lw-section">
            <h3>Notes</h3>
            <textarea name="notes" rows="4" style="width:100%;padding:10px;border:1px solid var(--border-color);border-radius:7px;"><?= h($r['notes']); ?></textarea>
        </div>

        <div class="lw-form-actions">
            <button type="submit" class="lw-btn primary"><?= $edit_record ? 'Update Product' : 'Save Product'; ?></button>
            <a href="<?= h(page_url(['tab' => 'view'])); ?>" class="lw-btn secondary">Cancel</a>
        </div>
    </form>
</div>
<?php endif; ?>

<!-- =======================================================
     IMPORT
======================================================= -->

<?php if ($tab === 'import' && $canImport): ?>
<div class="lw-panel">
    <div class="import-panel">
        <div>
            <h3>Import License / Warranty CSV</h3>
            <p>Upload a CSV file matching the supported column names. Every imported row will be recorded in the History log.</p>
        </div>
        <form method="POST" action="<?= h($current_page); ?>" enctype="multipart/form-data" class="import-form">
            <input type="hidden" name="action" value="import">
            <input type="file" name="csv_file" accept=".csv,text/csv" required>
            <button type="submit" class="lw-btn primary">Import CSV</button>
        </form>
    </div>
</div>
<?php endif; ?>

<!-- =======================================================
     DELETE
======================================================= -->

<?php if ($tab === 'delete' && $delete_record && $canDelete): ?>
<div class="lw-panel">
    <h2 style="color:#B91C1C;">Delete Product</h2>
    <div class="delete-warning">
        <span>Are you sure you want to permanently delete: <strong><?= h($delete_record['product_name']); ?></strong>?</span>
        <span><small>The deletion will be recorded in the History log.</small></span>
    </div>
    <form method="POST" action="<?= h($current_page); ?>">
        <input type="hidden" name="action" value="delete">
        <input type="hidden" name="id" value="<?= (int)$delete_record['id']; ?>">
        <button type="submit" class="lw-btn" style="background:#DC2626;color:white;" onclick="return confirm('Permanently delete this record?');">Delete Permanently</button>
        <a href="<?= h(page_url(['tab' => 'view'])); ?>" class="lw-btn secondary">Cancel</a>
    </form>
</div>
<?php endif; ?>

<!-- =======================================================
     GLOBAL HISTORY
======================================================= -->

<?php if ($tab === 'history' && $canAudit): ?>
<div class="lw-panel">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <h2>Audit History</h2>
        <a href="<?= h(page_url(['tab' => 'view'])); ?>" class="lw-btn secondary">← Back</a>
    </div>
    <div class="lw-table-wrap">
        <table class="lw-table">
            <thead>
                <tr>
                    <th>Date / Time</th>
                    <th>Action</th>
                    <th>Product</th>
                    <th>User</th>
                    <th>Changes</th>
                </tr>
            </thead>
            <tbody>
                <?php if (!$history_records): ?>
                    <tr><td colspan="5" class="empty">No history found.</td></tr>
                <?php endif; ?>
                <?php foreach ($history_records as $history):
                    $old = $history['old_values'] ? json_decode($history['old_values'], true) : [];
                    $new = $history['new_values'] ? json_decode($history['new_values'], true) : [];
                ?>
                <tr>
                    <td><?= h($history['changed_at']); ?></td>
                    <td><span class="status-badge"><?= h($history['action']); ?></span></td>
                    <td><?= h($history['product_name'] ?: '[Deleted Record]'); ?></td>
                    <td><?= h($history['changed_by']); ?></td>
                    <td>
                        <?php if ($history['action'] === 'CREATE'): ?>
                            <span style="color:#166534;">Record created</span>
                        <?php elseif ($history['action'] === 'DELETE'): ?>
                            <span style="color:#991B1B;">Record deleted</span>
                        <?php else:
                            $changed_fields = array_unique(array_merge(array_keys($old), array_keys($new)));
                            foreach ($changed_fields as $field):
                        ?>
                            <div style="margin-bottom:6px;font-size:12px;">
                                <strong><?= h(history_label($field)); ?></strong><br>
                                <span style="color:#991B1B;">→ <?= h(history_display_value($field, $old[$field] ?? '')); ?></span>
                                <span style="color:#166534;">→ <?= h(history_display_value($field, $new[$field] ?? '')); ?></span>
                            </div>
                        <?php endforeach; endif; ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>

<!-- =======================================================
     RECORD HISTORY
======================================================= -->

<?php if ($tab === 'record_history' && $canAudit): ?>
<div class="lw-panel">
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:20px;">
        <div>
            <h2>Record History</h2>
            <?php if ($history_product): ?>
                <p style="color:var(--text-secondary);">Product: <strong><?= h($history_product); ?></strong></p>
            <?php endif; ?>
        </div>
        <a href="<?= h(page_url(['tab' => 'view'])); ?>" class="lw-btn secondary">← Back</a>
    </div>
    
    <?php if (!$record_history): ?>
        <div style="padding:30px;text-align:center;color:var(--text-secondary);">No history found for this record.</div>
    <?php endif; ?>
    
    <?php foreach ($record_history as $history):
        $old = $history['old_values'] ? json_decode($history['old_values'], true) : [];
        $new = $history['new_values'] ? json_decode($history['new_values'], true) : [];
    ?>
    <div style="border:1px solid var(--border-color);border-radius:8px;margin-bottom:15px;overflow:hidden;">
        <div style="padding:12px 15px;background:var(--hover-bg);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px;">
            <span class="status-badge"><?= h($history['action']); ?></span>
            <span style="color:var(--text-secondary);font-size:12px;"><?= h($history['changed_at']); ?> — <strong><?= h($history['changed_by']); ?></strong></span>
        </div>
        <div style="padding:15px;">
            <?php if ($history['action'] === 'CREATE'): ?>
                <div style="color:#166534;">Record created by <?= h($history['changed_by']); ?></div>
            <?php elseif ($history['action'] === 'DELETE'): ?>
                <div style="color:#991B1B;">Record deleted by <?= h($history['changed_by']); ?></div>
            <?php else:
                $changed_fields = array_unique(array_merge(array_keys($old), array_keys($new)));
                foreach ($changed_fields as $field):
            ?>
                <div style="padding:8px 0;border-bottom:1px solid #EEF2F7;">
                    <div style="font-weight:600;margin-bottom:4px;"><?= h(history_label($field)); ?></div>
                    <div style="color:#991B1B;font-size:13px;">Old: <?= nl2br(h(history_display_value($field, $old[$field] ?? ''))); ?></div>
                    <div style="color:#166534;font-size:13px;">New: <?= nl2br(h(history_display_value($field, $new[$field] ?? ''))); ?></div>
                </div>
            <?php endforeach; endif; ?>
        </div>
    </div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<!-- Global History Modal -->
<div id="globalHistoryModal" class="modal-overlay">
    <div class="modal-content" style="max-width:900px;">
        <div class="modal-header">
            <h3 id="historyModalTitle">Audit History</h3>
            <button type="button" class="close-modal" onclick="closeModal('globalHistoryModal')">&times;</button>
        </div>
        <div class="modal-body" id="globalHistoryContent" style="max-height:60vh;overflow-y:auto;">
            <p style="text-align:center;padding:20px;color:var(--text-secondary);">Loading audit history...</p>
        </div>
    </div>
</div>

</div>

<script>
function toggleAdvancedSearch() {
    const panel = document.getElementById('advancedSearchPanel');
    if (panel.style.display === 'none') {
        panel.style.display = 'block';
    } else {
        panel.style.display = 'none';
    }
}

function openModal(modalId) {
    document.getElementById(modalId).classList.add('active');
}

function closeModal(modalId) {
    document.getElementById(modalId).classList.remove('active');
}

function openGlobalHistoryModal() {
    openModal('globalHistoryModal');
    document.getElementById('globalHistoryContent').innerHTML = '<p style="text-align:center;padding:20px;color:var(--text-secondary);">Loading audit history...</p>';

    fetch('<?= h($current_page); ?>?action=get_history')
        .then(res => res.text())
        .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
        .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p style="text-align:center;padding:20px;color:#991b1b;">Failed to load audit history.</p>'; });
}

function openRowHistoryModal(recordId, productName) {
    document.getElementById('historyModalTitle').innerText = 'Record History: ' + productName;
    openModal('globalHistoryModal');
    document.getElementById('globalHistoryContent').innerHTML = '<p style="text-align:center;padding:20px;color:var(--text-secondary);">Loading audit history...</p>';

    fetch('<?= h($current_page); ?>?action=get_history&id=' + recordId)
        .then(res => res.text())
        .then(html => { document.getElementById('globalHistoryContent').innerHTML = html; })
        .catch(() => { document.getElementById('globalHistoryContent').innerHTML = '<p style="text-align:center;padding:20px;color:#991b1b;">Failed to load audit history.</p>'; });
}

// Close modal when clicking outside
document.querySelectorAll('.modal-overlay').forEach(modal => {
    modal.addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal(this.id);
        }
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>