<?php

session_start();

require "config/db.php";


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('ip', 'can_view');
requirePermission('ip', 'can_delete');



$role = $_SESSION['role'] ?? 'User';

$username = $_SESSION['name'] ?? 'Unknown';



if($role!="Admin"){

    die("Permission denied");

}



$id = intval($_POST['id'] ?? 0);



if(!$id){

    header("Location:ip.php");
    exit;

}



/*
=========================================
GET RECORD BEFORE DELETE
=========================================
*/


$stmt=$pdo->prepare("

SELECT *

FROM ip_ranges

WHERE id=?

");


$stmt->execute([$id]);


$record=$stmt->fetch(PDO::FETCH_ASSOC);



if(!$record){

    header("Location:ip.php");
    exit;

}





/*
=========================================
SAVE HISTORY
=========================================
*/


$stmt=$pdo->prepare("

INSERT INTO ip_ranges_history

(
ip_range_id,
action_type,
performed_by,
details

)

VALUES
(?,?,?,?)

");



$stmt->execute([

$id,

"DELETE",

$username,

"Deleted IP Range: ".$record['ip_range'].

" | Project: ".$record['project'].

" | VLAN: ".$record['vlan']

]);







/*
=========================================
DELETE
=========================================
*/


$stmt=$pdo->prepare("

DELETE FROM ip_ranges

WHERE id=?

");


$stmt->execute([$id]);





header("Location:ip.php");

exit;


?>
