<?php
/**
 * Quick Links -- shared shortcuts to the consoles, dashboards and portals
 * a team reaches for daily.
 *
 * Each link is published at one of four scopes, using the same vocabulary
 * and the same helpers as SOPs, KB articles and known issues:
 * private ("only me"), team, teams (several), or public. Every create,
 * edit, delete and re-scope is written to quick_link_audit.
 *
 * Deliberately holds no credentials. A link that needs a password pairs
 * with a vault.php entry, which is what vault_entries.url is for.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/permission-helpers.php';

requireLogin();
requirePermission('links', 'can_view');

$canEdit   = can('links', 'can_edit');
$canDelete = can('links', 'can_delete');
$canExport = can('links', 'can_export');
$canAudit  = can('links', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));
$userId   = (int) ($_SESSION['user_id'] ?? 0);
$role     = trim((string) ($_SESSION['role'] ?? ''));
$isAdmin  = strtolower($role) === 'admin';

/* The session carries the role but not the team; visibility depends on it. */
$teamStmt = $pdo->prepare("SELECT team FROM users WHERE id = ? LIMIT 1");
$teamStmt->execute([$userId]);
$userTeam = (string) ($teamStmt->fetchColumn() ?: '');

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

const LK_MODULE = 'quick_link';

$categories = [
    'Monitoring', 'Ticketing', 'Documentation', 'Cloud Console',
    'Virtualisation', 'Storage', 'Backup', 'Network', 'Security',
    'Database', 'Patching', 'CI / CD', 'Vendor Support', 'Internal Portal',
    'Other',
];

$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development', 'All'];

$visibilities = [
    'private' => 'Only me',
    'team'    => 'My team',
    'teams'   => 'Multiple teams',
    'public'  => 'Public',
];

$allTeams = $pdo->query("SELECT team_name FROM teams ORDER BY team_name")->fetchAll(PDO::FETCH_COLUMN);

$lkFields = [
    'title'       => 'Title',
    'url'         => 'URL',
    'description' => 'Description',
    'category'    => 'Category',
    'environment' => 'Environment',
    'tags'        => 'Tags',
    'owner_team'  => 'Owner Team',
    'notes'       => 'Notes',
];


/* ---------------- URL SAFETY ---------------- */

/**
 * Schemes allowed in a stored link.
 *
 * This is a whitelist rather than a blacklist because the stored value is
 * rendered into an href: `javascript:` and `data:` URLs would execute in
 * the clicking user's session, turning a shared bookmark list into stored
 * XSS. The infrastructure schemes are here because this is an ops tool and
 * an rdp:// or ssh:// shortcut is a legitimate thing to want.
 */
const LK_SCHEMES = ['http', 'https', 'ssh', 'rdp', 'vnc', 'ftp', 'ftps', 'sftp', 'telnet'];

function lkNormaliseUrl(string $raw): array
{
    $url = trim($raw);
    if ($url === '') {
        return [null, 'URL is required.'];
    }

    // A bare host is what people paste most often; assume https rather
    // than rejecting it, but only when there is no scheme at all.
    if (!preg_match('~^[a-zA-Z][a-zA-Z0-9+.\-]*:~', $url)) {
        $url = 'https://' . $url;
    }

    $scheme = strtolower((string) parse_url($url, PHP_URL_SCHEME));

    if ($scheme === '' || !in_array($scheme, LK_SCHEMES, true)) {
        return [null, 'Only these link types are allowed: ' . implode(', ', LK_SCHEMES) . '.'];
    }

    if (parse_url($url, PHP_URL_HOST) === null) {
        return [null, 'That URL has no host part -- check it and try again.'];
    }

    return [$url, null];
}

/** Host shown under the title, so a link is recognisable at a glance. */
function lkHost(string $url): string
{
    $h = parse_url($url, PHP_URL_HOST);
    return is_string($h) ? $h : $url;
}


/* ---------------- VISIBILITY ---------------- */

/**
 * Rows this user may see, with their shared teams already attached.
 *
 * Filtered in SQL rather than by fetching everything and discarding in
 * PHP: a private link must never travel to a browser that has no right to
 * it, and "filter it out in the template" is how that goes wrong.
 */
function lkVisibleWhere(bool $isAdmin, int $userId, string $userTeam): array
{
    if ($isAdmin) {
        return ['1=1', []];
    }

    $sql = "(
        l.visibility = 'public'
        OR l.created_by_id = ?
        OR (l.visibility = 'team'  AND l.owner_team <> '' AND l.owner_team = ?)
        OR (l.visibility = 'teams' AND EXISTS (
                SELECT 1 FROM quick_link_teams t
                WHERE t.quick_link_id = l.id AND t.team_name = ?
        ))
    )";

    return [$sql, [$userId, $userTeam, $userTeam]];
}

/**
 * Loads a link only if this user is allowed to see it, returning null
 * otherwise.
 *
 * Every write path goes through this rather than a bare SELECT by id.
 * Checking "can this user edit?" against a row fetched by id alone is not
 * enough: the id is the only thing an attacker needs to supply, so a row
 * they may not even read would otherwise be editable and deletable by
 * guessing its number.
 */
function lkLoadVisible(PDO $pdo, int $id, bool $isAdmin, int $userId, string $userTeam): ?array
{
    [$visSql, $visParams] = lkVisibleWhere($isAdmin, $userId, $userTeam);

    $stmt = $pdo->prepare("SELECT l.* FROM quick_links l WHERE l.id = ? AND $visSql");
    $stmt->execute([$id, ...$visParams]);

    return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
}

/**
 * True when this user may modify a row they can already see.
 *
 * Visibility is the caller's job (lkLoadVisible); this adds the ownership
 * rule on top of it.
 */
function lkCanModify(array $link, bool $isAdmin, int $userId, bool $canEdit): bool
{
    if ($isAdmin) { return true; }
    if (!$canEdit) { return false; }

    // A private link belongs to its author alone; everything else the
    // user can see and has can_edit for is fair game, matching how the
    // other shared modules behave.
    if ((string) $link['visibility'] === 'private') {
        return (int) $link['created_by_id'] === $userId;
    }

    return true;
}


/* ---------------- AJAX ---------------- */

if (($_GET['action'] ?? '') === 'audit') {
    requirePermission('links', 'can_audit');

    $id = (int) ($_GET['id'] ?? 0);

    // Audit is still scoped: the trail names who used a link, which is not
    // something to hand out for a record the reader cannot otherwise see.
    [$visSql, $visParams] = lkVisibleWhere($isAdmin, $userId, $userTeam);

    if ($id > 0) {
        $chk = $pdo->prepare("SELECT COUNT(*) FROM quick_links l WHERE l.id = ? AND $visSql");
        $chk->execute([$id, ...$visParams]);

        if (!$chk->fetchColumn()) {
            http_response_code(403);
            exit('<p class="plat-empty">You do not have access to this link.</p>');
        }

        $rows = getItemAuditTrail($pdo, LK_MODULE, $id);
        $empty = 'No audit entries for this link yet.';
    } else {
        /*
         * Whole-module view. Non-admins see only entries for links they
         * can currently see -- which necessarily drops entries for deleted
         * links, since there is no row left to test visibility against.
         * Admins see everything, including those deletions, because "who
         * removed that link" is exactly what the trail is kept for.
         */
        if ($isAdmin) {
            $sql = "SELECT a.* FROM quick_link_audit a ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = [];
        } else {
            $sql = "SELECT a.* FROM quick_link_audit a
                    JOIN quick_links l ON l.id = a.quick_link_id
                    WHERE $visSql
                    ORDER BY a.action_date DESC, a.id DESC LIMIT 300";
            $bind = $visParams;
        }

        $st = $pdo->prepare($sql);
        $st->execute($bind);
        $rows = $st->fetchAll(PDO::FETCH_ASSOC);
        $empty = 'No audit entries recorded yet.';
    }

    if (!$rows) {
        echo '<p class="plat-empty">' . $empty . '</p>';
        exit;
    }

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>When</th><th>Action</th><th>By</th><th>Details</th>'
       . '</tr></thead><tbody>';

    foreach ($rows as $r) {
        $detail = '';
        if (!empty($r['details'])) {
            $decoded = json_decode((string) $r['details'], true);
            $detail = is_array($decoded)
                ? implode('<br>', array_map(
                    fn($k, $v) => '<strong>' . plat_h($k) . ':</strong> ' . plat_h(is_scalar($v) ? (string) $v : json_encode($v)),
                    array_keys($decoded),
                    $decoded
                ))
                : plat_h((string) $r['details']);
        }

        echo '<tr>'
           . '<td>' . plat_h($r['action_date'] ?? '') . '</td>'
           . '<td><span class="plat-pill neutral">' . plat_h($r['action'] ?? '') . '</span></td>'
           . '<td>' . plat_h($r['user_name'] ?? '') . '</td>'
           . '<td>' . ($detail ?: '—') . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/* ---------------- FILTERS ---------------- */

$q       = trim((string) ($_GET['q'] ?? ''));
$fCat    = trim((string) ($_GET['f_cat'] ?? ''));
$fEnv    = trim((string) ($_GET['f_env'] ?? ''));
$fVis    = trim((string) ($_GET['f_vis'] ?? ''));

[$visSql, $visParams] = lkVisibleWhere($isAdmin, $userId, $userTeam);

$where  = [$visSql];
$params = $visParams;

if ($q !== '') {
    $where[] = '(l.title LIKE ? OR l.url LIKE ? OR l.description LIKE ? OR l.tags LIKE ? OR l.category LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fCat !== '') { $where[] = 'l.category = ?';    $params[] = $fCat; }
if ($fEnv !== '') { $where[] = 'l.environment = ?'; $params[] = $fEnv; }
if ($fVis !== '') { $where[] = 'l.visibility = ?';  $params[] = $fVis; }

$whereSql = implode(' AND ', $where);


/* ---------------- EXPORT ---------------- */

if (($_GET['action'] ?? '') === 'export') {
    requirePermission('links', 'can_export');

    $stmt = $pdo->prepare("SELECT l.* FROM quick_links l WHERE $whereSql ORDER BY l.title");
    $stmt->execute($params);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="quick_links_' . date('Ymd_His') . '.csv"');

    $out = fopen('php://output', 'w');
    fputcsv($out, [...array_values($lkFields), 'Visibility', 'Shared Teams', 'Pinned', 'Created By']);

    foreach ($stmt as $r) {
        $shared = $r['visibility'] === 'teams'
            ? implode(' | ', getSharedTeams($pdo, LK_MODULE, (int) $r['id']))
            : '';

        fputcsv($out, [
            ...array_map(fn($c) => $r[$c] ?? '', array_keys($lkFields)),
            $r['visibility'],
            $shared,
            $r['is_pinned'] ? 'Yes' : 'No',
            $r['created_by'],
        ]);
    }

    fclose($out);
    exit;
}


/* ---------------- WRITES ---------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('links', 'can_edit');

        $id   = (int) ($_POST['id'] ?? 0);
        $data = [];
        foreach (array_keys($lkFields) as $col) {
            $data[$col] = trim((string) ($_POST[$col] ?? ''));
        }

        $visibility = (string) ($_POST['visibility'] ?? 'public');
        if (!isset($visibilities[$visibility])) {
            $visibility = 'public';
        }

        $sharedTeams = array_values(array_filter(array_map(
            'trim',
            (array) ($_POST['shared_teams'] ?? [])
        ), fn($t) => $t !== ''));

        // A team the user invented is not a team; only real ones are stored.
        $sharedTeams = array_values(array_intersect($sharedTeams, $allTeams));

        $isPinned = !empty($_POST['is_pinned']) ? 1 : 0;

        [$url, $urlErr] = lkNormaliseUrl($data['url']);
        $data['url'] = $url ?? $data['url'];

        // 'team' scope means the author's own team; storing it explicitly
        // keeps the row readable if the author later changes team.
        $data['owner_team'] = $visibility === 'team' ? $userTeam : '';

        if ($data['title'] === '') {
            $err = 'Title is required.';
        } elseif ($urlErr !== null) {
            $err = $urlErr;
        } elseif ($visibility === 'team' && $userTeam === '') {
            $err = 'You are not assigned to a team, so "My team" cannot be used. Ask an administrator to set your team.';
        } elseif ($visibility === 'teams' && !$sharedTeams) {
            $err = 'Choose at least one team to share with.';
        } else {
            try {
                $pdo->beginTransaction();

                if ($id > 0) {
                    $old = lkLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

                    // Same message whether the link is missing or merely
                    // out of scope -- distinguishing them would confirm
                    // that a given id exists to someone who cannot see it.
                    if (!$old || !lkCanModify($old, $isAdmin, $userId, $canEdit)) {
                        throw new RuntimeException('That link does not exist, or you cannot edit it.');
                    }

                    $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($data)));
                    $pdo->prepare("
                        UPDATE quick_links
                        SET $set, is_pinned = ?, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                        WHERE id = ?
                    ")->execute([...array_values($data), $isPinned, $username, $id]);

                    $action  = 'UPDATED';
                    $details = ['Link' => $data['title']];

                    if ((string) $old['visibility'] !== $visibility) {
                        $details['Visibility'] =
                            ($visibilities[$old['visibility']] ?? $old['visibility'])
                            . ' → ' . $visibilities[$visibility];
                    }
                } else {
                    $cols = implode(', ', array_keys($data));
                    $ph   = implode(', ', array_fill(0, count($data), '?'));

                    $pdo->prepare("
                        INSERT INTO quick_links ($cols, is_pinned, visibility, created_by, created_by_id)
                        VALUES ($ph, ?, ?, ?, ?)
                    ")->execute([...array_values($data), $isPinned, $visibility, $username, $userId]);

                    $id      = (int) $pdo->lastInsertId();
                    $action  = 'CREATED';
                    $details = ['Link' => $data['title'], 'Visibility' => $visibilities[$visibility]];
                }

                $pdo->commit();

                // saveItemSharing opens its own transaction, so it has to
                // run after the commit above rather than nested inside it.
                // Its return value is checked: it reports failure rather
                // than throwing, and an unreported failure here means the
                // row keeps its old visibility while the user is told the
                // save succeeded -- which for a private link means it stays
                // readable by people it was just hidden from.
                if (!saveItemSharing($pdo, LK_MODULE, $id, $visibility, $sharedTeams)) {
                    throw new RuntimeException(
                        'the link was saved but its visibility could not be applied; it still has its previous scope'
                    );
                }

                if ($visibility === 'teams' && $sharedTeams) {
                    $details['Shared with'] = implode(', ', $sharedTeams);
                }

                logItemAction($pdo, LK_MODULE, $id, $action, $userId, $username, $details);
                $msg = $action === 'CREATED' ? 'Link added.' : 'Link updated.';

            } catch (Throwable $e) {
                if ($pdo->inTransaction()) { $pdo->rollBack(); }
                $err = 'Unable to save: ' . $e->getMessage();
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('links', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);

        $link = lkLoadVisible($pdo, $id, $isAdmin, $userId, $userTeam);

        if (!$link || !lkCanModify($link, $isAdmin, $userId, $canEdit)) {
            $err = 'That link does not exist, or you cannot delete it.';
        } else {
            // Foreign keys are off app-wide, so ON DELETE CASCADE on
            // quick_link_teams does not fire -- clear the children here.
            $pdo->prepare("DELETE FROM quick_link_teams WHERE quick_link_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM quick_links WHERE id = ?")->execute([$id]);

            // The audit rows deliberately outlive the link: "who deleted
            // that bookmark, and when" is the question audit exists for.
            logItemAction($pdo, LK_MODULE, $id, 'DELETED', $userId, $username, ['Link' => $link['title']]);
            $msg = 'Link deleted.';
        }
    }
}


/* ---------------- DATA ---------------- */

$stmt = $pdo->prepare("
    SELECT l.* FROM quick_links l
    WHERE $whereSql
    ORDER BY l.is_pinned DESC, l.category, l.sort_order, l.title
");
$stmt->execute($params);
$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

/* Shared-team lists for every visible row, in one query rather than N. */
$sharedByLink = [];
if ($links) {
    $ids = array_column($links, 'id');
    $in  = implode(',', array_fill(0, count($ids), '?'));
    $ts  = $pdo->prepare("SELECT quick_link_id, team_name FROM quick_link_teams WHERE quick_link_id IN ($in) ORDER BY team_name");
    $ts->execute($ids);
    foreach ($ts as $r) {
        $sharedByLink[(int) $r['quick_link_id']][] = $r['team_name'];
    }
}

/* Grouped by category for the card view; pinned lifted into their own group. */
$pinned  = [];
$grouped = [];
foreach ($links as $l) {
    if ((int) $l['is_pinned']) {
        $pinned[] = $l;
    } else {
        $grouped[$l['category'] ?: 'Uncategorised'][] = $l;
    }
}
ksort($grouped);

$countAll     = count($links);
$countPinned  = count($pinned);
$countPrivate = count(array_filter($links, fn($l) => $l['visibility'] === 'private'));
$countShared  = count(array_filter($links, fn($l) => in_array($l['visibility'], ['team', 'teams'], true)));

$page_title = 'Quick Links | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>

<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🔗</div>
            <div>
                <h1>Quick Links</h1>
                <p>Shared shortcuts to the consoles, dashboards and portals your team uses.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="lkOpen(null)">+ Add Link</button>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <a class="plat-btn plat-btn-light" href="?action=export&amp;q=<?= urlencode($q) ?>&amp;f_cat=<?= urlencode($fCat) ?>&amp;f_env=<?= urlencode($fEnv) ?>&amp;f_vis=<?= urlencode($fVis) ?>">Export CSV</a>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <?php /* id 0 = the whole module, matching the other pages'
                         header History button. */ ?>
                <button type="button" class="plat-btn" onclick="lkAudit(0)">History</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $countAll ?></b><span>Visible to you</span></div>
        <div class="plat-stat"><b><?= $countPinned ?></b><span>Pinned</span></div>
        <div class="plat-stat"><b><?= $countShared ?></b><span>Team shared</span></div>
        <div class="plat-stat tone-warn"><b><?= $countPrivate ?></b><span>Only me</span></div>
    </div>

    <form method="get" class="plat-filters" style="margin-bottom:18px;">
        <div class="plat-field">
            <label>Search</label>
            <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Title, URL, tag…" style="min-width:220px;">
        </div>
        <div class="plat-field">
            <label>Category</label>
            <select name="f_cat">
                <option value="">All</option>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= plat_h($c) ?>" <?= $fCat === $c ? 'selected' : '' ?>><?= plat_h($c) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="plat-field">
            <label>Environment</label>
            <select name="f_env">
                <option value="">All</option>
                <?php foreach ($environments as $e): ?>
                    <option value="<?= plat_h($e) ?>" <?= $fEnv === $e ? 'selected' : '' ?>><?= plat_h($e) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="plat-field">
            <label>Visibility</label>
            <select name="f_vis">
                <option value="">All</option>
                <?php foreach ($visibilities as $k => $v): ?>
                    <option value="<?= plat_h($k) ?>" <?= $fVis === $k ? 'selected' : '' ?>><?= plat_h($v) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <button type="submit" class="plat-btn plat-btn-primary">Filter</button>
        <a class="plat-btn plat-btn-light" href="links.php">Reset</a>
    </form>

    <?php if (!$links): ?>
        <p class="plat-empty">No links match. <?= $canEdit ? 'Add the first one with “Add Link”.' : '' ?></p>
    <?php endif; ?>

    <?php
    /* Renders one card. Declared inline because it closes over the
       per-user permission flags computed above. */
    $renderCard = function (array $l) use ($sharedByLink, $visibilities, $isAdmin, $userId, $canEdit, $canDelete, $canAudit) {
        $id     = (int) $l['id'];
        $vis    = (string) $l['visibility'];
        $shared = $sharedByLink[$id] ?? [];
        $mine   = (int) $l['created_by_id'] === $userId;
        $modify = lkCanModify($l, $isAdmin, $userId, $canEdit);
        ?>
        <div class="lk-card">
            <div class="lk-card-top">
                <a class="lk-title" href="<?= plat_h($l['url']) ?>" target="_blank" rel="noopener noreferrer">
                    <?= plat_h($l['title']) ?>
                    <span class="lk-ext" aria-hidden="true">&#8599;</span>
                </a>
                <?php if ((int) $l['is_pinned']): ?><span class="lk-pin" title="Pinned">★</span><?php endif; ?>
            </div>

            <div class="lk-host"><?= plat_h(lkHost($l['url'])) ?></div>

            <?php if (trim((string) $l['description']) !== ''): ?>
                <p class="lk-desc"><?= plat_h($l['description']) ?></p>
            <?php endif; ?>

            <div class="lk-meta">
                <span class="lk-vis vis-<?= plat_h($vis) ?>" title="<?= $vis === 'teams'
                    ? 'Shared with: ' . plat_h(implode(', ', $shared))
                    : ($vis === 'team' ? 'Team: ' . plat_h($l['owner_team']) : plat_h($visibilities[$vis] ?? $vis)) ?>">
                    <?= plat_h($visibilities[$vis] ?? $vis) ?>
                    <?php if ($vis === 'teams' && $shared): ?> (<?= count($shared) ?>)<?php endif; ?>
                </span>
                <?php if ($l['environment']): ?><span class="plat-pill neutral"><?= plat_h($l['environment']) ?></span><?php endif; ?>
                <?php if ($mine): ?><span class="lk-mine">yours</span><?php endif; ?>
            </div>

            <?php if (trim((string) $l['tags']) !== ''): ?>
                <div class="lk-tags">
                    <?php foreach (array_slice(platformSplitHosts($l['tags']), 0, 6) as $t): ?>
                        <span class="lk-tag"><?= plat_h($t) ?></span>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

            <div class="lk-actions">
                <button type="button" class="plat-icon-btn plat-icon-view" title="Copy URL"
                    onclick='lkCopy(<?= json_encode($l["url"], JSON_HEX_APOS | JSON_HEX_QUOT) ?>, this)'>⧉</button>
                <?php if ($modify): ?>
                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                        onclick='lkOpen(<?= json_encode($l + ["shared_teams" => $shared], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                <?php endif; ?>
                <?php if ($canAudit): ?>
                    <button type="button" class="plat-icon-btn plat-icon-hist" title="Audit trail"
                        onclick="lkAudit(<?= $id ?>)">⏱</button>
                <?php endif; ?>
                <?php if ($canDelete && $modify): ?>
                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                        onclick='lkDelete(<?= $id ?>, <?= json_encode($l["title"], JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>🗑</button>
                <?php endif; ?>
            </div>
        </div>
        <?php
    };
    ?>

    <?php if ($pinned): ?>
        <div class="lk-group-title">★ Pinned</div>
        <div class="lk-grid">
            <?php foreach ($pinned as $l) { $renderCard($l); } ?>
        </div>
    <?php endif; ?>

    <?php foreach ($grouped as $cat => $rows): ?>
        <div class="lk-group-title"><?= plat_h($cat) ?> <span class="lk-group-n"><?= count($rows) ?></span></div>
        <div class="lk-grid">
            <?php foreach ($rows as $l) { $renderCard($l); } ?>
        </div>
    <?php endforeach; ?>

</div>


<?php if ($canEdit): ?>
<div class="plat-modal" id="lkModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="lkTitle">New Link</h2>
            <button type="button" class="plat-close" onclick="platClose('lkModal')">&times;</button>
        </div>

        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="lk_id">

            <div class="plat-form-grid cols-2">

                <div class="plat-field full"><label>Title *</label>
                    <input type="text" name="title" id="lk_title" required placeholder="vCenter — Production"></div>

                <div class="plat-field full"><label>URL *</label>
                    <input type="text" name="url" id="lk_url" required placeholder="https://vcenter.example.gov.sa">
                    <span class="lk-hint">A bare hostname becomes https://. Allowed: <?= plat_h(implode(', ', LK_SCHEMES)) ?>.</span>
                </div>

                <div class="plat-field full"><label>Description</label>
                    <textarea name="description" id="lk_description" rows="2" placeholder="What is this link for?"></textarea></div>

                <div class="plat-field"><label>Category</label>
                    <select name="category" id="lk_category">
                        <option value="">—</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>"><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="lk_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field full"><label>Tags</label>
                    <input type="text" name="tags" id="lk_tags" placeholder="comma separated"></div>

                <div class="plat-section-title">Publish to</div>

                <div class="plat-field full">
                    <div class="lk-vis-opts">
                        <?php foreach ($visibilities as $k => $label): ?>
                            <label class="lk-vis-opt">
                                <input type="radio" name="visibility" value="<?= plat_h($k) ?>"
                                       <?= $k === 'public' ? 'checked' : '' ?> onchange="lkVisChanged()">
                                <span><?= plat_h($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <span class="lk-hint" id="lk_vis_hint"></span>
                </div>

                <div class="plat-field full" id="lk_teams_wrap" style="display:none;">
                    <label>Share with teams</label>
                    <div class="lk-team-list">
                        <?php foreach ($allTeams as $t): ?>
                            <label class="lk-team">
                                <input type="checkbox" name="shared_teams[]" value="<?= plat_h($t) ?>">
                                <span><?= plat_h($t) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="plat-field full">
                    <label class="lk-check">
                        <input type="checkbox" name="is_pinned" id="lk_is_pinned" value="1">
                        <span>Pin to the top</span>
                    </label>
                </div>

                <div class="plat-field full"><label>Notes</label>
                    <textarea name="notes" id="lk_notes" rows="2"></textarea></div>

            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('lkModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-primary">Save Link</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="lkDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete Link</h2>
            <button type="button" class="plat-close" onclick="platClose('lkDelModal')">&times;</button></div>
        <form method="post">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="lkDelId">
            <p>Delete <strong id="lkDelName"></strong>? The audit trail is kept.</p>
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('lkDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>

<div class="plat-modal" id="lkAuditModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="lkAuditTitle">Audit Trail</h2>
            <button type="button" class="plat-close" onclick="platClose('lkAuditModal')">&times;</button></div>
        <div id="lkAuditBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<style>
.lk-group-title {
    margin: 22px 0 10px;
    font-size: 13px;
    font-weight: 700;
    letter-spacing: .04em;
    text-transform: uppercase;
    color: var(--text-secondary);
    display: flex;
    align-items: center;
    gap: 8px;
}
.lk-group-n {
    font-weight: 600;
    font-size: 11px;
    color: var(--text-muted);
    background: var(--border-light);
    border-radius: 999px;
    padding: 1px 7px;
}

.lk-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(265px, 1fr));
    gap: 12px;
}

.lk-card {
    display: flex;
    flex-direction: column;
    gap: 6px;
    padding: 14px;
    border: 1px solid var(--border-color);
    border-radius: 12px;
    background: var(--card-bg, #fff);
    transition: border-color .15s, box-shadow .15s;
}
.lk-card:hover {
    border-color: var(--accent);
    box-shadow: 0 4px 14px rgba(15, 23, 42, .08);
}

.lk-card-top { display: flex; align-items: flex-start; gap: 6px; }

.lk-title {
    flex: 1;
    font-weight: 650;
    font-size: 14.5px;
    color: var(--text-primary);
    text-decoration: none;
    line-height: 1.3;
}
.lk-title:hover { color: var(--accent); text-decoration: underline; }
.lk-ext { font-size: 11px; opacity: .55; }
.lk-pin { color: #B45309; font-size: 13px; }

.lk-host {
    font-size: 11.5px;
    color: var(--text-muted);
    font-family: ui-monospace, Menlo, Consolas, monospace;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.lk-desc {
    margin: 2px 0 0;
    font-size: 12.5px;
    line-height: 1.45;
    color: var(--text-secondary);
}

.lk-meta { display: flex; flex-wrap: wrap; gap: 5px; align-items: center; margin-top: 2px; }

.lk-vis {
    font-size: 10.5px;
    font-weight: 700;
    padding: 2px 8px;
    border-radius: 999px;
    color: #fff;
    letter-spacing: .02em;
}
/* Four distinct scopes -- the badge is the only thing telling a reader
   whether a link is theirs alone or visible estate-wide. */
.lk-vis.vis-private { background: #B42318; }
.lk-vis.vis-team    { background: #0369A1; }
.lk-vis.vis-teams   { background: #6D28D9; }
.lk-vis.vis-public  { background: #0D9488; }

.lk-mine {
    font-size: 10.5px;
    font-weight: 600;
    color: var(--text-muted);
    border: 1px dashed var(--border-color);
    border-radius: 999px;
    padding: 1px 7px;
}

.lk-tags { display: flex; flex-wrap: wrap; gap: 4px; }
.lk-tag {
    font-size: 10.5px;
    padding: 1px 7px;
    border-radius: 5px;
    background: var(--border-light);
    color: var(--text-secondary);
}

.lk-actions {
    display: flex;
    gap: 4px;
    margin-top: auto;
    padding-top: 8px;
}

.lk-hint { font-size: 11.5px; color: var(--text-muted); }

.lk-vis-opts { display: flex; flex-wrap: wrap; gap: 8px; }
.lk-vis-opt {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 7px 12px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
    cursor: pointer;
    font-size: 13px;
}
.lk-vis-opt:has(input:checked) {
    border-color: var(--accent);
    background: var(--focus-ring, rgba(67, 56, 202, .08));
    font-weight: 600;
}

.lk-team-list {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(165px, 1fr));
    gap: 6px;
    max-height: 175px;
    overflow-y: auto;
    padding: 9px;
    border: 1px solid var(--border-color);
    border-radius: 9px;
}
.lk-team, .lk-check {
    display: flex;
    align-items: center;
    gap: 7px;
    font-size: 13px;
    cursor: pointer;
}

[data-theme="dark"] .lk-card { background: rgba(255, 255, 255, .03); }
[data-theme="dark"] .lk-card:hover { box-shadow: 0 4px 14px rgba(0, 0, 0, .35); }
</style>

<script>
const LK_VIS_HINT = {
    private: 'Only you (and administrators) can see this link.',
    team:    <?= json_encode($userTeam !== ''
                 ? 'Everyone in ' . $userTeam . ' can see this link.'
                 : 'You are not assigned to a team — ask an administrator first.') ?>,
    teams:   'Only the teams you tick below can see this link.',
    public:  'Everyone who can open this page can see this link.'
};

/* Modal show/hide. Defined per page across this codebase -- there is no
   shared platform.js, and platform.css only supplies the .show rule. */
function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

function lkEsc(s) {
    return String(s ?? '').replace(/[&<>"']/g, c =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

function lkVisChecked() {
    const el = document.querySelector('input[name="visibility"]:checked');
    return el ? el.value : 'public';
}

function lkVisChanged() {
    // The editor markup only exists for users with can_edit, but this runs
    // on DOMContentLoaded for everyone -- without the guards a view-only
    // user takes a TypeError on every page load.
    const wrap = document.getElementById('lk_teams_wrap');
    const hint = document.getElementById('lk_vis_hint');
    if (!wrap || !hint) return;

    const v = lkVisChecked();
    wrap.style.display = v === 'teams' ? '' : 'none';
    hint.textContent = LK_VIS_HINT[v] || '';
}

function lkOpen(data) {
    const editing = !!data;
    document.getElementById('lkTitle').innerText = editing ? 'Edit Link' : 'New Link';
    document.getElementById('lk_id').value = editing ? data.id : '';

    ['title', 'url', 'description', 'category', 'environment', 'tags', 'notes'].forEach(f => {
        const el = document.getElementById('lk_' + f);
        if (el) el.value = editing ? (data[f] ?? '') : '';
    });

    document.getElementById('lk_is_pinned').checked = editing && Number(data.is_pinned) === 1;

    const vis = editing ? (data.visibility || 'public') : 'public';
    const radio = document.querySelector(`input[name="visibility"][value="${vis}"]`);
    if (radio) radio.checked = true;

    const shared = (editing && Array.isArray(data.shared_teams)) ? data.shared_teams : [];
    document.querySelectorAll('input[name="shared_teams[]"]').forEach(cb => {
        cb.checked = shared.includes(cb.value);
    });

    lkVisChanged();
    platOpen('lkModal');
}

function lkDelete(id, name) {
    document.getElementById('lkDelId').value = id;
    document.getElementById('lkDelName').innerText = name;
    platOpen('lkDelModal');
}

function lkAudit(id) {
    document.getElementById('lkAuditTitle').innerText =
        id ? 'Audit Trail — link #' + id : 'Audit Trail — all links';
    document.getElementById('lkAuditBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('lkAuditModal');
    fetch('links.php?action=audit&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('lkAuditBody').innerHTML = h; })
        .catch(() => {
            document.getElementById('lkAuditBody').innerHTML = '<p class="plat-empty">Failed to load.</p>';
        });
}

function lkCopy(url, btn) {
    const done = () => {
        const was = btn.innerHTML;
        btn.innerHTML = '✓';
        setTimeout(() => { btn.innerHTML = was; }, 1100);
    };

    // navigator.clipboard needs a secure context; this app is often reached
    // over plain HTTP internally, so fall back rather than silently failing.
    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(url).then(done).catch(() => lkCopyFallback(url, done));
    } else {
        lkCopyFallback(url, done);
    }
}

function lkCopyFallback(url, done) {
    const ta = document.createElement('textarea');
    ta.value = url;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); } catch (e) { /* nothing else to try */ }
    document.body.removeChild(ta);
}

document.addEventListener('DOMContentLoaded', lkVisChanged);
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
