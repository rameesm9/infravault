<?php

require_once 'config/db.php';
require_once 'includes/permission-helpers.php';
require_once 'includes/pagination-helpers.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (!isset($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

$current_user_id = (int) $_SESSION['user_id'];
$role = trim($_SESSION['role'] ?? '');

// Get user info for audit logging
$user_stmt = $pdo->prepare("SELECT first_name, ncgr_id, email, team FROM users WHERE id = ?");
$user_stmt->execute([$current_user_id]);
$user_info = $user_stmt->fetch(PDO::FETCH_ASSOC);
$username = ($user_info && !empty($user_info['first_name']))
    ? $user_info['first_name'] . ' (' . ($user_info['ncgr_id'] ?? 'N/A') . ')'
    : ($user_info['email'] ?? 'Unknown User');
$user_team = $user_info['team'] ?? '';
$is_admin = strtolower($role) === 'admin';

/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
*/

function knownIssuesHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'known_issues', $permission);
}

$canView   = knownIssuesHasPermission($pdo, $role, 'can_view');
$canEdit   = knownIssuesHasPermission($pdo, $role, 'can_edit');
$canDelete = knownIssuesHasPermission($pdo, $role, 'can_delete');
$canExport = knownIssuesHasPermission($pdo, $role, 'can_export');
$canImport = knownIssuesHasPermission($pdo, $role, 'can_import');
$canAudit  = knownIssuesHasPermission($pdo, $role, 'can_audit');

if (!$canView) {
    http_response_code(403);
    exit('You do not have permission to view this page.');
}

/*
|--------------------------------------------------------------------------
| Helpers
|--------------------------------------------------------------------------
*/

function h($value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function ki_slug(string $value): string
{
    return strtolower(str_replace(' ', '-', trim($value)));
}

function ki_generate_issue_number(PDO $pdo): string
{
    $last = $pdo->query("SELECT issue_number FROM known_issues ORDER BY id DESC LIMIT 1")->fetchColumn();
    if (!$last || !preg_match('/(\d+)$/', $last, $m)) {
        return 'KI-001';
    }
    return 'KI-' . str_pad((int)$m[1] + 1, 3, '0', STR_PAD_LEFT);
}

const KI_VALID_SEVERITIES = ['Critical', 'High', 'Medium', 'Low'];
const KI_VALID_STATUSES = ['Open', 'In Progress', 'Resolved', 'Closed'];
const KI_VALID_VISIBILITY = ['public', 'team', 'teams'];

function ki_can_view(PDO $pdo, array $issue, int $user_id, string $role, string $user_team, bool $bypass): bool
{
    if ($bypass) {
        return true;
    }
    $sharedTeams = getSharedTeams($pdo, 'known_issue', (int) $issue['id']);
    $access = getItemAccessLevel(
        $pdo, $user_id, $role, $user_team,
        (int) $issue['owner_id'], $issue['team_scoped_visibility'] ?? 'public', $issue['owner_team'] ?? '',
        $sharedTeams, 'known_issue'
    );
    return $access !== 'none';
}

/*
|--------------------------------------------------------------------------
| CSV EXPORT
|--------------------------------------------------------------------------
*/

if (isset($_GET['action']) && $_GET['action'] === 'export') {
    if (!$canExport) {
        http_response_code(403);
        exit('You do not have permission to export issues.');
    }

    $export_where_clauses = ['1=1'];
    $export_params = [];

    $keyword = trim($_GET['keyword'] ?? '');
    $s_severity = trim($_GET['s_severity'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');

    if (!empty($keyword)) {
        $export_where_clauses[] = "(issue_number LIKE ? OR title LIKE ?)";
        array_push($export_params, "%$keyword%", "%$keyword%");
    }
    if (!empty($s_severity)) {
        $export_where_clauses[] = "severity = ?";
        $export_params[] = "$s_severity";
    }
    if (!empty($s_status)) {
        $export_where_clauses[] = "status = ?";
        $export_params[] = "$s_status";
    }

    $export_where_sql = implode(" AND ", $export_where_clauses);

    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=known_issues_export_' . date('Y-m-d_H-i-s') . '.csv');
    header('Pragma: no-cache');
    header('Expires: 0');

    $output = fopen('php://output', 'w');
    fputcsv($output, ['Issue Number', 'Title', 'Category', 'Severity', 'Status', 'Affected System', 'Created At']);

    $stmt = $pdo->prepare("
        SELECT issue_number, title, category, severity, status, affected_system, created_at
        FROM known_issues
        WHERE $export_where_sql
        ORDER BY issue_number ASC
    ");
    $stmt->execute($export_params);

    while (($row = $stmt->fetch(PDO::FETCH_ASSOC)) !== false) {
        fputcsv($output, [
            $row['issue_number'], $row['title'], $row['category'] ?? '',
            $row['severity'], $row['status'], $row['affected_system'] ?? '', $row['created_at']
        ]);
    }
    fclose($output);
    exit;
}

/*
|--------------------------------------------------------------------------
| Handle Delete
|--------------------------------------------------------------------------
*/

$msg = $_SESSION['ki_msg'] ?? "";
$error = $_SESSION['ki_error'] ?? "";
unset($_SESSION['ki_msg'], $_SESSION['ki_error']);
$form_values = $_SESSION['ki_form'] ?? null;
unset($_SESSION['ki_form']);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    if (!$canDelete) {
        $error = "You do not have permission to delete issues.";
    } else {
        $issue_id = (int)($_POST['issue_id'] ?? 0);
        if ($issue_id > 0) {
            $stmt = $pdo->prepare("DELETE FROM known_issues WHERE id = ?");
            $stmt->execute([$issue_id]);
            logItemAction($pdo, 'known_issue', $issue_id, 'DELETED', $current_user_id, $username);
            $msg = "Issue deleted successfully.";
        }
    }
}

/*
|--------------------------------------------------------------------------
| Handle Create / Update
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && in_array($_POST['action'], ['create', 'update'], true)) {
    if (!$canEdit) {
        $_SESSION['ki_error'] = "You do not have permission to save issues.";
        header('Location: known-issues.php');
        exit;
    }

    $is_create = $_POST['action'] === 'create';
    $issue_id = (int)($_POST['issue_id'] ?? 0);

    $title = trim($_POST['title'] ?? '');
    $summary = trim($_POST['description'] ?? '');
    $category = trim($_POST['category'] ?? '');
    $severity = trim($_POST['severity'] ?? '');
    $status = trim($_POST['status'] ?? '');
    $affected_team = trim($_POST['affected_team'] ?? '') ?: null;
    $affected_system = trim($_POST['affected_system'] ?? '') ?: null;
    $environment = trim($_POST['environment'] ?? '') ?: null;
    $symptoms = trim($_POST['symptoms'] ?? '') ?: null;
    $cause = trim($_POST['cause'] ?? '') ?: null;
    $workaround = trim($_POST['workaround'] ?? '') ?: null;
    $resolution = trim($_POST['resolution'] ?? '') ?: null;
    $notes = trim($_POST['notes'] ?? '') ?: null;

    $visibility = trim($_POST['visibility'] ?? 'public');
    if (!in_array($visibility, KI_VALID_VISIBILITY, true)) {
        $visibility = 'public';
    }
    $shared_teams = isset($_POST['shared_teams'])
        ? array_filter(explode(',', trim($_POST['shared_teams'])))
        : [];

    $formErrors = [];
    if ($title === '') $formErrors[] = 'Title is required.';
    if ($summary === '') $formErrors[] = 'Summary is required.';
    if ($category === '') $formErrors[] = 'Category is required.';
    if (!in_array($severity, KI_VALID_SEVERITIES, true)) $formErrors[] = 'A valid severity is required.';
    if (!in_array($status, KI_VALID_STATUSES, true)) $formErrors[] = 'A valid status is required.';
    if (!$is_create && $issue_id <= 0) $formErrors[] = 'Invalid issue.';

    if ($formErrors) {
        $_SESSION['ki_error'] = implode(' ', $formErrors);
        $_SESSION['ki_form'] = $_POST;
        header('Location: known-issues.php?action=' . ($is_create ? 'create' : 'edit&id=' . $issue_id));
        exit;
    }

    if (in_array($status, ['Resolved', 'Closed'], true)) {
        // Only stamp resolved_at the first time an issue reaches this status;
        // later edits that keep it resolved must not keep bumping the date.
        $resolved_at = date('Y-m-d H:i:s');
        if (!$is_create) {
            $existing = $pdo->prepare("SELECT resolved_at FROM known_issues WHERE id = ?");
            $existing->execute([$issue_id]);
            $existingResolvedAt = $existing->fetchColumn();
            if ($existingResolvedAt) {
                $resolved_at = $existingResolvedAt;
            }
        }
    } else {
        $resolved_at = null;
    }

    if ($is_create) {
        $issue_number = ki_generate_issue_number($pdo);
        $stmt = $pdo->prepare("
            INSERT INTO known_issues
                (issue_number, title, description, category, severity, status, owner_id,
                 affected_team, affected_system, environment,
                 symptoms_html, cause_html, workaround_html, resolution_html, notes_html,
                 resolved_at, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)
        ");
        $stmt->execute([
            $issue_number, $title, $summary, $category, $severity, $status, $current_user_id,
            $affected_team, $affected_system, $environment,
            $symptoms, $cause, $workaround, $resolution, $notes,
            $resolved_at,
        ]);
        $issue_id = (int) $pdo->lastInsertId();

        saveItemSharing($pdo, 'known_issue', $issue_id, $visibility, $shared_teams);
        if ($visibility === 'team') {
            $pdo->prepare("UPDATE known_issues SET owner_team = ? WHERE id = ?")->execute([$user_team, $issue_id]);
        }

        logItemAction($pdo, 'known_issue', $issue_id, 'CREATED', $current_user_id, $username, ['visibility' => $visibility]);
        $_SESSION['ki_msg'] = "Issue $issue_number created successfully.";
    } else {
        $stmt = $pdo->prepare("
            UPDATE known_issues SET
                title = ?, description = ?, category = ?, severity = ?, status = ?,
                affected_team = ?, affected_system = ?, environment = ?,
                symptoms_html = ?, cause_html = ?, workaround_html = ?, resolution_html = ?, notes_html = ?,
                resolved_at = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
        ");
        $stmt->execute([
            $title, $summary, $category, $severity, $status,
            $affected_team, $affected_system, $environment,
            $symptoms, $cause, $workaround, $resolution, $notes,
            $resolved_at, $issue_id,
        ]);

        saveItemSharing($pdo, 'known_issue', $issue_id, $visibility, $shared_teams);
        if ($visibility === 'team') {
            $pdo->prepare("UPDATE known_issues SET owner_team = ? WHERE id = ?")->execute([$user_team, $issue_id]);
        }

        logItemAction($pdo, 'known_issue', $issue_id, 'EDITED', $current_user_id, $username, ['visibility' => $visibility]);
        $_SESSION['ki_msg'] = "Issue updated successfully.";
    }

    header('Location: known-issues.php?action=view&id=' . $issue_id);
    exit;
}

/*
|--------------------------------------------------------------------------
| Page Routing
|--------------------------------------------------------------------------
*/

$action = $_GET['action'] ?? 'list';
if (!in_array($action, ['list', 'create', 'edit', 'view'], true)) {
    $action = 'list';
}
if (in_array($action, ['create', 'edit'], true) && !$canEdit) {
    $action = 'list';
}

$record = null;
if (in_array($action, ['edit', 'view'], true)) {
    $view_id = (int)($_GET['id'] ?? 0);
    $stmt = $pdo->prepare("
        SELECT ki.*, COALESCE(u.first_name || ' ' || u.last_name, u.ncgr_id, 'Unknown') AS owner_name
        FROM known_issues ki
        LEFT JOIN users u ON u.id = ki.owner_id
        WHERE ki.id = ?
    ");
    $stmt->execute([$view_id]);
    $record = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$record) {
        $_SESSION['ki_error'] = 'Issue not found.';
        header('Location: known-issues.php');
        exit;
    }

    if (!ki_can_view($pdo, $record, $current_user_id, $role, $user_team, $is_admin || $canAudit)) {
        $_SESSION['ki_error'] = 'You do not have permission to view this issue.';
        header('Location: known-issues.php');
        exit;
    }

    $record_shared_teams = ($record['team_scoped_visibility'] ?? '') === 'teams'
        ? getSharedTeams($pdo, 'known_issue', (int) $record['id'])
        : [];
}

if ($action === 'list') {
    /*
    |--------------------------------------------------------------------------
    | Pagination & Search
    |--------------------------------------------------------------------------
    */

    $limit = resolveUserPageSize($pdo, $current_user_id);
    $page = isset($_GET['page']) ? max(1, (int)$_GET['page']) : 1;
    $start = ($page - 1) * $limit;

    $keyword = trim($_GET['keyword'] ?? '');
    $s_severity = trim($_GET['s_severity'] ?? '');
    $s_status = trim($_GET['s_status'] ?? '');

    $where_clauses = ["1=1"];
    $params = [];

    if (!empty($keyword)) {
        $where_clauses[] = "(issue_number LIKE ? OR title LIKE ?)";
        array_push($params, "%$keyword%", "%$keyword%");
    }
    if (!empty($s_severity)) {
        $where_clauses[] = "severity = ?";
        $params[] = "$s_severity";
    }
    if (!empty($s_status)) {
        $where_clauses[] = "status = ?";
        $params[] = "$s_status";
    }

    $canSeeAll = $is_admin || $canAudit;
    if (!$canSeeAll) {
        $where_clauses[] = "(
            owner_id = ?
            OR team_scoped_visibility = 'public'
            OR (team_scoped_visibility = 'team' AND owner_team = ?)
            OR (team_scoped_visibility = 'teams' AND id IN (
                SELECT issue_id FROM known_issue_teams WHERE team_name = ?
            ))
        )";
        array_push($params, $current_user_id, $user_team, $user_team);
    }

    $where_sql = implode(" AND ", $where_clauses);

    $total_stmt = $pdo->prepare("SELECT COUNT(*) FROM known_issues WHERE $where_sql");
    $total_stmt->execute($params);
    $total_records = $total_stmt->fetchColumn();
    $total_pages = max(1, (int)ceil($total_records / $limit));

    if ($page > $total_pages && $total_records > 0) {
        $page = $total_pages;
        $start = ($page - 1) * $limit;
    }

    $sort_by = trim((string) ($_GET['sort_by'] ?? 'id'));
    $sort_dir = trim((string) ($_GET['sort_dir'] ?? 'DESC'));

    $valid_sort_columns = ['id', 'issue_number', 'title', 'severity', 'status', 'created_at'];
    if (!in_array($sort_by, $valid_sort_columns, true)) {
        $sort_by = 'id';
    }
    if (!in_array($sort_dir, ['ASC', 'DESC'], true)) {
        $sort_dir = 'DESC';
    }

    $next_sort_dir = ($sort_dir === 'ASC') ? 'DESC' : 'ASC';

    $data_stmt = $pdo->prepare("
        SELECT * FROM known_issues
        WHERE $where_sql
        ORDER BY `$sort_by` $sort_dir
        LIMIT $limit OFFSET $start
    ");
    $data_stmt->execute($params);
    $records = $data_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Hidden fields so the page-size selector preserves the current
    // search/filter/sort state instead of resetting it.
    $hidden_filter_fields = '';
    foreach ([
        'keyword' => $keyword,
        's_severity' => $s_severity,
        's_status' => $s_status,
        'sort_by' => $sort_by,
        'sort_dir' => $sort_dir,
    ] as $fk => $fv) {
        if ($fv !== '') {
            $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk, ENT_QUOTES, 'UTF-8') . '" value="' . htmlspecialchars($fv, ENT_QUOTES, 'UTF-8') . '">';
        }
    }
}

if ($action === 'view' && $canAudit) {
    $history = getItemAuditTrail($pdo, 'known_issue', (int) $record['id']);
} else {
    $history = [];
}

$page_title = "Known Issues | InfraVault";
require 'includes/header.php';
?>
<link href="assets/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/decommission.css">
<link rel="stylesheet" href="assets/css/known-issues.css">
<?php require 'includes/sidebar.php'; ?>

<div class="content">

<?php if ($action === 'list'): ?>

    <div class="dashboard-header">
        <div>
            <h1>Known Issues</h1>
            <p>Track known issues, workarounds, and resolutions across systems and teams.</p>
        </div>
        <div class="dashboard-actions">
            <?php if ($canEdit): ?>
                <a href="known-issues.php?action=create" class="btn btn-success">➕ Add Issue</a>
            <?php endif; ?>
            <?php if ($canImport): ?>
                <a href="known-issues-import.php" class="btn btn-info">📥 Import CSV</a>
            <?php endif; ?>
            <?php if ($canExport): ?>
                <?php
                $export_params = ['action' => 'export'];
                if ($keyword !== '') $export_params['keyword'] = $keyword;
                if ($s_severity !== '') $export_params['s_severity'] = $s_severity;
                if ($s_status !== '') $export_params['s_status'] = $s_status;
                $export_url = 'known-issues.php?' . http_build_query($export_params);
                ?>
                <a href="<?= htmlspecialchars($export_url) ?>" class="btn btn-info">📊 Export CSV</a>
            <?php endif; ?>
        </div>
    </div>

    <?php if ($msg): ?><div class="alert alert-success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <!-- Search Panel -->
    <div class="panel">
        <div class="panel-header">
            <h3 class="panel-title">Search & Filters</h3>
            <span style="cursor:pointer; color:#2563EB; font-size:13px; font-weight:600;" onclick="toggleAdvancedSearch()">
                Search Multiple Values ▼
            </span>
        </div>

        <div style="display:flex; flex-wrap:wrap; align-items:center; justify-content:space-between; gap:14px;">
            <form method="GET" action="known-issues.php" style="display:flex; gap:10px; flex-wrap:wrap;">
                <input type="text" name="keyword" class="form-control" style="max-width:320px;" placeholder="Search issue number, title..." value="<?php echo htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8'); ?>">
                <button type="submit" class="btn btn-primary">Search</button>
            </form>

            <?= pageSizeSelectorHtml($limit, $hidden_filter_fields) ?>
        </div>

        <div id="advancedSearch" style="display:none; margin-top:15px; padding-top:15px; border-top:1px solid #e5e7eb;">
            <form method="GET" action="known-issues.php" style="display:flex; gap:10px; flex-wrap:wrap;">
                <input type="text" name="keyword" class="form-control" style="max-width:200px;" placeholder="Global search..." value="<?php echo htmlspecialchars($keyword, ENT_QUOTES, 'UTF-8'); ?>">

                <select name="s_severity" class="form-control" style="max-width:150px;">
                    <option value="">-- Severity --</option>
                    <option value="Critical" <?php echo $s_severity === 'Critical' ? 'selected' : ''; ?>>Critical</option>
                    <option value="High" <?php echo $s_severity === 'High' ? 'selected' : ''; ?>>High</option>
                    <option value="Medium" <?php echo $s_severity === 'Medium' ? 'selected' : ''; ?>>Medium</option>
                    <option value="Low" <?php echo $s_severity === 'Low' ? 'selected' : ''; ?>>Low</option>
                </select>

                <select name="s_status" class="form-control" style="max-width:150px;">
                    <option value="">-- Status --</option>
                    <option value="Open" <?php echo $s_status === 'Open' ? 'selected' : ''; ?>>Open</option>
                    <option value="In Progress" <?php echo $s_status === 'In Progress' ? 'selected' : ''; ?>>In Progress</option>
                    <option value="Resolved" <?php echo $s_status === 'Resolved' ? 'selected' : ''; ?>>Resolved</option>
                    <option value="Closed" <?php echo $s_status === 'Closed' ? 'selected' : ''; ?>>Closed</option>
                </select>

                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <a href="known-issues.php" class="btn btn-secondary">Clear</a>
            </form>
        </div>
    </div>

    <!-- Pagination Info -->
    <div style="margin: 15px 0; font-size: 14px; color: #666;">
        Showing <?php echo $total_records > 0 ? ($start + 1) : 0; ?> to <?php echo min($start + $limit, $total_records); ?> of <?php echo $total_records; ?> issues
        <?php if ($total_pages > 1): ?>
            | Page <?php echo $page; ?> of <?php echo $total_pages; ?>
        <?php endif; ?>
    </div>

    <!-- Data Table -->
    <div class="table-wrap">
        <table class="data-table">
            <thead>
                <tr>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'issue_number', 'sort_dir' => ($sort_by === 'issue_number' && $sort_dir === 'ASC' ? 'DESC' : 'ASC')])); ?>">Issue <?php echo $sort_by === 'issue_number' ? ($sort_dir === 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'title', 'sort_dir' => ($sort_by === 'title' && $sort_dir === 'ASC' ? 'DESC' : 'ASC')])); ?>">Title <?php echo $sort_by === 'title' ? ($sort_dir === 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'severity', 'sort_dir' => ($sort_by === 'severity' && $sort_dir === 'ASC' ? 'DESC' : 'ASC')])); ?>">Severity <?php echo $sort_by === 'severity' ? ($sort_dir === 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'status', 'sort_dir' => ($sort_by === 'status' && $sort_dir === 'ASC' ? 'DESC' : 'ASC')])); ?>">Status <?php echo $sort_by === 'status' ? ($sort_dir === 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                    <th>Affected System</th>
                    <th><a href="?<?php echo http_build_query(array_merge($_GET, ['sort_by' => 'created_at', 'sort_dir' => ($sort_by === 'created_at' && $sort_dir === 'ASC' ? 'DESC' : 'ASC')])); ?>">Created <?php echo $sort_by === 'created_at' ? ($sort_dir === 'ASC' ? '▲' : '▼') : ''; ?></a></th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($records)): ?>
                    <tr>
                        <td colspan="7" class="text-center text-muted">No issues found.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($records as $record_row): ?>
                        <tr>
                            <td><strong><?php echo htmlspecialchars($record_row['issue_number'] ?? '', ENT_QUOTES, 'UTF-8'); ?></strong></td>
                            <td>
                                <a class="known-title" href="known-issues.php?action=view&id=<?php echo (int) $record_row['id']; ?>">
                                    <?php echo htmlspecialchars(substr($record_row['title'] ?? '', 0, 40), ENT_QUOTES, 'UTF-8'); ?><?php echo strlen($record_row['title'] ?? '') > 40 ? '...' : ''; ?>
                                </a>
                            </td>
                            <td><span class="badge" style="background-color: <?php
                                $sev = strtolower($record_row['severity'] ?? 'medium');
                                echo $sev === 'critical' ? '#dc2626' :
                                     ($sev === 'high' ? '#ea580c' :
                                      ($sev === 'medium' ? '#f59e0b' : '#10b981'));
                            ?>;"><?php echo htmlspecialchars($record_row['severity'] ?? '', ENT_QUOTES, 'UTF-8'); ?></span></td>
                            <td><?php echo htmlspecialchars($record_row['status'] ?? '', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars($record_row['affected_system'] ?? '-', ENT_QUOTES, 'UTF-8'); ?></td>
                            <td><?php echo htmlspecialchars(substr($record_row['created_at'] ?? '', 0, 10), ENT_QUOTES, 'UTF-8'); ?></td>
                            <td>
                                <?php if ($canEdit): ?>
                                    <a class="btn btn-sm btn-outline-primary" href="known-issues.php?action=edit&id=<?php echo (int) $record_row['id']; ?>">✏️</a>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <a class="btn btn-sm btn-outline-secondary" href="known-issues.php?action=view&id=<?php echo (int) $record_row['id']; ?>#history">⏱</a>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button class="btn btn-sm btn-outline-danger" onclick="if(confirm('Delete this issue?')) { document.getElementById('deleteForm_<?php echo $record_row['id']; ?>').submit(); }">🗑️</button>
                                    <form id="deleteForm_<?php echo $record_row['id']; ?>" method="POST" style="display:none;">
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="issue_id" value="<?php echo $record_row['id']; ?>">
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if ($total_pages > 1): ?>
        <nav style="margin-top: 20px;">
            <ul class="pagination">
                <?php if ($page > 1): ?>
                    <li class="page-item"><a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => 1])); ?>">First</a></li>
                    <li class="page-item"><a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page - 1])); ?>">Previous</a></li>
                <?php endif; ?>

                <?php for ($i = max(1, $page - 2); $i <= min($total_pages, $page + 2); $i++): ?>
                    <li class="page-item <?php echo $i === $page ? 'active' : ''; ?>">
                        <a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $i])); ?>"><?php echo $i; ?></a>
                    </li>
                <?php endfor; ?>

                <?php if ($page < $total_pages): ?>
                    <li class="page-item"><a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $page + 1])); ?>">Next</a></li>
                    <li class="page-item"><a class="page-link" href="?<?php echo http_build_query(array_merge($_GET, ['page' => $total_pages])); ?>">Last</a></li>
                <?php endif; ?>
            </ul>
        </nav>
    <?php endif; ?>

<?php elseif ($action === 'create' || $action === 'edit'): ?>

    <?php
    $is_edit = $action === 'edit';
    $fv = $form_values ?? $record ?? [];
    $fv_get = static function (string $key) use ($fv): string {
        return h($fv[$key] ?? '');
    };
    $all_teams = getAllTeams($pdo);
    $current_visibility = $fv['visibility'] ?? $fv['team_scoped_visibility'] ?? 'public';
    if (!in_array($current_visibility, KI_VALID_VISIBILITY, true)) {
        $current_visibility = 'public';
    }
    $current_shared_teams_str = $fv['shared_teams'] ?? implode(',', $record_shared_teams ?? []);
    $current_shared_teams_arr = array_filter(explode(',', $current_shared_teams_str));
    ?>

    <div class="known-page-header">
        <div>
            <h1><?= $is_edit ? 'Edit Issue' : 'New Known Issue' ?></h1>
            <p><?= $is_edit ? 'Issue ' . h($record['issue_number']) : 'Fields marked with * are required.' ?></p>
        </div>
        <div class="known-header-actions">
            <a href="known-issues.php<?= $is_edit ? '?action=view&id=' . (int) $record['id'] : '' ?>" class="known-secondary-btn">Cancel</a>
        </div>
    </div>

    <?php if ($error): ?><div class="known-alert error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div class="known-form-panel">
        <form method="POST" action="known-issues.php">
            <input type="hidden" name="action" value="<?= $is_edit ? 'update' : 'create' ?>">
            <?php if ($is_edit): ?><input type="hidden" name="issue_id" value="<?= (int) $record['id'] ?>"><?php endif; ?>

            <div class="known-form-grid">
                <div class="known-field full">
                    <label>Title <span>*</span></label>
                    <input type="text" name="title" maxlength="255" required value="<?= $fv_get('title') ?>">
                </div>

                <div class="known-field full">
                    <label>Summary <span>*</span></label>
                    <textarea name="description" rows="3" required><?= $fv_get('description') ?></textarea>
                    <span class="field-help">A concise overview of the issue — shown wherever this issue is referenced.</span>
                </div>

                <div class="known-field">
                    <label>Category <span>*</span></label>
                    <input type="text" name="category" maxlength="120" required value="<?= $fv_get('category') ?>">
                </div>

                <div class="known-field">
                    <label>Severity <span>*</span></label>
                    <select name="severity" required>
                        <option value="">-- Select --</option>
                        <?php foreach (KI_VALID_SEVERITIES as $opt): ?>
                            <option value="<?= h($opt) ?>" <?= ($fv['severity'] ?? '') === $opt ? 'selected' : '' ?>><?= h($opt) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="known-field">
                    <label>Status <span>*</span></label>
                    <select name="status" required>
                        <option value="">-- Select --</option>
                        <?php foreach (KI_VALID_STATUSES as $opt): ?>
                            <option value="<?= h($opt) ?>" <?= ($fv['status'] ?? ($is_edit ? '' : 'Open')) === $opt ? 'selected' : '' ?>><?= h($opt) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="known-field full">
                    <fieldset class="known-vis-fieldset">
                        <legend>Publish To <span>*</span></legend>
                        <div class="known-vis-options">
                            <label class="known-vis-option">
                                <input type="radio" name="visibility" value="public" <?= $current_visibility === 'public' ? 'checked' : '' ?> onchange="kiUpdateVisibility()">
                                <span class="known-vis-label">Public</span>
                                <span class="known-vis-desc">Visible to everyone with Known Issues access</span>
                            </label>
                            <label class="known-vis-option">
                                <input type="radio" name="visibility" value="team" <?= $current_visibility === 'team' ? 'checked' : '' ?> onchange="kiUpdateVisibility()">
                                <span class="known-vis-label">My Team Only</span>
                                <span class="known-vis-desc">Visible only to your team<?= $user_team ? ' (' . h($user_team) . ')' : '' ?></span>
                            </label>
                            <label class="known-vis-option">
                                <input type="radio" name="visibility" value="teams" <?= $current_visibility === 'teams' ? 'checked' : '' ?> onchange="kiUpdateVisibility()">
                                <span class="known-vis-label">Specific Teams</span>
                                <span class="known-vis-desc">Visible only to the teams you select</span>
                            </label>
                        </div>
                        <div id="ki-teams-selector" class="known-vis-teams" style="<?= $current_visibility === 'teams' ? '' : 'display:none;' ?>">
                            <label class="known-vis-label">Select Teams:</label>
                            <div class="known-vis-teams-grid">
                                <?php foreach ($all_teams as $team): ?>
                                    <label class="known-vis-team-cb">
                                        <input type="checkbox" value="<?= h($team) ?>" <?= in_array($team, $current_shared_teams_arr, true) ? 'checked' : '' ?> onchange="kiUpdateSharedTeams()">
                                        <?= h($team) ?>
                                    </label>
                                <?php endforeach; ?>
                                <?php if (empty($all_teams)): ?>
                                    <span class="muted">No teams found.</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </fieldset>
                    <input type="hidden" name="shared_teams" id="ki_shared_teams" value="<?= h($current_shared_teams_str) ?>">
                </div>

                <div class="known-field">
                    <label>Affected Team</label>
                    <input type="text" name="affected_team" maxlength="120" value="<?= $fv_get('affected_team') ?>">
                </div>

                <div class="known-field">
                    <label>Affected System</label>
                    <input type="text" name="affected_system" maxlength="120" value="<?= $fv_get('affected_system') ?>">
                </div>

                <div class="known-field">
                    <label>Environment</label>
                    <input type="text" name="environment" maxlength="60" value="<?= $fv_get('environment') ?>">
                </div>

                <div class="known-field full">
                    <label>Symptoms</label>
                    <textarea name="symptoms" rows="3"><?= h($fv['symptoms'] ?? $fv['symptoms_html'] ?? '') ?></textarea>
                </div>

                <div class="known-field full">
                    <label>Cause</label>
                    <textarea name="cause" rows="3"><?= h($fv['cause'] ?? $fv['cause_html'] ?? '') ?></textarea>
                </div>

                <div class="known-field full">
                    <label>Workaround</label>
                    <textarea name="workaround" rows="3"><?= h($fv['workaround'] ?? $fv['workaround_html'] ?? '') ?></textarea>
                </div>

                <div class="known-field full">
                    <label>Resolution</label>
                    <textarea name="resolution" rows="3"><?= h($fv['resolution'] ?? $fv['resolution_html'] ?? '') ?></textarea>
                </div>

                <div class="known-field full">
                    <label>Notes</label>
                    <textarea name="notes" rows="3"><?= h($fv['notes'] ?? $fv['notes_html'] ?? '') ?></textarea>
                </div>
            </div>

            <div class="known-form-actions" style="padding: 0 20px 20px;">
                <a href="known-issues.php<?= $is_edit ? '?action=view&id=' . (int) $record['id'] : '' ?>" class="known-secondary-btn">Cancel</a>
                <button type="submit" class="known-primary-btn"><?= $is_edit ? 'Save Changes' : 'Create Issue' ?></button>
            </div>
        </form>
    </div>

<?php elseif ($action === 'view'): ?>

    <?php
    $status_slug = ki_slug($record['status'] ?? '');
    $severity_slug = ki_slug($record['severity'] ?? '');
    ?>

    <div class="known-page-header">
        <div>
            <div class="known-issue-number">Issue <?= h($record['issue_number']) ?></div>
            <h1><?= h($record['title']) ?></h1>
            <p><?= h($record['category'] ?: 'Uncategorized') ?></p>
        </div>
        <div class="known-header-actions">
            <?php if ($canEdit): ?>
                <a href="known-issues.php?action=edit&id=<?= (int) $record['id'] ?>" class="known-primary-btn">✏️ Edit</a>
            <?php endif; ?>
            <a href="known-issues.php" class="known-secondary-btn">← Back to List</a>
        </div>
    </div>

    <?php if ($msg): ?><div class="known-alert success"><?php echo htmlspecialchars($msg); ?></div><?php endif; ?>

    <?php
    $vis = $record['team_scoped_visibility'] ?? 'public';
    $visLabel = [
        'public' => 'Public',
        'team'   => 'My Team Only' . ($record['owner_team'] ? ' (' . $record['owner_team'] . ')' : ''),
        'teams'  => 'Specific Teams' . (!empty($record_shared_teams) ? ' (' . implode(', ', $record_shared_teams) . ')' : ''),
    ][$vis] ?? ucfirst($vis);
    ?>

    <div class="known-meta-grid">
        <div><span>Severity</span><strong><span class="known-severity severity-<?= h($severity_slug) ?>"><?= h($record['severity']) ?></span></strong></div>
        <div><span>Status</span><strong><span class="known-status status-<?= h($status_slug) ?>"><?= h($record['status']) ?></span></strong></div>
        <div><span>Affected System</span><strong><?= h($record['affected_system'] ?: '—') ?></strong></div>
        <div><span>Environment</span><strong><?= h($record['environment'] ?: '—') ?></strong></div>
        <div><span>Affected Team</span><strong><?= h($record['affected_team'] ?: '—') ?></strong></div>
        <div><span>Owner</span><strong><?= h($record['owner_name'] ?: 'Unknown') ?></strong></div>
        <div><span>Visibility</span><strong><?= h($visLabel) ?></strong></div>
        <div><span>Created</span><strong><?= h(date('M d, Y', strtotime($record['created_at']))) ?></strong></div>
        <div><span>Updated</span><strong><?= h(date('M d, Y', strtotime($record['updated_at']))) ?></strong></div>
    </div>

    <div class="known-document">
        <section>
            <h2>Summary</h2>
            <p class="known-rich-content"><?= nl2br(h($record['description'])) ?></p>
        </section>

        <?php if (!empty($record['symptoms_html'])): ?>
        <section>
            <h2>Symptoms</h2>
            <p class="known-rich-content"><?= nl2br(h($record['symptoms_html'])) ?></p>
        </section>
        <?php endif; ?>

        <?php if (!empty($record['cause_html'])): ?>
        <section>
            <h2>Cause</h2>
            <p class="known-rich-content"><?= nl2br(h($record['cause_html'])) ?></p>
        </section>
        <?php endif; ?>

        <?php if (!empty($record['workaround_html'])): ?>
        <section class="known-workaround">
            <h2>Workaround</h2>
            <p class="known-rich-content"><?= nl2br(h($record['workaround_html'])) ?></p>
        </section>
        <?php endif; ?>

        <?php if (!empty($record['resolution_html'])): ?>
        <section class="known-resolution">
            <h2>Resolution</h2>
            <p class="known-rich-content"><?= nl2br(h($record['resolution_html'])) ?></p>
        </section>
        <?php endif; ?>

        <?php if (!empty($record['notes_html'])): ?>
        <section>
            <h2>Notes</h2>
            <p class="known-rich-content"><?= nl2br(h($record['notes_html'])) ?></p>
        </section>
        <?php endif; ?>
    </div>

    <?php if ($canAudit): ?>
    <div class="known-panel" id="history" style="margin-top:20px;">
        <div class="known-panel-header">
            <div>
                <h2>History</h2>
                <span><?= count($history) ?> action<?= count($history) === 1 ? '' : 's' ?> recorded</span>
            </div>
        </div>
        <div style="padding: 4px 20px 20px;">
            <?php if (empty($history)): ?>
                <p class="muted">No history recorded yet.</p>
            <?php else: ?>
                <?php foreach ($history as $entry): ?>
                    <div style="padding:10px 0; border-bottom:1px solid var(--border-light);">
                        <strong><?= h(ucwords(strtolower($entry['action']))) ?></strong>
                        <span class="muted"> by <?= h($entry['user_name']) ?> &middot; <?= h(date('M d, Y H:i', strtotime($entry['action_date']))) ?></span>
                    </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>

<?php endif; ?>

</div>

<script>
function toggleAdvancedSearch() {
    const elem = document.getElementById('advancedSearch');
    elem.style.display = elem.style.display === 'none' ? 'block' : 'none';
}

function kiUpdateVisibility() {
    const selected = document.querySelector('input[name="visibility"]:checked');
    const visibility = selected ? selected.value : 'public';
    const teamsSelector = document.getElementById('ki-teams-selector');
    if (!teamsSelector) return;

    if (visibility === 'teams') {
        teamsSelector.style.display = 'block';
    } else {
        teamsSelector.style.display = 'none';
        const hidden = document.getElementById('ki_shared_teams');
        if (hidden) hidden.value = '';
    }
}

function kiUpdateSharedTeams() {
    const selected = Array.from(document.querySelectorAll('#ki-teams-selector input[type="checkbox"]:checked'))
        .map(cb => cb.value);
    const hidden = document.getElementById('ki_shared_teams');
    if (hidden) hidden.value = selected.join(',');
}
</script>

<?php require 'includes/footer.php'; ?>
