<?php
// get_tasks.php
session_start();
require 'config/db.php';

if (!isset($_SESSION['user_id'])) {
    http_response_code(401);
    echo "Unauthorized";
    exit;
}

/*
| Authorization. Added because this file performed its work with a
| login check only -- being signed in was enough, regardless of role.
| The verb is checked here, in the file that does the work, so it
| cannot be bypassed by calling this endpoint directly.
*/
requirePermission('dashboard', 'can_view');


$role = trim($_SESSION['role'] ?? '');
$decommission_id = $_GET['decommission_id'] ?? null;
$editable = isset($_GET['edit']) && $_GET['edit'] == '1' && ($role === 'Admin' || $role === 'Edit');

if (!$decommission_id) {
    echo '<p class="text-danger">Invalid Decommission ID.</p>';
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM decommission_tasks WHERE decommission_id = ? ORDER BY id ASC");
$stmt->execute([$decommission_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<div class="table-responsive">
    <form id="inlineTaskForm" onsubmit="submitTaskForm(event, <?php echo $decommission_id; ?>, <?php echo $editable ? '1' : '0'; ?>)">
        <table class="table table-bordered align-middle">
            <thead class="table-dark">
                <tr>
                    <th style="width: 50px; text-align: center;">Status</th>
                    <th>Task Description</th>
                    <th style="width: 250px;">REQ NO / Reference</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($tasks) > 0): ?>
                    <?php foreach ($tasks as $t): ?>
                        <?php 
                            $tid = $t['id'];
                            $is_checked = ($t['status'] === 'Completed') ? 'checked' : '';
                            $req_val = htmlspecialchars($t['req_no'] ?? '');
                        ?>
                        <tr>
                            <td style="text-align: center;">
                                <?php if ($editable): ?>
                                    <input type="checkbox" name="task_status[<?php echo $tid; ?>]" value="Completed" <?php echo $is_checked; ?> class="form-check-input" style="transform: scale(1.2);">
                                <?php else: ?>
                                    <input type="checkbox" <?php echo $is_checked; ?> disabled class="form-check-input" style="transform: scale(1.2);">
                                <?php endif; ?>
                            </td>
                            <td><?php echo htmlspecialchars($t['task_name']); ?></td>
                            <td>
                                <?php if ($editable): ?>
                                    <input type="text" name="task_req[<?php echo $tid; ?>]" value="<?php echo $req_val; ?>" class="form-control form-control-sm" placeholder="Enter REQ NO...">
                                <?php else: ?>
                                    <span class="text-muted"><?php echo $req_val !== '' ? $req_val : 'N/A'; ?></span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr><td colspan="3" class="text-muted text-center italic">No checklist tasks defined for this record.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div style="display: flex; justify-content: space-between; align-items: center; margin-top: 1rem;">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            <?php if ($editable): ?>
                <button type="submit" class="btn btn-success">Save Checklist Progress</button>
            <?php endif; ?>
        </div>
    </form>
</div>
