<?php

session_start();

require "config/db.php";
require_once 'includes/pagination-helpers.php';


if(!isset($_SESSION['user_id'])){

    header("Location:index.php");
    exit;

}


/*
|--------------------------------------------------------------------------
| PERMISSION HELPER
|--------------------------------------------------------------------------
|
| Permissions table:
|
| role
| page_key
| can_view
| can_edit
| can_delete
| can_export
| can_import
| can_audit
|
| This page's key is 'ip' (registered in permission.php as
| "IP Address Management").
|
*/

function ipHasPermission(PDO $pdo, string $role, string $permission): bool
{
    /*
    | Delegates to the single authorization helper.
    |
    | This used to be a hand-rolled copy with its own role-matching
    | rule; sixteen such copies existed and three of them disagreed
    | about what counted as a match. The name and signature are kept
    | so existing call sites in this file continue to work.
    */
    return authzCan($pdo, $role, 'ip', $permission);
}


$role = trim($_SESSION['role'] ?? '');


$canView   = ipHasPermission($pdo, $role, 'can_view');
$canEdit   = ipHasPermission($pdo, $role, 'can_edit');
$canDelete = ipHasPermission($pdo, $role, 'can_delete');
$canExport = ipHasPermission($pdo, $role, 'can_export');
$canImport = ipHasPermission($pdo, $role, 'can_import');
$canAudit  = ipHasPermission($pdo, $role, 'can_audit');


/*
|--------------------------------------------------------------------------
| PAGE VIEW PERMISSION
|--------------------------------------------------------------------------
|
| This must happen BEFORE header/sidebar are included, otherwise a
| user without can_view would still see the page chrome rendered
| before the deny message.
|
*/

if (!$canView) {

    http_response_code(403);

    exit('You do not have permission to view this page.');
}


/*
|--------------------------------------------------------------------------
| HOSTS IN RANGE (AJAX)
|--------------------------------------------------------------------------
|
| Returns the inventory servers whose primary or additional address falls
| inside a given range, for the second tab of the IP details modal.
|
| Fetched on demand rather than embedded in the listing: the match has to
| be computed per range against the whole inventory, and only one range
| is ever open at a time.
|
| Placed after the can_view gate above so it inherits it.
|--------------------------------------------------------------------------
*/

require_once __DIR__ . '/includes/ip-helpers.php';

if (($_GET['action'] ?? '') === 'range_hosts') {

    $rangeId = (int) ($_GET['id'] ?? 0);

    $stmt = $pdo->prepare("SELECT id, ip_range, cidr, vlan, environment, project FROM ip_ranges WHERE id = ?");
    $stmt->execute([$rangeId]);
    $range = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$range) {
        echo '<p class="ip-hosts-empty">Range not found.</p>';
        exit;
    }

    $bounds = ipRangeBounds($range['ip_range'], $range['cidr']);

    if (!$bounds) {
        echo '<p class="ip-hosts-empty">This range could not be parsed ('
           . htmlspecialchars((string) $range['ip_range'], ENT_QUOTES, 'UTF-8')
           . '), so matching hosts cannot be determined. Check the IP Range and CIDR values.</p>';
        exit;
    }

    /* Both Inventory and Asset records, merged and sorted by address. */
    $records = ipRecordsInRange($pdo, $bounds);

    $fromInventory = count(array_filter($records, fn($r) => $r['source'] === 'Inventory'));
    $fromAssets    = count($records) - $fromInventory;

    $parts = [];
    if ($fromInventory) { $parts[] = $fromInventory . ' from Inventory'; }
    if ($fromAssets)    { $parts[] = $fromAssets . ' from Assets'; }

    echo '<div class="ip-hosts-summary">'
       . '<span><strong>' . count($records) . '</strong> record' . (count($records) === 1 ? '' : 's')
       . ' in <code>' . htmlspecialchars($bounds['label'], ENT_QUOTES, 'UTF-8') . '</code>'
       . ($parts ? ' <span class="ip-hosts-split">(' . implode(' · ', $parts) . ')</span>' : '')
       . '</span>'
       . '<span class="ip-hosts-bounds">'
       . htmlspecialchars(long2ip($bounds['network']), ENT_QUOTES, 'UTF-8') . ' – '
       . htmlspecialchars(long2ip($bounds['broadcast']), ENT_QUOTES, 'UTF-8')
       . '</span></div>';

    if (!$records) {
        echo '<p class="ip-hosts-empty">Nothing in Inventory or Assets has an address in this range yet.</p>';
        exit;
    }

    echo '<div class="ip-hosts-wrap"><table class="ip-hosts-table"><thead><tr>'
       . '<th>IP Address</th><th>Name</th><th>Source</th><th>Type / OS</th>'
       . '<th>Class</th><th>State</th><th>Context</th><th>Owner</th>'
       . '</tr></thead><tbody>';

    foreach ($records as $r) {

        $ipCells = [];
        foreach ($r['matched_ips'] as $m) {
            $ipCells[] = '<span class="ip-host-ip">'
                       . htmlspecialchars($m['ip'], ENT_QUOTES, 'UTF-8')
                       . ($m['primary'] ? '' : ' <em>additional</em>')
                       . '</span>';
        }

        $state = strtolower(trim((string) $r['state']));
        $stateClass = 'neutral';
        if (str_contains($state, 'on') || str_contains($state, 'active') || str_contains($state, 'service')) {
            $stateClass = 'ok';
        } elseif (str_contains($state, 'off') || str_contains($state, 'retired') || str_contains($state, 'decom')) {
            $stateClass = 'crit';
        }

        $srcClass = $r['source'] === 'Asset' ? 'asset' : 'inv';

        echo '<tr>'
           . '<td>' . implode('<br>', $ipCells) . '</td>'
           . '<td class="ip-host-name">' . htmlspecialchars((string) $r['name'], ENT_QUOTES, 'UTF-8') . '</td>'
           . '<td><a class="ip-src ' . $srcClass . '" href="' . htmlspecialchars($r['source_page'], ENT_QUOTES, 'UTF-8') . '">'
             . htmlspecialchars((string) $r['source'], ENT_QUOTES, 'UTF-8') . '</a></td>'
           . '<td>' . htmlspecialchars(($r['kind'] !== '' ? $r['kind'] : '—'), ENT_QUOTES, 'UTF-8') . '</td>'
           . '<td>' . htmlspecialchars(($r['tier'] !== '' ? $r['tier'] : '—'), ENT_QUOTES, 'UTF-8') . '</td>'
           . '<td><span class="ip-host-pill ' . $stateClass . '">'
             . htmlspecialchars(($r['state'] !== '' ? $r['state'] : '—'), ENT_QUOTES, 'UTF-8') . '</span></td>'
           . '<td>' . htmlspecialchars(($r['context'] !== '' ? $r['context'] : '—'), ENT_QUOTES, 'UTF-8')
             . ($r['context_sub'] !== '' ? '<small>' . htmlspecialchars((string) $r['context_sub'], ENT_QUOTES, 'UTF-8') . '</small>' : '')
             . '</td>'
           . '<td>' . htmlspecialchars(($r['owner'] !== '' ? $r['owner'] : '—'), ENT_QUOTES, 'UTF-8') . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/*
|--------------------------------------------------------------------------
| COLUMN DEFINITIONS
|--------------------------------------------------------------------------
|
| Single source of truth for every toggleable column -- used to render
| the table header, the table cells, and the column-picker checkboxes,
| so a field can never go missing from one of the three the way
| portgroup/comments previously did.
|
*/

$ip_columns = [
    'ip_range'     => 'IP Range',
    'cidr'         => 'CIDR',
    'subnet'       => 'Subnet',
    'vlan'         => 'VLAN',
    'portgroup'    => 'Port Group',
    'environment'  => 'Environment',
    'project'      => 'Project',
    'gateway'      => 'Gateway',
    'usable_hosts' => 'Hosts',
    'comments'     => 'Comments',
    'created_by'   => 'Created By',
];

$default_visible_columns = [
    'ip_range',
    'cidr',
    'subnet',
    'vlan',
    'environment',
    'project',
    'gateway',
    'usable_hosts',
    'created_by',
];


/*
|--------------------------------------------------------------------------
| PER-USER COLUMN PREFERENCES (persisted, not just localStorage)
|--------------------------------------------------------------------------
*/

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS ip_column_preferences (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        column_key TEXT NOT NULL,
        is_visible INTEGER NOT NULL DEFAULT 1,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        UNIQUE(user_id, column_key)
    )");
} catch (Throwable $e) {
    error_log('Unable to initialize ip_column_preferences: ' . $e->getMessage());
}


/*
|--------------------------------------------------------------------------
| MIGRATE ip_column_preferences
|--------------------------------------------------------------------------
|
| CREATE TABLE IF NOT EXISTS is a no-op if a table with this name
| already exists (e.g. from an earlier version of this feature with
| a different column set). Two cases are handled:
|
| 1. The existing table is just missing some of our columns -> add
|    them with ALTER TABLE, same as permission.php's migrations.
|
| 2. The existing table has a leftover column from an earlier,
|    incompatible version of this feature (e.g. a NOT NULL
|    "columns" column with no default) that would block every
|    insert regardless of which columns we add. This table only
|    caches per-user display preferences, nothing worth preserving,
|    so in that case it's dropped and recreated cleanly instead of
|    trying to patch around an unknown legacy shape.
|
*/

try {
    $ipColumnPrefsExisting = [];
    $ipColumnPrefsIncompatible = false;

    $ipColumnPrefsInfo = $pdo->query("PRAGMA table_info(ip_column_preferences)")->fetchAll(PDO::FETCH_ASSOC);

    $ipColumnPrefsKnown = ['id', 'user_id', 'column_key', 'is_visible', 'updated_at'];

    foreach ($ipColumnPrefsInfo as $col) {
        $ipColumnPrefsExisting[] = $col['name'];

        $isUnknownColumn = !in_array($col['name'], $ipColumnPrefsKnown, true);
        $isNotNullNoDefault = ((int)($col['notnull'] ?? 0) === 1) && ($col['dflt_value'] === null);

        if ($isUnknownColumn && $isNotNullNoDefault) {
            $ipColumnPrefsIncompatible = true;
        }
    }

    if ($ipColumnPrefsIncompatible) {

        $pdo->exec("DROP TABLE IF EXISTS ip_column_preferences");

        $pdo->exec("CREATE TABLE ip_column_preferences (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            column_key TEXT NOT NULL,
            is_visible INTEGER NOT NULL DEFAULT 1,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(user_id, column_key)
        )");

    } else {

        $ipColumnPrefsRequired = [
            'user_id'    => "INTEGER NOT NULL DEFAULT 0",
            'column_key' => "TEXT NOT NULL DEFAULT ''",
            'is_visible' => "INTEGER NOT NULL DEFAULT 1",
            'updated_at' => "DATETIME DEFAULT CURRENT_TIMESTAMP",
        ];

        foreach ($ipColumnPrefsRequired as $colName => $definition) {
            if (!in_array($colName, $ipColumnPrefsExisting, true)) {
                $pdo->exec("ALTER TABLE ip_column_preferences ADD COLUMN {$colName} {$definition}");
            }
        }
    }
} catch (Throwable $e) {
    error_log('Unable to migrate ip_column_preferences: ' . $e->getMessage());
}


$visible_columns = $default_visible_columns;
$user_id = (int)($_SESSION['user_id'] ?? 0);

if ($user_id > 0) {
    try {
        $prefStmt = $pdo->prepare("
            SELECT column_key
            FROM ip_column_preferences
            WHERE user_id = ? AND is_visible = 1
            ORDER BY column_key
        ");
        $prefStmt->execute([$user_id]);
        $savedColumns = $prefStmt->fetchAll(PDO::FETCH_COLUMN);

        if (is_array($savedColumns) && count($savedColumns) > 0) {
            $visible_columns = array_values(array_intersect(
                array_keys($ip_columns),
                array_map('strval', $savedColumns)
            ));
            if (count($visible_columns) === 0) {
                $visible_columns = $default_visible_columns;
            }
        }
    } catch (Throwable $e) {
        error_log('Unable to load ip_column_preferences: ' . $e->getMessage());
    }
}


/*
|--------------------------------------------------------------------------
| SAVE COLUMN PREFERENCES (AJAX)
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && (($_POST['form_action'] ?? '') === 'save_columns')) {

    header('Content-Type: application/json; charset=utf-8');

    try {
        if ($user_id <= 0) {
            throw new Exception('Invalid user session.');
        }

        $requested = json_decode($_POST['visible_columns'] ?? '[]', true);
        if (!is_array($requested)) {
            $requested = [];
        }

        $requested = array_values(array_unique(array_intersect(
            array_keys($ip_columns),
            array_map('strval', $requested)
        )));

        if (count($requested) === 0) {
            throw new Exception('Select at least one column.');
        }

        $pdo->beginTransaction();

        $pdo->prepare("DELETE FROM ip_column_preferences WHERE user_id = ?")
            ->execute([$user_id]);

        $insertStmt = $pdo->prepare("
            INSERT INTO ip_column_preferences (user_id, column_key, is_visible, updated_at)
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
        ");

        foreach (array_keys($ip_columns) as $columnKey) {
            $insertStmt->execute([
                $user_id,
                $columnKey,
                in_array($columnKey, $requested, true) ? 1 : 0
            ]);
        }

        $pdo->commit();

        echo json_encode(['ok' => true, 'message' => 'Column layout saved.']);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        error_log('Saving ip_column_preferences failed: ' . $e->getMessage());
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Unable to save column layout: ' . $e->getMessage()]);
    }

    exit;
}


$page_title="IP Address Management";


include "includes/header.php";
include "includes/sidebar.php";



/*
=====================================================
SEARCH & FILTERING
=====================================================
*/

$keyword = trim($_GET['keyword'] ?? "");
$s_ip_range = trim($_GET['s_ip_range'] ?? "");
$s_vlan = trim($_GET['s_vlan'] ?? "");
$s_project = trim($_GET['s_project'] ?? "");
$s_environment = trim($_GET['s_environment'] ?? "");
$s_gateway = trim($_GET['s_gateway'] ?? "");
$s_usable_hosts_min = trim($_GET['s_usable_hosts_min'] ?? "");
$s_usable_hosts_max = trim($_GET['s_usable_hosts_max'] ?? "");

/*
=====================================================
SORTING
=====================================================
*/

$sort_by = trim($_GET['sort_by'] ?? "id");
$sort_dir = trim($_GET['sort_dir'] ?? "DESC");

// Whitelist sort columns to prevent SQL injection
$allowed_sort_columns = array_keys($ip_columns);
$allowed_sort_columns[] = 'id';
$allowed_sort_columns[] = 'created_at';

if (!in_array($sort_by, $allowed_sort_columns, true)) {
    $sort_by = 'id';
}

if ($sort_dir !== 'ASC' && $sort_dir !== 'DESC') {
    $sort_dir = 'DESC';
}

$whereSql="
WHERE 1=1
";

$params=[];

// General keyword search
if($keyword!=""){
    $whereSql.="
    AND
    (
    ip_range LIKE ?
    OR vlan LIKE ?
    OR project LIKE ?
    OR gateway LIKE ?
    OR environment LIKE ?
    )
    ";

    $search="%".$keyword."%";
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
    $params[]=$search;
}

// Individual field searches
if($s_ip_range!=""){
    $whereSql.=" AND ip_range LIKE ?";
    $params[]="%" . $s_ip_range . "%";
}

if($s_vlan!=""){
    $whereSql.=" AND vlan LIKE ?";
    $params[]="%" . $s_vlan . "%";
}

if($s_project!=""){
    $whereSql.=" AND project LIKE ?";
    $params[]="%" . $s_project . "%";
}

if($s_environment!=""){
    $whereSql.=" AND environment = ?";
    $params[]=$s_environment;
}

if($s_gateway!=""){
    $whereSql.=" AND gateway LIKE ?";
    $params[]="%" . $s_gateway . "%";
}

if($s_usable_hosts_min!=""){
    $min_val = (int)$s_usable_hosts_min;
    $whereSql.=" AND usable_hosts >= ?";
    $params[]=$min_val;
}

if($s_usable_hosts_max!=""){
    $max_val = (int)$s_usable_hosts_max;
    $whereSql.=" AND usable_hosts <= ?";
    $params[]=$max_val;
}

/*
=====================================================
PAGINATION
=====================================================
COUNT query reuses the exact same WHERE clause + params
as the main query, before LIMIT/OFFSET is applied.
*/

$count_stmt = $pdo->prepare("SELECT COUNT(*) FROM ip_ranges $whereSql");
$count_stmt->execute($params);
$filtered_total = (int) $count_stmt->fetchColumn();

$page_size = resolveUserPageSize($pdo, $user_id);
$current_page = max(1, (int) ($_GET['page'] ?? 1));
$total_pages = max(1, (int) ceil($filtered_total / $page_size));
if ($current_page > $total_pages) {
    $current_page = $total_pages;
}
$offset = ($current_page - 1) * $page_size;

/*
=====================================================
STATS SOURCE
=====================================================
The summary cards above the table (Production/PreProd/UAT/
DMZ/Usable Hosts counts) must reflect ALL filtered rows, not
just the current page, so they're sourced from a separate
query against the same WHERE clause -- fetching only the two
columns the stats loop below reads, not every column.
*/

$stats_stmt = $pdo->prepare("SELECT environment, usable_hosts FROM ip_ranges $whereSql");
$stats_stmt->execute($params);
$rows = $stats_stmt->fetchAll(PDO::FETCH_ASSOC);

// Add sorting, then LIMIT/OFFSET for the table's current page
$sql = "SELECT * FROM ip_ranges $whereSql ORDER BY " . $sort_by . " " . $sort_dir . " LIMIT $page_size OFFSET $offset";

$stmt=$pdo->prepare($sql);

$stmt->execute($params);


$page_rows=$stmt->fetchAll(PDO::FETCH_ASSOC);

// Every filter/sort param that needs to survive pagination, sorting,
// and page-size changes -- built once, reused by all of them.
$list_query_params = array_filter([
    'keyword' => $keyword,
    's_ip_range' => $s_ip_range,
    's_vlan' => $s_vlan,
    's_project' => $s_project,
    's_environment' => $s_environment,
    's_gateway' => $s_gateway,
    's_usable_hosts_min' => $s_usable_hosts_min,
    's_usable_hosts_max' => $s_usable_hosts_max,
    'sort_by' => $sort_by,
    'sort_dir' => $sort_dir,
], static fn($v) => $v !== '');

$hidden_filter_fields = '';
foreach ($list_query_params as $fk => $fv) {
    $hidden_filter_fields .= '<input type="hidden" name="' . htmlspecialchars($fk) . '" value="' . htmlspecialchars($fv) . '">';
}





/*
=====================================================
STATISTICS
=====================================================
*/


$totalNetworks=count($rows);


$production=0;
$preprod=0;
$uat=0;
$dmz=0;
$totalHosts=0;



foreach($rows as $r){


$env=strtolower($r['environment'] ?? "");



if($env=="production"){
    $production++;
}


if($env=="preprod" || $env=="pre-prod"){
    $preprod++;
}


if($env=="uat"){
    $uat++;
}


if($env=="dmz"){
    $dmz++;
}



$totalHosts+=intval(
$r['usable_hosts'] ?? 0
);


}



?>


<link rel="stylesheet" href="assets/css/ip.css">


<div class="content">


<div class="ip-container">



<div class="ip-header">


<div>

<h1>
IP Address Management
</h1>


<p>
Enterprise Network Address Management
</p>


</div>



<div class="ip-header-actions">

<?php if($canEdit): ?>
<button class="btn-primary" onclick="newIP()">+ Add IP Range</button>
<?php endif; ?>

<?php if($canImport): ?>
<a href="#" onclick="openImportModal(); return false;" class="btn-secondary">Import CSV</a>
<?php endif; ?>

<?php if($canExport): ?>
<a href="ip-export.php?keyword=<?php echo urlencode($keyword); ?>&s_ip_range=<?php echo urlencode($s_ip_range); ?>&s_vlan=<?php echo urlencode($s_vlan); ?>&s_project=<?php echo urlencode($s_project); ?>&s_environment=<?php echo urlencode($s_environment); ?>&s_gateway=<?php echo urlencode($s_gateway); ?>&s_usable_hosts_min=<?php echo urlencode($s_usable_hosts_min); ?>&s_usable_hosts_max=<?php echo urlencode($s_usable_hosts_max); ?>" class="btn-secondary">Export</a>
<?php endif; ?>

<?php if($canAudit): ?>
<a href="ip-history.php" class="btn-secondary">History</a>
<?php endif; ?>

</div>


</div>





<div class="stats-grid">


<div class="stat-card">

<span>
Total Networks
</span>

<strong>
<?=$totalNetworks?>
</strong>

</div>



<div class="stat-card green">

<span>
Production
</span>

<strong>
<?=$production?>
</strong>

</div>




<div class="stat-card blue">

<span>
PreProd
</span>

<strong>
<?=$preprod?>
</strong>

</div>




<div class="stat-card purple">

<span>
UAT
</span>

<strong>
<?=$uat?>
</strong>

</div>



<div class="stat-card red">

<span>
DMZ
</span>

<strong>
<?=$dmz?>
</strong>

</div>




<div class="stat-card">

<span>
Usable Hosts
</span>

<strong>
<?=number_format($totalHosts)?>
</strong>

</div>



</div>





<div class="ip-toolbar">

<form method="GET" class="search-box">

<div class="search-input">
<i class="fa-solid fa-magnifying-glass"></i>
<input
type="text"
name="keyword"
placeholder="Search IP Range, VLAN, Project, Gateway..."
value="<?=htmlspecialchars($keyword)?>"
>
<?php if($keyword!="" || $s_ip_range!="" || $s_vlan!="" || $s_project!="" || $s_environment!="" || $s_gateway!="" || $s_usable_hosts_min!="" || $s_usable_hosts_max!=""): ?>
<a href="ip.php" class="clear-search">
<i class="fa-solid fa-xmark"></i>
</a>
<?php endif; ?>
</div>

<button type="button" class="btn-secondary" onclick="toggleAdvancedSearch()">
<i class="fa-solid fa-sliders"></i>
Advanced Search
</button>

<button class="btn-primary">
Search
</button>

</form>

<?= pageSizeSelectorHtml($page_size, $hidden_filter_fields) ?>

<a href="ip.php" class="btn-secondary">
Reset
</a>

<button class="btn-secondary" onclick="openColumnSettings()">
<i class="fa-solid fa-table-columns"></i>
Columns
</button>

</div>

<!-- Advanced Search Section -->
<div id="advancedSearchPanel" class="advanced-search-panel" style="display:none;">
<form method="GET" class="advanced-search-form">

<h3>Advanced Filters</h3>

<div class="search-filters-grid">

<div>
<label>IP Range</label>
<input type="text" name="s_ip_range" placeholder="e.g., 10.10.10" value="<?=htmlspecialchars($s_ip_range)?>">
</div>

<div>
<label>VLAN</label>
<input type="text" name="s_vlan" placeholder="e.g., VLAN-100" value="<?=htmlspecialchars($s_vlan)?>">
</div>

<div>
<label>Project</label>
<input type="text" name="s_project" placeholder="e.g., ProjectA" value="<?=htmlspecialchars($s_project)?>">
</div>

<div>
<label>Environment</label>
<select name="s_environment">
<option value="">All Environments</option>
<option value="Production" <?=$s_environment==="Production" ? "selected" : ""?>>Production</option>
<option value="PreProd" <?=$s_environment==="PreProd" ? "selected" : ""?>>PreProd</option>
<option value="UAT" <?=$s_environment==="UAT" ? "selected" : ""?>>UAT</option>
<option value="Development" <?=$s_environment==="Development" ? "selected" : ""?>>Development</option>
<option value="Test" <?=$s_environment==="Test" ? "selected" : ""?>>Test</option>
<option value="Sandbox" <?=$s_environment==="Sandbox" ? "selected" : ""?>>Sandbox</option>
<option value="POC" <?=$s_environment==="POC" ? "selected" : ""?>>POC</option>
<option value="DMZ" <?=$s_environment==="DMZ" ? "selected" : ""?>>DMZ</option>
</select>
</div>

<div>
<label>Gateway</label>
<input type="text" name="s_gateway" placeholder="e.g., 10.10.10.1" value="<?=htmlspecialchars($s_gateway)?>">
</div>

<div>
<label>Usable Hosts (Min)</label>
<input type="number" name="s_usable_hosts_min" placeholder="Min" value="<?=htmlspecialchars($s_usable_hosts_min)?>" min="0">
</div>

<div>
<label>Usable Hosts (Max)</label>
<input type="number" name="s_usable_hosts_max" placeholder="Max" value="<?=htmlspecialchars($s_usable_hosts_max)?>" min="0">
</div>

<div>
<label>General Keyword</label>
<input type="text" name="keyword" placeholder="Search across all fields..." value="<?=htmlspecialchars($keyword)?>">
</div>

</div>

<div class="search-filters-actions">
<button type="submit" class="btn-primary">
<i class="fa-solid fa-magnifying-glass"></i>
Apply Filters
</button>
<a href="ip.php" class="btn-secondary">
Clear All
</a>
</div>

</form>
</div>





<div class="table-card">


<table class="ip-table">



<thead>

<tr>

<?php foreach ($ip_columns as $col_key => $col_label): ?>
<?php
$is_sortable = true;
$sort_param_col = ($sort_by === $col_key) ? ($sort_dir === 'ASC' ? 'DESC' : 'ASC') : 'ASC';
$sort_indicator = '';
if ($sort_by === $col_key) {
    $sort_indicator = $sort_dir === 'ASC' ? ' ↑' : ' ↓';
}
$query_params = http_build_query([
    'keyword' => $keyword,
    's_ip_range' => $s_ip_range,
    's_vlan' => $s_vlan,
    's_project' => $s_project,
    's_environment' => $s_environment,
    's_gateway' => $s_gateway,
    's_usable_hosts_min' => $s_usable_hosts_min,
    's_usable_hosts_max' => $s_usable_hosts_max,
    'sort_by' => $col_key,
    'sort_dir' => $sort_param_col
]);
?>

<th
class="col-th-<?=htmlspecialchars($col_key)?> sortable-header <?=in_array($col_key, $visible_columns, true) ? '' : 'hidden-col'?> <?=$sort_by === $col_key ? 'sorted-' . strtolower($sort_dir) : ''?>"
data-col="<?=htmlspecialchars($col_key)?>">

<a href="ip.php?<?=$query_params?>" class="sort-link" title="Click to sort by <?=htmlspecialchars($col_label)?>">
<?=htmlspecialchars($col_label)?><?=$sort_indicator?>
</a>

</th>

<?php endforeach; ?>

<th>
Actions
</th>

</tr>

</thead>



<tbody>

<?php if(count($page_rows)>0): ?>


<?php foreach($page_rows as $row): ?>


<tr>


<?php foreach ($ip_columns as $col_key => $col_label): ?>

<td
class="col-td-<?=htmlspecialchars($col_key)?> <?=in_array($col_key, $visible_columns, true) ? '' : 'hidden-col'?>"
data-field="<?=htmlspecialchars($col_key)?>">

<?php if ($col_key === 'ip_range'): ?>

<span class="ip-badge">

<?=htmlspecialchars($row['ip_range'] ?? "-")?>

</span>

<?php elseif ($col_key === 'environment'): ?>

<span class="environment">

<?=htmlspecialchars($row['environment'] ?? "-")?>

</span>

<?php elseif ($col_key === 'usable_hosts'): ?>

<?=htmlspecialchars($row['usable_hosts'] ?? "0")?>

<?php else: ?>

<?=htmlspecialchars($row[$col_key] ?? "-")?>

<?php endif; ?>

</td>

<?php endforeach; ?>



<td style="text-align: center;">

<div class="row-actions">

<button class="action-icon action-view" title="View" onclick='viewIP(<?=json_encode($row)?>)'>👁</button>

<?php if($canEdit): ?>
<button class="action-icon action-edit" title="Edit" onclick='editIP(<?=json_encode($row)?>)'>✎</button>
<?php endif; ?>

<?php if($canDelete): ?>
<button class="action-icon action-delete" title="Delete" onclick="if(confirm('Delete this IP range?')) { document.getElementById('deleteForm<?=$row['id']?>').submit(); }">🗑</button>
<form id="deleteForm<?=$row['id']?>" method="POST" action="ip-delete.php" style="display:none;">
<input type="hidden" name="id" value="<?=$row['id']?>">
</form>
<?php endif; ?>

<?php if($canAudit): ?>
<button class="action-icon action-history" title="History" onclick='openHistory(<?=(int)$row['id']?>)'>⏱</button>
<?php endif; ?>

</div>

</td>


</tr>



<?php endforeach; ?>



<?php else: ?>


<tr>

<td colspan="10"
class="empty">

No IP ranges found

</td>

</tr>


<?php endif; ?>


</tbody>


</table>


<?php if ($total_pages > 1): ?>
<div class="pagination" style="display:flex;justify-content:center;gap:6px;margin-top:20px;flex-wrap:wrap;">
<?php for ($p = 1; $p <= $total_pages; $p++): ?>
<a
href="ip.php?<?=htmlspecialchars(http_build_query(array_merge($list_query_params, ['page' => $p])))?>"
class="btn-secondary"
style="<?= $p === $current_page ? 'background:#2563eb;color:#fff;border-color:#2563eb;' : '' ?>"
>
<?= $p ?>
</a>
<?php endfor; ?>
</div>
<?php endif; ?>

<div style="text-align:center;color:#94a3b8;font-size:12.5px;margin-top:10px;">
Showing <?= count($page_rows) ?> of <?= $filtered_total ?> IP range<?= $filtered_total === 1 ? '' : 's' ?>
</div>


</div>







<!-- ============================
ADD / EDIT DRAWER
============================ -->


<div id="ipDrawer"
class="drawer">


<div class="drawer-header">


<h2 id="drawerTitle">

Add IP Range

</h2>



<button onclick="closeIPDrawer()">

×

</button>


</div>





<form method="POST"
action="ip-save.php"
id="ipSaveForm">


<input type="hidden"
name="id"
id="id">





<div class="drawer-body">



<div class="section">


<h3>
Network Details
</h3>



<div class="form-grid">



<div>

<label>
IP Range / CIDR
</label>


<input

id="ip_range"

name="ip_range"

placeholder="10.10.10.0/24"

required

>


</div>




<div>

<label>
CIDR
</label>


<input

id="cidr"

name="cidr"

readonly

>


</div>




<div>

<label>
Subnet Mask
</label>


<input

id="subnet"

name="subnet"

readonly

>


</div>




<div>

<label>
Gateway
</label>


<input

id="gateway"

name="gateway"

>

</div>



</div>


</div>







<div class="section">


<h3>
Calculated Network Information
</h3>



<div class="form-grid">



<div>

<label>
Network Address
</label>


<input

id="network"

name="network"

readonly

>


</div>




<div>

<label>
Broadcast
</label>


<input

id="broadcast"

name="broadcast"

readonly

>


</div>





<div>

<label>
Usable Range
</label>


<input

id="usable_range"

name="usable_range"

readonly

>


</div>





<div>

<label>
Total Hosts
</label>


<input

id="total_hosts"

name="total_hosts"

readonly

>


</div>





<div>

<label>
Usable Hosts
</label>


<input

id="usable_hosts"

name="usable_hosts"

readonly

>


</div>



</div>


</div>






<div class="section">


<h3>
Classification
</h3>



<div class="form-grid">



<div>

<label>
VLAN
</label>


<input

id="vlan"

name="vlan"

>

</div>




<div>

<label>
Port Group
</label>


<input

id="portgroup"

name="portgroup"

>

</div>





<div>

<label>
Environment
</label>


<select

id="environment"

name="environment">


<option value="">
Select Environment
</option>


<option>Production</option>

<option>PreProd</option>

<option>UAT</option>

<option>Development</option>

<option>Test</option>

<option>Sandbox</option>

<option>POC</option>

<option>DMZ</option>


</select>


</div>




<div>

<label>
Project
</label>


<input

id="project"

name="project"

>


</div>



</div>


</div>







<div class="section">


<label>
Comments
</label>


<textarea

id="comments"

name="comments"

rows="4">

</textarea>


</div>



</div>








<div class="drawer-footer">



<button

type="button"

class="btn-secondary"

onclick="closeIPDrawer()">

Cancel

</button>




<button

type="submit"

class="btn-primary">

<i class="fa-solid fa-save"></i>

Save IP Range

</button>



</div>



</form>


</div>





<!-- =============================
COLUMN CUSTOMIZATION
============================= -->


<div id="columnPanel"
class="side-panel">



<div class="panel-header">


<h3>
Customize Columns
</h3>



<button onclick="closeColumnSettings()">

×

</button>


</div>




<div class="column-options">


<?php foreach ($ip_columns as $col_key => $col_label): ?>

<label>

<input

type="checkbox"

<?=in_array($col_key, $visible_columns, true) ? 'checked' : ''?>

data-field="<?=htmlspecialchars($col_key)?>">

<?=htmlspecialchars($col_label)?>

</label>

<?php endforeach; ?>


</div>





<button

class="btn-primary"

onclick="saveColumns()">

<i class="fa-solid fa-check"></i>

Apply Layout

</button>



</div>

<!-- =============================
CSV IMPORT
============================= -->


<div id="importModal"
class="overlay">


<div class="modal">


<div class="modal-header">

<h2>
Import IP CSV
</h2>


<button onclick="closeImportModal()">

×

</button>


</div>



<form

action="ip-import.php"

method="POST"

enctype="multipart/form-data">


<input

type="file"

name="csv_file"

accept=".csv"

required>


<p>

CSV Format:

</p>


<code>

ip_range,vlan,gateway,environment,project,portgroup,comments

</code>



<br><br>


<button

class="btn-primary">

<i class="fa-solid fa-upload"></i>

Upload

</button>



<button

type="button"

class="btn-secondary"

onclick="closeImportModal()">

Cancel

</button>


</form>


</div>

</div>





<!-- =============================
HISTORY MODAL
============================= -->


<div id="historyModal"
class="overlay">


<div class="modal history-modal">


<div class="modal-header">


<h2 id="historyModalTitle">
Change History
</h2>



<button onclick="closeHistory()">

×

</button>


</div>



<div id="historyContent">

Loading...

</div>


</div>


</div>






</div>



<script src="assets/js/ip.js"></script>


<script>


/* ============================
ESCAPE HELPER (used by the view modal so field values
   -- which can contain arbitrary text like Comments --
   are never inserted as raw HTML)
============================ */


function escapeHtml(value){


return String(value ?? "-")

.replace(/&/g,"&amp;")

.replace(/</g,"&lt;")

.replace(/>/g,"&gt;")

.replace(/"/g,"&quot;")

.replace(/'/g,"&#039;");


}





function formatFieldLabel(key){


return key

.replaceAll("_"," ")

.replace(/\w\S*/g, function(word){

return word.charAt(0).toUpperCase() + word.slice(1).toLowerCase();

});


}





/* ============================
ADVANCED SEARCH TOGGLE
============================ */

function toggleAdvancedSearch(){
    var panel = document.getElementById("advancedSearchPanel");
    if (panel.style.display === "none") {
        panel.style.display = "block";
    } else {
        panel.style.display = "none";
    }
}





/* ============================
DRAWER
============================ */


function openIPDrawer(){


document
.getElementById("ipDrawer")
.classList.add("show");


}



function closeIPDrawer(){


document
.getElementById("ipDrawer")
.classList.remove("show");


}




function newIP(){


openIPDrawer();



document
.getElementById("ipSaveForm")
.reset();



document
.getElementById("id")
.value="";



document
.getElementById("drawerTitle")
.innerHTML="Add IP Range";


}





function editIP(data){


openIPDrawer();



document
.getElementById("drawerTitle")
.innerHTML="Edit IP Range";



Object.keys(data).forEach(function(key){


let field=document.getElementById(key);



if(field){


field.value=data[key] ?? "";


}



});



}







/* ============================
VIEW
============================
Fixes vs the previous version:
  - values are HTML-escaped instead of injected raw
    (a Comments/Project field containing "<" or "&"
    would previously break the layout or, worse, run
    as HTML)
  - any already-open view modal is removed first, so
    clicking View on multiple rows in a row no longer
    stacks duplicate overlays on top of each other
  - closes on Escape and on click-outside, matching
    the other modals on this page
============================ */


function viewIP(data){


document
.querySelectorAll(".overlay.ip-view-overlay")
.forEach(function(existing){

existing.remove();

});



let html="";


Object.keys(data).forEach(function(k){


html+=`

<div class="detail-item">

<label>
${escapeHtml(formatFieldLabel(k))}
</label>


<strong>

${escapeHtml(data[k])}

</strong>


</div>

`;


});




let modal=document.createElement("div");


modal.className="overlay ip-view-overlay";


modal.style.display="flex";



/* Two tabs: the stored fields, and the inventory servers whose address
   falls inside this range. The host list is loaded on demand, the first
   time its tab is opened. */

const rangeId = data.id || data.ID || "";
const rangeLabel = escapeHtml(data.ip_range || "IP Range");


modal.innerHTML=`

<div class="modal ip-view-modal">


<div class="modal-header">


<h2>
${rangeLabel}
</h2>


<button onclick="this.closest('.overlay').remove()">

×

</button>


</div>


<div class="ip-tabs" role="tablist">

<button type="button" class="ip-tab active" role="tab" data-tab="details">
Range Details
</button>

<button type="button" class="ip-tab" role="tab" data-tab="hosts">
Hosts in Range
</button>

</div>


<div class="ip-tab-panel active" data-panel="details">

<div class="details-grid">

${html}

</div>

</div>


<div class="ip-tab-panel" data-panel="hosts">

<p class="ip-hosts-empty">Loading hosts…</p>

</div>


</div>

`;


/* Tab switching. The hosts panel fetches once and then keeps its
   content, so flicking between tabs does not re-query. */

let hostsLoaded = false;


modal.querySelectorAll(".ip-tab").forEach(function(tab){

tab.addEventListener("click", function(){

modal.querySelectorAll(".ip-tab").forEach(t => t.classList.remove("active"));

modal.querySelectorAll(".ip-tab-panel").forEach(p => p.classList.remove("active"));

tab.classList.add("active");

const panel = modal.querySelector('.ip-tab-panel[data-panel="' + tab.dataset.tab + '"]');

if(panel){ panel.classList.add("active"); }


if(tab.dataset.tab === "hosts" && !hostsLoaded){

hostsLoaded = true;

fetch("ip.php?action=range_hosts&id=" + encodeURIComponent(rangeId))
.then(r => r.text())
.then(function(markup){

panel.innerHTML = markup;

})
.catch(function(){

panel.innerHTML = '<p class="ip-hosts-empty">Could not load hosts for this range.</p>';

hostsLoaded = false;   // allow a retry on the next click

});

}

});

});



modal.addEventListener("click", function(event){

if(event.target === modal){

modal.remove();

}

});



document.body.appendChild(modal);


}





document.addEventListener("keydown", function(event){

if(event.key === "Escape"){

document
.querySelectorAll(".overlay.ip-view-overlay")
.forEach(function(modal){

modal.remove();

});

}

});






/* ============================
IMPORT
============================ */


function openImportModal(){


document
.getElementById("importModal")
.style.display="flex";


}



function closeImportModal(){


document
.getElementById("importModal")
.style.display="none";


}






/* ============================
HISTORY
============================
Called from the per-row "History" button (openHistory(id))
as well as the toolbar's global History link -- that link
still goes to ip-history.php directly. This AJAX path is
for the per-row drill-down: it fetches just the entries for
that one IP range's id, so it should show who created it,
who edited it (and what field changed), and who deleted it
-- not the entire table's history.

NOTE: this expects ip-history.php to support a filtered
mode via ?id=<ip_ranges.id>, returning HTML for just that
record's log rows, the same way the other modules
(inventory.php, asset.php) filter get_history by their own
id. See the note below the code for what that endpoint
needs to look like.
============================ */


function openHistory(id){


document
.getElementById("historyModal")
.style.display="flex";


document
.getElementById("historyModalTitle")
.innerText = id ? ("Change History (Record #" + id + ")") : "Change History";


document
.getElementById("historyContent")
.innerHTML = "Loading...";



fetch(
"ip-history.php?id="+encodeURIComponent(id)
)


.then(r=>r.text())


.then(data=>{


document
.getElementById("historyContent")
.innerHTML=data;


})


.catch(function(){


document
.getElementById("historyContent")
.innerHTML = "Unable to load history.";


});


}



function closeHistory(){


document
.getElementById("historyModal")
.style.display="none";


}







/* ============================
COLUMN SETTINGS
============================ */


function openColumnSettings(){


document
.getElementById("columnPanel")
.classList.add("show");


}




function closeColumnSettings(){


document
.getElementById("columnPanel")
.classList.remove("show");


}







function toggleColumnVisibility(field, visible){

document
.querySelectorAll(
"th[data-col='"+field+"'],td[data-field='"+field+"']"
)
.forEach(function(el){

el.classList.toggle("hidden-col", !visible);

});

}



function getSelectedColumns(){

return Array
.from(document.querySelectorAll(".column-options input[type='checkbox']"))
.filter(function(cb){ return cb.checked; })
.map(function(cb){ return cb.dataset.field; });

}



function saveColumns(){


let selected = getSelectedColumns();


if(selected.length === 0){

alert("Select at least one column.");

return;

}


document
.querySelectorAll(".column-options input")
.forEach(function(cb){

toggleColumnVisibility(cb.dataset.field, cb.checked);

});


let formData = new FormData();

formData.append("form_action", "save_columns");

formData.append("visible_columns", JSON.stringify(selected));


fetch("ip.php", {

method: "POST",

body: formData

})

.then(function(r){ return r.json(); })

.then(function(data){

if(!data || !data.ok){

alert((data && data.message) || "Unable to save column layout.");

}

})

.catch(function(){

alert("Unable to save column layout.");

});


closeColumnSettings();


}


/*
Column visibility on page load is now rendered server-side from
the signed-in user's saved preference (see the "hidden-col" class
applied in PHP on the <th>/<td> elements), so there is no client-side
load step or localStorage involved anymore -- this keeps the layout
consistent across browsers/devices for the same account instead of
being tied to one browser's local storage.
*/




</script>




<?php include "includes/footer.php"; ?>
