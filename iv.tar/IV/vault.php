<?php
/**
 * Password vault.
 *
 * Secrets are NEVER rendered into the page HTML. The listing sends only
 * metadata; the plaintext is fetched by an explicit POST that is CSRF
 * checked, permission checked and written to the access log. Embedding
 * secrets in the markup would put them in view-source, the browser's
 * back/forward cache, and any proxy log along the way -- and would make
 * "who saw this credential" unanswerable, because merely opening the
 * list would have disclosed everything on it.
 */

session_start();

require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/platform-helpers.php';
require_once __DIR__ . '/includes/vault-helpers.php';

requireLogin();
requirePermission('vault', 'can_view');

$canEdit   = can('vault', 'can_edit');
$canDelete = can('vault', 'can_delete');
$canAudit  = can('vault', 'can_audit');

$username = trim((string) ($_SESSION['name'] ?? 'Unknown User'));

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['csrf_token'];

$msg = '';
$err = '';

$categories   = ['Server', 'Database', 'Network Device', 'Application', 'Service Account', 'API Key', 'Certificate', 'Other'];
$environments = ['Production', 'DR', 'Pre-prod', 'SIT', 'Test', 'Development'];

$vaultReady = vaultIsConfigured();


/*
|--------------------------------------------------------------------------
| REVEAL (POST only, logged)
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['form_action'] ?? '') === 'reveal') {

    header('Content-Type: application/json; charset=utf-8');
    // Belt and braces: a secret must never be cached anywhere.
    header('Cache-Control: no-store, no-cache, must-revalidate, private');
    header('Pragma: no-cache');

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        echo json_encode(['ok' => false, 'message' => 'Invalid security token.']);
        exit;
    }

    if (!$vaultReady) {
        http_response_code(503);
        echo json_encode(['ok' => false, 'message' => vaultUnavailableReason()]);
        exit;
    }

    $id = (int) ($_POST['id'] ?? 0);
    $reason = strtoupper(trim((string) ($_POST['reason'] ?? 'REVEAL')));
    if (!in_array($reason, ['REVEAL', 'COPY'], true)) { $reason = 'REVEAL'; }

    $stmt = $pdo->prepare("SELECT * FROM vault_entries WHERE id = ?");
    $stmt->execute([$id]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        http_response_code(404);
        echo json_encode(['ok' => false, 'message' => 'Entry not found.']);
        exit;
    }

    $secret = vaultDecrypt($row['secret_ct'], $row['secret_iv'], $row['secret_tag']);

    if ($secret === null) {
        // Logged as a failure too: repeated failures mean either the wrong
        // key is deployed or rows have been tampered with.
        vaultLog($pdo, $id, (string) $row['title'], 'DECRYPT_FAILED', $username);
        http_response_code(500);
        echo json_encode(['ok' => false, 'message' => 'Unable to decrypt. The vault key may have changed since this entry was saved.']);
        exit;
    }

    vaultLog($pdo, $id, (string) $row['title'], $reason, $username);

    $notes = vaultDecrypt($row['notes_ct'], $row['notes_iv'], $row['notes_tag']);

    echo json_encode([
        'ok'     => true,
        'secret' => $secret,
        'notes'  => $notes ?? '',
    ]);
    exit;
}


/*
|--------------------------------------------------------------------------
| ACCESS LOG
|--------------------------------------------------------------------------
*/

if (($_GET['action'] ?? '') === 'log') {
    requirePermission('vault', 'can_audit');

    $id = (int) ($_GET['id'] ?? 0);

    if ($id > 0) {
        $stmt = $pdo->prepare("SELECT * FROM vault_access_log WHERE entry_id = ? ORDER BY timestamp DESC, id DESC LIMIT 300");
        $stmt->execute([$id]);
    } else {
        $stmt = $pdo->query("SELECT * FROM vault_access_log ORDER BY timestamp DESC, id DESC LIMIT 300");
    }

    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if (!$rows) {
        echo '<p class="plat-empty">No access recorded yet.</p>';
        exit;
    }

    $tone = [
        'REVEAL'         => 'warn',
        'COPY'           => 'warn',
        'CREATED'        => 'ok',
        'UPDATED'        => 'neutral',
        'DELETED'        => 'crit',
        'DECRYPT_FAILED' => 'crit',
    ];

    echo '<div class="plat-table-wrap"><table class="plat-table"><thead><tr>'
       . '<th>Action</th><th>Entry</th><th>By</th><th>IP</th><th>When</th></tr></thead><tbody>';

    foreach ($rows as $r) {
        echo '<tr>'
           . '<td><span class="plat-pill ' . ($tone[$r['action']] ?? 'neutral') . '">' . plat_h($r['action']) . '</span></td>'
           . '<td>' . plat_h($r['entry_title']) . '</td>'
           . '<td>' . plat_h($r['performed_by']) . '</td>'
           . '<td><span class="plat-chip">' . plat_h($r['ip_address'] ?: '—') . '</span></td>'
           . '<td>' . plat_h($r['timestamp']) . '</td>'
           . '</tr>';
    }

    echo '</tbody></table></div>';
    exit;
}


/*
|--------------------------------------------------------------------------
| WRITES
|--------------------------------------------------------------------------
*/

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (!hash_equals($_SESSION['csrf_token'] ?? '', $_POST['csrf_token'] ?? '')) {
        http_response_code(403);
        exit('Invalid security token — reload the page and try again.');
    }

    $formAction = $_POST['form_action'] ?? '';

    if ($formAction === 'save') {
        requirePermission('vault', 'can_edit');

        if (!$vaultReady) {
            $err = 'Cannot save: ' . vaultUnavailableReason();
        } else {
            $id     = (int) ($_POST['id'] ?? 0);
            $title  = trim((string) ($_POST['title'] ?? ''));
            $secret = (string) ($_POST['secret'] ?? '');   // not trimmed: spaces can be significant
            $notes  = (string) ($_POST['notes'] ?? '');

            $meta = [
                'username'    => trim((string) ($_POST['username'] ?? '')),
                'category'    => trim((string) ($_POST['category'] ?? '')),
                'environment' => trim((string) ($_POST['environment'] ?? '')),
                'project'     => trim((string) ($_POST['project'] ?? '')),
                'hostname'    => trim((string) ($_POST['hostname'] ?? '')),
                'url'         => trim((string) ($_POST['url'] ?? '')),
                'owner_team'  => trim((string) ($_POST['owner_team'] ?? '')),
                'rotated_at'  => trim((string) ($_POST['rotated_at'] ?? '')),
                'expires_at'  => trim((string) ($_POST['expires_at'] ?? '')),
            ];

            if ($title === '') {
                $err = 'Title is required.';
            } elseif ($id === 0 && $secret === '') {
                $err = 'A secret is required for a new entry.';
            } else {
                try {
                    $notesEnc = $notes === '' ? null : vaultEncrypt($notes);

                    if ($id > 0) {
                        /*
                         * A blank secret field on edit means "leave it
                         * alone". The existing value is never sent to the
                         * browser, so an empty box cannot be taken as an
                         * instruction to erase it.
                         */
                        if ($secret !== '') {
                            $enc = vaultEncrypt($secret);
                            if ($enc === null) { throw new RuntimeException('Encryption failed.'); }

                            $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($meta)));
                            $pdo->prepare("
                                UPDATE vault_entries
                                SET title = ?, secret_ct = ?, secret_iv = ?, secret_tag = ?,
                                    notes_ct = ?, notes_iv = ?, notes_tag = ?,
                                    key_version = ?, $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                                WHERE id = ?
                            ")->execute([
                                $title, $enc['ct'], $enc['iv'], $enc['tag'],
                                $notesEnc['ct'] ?? null, $notesEnc['iv'] ?? null, $notesEnc['tag'] ?? null,
                                VAULT_KEY_VERSION, ...array_values($meta), $username, $id,
                            ]);
                        } else {
                            $set = implode(', ', array_map(fn($c) => "$c = ?", array_keys($meta)));
                            $pdo->prepare("
                                UPDATE vault_entries
                                SET title = ?, notes_ct = ?, notes_iv = ?, notes_tag = ?,
                                    $set, updated_by = ?, updated_at = CURRENT_TIMESTAMP
                                WHERE id = ?
                            ")->execute([
                                $title,
                                $notesEnc['ct'] ?? null, $notesEnc['iv'] ?? null, $notesEnc['tag'] ?? null,
                                ...array_values($meta), $username, $id,
                            ]);
                        }

                        vaultLog($pdo, $id, $title, 'UPDATED', $username);
                        $msg = 'Entry updated.';

                    } else {
                        $enc = vaultEncrypt($secret);
                        if ($enc === null) { throw new RuntimeException('Encryption failed.'); }

                        $cols = implode(', ', array_keys($meta));
                        $ph   = implode(', ', array_fill(0, count($meta), '?'));

                        $pdo->prepare("
                            INSERT INTO vault_entries
                                (title, secret_ct, secret_iv, secret_tag,
                                 notes_ct, notes_iv, notes_tag, key_version, $cols, created_by)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, $ph, ?)
                        ")->execute([
                            $title, $enc['ct'], $enc['iv'], $enc['tag'],
                            $notesEnc['ct'] ?? null, $notesEnc['iv'] ?? null, $notesEnc['tag'] ?? null,
                            VAULT_KEY_VERSION, ...array_values($meta), $username,
                        ]);

                        vaultLog($pdo, (int) $pdo->lastInsertId(), $title, 'CREATED', $username);
                        $msg = 'Entry added.';
                    }
                } catch (Throwable $e) {
                    $err = 'Unable to save: ' . $e->getMessage();
                }
            }
        }
    }

    if ($formAction === 'delete') {
        requirePermission('vault', 'can_delete');

        $id = (int) ($_POST['id'] ?? 0);
        $n = $pdo->prepare("SELECT title FROM vault_entries WHERE id = ?");
        $n->execute([$id]);
        $title = (string) ($n->fetchColumn() ?: 'Unknown');

        $pdo->prepare("DELETE FROM vault_entries WHERE id = ?")->execute([$id]);
        vaultLog($pdo, $id, $title, 'DELETED', $username);

        $msg = 'Entry deleted.';
    }
}


/*
|--------------------------------------------------------------------------
| DATA (metadata only -- no secrets leave the server here)
|--------------------------------------------------------------------------
*/

$q     = trim((string) ($_GET['q'] ?? ''));
$fCat  = trim((string) ($_GET['f_cat'] ?? ''));

$where  = ['1=1'];
$params = [];

if ($q !== '') {
    $where[] = '(title LIKE ? OR username LIKE ? OR hostname LIKE ? OR project LIKE ?)';
    array_push($params, "%$q%", "%$q%", "%$q%", "%$q%");
}
if ($fCat !== '') { $where[] = 'category = ?'; $params[] = $fCat; }

$whereSql = implode(' AND ', $where);

$stmt = $pdo->prepare("
    SELECT id, title, username, category, environment, project, hostname, url,
           owner_team, rotated_at, expires_at, key_version,
           created_by, created_at, updated_by, updated_at
    FROM vault_entries WHERE $whereSql ORDER BY title
");
$stmt->execute($params);
$entries = $stmt->fetchAll(PDO::FETCH_ASSOC);

$total = count($entries);
$today = date('Y-m-d');
$expiring = $expired = 0;

foreach ($entries as $e) {
    if (!empty($e['expires_at'])) {
        if ($e['expires_at'] < $today) {
            $expired++;
        } elseif ($e['expires_at'] <= date('Y-m-d', strtotime('+30 days'))) {
            $expiring++;
        }
    }
}

$recentReveals = 0;
try {
    $recentReveals = (int) $pdo->query("
        SELECT COUNT(*) FROM vault_access_log
        WHERE action IN ('REVEAL','COPY') AND timestamp >= datetime('now','-7 days')
    ")->fetchColumn();
} catch (Throwable $e) {
    // Display value only.
}

$hostnames = platformHostnames($pdo);

$page_title = 'Password Vault | InfraVault';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/sidebar.php';
?>
<link rel="stylesheet" href="assets/css/platform.css">

<div class="content">

    <div class="plat-hero">
        <div class="plat-hero-main">
            <div class="plat-hero-icon">🔐</div>
            <div>
                <h1>Password Vault</h1>
                <p>Shared infrastructure credentials, encrypted at rest. Every reveal and copy is recorded.</p>
            </div>
        </div>
        <div class="plat-actions">
            <?php if ($canEdit && $vaultReady): ?>
                <button type="button" class="plat-btn plat-btn-primary" onclick="vOpen()">+ Add Entry</button>
            <?php endif; ?>
            <?php if ($canAudit): ?>
                <button type="button" class="plat-btn" onclick="vLog(0)">Access Log</button>
            <?php endif; ?>
        </div>
    </div>

    <?php if (!$vaultReady): ?>
        <div class="plat-alert plat-alert-err">
            <strong>Vault is not configured.</strong>
            <?= plat_h(vaultUnavailableReason()) ?>
            Existing entries cannot be read and new ones cannot be saved until this is set —
            the vault refuses rather than storing anything in plain text.
        </div>
    <?php endif; ?>

    <?php if ($msg): ?><div class="plat-alert plat-alert-ok"><?= plat_h($msg) ?></div><?php endif; ?>
    <?php if ($err): ?><div class="plat-alert plat-alert-err"><?= plat_h($err) ?></div><?php endif; ?>

    <div class="plat-stats">
        <div class="plat-stat"><b><?= $total ?></b><span>Entries</span></div>
        <div class="plat-stat tone-warn"><b><?= $expiring ?></b><span>Expiring &lt;30d</span></div>
        <div class="plat-stat tone-crit"><b><?= $expired ?></b><span>Expired</span></div>
        <div class="plat-stat"><b><?= $recentReveals ?></b><span>Reveals (7d)</span></div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head"><h3>Search</h3></div>
        <div class="plat-panel-body">
            <form method="GET" class="plat-filters">
                <div class="plat-field">
                    <label>Search</label>
                    <input type="text" name="q" value="<?= plat_h($q) ?>" placeholder="Title, username, host, project…">
                </div>
                <div class="plat-field">
                    <label>Category</label>
                    <select name="f_cat">
                        <option value="">All</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>" <?= $fCat === $c ? 'selected' : '' ?>><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <button type="submit" class="plat-btn plat-btn-accent">Search</button>
                <a href="vault.php" class="plat-btn plat-btn-light">Reset</a>
            </form>
        </div>
    </div>

    <div class="plat-panel">
        <div class="plat-panel-head">
            <h3>Entries</h3>
            <span style="font-size:13px;color:var(--text-muted);"><?= $total ?> shown</span>
        </div>
        <div class="plat-table-wrap">
            <table class="plat-table">
                <thead>
                    <tr>
                        <th>Title</th><th>Username</th><th>Secret</th><th>Category</th>
                        <th>Host / URL</th><th>Rotated</th><th>Expires</th>
                        <th style="text-align:center;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (!$entries): ?>
                    <tr><td colspan="8"><p class="plat-empty">No credentials stored yet.</p></td></tr>
                <?php else: foreach ($entries as $e): ?>
                    <?php
                        $eid = (int) $e['id'];
                        $isExpired  = !empty($e['expires_at']) && $e['expires_at'] < $today;
                        $isExpiring = !$isExpired && !empty($e['expires_at']) && $e['expires_at'] <= date('Y-m-d', strtotime('+30 days'));
                    ?>
                    <tr>
                        <td>
                            <span class="plat-primary"><?= plat_h($e['title']) ?></span>
                            <span class="plat-sub"><?= plat_h($e['project'] ?: $e['owner_team'] ?: '—') ?></span>
                        </td>
                        <td>
                            <?php if ($e['username']): ?>
                                <span class="plat-chip" id="u<?= $eid ?>"><?= plat_h($e['username']) ?></span>
                                <button type="button" class="plat-icon-btn plat-btn-sm" style="width:26px;height:26px;font-size:12px;"
                                    title="Copy username" onclick="vCopyText('<?= plat_h(addslashes($e['username'])) ?>', this)">⧉</button>
                            <?php else: ?>—<?php endif; ?>
                        </td>
                        <td>
                            <!-- The secret is not present in this markup. -->
                            <code class="v-secret" id="s<?= $eid ?>">••••••••••</code>
                            <?php if ($vaultReady): ?>
                                <button type="button" class="plat-icon-btn plat-icon-view" title="Reveal"
                                    onclick="vReveal(<?= $eid ?>, this)">👁</button>
                                <button type="button" class="plat-icon-btn plat-icon-hist" title="Copy secret"
                                    onclick="vCopySecret(<?= $eid ?>, this)">⧉</button>
                            <?php endif; ?>
                        </td>
                        <td><span class="plat-pill neutral"><?= plat_h($e['category'] ?: '—') ?></span>
                            <?php if ($e['environment']): ?><span class="plat-sub"><?= plat_h($e['environment']) ?></span><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($e['hostname']): ?><span class="plat-chip"><?= plat_h($e['hostname']) ?></span><?php endif; ?>
                            <?php if ($e['url']): ?><span class="plat-sub"><a href="<?= plat_h($e['url']) ?>" target="_blank" rel="noopener"><?= plat_h(mb_strimwidth((string) $e['url'], 0, 34, '…')) ?></a></span><?php endif; ?>
                            <?= (!$e['hostname'] && !$e['url']) ? '—' : '' ?>
                        </td>
                        <td><?= plat_h($e['rotated_at'] ?: '—') ?></td>
                        <td>
                            <?php if ($isExpired): ?>
                                <span class="plat-pill crit"><?= plat_h($e['expires_at']) ?></span>
                            <?php elseif ($isExpiring): ?>
                                <span class="plat-pill warn"><?= plat_h($e['expires_at']) ?></span>
                            <?php else: ?>
                                <?= plat_h($e['expires_at'] ?: '—') ?>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="plat-row-actions">
                                <?php if ($canEdit && $vaultReady): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-edit" title="Edit"
                                        onclick='vOpen(<?= json_encode($e, JSON_HEX_APOS | JSON_HEX_QUOT) ?>)'>✎</button>
                                <?php endif; ?>
                                <?php if ($canAudit): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-hist" title="Access log"
                                        onclick="vLog(<?= $eid ?>)">⏱</button>
                                <?php endif; ?>
                                <?php if ($canDelete): ?>
                                    <button type="button" class="plat-icon-btn plat-icon-del" title="Delete"
                                        onclick="vDelete(<?= $eid ?>, '<?= plat_h(addslashes($e['title'])) ?>')">🗑</button>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<div class="plat-modal" id="vModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head">
            <h2 id="vTitle">Add Entry</h2>
            <button type="button" class="plat-close" onclick="platClose('vModal')">&times;</button>
        </div>
        <p class="plat-modal-sub" id="vSubtitle">The secret and the notes are both encrypted before they are stored.</p>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="save">
            <input type="hidden" name="id" id="v_id">

            <div class="plat-form-grid">
                <div class="plat-field"><label>Title *</label><input type="text" name="title" id="v_title" required placeholder="e.g. Oracle SYS - PROD"></div>
                <div class="plat-field"><label>Username</label><input type="text" name="username" id="v_username"></div>
                <div class="plat-field"><label>Category</label>
                    <select name="category" id="v_category">
                        <option value="">—</option>
                        <?php foreach ($categories as $c): ?><option value="<?= plat_h($c) ?>"><?= plat_h($c) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <div class="plat-field full">
                    <label>Secret <span id="v_secret_hint" style="font-weight:400;color:var(--text-muted);"></span></label>
                    <div style="display:flex;gap:6px;align-items:center;">
                        <input type="password" name="secret" id="v_secret" style="flex:1;" autocomplete="new-password">
                        <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="vToggleField()">Show</button>
                        <button type="button" class="plat-btn plat-btn-light plat-btn-sm" onclick="vGenerate()">Generate</button>
                    </div>
                    <small id="v_strength" style="color:var(--text-muted);"></small>
                </div>

                <div class="plat-field"><label>Environment</label>
                    <select name="environment" id="v_environment">
                        <option value="">—</option>
                        <?php foreach ($environments as $e): ?><option value="<?= plat_h($e) ?>"><?= plat_h($e) ?></option><?php endforeach; ?>
                    </select>
                </div>
                <div class="plat-field"><label>Project</label><input type="text" name="project" id="v_project"></div>
                <div class="plat-field"><label>Owner Team</label><input type="text" name="owner_team" id="v_owner_team"></div>

                <div class="plat-field"><label>Hostname</label><input list="platHostnames" name="hostname" id="v_hostname"></div>
                <div class="plat-field"><label>URL</label><input type="url" name="url" id="v_url"></div>
                <div class="plat-field"><label>Last Rotated</label><input type="date" name="rotated_at" id="v_rotated_at"></div>

                <div class="plat-field"><label>Expires</label><input type="date" name="expires_at" id="v_expires_at"></div>

                <div class="plat-field full"><label>Notes (encrypted)</label><textarea name="notes" id="v_notes" rows="2"></textarea></div>
            </div>

            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('vModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-accent">Save Entry</button>
            </div>
        </form>
    </div>
</div>

<div class="plat-modal" id="vLogModal">
    <div class="plat-modal-inner">
        <div class="plat-modal-head"><h2 id="vLogTitle">Access Log</h2>
            <button type="button" class="plat-close" onclick="platClose('vLogModal')">&times;</button></div>
        <div id="vLogBody"><p class="plat-empty">Loading…</p></div>
    </div>
</div>

<div class="plat-modal" id="vDelModal">
    <div class="plat-modal-inner narrow">
        <div class="plat-modal-head"><h2>Delete entry</h2>
            <button type="button" class="plat-close" onclick="platClose('vDelModal')">&times;</button></div>
        <p style="color:var(--text-secondary);">Delete <strong id="vDelName"></strong>? The stored secret is destroyed and cannot be recovered.</p>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= plat_h($csrf) ?>">
            <input type="hidden" name="form_action" value="delete">
            <input type="hidden" name="id" id="vDelId">
            <div class="plat-modal-foot">
                <button type="button" class="plat-btn plat-btn-light" onclick="platClose('vDelModal')">Cancel</button>
                <button type="submit" class="plat-btn plat-btn-danger">Delete</button>
            </div>
        </form>
    </div>
</div>

<datalist id="platHostnames">
    <?php foreach ($hostnames as $h): ?><option value="<?= plat_h($h) ?>"></option><?php endforeach; ?>
</datalist>

<style>
.v-secret {
    font-family: ui-monospace, Consolas, monospace;
    font-size: 13px;
    letter-spacing: .06em;
    color: var(--text-secondary);
    padding: 3px 8px;
    background: var(--hover-bg);
    border-radius: 6px;
    user-select: all;
}
.v-secret.revealed { color: var(--text-primary); background: #FDF2E3; }
[data-theme="dark"] .v-secret.revealed { background: #2B2111; }
</style>

<script>
const V_CSRF = <?= json_encode($csrf) ?>;

function platClose(id) { document.getElementById(id).classList.remove('show'); }
function platOpen(id)  { document.getElementById(id).classList.add('show'); }

/* Fetches the plaintext. Every call is server-side logged. */
function vFetchSecret(id, reason) {
    const body = new FormData();
    body.append('form_action', 'reveal');
    body.append('csrf_token', V_CSRF);
    body.append('id', id);
    body.append('reason', reason);

    return fetch('vault.php', { method: 'POST', body: body, cache: 'no-store' })
        .then(r => r.json());
}

function vReveal(id, btn) {
    const cell = document.getElementById('s' + id);

    // Second click hides it again.
    if (cell.classList.contains('revealed')) {
        cell.textContent = '••••••••••';
        cell.classList.remove('revealed');
        return;
    }

    cell.textContent = '…';

    vFetchSecret(id, 'REVEAL').then(d => {
        if (!d.ok) { cell.textContent = '••••••••••'; alert(d.message || 'Unable to reveal.'); return; }
        cell.textContent = d.secret;
        cell.classList.add('revealed');

        // Auto-hide: a revealed secret left on screen is a shoulder-surfing
        // risk and tends to end up in screenshots.
        setTimeout(() => {
            if (cell.classList.contains('revealed')) {
                cell.textContent = '••••••••••';
                cell.classList.remove('revealed');
            }
        }, 30000);
    }).catch(() => { cell.textContent = '••••••••••'; alert('Unable to reveal.'); });
}

function vCopySecret(id, btn) {
    vFetchSecret(id, 'COPY').then(d => {
        if (!d.ok) { alert(d.message || 'Unable to copy.'); return; }
        vCopyText(d.secret, btn);
    }).catch(() => alert('Unable to copy.'));
}

function vCopyText(text, btn) {
    const done = () => {
        if (!btn) { return; }
        const old = btn.textContent;
        btn.textContent = '✓';
        setTimeout(() => { btn.textContent = old; }, 1200);
    };

    if (navigator.clipboard && window.isSecureContext) {
        navigator.clipboard.writeText(text).then(done).catch(() => vCopyFallback(text, done));
    } else {
        // clipboard API needs HTTPS; this app may be served over plain
        // HTTP internally, so the legacy path is kept.
        vCopyFallback(text, done);
    }
}

function vCopyFallback(text, done) {
    const ta = document.createElement('textarea');
    ta.value = text;
    ta.setAttribute('readonly', '');
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    try { document.execCommand('copy'); done(); }
    catch (e) { alert('Copy failed — reveal the secret and copy it manually.'); }
    document.body.removeChild(ta);
}

function vToggleField() {
    const f = document.getElementById('v_secret');
    f.type = f.type === 'password' ? 'text' : 'password';
}

function vGenerate() {
    const alphabet = 'abcdefghijkmnopqrstuvwxyzABCDEFGHJKLMNPQRSTUVWXYZ23456789!@#$%^&*()-_=+';
    const bytes = new Uint32Array(24);
    crypto.getRandomValues(bytes);

    let out = '';
    for (let i = 0; i < bytes.length; i++) { out += alphabet[bytes[i] % alphabet.length]; }

    const f = document.getElementById('v_secret');
    f.value = out;
    f.type = 'text';
    vScore();
}

function vScore() {
    const s = document.getElementById('v_secret').value;
    const out = document.getElementById('v_strength');
    if (!s) { out.textContent = ''; return; }

    let n = 0;
    if (s.length >= 8) n++;
    if (s.length >= 12) n++;
    if (s.length >= 16) n++;
    if (/[a-z]/.test(s) && /[A-Z]/.test(s)) n++;
    if (/[0-9]/.test(s)) n++;
    if (/[^A-Za-z0-9]/.test(s)) n++;

    out.textContent = (n <= 2 ? 'Weak' : n <= 4 ? 'Fair' : 'Strong') + ' · ' + s.length + ' characters';
}

document.addEventListener('DOMContentLoaded', () => {
    const f = document.getElementById('v_secret');
    if (f) { f.addEventListener('input', vScore); }
});

function vOpen(data) {
    const editing = !!data;
    document.getElementById('vTitle').innerText = editing ? 'Edit Entry' : 'Add Entry';
    document.getElementById('v_id').value = editing ? data.id : '';

    ['title','username','category','environment','project','owner_team','hostname','url','rotated_at','expires_at']
        .forEach(f => {
            const el = document.getElementById('v_' + f);
            if (el) { el.value = editing ? (data[f] ?? '') : ''; }
        });

    // The stored secret and notes are deliberately not loaded into the
    // form. Blank means "keep what is stored".
    const sec = document.getElementById('v_secret');
    sec.value = '';
    sec.type = 'password';
    document.getElementById('v_notes').value = '';
    document.getElementById('v_strength').textContent = '';

    document.getElementById('v_secret_hint').textContent =
        editing ? '— leave blank to keep the current secret' : '';
    document.getElementById('vSubtitle').textContent = editing
        ? 'Leave the secret blank to keep the stored one. Notes are re-saved from this form.'
        : 'The secret and the notes are both encrypted before they are stored.';

    platOpen('vModal');
}

function vLog(id) {
    document.getElementById('vLogTitle').innerText = id ? 'Access Log — entry #' + id : 'Vault Access Log';
    document.getElementById('vLogBody').innerHTML = '<p class="plat-empty">Loading…</p>';
    platOpen('vLogModal');

    fetch('vault.php?action=log&id=' + encodeURIComponent(id))
        .then(r => r.text())
        .then(h => { document.getElementById('vLogBody').innerHTML = h; })
        .catch(() => { document.getElementById('vLogBody').innerHTML = '<p class="plat-empty">Failed to load.</p>'; });
}

function vDelete(id, name) {
    document.getElementById('vDelId').value = id;
    document.getElementById('vDelName').innerText = name;
    platOpen('vDelModal');
}
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
